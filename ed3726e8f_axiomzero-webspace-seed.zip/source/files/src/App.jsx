import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import { lazy, Suspense } from 'react';
// Add page imports here
import AxiomZero from '@/pages/AxiomZero';
const About = lazy(() => import('@/pages/About'));
const DataInfrastructure = lazy(() => import('@/pages/combined/DataInfrastructure'));
const Outreach = lazy(() => import('@/pages/combined/Outreach'));
import QuantumCat from '@/components/quantum-cat/QuantumCat';
import GlobalOverlays from '@/components/shared/GlobalOverlays';
const AxiomOSCore = lazy(() => import('@/pages/AxiomOSCore'));
const Lean4Formalization = lazy(() => import('@/pages/Lean4Formalization'));
const IntegrationHub = lazy(() => import('@/pages/IntegrationHub'));
const EclipsaIntegrity = lazy(() => import('@/pages/EclipsaIntegrity'));
const Delphi = lazy(() => import('@/pages/Delphi'));
const AxiomJournalist = lazy(() => import('@/pages/AxiomJournalist'));
const FilmersCompanion = lazy(() => import('@/pages/FilmersCompanion'));
const MerlinFirstAddress = lazy(() => import('@/pages/MerlinFirstAddress'));
const MerlinLibrary = lazy(() => import('@/pages/MerlinLibrary'));
const MerlinGovernance = lazy(() => import('@/pages/MerlinGovernance'));
const MerlinDmAssistant = lazy(() => import('@/pages/MerlinDmAssistant'));
const FoundingFathers = lazy(() => import('@/pages/FoundingFathers'));
const AZProducts = lazy(() => import('@/pages/AZProducts'));
const EIGE = lazy(() => import('@/pages/az-apps/EIGE'));
const OmegaSynthesis = lazy(() => import('@/pages/az-apps/OmegaSynthesis'));
const HolonZero = lazy(() => import('@/pages/az-apps/HolonZero'));
const TerraOS = lazy(() => import('@/pages/az-apps/TerraOS'));
const Pentacorder = lazy(() => import('@/pages/az-apps/Pentacorder'));
const GeoMonitor = lazy(() => import('@/pages/az-apps/GeoMonitor'));
const PsicatWebBrowser = lazy(() => import('@/pages/PsicatWebBrowser'));
const SdrRadioConsole = lazy(() => import('@/pages/SdrRadioConsole'));
const Lean4ProofLab = lazy(() => import('@/pages/Lean4ProofLab'));
const ClosurePipelineSimulator = lazy(() => import('@/pages/ClosurePipelineSimulator'));
const LeanPythonBridge = lazy(() => import('@/pages/LeanPythonBridge'));
const PsiCatPromotion = lazy(() => import('@/pages/PsiCatPromotion'));
// Combined pages (webspace compactification)
const TrainingGym = lazy(() => import('@/pages/combined/TrainingGym'));
const Labs = lazy(() => import('@/pages/combined/Labs'));
const MerlinHub = lazy(() => import('@/pages/combined/MerlinHub'));
const FalsificationLab = lazy(() => import('@/pages/combined/FalsificationLab'));
const Corporate = lazy(() => import('@/pages/combined/Corporate'));
const PentadGovernance = lazy(() => import('@/pages/combined/PentadGovernance'));
const GovernanceLedgerHub = lazy(() => import('@/pages/combined/GovernanceLedgerHub'));
const SystemStatus = lazy(() => import('@/pages/combined/SystemStatus'));
const SafetyHub = lazy(() => import('@/pages/combined/SafetyHub'));
const ManifoldExplorer = lazy(() => import('@/pages/combined/ManifoldExplorer'));
const KnowledgeHub = lazy(() => import('@/pages/combined/KnowledgeHub'));
const LensSuite = lazy(() => import('@/pages/combined/LensSuite'));
const RecordsHub = lazy(() => import('@/pages/combined/RecordsHub'));
import LicenseNotice from '@/components/shared/LicenseNotice';
import JsonLdInjector from '@/components/shared/JsonLdInjector';
import PsiCatRouteLoader from '@/components/shared/PsiCatRouteLoader';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin, checkAppState } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    } else if (authError.type === 'unknown') {
      // Recoverable bootstrap failure — never render the app user-less (cascades 500s)
      return (
        <div className="fixed inset-0 flex items-center justify-center bg-[#0B0F13] p-4">
          <div className="glass-strong clip-corner p-6 max-w-md w-full text-center">
            <p className="text-sm font-bold text-[#FF9F00] mb-1.5 font-heading">Couldn't load the application</p>
            <p className="text-[11px] text-[#8b949e] mb-4 leading-relaxed">
              {authError.message || 'An unexpected error occurred while starting up.'}
            </p>
            <button onClick={() => checkAppState()}
              className="px-4 py-2.5 bg-[#FF9F00] text-black text-xs font-bold clip-corner touch-manipulation hover:brightness-110">
              Retry
            </button>
          </div>
        </div>
      );
    }
  }

  // Render the main app
  return (
    <>
    <Suspense fallback={<PsiCatRouteLoader />}>
    <Routes>
      {/* Add your page Route elements here */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/" element={<AxiomZero />} />
      <Route path="/psicat-first-address" element={<MerlinFirstAddress />} />
      <Route path="/merlin-first-address" element={<Navigate to="/psicat-first-address" replace />} />
      <Route path="/psicat-library" element={<MerlinLibrary />} />
      <Route path="/merlin-library" element={<Navigate to="/psicat-library" replace />} />
      <Route path="/psicat-governance" element={<MerlinGovernance />} />
      <Route path="/merlin-governance" element={<Navigate to="/psicat-governance" replace />} />
      <Route path="/cognitive-layer" element={<Navigate to="/axiom-os-core" replace />} />
      <Route path="/repository" element={<Navigate to="/manifold-explorer" replace />} />
      <Route path="/about" element={<About />} />
      <Route path="/projects" element={<Navigate to="/az-products" replace />} />
      <Route path="/task-management" element={<Navigate to="/records-hub" replace />} />
      <Route path="/technology-roadmap" element={<Navigate to="/knowledge-hub" replace />} />
      <Route path="/resource-library" element={<Navigate to="/knowledge-hub" replace />} />
      <Route path="/client-inquiry" element={<Navigate to="/corporate" replace />} />
      <Route path="/media-archive" element={<Navigate to="/outreach" replace />} />
      <Route path="/alliances" element={<Navigate to="/outreach" replace />} />
      <Route path="/orientation-portals" element={<Navigate to="/" replace />} />
      <Route path="/ethical-synthesis" element={<Navigate to="/lens-suite" replace />} />
      <Route path="/axiom-os-core" element={<AxiomOSCore />} />
      <Route path="/unitary-sos" element={<Navigate to="/axiom-os-core" replace />} />
      <Route path="/lean4-formalization" element={<Lean4Formalization />} />
      <Route path="/data-provenance" element={<Navigate to="/data-infrastructure" replace />} />
      <Route path="/axiom-archive" element={<Navigate to="/records-hub" replace />} />
      <Route path="/axiom-ledger" element={<Navigate to="/records-hub" replace />} />
      <Route path="/integration-hub" element={<IntegrationHub />} />
      <Route path="/contributor-portal" element={<Navigate to="/corporate" replace />} />
      <Route path="/eclipsa-integrity" element={<EclipsaIntegrity />} />
      <Route path="/eclipsa-logs" element={<Navigate to="/eclipsa-integrity" replace />} />
      <Route path="/eclipsa-status" element={<Navigate to="/eclipsa-integrity" replace />} />
      <Route path="/system-integrity" element={<Navigate to="/eclipsa-integrity" replace />} />
      <Route path="/delphi" element={<Delphi />} />
      <Route path="/tarot-oracle" element={<Navigate to="/delphi" replace />} />
      <Route path="/oracle-engine" element={<Navigate to="/delphi" replace />} />
      <Route path="/axiom-journalist" element={<AxiomJournalist />} />
      <Route path="/filmers-companion" element={<FilmersCompanion />} />
      <Route path="/psicat-dm-assistant" element={<MerlinDmAssistant />} />
      <Route path="/merlin-dm-assistant" element={<Navigate to="/psicat-dm-assistant" replace />} />
      <Route path="/compactification" element={<Navigate to="/axiom-os-core" replace />} />
      <Route path="/founding-fathers" element={<FoundingFathers />} />
      <Route path="/repo-docs" element={<Navigate to="/manifold-explorer" replace />} />
      <Route path="/az-products" element={<AZProducts />} />
      <Route path="/settings" element={<Navigate to="/" replace />} />
      <Route path="/az-kernel" element={<Navigate to="/axiom-os-core" replace />} />
      <Route path="/eige" element={<EIGE />} />
      <Route path="/uos-kernel" element={<Navigate to="/axiom-os-core" replace />} />
      <Route path="/omega-synthesis" element={<OmegaSynthesis />} />
      <Route path="/holon-zero" element={<HolonZero />} />
      <Route path="/omegaholon" element={<Navigate to="/holon-zero" replace />} />
      <Route path="/terra-os" element={<TerraOS />} />
      <Route path="/lithos-os" element={<Navigate to="/terra-os" replace />} />
      <Route path="/botanica-os" element={<Navigate to="/terra-os" replace />} />
      <Route path="/sdam" element={<Navigate to="/pentacorder" replace />} />
      <Route path="/pentacorder" element={<Pentacorder />} />
      <Route path="/flashcard-trainer" element={<Navigate to="/psicat" replace />} />
      <Route path="/omega-oracle" element={<Navigate to="/delphi" replace />} />
      <Route path="/um-image-generator" element={<Navigate to="/lens-suite" replace />} />
      <Route path="/um-reader" element={<Navigate to="/knowledge-hub" replace />} />
      <Route path="/ox-navigator" element={<Navigate to="/psicat" replace />} />
      <Route path="/geo-monitor" element={<GeoMonitor />} />
      <Route path="/psicat-browser" element={<PsicatWebBrowser />} />
      <Route path="/sdr-radio" element={<SdrRadioConsole />} />
      <Route path="/lean4-proof-lab" element={<Lean4ProofLab />} />
      <Route path="/closure-pipeline" element={<ClosurePipelineSimulator />} />
      <Route path="/lean-python-bridge" element={<LeanPythonBridge />} />
      <Route path="/psicat-promotion" element={<PsiCatPromotion />} />
      <Route path="/az-sge" element={<Navigate to="/safety" replace />} />
      <Route path="/hf-spaces" element={<Navigate to="/system-status" replace />} />
      {/* Combined pages (webspace compactification) */}
      <Route path="/training-gym" element={<TrainingGym />} />
      <Route path="/labs" element={<Labs />} />
      <Route path="/psicat" element={<MerlinHub />} />
      <Route path="/merlin" element={<Navigate to="/psicat" replace />} />
      <Route path="/falsification-lab" element={<FalsificationLab />} />
      <Route path="/corporate" element={<Corporate />} />
      <Route path="/pentad-governance" element={<PentadGovernance />} />
      <Route path="/governance-ledger" element={<GovernanceLedgerHub />} />
      <Route path="/system-status" element={<SystemStatus />} />
      <Route path="/safety" element={<SafetyHub />} />
      <Route path="/manifold-explorer" element={<ManifoldExplorer />} />
      <Route path="/knowledge-hub" element={<KnowledgeHub />} />
      <Route path="/lens-suite" element={<LensSuite />} />
      <Route path="/crawl-center" element={<Navigate to="/data-infrastructure" replace />} />
      <Route path="/records-hub" element={<RecordsHub />} />
      <Route path="/data-infrastructure" element={<DataInfrastructure />} />
      <Route path="/outreach" element={<Outreach />} />
      {/* ── Compactification redirects — old standalone paths → combined hubs ── */}
      <Route path="/knowledge-base" element={<Navigate to="/knowledge-hub" replace />} />
      <Route path="/faq" element={<Navigate to="/knowledge-hub" replace />} />
      <Route path="/glossary" element={<Navigate to="/knowledge-hub" replace />} />
      <Route path="/api-documentation" element={<Navigate to="/knowledge-hub" replace />} />
      <Route path="/interactive-labs" element={<Navigate to="/labs" replace />} />
      <Route path="/dev-sandbox" element={<Navigate to="/labs" replace />} />
      <Route path="/stem-sandbox" element={<Navigate to="/labs" replace />} />
      <Route path="/unitary-notebook" element={<Navigate to="/labs" replace />} />
      <Route path="/training-lodge" element={<Navigate to="/training-gym" replace />} />
      <Route path="/gym-analytics" element={<Navigate to="/training-gym" replace />} />
      <Route path="/training-catalog" element={<Navigate to="/training-gym" replace />} />
      <Route path="/thermo-reports" element={<Navigate to="/training-gym" replace />} />
      <Route path="/gym-certification" element={<Navigate to="/training-gym" replace />} />
      <Route path="/ethical-lens" element={<Navigate to="/lens-suite" replace />} />
      <Route path="/quantum-lens" element={<Navigate to="/lens-suite" replace />} />
      <Route path="/safety-protocols" element={<Navigate to="/safety" replace />} />
      <Route path="/emergency-protocols" element={<Navigate to="/safety" replace />} />
      <Route path="/corporate-charter" element={<Navigate to="/corporate" replace />} />
      <Route path="/compliance-portal" element={<Navigate to="/corporate" replace />} />
      <Route path="/system-telemetry" element={<Navigate to="/system-status" replace />} />
      <Route path="/um-status-dashboard" element={<Navigate to="/system-status" replace />} />
      <Route path="/um-status" element={<Navigate to="/system-status" replace />} />
      <Route path="/system-governance" element={<Navigate to="/governance-ledger" replace />} />
      <Route path="/audit-log" element={<Navigate to="/governance-ledger" replace />} />
      <Route path="/merlin-docs" element={<Navigate to="/psicat" replace />} />
      <Route path="/merlin-research" element={<Navigate to="/psicat" replace />} />
      <Route path="/merlin-interface" element={<Navigate to="/psicat" replace />} />
      <Route path="/unitary-explorer" element={<Navigate to="/manifold-explorer" replace />} />
      <Route path="/manifold-atlas" element={<Navigate to="/manifold-explorer" replace />} />
      <Route path="/pentad-dashboard" element={<Navigate to="/pentad-governance" replace />} />
      <Route path="/falsification-observatory" element={<Navigate to="/falsification-lab" replace />} />
      <Route path="/interrogator" element={<Navigate to="/falsification-lab" replace />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
    </Suspense>
    <QuantumCat />
    <GlobalOverlays />
    <JsonLdInjector />
    <LicenseNotice />
    </>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App