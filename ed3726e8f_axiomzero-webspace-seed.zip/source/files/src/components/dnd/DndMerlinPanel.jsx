import { useState } from 'react';
import PageMerlinPanel from '@/components/shared/PageMerlinPanel';
import { Dices } from 'lucide-react';

const SUGGESTED_QUESTIONS = [
  'What\'s a balanced encounter for a party of 4 level-3 characters?',
  'Explain the difference between 5e-2014 and 5e-2024 exhaustion rules',
  'How does the Spirit Guardians spell interact with difficult terrain?',
  'Generate an NPC for a frontier town — a suspicious merchant with a secret',
  'What conditions can a Ghoul inflict and how do I resolve them?',
  'Help me build a level 5 Forge Domain Cleric spell loadout',
  'What\'s the tactical difference between a Young Red Dragon and an Adult Red Dragon?',
  'Generate a quest seed for a haunted forest with a lycanthrope theme',
];

export default function DndMerlinPanel({ isOpen, onClose, liveState }) {
  return (
    <PageMerlinPanel
      pagePath="/psicat-dm-assistant"
      pageTitle="Merlin DM Guide & Player Assistant"
      pageDescription="D&D 5e/5.5e campaign management with deterministic encounter balancing, live combat tracking, SRD compendium, and invite-code party linking."
      suggestedQuestions={SUGGESTED_QUESTIONS}
      accent="#FF9F00"
      icon={Dices}
      expertLabel="D&D Expert"
      liveState={liveState}
      isOpen={isOpen}
      onClose={onClose}
    />
  );
}