/**
 * HomebrewForge — tabbed shell for creating custom monsters, spells, items,
 * and subclasses, plus a library/publish tab for bundling and publishing to
 * the marketplace.
 */
import { useState } from 'react';
import { Swords, Sparkles, Package, Shield, BookOpen } from 'lucide-react';
import CustomMonsterEditor from './CustomMonsterEditor';
import CustomSpellEditor from './CustomSpellEditor';
import CustomItemEditor from './CustomItemEditor';
import CustomSubclassEditor from './CustomSubclassEditor';
import HomebrewLibrary from './HomebrewLibrary';

const TABS = [
  { id: 'monsters', label: 'Monsters', icon: Swords },
  { id: 'spells', label: 'Spells', icon: Sparkles },
  { id: 'items', label: 'Items', icon: Package },
  { id: 'subclasses', label: 'Subclasses', icon: Shield },
  { id: 'library', label: 'Library', icon: BookOpen },
];

export default function HomebrewForge({ campaignId }) {
  const [tab, setTab] = useState('monsters');
  return (
    <div className="space-y-3">
      <div className="glass-panel clip-corner p-2.5">
        <p className="text-[10px] text-[#8b949e]"><span className="text-[#FF9F00] font-bold">Homebrew Forge</span> — Create custom monsters, spells, items, and subclasses. CR is computed deterministically from the defensive/offensive worksheet. Bundle content into a pack and publish to the marketplace.</p>
      </div>
      <div className="flex gap-1 overflow-x-auto pb-1">
        {TABS.map((t) => { const Icon = t.icon; const active = tab === t.id;
          return <button key={t.id} onClick={() => setTab(t.id)} className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold border clip-corner whitespace-nowrap touch-manipulation ${active ? 'border-[#FF9F00] bg-[#FF9F00]/15 text-[#FF9F00]' : 'border-[#30363d] bg-[#0d1117] text-[#8b949e]'}`}><Icon size={12} /> {t.label}</button>;
        })}
      </div>
      {tab === 'monsters' && <CustomMonsterEditor campaignId={campaignId} />}
      {tab === 'spells' && <CustomSpellEditor campaignId={campaignId} />}
      {tab === 'items' && <CustomItemEditor campaignId={campaignId} />}
      {tab === 'subclasses' && <CustomSubclassEditor campaignId={campaignId} />}
      {tab === 'library' && <HomebrewLibrary />}
    </div>
  );
}