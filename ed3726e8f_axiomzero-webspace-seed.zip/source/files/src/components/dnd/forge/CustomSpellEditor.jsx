import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Sparkles } from 'lucide-react';
import { validateSpell } from '@/lib/dnd/crEngine';

export default function CustomSpellEditor({ campaignId }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ name: '', level: 0, school: 'evocation', casting_time: '1 action', range: 'Self', duration: 'Instantaneous', components: 'V, S', concentration: false, ritual: false, description: '', classes: '' });
  const [errors, setErrors] = useState([]);
  const load = useCallback(async () => { const l = await base44.entities.DnDCustomSpell.list('-created_date', 100); setItems(l || []); }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const u = base44.entities.DnDCustomSpell.subscribe(() => load()); return u; }, [load]);
  const save = async () => {
    const errs = validateSpell({ name: form.name, level: Number(form.level), school: form.school });
    if (errs.length) { setErrors(errs); return; }
    setErrors([]);
    const slug = form.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    await base44.entities.DnDCustomSpell.create({
      name: form.name, slug, level: Number(form.level), school: form.school, casting_time: form.casting_time,
      range: form.range, duration: form.duration, components: form.components, concentration: form.concentration, ritual: form.ritual,
      description: form.description, classes_json: JSON.stringify(form.classes.split(',').map((s) => s.trim()).filter(Boolean)), campaign_id: campaignId || '',
    });
    setForm({ name: '', level: 0, school: 'evocation', casting_time: '1 action', range: 'Self', duration: 'Instantaneous', components: 'V, S', concentration: false, ritual: false, description: '', classes: '' }); load();
  };
  const del = async (id) => { await base44.entities.DnDCustomSpell.delete(id); load(); };
  const set = (k, v) => setForm({ ...form, [k]: v });
  return (
    <div className="space-y-3">
      <div className="glass-strong clip-corner p-3 space-y-2">
        <div className="flex items-center gap-1.5"><Sparkles size={13} className="text-[#4dd0e1]" /><span className="text-[10px] font-bold text-[#4dd0e1] uppercase tracking-wider">New Custom Spell</span></div>
        <input value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Spell name..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          <Field label="Level"><select value={form.level} onChange={(e) => set('level', Number(e.target.value))} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">{[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((l) => <option key={l} value={l}>{l === 0 ? 'Cantrip' : `Level ${l}`}</option>)}</select></Field>
          <Field label="School"><select value={form.school} onChange={(e) => set('school', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">{['abjuration', 'conjuration', 'divination', 'enchantment', 'evocation', 'illusion', 'necromancy', 'transmutation'].map((s) => <option key={s} value={s}>{s}</option>)}</select></Field>
          <Field label="Cast Time"><input value={form.casting_time} onChange={(e) => set('casting_time', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
          <Field label="Range"><input value={form.range} onChange={(e) => set('range', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
          <Field label="Duration"><input value={form.duration} onChange={(e) => set('duration', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
          <Field label="Components"><input value={form.components} onChange={(e) => set('components', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
        </div>
        <div className="flex gap-2">
          <label className="flex items-center gap-1.5 text-[10px] text-[#8b949e]"><input type="checkbox" checked={form.concentration} onChange={(e) => set('concentration', e.target.checked)} /> Concentration</label>
          <label className="flex items-center gap-1.5 text-[10px] text-[#8b949e]"><input type="checkbox" checked={form.ritual} onChange={(e) => set('ritual', e.target.checked)} /> Ritual</label>
        </div>
        <input value={form.classes} onChange={(e) => set('classes', e.target.value)} placeholder="Classes (comma-separated)..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <textarea value={form.description} onChange={(e) => set('description', e.target.value)} placeholder="Description..." rows={3} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        {errors.length > 0 && <div className="text-[10px] text-[#f85149]">{errors.join(' · ')}</div>}
        <button onClick={save} disabled={!form.name.trim()} className="flex items-center gap-1.5 px-3 py-2 bg-[#4dd0e1] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation"><Plus size={12} /> Save Spell</button>
      </div>
      <div className="space-y-1.5">
        {items.map((s) => (
          <div key={s.id} className="flex items-center justify-between p-2 border border-[#30363d] bg-[#0d1117] clip-corner">
            <div className="flex items-center gap-1.5"><Sparkles size={12} className="text-[#4dd0e1]" /><span className="text-xs font-bold text-[#e6edf3]">{s.name}</span><span className="text-[9px] text-[#4dd0e1]">{s.level === 0 ? 'Cantrip' : `L${s.level}`} {s.school}</span></div>
            <button onClick={() => del(s.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
          </div>
        ))}
        {items.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No custom spells yet</p>}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return <div><label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">{label}</label>{children}</div>;
}