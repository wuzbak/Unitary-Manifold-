import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Shield } from 'lucide-react';

export default function CustomSubclassEditor({ campaignId }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ name: '', parent_class: 'fighter', hit_die: 'd10', description: '', features: '' });
  const load = useCallback(async () => { const l = await base44.entities.DnDCustomSubclass.list('-created_date', 100); setItems(l || []); }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const u = base44.entities.DnDCustomSubclass.subscribe(() => load()); return u; }, [load]);
  const save = async () => {
    const slug = form.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    await base44.entities.DnDCustomSubclass.create({
      ...form, slug, features_json: JSON.stringify(form.features.split('\n').map((s) => s.trim()).filter(Boolean)), campaign_id: campaignId || '',
    });
    setForm({ name: '', parent_class: 'fighter', hit_die: 'd10', description: '', features: '' }); load();
  };
  const del = async (id) => { await base44.entities.DnDCustomSubclass.delete(id); load(); };
  const set = (k, v) => setForm({ ...form, [k]: v });
  return (
    <div className="space-y-3">
      <div className="glass-strong clip-corner p-3 space-y-2">
        <div className="flex items-center gap-1.5"><Shield size={13} className="text-[#bc8cff]" /><span className="text-[10px] font-bold text-[#bc8cff] uppercase tracking-wider">New Custom Subclass</span></div>
        <input value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Subclass name..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <div className="grid grid-cols-2 gap-2">
          <Field label="Parent Class"><input value={form.parent_class} onChange={(e) => set('parent_class', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
          <Field label="Hit Die"><select value={form.hit_die} onChange={(e) => set('hit_die', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">{['d6', 'd8', 'd10', 'd12'].map((d) => <option key={d} value={d}>{d}</option>)}</select></Field>
        </div>
        <textarea value={form.description} onChange={(e) => set('description', e.target.value)} placeholder="Description..." rows={2} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <textarea value={form.features} onChange={(e) => set('features', e.target.value)} placeholder="Features (one per line)..." rows={4} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <button onClick={save} disabled={!form.name.trim()} className="flex items-center gap-1.5 px-3 py-2 bg-[#bc8cff] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation"><Plus size={12} /> Save Subclass</button>
      </div>
      <div className="space-y-1.5">
        {items.map((s) => (
          <div key={s.id} className="flex items-center justify-between p-2 border border-[#30363d] bg-[#0d1117] clip-corner">
            <div className="flex items-center gap-1.5"><Shield size={12} className="text-[#bc8cff]" /><span className="text-xs font-bold text-[#e6edf3]">{s.name}</span><span className="text-[9px] text-[#484f58]">{s.parent_class} · {s.hit_die}</span></div>
            <button onClick={() => del(s.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
          </div>
        ))}
        {items.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No custom subclasses yet</p>}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return <div><label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">{label}</label>{children}</div>;
}