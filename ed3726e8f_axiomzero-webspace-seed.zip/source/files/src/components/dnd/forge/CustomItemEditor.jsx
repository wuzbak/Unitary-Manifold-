import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Package } from 'lucide-react';

export default function CustomItemEditor({ campaignId }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ name: '', type: 'wondrous', rarity: 'uncommon', attunement: false, value: 0, description: '' });
  const load = useCallback(async () => { const l = await base44.entities.DnDCustomItem.list('-created_date', 100); setItems(l || []); }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const u = base44.entities.DnDCustomItem.subscribe(() => load()); return u; }, [load]);
  const save = async () => {
    const slug = form.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    await base44.entities.DnDCustomItem.create({ ...form, value: Number(form.value), slug, campaign_id: campaignId || '' });
    setForm({ name: '', type: 'wondrous', rarity: 'uncommon', attunement: false, value: 0, description: '' }); load();
  };
  const del = async (id) => { await base44.entities.DnDCustomItem.delete(id); load(); };
  const set = (k, v) => setForm({ ...form, [k]: v });
  const RARITY_COLOR = { common: '#8b949e', uncommon: '#3fb950', rare: '#4dd0e1', 'very-rare': '#bc8cff', legendary: '#ff9f0a', artifact: '#f85149' };
  return (
    <div className="space-y-3">
      <div className="glass-strong clip-corner p-3 space-y-2">
        <div className="flex items-center gap-1.5"><Package size={13} className="text-[#3fb950]" /><span className="text-[10px] font-bold text-[#3fb950] uppercase tracking-wider">New Custom Item</span></div>
        <input value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Item name..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          <Field label="Type"><input value={form.type} onChange={(e) => set('type', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
          <Field label="Rarity"><select value={form.rarity} onChange={(e) => set('rarity', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">{['common', 'uncommon', 'rare', 'very-rare', 'legendary', 'artifact'].map((r) => <option key={r} value={r}>{r}</option>)}</select></Field>
          <Field label="Value (gp)"><input type="number" value={form.value} onChange={(e) => set('value', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
        </div>
        <label className="flex items-center gap-1.5 text-[10px] text-[#8b949e]"><input type="checkbox" checked={form.attunement} onChange={(e) => set('attunement', e.target.checked)} /> Requires Attunement</label>
        <textarea value={form.description} onChange={(e) => set('description', e.target.value)} placeholder="Description..." rows={3} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <button onClick={save} disabled={!form.name.trim()} className="flex items-center gap-1.5 px-3 py-2 bg-[#3fb950] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation"><Plus size={12} /> Save Item</button>
      </div>
      <div className="space-y-1.5">
        {items.map((i) => (
          <div key={i.id} className="flex items-center justify-between p-2 border border-[#30363d] bg-[#0d1117] clip-corner">
            <div className="flex items-center gap-1.5"><Package size={12} style={{ color: RARITY_COLOR[i.rarity] }} /><span className="text-xs font-bold text-[#e6edf3]">{i.name}</span><span className="text-[9px]" style={{ color: RARITY_COLOR[i.rarity] }}>{i.rarity}</span>{i.attunement && <span className="text-[8px] text-[#bc8cff]">attune</span>}</div>
            <button onClick={() => del(i.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
          </div>
        ))}
        {items.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No custom items yet</p>}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return <div><label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">{label}</label>{children}</div>;
}