/**
 * HomebrewLibrary — bundles custom content into a HomebrewPack and publishes
 * it to the marketplace via the dndMarketplace backend function.
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Package, Send, Trash2, Loader2, Check } from 'lucide-react';
import { loadCustomMonsters, loadCustomSpells, loadCustomItems, loadCustomSubclasses } from '@/lib/dnd/customCompendium';

export default function HomebrewLibrary() {
  const [monsters, setMonsters] = useState([]);
  const [spells, setSpells] = useState([]);
  const [items, setItems] = useState([]);
  const [subclasses, setSubclasses] = useState([]);
  const [packs, setPacks] = useState([]);
  const [selected, setSelected] = useState({ monsters: [], spells: [], items: [], subclasses: [] });
  const [packForm, setPackForm] = useState({ name: '', description: '', tags: '' });
  const [publishing, setPublishing] = useState(null);
  const [msg, setMsg] = useState('');

  const load = useCallback(async () => {
    const [m, s, i, sc, p] = await Promise.all([
      loadCustomMonsters(), loadCustomSpells(), loadCustomItems(), loadCustomSubclasses(),
      base44.entities.HomebrewPack.list('-created_date', 50).catch(() => []),
    ]);
    setMonsters(m); setSpells(s); setItems(i); setSubclasses(sc); setPacks(p || []);
  }, []);
  useEffect(() => { load(); }, [load]);

  const toggle = (group, id) => setSelected((prev) => ({ ...prev, [group]: prev[group].includes(id) ? prev[group].filter((x) => x !== id) : [...prev[group], id] }));

  const createPack = async () => {
    if (!packForm.name.trim()) return;
    const pack = await base44.entities.HomebrewPack.create({
      name: packForm.name, description: packForm.description, tags_json: JSON.stringify(packForm.tags.split(',').map((t) => t.trim()).filter(Boolean)),
      version: '1.0', contents_json: JSON.stringify(selected), cover_url: '',
    });
    setPackForm({ name: '', description: '', tags: '' }); setSelected({ monsters: [], spells: [], items: [], subclasses: [] }); load();
  };

  const publish = async (pack) => {
    setPublishing(pack.id); setMsg('');
    try {
      const res = await base44.functions.invoke('dndMarketplace', { action: 'publish', pack_id: pack.id });
      const d = res.data || res;
      if (d.error) setMsg(`Error: ${d.error}`); else setMsg(`Published "${d.pack?.name}" to the marketplace.`);
    } catch (e) { setMsg(`Error: ${e.message}`); }
    setPublishing(null);
  };

  const delPack = async (id) => { await base44.entities.HomebrewPack.delete(id); load(); };

  const Picker = ({ group, list, color, icon }) => (
    <div>
      <p className="text-[9px] text-[#8b949e] uppercase font-bold mb-1">{group} ({list.length})</p>
      <div className="space-y-1 max-h-32 overflow-y-auto">
        {list.length === 0 && <p className="text-[9px] text-[#484f58]">None</p>}
        {list.map((x) => (
          <label key={x.id} className="flex items-center gap-1.5 p-1.5 bg-[#0d1117] border border-[#30363d] clip-corner cursor-pointer">
            <input type="checkbox" checked={selected[group].includes(x.id)} onChange={() => toggle(group, x.id)} />
            <span style={{ color }}>{icon}</span>
            <span className="text-[10px] text-[#e6edf3] truncate">{x.name}</span>
          </label>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-3">
      <div className="glass-strong clip-corner p-3 space-y-3">
        <div className="flex items-center gap-1.5"><Package size={13} className="text-[#FF9F00]" /><span className="text-[10px] font-bold text-[#FF9F00] uppercase tracking-wider">Bundle a Pack</span></div>
        <div className="grid grid-cols-2 gap-3">
          <Picker group="monsters" list={monsters} color="#f85149" icon="⚔" />
          <Picker group="spells" list={spells} color="#4dd0e1" icon="✦" />
          <Picker group="items" list={items} color="#3fb950" icon="📦" />
          <Picker group="subclasses" list={subclasses} color="#bc8cff" icon="🛡" />
        </div>
        <input value={packForm.name} onChange={(e) => setPackForm({ ...packForm, name: e.target.value })} placeholder="Pack name..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <input value={packForm.description} onChange={(e) => setPackForm({ ...packForm, description: e.target.value })} placeholder="Description..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <input value={packForm.tags} onChange={(e) => setPackForm({ ...packForm, tags: e.target.value })} placeholder="Tags (comma-separated)..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <button onClick={createPack} disabled={!packForm.name.trim()} className="flex items-center gap-1.5 px-3 py-2 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation"><Package size={12} /> Create Pack</button>
      </div>

      {msg && <div className="glass-panel clip-corner p-2 text-[10px] text-[#3fb950]">{msg}</div>}

      <div className="space-y-1.5">
        <p className="text-[9px] text-[#8b949e] uppercase font-bold">Your Packs</p>
        {packs.map((p) => {
          const c = (() => { try { return JSON.parse(p.contents_json || '{}'); } catch { return {}; } })();
          const count = (c.monsters?.length || 0) + (c.spells?.length || 0) + (c.items?.length || 0) + (c.subclasses?.length || 0);
          return (
            <div key={p.id} className="flex items-center justify-between p-2.5 border border-[#30363d] bg-[#0d1117] clip-corner">
              <div>
                <span className="text-xs font-bold text-[#e6edf3]">{p.name}</span>
                <span className="text-[9px] text-[#484f58] ml-2">{count} items · v{p.version}</span>
              </div>
              <div className="flex gap-1">
                <button onClick={() => publish(p)} disabled={publishing === p.id} className="flex items-center gap-1 px-2 py-1 border border-[#4dd0e1]/40 bg-[#4dd0e1]/10 text-[#4dd0e1] text-[9px] font-bold clip-corner disabled:opacity-50 touch-manipulation">
                  {publishing === p.id ? <Loader2 size={10} className="animate-spin" /> : <Send size={10} />} Publish
                </button>
                <button onClick={() => delPack(p.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
              </div>
            </div>
          );
        })}
        {packs.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No packs yet</p>}
      </div>
    </div>
  );
}