import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Swords, Wand2 } from 'lucide-react';
import { suggestCR, validateMonster } from '@/lib/dnd/crEngine';

export default function CustomMonsterEditor({ campaignId }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ name: '', hp: 10, ac: 12, dpr: 5, attackBonus: 4, size: 'Medium', type: 'humanoid', environment: 'any', role: 'custom', abilities: '', description: '' });
  const [errors, setErrors] = useState([]);
  const load = useCallback(async () => { const l = await base44.entities.DnDCustomMonster.list('-created_date', 100); setItems(l || []); }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const u = base44.entities.DnDCustomMonster.subscribe(() => load()); return u; }, [load]);
  const suggested = suggestCR({ hp: Number(form.hp), ac: Number(form.ac), dpr: Number(form.dpr), attackBonus: Number(form.attackBonus) });
  const save = async () => {
    const errs = validateMonster({ name: form.name, cr: suggested.cr, hp: Number(form.hp), ac: Number(form.ac) });
    if (errs.length) { setErrors(errs); return; }
    setErrors([]);
    const slug = form.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    await base44.entities.DnDCustomMonster.create({
      name: form.name, slug, cr: suggested.cr, xp: suggested.xp, hp: Number(form.hp), ac: Number(form.ac),
      size: form.size, type: form.type, environment: form.environment, role: form.role,
      signature_abilities_json: JSON.stringify(form.abilities.split(',').map((s) => s.trim()).filter(Boolean)),
      description: form.description, campaign_id: campaignId || '',
    });
    setForm({ name: '', hp: 10, ac: 12, dpr: 5, attackBonus: 4, size: 'Medium', type: 'humanoid', environment: 'any', role: 'custom', abilities: '', description: '' }); load();
  };
  const del = async (id) => { await base44.entities.DnDCustomMonster.delete(id); load(); };
  const num = (k, v) => setForm({ ...form, [k]: v });
  return (
    <div className="space-y-3">
      <div className="glass-strong clip-corner p-3 space-y-2">
        <div className="flex items-center gap-1.5"><Wand2 size={13} className="text-[#FF9F00]" /><span className="text-[10px] font-bold text-[#FF9F00] uppercase tracking-wider">New Custom Monster</span></div>
        <input value={form.name} onChange={(e) => num('name', e.target.value)} placeholder="Monster name..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <Field label="HP"><input type="number" value={form.hp} onChange={(e) => num('hp', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
          <Field label="AC"><input type="number" value={form.ac} onChange={(e) => num('ac', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
          <Field label="DPR"><input type="number" value={form.dpr} onChange={(e) => num('dpr', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
          <Field label="Atk Bonus"><input type="number" value={form.attackBonus} onChange={(e) => num('attackBonus', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <Field label="Size"><select value={form.size} onChange={(e) => num('size', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">{['Tiny', 'Small', 'Medium', 'Large', 'Huge', 'Gargantuan'].map((s) => <option key={s} value={s}>{s}</option>)}</select></Field>
          <Field label="Type"><input value={form.type} onChange={(e) => num('type', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
          <Field label="Environment"><input value={form.environment} onChange={(e) => num('environment', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
          <Field label="Role"><input value={form.role} onChange={(e) => num('role', e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" /></Field>
        </div>
        <input value={form.abilities} onChange={(e) => num('abilities', e.target.value)} placeholder="Signature abilities (comma-separated)..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <textarea value={form.description} onChange={(e) => num('description', e.target.value)} placeholder="Description..." rows={2} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <div className="glass-panel clip-corner p-2 flex items-center justify-between">
          <span className="text-[9px] text-[#8b949e]">Suggested CR (deterministic):</span>
          <span className="text-sm font-bold text-[#FF9F00] font-mono">CR {suggested.cr} · {suggested.xp} XP</span>
        </div>
        {errors.length > 0 && <div className="text-[10px] text-[#f85149]">{errors.join(' · ')}</div>}
        <button onClick={save} disabled={!form.name.trim()} className="flex items-center gap-1.5 px-3 py-2 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation"><Plus size={12} /> Save Monster</button>
      </div>
      <div className="space-y-1.5">
        {items.map((m) => (
          <div key={m.id} className="flex items-center justify-between p-2 border border-[#30363d] bg-[#0d1117] clip-corner">
            <div className="flex items-center gap-1.5"><Swords size={12} className="text-[#f85149]" /><span className="text-xs font-bold text-[#e6edf3]">{m.name}</span><span className="text-[9px] text-[#FF9F00]">CR {m.cr}</span><span className="text-[9px] text-[#484f58]">{m.hp} HP · AC {m.ac}</span></div>
            <button onClick={() => del(m.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
          </div>
        ))}
        {items.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No custom monsters yet</p>}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return <div><label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">{label}</label>{children}</div>;
}