import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { buildCharacter, abilityModifiers, ABILITY_SCORES, SKILLS, ALIGNMENTS, classDisplayName, speciesDisplayName, backgroundDisplayName, rollCharacterInitiative } from '@/lib/dnd/characterEngine';
import { CLASSES, SPECIES, BACKGROUNDS } from '@/lib/dnd/compendium';
import { X, Dices, Save, Sparkles } from 'lucide-react';
import ConditionBadges from '@/components/dnd/ConditionBadges';
import CharacterPortraitGenerator from '@/components/dnd/CharacterPortraitGenerator';
import ImportExportBar from '@/components/filmers/ImportExportBar';
import { characterToExport, exportToCharacterPayload, downloadJSON, downloadCSV, readFileAsText } from '@/lib/dnd/dndExport';

export default function CharacterBuilder({ character, onSave, onCancel, solo = false, campaignId = '', playerId = '' }) {
  const [form, setForm] = useState(() => {
    if (character) {
      const scores = typeof character.ability_scores_json === 'string'
        ? JSON.parse(character.ability_scores_json)
        : character.ability_scores_json || {};
      return {
        name: character.name || '',
        species: character.species || 'human',
        klass: character.klass || 'fighter',
        background: character.background || 'wanderer',
        level: character.level || 1,
        alignment: character.alignment || 'unaligned',
        ability_scores: scores,
        xp: character.xp || 0,
        gold: character.gold || 0,
        armor_class: character.armor_class || 0,
        hp_max: character.hp_max || 0,
        notes: typeof character.notes_json === 'string' ? JSON.parse(character.notes_json) : (character.notes_json || []),
      };
    }
    return {
      name: '', species: 'human', klass: 'fighter', background: 'wanderer',
      level: 1, alignment: 'unaligned',
      ability_scores: { strength: 15, dexterity: 14, constitution: 13, intelligence: 12, wisdom: 10, charisma: 8 },
      xp: 0, gold: 10, armor_class: 0, hp_max: 0, notes: [],
    };
  });
  const [saving, setSaving] = useState(false);

  const preview = buildCharacter({ ...form, solo, campaign_id: campaignId, player_id: playerId });
  const mods = abilityModifiers(form.ability_scores);

  const update = (field, value) => setForm((p) => ({ ...p, [field]: value }));
  const updateScore = (ab, value) => setForm((p) => ({ ...p, ability_scores: { ...p.ability_scores, [ab]: Number(value) } }));

  const handleSave = async () => {
    setSaving(true);
    try {
      const built = buildCharacter({ ...form, solo, campaign_id: campaignId, player_id: playerId });
      const payload = {
        ...built,
        ability_scores_json: JSON.stringify(built.ability_scores),
        abilities_json: JSON.stringify(built.abilities),
        conditions_json: JSON.stringify(built.conditions),
        spell_slots_json: JSON.stringify(built.spell_slots),
        spellbook_json: JSON.stringify(built.spellbook),
        inventory_json: JSON.stringify(built.inventory),
        notes_json: JSON.stringify(built.notes),
        campaign_id: campaignId,
        player_id: playerId,
        solo,
      };
      delete payload.ability_scores;
      delete payload.abilities;
      delete payload.conditions;
      delete payload.spell_slots;
      delete payload.spellbook;
      delete payload.inventory;
      delete payload.notes;

      if (character?.id) {
        await base44.entities.DnDCharacter.update(character.id, payload);
      } else {
        await base44.entities.DnDCharacter.create(payload);
      }
      onSave?.();
    } catch (e) {
      console.error('Save character failed:', e);
      alert(`Failed to save character: ${e.message}`);
    }
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-3 overflow-y-auto">
      <div className="glass-strong clip-corner w-full max-w-3xl my-8">
        <div className="flex items-center justify-between p-3 border-b border-[#30363d] sticky top-0 bg-[#12161A] z-10">
          <h2 className="text-sm font-bold text-[#FF9F00] font-heading">
            {character ? 'Edit Character' : 'New Character'}
          </h2>
          <button onClick={onCancel} className="text-[#484f58] hover:text-[#e6edf3] p-1"><X size={18} /></button>
        </div>

        <div className="p-4 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Basic info */}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Character Name">
              <input value={form.name} onChange={(e) => update('name', e.target.value)}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner focus:border-[#FF9F00]/50" />
            </Field>
            <Field label="Level">
              <input type="number" min={1} max={20} value={form.level}
                onChange={(e) => update('level', Math.max(1, Math.min(20, Number(e.target.value))))}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
            </Field>
            <Field label="Species">
              <select value={form.species} onChange={(e) => update('species', e.target.value)}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
                {SPECIES.map((s) => <option key={s.slug} value={s.slug}>{s.name}</option>)}
              </select>
            </Field>
            <Field label="Class">
              <select value={form.klass} onChange={(e) => update('klass', e.target.value)}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
                {CLASSES.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
              </select>
            </Field>
            <Field label="Background">
              <select value={form.background} onChange={(e) => update('background', e.target.value)}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
                {BACKGROUNDS.map((b) => <option key={b.slug} value={b.slug}>{b.name}</option>)}
              </select>
            </Field>
            <Field label="Alignment">
              <select value={form.alignment} onChange={(e) => update('alignment', e.target.value)}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
                {ALIGNMENTS.map((a) => <option key={a} value={a}>{a}</option>)}
              </select>
            </Field>
          </div>

          {/* Ability scores */}
          <div>
            <p className="text-[10px] text-[#FF9F00] font-bold uppercase mb-1.5">Ability Scores</p>
            <div className="grid grid-cols-6 gap-2">
              {ABILITY_SCORES.map((ab) => (
                <div key={ab} className="bg-[#0d1117] border border-[#30363d] p-2 clip-corner text-center">
                  <div className="text-[8px] text-[#8b949e] uppercase font-bold mb-1">{ab.slice(0, 3)}</div>
                  <input type="number" min={1} max={30} value={form.ability_scores[ab] || 10}
                    onChange={(e) => updateScore(ab, e.target.value)}
                    className="w-full bg-transparent text-center text-sm font-bold text-[#e6edf3] border-b border-[#30363d] focus:border-[#FF9F00]/50 focus:outline-none" />
                  <div className="text-[9px] text-[#FF9F00] mt-0.5">{mods[ab] >= 0 ? '+' : ''}{mods[ab]}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Resources */}
          <div className="grid grid-cols-3 gap-3">
            <Field label="XP">
              <input type="number" value={form.xp} onChange={(e) => update('xp', Number(e.target.value))}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
            </Field>
            <Field label="Gold">
              <input type="number" value={form.gold} onChange={(e) => update('gold', Number(e.target.value))}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
            </Field>
            <Field label="AC Override (0 = auto)">
              <input type="number" value={form.armor_class} onChange={(e) => update('armor_class', Number(e.target.value))}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
            </Field>
          </div>

          {/* Auto-computed preview */}
          <div className="glass-panel clip-corner p-3 border-l-2 border-[#FF9F00]/40">
            <p className="text-[10px] text-[#FF9F00] font-bold uppercase mb-2">Auto-Computed Stats (Deterministic Engine)</p>
            <div className="grid grid-cols-4 gap-2 text-center text-[10px]">
              <PreviewStat label="Prof Bonus" value={`+${preview.proficiency_bonus}`} />
              <PreviewStat label="HP Max" value={preview.hp_max} />
              <PreviewStat label="AC" value={preview.armor_class} />
              <PreviewStat label="Pass Perc" value={preview.passive_perception} />
              {preview.spellcasting_ability && (
                <>
                  <PreviewStat label="Save DC" value={preview.spell_save_dc} />
                  <PreviewStat label="Spell Atk" value={`+${preview.spell_attack_bonus}`} />
                  <PreviewStat label="Cast Abil" value={preview.spellcasting_ability.slice(0, 3).toUpperCase()} />
                  <PreviewStat label="Initiative" value={`+${preview.initiative}`} />
                </>
              )}
              {!preview.spellcasting_ability && (
                <>
                  <PreviewStat label="Initiative" value={`+${preview.initiative}`} />
                </>
              )}
            </div>
            {preview.spell_slots.length > 0 && (
              <div className="mt-2 text-[10px] text-[#8b949e]">
                Spell Slots: {preview.spell_slots.map((s, i) => `${i + 1}:${s}`).join(' · ')}
              </div>
            )}
          </div>

          {/* AI Portrait Generator */}
          {character?.id && (
            <CharacterPortraitGenerator character={character} onSave={() => {}} accent="#FF9F00" />
          )}

          {/* Import / Export */}
          <div className="glass-panel clip-corner p-3">
            <p className="text-[10px] text-[#FF9F00] font-bold uppercase mb-2 flex items-center gap-1.5"><Sparkles size={10} /> Import / Export Character</p>
            <ImportExportBar
              accent="#FF9F00"
              onExportJSON={() => {
                const built = buildCharacter({ ...form, solo, campaign_id: campaignId, player_id: playerId });
                downloadJSON(`${form.name || 'character'}.json`, characterToExport(built));
              }}
              onExportCSV={() => {
                const built = buildCharacter({ ...form, solo, campaign_id: campaignId, player_id: playerId });
                downloadCSV(`${form.name || 'character'}.csv`, [characterToExport(built)]);
              }}
              onImportJSON={async (file) => {
                try {
                  const text = await readFileAsText(file);
                  const data = JSON.parse(text);
                  const payload = exportToCharacterPayload(data);
                  setForm({
                    name: payload.name, species: payload.species, klass: payload.klass,
                    background: payload.background, level: payload.level, alignment: payload.alignment,
                    ability_scores: JSON.parse(payload.ability_scores_json), xp: payload.xp, gold: payload.gold,
                    armor_class: payload.armor_class, hp_max: payload.hp_max, notes: JSON.parse(payload.notes_json),
                  });
                } catch (e) { alert(`Import failed: ${e.message}`); }
              }}
              exportLabel="Export"
            />
          </div>
        </div>

        <div className="flex gap-2 p-3 border-t border-[#30363d] sticky bottom-0 bg-[#12161A]">
          <button onClick={handleSave} disabled={saving || !form.name.trim()}
            className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 bg-[#FF9F00] text-black text-xs font-bold clip-corner disabled:opacity-50 touch-manipulation">
            <Save size={14} /> {saving ? 'Saving...' : 'Save Character'}
          </button>
          <button onClick={onCancel}
            className="px-3 py-2.5 border border-[#30363d] text-[#8b949e] text-xs clip-corner touch-manipulation">Cancel</button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">{label}</label>
      {children}
    </div>
  );
}

function PreviewStat({ label, value }) {
  return (
    <div className="bg-[#0d1117] border border-[#30363d] p-1.5 clip-corner">
      <div className="text-[#8b949e] text-[8px] uppercase">{label}</div>
      <div className="text-[#e6edf3] font-bold">{value}</div>
    </div>
  );
}