import { useState } from 'react';
import { Edit, Heart, Shield, Eye, Sparkles, Coins, Star, Zap } from 'lucide-react';
import { abilityModifiers, ABILITY_SCORES, classDisplayName, speciesDisplayName, backgroundDisplayName } from '@/lib/dnd/characterEngine';
import { getCondition } from '@/lib/dnd/compendium';
import ConditionBadges from '@/components/dnd/ConditionBadges';

export default function CharacterSheet({ character, onEdit }) {
  if (!character) return null;
  const scores = typeof character.ability_scores_json === 'string'
    ? JSON.parse(character.ability_scores_json)
    : character.ability_scores_json || {};
  const mods = abilityModifiers(scores);
  const conditions = typeof character.conditions_json === 'string'
    ? JSON.parse(character.conditions_json)
    : character.conditions_json || [];
  const spellSlots = typeof character.spell_slots_json === 'string'
    ? JSON.parse(character.spell_slots_json)
    : character.spell_slots_json || [];
  const inventory = typeof character.inventory_json === 'string'
    ? JSON.parse(character.inventory_json)
    : character.inventory_json || [];
  const notes = typeof character.notes_json === 'string'
    ? JSON.parse(character.notes_json)
    : character.notes_json || [];
  const abilities = typeof character.abilities_json === 'string'
    ? JSON.parse(character.abilities_json)
    : character.abilities_json || [];

  const hpPct = character.hp_max > 0 ? (character.hp_current / character.hp_max) * 100 : 0;
  const hpColor = hpPct > 50 ? '#3fb950' : hpPct > 25 ? '#d29922' : '#f85149';

  return (
    <div className="glass-strong clip-corner p-4 border-l-2 border-[#FF9F00]/40">
      {/* Header */}
      <div className="flex items-start justify-between gap-2 mb-3">
        <div>
          <h3 className="text-lg font-bold text-[#e6edf3] font-heading">{character.name}</h3>
          <p className="text-[10px] text-[#8b949e]">
            {speciesDisplayName(character.species)} {classDisplayName(character.klass)} · Level {character.level}
          </p>
          <p className="text-[9px] text-[#484f58]">
            {backgroundDisplayName(character.background)} · {character.alignment}
          </p>
        </div>
        {onEdit && (
          <button onClick={() => onEdit(character)} className="p-2 border border-[#30363d] text-[#8b949e] hover:text-[#FF9F00] hover:border-[#FF9F00]/40 clip-corner touch-manipulation">
            <Edit size={14} />
          </button>
        )}
      </div>

      {/* Conditions */}
      {conditions.length > 0 && (
        <div className="mb-3">
          <p className="text-[9px] text-[#8b949e] uppercase font-bold mb-1">Conditions</p>
          <ConditionBadges conditions={conditions} />
        </div>
      )}

      {/* HP bar */}
      <div className="mb-3">
        <div className="flex items-center justify-between text-[10px] mb-1">
          <span className="flex items-center gap-1 text-[#8b949e]"><Heart size={10} /> Hit Points</span>
          <span className="text-[#e6edf3] font-bold">{character.hp_current} / {character.hp_max}{character.temp_hp > 0 ? ` (+${character.temp_hp} temp)` : ''}</span>
        </div>
        <div className="h-2 bg-[#0d1117] border border-[#30363d] clip-corner overflow-hidden">
          <div className="h-full transition-all" style={{ width: `${Math.max(0, Math.min(100, hpPct))}%`, background: hpColor }} />
        </div>
      </div>

      {/* Core stats grid */}
      <div className="grid grid-cols-4 gap-2 mb-3">
        <CoreStat icon={Shield} label="AC" value={character.armor_class} />
        <CoreStat icon={Eye} label="Pass Perc" value={character.passive_perception} />
        <CoreStat icon={Sparkles} label="Prof" value={`+${character.proficiency_bonus}`} />
        <CoreStat icon={Zap} label="Init" value={`+${mods.dexterity || 0}`} />
      </div>

      {/* Ability scores */}
      <div className="grid grid-cols-6 gap-1.5 mb-3">
        {ABILITY_SCORES.map((ab) => (
          <div key={ab} className="bg-[#0d1117] border border-[#30363d] p-1.5 clip-corner text-center">
            <div className="text-[7px] text-[#8b949e] uppercase font-bold">{ab.slice(0, 3)}</div>
            <div className="text-sm font-bold text-[#e6edf3]">{scores[ab] || 10}</div>
            <div className="text-[8px] text-[#FF9F00]">{mods[ab] >= 0 ? '+' : ''}{mods[ab]}</div>
          </div>
        ))}
      </div>

      {/* Spellcasting */}
      {character.spellcasting_ability && (
        <div className="mb-3 glass-panel clip-corner p-2">
          <p className="text-[9px] text-[#FF9F00] font-bold uppercase mb-1">Spellcasting ({character.spellcasting_ability})</p>
          <div className="flex gap-3 text-[10px]">
            <span className="text-[#8b949e]">Save DC: <span className="text-[#e6edf3] font-bold">{character.spell_save_dc}</span></span>
            <span className="text-[#8b949e]">Attack: <span className="text-[#e6edf3] font-bold">+{character.spell_attack_bonus}</span></span>
          </div>
          {spellSlots.length > 0 && (
            <div className="flex gap-1 mt-1.5">
              {spellSlots.map((slots, i) => (
                <div key={i} className="flex flex-col items-center">
                  <span className="text-[7px] text-[#484f58]">L{i + 1}</span>
                  <span className="text-[10px] text-[#e6edf3] font-bold">{slots}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Resources */}
      <div className="grid grid-cols-2 gap-2 mb-3">
        <div className="flex items-center gap-2 bg-[#0d1117] border border-[#30363d] p-2 clip-corner">
          <Coins size={12} className="text-[#d29922]" />
          <span className="text-[10px] text-[#8b949e]">Gold: <span className="text-[#e6edf3] font-bold">{character.gold}</span></span>
        </div>
        <div className="flex items-center gap-2 bg-[#0d1117] border border-[#30363d] p-2 clip-corner">
          <Star size={12} className="text-[#a371f7]" />
          <span className="text-[10px] text-[#8b949e]">XP: <span className="text-[#e6edf3] font-bold">{character.xp}</span></span>
        </div>
      </div>

      {/* Abilities */}
      {abilities.length > 0 && (
        <div className="mb-3">
          <p className="text-[9px] text-[#8b949e] uppercase font-bold mb-1">Abilities & Traits</p>
          <div className="flex flex-wrap gap-1">
            {abilities.map((a, i) => (
              <span key={i} className="text-[9px] px-1.5 py-0.5 bg-[#0d1117] border border-[#30363d] text-[#c9d1d9] clip-corner">{a}</span>
            ))}
          </div>
        </div>
      )}

      {/* Inventory */}
      {inventory.length > 0 && (
        <div className="mb-3">
          <p className="text-[9px] text-[#8b949e] uppercase font-bold mb-1">Inventory</p>
          <div className="space-y-0.5">
            {inventory.map((item, i) => (
              <div key={i} className="text-[10px] text-[#c9d1d9] flex justify-between">
                <span>{item.name || item}</span>
                {item.quantity > 1 && <span className="text-[#8b949e]">×{item.quantity}</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Notes */}
      {notes.length > 0 && (
        <div>
          <p className="text-[9px] text-[#8b949e] uppercase font-bold mb-1">Notes</p>
          <div className="space-y-0.5">
            {notes.map((n, i) => (
              <p key={i} className="text-[10px] text-[#8b949e] italic">• {n}</p>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function CoreStat({ icon: Icon, label, value }) {
  return (
    <div className="bg-[#0d1117] border border-[#30363d] p-2 clip-corner text-center">
      <Icon size={12} className="mx-auto text-[#FF9F00] mb-0.5" />
      <div className="text-[8px] text-[#8b949e] uppercase">{label}</div>
      <div className="text-sm font-bold text-[#e6edf3]">{value}</div>
    </div>
  );
}