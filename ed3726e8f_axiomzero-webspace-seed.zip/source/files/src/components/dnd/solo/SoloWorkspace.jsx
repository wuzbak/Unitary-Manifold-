import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { User, Swords, Search, Plus, ScrollText, Dices, Store, Globe, Hammer } from 'lucide-react';
import CharacterSheet from '@/components/dnd/CharacterSheet';
import CharacterBuilder from '@/components/dnd/CharacterBuilder';
import CompendiumBrowser from '@/components/dnd/CompendiumBrowser';
import EncounterBalancer from '@/components/dnd/EncounterBalancer';
import CosmicDiceChamber from '@/components/dnd/dice/CosmicDiceChamber';
import CosmicDiceModal from '@/components/dnd/dice/CosmicDiceModal';
import Marketplace from '@/components/dnd/shop/Marketplace';
import HomebrewForge from '@/components/dnd/forge/HomebrewForge';
import { loadCustomMonsters, mergeMonsters } from '@/lib/dnd/customCompendium';
import { computeEncounter, DIFFICULTY_STYLES } from '@/lib/dnd/encounterEngine';
import { searchMonsters, getMonster } from '@/lib/dnd/compendium';
import { rollAllInitiative, damageCombatant, healCombatant } from '@/lib/dnd/combatEngine';

export default function SoloWorkspace({ onLiveState }) {
  const [tab, setTab] = useState('characters');
  const [characters, setCharacters] = useState([]);
  const [showBuilder, setShowBuilder] = useState(false);
  const [editingChar, setEditingChar] = useState(null);
  const [encounterMonsters, setEncounterMonsters] = useState([]);
  const [combatants, setCombatants] = useState([]);
  const [round, setRound] = useState(1);
  const [activeIdx, setActiveIdx] = useState(0);
  const [search, setSearch] = useState('');
  const [customMonsters, setCustomMonsters] = useState([]);
  const [diceModalOpen, setDiceModalOpen] = useState(false);

  const loadChars = useCallback(async () => {
    try {
      const list = await base44.entities.DnDCharacter.filter({ solo: true }, '-created_date', 20);
      setCharacters(list || []);
    } catch (e) { console.error('Load solo chars:', e); }
  }, []);

  useEffect(() => { loadChars(); }, [loadChars]);
  useEffect(() => {
    const unsub = base44.entities.DnDCharacter.subscribe(() => loadChars());
    return unsub;
  }, [loadChars]);
  useEffect(() => { loadCustomMonsters().then(setCustomMonsters); }, []);

  useEffect(() => {
    onLiveState?.((prev) => ({ ...prev, soloCharacters: characters.length, partyLevels: characters.map((c) => c.level) }));
  }, [characters, onLiveState]);

  const partyLevels = characters.map((c) => c.level).length > 0 ? characters.map((c) => c.level) : [1];
  const encStats = computeEncounter(encounterMonsters, partyLevels);

  const TABS = [
    { id: 'characters', label: 'Characters', icon: User },
    { id: 'encounter', label: 'Encounter', icon: Swords },
    { id: 'combat', label: 'Combat', icon: Swords },
    { id: 'dice', label: 'Dice', icon: Dices },
    { id: 'marketplace', label: 'Marketplace', icon: Store },
    { id: 'forge', label: 'Forge', icon: Hammer },
    { id: 'compendium', label: 'Compendium', icon: Search },
  ];

  return (
    <div className="space-y-3">
      <div className="glass-panel clip-corner p-3">
        <p className="text-[10px] text-[#8b949e]">
          <span className="text-[#FF9F00] font-bold">Solo Mode</span> — Manage characters, build encounters, and run combat locally for theorycrafting or solo play. No DM required. Characters can later be imported into a campaign via invite code.
        </p>
      </div>

      <div className="flex gap-1 overflow-x-auto pb-1">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold border clip-corner whitespace-nowrap touch-manipulation ${
                active ? 'border-[#FF9F00] bg-[#FF9F00]/15 text-[#FF9F00]' : 'border-[#30363d] bg-[#0d1117] text-[#8b949e]'
              }`}>
              <Icon size={12} /> {t.label}
            </button>
          );
        })}
      </div>

      {tab === 'characters' && (
        <div className="space-y-3">
          <button onClick={() => { setEditingChar(null); setShowBuilder(true); }}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> New Solo Character</button>
          <div className="grid sm:grid-cols-2 gap-3">
            {characters.map((c) => (
              <CharacterSheet key={c.id} character={c} onEdit={(ch) => { setEditingChar(ch); setShowBuilder(true); }} />
            ))}
          </div>
          {characters.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-8">No solo characters yet. Create one to start.</p>}
        </div>
      )}

      {tab === 'encounter' && (
        <div className="space-y-3">
          {/* Encounter Balancer with auto-procure */}
          <EncounterBalancer
            partyLevels={partyLevels}
            onInsertEncounter={(slugs) => setEncounterMonsters(slugs)}
            accent="#FF9F00"
          />
          <div className="glass-strong clip-corner p-3" style={{ borderLeft: `3px solid ${encStats.difficultyStyle.color}` }}>
            <div className="flex justify-between">
              <span className="text-sm font-bold" style={{ color: encStats.difficultyStyle.color }}>{encStats.difficultyStyle.label}</span>
              <span className="text-[10px] text-[#8b949e]">{encStats.adjustedXp} XP · {encStats.monsterCount} monsters</span>
            </div>
            <div className="grid grid-cols-4 gap-1 mt-1.5 text-[9px] text-center">
              {['easy', 'medium', 'hard', 'deadly'].map((d) => (
                <div key={d} className="text-[#8b949e]">{DIFFICULTY_STYLES[d].label}: {encStats.thresholds[d]}</div>
              ))}
            </div>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {encounterMonsters.map((slug, i) => {
              const m = getMonster(slug);
              return (
                <div key={i} className="flex items-center gap-1 px-2 py-1 bg-[#0d1117] border border-[#30363d] clip-corner text-[10px]">
                  <span className="text-[#e6edf3]">{m?.name || slug}</span>
                  <button onClick={() => setEncounterMonsters(encounterMonsters.filter((_, idx) => idx !== i))} className="text-[#484f58] hover:text-[#f85149]">✕</button>
                </div>
              );
            })}
          </div>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search monsters..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-[40vh] overflow-y-auto">
            {mergeMonsters(customMonsters).filter((m) => !search.trim() || m.name.toLowerCase().includes(search.toLowerCase())).slice(0, 60).map((m) => (
              <button key={m.slug} onClick={() => setEncounterMonsters((prev) => [...prev, m.slug])}
                className="p-2 border border-[#30363d] bg-[#0d1117] clip-corner hover:border-[#FF9F00]/40 text-left touch-manipulation">
                <span className="text-[10px] font-bold text-[#e6edf3]">{m.name}</span>
                <span className="text-[9px] text-[#FF9F00] block">CR {m.cr} · {m.xp}xp</span>
              </button>
            ))}
          </div>
          {encounterMonsters.length > 0 && (
            <button onClick={() => {
              const monsterCombatants = encounterMonsters.map((slug, i) => {
                const m = getMonster(slug);
                return { id: `solo-m-${i}`, name: m.name, initiative: 0, hp_current: m.hp, hp_max: m.hp, ac: m.ac, conditions_json: '[]', type: 'monster', ref_id: slug, sort_order: i, active_turn: false };
              });
              const charCombatants = characters.map((c, i) => ({
                id: `solo-c-${i}`, name: c.name, initiative: 0, hp_current: c.hp_current, hp_max: c.hp_max, ac: c.armor_class, conditions_json: c.conditions_json || '[]', type: 'character', ref_id: c.id, sort_order: 0, active_turn: false,
              }));
              const rolled = rollAllInitiative([...monsterCombatants, ...charCombatants]);
              setCombatants(rolled); setRound(1); setActiveIdx(0); setTab('combat');
            }}
              className="flex items-center gap-1.5 px-3 py-2 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner touch-manipulation"><Swords size={12} /> Start Combat</button>
          )}
        </div>
      )}

      {tab === 'combat' && (
        <div className="space-y-2">
          {combatants.length === 0 ? (
            <p className="text-[10px] text-[#484f58] text-center py-8">No active combat. Build an encounter and start combat.</p>
          ) : (
            <>
              <div className="flex justify-between items-center glass-strong clip-corner p-2">
                <span className="text-sm font-bold text-[#FF9F00]">Round {round}</span>
                <button onClick={() => { setActiveIdx((prev) => { const n = prev + 1; if (n >= combatants.length) { setRound((r) => r + 1); return 0; } return n; }); }}
                  className="px-3 py-1.5 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner touch-manipulation">Next Turn</button>
              </div>
              {combatants.map((c, i) => {
                const isActive = i === activeIdx;
                const hpPct = c.hp_max > 0 ? (c.hp_current / c.hp_max) * 100 : 0;
                const hpColor = hpPct > 50 ? '#3fb950' : hpPct > 25 ? '#d29922' : '#f85149';
                return (
                  <div key={c.id} className={`p-2.5 border clip-corner ${isActive ? 'border-[#FF9F00] bg-[#FF9F00]/10' : 'border-[#30363d] bg-[#0d1117]'} ${c.hp_current <= 0 ? 'opacity-40' : ''}`}>
                    <div className="flex justify-between">
                      <span className="text-xs font-bold text-[#e6edf3]">{c.name}</span>
                      <span className="text-[10px] text-[#FF9F00]">Init {c.initiative}</span>
                    </div>
                    <div className="text-[10px] text-[#8b949e]">❤️ {c.hp_current}/{c.hp_max} · 🛡️ {c.ac}</div>
                    <div className="h-1 bg-[#0d1117] mt-1 clip-corner overflow-hidden">
                      <div className="h-full" style={{ width: `${Math.max(0, hpPct)}%`, background: hpColor }} />
                    </div>
                  </div>
                );
              })}
            </>
          )}
        </div>
      )}

      {tab === 'dice' && (
        <div className="space-y-3">
          <CosmicDiceChamber onOpenModal={() => setDiceModalOpen(true)} mode="player" accent="#FF9F00" />
          <div className="glass-panel clip-corner p-3">
            <p className="text-[10px] text-[#8b949e]">
              <span className="text-[#FF9F00] font-bold">Solo Cosmic Dice</span> — Roll through the toroidal universe for theorycrafting and solo play.
            </p>
          </div>
        </div>
      )}
      {tab === 'marketplace' && (
        <Marketplace mode="solo" character={characters[0]} />
      )}
      {tab === 'forge' && <HomebrewForge campaignId="" />}
      {tab === 'compendium' && <CompendiumBrowser />}

      <CosmicDiceModal isOpen={diceModalOpen} onClose={() => setDiceModalOpen(false)} mode="player" accent="#FF9F00" />

      {showBuilder && (
        <CharacterBuilder character={editingChar} solo={true}
          onCancel={() => setShowBuilder(false)} onSave={() => { setShowBuilder(false); loadChars(); }} />
      )}
    </div>
  );
}