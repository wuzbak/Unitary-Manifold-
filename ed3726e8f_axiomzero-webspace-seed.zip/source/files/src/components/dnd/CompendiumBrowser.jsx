import { useState, useEffect, useMemo, useCallback } from 'react';
import { Search, Swords, Sparkles, Package, Users, BookOpen, User, AlertTriangle } from 'lucide-react';
import { MONSTERS, SPELLS, ITEMS, CLASSES, BACKGROUNDS, SPECIES, CONDITIONS, MONSTER_ENVIRONMENTS, MONSTER_ROLES, SPELL_SCHOOLS, SPELL_LEVELS, ITEM_TYPES, ITEM_RARITIES } from '@/lib/dnd/compendium';
import { loadCustomMonsters, loadCustomSpells, loadCustomItems, customMonsterToCompendium, customSpellToCompendium, customItemToCompendium } from '@/lib/dnd/customCompendium';
import { getMonsterIcon, getItemIcon, getSpellIcon } from '@/lib/dnd/entityIcons';
import StatBlock from '@/components/dnd/StatBlock';
import CompendiumCompileButton from '@/components/dnd/CompendiumCompileButton';

const TABS = [
  { id: 'monsters', label: 'Monsters', icon: Swords, compileCategory: 'monsters' },
  { id: 'spells', label: 'Spells', icon: Sparkles, compileCategory: 'spells' },
  { id: 'items', label: 'Items', icon: Package, compileCategory: 'items' },
  { id: 'classes', label: 'Classes', icon: Users },
  { id: 'backgrounds', label: 'Backgrounds', icon: BookOpen },
  { id: 'species', label: 'Species', icon: User },
  { id: 'conditions', label: 'Conditions', icon: AlertTriangle },
];

export default function CompendiumBrowser({ onSelectMonster, initialTab = 'monsters' }) {
  const [tab, setTab] = useState(initialTab);
  const [query, setQuery] = useState('');
  const [filters, setFilters] = useState({});
  const [selected, setSelected] = useState(null);
  const [customMonsters, setCustomMonsters] = useState([]);
  const [customSpells, setCustomSpells] = useState([]);
  const [customItems, setCustomItems] = useState([]);

  const loadCustom = useCallback(async () => {
    const [m, s, i] = await Promise.all([loadCustomMonsters(), loadCustomSpells(), loadCustomItems()]);
    setCustomMonsters(m || []);
    setCustomSpells(s || []);
    setCustomItems(i || []);
  }, []);

  useEffect(() => { loadCustom(); }, [loadCustom]);

  // Merged lists (static + custom)
  const mergedMonsters = useMemo(() => [...MONSTERS, ...customMonsters.map(customMonsterToCompendium)], [customMonsters]);
  const mergedSpells = useMemo(() => [...SPELLS, ...customSpells.map(customSpellToCompendium)], [customSpells]);
  const mergedItems = useMemo(() => [...ITEMS, ...customItems.map(customItemToCompendium)], [customItems]);

  return (
    <div className="space-y-3">
      {/* Tabs + Compile button */}
      <div className="flex gap-1 overflow-x-auto pb-1 items-center">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button key={t.id} onClick={() => { setTab(t.id); setSelected(null); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold border clip-corner whitespace-nowrap transition-all touch-manipulation ${
                active ? 'border-[#FF9F00] bg-[#FF9F00]/15 text-[#FF9F00]' : 'border-[#30363d] bg-[#0d1117] text-[#8b949e] hover:border-[#FF9F00]/30'
              }`}>
              <Icon size={12} /> {t.label}
            </button>
          );
        })}
        {TABS.find((t) => t.id === tab)?.compileCategory && (
          <CompendiumCompileButton
            category={TABS.find((t) => t.id === tab).compileCategory}
            existingSlugs={tab === 'monsters' ? mergedMonsters.map((m) => m.slug) : tab === 'spells' ? mergedSpells.map((s) => s.slug) : mergedItems.map((i) => i.slug)}
            onCompiled={loadCustom}
          />
        )}
      </div>

      {/* Search */}
      <div className="flex items-center gap-2 glass-panel clip-corner px-3 py-2">
        <Search size={14} className="text-[#484f58]" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search..."
          className="flex-1 bg-transparent text-xs text-[#e6edf3] focus:outline-none placeholder:text-[#484f58]" />
      </div>

      {/* Tab-specific filters */}
      {tab === 'monsters' && (
        <div className="flex flex-wrap gap-2">
          <FilterSelect value={filters.environment} onChange={(v) => setFilters({ ...filters, environment: v })}
            options={[{ value: '', label: 'All Env' }, ...MONSTER_ENVIRONMENTS.map((e) => ({ value: e, label: e }))]} />
          <FilterSelect value={filters.role} onChange={(v) => setFilters({ ...filters, role: v })}
            options={[{ value: '', label: 'All Roles' }, ...MONSTER_ROLES.map((r) => ({ value: r, label: r }))]} />
          <FilterSelect value={filters.crMax} onChange={(v) => setFilters({ ...filters, crMax: v ? Number(v) : undefined })}
            options={[{ value: '', label: 'Any CR' }, { value: 0.5, label: 'CR ≤ 1/2' }, { value: 1, label: 'CR ≤ 1' }, { value: 3, label: 'CR ≤ 3' }, { value: 5, label: 'CR ≤ 5' }, { value: 10, label: 'CR ≤ 10' }, { value: 30, label: 'Any' }]} />
        </div>
      )}
      {tab === 'spells' && (
        <div className="flex flex-wrap gap-2">
          <FilterSelect value={filters.level} onChange={(v) => setFilters({ ...filters, level: v === '' ? undefined : Number(v) })}
            options={[{ value: '', label: 'All Levels' }, ...SPELL_LEVELS.map((l) => ({ value: l, label: l === 0 ? 'Cantrip' : `Level ${l}` }))]} />
          <FilterSelect value={filters.school} onChange={(v) => setFilters({ ...filters, school: v })}
            options={[{ value: '', label: 'All Schools' }, ...SPELL_SCHOOLS.map((s) => ({ value: s, label: s }))]} />
        </div>
      )}
      {tab === 'items' && (
        <div className="flex flex-wrap gap-2">
          <FilterSelect value={filters.type} onChange={(v) => setFilters({ ...filters, type: v })}
            options={[{ value: '', label: 'All Types' }, ...ITEM_TYPES.map((t) => ({ value: t, label: t }))]} />
          <FilterSelect value={filters.rarity} onChange={(v) => setFilters({ ...filters, rarity: v })}
            options={[{ value: '', label: 'All Rarity' }, ...ITEM_RARITIES.map((r) => ({ value: r, label: r }))]} />
        </div>
      )}

      {/* Results */}
      {tab === 'monsters' && <MonsterResults query={query} filters={filters} merged={mergedMonsters} selected={selected} setSelected={setSelected} onSelectMonster={onSelectMonster} />}
      {tab === 'spells' && <SpellResults query={query} filters={filters} merged={mergedSpells} />}
      {tab === 'items' && <ItemResults query={query} filters={filters} merged={mergedItems} />}
      {tab === 'classes' && <ClassResults query={query} />}
      {tab === 'backgrounds' && <BackgroundResults query={query} />}
      {tab === 'species' && <SpeciesResults query={query} />}
      {tab === 'conditions' && <ConditionResults query={query} />}
    </div>
  );
}

function FilterSelect({ value, onChange, options }) {
  return (
    <select value={value ?? ''} onChange={(e) => onChange(e.target.value)}
      className="bg-[#0d1117] border border-[#30363d] px-2 py-1 text-[10px] text-[#e6edf3] clip-corner focus:border-[#FF9F00]/40">
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}

function MonsterResults({ query, filters, merged, selected, setSelected, onSelectMonster }) {
  const results = useMemo(() => {
    return merged.filter((m) => {
      if (query && !m.name.toLowerCase().includes(query.toLowerCase())) return false;
      if (filters.crMin !== undefined && m.cr < filters.crMin) return false;
      if (filters.crMax !== undefined && m.cr > filters.crMax) return false;
      if (filters.environment && !m.environment?.toLowerCase().includes(filters.environment.toLowerCase())) return false;
      if (filters.role && m.role !== filters.role) return false;
      return true;
    });
  }, [merged, query, filters]);
  return (
    <div className="grid lg:grid-cols-2 gap-3">
      <div className="space-y-1.5 max-h-[60vh] overflow-y-auto pr-1">
        {results.map((m) => {
          const Icon = getMonsterIcon(m.type);
          return (
            <button key={m.slug} onClick={() => { setSelected(m); onSelectMonster?.(m); }}
              className={`w-full text-left p-2 border clip-corner transition-all flex items-center gap-2 ${selected?.slug === m.slug ? 'border-[#FF9F00] bg-[#FF9F00]/10' : 'border-[#30363d] bg-[#0d1117] hover:border-[#FF9F00]/30'}`}>
              <Icon size={16} className="text-[#f85149] shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-[#e6edf3] truncate">{m.name}{m.custom && <span className="text-[8px] text-[#4dd0e1] ml-1">★</span>}</span>
                  <span className="text-[9px] text-[#FF9F00] font-bold shrink-0">CR {m.cr}</span>
                </div>
                <div className="text-[9px] text-[#8b949e] truncate">{m.size} {m.type} · {m.environment} · {m.xp} XP</div>
              </div>
            </button>
          );
        })}
        {results.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No monsters found</p>}
      </div>
      <div className="max-h-[60vh] overflow-y-auto">{selected && <StatBlock monster={selected} />}</div>
    </div>
  );
}

function SpellResults({ query, filters, merged }) {
  const results = useMemo(() => {
    return merged.filter((s) => {
      if (query && !s.name.toLowerCase().includes(query.toLowerCase())) return false;
      if (filters.level !== undefined && s.level !== filters.level) return false;
      if (filters.school && s.school !== filters.school) return false;
      return true;
    });
  }, [merged, query, filters]);
  return (
    <div className="space-y-1.5 max-h-[60vh] overflow-y-auto">
      {results.map((s) => {
        const Icon = getSpellIcon(s.school);
        return (
          <div key={s.slug} className="p-2 border border-[#30363d] bg-[#0d1117] clip-corner flex items-start gap-2">
            <Icon size={16} className="text-[#4dd0e1] shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-[#e6edf3]">{s.name}{s.custom && <span className="text-[8px] text-[#4dd0e1] ml-1">★</span>}</span>
                <span className="text-[9px] px-1.5 py-0.5 border border-[#FF9F00]/30 text-[#FF9F00] bg-[#FF9F00]/5 clip-corner shrink-0">
                  {s.level === 0 ? 'Cantrip' : `L${s.level}`} · {s.school}
                </span>
              </div>
              <div className="text-[9px] text-[#8b949e] mt-0.5">
                {s.casting_time} · {s.range} {s.concentration ? '· Conc' : ''} {s.ritual ? '· Ritual' : ''}
              </div>
              <p className="text-[10px] text-[#c9d1d9] mt-1 leading-relaxed">{s.description}</p>
              <div className="text-[8px] text-[#484f58] mt-1">Classes: {s.classes.join(', ')}</div>
            </div>
          </div>
        );
      })}
      {results.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No spells found</p>}
    </div>
  );
}

function ItemResults({ query, filters, merged }) {
  const results = useMemo(() => {
    return merged.filter((i) => {
      if (query && !i.name.toLowerCase().includes(query.toLowerCase())) return false;
      if (filters.type && i.type !== filters.type) return false;
      if (filters.rarity && i.rarity !== filters.rarity) return false;
      return true;
    });
  }, [merged, query, filters]);
  const rarityColor = { common: '#8b949e', uncommon: '#3fb950', rare: '#3b8bff', 'very-rare': '#a371f7', legendary: '#fbbf24', artifact: '#f85149' };
  return (
    <div className="space-y-1.5 max-h-[60vh] overflow-y-auto">
      {results.map((i) => {
        const Icon = getItemIcon(i.type);
        return (
          <div key={i.slug} className="p-2 border border-[#30363d] bg-[#0d1117] clip-corner flex items-start gap-2">
            <Icon size={16} className="text-[#3fb950] shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-[#e6edf3]">{i.name}{i.custom && <span className="text-[8px] text-[#4dd0e1] ml-1">★</span>}</span>
                <span className="text-[9px] font-bold shrink-0" style={{ color: rarityColor[i.rarity] }}>{i.rarity}</span>
              </div>
              <div className="text-[9px] text-[#8b949e] mt-0.5">{i.type} · {i.value} {i.attunement ? '· Attunement' : ''}</div>
              <p className="text-[10px] text-[#c9d1d9] mt-1 leading-relaxed">{i.description}</p>
            </div>
          </div>
        );
      })}
      {results.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No items found</p>}
    </div>
  );
}

function ClassResults({ query }) {
  const results = CLASSES.filter((c) => !query || c.name.toLowerCase().includes(query.toLowerCase()));
  return (
    <div className="grid sm:grid-cols-2 gap-2 max-h-[60vh] overflow-y-auto">
      {results.map((c) => (
        <div key={c.slug} className="p-2 border border-[#30363d] bg-[#0d1117] clip-corner">
          <div className="flex justify-between">
            <span className="text-xs font-bold text-[#e6edf3]">{c.name}</span>
            <span className="text-[9px] text-[#FF9F00]">d{c.hit_die} HD</span>
          </div>
          <p className="text-[10px] text-[#8b949e] mt-0.5">{c.description}</p>
          <div className="text-[9px] text-[#484f58] mt-1">
            Saves: {c.save_proficiencies.join(', ')} · {c.spellcasting ? `Casts (${c.spellcasting_ability})` : 'No casting'}
          </div>
          <div className="text-[8px] text-[#484f58] mt-0.5">Key: {c.key_features.slice(0, 4).join(', ')}</div>
        </div>
      ))}
    </div>
  );
}

function BackgroundResults({ query }) {
  const results = BACKGROUNDS.filter((b) => !query || b.name.toLowerCase().includes(query.toLowerCase()));
  return (
    <div className="grid sm:grid-cols-2 gap-2 max-h-[60vh] overflow-y-auto">
      {results.map((b) => (
        <div key={b.slug} className="p-2 border border-[#30363d] bg-[#0d1117] clip-corner">
          <span className="text-xs font-bold text-[#e6edf3]">{b.name}</span>
          <p className="text-[10px] text-[#8b949e] mt-0.5">{b.description}</p>
          <div className="text-[9px] text-[#FF9F00] mt-1">Skill: {b.skill}</div>
          <div className="text-[9px] text-[#484f58]">{b.feature}</div>
        </div>
      ))}
    </div>
  );
}

function SpeciesResults({ query }) {
  const results = SPECIES.filter((s) => !query || s.name.toLowerCase().includes(query.toLowerCase()));
  return (
    <div className="grid sm:grid-cols-2 gap-2 max-h-[60vh] overflow-y-auto">
      {results.map((s) => (
        <div key={s.slug} className="p-2 border border-[#30363d] bg-[#0d1117] clip-corner">
          <div className="flex justify-between">
            <span className="text-xs font-bold text-[#e6edf3]">{s.name}</span>
            <span className="text-[9px] text-[#FF9F00]">{s.size} · {s.speed}ft</span>
          </div>
          <p className="text-[10px] text-[#8b949e] mt-0.5">{s.description}</p>
          <div className="text-[9px] text-[#484f58] mt-1">{s.traits.join(' · ')}</div>
        </div>
      ))}
    </div>
  );
}

function ConditionResults({ query }) {
  const results = CONDITIONS.filter((c) => !query || c.name.toLowerCase().includes(query.toLowerCase()));
  return (
    <div className="space-y-1.5 max-h-[60vh] overflow-y-auto">
      {results.map((c) => (
        <div key={c.slug} className="p-2 border border-[#30363d] bg-[#0d1117] clip-corner">
          <span className="text-xs font-bold text-[#f85149]">{c.name}</span>
          <p className="text-[10px] text-[#c9d1d9] mt-0.5 leading-relaxed">{c.description}</p>
          <div className="text-[9px] text-[#484f58] mt-1">Removal: {c.removal}</div>
        </div>
      ))}
    </div>
  );
}