/**
 * ImportPreviewModal — Confirm-and-merge preview for imported data.
 *
 * Shows what Merlin extracted from the uploaded file (characters, items, spells,
 * notes, campaign), lets the user toggle which entries to merge, then creates
 * or updates the appropriate entities. Merlin oversees reconciliation.
 */
import { useState } from 'react';
import { X, User, Package, Sparkles, BookOpen, ScrollText, Check, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getMonsterIcon, getItemIcon, getSpellIcon } from '@/lib/dnd/entityIcons';

export default function ImportPreviewModal({ result, onClose, onMerged }) {
  const { characters = [], items = [], spells = [], notes = [], campaign, characterId, campaignId, summary } = result;
  const [selected, setSelected] = useState({
    characters: characters.map((_, i) => true),
    items: items.map((_, i) => true),
    spells: spells.map((_, i) => true),
    notes: notes.map((_, i) => true),
    campaign: !!campaign,
  });
  const [merging, setMerging] = useState(false);
  const [done, setDone] = useState(false);

  const toggle = (cat, idx) => {
    setSelected((prev) => {
      const next = { ...prev };
      if (cat === 'campaign') next.campaign = !next.campaign;
      else next[cat] = prev[cat].map((v, i) => (i === idx ? !v : v));
      return next;
    });
  };

  const merge = async () => {
    setMerging(true);
    try {
      const cid = campaignId || '';
      // Merge characters
      for (let i = 0; i < characters.length; i++) {
        if (!selected.characters[i]) continue;
        const c = characters[i];
        const payload = {
          name: c.name || 'Imported Character',
          species: c.species || 'human',
          klass: c.klass || 'fighter',
          background: c.background || 'wanderer',
          level: c.level || 1,
          alignment: c.alignment || 'unaligned',
          ability_scores_json: JSON.stringify(c.ability_scores || {}),
          hp_current: c.hp_max || 0,
          hp_max: c.hp_max || 0,
          armor_class: c.armor_class || 10,
          gold: c.gold || 0,
          xp: c.xp || 0,
          spellcasting_ability: c.spellcasting_ability || '',
          spellbook_json: JSON.stringify(c.spellbook || []),
          inventory_json: JSON.stringify(c.inventory || []),
          notes_json: JSON.stringify(c.notes || []),
          abilities_json: JSON.stringify(c.abilities || []),
          solo: !cid,
          campaign_id: cid,
          player_id: '',
        };
        await base44.entities.DnDCharacter.create(payload);
      }

      // Merge items as inventory items or custom items
      for (let i = 0; i < items.length; i++) {
        if (!selected.items[i]) continue;
        const it = items[i];
        await base44.entities.DnDInventoryItem.create({
          campaign_id: cid,
          owner_type: cid ? 'party' : 'party',
          name: it.name || 'Imported Item',
          kind: it.type || 'misc',
          quantity: 1,
          rarity: it.rarity || 'common',
          description: it.description || '',
        });
      }

      // Merge spells as custom spells
      for (let i = 0; i < spells.length; i++) {
        if (!selected.spells[i]) continue;
        const s = spells[i];
        await base44.entities.DnDCustomSpell.create({
          name: s.name || 'Imported Spell',
          level: s.level || 0,
          school: s.school || 'custom',
          casting_time: s.casting_time || '',
          range: s.range || '',
          duration: s.duration || '',
          components: s.components || '',
          concentration: !!s.concentration,
          ritual: !!s.ritual,
          description: s.description || '',
          classes_json: JSON.stringify(s.classes || []),
          campaign_id: cid,
        });
      }

      // Merge notes as lore articles
      for (let i = 0; i < notes.length; i++) {
        if (!selected.notes[i]) continue;
        const n = notes[i];
        await base44.entities.DnDLoreArticle.create({
          campaign_id: cid,
          title: n.title || 'Imported Note',
          body: n.body || '',
          tags_json: JSON.stringify(n.tags || []),
        });
      }

      setDone(true);
      setTimeout(() => { onMerged?.(); }, 1200);
    } catch (e) {
      console.error('Merge failed:', e);
      alert('Merge failed: ' + e.message);
    }
    setMerging(false);
  };

  const totalSelected =
    selected.characters.filter(Boolean).length +
    selected.items.filter(Boolean).length +
    selected.spells.filter(Boolean).length +
    selected.notes.filter(Boolean).length +
    (selected.campaign ? 1 : 0);

  return (
    <div className="fixed inset-0 z-[800] bg-black/60 backdrop-blur-sm flex items-center justify-center p-3" onClick={onClose}>
      <div className="glass-strong clip-corner p-4 max-w-2xl w-full max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-bold text-[#e6edf3] font-heading">Import Preview</h3>
            <p className="text-[10px] text-[#8b949e] mt-0.5">{summary || `Parsed ${result.fileType} file`}</p>
          </div>
          <button onClick={onClose} className="text-[#8b949e] hover:text-[#e6edf3]"><X size={16} /></button>
        </div>

        {done ? (
          <div className="text-center py-8">
            <Check size={32} className="mx-auto text-[#3fb950] mb-2" />
            <p className="text-sm font-bold text-[#3fb950]">Merged successfully!</p>
            <p className="text-[10px] text-[#8b949e] mt-1">{totalSelected} entries imported to your sheets.</p>
          </div>
        ) : (
          <>
            {/* Characters */}
            {characters.length > 0 && (
              <Section title="Characters" icon={User} accent="#FF9F00">
                {characters.map((c, i) => (
                  <ImportRow key={i} checked={selected.characters[i]} onToggle={() => toggle('characters', i)}>
                    <div className="flex items-center gap-2">
                      <User size={14} className="text-[#FF9F00] shrink-0" />
                      <div>
                        <span className="text-xs font-bold text-[#e6edf3]">{c.name}</span>
                        <span className="text-[9px] text-[#8b949e] ml-2">{c.species} {c.klass} · L{c.level}</span>
                      </div>
                    </div>
                  </ImportRow>
                ))}
              </Section>
            )}

            {/* Items */}
            {items.length > 0 && (
              <Section title="Items" icon={Package} accent="#3fb950">
                {items.map((it, i) => {
                  const Icon = getItemIcon(it.type);
                  return (
                    <ImportRow key={i} checked={selected.items[i]} onToggle={() => toggle('items', i)}>
                      <div className="flex items-center gap-2">
                        <Icon size={14} className="text-[#3fb950] shrink-0" />
                        <div>
                          <span className="text-xs font-bold text-[#e6edf3]">{it.name}</span>
                          <span className="text-[9px] text-[#8b949e] ml-2">{it.type} · {it.rarity}</span>
                        </div>
                      </div>
                    </ImportRow>
                  );
                })}
              </Section>
            )}

            {/* Spells */}
            {spells.length > 0 && (
              <Section title="Spells" icon={Sparkles} accent="#4dd0e1">
                {spells.map((s, i) => {
                  const Icon = getSpellIcon(s.school);
                  return (
                    <ImportRow key={i} checked={selected.spells[i]} onToggle={() => toggle('spells', i)}>
                      <div className="flex items-center gap-2">
                        <Icon size={14} className="text-[#4dd0e1] shrink-0" />
                        <div>
                          <span className="text-xs font-bold text-[#e6edf3]">{s.name}</span>
                          <span className="text-[9px] text-[#8b949e] ml-2">{s.level === 0 ? 'Cantrip' : 'L'+s.level} · {s.school}</span>
                        </div>
                      </div>
                    </ImportRow>
                  );
                })}
              </Section>
            )}

            {/* Notes */}
            {notes.length > 0 && (
              <Section title="Notes & Lore" icon={BookOpen} accent="#bc8cff">
                {notes.map((n, i) => (
                  <ImportRow key={i} checked={selected.notes[i]} onToggle={() => toggle('notes', i)}>
                    <div className="flex items-center gap-2">
                      <BookOpen size={14} className="text-[#bc8cff] shrink-0" />
                      <div>
                        <span className="text-xs font-bold text-[#e6edf3]">{n.title}</span>
                        {n.body && <p className="text-[9px] text-[#8b949e] truncate max-w-xs">{n.body.slice(0, 80)}</p>}
                      </div>
                    </div>
                  </ImportRow>
                ))}
              </Section>
            )}

            {/* Campaign */}
            {campaign && (
              <Section title="Campaign" icon={ScrollText} accent="#d29922">
                <ImportRow checked={selected.campaign} onToggle={() => toggle('campaign')}>
                  <div className="flex items-center gap-2">
                    <ScrollText size={14} className="text-[#d29922] shrink-0" />
                    <div>
                      <span className="text-xs font-bold text-[#e6edf3]">{campaign.name}</span>
                      <span className="text-[9px] text-[#8b949e] ml-2">{campaign.setting} · {campaign.tone}</span>
                    </div>
                  </div>
                </ImportRow>
              </Section>
            )}

            {totalSelected === 0 && (
              <p className="text-[10px] text-[#484f58] text-center py-6">Nothing to import — toggle entries above to merge.</p>
            )}

            <div className="flex gap-2 mt-4 pt-3 border-t border-[#30363d]">
              <button onClick={onClose} className="flex-1 px-3 py-2 border border-[#30363d] text-[#8b949e] text-[10px] font-bold clip-corner touch-manipulation">Cancel</button>
              <button onClick={merge} disabled={merging || totalSelected === 0}
                className="flex-1 px-3 py-2 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation flex items-center justify-center gap-1.5">
                {merging ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />}
                {merging ? 'Merging...' : `Merge ${totalSelected} entr${totalSelected === 1 ? 'y' : 'ies'}`}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function Section({ title, icon: Icon, accent, children }) {
  return (
    <div className="mb-3">
      <div className="flex items-center gap-1.5 mb-1.5">
        <Icon size={12} style={{ color: accent }} />
        <span className="text-[10px] font-bold uppercase" style={{ color: accent }}>{title}</span>
      </div>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

function ImportRow({ checked, onToggle, children }) {
  return (
    <button onClick={onToggle} className={`w-full text-left p-2 border clip-corner transition-all flex items-center justify-between gap-2 ${
      checked ? 'border-[#FF9F00]/40 bg-[#FF9F00]/5' : 'border-[#30363d] bg-[#0d1117] opacity-60'
    }`}>
      {children}
      <div className={`w-4 h-4 border clip-corner flex items-center justify-center shrink-0 ${checked ? 'border-[#FF9F00] bg-[#FF9F00]' : 'border-[#484f58]'}`}>
        {checked && <Check size={10} className="text-black" />}
      </div>
    </button>
  );
}