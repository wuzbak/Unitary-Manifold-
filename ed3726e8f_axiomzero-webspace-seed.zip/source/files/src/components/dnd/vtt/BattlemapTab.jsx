/**
 * BattlemapTab — DM surface for the live VTT. Scene selector, map upload,
 * token sync from the active encounter, fog reveal-all, AoE clear, and the
 * tool toolbar (Move / Reveal / Hide / Measure / Cone / Line / Cube / Sphere).
 * Renders BattlemapCanvas; all edits persist to the BattlemapScene entity and
 * sync live to every joined player.
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Upload, Eye, EyeOff, Ruler, Cone, Minus, Square, Circle, Trash2, Users } from 'lucide-react';
import BattlemapCanvas from './BattlemapCanvas';
import { DEFAULT_GRID } from '@/lib/dnd/vttEngine';

const TOOLS = [
  { id: 'select', label: 'Move', icon: Users },
  { id: 'fog-reveal', label: 'Reveal', icon: Eye },
  { id: 'fog-hide', label: 'Hide', icon: EyeOff },
  { id: 'measure', label: 'Measure', icon: Ruler },
  { id: 'aoe-cone', label: 'Cone', icon: Cone },
  { id: 'aoe-line', label: 'Line', icon: Minus },
  { id: 'aoe-cube', label: 'Cube', icon: Square },
  { id: 'aoe-sphere', label: 'Sphere', icon: Circle },
];

export default function BattlemapTab({ campaign, characters }) {
  const [scenes, setScenes] = useState([]);
  const [activeScene, setActiveScene] = useState(null);
  const [tool, setTool] = useState('select');
  const [aoeSize, setAoeSize] = useState(3);
  const [combatants, setCombatants] = useState([]);
  const [activeCombatantId, setActiveCombatantId] = useState('');

  const loadScenes = useCallback(async () => {
    if (!campaign) return;
    const list = await base44.entities.BattlemapScene.filter({ campaign_id: campaign.id }, '-created_date', 20);
    setScenes(list || []);
    setActiveScene((prev) => prev || (list && list[0]) || null);
  }, [campaign]);

  const loadCombatants = useCallback(async () => {
    if (!campaign) return;
    const encs = await base44.entities.DnDEncounter.filter({ campaign_id: campaign.id, status: 'active' }, '-created_date', 1);
    const enc = encs && encs[0];
    if (!enc) { setCombatants([]); setActiveCombatantId(''); return; }
    const list = await base44.entities.DnDCombatant.filter({ encounter_id: enc.id }, 'sort_order', 50);
    setCombatants(list || []);
    const sorted = [...(list || [])].sort((a, b) => (b.initiative || 0) - (a.initiative || 0));
    setActiveCombatantId(sorted[0]?.id || '');
  }, [campaign]);

  useEffect(() => { loadScenes(); }, [loadScenes]);
  useEffect(() => { loadCombatants(); }, [loadCombatants]);
  useEffect(() => {
    const u1 = base44.entities.BattlemapScene.subscribe(() => loadScenes());
    const u2 = base44.entities.DnDCombatant.subscribe(() => loadCombatants());
    return () => { u1(); u2(); };
  }, [loadScenes, loadCombatants]);

  const updateScene = async (patch) => { if (activeScene) await base44.entities.BattlemapScene.update(activeScene.id, patch); };

  const createScene = async () => {
    const s = await base44.entities.BattlemapScene.create({
      campaign_id: campaign.id, name: `Scene ${scenes.length + 1}`, map_image_url: '',
      grid_config_json: JSON.stringify(DEFAULT_GRID), fog_json: JSON.stringify({ hidden: [] }),
      tokens_json: '[]', templates_json: '[]',
    });
    await loadScenes(); setActiveScene(s);
  };

  const uploadMap = async (file) => {
    if (!file || !activeScene) return;
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await updateScene({ map_image_url: file_url });
    await loadScenes();
  };

  const syncCombatants = async () => {
    if (!activeScene || combatants.length === 0) return;
    let mcol = 26;
    const tokens = combatants.map((c) => ({
      id: c.id, combatant_id: c.id, name: c.name,
      col: c.type === 'character' ? 2 : mcol++,
      row: 2 + Math.floor((c.sort_order || 0) % 8),
      color: c.type === 'character' ? '#4dd0e1' : '#f85149',
      type: c.type, hp_current: c.hp_current, hp_max: c.hp_max,
    }));
    await updateScene({ tokens_json: JSON.stringify(tokens) });
  };

  return (
    <div className="space-y-3">
      <div className="glass-strong clip-corner p-2.5 flex flex-wrap items-center gap-2">
        <select value={activeScene?.id || ''} onChange={(e) => setActiveScene(scenes.find((s) => s.id === e.target.value))}
          className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
          <option value="">Select scene…</option>
          {scenes.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
        <button onClick={createScene} className="flex items-center gap-1 px-2 py-1.5 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> New</button>
        <label className="flex items-center gap-1 px-2 py-1.5 border border-[#30363d] text-[#8b949e] text-[10px] clip-corner touch-manipulation cursor-pointer">
          <Upload size={12} /> Upload Map
          <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files[0] && uploadMap(e.target.files[0])} />
        </label>
        <button onClick={syncCombatants} className="flex items-center gap-1 px-2 py-1.5 border border-[#30363d] text-[#8b949e] text-[10px] clip-corner touch-manipulation"><Users size={12} /> Sync Tokens</button>
        <button onClick={() => updateScene({ fog_json: JSON.stringify({ hidden: [] }) })} className="flex items-center gap-1 px-2 py-1.5 border border-[#30363d] text-[#8b949e] text-[10px] clip-corner touch-manipulation"><Eye size={12} /> Reveal All</button>
        <button onClick={() => updateScene({ templates_json: '[]' })} className="flex items-center gap-1 px-2 py-1.5 border border-[#30363d] text-[#8b949e] text-[10px] clip-corner touch-manipulation"><Trash2 size={12} /> Clear AoE</button>
      </div>

      <div className="flex flex-wrap items-center gap-1.5">
        {TOOLS.map((t) => {
          const Icon = t.icon; const active = tool === t.id;
          return (
            <button key={t.id} onClick={() => setTool(t.id)}
              className={`flex items-center gap-1 px-2.5 py-1.5 border clip-corner text-[10px] font-bold touch-manipulation ${active ? 'border-[#FF9F00] bg-[#FF9F00]/15 text-[#FF9F00]' : 'border-[#30363d] text-[#8b949e]'}`}>
              <Icon size={12} /> {t.label}
            </button>
          );
        })}
        {tool.startsWith('aoe-') && (
          <div className="flex items-center gap-1.5 px-2 py-1 border border-[#30363d] clip-corner">
            <span className="text-[9px] text-[#8b949e]">Size</span>
            <input type="number" min={1} max={10} value={aoeSize} onChange={(e) => setAoeSize(Number(e.target.value))} className="w-12 bg-[#0d1117] border border-[#30363d] px-1 py-0.5 text-[10px] text-[#e6edf3] clip-corner" />
          </div>
        )}
      </div>

      {activeScene ? (
        <div className="tactical-hud glass-panel clip-corner p-2">
          <BattlemapCanvas scene={activeScene} activeCombatantId={activeCombatantId} mode="dm" tool={tool} aoeSize={aoeSize} onUpdateScene={updateScene} />
        </div>
      ) : (
        <div className="glass-panel clip-corner p-8 text-center text-[10px] text-[#8b949e]">Create a scene to begin the live battlemap.</div>
      )}
    </div>
  );
}