/**
 * RollFeed — live stream of DnDRoll records for a campaign. Subscribes to the
 * entity so new rolls appear in real time. Shows roller, label, total, and
 * crit/fumble indicators.
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Dices, Zap, Skull } from 'lucide-react';

export default function RollFeed({ campaignId }) {
  const [rolls, setRolls] = useState([]);
  const load = useCallback(async () => {
    if (!campaignId) return;
    const list = await base44.entities.DnDRoll.filter({ campaign_id: campaignId }, '-created_date', 20);
    setRolls(list || []);
  }, [campaignId]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const u = base44.entities.DnDRoll.subscribe(() => load()); return u; }, [load]);

  return (
    <div className="glass-panel clip-corner p-2.5">
      <div className="flex items-center gap-1.5 mb-2">
        <Dices size={13} className="text-[#FF9F00]" />
        <span className="text-[10px] font-bold text-[#FF9F00] uppercase tracking-wider">Live Roll Feed</span>
      </div>
      <div className="space-y-1 max-h-48 overflow-y-auto">
        {rolls.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-3">No rolls yet</p>}
        {rolls.map((r) => (
          <div key={r.id} className="flex items-center justify-between p-1.5 bg-[#0d1117] border border-[#30363d] clip-corner">
            <div className="min-w-0">
              <span className="text-[10px] font-bold text-[#e6edf3]">{r.roller_name || 'Someone'}</span>
              <span className="text-[9px] text-[#484f58] ml-1.5 truncate">{r.label || r.expression}</span>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <span className="text-sm font-bold font-mono" style={{ color: r.is_crit ? '#3fb950' : r.is_fumble ? '#f85149' : '#e6edf3' }}>{r.total}</span>
              {r.is_crit && <Zap size={11} className="text-[#3fb950]" />}
              {r.is_fumble && <Skull size={11} className="text-[#f85149]" />}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}