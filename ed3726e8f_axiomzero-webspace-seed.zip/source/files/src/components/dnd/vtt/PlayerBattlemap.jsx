/**
 * PlayerBattlemap — read-only live VTT view for a joined player. Shows the
 * campaign's most recent battlemap scene with only revealed cells visible,
 * the active combatant ring, and the live roll feed. Falls back gracefully
 * when the DM hasn't launched a scene.
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import BattlemapCanvas from './BattlemapCanvas';
import RollFeed from './RollFeed';

export default function PlayerBattlemap({ campaign }) {
  const [scene, setScene] = useState(null);
  const [activeCombatantId, setActiveCombatantId] = useState('');

  const load = useCallback(async () => {
    if (!campaign) return;
    const list = await base44.entities.BattlemapScene.filter({ campaign_id: campaign.id }, '-created_date', 1);
    setScene(list && list[0] ? list[0] : null);
    const encs = await base44.entities.DnDEncounter.filter({ campaign_id: campaign.id, status: 'active' }, '-created_date', 1);
    const enc = encs && encs[0];
    if (enc) {
      const combs = await base44.entities.DnDCombatant.filter({ encounter_id: enc.id }, 'sort_order', 50);
      const sorted = [...(combs || [])].sort((a, b) => (b.initiative || 0) - (a.initiative || 0));
      setActiveCombatantId(sorted[0]?.id || '');
    }
  }, [campaign]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const u1 = base44.entities.BattlemapScene.subscribe(() => load());
    const u2 = base44.entities.DnDCombatant.subscribe(() => load());
    return () => { u1(); u2(); };
  }, [load]);

  return (
    <div className="space-y-3">
      <div className="glass-strong clip-corner p-2.5 flex items-center justify-between">
        <span className="text-xs font-bold text-[#4dd0e1] font-heading">LIVE BATTLEMAP</span>
        <span className="text-[9px] text-[#8b949e] flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-[#30d158] glow-pulse" /> Synced</span>
      </div>
      {scene ? (
        <div className="tactical-hud glass-panel clip-corner p-2">
          <BattlemapCanvas scene={scene} activeCombatantId={activeCombatantId} mode="player" tool="select" />
        </div>
      ) : (
        <div className="glass-panel clip-corner p-8 text-center text-[10px] text-[#8b949e]">The DM hasn't launched a battlemap scene yet.</div>
      )}
      <RollFeed campaignId={campaign?.id} />
    </div>
  );
}