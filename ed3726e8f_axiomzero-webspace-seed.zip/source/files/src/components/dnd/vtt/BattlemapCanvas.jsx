/**
 * BattlemapCanvas — HTML-canvas VTT grid with token drag, cell-based fog-of-war,
 * a measuring tool, and AoE template stamps. DM mode edits; player mode is
 * read-only and only sees revealed (non-hidden) cells. Token/fog/template
 * state is held locally during a drag and persisted to the BattlemapScene
 * entity on pointer-up, so every subscriber syncs live.
 */
import { useState, useEffect, useRef } from 'react';
import {
  DEFAULT_GRID, parseGrid, parseTokens, parseFog, parseTemplates,
  pixelToCell, cellKey, keyToCell, drawToken, drawTemplateCells, drawMeasure,
} from '@/lib/dnd/vttEngine';

const CANVAS_W = 960, CANVAS_H = 600;

export default function BattlemapCanvas({ scene, activeCombatantId = '', mode = 'dm', tool = 'select', aoeSize = 3, onUpdateScene }) {
  const canvasRef = useRef(null);
  const imgRef = useRef(null);
  const dragRef = useRef(false);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [tokens, setTokens] = useState(() => parseTokens(scene));
  const [fog, setFog] = useState(() => parseFog(scene));
  const [templates, setTemplates] = useState(() => parseTemplates(scene));
  const [dragId, setDragId] = useState(null);
  const [fogDragging, setFogDragging] = useState(null);
  const [measure, setMeasure] = useState({ start: null, end: null });

  const grid = { ...DEFAULT_GRID, ...parseGrid(scene) };

  useEffect(() => {
    setImgLoaded(false);
    if (!scene?.map_image_url) return;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => { imgRef.current = img; setImgLoaded(true); };
    img.src = scene.map_image_url;
  }, [scene?.map_image_url]);

  useEffect(() => { if (!dragRef.current) setTokens(parseTokens(scene)); }, [scene]);
  useEffect(() => { if (!dragRef.current) setFog(parseFog(scene)); }, [scene]);
  useEffect(() => { setTemplates(parseTemplates(scene)); }, [scene]);
  useEffect(() => { draw(); });

  function getCell(e) {
    const canvas = canvasRef.current; if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (canvas.width / rect.width);
    const y = (e.clientY - rect.top) * (canvas.height / rect.height);
    return pixelToCell(x, y, grid);
  }

  function draw() {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const cs = grid.cellSize;
    const cols = Math.floor(CANVAS_W / cs), rows = Math.floor(CANVAS_H / cs);
    ctx.fillStyle = '#0B0F13'; ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    if (imgRef.current && imgLoaded) ctx.drawImage(imgRef.current, 0, 0, CANVAS_W, CANVAS_H);
    ctx.strokeStyle = 'rgba(77,208,225,0.13)'; ctx.lineWidth = 1;
    for (let c = 0; c <= cols; c++) { ctx.beginPath(); ctx.moveTo(c * cs, 0); ctx.lineTo(c * cs, rows * cs); ctx.stroke(); }
    for (let r = 0; r <= rows; r++) { ctx.beginPath(); ctx.moveTo(0, r * cs); ctx.lineTo(cols * cs, r * cs); ctx.stroke(); }
    for (const k of fog) {
      const { col, row } = keyToCell(k);
      if (col < 0 || row < 0 || col >= cols || row >= rows) continue;
      ctx.fillStyle = mode === 'player' ? 'rgba(11,15,19,0.97)' : 'rgba(11,15,19,0.5)';
      ctx.fillRect(col * cs, row * cs, cs, cs);
      if (mode === 'dm') { ctx.strokeStyle = 'rgba(255,159,0,0.22)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(col * cs, row * cs); ctx.lineTo(col * cs + cs, row * cs + cs); ctx.stroke(); }
    }
    for (const t of templates) drawTemplateCells(ctx, t, cs);
    for (const tk of tokens) drawToken(ctx, tk, cs, activeCombatantId, dragId === tk.id);
    if (measure.start && measure.end) drawMeasure(ctx, measure.start, measure.end, cs);
  }

  const persistTokens = (next) => onUpdateScene?.({ tokens_json: JSON.stringify(next) });
  const persistFog = (next) => onUpdateScene?.({ fog_json: JSON.stringify({ hidden: [...next] }) });
  const persistTemplates = (next) => onUpdateScene?.({ templates_json: JSON.stringify(next) });

  function onPointerDown(e) {
    if (mode === 'player') return;
    const cell = getCell(e); if (!cell) return;
    dragRef.current = true;
    e.currentTarget.setPointerCapture?.(e.pointerId);
    if (tool === 'select') {
      const tk = [...tokens].reverse().find((t) => t.col === cell.col && t.row === cell.row);
      if (tk) setDragId(tk.id);
    } else if (tool === 'fog-reveal') {
      setFog((p) => { const n = new Set(p); n.delete(cellKey(cell)); return n; }); setFogDragging('reveal');
    } else if (tool === 'fog-hide') {
      setFog((p) => { const n = new Set(p); n.add(cellKey(cell)); return n; }); setFogDragging('hide');
    } else if (tool === 'measure') {
      setMeasure({ start: cell, end: cell });
    } else if (tool.startsWith('aoe-')) {
      const shape = tool.replace('aoe-', '');
      setTemplates((p) => { const n = [...p, { shape, origin: cell, size: aoeSize, dir: 'right' }]; persistTemplates(n); return n; });
    }
  }

  function onPointerMove(e) {
    const cell = getCell(e); if (!cell) return;
    if (dragId) setTokens((p) => p.map((t) => (t.id === dragId ? { ...t, col: cell.col, row: cell.row } : t)));
    else if (fogDragging) setFog((p) => { const n = new Set(p); fogDragging === 'reveal' ? n.delete(cellKey(cell)) : n.add(cellKey(cell)); return n; });
    else if (measure.start && tool === 'measure') setMeasure((m) => ({ ...m, end: cell }));
  }

  function onPointerUp() {
    if (dragId) { persistTokens(tokens); setDragId(null); }
    if (fogDragging) { persistFog(fog); setFogDragging(null); }
    dragRef.current = false;
  }

  return (
    <canvas
      ref={canvasRef}
      width={CANVAS_W}
      height={CANVAS_H}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      className="w-full h-auto bg-[#0B0F13] clip-corner touch-none"
      style={{ aspectRatio: `${CANVAS_W}/${CANVAS_H}`, cursor: mode === 'player' ? 'default' : 'crosshair' }}
    />
  );
}