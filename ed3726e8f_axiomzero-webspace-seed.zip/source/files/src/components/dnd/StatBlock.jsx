import { useState } from 'react';
import { CONDITIONS, MONSTER_ROLES, MONSTER_ENVIRONMENTS } from '@/lib/dnd/compendium';

const RARITY_COLORS = {
  common: '#8b949e', uncommon: '#3fb950', rare: '#3b8bff',
  'very-rare': '#a371f7', legendary: '#fbbf24', artifact: '#f85149',
};

export default function StatBlock({ monster }) {
  if (!monster) return null;
  return (
    <div className="glass-panel clip-corner p-3 border-l-2" style={{ borderLeftColor: '#FF9F00' }}>
      <div className="flex items-start justify-between gap-2 mb-2">
        <div>
          <h3 className="text-base font-bold text-[#e6edf3] font-heading">{monster.name}</h3>
          <p className="text-[10px] text-[#8b949e]">
            {monster.size} {monster.type}, {monster.alignment || 'unaligned'}
          </p>
        </div>
        <div className="text-right">
          <span className="text-[9px] px-1.5 py-0.5 border border-[#FF9F00]/40 text-[#FF9F00] bg-[#FF9F00]/10 clip-corner font-bold">
            CR {monster.cr}
          </span>
          <p className="text-[9px] text-[#8b949e] mt-1">{monster.xp} XP</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 text-[10px] mb-2">
        <Stat label="AC" value={monster.ac} />
        <Stat label="HP" value={monster.hp} />
        <Stat label="Speed" value={monster.speed} />
      </div>

      <div className="grid grid-cols-6 gap-1 text-center text-[9px] mb-2">
        {['str', 'dex', 'con', 'int', 'wis', 'cha'].map((ab) => (
          <div key={ab} className="bg-[#0d1117] border border-[#30363d] p-1 clip-corner">
            <div className="text-[#8b949e] uppercase font-bold">{ab}</div>
            <div className="text-[#e6edf3] font-bold">{monster[ab]}</div>
            <div className="text-[#484f58]">({mod(monster[ab])})</div>
          </div>
        ))}
      </div>

      {monster.senses && <Line label="Senses" value={monster.senses} />}
      {monster.languages && <Line label="Languages" value={monster.languages} />}

      {monster.signature_abilities?.length > 0 && (
        <div className="mt-2">
          <p className="text-[9px] text-[#FF9F00] font-bold uppercase mb-1">Signature Abilities</p>
          {monster.signature_abilities.map((a, i) => (
            <p key={i} className="text-[10px] text-[#c9d1d9] mb-0.5">• {a}</p>
          ))}
        </div>
      )}

      {monster.actions?.length > 0 && (
        <div className="mt-2">
          <p className="text-[9px] text-[#FF9F00] font-bold uppercase mb-1">Actions</p>
          {monster.actions.map((a, i) => (
            <p key={i} className="text-[10px] text-[#c9d1d9] mb-0.5">• {a}</p>
          ))}
        </div>
      )}

      {monster.tactics?.length > 0 && (
        <div className="mt-2 pt-2 border-t border-[#30363d]">
          <p className="text-[9px] text-[#4dd0e1] font-bold uppercase mb-1">Tactics</p>
          {monster.tactics.map((t, i) => (
            <p key={i} className="text-[10px] text-[#8b949e] mb-0.5">• {t}</p>
          ))}
        </div>
      )}
    </div>
  );
}

function mod(score) {
  return Math.floor((score - 10) / 2);
}

function Stat({ label, value }) {
  return (
    <div className="bg-[#0d1117] border border-[#30363d] p-1.5 clip-corner text-center">
      <div className="text-[#8b949e] uppercase text-[8px] font-bold">{label}</div>
      <div className="text-[#e6edf3] font-bold">{value}</div>
    </div>
  );
}

function Line({ label, value }) {
  return (
    <p className="text-[10px] text-[#c9d1d9] mb-0.5">
      <span className="text-[#FF9F00] font-bold uppercase text-[9px]">{label} </span>
      {value}
    </p>
  );
}