import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Users, ScrollText, Swords, Image, BookOpen, Search, Plus, KeyRound, Dices, Store, Radio } from 'lucide-react';
import CharacterSheet from '@/components/dnd/CharacterSheet';
import CharacterBuilder from '@/components/dnd/CharacterBuilder';
import CompendiumBrowser from '@/components/dnd/CompendiumBrowser';
import ConditionBadges from '@/components/dnd/ConditionBadges';
import CosmicDiceChamber from '@/components/dnd/dice/CosmicDiceChamber';
import CosmicDiceModal from '@/components/dnd/dice/CosmicDiceModal';
import Marketplace from '@/components/dnd/shop/Marketplace';
import PlayerBattlemap from '@/components/dnd/vtt/PlayerBattlemap';
import { logRoll } from '@/lib/dnd/rollLog';

export default function PlayerDashboard({ playerRecords, campaigns, activeCampaign, setActiveCampaign, activePlayer, setActivePlayer, onRefresh, onLiveState }) {
  const [tab, setTab] = useState('join');
  const [characters, setCharacters] = useState([]);
  const [sharedImages, setSharedImages] = useState([]);
  const [quests, setQuests] = useState([]);
  const [npcs, setNpcs] = useState([]);
  const [combatants, setCombatants] = useState([]);
  const [showCharBuilder, setShowCharBuilder] = useState(false);
  const [editingChar, setEditingChar] = useState(null);
  const [joinCode, setJoinCode] = useState('');
  const [joinName, setJoinName] = useState('');
  const [joining, setJoining] = useState(false);
  const [diceModalOpen, setDiceModalOpen] = useState(false);

  const loadPlayerData = useCallback(async () => {
    if (!activeCampaign || !activePlayer) return;
    try {
      const [chars, imgs, qs, ns, combs] = await Promise.all([
        base44.entities.DnDCharacter.filter({ campaign_id: activeCampaign.id, player_id: activePlayer.id }, '-created_date', 20),
        base44.entities.DnDSharedImage.filter({ campaign_id: activeCampaign.id }, '-created_date', 20),
        base44.entities.DnDQuest.filter({ campaign_id: activeCampaign.id }, '-created_date', 50),
        base44.entities.DnDNpc.filter({ campaign_id: activeCampaign.id }, '-created_date', 50),
        base44.entities.DnDCombatant.list('-sort_order', 50),
      ]);
      setCharacters(chars || []); setSharedImages(imgs || []); setQuests(qs || []); setNpcs(ns || []);
      setCombatants((combs || []).filter((c) => c.campaign_id === activeCampaign.id));
    } catch (e) { console.error('Load player data:', e); }
  }, [activeCampaign, activePlayer]);

  useEffect(() => { loadPlayerData(); }, [loadPlayerData]);
  useEffect(() => {
    const unsubs = [
      base44.entities.DnDCharacter.subscribe(() => loadPlayerData()),
      base44.entities.DnDSharedImage.subscribe(() => loadPlayerData()),
      base44.entities.DnDQuest.subscribe(() => loadPlayerData()),
      base44.entities.DnDCombatant.subscribe(() => loadPlayerData()),
    ];
    return () => unsubs.forEach((u) => u());
  }, [loadPlayerData]);

  useEffect(() => {
    if (activeCampaign) onLiveState?.((prev) => ({ ...prev, activeCampaign: { name: activeCampaign.name, setting: activeCampaign.setting, rules_edition: activeCampaign.rules_edition } }));
  }, [activeCampaign, onLiveState]);

  const joinCampaign = async () => {
    setJoining(true);
    try {
      const camp = campaigns.find((c) => c.invite_code === joinCode.toUpperCase().trim());
      if (!camp) { alert('Invalid invite code. Check with your DM.'); setJoining(false); return; }
      const player = await base44.entities.DnDPlayer.create({
        campaign_id: camp.id, display_name: joinName || 'Player', invite_code: joinCode.toUpperCase().trim(),
      });
      await onRefresh();
      setActiveCampaign(camp); setActivePlayer(player); setTab('sheet');
      setJoinCode(''); setJoinName('');
    } catch (e) { alert(`Failed to join: ${e.message}`); }
    setJoining(false);
  };

  const myCombatants = combatants.filter((c) => characters.some((ch) => ch.name === c.name));

  // If already in a campaign, show the dashboard
  if (activeCampaign && activePlayer) {
    const TABS = [
      { id: 'sheet', label: 'My Character', icon: ScrollText },
      { id: 'party', label: 'Party', icon: Users },
      { id: 'combat', label: 'Combat', icon: Swords },
      { id: 'live', label: 'Live', icon: Radio },
      { id: 'dice', label: 'Dice', icon: Dices },
      { id: 'quests', label: 'Quests', icon: BookOpen },
      { id: 'marketplace', label: 'Marketplace', icon: Store },
      { id: 'images', label: 'Images', icon: Image },
      { id: 'compendium', label: 'Compendium', icon: Search },
    ];
    return (
      <div className="space-y-3">
        <div className="glass-strong clip-corner p-3 flex justify-between items-center">
          <div>
            <h2 className="text-sm font-bold text-[#e6edf3] font-heading">{activeCampaign.name}</h2>
            <p className="text-[10px] text-[#8b949e]">Playing as {activePlayer.display_name} · {activeCampaign.rules_edition}</p>
          </div>
          <button onClick={() => { setActiveCampaign(null); setActivePlayer(null); setTab('join'); }}
            className="text-[10px] text-[#8b949e] hover:text-[#FF9F00]">Leave</button>
        </div>

        <div className="flex gap-1 overflow-x-auto pb-1">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold border clip-corner whitespace-nowrap touch-manipulation ${
                  active ? 'border-[#FF9F00] bg-[#FF9F00]/15 text-[#FF9F00]' : 'border-[#30363d] bg-[#0d1117] text-[#8b949e]'
                }`}>
                <Icon size={12} /> {t.label}
              </button>
            );
          })}
        </div>

        {tab === 'sheet' && (
          <div className="space-y-3">
            {characters.length > 0 ? characters.map((c) => (
              <CharacterSheet key={c.id} character={c} onEdit={(ch) => { setEditingChar(ch); setShowCharBuilder(true); }} />
            )) : (
              <div className="glass-panel clip-corner p-4 text-center">
                <p className="text-[10px] text-[#8b949e] mb-3">Create your character to join the adventure.</p>
                <button onClick={() => { setEditingChar(null); setShowCharBuilder(true); }}
                  className="flex items-center gap-1.5 px-3 py-2 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner mx-auto touch-manipulation"><Plus size={12} /> Create Character</button>
              </div>
            )}
          </div>
        )}
        {tab === 'party' && (
          <div className="space-y-2">
            {characters.map((c) => (
              <div key={c.id} className="p-2.5 border border-[#30363d] bg-[#0d1117] clip-corner">
                <span className="text-xs font-bold text-[#e6edf3]">{c.name}</span>
                <span className="text-[9px] text-[#8b949e] ml-2">Lv {c.level} {c.klass}</span>
                <div className="flex gap-3 mt-1 text-[10px] text-[#8b949e]">
                  <span>❤️ {c.hp_current}/{c.hp_max}</span><span>🛡️ {c.armor_class}</span><span>👁️ {c.passive_perception}</span>
                </div>
                <ConditionBadges conditions={c.conditions_json} />
              </div>
            ))}
            {characters.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No party members yet</p>}
          </div>
        )}
        {tab === 'live' && <PlayerBattlemap campaign={activeCampaign} />}
        {tab === 'combat' && (
          <div className="space-y-2">
            {myCombatants.length > 0 ? myCombatants.map((c) => {
              const hpPct = c.hp_max > 0 ? (c.hp_current / c.hp_max) * 100 : 0;
              const hpColor = hpPct > 50 ? '#3fb950' : hpPct > 25 ? '#d29922' : '#f85149';
              return (
                <div key={c.id} className={`p-2.5 border clip-corner ${c.active_turn ? 'border-[#FF9F00] bg-[#FF9F00]/10' : 'border-[#30363d] bg-[#0d1117]'}`}>
                  <div className="flex justify-between">
                    <span className="text-xs font-bold text-[#e6edf3]">{c.name}</span>
                    {c.active_turn && <span className="text-[9px] text-[#FF9F00] font-bold animate-pulse">YOUR TURN</span>}
                  </div>
                  <div className="text-[10px] text-[#8b949e]">❤️ {c.hp_current}/{c.hp_max} · 🛡️ {c.ac}</div>
                  <div className="h-1.5 bg-[#0d1117] mt-1 clip-corner overflow-hidden">
                    <div className="h-full" style={{ width: `${Math.max(0, hpPct)}%`, background: hpColor }} />
                  </div>
                  <ConditionBadges conditions={c.conditions_json} />
                </div>
              );
            }) : <p className="text-[10px] text-[#484f58] text-center py-4">You are not in active combat</p>}
          </div>
        )}
        {tab === 'quests' && (
          <div className="space-y-2">
            {quests.filter((q) => q.status === 'active').map((q) => (
              <div key={q.id} className="p-2.5 border border-[#30363d] bg-[#0d1117] clip-corner">
                <span className="text-xs font-bold text-[#e6edf3]">{q.title}</span>
                {q.objective && <p className="text-[10px] text-[#8b949e] mt-0.5">🎯 {q.objective}</p>}
                {q.reward && <p className="text-[10px] text-[#d29922]">💰 {q.reward}</p>}
              </div>
            ))}
            {quests.filter((q) => q.status === 'active').length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No active quests</p>}
          </div>
        )}
        {tab === 'images' && (
          <div className="grid sm:grid-cols-2 gap-2">
            {sharedImages.filter((i) => i.audience !== 'dm_only').map((img) => (
              <div key={img.id} className="border border-[#30363d] bg-[#0d1117] clip-corner overflow-hidden">
                {img.image_url && <img src={img.image_url} alt={img.title} className="w-full h-32 object-cover" />}
                <div className="p-2">
                  <span className="text-xs font-bold text-[#e6edf3]">{img.title}</span>
                  {img.caption && <p className="text-[10px] text-[#8b949e]">{img.caption}</p>}
                </div>
              </div>
            ))}
            {sharedImages.filter((i) => i.audience !== 'dm_only').length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4 sm:col-span-2">No shared images</p>}
          </div>
        )}
        {tab === 'dice' && (
          <div className="space-y-3">
            <CosmicDiceChamber onOpenModal={() => setDiceModalOpen(true)} mode="player" accent="#FF9F00" onRollLogged={(roll) => logRoll(activeCampaign?.id, '', activePlayer?.id, activePlayer?.display_name || 'Player', roll)} />
            <div className="glass-panel clip-corner p-3">
              <p className="text-[10px] text-[#8b949e]">
                <span className="text-[#FF9F00] font-bold">Player Cosmic Dice</span> — Roll through the toroidal universe. Quick-roll with the inline chamber, or open the full modal for advantage/disadvantage, DC checks, and roll history.
              </p>
            </div>
          </div>
        )}
        {tab === 'marketplace' && (
          <Marketplace mode="player" campaign={activeCampaign} character={characters[0]} />
        )}
        {tab === 'compendium' && <CompendiumBrowser />}

        <CosmicDiceModal isOpen={diceModalOpen} onClose={() => setDiceModalOpen(false)} mode="player" accent="#FF9F00" onRollLogged={(roll) => logRoll(activeCampaign?.id, '', activePlayer?.id, activePlayer?.display_name || 'Player', roll)} />

        {showCharBuilder && (
          <CharacterBuilder character={editingChar} campaignId={activeCampaign.id} playerId={activePlayer.id}
            onCancel={() => setShowCharBuilder(false)} onSave={() => { setShowCharBuilder(false); loadPlayerData(); }} />
        )}
      </div>
    );
  }

  // Join screen
  const myCampaigns = playerRecords.map((p) => campaigns.find((c) => c.id === p.campaign_id)).filter(Boolean);
  return (
    <div className="space-y-3">
      <div className="glass-strong clip-corner p-4 max-w-md mx-auto">
        <KeyRound size={28} className="mx-auto text-[#FF9F00]/60 mb-3" />
        <h3 className="text-sm font-bold text-[#e6edf3] text-center mb-1">Join a Campaign</h3>
        <p className="text-[10px] text-[#8b949e] text-center mb-4">Enter the invite code from your Dungeon Master.</p>
        <div className="space-y-2">
          <input value={joinCode} onChange={(e) => setJoinCode(e.target.value.toUpperCase())} placeholder="INVITE CODE" maxLength={6}
            className="w-full bg-[#0d1117] border border-[#30363d] px-3 py-2.5 text-center text-lg font-bold text-[#FF9F00] tracking-widest clip-corner font-mono" />
          <input value={joinName} onChange={(e) => setJoinName(e.target.value)} placeholder="Your display name"
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <button onClick={joinCampaign} disabled={joining || !joinCode.trim()}
            className="w-full px-3 py-2.5 bg-[#FF9F00] text-black text-xs font-bold clip-corner disabled:opacity-50 touch-manipulation">
            {joining ? 'Joining...' : 'Join Campaign'}
          </button>
        </div>
      </div>
      {myCampaigns.length > 0 && (
        <div>
          <p className="text-[10px] text-[#8b949e] uppercase font-bold mb-1.5">Your Campaigns</p>
          <div className="space-y-1.5">
            {myCampaigns.map((c) => {
              const p = playerRecords.find((pr) => pr.campaign_id === c.id);
              return (
                <button key={c.id} onClick={() => { setActiveCampaign(c); setActivePlayer(p); setTab('sheet'); }}
                  className="w-full text-left p-3 border border-[#30363d] bg-[#0d1117] clip-corner hover:border-[#FF9F00]/40">
                  <span className="text-sm font-bold text-[#e6edf3]">{c.name}</span>
                  <span className="text-[10px] text-[#8b949e] ml-2">{c.setting} · {c.rules_edition}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}