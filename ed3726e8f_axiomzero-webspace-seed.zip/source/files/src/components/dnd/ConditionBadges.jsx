import { CONDITIONS } from '@/lib/dnd/compendium';

const CONDITION_COLORS = {
  blinded: '#8b949e', charmed: '#f778ba', deafened: '#8b949e',
  frightened: '#db6d28', grappled: '#d29922', incapacitated: '#f85149',
  invisible: '#79c0ff', paralyzed: '#f85149', petrified: '#8b949e',
  poisoned: '#3fb950', prone: '#8b949e', restrained: '#d29922',
  stunned: '#f85149', unconscious: '#f85149', exhaustion: '#a371f7',
};

export default function ConditionBadges({ conditions = [], onRemove }) {
  if (!conditions || conditions.length === 0) return null;
  const parsed = typeof conditions === 'string' ? safeParse(conditions) : conditions;

  return (
    <div className="flex flex-wrap gap-1">
      {parsed.map((c, i) => {
        const name = typeof c === 'string' ? c : c.name;
        const slug = name.toLowerCase();
        const color = CONDITION_COLORS[slug] || '#8b949e';
        const condData = CONDITIONS.find((cd) => cd.slug === slug);
        const duration = typeof c === 'object' && c.duration ? ` (${c.duration}r)` : '';
        return (
          <span
            key={i}
            title={condData?.description || name}
            className="inline-flex items-center gap-1 px-1.5 py-0.5 text-[9px] font-bold border clip-corner cursor-default"
            style={{ color, borderColor: `${color}50`, background: `${color}15` }}
          >
            {name}{duration}
            {onRemove && (
              <button onClick={() => onRemove(name)} className="hover:text-white ml-0.5">✕</button>
            )}
          </span>
        );
      })}
    </div>
  );
}

function safeParse(str) {
  try { return JSON.parse(str); } catch { return []; }
}