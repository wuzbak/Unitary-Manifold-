/**
 * MerchantShop — Flushed-out NPC vendor shop view.
 *
 * Renders the vendor header (portrait glyph, name, specialty, temperament,
 * hooks, dialogue) above a dynamic inventory grid with live prices, stock
 * counts, and buy buttons. The UM shop gets a distinct cosmic treatment.
 */
import { useState, useMemo } from 'react';
import { ArrowLeft, RefreshCw, Coins, Sparkles, Package, Star } from 'lucide-react';
import { getShop, getShopInventory, bumpRestockEpoch, formatGold, RARITY_COLOR } from '@/lib/dnd/shopEngine';

const TEMPERAMENT_COLOR = {
  pragmatic: '#8b949e', precise: '#4dd0e1', warm: '#3fb950', gruff: '#db6d28',
  mysterious: '#a371f7', eccentric: '#fbbf24', enigmatic: '#bc8cff',
};

const VENDOR_GLYPH = {
  'lantern-guild-quartermaster': '🏮',
  'ember-arcana-broker': '🔥',
  'greenbottle-apothecary': '🧪',
  'ironhand-smith': '⚒️',
  'silken-way-trader': '🧭',
  'old-mother-hargrove': '🌙',
  'unitary-manifold-shop': '✦',
};

export default function MerchantShop({ slug, mode, onBuy, onBack }) {
  const [restockTick, setRestockTick] = useState(0);
  const merchant = getShop(slug);

  const inventory = useMemo(() => {
    return getShopInventory(slug);
  }, [slug, restockTick]);

  if (!merchant) return null;

  const isUM = merchant.isUM;
  const tempColor = TEMPERAMENT_COLOR[merchant.temperament] || '#8b949e';
  const glyph = VENDOR_GLYPH[slug] || '🏪';

  const restock = () => {
    bumpRestockEpoch();
    setRestockTick((t) => t + 1);
  };

  return (
    <div className="space-y-3">
      <button onClick={onBack} className="flex items-center gap-1.5 text-[10px] text-[#8b949e] hover:text-[#FF9F00] touch-manipulation">
        <ArrowLeft size={12} /> Back to Marketplace
      </button>

      {/* Vendor header */}
      <div
        className={`glass-strong clip-corner p-4 relative overflow-hidden ${isUM ? 'um-shop' : ''}`}
        style={isUM ? { borderColor: 'rgba(188,140,255,0.35)' } : { borderColor: `${tempColor}40` }}
      >
        {isUM && <div className="um-starfield" />}
        <div className="relative flex gap-4">
          {/* Portrait */}
          <div
            className="w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center text-3xl sm:text-4xl border-2 clip-corner shrink-0"
            style={{
              borderColor: isUM ? 'rgba(188,140,255,0.5)' : `${tempColor}50`,
              background: isUM
                ? 'linear-gradient(135deg, rgba(77,208,225,0.12), rgba(188,140,255,0.18))'
                : `${tempColor}12`,
            }}
          >
            {glyph}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-sm sm:text-base font-bold font-heading" style={{ color: isUM ? '#bc8cff' : '#e6edf3' }}>
                {merchant.name}
              </h3>
              <span
                className="text-[9px] px-1.5 py-0.5 border clip-corner font-bold"
                style={{ color: tempColor, borderColor: `${tempColor}50`, background: `${tempColor}12` }}
              >
                {merchant.temperament}
              </span>
              {isUM && (
                <span className="text-[9px] px-1.5 py-0.5 border border-[#4dd0e1]/40 text-[#4dd0e1] bg-[#4dd0e1]/10 clip-corner font-bold flex items-center gap-1">
                  <Sparkles size={9} /> UNITARY MANIFOLD
                </span>
              )}
            </div>
            <p className="text-[10px] text-[#8b949e] mt-0.5">{merchant.specialty}</p>
            {merchant.lore && (
              <p className="text-[10px] text-[#a371f7]/80 mt-1.5 italic leading-relaxed">{merchant.lore}</p>
            )}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {merchant.hooks.map((h, i) => (
                <span key={i} className="text-[9px] text-[#d29922] bg-[#d29922]/8 px-1.5 py-0.5 border border-[#d29922]/20 clip-corner">
                  {h}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Dialogue line */}
        {merchant.dialogue && (
          <div className="relative mt-3 glass-panel clip-corner p-2.5 border-l-2" style={{ borderLeftColor: isUM ? '#bc8cff' : tempColor }}>
            <p className="text-[11px] text-[#c9d1d9] italic leading-relaxed">
              "{merchant.dialogue[Math.floor(Math.random() * merchant.dialogue.length)]}"
            </p>
          </div>
        )}
      </div>

      {/* Inventory header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Package size={13} className="text-[#FF9F00]" />
          <span className="text-[10px] font-bold font-heading text-[#FF9F00]">CURRENT STOCK</span>
          <span className="text-[9px] text-[#484f58]">· {inventory.length} items</span>
        </div>
        <button
          onClick={restock}
          className="flex items-center gap-1.5 text-[9px] text-[#8b949e] hover:text-[#FF9F00] border border-[#30363d] hover:border-[#FF9F00]/40 px-2 py-1 clip-corner transition-all touch-manipulation"
        >
          <RefreshCw size={10} />
          {isUM ? 'The Child wanders off…' : 'Restock'}
        </button>
      </div>

      {/* Inventory grid */}
      <div className="grid sm:grid-cols-2 gap-2">
        {inventory.map(({ item, priceGold, stock, priceless }) => {
          const rarityColor = RARITY_COLOR[item.rarity] || '#8b949e';
          const canBuy = mode !== 'browse' && !priceless && stock > 0;
          return (
            <div
              key={item.slug}
              className="p-2.5 border bg-[#0d1117] clip-corner flex flex-col gap-1.5"
              style={{ borderColor: `${rarityColor}30` }}
            >
              <div className="flex justify-between items-start gap-2">
                <span className="text-xs font-bold text-[#e6edf3] leading-tight">{item.name}</span>
                <span className="text-[9px] font-bold shrink-0" style={{ color: rarityColor }}>{item.rarity}</span>
              </div>
              <div className="text-[9px] text-[#8b949e]">
                {item.type}
                {item.attunement ? ' · Attunement' : ''}
                {stock > 1 && !isUM ? ` · ${stock} in stock` : isUM ? ' · one-of-a-kind' : ''}
              </div>
              <p className="text-[10px] text-[#c9d1d9] leading-relaxed line-clamp-2">{item.description}</p>
              <div className="flex items-center justify-between mt-auto pt-1">
                <span className="flex items-center gap-1 text-[11px] font-bold" style={{ color: priceless ? '#f85149' : '#d29922' }}>
                  <Coins size={11} /> {priceless ? 'priceless' : formatGold(priceGold)}
                </span>
                {mode === 'browse' ? (
                  <span className="text-[9px] text-[#484f58] italic">browse only</span>
                ) : canBuy ? (
                  <button
                    onClick={() => onBuy?.(item, priceGold, merchant)}
                    className="flex items-center gap-1 px-2.5 py-1 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner hover:brightness-110 transition-all touch-manipulation"
                  >
                    Buy
                  </button>
                ) : (
                  <span className="text-[9px] text-[#f85149] italic">{priceless ? 'not for sale' : 'out of stock'}</span>
                )}
              </div>
            </div>
          );
        })}
        {inventory.length === 0 && (
          <div className="sm:col-span-2 glass-panel clip-corner p-4 text-center">
            <p className="text-[10px] text-[#8b949e]">
              {isUM ? 'The Child has wandered off. Try again soon.' : 'No stock available. Restock to refresh.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}