/**
 * Marketplace — Browse merchants, open shops, and run the approval-gated economy.
 *
 * Modes:
 *  - 'dm':     Buy deducts campaign.party_gold; self-approve immediate.
 *              Shows pending purchases from players for approval.
 *  - 'solo':   Buy deducts character.gold; self-approve immediate.
 *  - 'player': Buy creates a pending DnDInventoryItem (transaction_status='pending')
 *              for DM approval. No gold moved yet.
 *  - 'browse': No buy buttons (used by Adventurer's Commons).
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Store, Coins, Check, X, ShoppingBag, Sparkles, User } from 'lucide-react';
import { getAllShops, getShopInventory, RARITY_COLOR, formatGold } from '@/lib/dnd/shopEngine';
import MerchantShop from './MerchantShop';

export default function Marketplace({ mode = 'browse', campaign, character, onNotify }) {
  const [selectedShop, setSelectedShop] = useState(null);
  const [pending, setPending] = useState([]);
  const [gold, setGold] = useState(0);
  const [toast, setToast] = useState(null);

  const shops = getAllShops();

  const loadPending = useCallback(async () => {
    if (mode === 'dm' && campaign) {
      try {
        const items = await base44.entities.DnDInventoryItem.filter(
          { campaign_id: campaign.id, transaction_status: 'pending' },
          '-created_date', 50
        );
        setPending(items || []);
      } catch (e) { console.error('Load pending:', e); }
    }
  }, [mode, campaign]);

  const loadGold = useCallback(async () => {
    if (mode === 'dm' && campaign) {
      setGold(campaign.party_gold || 0);
    } else if (mode === 'solo' && character) {
      setGold(character.gold || 0);
    } else if (mode === 'player' && character) {
      setGold(character.gold || 0);
    }
  }, [mode, campaign, character]);

  useEffect(() => { loadPending(); }, [loadPending]);
  useEffect(() => { loadGold(); }, [loadGold]);
  useEffect(() => {
    if (mode !== 'dm') return;
    const unsub = base44.entities.DnDInventoryItem.subscribe(() => loadPending());
    return unsub;
  }, [mode, loadPending]);

  const notify = (msg) => {
    if (onNotify) { onNotify(msg); return; }
    setToast({ msg, id: Date.now() });
    setTimeout(() => setToast(null), 3500);
  };

  const handleBuy = async (item, priceGold, merchant) => {
    if (mode === 'browse') return;

    if (mode === 'player') {
      // Submit pending purchase for DM approval
      try {
        await base44.entities.DnDInventoryItem.create({
          campaign_id: campaign?.id || '',
          owner_type: 'party',
          owner_id: 'party',
          name: item.name,
          kind: mapKind(item.type),
          quantity: 1,
          rarity: item.rarity,
          attunement_required: !!item.attunement,
          description: item.description || '',
          transaction_status: 'pending',
          buyer_name: character?.name || 'Player',
          price_paid: priceGold,
          source_merchant: merchant.slug,
        });
        notify(`Purchase request submitted for ${item.name}. Awaiting DM approval.`);
      } catch (e) { notify(`Failed to submit request: ${e.message}`); }
      return;
    }

    // DM & Solo: confirm + self-approve
    const buyer = mode === 'dm' ? `the party` : (character?.name || 'you');
    if (!confirm(`Buy ${item.name} for ${formatGold(priceGold)} from ${merchant.name}?\n\nThis will deduct ${formatGold(priceGold)} from ${mode === 'dm' ? "the party's gold" : `${buyer}'s gold`}.`)) return;

    if (gold < priceGold) { notify(`Not enough gold. Need ${formatGold(priceGold)}, have ${formatGold(gold)}.`); return; }

    try {
      // Deduct gold
      if (mode === 'dm') {
        await base44.entities.DnDCampaign.update(campaign.id, { party_gold: (campaign.party_gold || 0) - priceGold });
      } else {
        await base44.entities.DnDCharacter.update(character.id, { gold: (character.gold || 0) - priceGold });
      }
      // Create approved inventory item
      await base44.entities.DnDInventoryItem.create({
        campaign_id: campaign?.id || '',
        owner_type: mode === 'dm' ? 'party' : 'character',
        owner_id: mode === 'dm' ? 'party' : (character?.id || 'solo'),
        name: item.name,
        kind: mapKind(item.type),
        quantity: 1,
        rarity: item.rarity,
        attunement_required: !!item.attunement,
        description: item.description || '',
        transaction_status: 'approved',
        buyer_name: buyer,
        price_paid: priceGold,
        source_merchant: merchant.slug,
      });
      notify(`Purchased ${item.name} for ${formatGold(priceGold)}.`);
      loadGold();
    } catch (e) { notify(`Purchase failed: ${e.message}`); }
  };

  const approvePending = async (p) => {
    if (!campaign) return;
    const price = p.price_paid || 0;
    if ((campaign.party_gold || 0) < price) { notify(`Not enough party gold for ${p.name}.`); return; }
    try {
      await base44.entities.DnDCampaign.update(campaign.id, { party_gold: (campaign.party_gold || 0) - price });
      await base44.entities.DnDInventoryItem.update(p.id, { transaction_status: 'approved' });
      notify(`Approved ${p.name} for ${p.buyer_name}.`);
      loadPending(); loadGold();
    } catch (e) { notify(`Approval failed: ${e.message}`); }
  };

  const rejectPending = async (p) => {
    try {
      await base44.entities.DnDInventoryItem.update(p.id, { transaction_status: 'rejected' });
      notify(`Rejected ${p.name}.`);
      loadPending();
    } catch (e) { notify(`Rejection failed: ${e.message}`); }
  };

  if (selectedShop) {
    return (
      <MerchantShop
        slug={selectedShop}
        mode={mode}
        onBuy={handleBuy}
        onBack={() => setSelectedShop(null)}
      />
    );
  }

  return (
    <div className="space-y-3">
      {/* Toast */}
      {toast && (
        <div className="glass-strong clip-corner p-2.5 text-[11px] text-[#e6edf3] border-l-2 border-[#FF9F00] animate-in fade-in" style={{ animation: 'fade-in 0.2s ease-out' }}>
          {toast.msg}
        </div>
      )}

      {/* Gold + pending bar */}
      {mode !== 'browse' && (
        <div className="glass-strong clip-corner p-2.5 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Coins size={14} className="text-[#d29922]" />
            <span className="text-xs font-bold text-[#d29922]">{formatGold(gold)}</span>
            <span className="text-[9px] text-[#8b949e]">
              {mode === 'dm' ? 'party gold' : 'your gold'}
            </span>
          </div>
          {mode === 'dm' && pending.length > 0 && (
            <span className="text-[9px] text-[#FF9F00] font-bold flex items-center gap-1">
              <ShoppingBag size={11} /> {pending.length} pending approval
            </span>
          )}
        </div>
      )}

      {/* Pending approvals (DM mode) */}
      {mode === 'dm' && pending.length > 0 && (
        <div className="glass-panel clip-corner p-3 space-y-2" style={{ borderColor: 'rgba(255,159,0,0.3)' }}>
          <div className="flex items-center gap-1.5">
            <ShoppingBag size={13} className="text-[#FF9F00]" />
            <span className="text-[10px] font-bold font-heading text-[#FF9F00]">PENDING PURCHASES</span>
          </div>
          {pending.map((p) => (
            <div key={p.id} className="flex items-center justify-between p-2 bg-[#0d1117] border border-[#30363d] clip-corner">
              <div className="min-w-0">
                <span className="text-xs font-bold text-[#e6edf3]">{p.name}</span>
                <span className="text-[9px] text-[#8b949e] ml-2">{p.buyer_name} · {formatGold(p.price_paid || 0)}</span>
              </div>
              <div className="flex gap-1 shrink-0">
                <button onClick={() => approvePending(p)} className="p-1.5 border border-[#3fb950]/40 text-[#3fb950] hover:bg-[#3fb950]/10 clip-corner touch-manipulation" title="Approve">
                  <Check size={12} />
                </button>
                <button onClick={() => rejectPending(p)} className="p-1.5 border border-[#f85149]/40 text-[#f85149] hover:bg-[#f85149]/10 clip-corner touch-manipulation" title="Reject">
                  <X size={12} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Shop grid */}
      <div className="grid sm:grid-cols-2 gap-2">
        {shops.map((shop) => {
          const isUM = shop.isUM;
          // Preview first 3 items
          const preview = getShopInventory(shop.slug).slice(0, 3);
          return (
            <button
              key={shop.slug}
              onClick={() => setSelectedShop(shop.slug)}
              className={`text-left p-3 border clip-corner transition-all touch-manipulation ${
                isUM
                  ? 'border-[#bc8cff]/30 bg-gradient-to-br from-[#0d1117] to-[#15102a] hover:border-[#bc8cff]/60'
                  : 'border-[#30363d] bg-[#0d1117] hover:border-[#FF9F00]/40'
              }`}
            >
              <div className="flex items-start gap-2">
                <Store size={16} className={isUM ? 'text-[#bc8cff]' : 'text-[#FF9F00]'} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold" style={{ color: isUM ? '#bc8cff' : '#e6edf3' }}>{shop.name}</span>
                    {isUM && <Sparkles size={10} className="text-[#4dd0e1]" />}
                  </div>
                  <p className="text-[10px] text-[#8b949e] mt-0.5">{shop.specialty}</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 mt-2">
                {preview.map(({ item }) => (
                  <span key={item.slug} className="text-[8px] px-1 py-0.5 border clip-corner" style={{ color: RARITY_COLOR[item.rarity], borderColor: `${RARITY_COLOR[item.rarity]}30`, background: `${RARITY_COLOR[item.rarity]}08` }}>
                    {item.name}
                  </span>
                ))}
                {preview.length === 0 && <span className="text-[8px] text-[#484f58] italic">stock rotates — open to see</span>}
              </div>
            </button>
          );
        })}
      </div>

      {mode === 'browse' && (
        <div className="glass-panel clip-corner p-2.5">
          <p className="text-[10px] text-[#8b949e]">
            <User size={10} className="inline mr-1 text-[#4dd0e1]" />
            Browse-only mode. Open the Marketplace from a campaign or solo workspace to buy items.
          </p>
        </div>
      )}
    </div>
  );
}

function mapKind(type) {
  const t = (type || '').toLowerCase();
  if (t === 'weapon') return 'weapon';
  if (t === 'armor') return 'armor';
  if (t === 'shield') return 'shield';
  if (t === 'consumable') return 'consumable';
  if (t === 'tool') return 'tool';
  return 'misc';
}