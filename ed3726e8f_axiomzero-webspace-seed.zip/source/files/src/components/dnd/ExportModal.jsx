/**
 * ExportModal — One EXPORT button's dropdown.
 *
 * Opens a modal with a format dropdown (JSON bundle, printable PDF, Markdown
 * journal, printable HTML), a file-name field, and a download trigger. Calls
 * dndExportBundle to compile the full character + campaign bundle, then
 * downloads the file. PDF is rendered client-side via jspdf.
 */
import { useState } from 'react';
import { X, Download, Loader2, FileJson, FileText, FileType, FileCode } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { downloadFile } from '@/lib/dnd/dndExport';

const FORMATS = [
  { id: 'json', label: 'JSON Bundle', icon: FileJson, desc: 'Full machine-readable data — re-importable' },
  { id: 'pdf', label: 'Printable PDF', icon: FileText, desc: 'Character sheet + campaign, print-ready' },
  { id: 'markdown', label: 'Markdown Journal', icon: FileCode, desc: 'Readable text journal for notes apps' },
  { id: 'html', label: 'Printable HTML', icon: FileType, desc: 'Web page, styled for printing' },
];

export default function ExportModal({ isOpen, onClose, characterId, campaignId }) {
  const [format, setFormat] = useState('json');
  const [fileName, setFileName] = useState('');
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const doExport = async () => {
    setExporting(true);
    setError('');
    try {
      const response = await base44.functions.invoke('dndExportBundle', { format, characterId, campaignId });
      const data = response.data || response;
      if (data.error) throw new Error(data.error);

      const name = (fileName.trim() || data.bundle?.character?.name || data.bundle?.campaign?.name || 'dnd-export').replace(/\s+/g, '-');
      const ext = data.ext || format;

      if (format === 'pdf') {
        await renderPdf(data.bundle, name);
      } else {
        downloadFile(`${name}.${ext}`, data.content, data.mimeType);
      }
      onClose();
    } catch (e) {
      setError(e.message || 'Export failed');
    }
    setExporting(false);
  };

  return (
    <div className="fixed inset-0 z-[800] bg-black/60 backdrop-blur-sm flex items-center justify-center p-3" onClick={onClose}>
      <div className="glass-strong clip-corner p-4 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-[#e6edf3] font-heading">Export Bundle</h3>
          <button onClick={onClose} className="text-[#8b949e] hover:text-[#e6edf3]"><X size={16} /></button>
        </div>

        <p className="text-[10px] text-[#8b949e] mb-3">
          Compiles your full character, campaign, feats, items, spells, and inventory into a downloadable file.
        </p>

        {/* Format dropdown */}
        <div className="space-y-1.5 mb-3">
          {FORMATS.map((f) => {
            const Icon = f.icon;
            const active = format === f.id;
            return (
              <button key={f.id} onClick={() => setFormat(f.id)}
                className={`w-full text-left p-2.5 border clip-corner transition-all flex items-center gap-2.5 ${
                  active ? 'border-[#3fb950] bg-[#3fb950]/10' : 'border-[#30363d] bg-[#0d1117] hover:border-[#3fb950]/30'
                }`}>
                <Icon size={16} className={active ? 'text-[#3fb950]' : 'text-[#8b949e]'} />
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-[#e6edf3]">{f.label}</div>
                  <div className="text-[9px] text-[#8b949e]">{f.desc}</div>
                </div>
              </button>
            );
          })}
        </div>

        {/* File name */}
        <div className="mb-3">
          <label className="text-[9px] text-[#8b949e] uppercase font-bold mb-1 block">File Name</label>
          <input value={fileName} onChange={(e) => setFileName(e.target.value)} placeholder="my-character"
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner focus:border-[#3fb950]/40" />
        </div>

        {error && <p className="text-[10px] text-[#f85149] mb-2">{error}</p>}

        <button onClick={doExport} disabled={exporting}
          className="w-full px-3 py-2.5 bg-[#3fb950] text-black text-xs font-bold clip-corner disabled:opacity-50 touch-manipulation flex items-center justify-center gap-1.5">
          {exporting ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
          {exporting ? 'Compiling...' : `Download ${format.toUpperCase()}`}
        </button>
      </div>
    </div>
  );
}

// ── Client-side PDF via jspdf ────────────────────────────────────────────────
async function renderPdf(bundle, name) {
  const { jsPDF } = await import('jspdf');
  const doc = new jsPDF();
  let y = 20;
  const c = bundle.character;
  const camp = bundle.campaign;

  doc.setFontSize(18);
  doc.text(c?.name || camp?.name || 'D&D Export', 20, y); y += 10;

  if (c) {
    doc.setFontSize(11);
    doc.text(`${c.species || ''} ${c.klass || ''} - Level ${c.level} - ${c.alignment || ''}`, 20, y); y += 8;
    doc.setFontSize(10);
    doc.text(`HP: ${c.hp_current}/${c.hp_max}  AC: ${c.armor_class}  PP: ${c.passive_perception}  Prof: +${c.proficiency_bonus}`, 20, y); y += 6;
    doc.text(`XP: ${c.xp}  Gold: ${c.gold}`, 20, y); y += 10;

    const as = c.ability_scores || {};
    doc.setFontSize(11); doc.text('Ability Scores', 20, y); y += 6;
    doc.setFontSize(9);
    doc.text(`STR ${as.strength||10}   DEX ${as.dexterity||10}   CON ${as.constitution||10}`, 20, y); y += 5;
    doc.text(`INT ${as.intelligence||10}   WIS ${as.wisdom||10}   CHA ${as.charisma||10}`, 20, y); y += 9;

    if (c.abilities?.length) {
      doc.setFontSize(11); doc.text('Abilities & Traits', 20, y); y += 6;
      doc.setFontSize(9);
      c.abilities.forEach((a) => { if (y > 270) { doc.addPage(); y = 20; } doc.text(`- ${a}`, 20, y); y += 5; });
      y += 4;
    }
    if (c.inventory?.length) {
      doc.setFontSize(11); doc.text('Inventory', 20, y); y += 6;
      doc.setFontSize(9);
      c.inventory.forEach((it) => { if (y > 270) { doc.addPage(); y = 20; } doc.text(`- ${it.name||it}${it.quantity>1?` x${it.quantity}`:''}`, 20, y); y += 5; });
      y += 4;
    }
    if (c.spellbook?.length) {
      doc.setFontSize(11); doc.text('Spellbook', 20, y); y += 6;
      doc.setFontSize(9);
      doc.text(c.spellbook.join(', '), 20, y); y += 9;
    }
    if (c.notes?.length) {
      doc.setFontSize(11); doc.text('Notes', 20, y); y += 6;
      doc.setFontSize(9);
      c.notes.forEach((n) => { if (y > 270) { doc.addPage(); y = 20; } doc.text(`- ${n}`, 20, y); y += 5; });
    }
  }

  if (camp) {
    if (y > 250) { doc.addPage(); y = 20; }
    y += 6;
    doc.setFontSize(14); doc.text(`Campaign: ${camp.name}`, 20, y); y += 8;
    doc.setFontSize(10);
    doc.text(`${camp.setting} - ${camp.rules_edition} - ${camp.tone}`, 20, y); y += 6;
    if (camp.summary) {
      const lines = doc.splitTextToSize(camp.summary, 170);
      doc.setFontSize(9); doc.text(lines, 20, y); y += lines.length * 5 + 4;
    }
  }

  if (bundle.customSpells?.length) {
    if (y > 250) { doc.addPage(); y = 20; }
    doc.setFontSize(14); doc.text('Custom Spells', 20, y); y += 8;
    doc.setFontSize(9);
    bundle.customSpells.forEach((s) => {
      if (y > 270) { doc.addPage(); y = 20; }
      doc.text(`${s.name} (${s.level===0?'Cantrip':'L'+s.level} ${s.school})`, 20, y); y += 5;
      const lines = doc.splitTextToSize(s.description || '', 170);
      doc.text(lines, 20, y); y += lines.length * 5 + 4;
    });
  }

  doc.setFontSize(8); doc.setTextColor(120);
  doc.text(`Exported ${new Date().toLocaleString()} - Merlin D&D`, 20, 285);
  doc.save(`${name}.pdf`);
}