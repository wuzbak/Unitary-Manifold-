/**
 * EliteVillainsMonsters — Elite Villains & Monsters Commons block.
 * Renders legendary and high-CR monsters with full stat blocks and lore.
 */
import EliteBlock from '@/components/dnd/commons/EliteBlock';

export default function EliteVillainsMonsters() {
  return <EliteBlock variant="villains" />;
}