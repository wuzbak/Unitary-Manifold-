/**
 * SandboxArena — A self-contained combat test suite.
 *
 * Pick a challenger (a solo character or a quick-build dummy) and a monster,
 * roll initiative, make attack rolls, apply damage, and track the outcome.
 * Fully local state — no persistence. A "FULL TEST AND USE SUITE" for DMs and
 * players to experiment with mechanics, stats, and rolls.
 */
import { useState, useMemo, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Swords, RefreshCw, Dice5, Heart, Shield, Zap, Trophy, Skull } from 'lucide-react';
import { MONSTERS, getMonster } from '@/lib/dnd/compendium';
import { rollExpression, addToHistory } from '@/lib/dnd/diceEngine';
import { abilityModifier } from '@/lib/dnd/rules';
import { rollAllInitiative, damageCombatant } from '@/lib/dnd/combatEngine';

const DEFAULT_DUMMY = {
  name: 'Test Dummy',
  level: 1,
  klass: 'fighter',
  hp_max: 12, hp_current: 12,
  armor_class: 14,
  ability_scores: { strength: 16, dexterity: 12, constitution: 14, intelligence: 10, wisdom: 10, charisma: 10 },
  proficiency_bonus: 2,
};

export default function SandboxArena() {
  const [characters, setCharacters] = useState([]);
  const [challenger, setChallenger] = useState(DEFAULT_DUMMY);
  const [monsterSlug, setMonsterSlug] = useState('goblin');
  const [combatants, setCombatants] = useState([]);
  const [round, setRound] = useState(1);
  const [activeIdx, setActiveIdx] = useState(0);
  const [log, setLog] = useState([]);
  const [started, setStarted] = useState(false);

  const loadChars = useCallback(async () => {
    try {
      const list = await base44.entities.DnDCharacter.filter({ solo: true }, '-created_date', 20);
      setCharacters(list || []);
    } catch (e) { /* ignore */ }
  }, []);
  useEffect(() => { loadChars(); }, [loadChars]);

  const monster = getMonster(monsterSlug);

  const addLog = (entry) => setLog((prev) => [{ ...entry, id: `log-${Date.now()}-${Math.random()}`, ts: Date.now() }, ...prev].slice(0, 40));

  const startCombat = () => {
    const m = getMonster(monsterSlug);
    if (!m || !challenger) return;
    const mComb = {
      id: 'arena-monster', name: m.name, initiative: 0,
      hp_current: m.hp, hp_max: m.hp, ac: m.ac,
      conditions_json: '[]', type: 'monster', ref_id: m.slug, sort_order: 0, active_turn: false,
      attackBonus: m.attack_bonus || 4, damageDice: m.damage_dice || '1d6+2',
    };
    const cComb = {
      id: 'arena-challenger', name: challenger.name, initiative: 0,
      hp_current: challenger.hp_current || challenger.hp_max, hp_max: challenger.hp_max,
      ac: challenger.armor_class, conditions_json: '[]', type: 'character', sort_order: 0, active_turn: false,
      attackBonus: (challenger.proficiency_bonus || 2) + abilityModifier((challenger.ability_scores?.strength) || 10),
      damageDice: '1d8+3',
    };
    const rolled = rollAllInitiative([mComb, cComb]);
    setCombatants(rolled); setRound(1); setActiveIdx(0); setStarted(true); setLog([]);
    addLog({ type: 'info', text: `Combat started: ${challenger.name} vs ${m.name}` });
    addLog({ type: 'init', text: `Initiative — ${rolled[0].name}: ${rolled[0].initiative}, ${rolled[1].name}: ${rolled[1].initiative}` });
  };

  const active = combatants[activeIdx];

  const makeAttack = (attacker, defender) => {
    const atkRoll = rollExpression(`1d20+${attacker.attackBonus || 0}`, { label: `${attacker.name} attack` });
    addToHistory(atkRoll);
    const hit = atkRoll.total >= (defender.ac || 10);
    addLog({
      type: 'attack',
      text: `${attacker.name} attacks ${defender.name}: ${atkRoll.expr} = ${atkRoll.total}${atkRoll.crit ? ' (CRIT!)' : atkRoll.fumble ? ' (FUMBLE!)' : ''} vs AC ${defender.ac} → ${hit || atkRoll.crit ? 'HIT' : 'MISS'}`,
    });
    if (atkRoll.fumble) return;
    if (!hit && !atkRoll.crit) return;
    // Damage
    const dmgExpr = attacker.damageDice || '1d6';
    const dmgRoll = rollExpression(dmgExpr, { label: `${attacker.name} damage` });
    addToHistory(dmgRoll);
    let dmg = dmgRoll.total;
    if (atkRoll.crit) dmg = dmg * 2;
    addLog({ type: 'damage', text: `${attacker.name} deals ${dmg} damage to ${defender.name} (${dmgRoll.expr}${atkRoll.crit ? ' ×2 crit' : ''})` });
    setCombatants((prev) => prev.map((c) => {
      if (c.id === defender.id) {
        const { hp_current } = damageCombatant(c, dmg);
        const dead = hp_current <= 0;
        if (dead) addLog({ type: 'death', text: `${defender.name} is defeated!` });
        return { ...c, hp_current };
      }
      return c;
    }));
  };

  const nextTurn = () => {
    const next = activeIdx + 1;
    if (next >= combatants.length) { setActiveIdx(0); setRound((r) => r + 1); }
    else setActiveIdx(next);
  };

  const reset = () => { setCombatants([]); setStarted(false); setLog([]); setRound(1); setActiveIdx(0); };

  const alive = combatants.filter((c) => c.hp_current > 0);
  const combatOver = started && alive.length <= 1;

  return (
    <div className="space-y-3">
      <div className="glass-panel clip-corner p-3">
        <p className="text-[10px] text-[#8b949e]">
          <span className="text-[#FF9F00] font-bold">Sandbox Combat Arena</span> — Pick a challenger and a monster, then test attack rolls, damage, and HP tracking. Fully local — no records saved. A safe space to learn the mechanics.
        </p>
      </div>

      {!started ? (
        <div className="space-y-3">
          {/* Challenger select */}
          <div className="glass-strong clip-corner p-3 space-y-2">
            <span className="text-[10px] font-bold font-heading text-[#4dd0e1]">CHALLENGER</span>
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => setChallenger(DEFAULT_DUMMY)}
                className={`px-2.5 py-1.5 text-[10px] font-bold border clip-corner touch-manipulation ${challenger === DEFAULT_DUMMY ? 'border-[#4dd0e1] bg-[#4dd0e1]/15 text-[#4dd0e1]' : 'border-[#30363d] text-[#8b949e]'}`}
              >
                Test Dummy (Lv 1 Fighter)
              </button>
              {characters.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setChallenger(c)}
                  className={`px-2.5 py-1.5 text-[10px] font-bold border clip-corner touch-manipulation ${challenger?.id === c.id ? 'border-[#4dd0e1] bg-[#4dd0e1]/15 text-[#4dd0e1]' : 'border-[#30363d] text-[#8b949e]'}`}
                >
                  {c.name} (Lv {c.level} {c.klass})
                </button>
              ))}
            </div>
            {challenger && (
              <div className="grid grid-cols-4 gap-2 text-[10px]">
                <Stat icon={Heart} label="HP" value={`${challenger.hp_current ?? challenger.hp_max}/${challenger.hp_max}`} color="#f85149" />
                <Stat icon={Shield} label="AC" value={challenger.armor_class} color="#4dd0e1" />
                <Stat icon={Zap} label="Atk" value={`+${(challenger.proficiency_bonus || 2) + abilityModifier((challenger.ability_scores?.strength) || 10)}`} color="#FF9F00" />
                <Stat icon={Dice5} label="Dmg" value="1d8+3" color="#d29922" />
              </div>
            )}
          </div>

          {/* Monster select */}
          <div className="glass-strong clip-corner p-3 space-y-2">
            <span className="text-[10px] font-bold font-heading text-[#f85149]">OPPONENT</span>
            <select
              value={monsterSlug}
              onChange={(e) => setMonsterSlug(e.target.value)}
              className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner"
            >
              {MONSTERS.map((m) => (
                <option key={m.slug} value={m.slug}>{m.name} (CR {m.cr} · {m.xp}xp)</option>
              ))}
            </select>
            {monster && (
              <div className="grid grid-cols-4 gap-2 text-[10px]">
                <Stat icon={Heart} label="HP" value={`${monster.hp}`} color="#f85149" />
                <Stat icon={Shield} label="AC" value={monster.ac} color="#4dd0e1" />
                <Stat icon={Zap} label="Atk" value={`+${monster.attack_bonus || 4}`} color="#FF9F00" />
                <Stat icon={Dice5} label="Dmg" value={monster.damage_dice || '1d6+2'} color="#d29922" />
              </div>
            )}
          </div>

          <button
            onClick={startCombat}
            disabled={!challenger || !monster}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-[#FF9F00] text-black text-xs font-bold clip-corner disabled:opacity-50 touch-manipulation"
          >
            <Swords size={14} /> Start Arena Combat
          </button>
        </div>
      ) : (
        <>
          {/* Combat status */}
          <div className="glass-strong clip-corner p-2.5 flex justify-between items-center">
            <span className="text-sm font-bold text-[#FF9F00] font-heading">Round {round}</span>
            {combatOver ? (
              <button onClick={reset} className="flex items-center gap-1.5 px-3 py-1.5 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner touch-manipulation">
                <RefreshCw size={11} /> New Arena
              </button>
            ) : (
              <button onClick={nextTurn} className="px-3 py-1.5 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner touch-manipulation">
                Next Turn →
              </button>
            )}
          </div>

          {/* Combatants */}
          <div className="grid sm:grid-cols-2 gap-2">
            {combatants.map((c, i) => {
              const isActive = i === activeIdx && !combatOver;
              const hpPct = c.hp_max > 0 ? (c.hp_current / c.hp_max) * 100 : 0;
              const hpColor = hpPct > 50 ? '#3fb950' : hpPct > 25 ? '#d29922' : '#f85149';
              const dead = c.hp_current <= 0;
              return (
                <div
                  key={c.id}
                  className={`p-3 border clip-corner ${isActive ? 'border-[#FF9F00] bg-[#FF9F00]/10' : 'border-[#30363d] bg-[#0d1117]'} ${dead ? 'opacity-50' : ''}`}
                >
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-bold text-[#e6edf3]">{c.name}</span>
                    {dead ? (
                      <Skull size={14} className="text-[#f85149]" />
                    ) : isActive ? (
                      <span className="text-[9px] text-[#FF9F00] font-bold animate-pulse">ACTIVE</span>
                    ) : null}
                  </div>
                  <div className="text-[10px] text-[#8b949e] mt-0.5">Init {c.initiative} · AC {c.ac}</div>
                  <div className="flex items-center gap-1.5 mt-1">
                    <Heart size={11} className="text-[#f85149]" />
                    <span className="text-xs font-bold" style={{ color: hpColor }}>{c.hp_current}/{c.hp_max}</span>
                  </div>
                  <div className="h-1.5 bg-[#0d1117] mt-1 clip-corner overflow-hidden">
                    <div className="h-full transition-all" style={{ width: `${Math.max(0, hpPct)}%`, background: hpColor }} />
                  </div>
                  {isActive && !dead && (
                    <button
                      onClick={() => {
                        const defender = combatants.find((x) => x.id !== c.id);
                        if (defender) makeAttack(c, defender);
                      }}
                      className="mt-2 w-full flex items-center justify-center gap-1.5 px-2 py-1.5 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner touch-manipulation"
                    >
                      <Swords size={11} /> Attack {combatants.find((x) => x.id !== c.id)?.name}
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {/* Combat over banner */}
          {combatOver && alive.length === 1 && (
            <div className="glass-strong clip-corner p-3 text-center" style={{ borderColor: 'rgba(255,159,0,0.4)' }}>
              <Trophy size={24} className="mx-auto text-[#FF9F00] mb-1" />
              <span className="text-sm font-bold text-[#FF9F00]">{alive[0].name} wins!</span>
            </div>
          )}

          {/* Combat log */}
          <div className="glass-panel clip-corner p-2.5">
            <span className="text-[10px] font-bold font-heading text-[#8b949e]">COMBAT LOG</span>
            <div className="space-y-1 mt-1.5 max-h-40 overflow-y-auto">
              {log.map((l) => (
                <div key={l.id} className="text-[10px] text-[#c9d1d9] font-mono leading-relaxed">
                  <span className="text-[#484f58]">›</span> {l.text}
                </div>
              ))}
              {log.length === 0 && <p className="text-[10px] text-[#484f58]">No actions yet.</p>}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function Stat({ icon: Icon, label, value, color }) {
  return (
    <div className="bg-[#0d1117] border border-[#30363d] p-1.5 clip-corner flex items-center gap-1.5">
      <Icon size={11} style={{ color }} />
      <div>
        <div className="text-[8px] text-[#8b949e] uppercase">{label}</div>
        <div className="text-[11px] font-bold" style={{ color }}>{value}</div>
      </div>
    </div>
  );
}