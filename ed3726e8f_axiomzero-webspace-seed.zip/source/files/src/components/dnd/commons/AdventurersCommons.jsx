/**
 * AdventurersCommons — Browse-only dashboard + Sandbox combat arena.
 *
 * A top-level "DEMO / LIBRARY" surface with tiles to browse shops, monsters,
 * items, spells, characters, classes, roll dice, and read the rules — all in
 * read-only mode — plus a full Sandbox combat arena for testing mechanics.
 */
import { useState } from 'react';
import { Store, Swords, Package, Sparkles, Users, BookOpen, Dices, ScrollText, FlaskConical, ArrowLeft, Skull, Crown } from 'lucide-react';
import CompendiumBrowser from '@/components/dnd/CompendiumBrowser';
import Marketplace from '@/components/dnd/shop/Marketplace';
import HomebrewForge from '@/components/dnd/forge/HomebrewForge';
import HomebrewMarketplace from '@/components/dnd/market/Marketplace';
import CosmicDiceChamber from '@/components/dnd/dice/CosmicDiceChamber';
import CosmicDiceModal from '@/components/dnd/dice/CosmicDiceModal';
import SandboxArena from '@/components/dnd/commons/SandboxArena';
import RulesCodex from '@/components/dnd/commons/RulesCodex';
import EliteVillainsMonsters from '@/components/dnd/commons/EliteVillainsMonsters';
import EliteHeroesNpcs from '@/components/dnd/commons/EliteHeroesNpcs';

const TILES = [
  { id: 'shops', label: 'Shops', icon: Store, desc: 'Browse merchant inventories & the Unitary Manifold Shop', accent: '#bc8cff' },
  { id: 'monsters', label: 'Monsters', icon: Swords, desc: 'Full SRD monster stat blocks', accent: '#f85149' },
  { id: 'elite-villains', label: 'Elite Villains & Monsters', icon: Skull, desc: 'Legendary high-CR villains & boss monsters', accent: '#f85149' },
  { id: 'elite-heroes', label: 'Elite Heroes & NPCs', icon: Crown, desc: 'Notable heroes & memorable NPCs', accent: '#FF9F00' },
  { id: 'items', label: 'Items', icon: Package, desc: 'Weapons, armor, wondrous items', accent: '#3fb950' },
  { id: 'spells', label: 'Spells', icon: Sparkles, desc: 'Cantrips through 9th level', accent: '#4dd0e1' },
  { id: 'classes', label: 'Classes', icon: Users, desc: '13 core classes & species', accent: '#FF9F00' },
  { id: 'dice', label: 'Roll Dice', icon: Dices, desc: 'Cosmic 3D dice roller', accent: '#a371f7' },
  { id: 'rules', label: 'Read the Rules', icon: ScrollText, desc: '5e/5.5e mechanics reference', accent: '#d29922' },
  { id: 'sandbox', label: 'Sandbox Arena', icon: FlaskConical, desc: 'Test combat mechanics — full suite', accent: '#FF9F00' },
  { id: 'forge', label: 'Homebrew Forge', icon: FlaskConical, desc: 'Create custom monsters, spells, items & publish packs', accent: '#FF9F00' },
  { id: 'market', label: 'Marketplace', icon: Store, desc: 'Browse & install community homebrew packs', accent: '#bc8cff' },
];

export default function AdventurersCommons() {
  const [view, setView] = useState(null);
  const [diceModalOpen, setDiceModalOpen] = useState(false);

  if (view) {
    const tile = TILES.find((t) => t.id === view);
    return (
      <div className="space-y-3">
        <button onClick={() => setView(null)} className="flex items-center gap-1.5 text-[10px] text-[#8b949e] hover:text-[#FF9F00] touch-manipulation">
          <ArrowLeft size={12} /> Back to Commons
        </button>
        <div className="flex items-center gap-2 mb-1">
          <tile.icon size={16} style={{ color: tile.accent }} />
          <h3 className="text-sm font-bold font-heading" style={{ color: tile.accent }}>{tile.label}</h3>
        </div>
        {view === 'shops' && <Marketplace mode="browse" />}
        {view === 'monsters' && <CompendiumBrowser initialTab="monsters" />}
        {view === 'elite-villains' && <EliteVillainsMonsters />}
        {view === 'elite-heroes' && <EliteHeroesNpcs />}
        {view === 'items' && <CompendiumBrowser initialTab="items" />}
        {view === 'spells' && <CompendiumBrowser initialTab="spells" />}
        {view === 'classes' && <CompendiumBrowser initialTab="classes" />}
        {view === 'dice' && (
          <div className="space-y-3">
            <CosmicDiceChamber onOpenModal={() => setDiceModalOpen(true)} mode="player" accent="#a371f7" />
            <div className="glass-panel clip-corner p-3">
              <p className="text-[10px] text-[#8b949e]">
                <span className="text-[#a371f7] font-bold">Cosmic Dice</span> — Roll through the toroidal universe. Open the full modal for advantage/disadvantage, DC checks, and roll history.
              </p>
            </div>
          </div>
        )}
        {view === 'rules' && <RulesCodex />}
        {view === 'sandbox' && <SandboxArena />}
        {view === 'forge' && <HomebrewForge campaignId="" />}
        {view === 'market' && <HomebrewMarketplace />}
        <CosmicDiceModal isOpen={diceModalOpen} onClose={() => setDiceModalOpen(false)} mode="player" accent="#a371f7" />
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="glass-panel clip-corner p-3">
        <p className="text-[10px] text-[#8b949e]">
          <span className="text-[#FF9F00] font-bold">Adventurer's Commons</span> — A browse-only library to explore shops, monsters, items, spells, classes, dice, and rules. No campaign required. Open the <span className="text-[#FF9F00] font-bold">Sandbox Arena</span> to test combat mechanics in a full hands-on suite.
        </p>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
        {TILES.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setView(t.id)}
              className="text-left p-3 border border-[#30363d] bg-[#0d1117] clip-corner hover:border-[#FF9F00]/40 transition-all touch-manipulation group"
            >
              <Icon size={22} style={{ color: t.accent }} className="mb-2 group-hover:scale-110 transition-transform" />
              <div className="text-xs font-bold text-[#e6edf3]">{t.label}</div>
              <div className="text-[9px] text-[#8b949e] mt-0.5 leading-tight">{t.desc}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}