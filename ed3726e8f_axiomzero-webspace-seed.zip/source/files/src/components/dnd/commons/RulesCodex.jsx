/**
 * RulesCodex — Shell for the expanded "Read the Rules" codex.
 *
 * Tabbed nav (Combat / Conditions / Spellcasting) with a global search field
 * that filters cards across the active domain. Delegates rendering to the
 * domain components.
 */
import { useState } from 'react';
import { Swords, HeartPulse, Sparkles, Search } from 'lucide-react';
import CombatRules from './rules/CombatRules';
import ConditionsCodex from './rules/ConditionsCodex';
import SpellcastingRules from './rules/SpellcastingRules';

const TABS = [
  { id: 'combat', label: 'Combat & Action Economy', icon: Swords, accent: '#FF9F00' },
  { id: 'conditions', label: 'Conditions & Status', icon: HeartPulse, accent: '#f85149' },
  { id: 'spellcasting', label: 'Spellcasting & Slots', icon: Sparkles, accent: '#4dd0e1' },
];

export default function RulesCodex() {
  const [tab, setTab] = useState('combat');
  const [search, setSearch] = useState('');

  const active = TABS.find((t) => t.id === tab);

  return (
    <div className="space-y-3">
      {/* Header strip */}
      <div className="glass-strong clip-corner p-3 border-l-2" style={{ borderColor: `${active.accent}80` }}>
        <div className="flex items-center gap-2 mb-1">
          <active.icon size={16} style={{ color: active.accent }} />
          <span className="text-xs font-bold font-heading" style={{ color: active.accent }}>Rules Codex — 5e / 5.5e (2024)</span>
        </div>
        <p className="text-[10px] text-[#8b949e] leading-relaxed">
          A deterministic rules reference with hands-on calculators. Read the rule, then try the math.
          All computation runs locally through the platform's rules engine — no LLM, no guesswork.
        </p>
      </div>

      {/* Tab nav + search */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="flex gap-1.5 flex-1">
          {TABS.map((t) => {
            const Icon = t.icon;
            const isActive = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => { setTab(t.id); setSearch(''); }}
                className={`flex items-center gap-1.5 px-3 py-2 text-[10px] font-bold border clip-corner transition-all touch-manipulation whitespace-nowrap ${
                  isActive ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'
                }`}
                style={isActive ? { background: t.accent } : {}}
              >
                <Icon size={12} /> <span className="hidden sm:inline">{t.label}</span>
                <span className="sm:hidden">{t.label.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>
        <div className="relative flex items-center gap-1.5 glass-panel clip-corner px-2 py-1.5 sm:w-56">
          <Search size={12} className="text-[#484f58] shrink-0" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search rules…"
            className="bg-transparent text-[11px] text-[#e6edf3] flex-1 min-w-0 focus:outline-none placeholder:text-[#484f58]"
          />
          {search && (
            <button onClick={() => setSearch('')} className="text-[#484f58] hover:text-[#e6edf3] shrink-0 text-xs">✕</button>
          )}
        </div>
      </div>

      {/* Active domain */}
      {tab === 'combat' && <CombatRules search={search} />}
      {tab === 'conditions' && <ConditionsCodex search={search} />}
      {tab === 'spellcasting' && <SpellcastingRules search={search} />}
    </div>
  );
}