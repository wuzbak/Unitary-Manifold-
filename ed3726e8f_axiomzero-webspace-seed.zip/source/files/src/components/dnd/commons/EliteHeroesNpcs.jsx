/**
 * EliteHeroesNpcs — Elite Heroes & NPCs Commons block.
 * Renders notable heroes and NPCs with full stat blocks and personality.
 */
import EliteBlock from '@/components/dnd/commons/EliteBlock';

export default function EliteHeroesNpcs() {
  return <EliteBlock variant="heroes" />;
}