/**
 * EliteBlock — Shared component for the two Elite Commons blocks.
 *
 * variant='villains'  → Elite Villains & Monsters (legendary/high-CR monsters)
 * variant='heroes'    → Elite Heroes & NPCs (notable heroes and NPCs)
 *
 * Seeds from the SRD compendium (villains only) and any persisted DnDCustomMonster
 * entries with the matching role. "Compile more with Merlin" calls dndCompileEntry
 * to retrieve additional entries on demand, which are persisted as DnDCustomMonster
 * records and merged into the display.
 *
 * Every entry shows a Lucide category icon (by monster type / entity class).
 */
import { useState, useEffect, useCallback } from 'react';
import { Sparkles, Loader2, Search, Skull, Crown } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { MONSTERS } from '@/lib/dnd/compendium';
import { customMonsterToCompendium } from '@/lib/dnd/customCompendium';
import StatBlock from '@/components/dnd/StatBlock';
import { getMonsterIcon, getEntityClassIcon } from '@/lib/dnd/entityIcons';

const CONFIG = {
  villains: {
    label: 'Elite Villains & Monsters',
    accent: '#f85149',
    icon: Skull,
    compileCategory: 'villains',
    role: 'villain',
    seed: () => MONSTERS.filter((m) => m.cr >= 10).sort((a, b) => b.cr - a.cr),
    entityIcon: (m) => getMonsterIcon(m.type),
    emptyMsg: 'No elite villains yet. Compile legendary monsters with Merlin.',
  },
  heroes: {
    label: 'Elite Heroes & NPCs',
    accent: '#FF9F00',
    icon: Crown,
    compileCategory: 'heroes',
    role: 'hero',
    seed: () => [],
    entityIcon: (m) => getEntityClassIcon(m.role === 'npc' ? 'npc' : 'hero'),
    emptyMsg: 'No elite heroes yet. Compile notable heroes and NPCs with Merlin.',
  },
};

export default function EliteBlock({ variant = 'villains' }) {
  const cfg = CONFIG[variant];
  const [entries, setEntries] = useState([]);
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState('');
  const [compiling, setCompiling] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const custom = await base44.entities.DnDCustomMonster.list('-created_date', 200);
      const roleFiltered = (custom || [])
        .map(customMonsterToCompendium)
        .filter((m) => m.role === cfg.role || (variant === 'heroes' && (m.role === 'hero' || m.role === 'npc')));
      const seeded = cfg.seed();
      // Merge: custom first, then seed (dedupe by slug)
      const seen = new Set(roleFiltered.map((m) => m.slug));
      const merged = [...roleFiltered, ...seeded.filter((m) => !seen.has(m.slug))];
      setEntries(merged);
      if (merged.length > 0 && !selected) setSelected(merged[0]);
    } catch (e) {
      console.error('Load elite block:', e);
      setEntries(cfg.seed());
    }
    setLoading(false);
  }, [cfg, variant]);

  useEffect(() => { load(); }, [load]);

  const compileMore = async () => {
    setCompiling(true);
    try {
      const existingSlugs = entries.map((m) => m.slug);
      const response = await base44.functions.invoke('dndCompileEntry', {
        category: cfg.compileCategory,
        count: 5,
        existingSlugs,
      });
      const data = response.data || response;
      if (data.error) throw new Error(data.error);
      const newEntries = data.entries || [];
      // Persist as DnDCustomMonster records
      for (const e of newEntries) {
        await base44.entities.DnDCustomMonster.create({
          name: e.name,
          slug: e.slug,
          cr: e.cr ?? e.level ?? 0,
          xp: e.xp || 0,
          hp: e.hp ?? e.hp_max ?? 1,
          ac: e.ac ?? e.armor_class ?? 10,
          size: e.size || 'Medium',
          type: e.type || 'Humanoid',
          environment: e.environment || 'any',
          role: cfg.role,
          signature_abilities_json: JSON.stringify(e.signature_abilities || e.abilities || []),
          description: e.description || '',
        });
      }
      await load();
    } catch (e) {
      alert('Compile failed: ' + e.message);
    }
    setCompiling(false);
  };

  const filtered = entries.filter((m) => !search.trim() || m.name.toLowerCase().includes(search.toLowerCase()));
  const Icon = cfg.icon;

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="glass-strong clip-corner p-3 border-l-2" style={{ borderLeftColor: cfg.accent }}>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <Icon size={18} style={{ color: cfg.accent }} />
            <div>
              <h3 className="text-sm font-bold font-heading" style={{ color: cfg.accent }}>{cfg.label}</h3>
              <p className="text-[9px] text-[#8b949e]">
                {variant === 'villains' ? 'Legendary & high-CR monsters with full stat blocks and lore.' : 'Notable heroes and NPCs with full stat blocks and personality.'}
              </p>
            </div>
          </div>
          <button onClick={compileMore} disabled={compiling}
            className="flex items-center gap-1.5 px-3 py-1.5 border clip-corner text-[10px] font-bold touch-manipulation disabled:opacity-50 transition-all"
            style={{ borderColor: `${cfg.accent}66`, color: cfg.accent, background: `${cfg.accent}15` }}>
            {compiling ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
            {compiling ? 'Compiling...' : 'Compile more with Merlin'}
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="flex items-center gap-2 glass-panel clip-corner px-3 py-2">
        <Search size={14} className="text-[#484f58]" />
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={`Search ${cfg.label.toLowerCase()}...`}
          className="flex-1 bg-transparent text-xs text-[#e6edf3] focus:outline-none placeholder:text-[#484f58]" />
        <span className="text-[9px] text-[#484f58]">{filtered.length} entries</span>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="w-6 h-6 border-2 border-[#30363d] border-t-[#FF9F00] rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="glass-panel clip-corner p-6 text-center">
          <Icon size={28} className="mx-auto mb-2" style={{ color: cfg.accent, opacity: 0.5 }} />
          <p className="text-[10px] text-[#8b949e]">{cfg.emptyMsg}</p>
        </div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-3">
          {/* List */}
          <div className="space-y-1.5 max-h-[60vh] overflow-y-auto pr-1">
            {filtered.map((m) => {
              const EntryIcon = cfg.entityIcon(m);
              const isActive = selected?.slug === m.slug;
              return (
                <button key={m.slug} onClick={() => setSelected(m)}
                  className={`w-full text-left p-2 border clip-corner transition-all flex items-center gap-2 ${
                    isActive ? 'border-[#FF9F00] bg-[#FF9F00]/10' : 'border-[#30363d] bg-[#0d1117] hover:border-[#FF9F00]/30'
                  }`}>
                  <EntryIcon size={16} className="shrink-0" style={{ color: cfg.accent }} />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-[#e6edf3] truncate">{m.name}</span>
                      <span className="text-[9px] font-bold shrink-0 ml-1" style={{ color: cfg.accent }}>
                        {variant === 'villains' ? `CR ${m.cr}` : `L${m.cr}`}
                      </span>
                    </div>
                    <div className="text-[9px] text-[#8b949e] truncate">{m.size} {m.type}{m.environment && m.environment !== 'any' ? ` · ${m.environment}` : ''}</div>
                  </div>
                </button>
              );
            })}
          </div>
          {/* Detail */}
          <div className="max-h-[60vh] overflow-y-auto">
            {selected && <StatBlock monster={selected} />}
          </div>
        </div>
      )}
    </div>
  );
}