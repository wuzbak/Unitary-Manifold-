/**
 * SpellcastingRules — Spellcasting reference cards + live spell-slot table calculator.
 *
 * Reference cards on spell slots, concentration, casting times, ritual casting.
 * Calculator: pick class + level → renders the exact slot progression from
 * spellSlotsForClass(), plus spell save DC and spell attack bonus for that
 * class/level (with an ability-score input).
 */
import { useState } from 'react';
import { ChevronRight, Calculator, Sparkles, Clock, Brain, Flame } from 'lucide-react';
import {
  spellSlotsForClass, abilityModifier, proficiencyBonus, spellSaveDC, spellAttackBonus,
  CLASS_SPELLCASTING_ABILITY,
} from '@/lib/dnd/rules';
import { CLASSES } from '@/lib/dnd/compendium';

const REFERENCE_CARDS = [
  {
    id: 'slots',
    title: 'Spell Slots',
    accent: '#4dd0e1',
    icon: Sparkles,
    body: [
      'Spell slots are the fuel for casting leveled spells. Each spell has a level (1–9), and casting it consumes a slot of that level or higher.',
      '• You have a fixed number of slots per level, determined by your class and level (see the calculator below).',
      '• Casting a spell at a higher level than its own is "upcasting" — many spells have enhanced effects when upcast.',
      '• Cantrips do not consume slots; they are always available.',
      '• All expended slots are regained on a Long Rest (warlocks regain theirs on a Short or Long Rest).',
    ],
  },
  {
    id: 'concentration',
    title: 'Concentration',
    accent: '#a371f7',
    icon: Brain,
    body: [
      'Some spells require Concentration to keep active. You can only concentrate on one spell at a time.',
      '• Casting another concentration spell ends the previous one.',
      '• Taking damage forces a Constitution saving throw (DC 10 or half the damage, whichever is higher) to maintain concentration.',
      '• Being incapacitated or killed ends concentration immediately.',
      '• Environmental factors (rough seas, a galloping mount) may prompt Constitution saves at the DM\'s discretion.',
    ],
  },
  {
    id: 'casting-times',
    title: 'Casting Times',
    accent: '#FF9F00',
    icon: Clock,
    body: [
      'Most spells take 1 Action to cast. Other casting times:',
      '• 1 Bonus Action — swift spells; if you cast one, you cannot cast a leveled spell with your action that turn.',
      '• 1 Reaction — cast in response to a trigger (e.g., Shield, Counterspell, Feather Fall).',
      '• 1 Minute — 10 rounds of combat; often cast outside combat.',
      '• 1 Hour / 10 Minutes — ritual-scale spells, usually cast during a short or long rest.',
    ],
  },
  {
    id: 'ritual',
    title: 'Ritual Casting',
    accent: '#3fb950',
    icon: Flame,
    body: [
      'Spells with the "ritual" tag can be cast without expending a spell slot — but only if you have the Ritual Casting feature (or a class feature like the wizard\'s).',
      '• The casting time becomes 10 minutes longer than normal.',
      '• You must have the spell prepared or in your spellbook (as applicable).',
      '• The spell must be cast at its base level — no upcasting via ritual.',
      '• Classes with ritual casting: Wizard (from spellbook), Cleric, Druid, Bard (at higher levels), and others via features.',
    ],
  },
];

const CASTER_CLASSES = CLASSES.filter((c) => c.spellcasting).map((c) => ({ slug: c.slug, name: c.name, ability: c.spellcasting_ability }));

export default function SpellcastingRules({ search }) {
  const [expanded, setExpanded] = useState(new Set(['slots']));

  const filtered = search.trim()
    ? REFERENCE_CARDS.filter((c) => {
        const q = search.toLowerCase();
        return c.title.toLowerCase().includes(q) || c.body.some((b) => b.toLowerCase().includes(q));
      })
    : REFERENCE_CARDS;

  const toggle = (id) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="grid lg:grid-cols-2 gap-3 items-start">
      {/* Reference cards */}
      <div className="space-y-1.5">
        {filtered.map((card) => {
          const Icon = card.icon;
          const isOpen = expanded.has(card.id);
          return (
            <div key={card.id} className="border border-[#30363d] clip-corner overflow-hidden">
              <button onClick={() => toggle(card.id)}
                className="w-full flex items-center gap-2 px-3 py-2.5 bg-[#0d1117] hover:bg-[#161b22] transition-colors touch-manipulation">
                <Icon size={12} style={{ color: card.accent }} className="shrink-0" />
                <span className="text-[11px] font-bold text-[#e6edf3] text-left flex-1">{card.title}</span>
                <ChevronRight size={14} className={`text-[#484f58] shrink-0 transition-transform ${isOpen ? 'rotate-90' : ''}`} />
              </button>
              {isOpen && (
                <div className="p-3 space-y-1.5 fade-in bg-[#0B0F13]">
                  {card.body.map((line, i) => (
                    <p key={i} className="text-[10px] text-[#c9d1d9] leading-relaxed">{line}</p>
                  ))}
                </div>
              )}
            </div>
          );
        })}
        {filtered.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-6">No rules match "{search}".</p>}
      </div>

      {/* Calculator */}
      <div className="lg:sticky lg:top-2">
        <SpellSlotCalculator />
      </div>
    </div>
  );
}

function SpellSlotCalculator() {
  const [klass, setKlass] = useState('wizard');
  const [level, setLevel] = useState(5);
  const [abilityScore, setAbilityScore] = useState(16);

  const slots = spellSlotsForClass(klass, level);
  const prof = proficiencyBonus(level);
  const ability = CLASS_SPELLCASTING_ABILITY[klass] || 'intelligence';
  const mod = abilityModifier(abilityScore);
  const dc = spellSaveDC(prof, abilityScore);
  const atk = spellAttackBonus(prof, abilityScore);

  const isWarlock = klass === 'warlock';

  return (
    <div className="glass-panel clip-corner p-3 border-l-2 border-[#4dd0e1]/40">
      <div className="flex items-center gap-1.5 mb-2">
        <Calculator size={12} className="text-[#4dd0e1]" />
        <span className="text-[10px] font-bold text-[#4dd0e1]">Spell Slot Table Calculator</span>
      </div>

      <div className="grid grid-cols-3 gap-2 mb-3">
        <div className="col-span-2">
          <label className="text-[8px] text-[#8b949e] uppercase font-bold block mb-0.5">Class</label>
          <select value={klass} onChange={(e) => setKlass(e.target.value)}
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner focus:border-[#4dd0e1]/50">
            {CASTER_CLASSES.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-[8px] text-[#8b949e] uppercase font-bold block mb-0.5">Level</label>
          <input type="number" min={1} max={20} value={level}
            onChange={(e) => setLevel(Math.max(1, Math.min(20, Number(e.target.value))))}
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner focus:border-[#4dd0e1]/50" />
        </div>
      </div>

      <div className="mb-3">
        <label className="text-[8px] text-[#8b949e] uppercase font-bold block mb-0.5">
          {ability.charAt(0).toUpperCase() + ability.slice(1)} Score (casting ability)
        </label>
        <input type="number" min={1} max={30} value={abilityScore}
          onChange={(e) => setAbilityScore(Math.max(1, Math.min(30, Number(e.target.value))))}
          className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner focus:border-[#4dd0e1]/50" />
      </div>

      {/* Spell save DC + attack */}
      <div className="grid grid-cols-3 gap-2 mb-3">
        <div className="bg-[#0d1117] border border-[#30363d] p-2 clip-corner text-center">
          <div className="text-[8px] text-[#8b949e] uppercase">Save DC</div>
          <div className="text-sm font-bold text-[#a371f7]">{dc}</div>
        </div>
        <div className="bg-[#0d1117] border border-[#30363d] p-2 clip-corner text-center">
          <div className="text-[8px] text-[#8b949e] uppercase">Spell Atk</div>
          <div className="text-sm font-bold text-[#3fb950]">+{atk}</div>
        </div>
        <div className="bg-[#0d1117] border border-[#30363d] p-2 clip-corner text-center">
          <div className="text-[8px] text-[#8b949e] uppercase">Prof</div>
          <div className="text-sm font-bold text-[#4dd0e1]">+{prof}</div>
        </div>
      </div>

      {/* Slot table */}
      <div>
        <span className="text-[8px] text-[#4dd0e1] uppercase font-bold block mb-1.5">
          {isWarlock ? 'Pact Magic Slots (regain on short rest)' : 'Spell Slots (regain on long rest)'}
        </span>
        {slots.length === 0 ? (
          <p className="text-[10px] text-[#484f58] py-3 text-center">
            No spell slots at level {level} for this class.
            {['paladin', 'ranger', 'artificer'].includes(klass) && ' (Half-casters gain slots at level 2.)'}
          </p>
        ) : (
          <div className="grid gap-1.5">
            {slots.map((count, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="text-[9px] text-[#8b949e] w-12 shrink-0">Level {i + 1}</span>
                <div className="flex gap-1 flex-1">
                  {Array.from({ length: count }).map((_, j) => (
                    <span key={j} className="w-3 h-3 bg-[#4dd0e1] clip-corner" style={{ boxShadow: '0 0 4px rgba(77,208,225,0.4)' }} />
                  ))}
                  {Array.from({ length: Math.max(0, 4 - count) }).map((_, j) => (
                    <span key={`e${j}`} className="w-3 h-3 border border-[#30363d] clip-corner" />
                  ))}
                </div>
                <span className="text-[9px] text-[#e6edf3] font-bold w-6 text-right shrink-0">{count}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <p className="text-[8px] text-[#484f58] mt-2 leading-relaxed">
        Slot progression computed deterministically from the rules engine. Warlock uses Pact Magic (fewer, higher-level slots that refresh on a short rest); other full casters use the standard table; half-casters (Paladin, Ranger, Artificer) progress at half rate.
      </p>
    </div>
  );
}