/**
 * CombatRules — Core combat & action economy reference cards + live calculators.
 *
 * Accordion reference cards (Action, Bonus Action, Reaction, Movement &
 * opportunity attacks, Attack rolls vs AC, Saving throws, Advantage/
 * Disadvantage, Cover, Death saves & dying) paired with three calculators:
 *   1. Ability Score → Modifier / Save DC / Passive Perception
 *   2. d20 Attack/Save roller with advantage/disadvantage + target AC/DC
 *   3. Death-save tracker (3 successes / 3 failures)
 */
import { useState } from 'react';
import { ChevronRight, Calculator, Dices, HeartPulse, Skull } from 'lucide-react';
import {
  abilityModifier, proficiencyBonus, passivePerception, spellSaveDC, rollDie,
} from '@/lib/dnd/rules';

const REFERENCE_CARDS = [
  {
    id: 'action',
    title: 'Action',
    accent: '#FF9F00',
    summary: 'One per turn — the main thing you do on your turn.',
    body: [
      'On your turn you take one Action. The most common is the Attack action, but you can also:',
      '• Attack (melee, ranged, or grapple/shove)',
      '• Dash — move up to your speed again',
      '• Disengage — move without provoking opportunity attacks',
      '• Dodge — attacks against you have disadvantage, Dexterity saves advantage',
      '• Help — grant an ally advantage on their next attack/check',
      '• Hide — make a Stealth check against passive Perception',
      '• Ready — prepare an action to trigger on a condition (uses your reaction)',
      '• Search — use your action to make a Perception or Investigation check',
      '• Use an Object — interact with an object or use a feature',
    ],
  },
  {
    id: 'bonus-action',
    title: 'Bonus Action',
    accent: '#d29922',
    summary: 'A special, faster action granted by a feature or spell.',
    body: [
      'You may take one Bonus Action on your turn — but only if a feature, spell, or class ability explicitly grants it.',
      '• Off-hand attack (Two-Weapon Fighting) when you take the Attack action',
      '• Spells with a casting time of "1 bonus action"',
      '• Class features like Cunning Action (Rogue), Rage (Barbarian), or Flurry of Blows (Monk)',
      'You choose when to take it during your turn. If a spell is cast as a bonus action, you cannot cast a leveled spell with your action on the same turn.',
    ],
  },
  {
    id: 'reaction',
    title: 'Reaction',
    accent: '#a371f7',
    summary: 'A special action taken in response to a trigger, not on your turn.',
    body: [
      'A Reaction is taken in response to a defined trigger, which can occur on your turn or someone else\'s.',
      '• Opportunity Attack — when a creature leaves your reach without disengaging',
      '• Readied Action — when your prepared condition is met',
      '• Spells like Shield, Counterspell, or Absorb Elements',
      'You get one reaction per round; it refreshes at the start of your next turn.',
    ],
  },
  {
    id: 'movement',
    title: 'Movement & Opportunity Attacks',
    accent: '#4dd0e1',
    summary: 'Your speed per turn; provoke by leaving an enemy\'s reach.',
    body: [
      'On your turn you can move up to your speed. You can break up movement across your turn (move, attack, move again).',
      '• Difficult terrain costs 1 extra foot per foot moved',
      '• Standing from prone costs half your speed',
      '• Climbing, swimming, and crawling cost 2 feet per foot (unless a feature says otherwise)',
      'Opportunity Attack: when a creature you can see leaves your reach using its movement (not a teleport, not being moved by someone else), you may use your reaction to make one melee attack against it.',
      'Disengage prevents opportunity attacks for the rest of the turn.',
    ],
  },
  {
    id: 'attack-vs-ac',
    title: 'Attack Rolls vs AC',
    accent: '#f85149',
    summary: 'd20 + modifier vs target Armor Class. Nat 20 always hits.',
    body: [
      'Make an attack roll: d20 + relevant ability modifier + proficiency bonus (if proficient) + any magic bonus.',
      '• Melee attacks use Strength; ranged attacks use Dexterity',
      '• Finesse weapons let you choose Strength or Dexterity',
      'Compare the total to the target\'s Armor Class (AC). Equal or higher hits.',
      'Natural 20: critical hit — always hits, and you roll the damage dice twice.',
      'Natural 1: always misses.',
      'On a hit, roll damage (weapon die + ability modifier). The modifier is added once, not doubled on a crit — only the dice are doubled.',
    ],
  },
  {
    id: 'saving-throws',
    title: 'Saving Throws',
    accent: '#3fb950',
    summary: 'Roll d20 + ability modifier (+ prof if proficient) vs a DC.',
    body: [
      'A saving throw is a d20 roll + an ability modifier (and proficiency bonus if you are proficient in that save) against a Difficulty Class (DC).',
      '• Strength — resist being pushed, shoved, or restrained',
      '• Dexterity — dodge area effects like a dragon\'s breath or fireball',
      '• Constitution — resist poison, disease, and maintain concentration',
      '• Intelligence, Wisdom, Charisma — resist many spells and magical effects',
      'Equal or higher succeeds. A natural 1 is not an automatic failure on a save (only attacks auto-miss on a 1), but many tables play it that way.',
    ],
  },
  {
    id: 'advantage',
    title: 'Advantage & Disadvantage',
    accent: '#bc8cff',
    summary: 'Roll 2d20, take the higher (advantage) or lower (disadvantage).',
    body: [
      'When you have advantage, roll two d20s and use the higher result. With disadvantage, use the lower.',
      '• You either have advantage, disadvantage, or neither — they do not stack. Multiple sources of advantage still mean you roll just two dice.',
      '• If you have both advantage and disadvantage, you roll one d20 (neither applies).',
      'Common sources: unseen attacker (advantage), prone target in melee (advantage), ranged attack vs prone (disadvantage), poisoned (disadvantage), restrained (disadvantage).',
    ],
  },
  {
    id: 'cover',
    title: 'Cover',
    accent: '#db6d28',
    summary: 'Obstacles grant AC bonus / Dexterity save bonus to a target.',
    body: [
      'Cover provides a bonus to AC and Dexterity saving throws against attacks that originate on the opposite side of the cover.',
      '• Half cover (+2) — about half the target is obscured (a low wall, a creature\'s body)',
      '• Three-quarters cover (+5) — most of the target is obscured (an arrow slit, a portcullis)',
      '• Full cover — the target can\'t be targeted directly at all',
      'Cover is measured from the attacker\'s position, not the target\'s.',
    ],
  },
  {
    id: 'death-saves',
    title: 'Death Saves & Dying',
    accent: '#f85149',
    summary: 'At 0 HP you fall unconscious and begin death saves.',
    body: [
      'When your HP drops to 0, you fall unconscious and begin making death saving throws at the start of each of your turns.',
      '• A death save is a d20 with no modifiers (unless a feature says otherwise).',
      '• 10 or higher = one success. Below 10 = one failure.',
      '• 3 successes = you stabilize (remain unconscious, regain HP at 1+).',
      '• 3 failures = you die.',
      '• Natural 20 = you regain 1 HP and become conscious (counts as 2 successes).',
      '• Natural 1 = two failures.',
      'Taking damage while at 0 HP counts as a failed death save. A critical hit counts as two failures. Healing that brings you to 1+ HP ends the dying state.',
    ],
  },
];

export default function CombatRules({ search }) {
  const [expanded, setExpanded] = useState(new Set(['action']));

  const filtered = search.trim()
    ? REFERENCE_CARDS.filter((c) => {
        const q = search.toLowerCase();
        return c.title.toLowerCase().includes(q) || c.summary.toLowerCase().includes(q) ||
          c.body.some((b) => b.toLowerCase().includes(q));
      })
    : REFERENCE_CARDS;

  const toggle = (id) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="grid lg:grid-cols-2 gap-3 items-start">
      {/* Reference cards */}
      <div className="space-y-1.5">
        {filtered.map((card) => {
          const isOpen = expanded.has(card.id);
          return (
            <div key={card.id} className="border border-[#30363d] clip-corner overflow-hidden">
              <button
                onClick={() => toggle(card.id)}
                className="w-full flex items-center gap-2 px-3 py-2.5 bg-[#0d1117] hover:bg-[#161b22] transition-colors touch-manipulation"
              >
                <span className="text-[9px] font-mono px-1.5 py-0.5 border clip-corner shrink-0"
                  style={{ borderColor: `${card.accent}40`, color: card.accent, background: `${card.accent}10` }}>
                  §
                </span>
                <div className="text-left flex-1 min-w-0">
                  <div className="text-[11px] font-bold text-[#e6edf3]">{card.title}</div>
                  <div className="text-[9px] text-[#8b949e] truncate">{card.summary}</div>
                </div>
                <ChevronRight size={14} className={`text-[#484f58] shrink-0 transition-transform ${isOpen ? 'rotate-90' : ''}`} />
              </button>
              {isOpen && (
                <div className="p-3 space-y-1.5 fade-in bg-[#0B0F13]">
                  {card.body.map((line, i) => (
                    <p key={i} className="text-[10px] text-[#c9d1d9] leading-relaxed">{line}</p>
                  ))}
                </div>
              )}
            </div>
          );
        })}
        {filtered.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-6">No rules match "{search}".</p>}
      </div>

      {/* Calculators */}
      <div className="space-y-3 lg:sticky lg:top-2">
        <AbilityCalculator />
        <D20Roller />
        <DeathSaveTracker />
      </div>
    </div>
  );
}

/* ── Calculator 1: Ability Score → Modifier / Save DC / Passive Perception ── */
function AbilityCalculator() {
  const [score, setScore] = useState(14);
  const [level, setLevel] = useState(1);
  const [proficient, setProficient] = useState(true);

  const mod = abilityModifier(score);
  const prof = proficiencyBonus(level);
  const dc = spellSaveDC(prof, score);
  const passive = passivePerception(score, prof, proficient);

  return (
    <div className="glass-panel clip-corner p-3 border-l-2 border-[#FF9F00]/40">
      <div className="flex items-center gap-1.5 mb-2">
        <Calculator size={12} className="text-[#FF9F00]" />
        <span className="text-[10px] font-bold text-[#FF9F00]">Ability Score Calculator</span>
      </div>
      <div className="grid grid-cols-3 gap-2 mb-3">
        <div>
          <label className="text-[8px] text-[#8b949e] uppercase font-bold block mb-0.5">Score</label>
          <input type="number" min={1} max={30} value={score}
            onChange={(e) => setScore(Math.max(1, Math.min(30, Number(e.target.value))))}
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner focus:border-[#FF9F00]/50" />
        </div>
        <div>
          <label className="text-[8px] text-[#8b949e] uppercase font-bold block mb-0.5">Level</label>
          <input type="number" min={1} max={20} value={level}
            onChange={(e) => setLevel(Math.max(1, Math.min(20, Number(e.target.value))))}
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner focus:border-[#FF9F00]/50" />
        </div>
        <div>
          <label className="text-[8px] text-[#8b949e] uppercase font-bold block mb-0.5">Perc Prof</label>
          <button onClick={() => setProficient((p) => !p)}
            className={`w-full px-2 py-1.5 text-xs font-bold clip-corner touch-manipulation border ${proficient ? 'border-[#FF9F00] bg-[#FF9F00]/15 text-[#FF9F00]' : 'border-[#30363d] text-[#8b949e]'}`}>
            {proficient ? 'Yes' : 'No'}
          </button>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Stat label="Modifier" value={`${mod >= 0 ? '+' : ''}${mod}`} accent="#e6edf3" />
        <Stat label="Proficiency" value={`+${prof}`} accent="#4dd0e1" />
        <Stat label="Spell Save DC" value={dc} accent="#a371f7" />
        <Stat label="Passive Perc" value={passive} accent="#3fb950" />
      </div>
    </div>
  );
}

/* ── Calculator 2: d20 Attack/Save Roller ── */
function D20Roller() {
  const [mode, setMode] = useState('attack'); // 'attack' | 'save'
  const [adv, setAdv] = useState('normal'); // 'advantage' | 'disadvantage' | 'normal'
  const [target, setTarget] = useState(15);
  const [bonus, setBonus] = useState(5);
  const [result, setResult] = useState(null);

  const roll = () => {
    const dice = [rollDie(20), rollDie(20)];
    const useDie = adv === 'advantage' ? Math.max(...dice) : adv === 'disadvantage' ? Math.min(...dice) : dice[0];
    const total = useDie + bonus;
    let outcome;
    if (mode === 'attack') {
      if (useDie === 20) outcome = 'critical';
      else if (useDie === 1) outcome = 'fumble';
      else outcome = total >= target ? 'hit' : 'miss';
    } else {
      outcome = total >= target ? 'success' : 'failure';
    }
    setResult({ dice, useDie, total, outcome });
  };

  const outcomeStyle = {
    critical: { color: '#3fb950', label: 'CRITICAL HIT!' },
    fumble: { color: '#f85149', label: 'CRITICAL MISS' },
    hit: { color: '#3fb950', label: 'HIT' },
    miss: { color: '#f85149', label: 'MISS' },
    success: { color: '#3fb950', label: 'SUCCESS' },
    failure: { color: '#f85149', label: 'FAILURE' },
  };

  return (
    <div className="glass-panel clip-corner p-3 border-l-2 border-[#4dd0e1]/40">
      <div className="flex items-center gap-1.5 mb-2">
        <Dices size={12} className="text-[#4dd0e1]" />
        <span className="text-[10px] font-bold text-[#4dd0e1]">d20 Attack / Save Roller</span>
      </div>
      <div className="grid grid-cols-2 gap-2 mb-2">
        <div className="flex gap-1">
          <button onClick={() => setMode('attack')}
            className={`flex-1 px-2 py-1.5 text-[10px] font-bold clip-corner touch-manipulation border ${mode === 'attack' ? 'border-[#4dd0e1] bg-[#4dd0e1]/15 text-[#4dd0e1]' : 'border-[#30363d] text-[#8b949e]'}`}>Attack</button>
          <button onClick={() => setMode('save')}
            className={`flex-1 px-2 py-1.5 text-[10px] font-bold clip-corner touch-manipulation border ${mode === 'save' ? 'border-[#4dd0e1] bg-[#4dd0e1]/15 text-[#4dd0e1]' : 'border-[#30363d] text-[#8b949e]'}`}>Save</button>
        </div>
        <div className="flex gap-1">
          {[['normal', 'Normal'], ['advantage', 'Adv'], ['disadvantage', 'Dis']].map(([v, l]) => (
            <button key={v} onClick={() => setAdv(v)}
              className={`flex-1 px-1 py-1.5 text-[9px] font-bold clip-corner touch-manipulation border ${adv === v ? 'border-[#a371f7] bg-[#a371f7]/15 text-[#a371f7]' : 'border-[#30363d] text-[#8b949e]'}`}>{l}</button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 mb-2">
        <div>
          <label className="text-[8px] text-[#8b949e] uppercase font-bold block mb-0.5">{mode === 'attack' ? 'Target AC' : 'Save DC'}</label>
          <input type="number" value={target} onChange={(e) => setTarget(Number(e.target.value))}
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner focus:border-[#4dd0e1]/50" />
        </div>
        <div>
          <label className="text-[8px] text-[#8b949e] uppercase font-bold block mb-0.5">Bonus</label>
          <input type="number" value={bonus} onChange={(e) => setBonus(Number(e.target.value))}
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner focus:border-[#4dd0e1]/50" />
        </div>
      </div>
      <button onClick={roll}
        className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-[#4dd0e1] text-black text-xs font-bold clip-corner touch-manipulation hover:brightness-110">
        <Dices size={14} /> Roll d20
      </button>
      {result && (
        <div className="mt-2 glass-strong clip-corner p-2.5 fade-in">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[9px] text-[#8b949e]">
              {adv !== 'normal' ? `Rolled 2d20 (${result.dice.join(', ')}) → ${result.useDie}` : `Rolled ${result.useDie}`}
            </span>
            <span className="text-[10px] font-bold text-[#e6edf3]">+{bonus} = {result.total}</span>
          </div>
          <div className="text-center text-sm font-bold font-heading" style={{ color: outcomeStyle[result.outcome].color }}>
            {outcomeStyle[result.outcome].label}
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Calculator 3: Death Save Tracker ── */
function DeathSaveTracker() {
  const [successes, setSuccesses] = useState(0);
  const [failures, setFailures] = useState(0);
  const [lastRoll, setLastRoll] = useState(null);
  const [status, setStatus] = useState('dying'); // 'dying' | 'stable' | 'dead' | 'conscious'

  const roll = () => {
    if (status !== 'dying') return;
    const die = rollDie(20);
    let s = successes, f = failures, newStatus = 'dying';
    if (die === 20) {
      s += 2;
      newStatus = 'conscious';
    } else if (die === 1) {
      f += 2;
    } else if (die >= 10) {
      s += 1;
    } else {
      f += 1;
    }
    if (s >= 3) newStatus = 'stable';
    if (f >= 3) newStatus = 'dead';
    setSuccesses(Math.min(s, 3));
    setFailures(Math.min(f, 3));
    setLastRoll(die);
    setStatus(newStatus);
  };

  const reset = () => {
    setSuccesses(0); setFailures(0); setLastRoll(null); setStatus('dying');
  };

  const statusInfo = {
    dying: { color: '#d29922', label: 'Dying — make death saves' },
    stable: { color: '#3fb950', label: 'Stabilized — unconscious, no more saves needed' },
    dead: { color: '#f85149', label: 'Dead — 3 failures' },
    conscious: { color: '#3fb950', label: 'Conscious — regained 1 HP (nat 20!)' },
  };

  return (
    <div className="glass-panel clip-corner p-3 border-l-2 border-[#f85149]/40">
      <div className="flex items-center gap-1.5 mb-2">
        <HeartPulse size={12} className="text-[#f85149]" />
        <span className="text-[10px] font-bold text-[#f85149]">Death Save Tracker</span>
      </div>
      <div className="flex justify-between items-center mb-2">
        <div>
          <span className="text-[8px] text-[#3fb950] uppercase font-bold">Successes</span>
          <div className="flex gap-1 mt-0.5">
            {[0, 1, 2].map((i) => (
              <span key={i} className={`w-4 h-4 border clip-corner ${i < successes ? 'bg-[#3fb950] border-[#3fb950]' : 'border-[#30363d]'}`} />
            ))}
          </div>
        </div>
        <div className="text-right">
          <span className="text-[8px] text-[#f85149] uppercase font-bold">Failures</span>
          <div className="flex gap-1 mt-0.5 justify-end">
            {[0, 1, 2].map((i) => (
              <span key={i} className={`w-4 h-4 border clip-corner ${i < failures ? 'bg-[#f85149] border-[#f85149]' : 'border-[#30363d]'}`} />
            ))}
          </div>
        </div>
      </div>
      <div className="flex gap-2">
        <button onClick={roll} disabled={status !== 'dying'}
          className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 bg-[#f85149] text-white text-xs font-bold clip-corner touch-manipulation disabled:opacity-40 hover:brightness-110">
          <Skull size={14} /> Roll Death Save
        </button>
        <button onClick={reset}
          className="px-3 py-2.5 border border-[#30363d] text-[#8b949e] text-xs clip-corner touch-manipulation">Reset</button>
      </div>
      {lastRoll !== null && (
        <div className="mt-2 text-center fade-in">
          <span className="text-[9px] text-[#8b949e]">Last roll: </span>
          <span className="text-sm font-bold text-[#e6edf3]">{lastRoll}</span>
          {lastRoll === 20 && <span className="text-[9px] text-[#3fb950] ml-1">(nat 20 → 2 successes + 1 HP)</span>}
          {lastRoll === 1 && <span className="text-[9px] text-[#f85149] ml-1">(nat 1 → 2 failures)</span>}
        </div>
      )}
      <div className="mt-2 text-center text-[10px] font-bold" style={{ color: statusInfo[status].color }}>
        {statusInfo[status].label}
      </div>
    </div>
  );
}

function Stat({ label, value, accent }) {
  return (
    <div className="bg-[#0d1117] border border-[#30363d] p-2 clip-corner text-center">
      <div className="text-[8px] text-[#8b949e] uppercase">{label}</div>
      <div className="text-sm font-bold" style={{ color: accent }}>{value}</div>
    </div>
  );
}