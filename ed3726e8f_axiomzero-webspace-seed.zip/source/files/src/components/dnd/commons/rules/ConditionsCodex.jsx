/**
 * ConditionsCodex — All 15 conditions as interactive branded cards.
 *
 * Delegates rendering to ConditionCard. Filter by impact category; search
 * filters across name, description, and removal text.
 */
import { useState, useMemo } from 'react';
import conditions from '@/lib/dnd/compendium/conditions.json';
import ConditionCard from './ConditionCard';

// Impact-type → filter-id mapping (mirrors ConditionCard's analyzeImpacts)
function getImpactTypes(desc) {
  const lower = desc.toLowerCase();
  const types = [];
  if (lower.includes('attack rolls against the creature have advantage')) types.push('adv-in');
  if (lower.includes("creature's attack rolls have advantage")) types.push('adv-out');
  if (lower.includes("creature's attack rolls have disadvantage") || lower.includes('creature has disadvantage on attack rolls')) types.push('dis-out');
  if (lower.includes('attack rolls against the creature have disadvantage')) types.push('dis-in');
  if (lower.includes('disadvantage on ability checks')) types.push('dis-checks');
  if (lower.includes('disadvantage on attacks and saves') || lower.includes('disadvantage on attack rolls and saving throws')) types.push('dis-saves');
  if (lower.includes('automatically fails strength and dexterity saving throws')) types.push('auto-fail');
  if (lower.includes("can't take actions")) types.push('no-actions');
  if (lower.includes("speed becomes 0") || lower.includes("speed reduced to 0")) types.push('speed-0');
  if (lower.includes('resistance to all damage')) types.push('resist');
  if (lower.includes('critical hit')) types.push('crit-hit');
  return types;
}

const FILTERS = [
  { id: 'all', label: 'All Conditions' },
  { id: 'adv-in', label: 'Easier to hit' },
  { id: 'dis-out', label: 'Harder to attack' },
  { id: 'auto-fail', label: 'Auto-fail saves' },
  { id: 'no-actions', label: 'No actions' },
];

export default function ConditionsCodex({ search }) {
  const [filter, setFilter] = useState('all');

  const enriched = useMemo(() =>
    conditions.map((c) => ({ ...c, impactTypes: getImpactTypes(c.description) })),
  []);

  const filtered = useMemo(() => {
    let list = enriched;
    if (filter !== 'all') list = list.filter((c) => c.impactTypes.includes(filter));
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter((c) =>
        c.name.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.removal.toLowerCase().includes(q)
      );
    }
    return list;
  }, [enriched, filter, search]);

  return (
    <div className="space-y-3">
      {/* Filter chips */}
      <div className="flex gap-1.5 flex-wrap items-center">
        {FILTERS.map((f) => (
          <button key={f.id} onClick={() => setFilter(f.id)}
            className={`px-3 py-1.5 text-[10px] font-bold border clip-corner transition-all touch-manipulation ${
              filter === f.id ? 'border-[#f85149] bg-[#f85149]/15 text-[#f85149]' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'
            }`}>
            {f.label}
          </button>
        ))}
        <span className="text-[9px] text-[#484f58] ml-1">{filtered.length} / 15</span>
      </div>

      {/* Condition cards grid */}
      <div className="grid sm:grid-cols-2 gap-2">
        {filtered.map((c) => (
          <ConditionCard key={c.slug} condition={c} />
        ))}
      </div>
      {filtered.length === 0 && (
        <p className="text-[10px] text-[#484f58] text-center py-6">No conditions match "{search}".</p>
      )}
    </div>
  );
}