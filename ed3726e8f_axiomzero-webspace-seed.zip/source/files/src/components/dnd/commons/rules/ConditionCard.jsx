/**
 * ConditionCard — A rich, branded, interactive card for a single D&D condition.
 *
 * Shows the condition icon, name, severity tier, combat-mechanic impact badges
 * (advantage/disadvantage/auto-fail), full description, and removal requirements.
 * Click to expand/collapse. Branded with the platform's charcoal + amber/teal
 * design language and hard-angled clip-corner containers.
 */
import { useState } from 'react';
import {
  ChevronRight, Shield, Eye, EyeOff, Swords, AlertCircle, Ban,
  Heart, VolumeX, Ghost, Hand, Mountain, Skull, ArrowDown, Link,
  Zap, Moon, BatteryLow, Sparkles,
} from 'lucide-react';

// Per-condition metadata: icon + severity tier (1=minor, 4=extreme)
const META = {
  blinded:      { icon: EyeOff,       tier: 2 },
  charmed:      { icon: Heart,        tier: 1 },
  deafened:     { icon: VolumeX,      tier: 1 },
  frightened:   { icon: Ghost,        tier: 2 },
  grappled:     { icon: Hand,         tier: 2 },
  incapacitated:{ icon: Ban,          tier: 3 },
  invisible:    { icon: Sparkles,     tier: 1 },
  paralyzed:    { icon: Zap,          tier: 4 },
  petrified:    { icon: Mountain,     tier: 4 },
  poisoned:     { icon: Skull,        tier: 2 },
  prone:        { icon: ArrowDown,    tier: 1 },
  restrained:   { icon: Link,         tier: 2 },
  stunned:      { icon: Zap,          tier: 3 },
  unconscious:  { icon: Moon,         tier: 4 },
  exhaustion:   { icon: BatteryLow,   tier: 3 },
};

const TIER = {
  1: { label: 'Minor',    color: '#3fb950', bg: 'rgba(63,185,80,0.10)' },
  2: { label: 'Moderate', color: '#d29922', bg: 'rgba(210,153,34,0.10)' },
  3: { label: 'Severe',   color: '#db6d28', bg: 'rgba(219,109,40,0.12)' },
  4: { label: 'Extreme',  color: '#f85149', bg: 'rgba(248,81,73,0.12)' },
};

// Parse combat-mechanic impacts from the description text
function analyzeImpacts(desc) {
  const lower = desc.toLowerCase();
  const impacts = [];
  if (lower.includes('attack rolls against the creature have advantage')) impacts.push({ type: 'adv-in', label: 'Attacks vs it: ADV', tone: 'adv' });
  if (lower.includes("creature's attack rolls have advantage")) impacts.push({ type: 'adv-out', label: 'Its attacks: ADV', tone: 'adv' });
  if (lower.includes("creature's attack rolls have disadvantage") || lower.includes('creature has disadvantage on attack rolls'))
    impacts.push({ type: 'dis-out', label: 'Its attacks: DIS', tone: 'dis' });
  if (lower.includes('attack rolls against the creature have disadvantage')) impacts.push({ type: 'dis-in', label: 'Attacks vs it: DIS', tone: 'dis' });
  if (lower.includes('disadvantage on ability checks')) impacts.push({ type: 'dis-checks', label: 'Ability checks: DIS', tone: 'dis' });
  if (lower.includes('disadvantage on attacks and saves') || lower.includes('disadvantage on attack rolls and saving throws'))
    impacts.push({ type: 'dis-saves', label: 'Saves: DIS', tone: 'dis' });
  if (lower.includes('automatically fails strength and dexterity saving throws')) impacts.push({ type: 'auto-fail', label: 'Str/Dex saves: AUTO-FAIL', tone: 'crit' });
  if (lower.includes("can't take actions")) impacts.push({ type: 'no-actions', label: 'No actions/reactions', tone: 'crit' });
  if (lower.includes("speed becomes 0") || lower.includes("speed reduced to 0")) impacts.push({ type: 'speed-0', label: 'Speed: 0', tone: 'warn' });
  if (lower.includes('resistance to all damage')) impacts.push({ type: 'resist', label: 'Resists all damage', tone: 'adv' });
  if (lower.includes('critical hit')) impacts.push({ type: 'crit-hit', label: 'Melee hits: CRIT', tone: 'crit' });
  return impacts;
}

const TONE_STYLES = {
  adv:  { color: '#3fb950', border: 'rgba(63,185,80,0.35)',  bg: 'rgba(63,185,80,0.08)' },
  dis:  { color: '#f85149', border: 'rgba(248,81,73,0.35)',  bg: 'rgba(248,81,73,0.08)' },
  crit: { color: '#ff7b72', border: 'rgba(255,123,114,0.40)', bg: 'rgba(255,123,114,0.10)' },
  warn: { color: '#d29922', border: 'rgba(210,153,34,0.35)',  bg: 'rgba(210,153,34,0.08)' },
};

function ImpactBadge({ impact }) {
  const style = TONE_STYLES[impact.tone] || TONE_STYLES.warn;
  const Icon = impact.tone === 'adv' ? Eye : impact.tone === 'dis' ? EyeOff : impact.tone === 'crit' ? AlertCircle : Swords;
  return (
    <span
      className="flex items-center gap-1 text-[9px] font-bold px-1.5 py-1 border clip-corner"
      style={{ color: style.color, borderColor: style.border, background: style.bg }}
    >
      <Icon size={9} />
      {impact.label}
    </span>
  );
}

export default function ConditionCard({ condition }) {
  const [open, setOpen] = useState(false);
  const meta = META[condition.slug] || { icon: AlertCircle, tier: 2 };
  const Icon = meta.icon;
  const tier = TIER[meta.tier];
  const impacts = analyzeImpacts(condition.description);

  return (
    <div
      className={`border clip-corner overflow-hidden transition-all duration-200 ${open ? 'glow-hover-amber' : ''}`}
      style={{ borderColor: open ? `${tier.color}55` : '#30363d' }}
    >
      {/* Header — always visible, click to toggle */}
      <button
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center gap-2.5 px-3 py-3 bg-[#0d1117] hover:bg-[#161b22] transition-colors touch-manipulation text-left"
      >
        <span
          className="w-8 h-8 shrink-0 flex items-center justify-center border clip-corner"
          style={{ borderColor: `${tier.color}50`, background: tier.bg }}
        >
          <Icon size={15} style={{ color: tier.color }} />
        </span>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-[12px] font-bold text-[#e6edf3] truncate">{condition.name}</span>
            <span
              className="text-[7px] font-bold px-1 py-0.5 border clip-corner shrink-0 uppercase tracking-wider"
              style={{ color: tier.color, borderColor: `${tier.color}40`, background: tier.bg }}
            >
              {tier.label}
            </span>
          </div>
          <span className="text-[8px] text-[#484f58] uppercase tracking-wide">
            {impacts.length} mechanic{impacts.length !== 1 ? 's' : ''}
          </span>
        </div>
        <ChevronRight size={14} className={`text-[#484f58] shrink-0 transition-transform ${open ? 'rotate-90' : ''}`} />
      </button>

      {/* Expanded detail */}
      {open && (
        <div className="p-3 space-y-2.5 fade-in bg-[#0B0F13] border-t border-[#30363d]">
          {/* Description */}
          <p className="text-[10px] text-[#c9d1d9] leading-relaxed">{condition.description}</p>

          {/* Combat mechanics impact */}
          {impacts.length > 0 && (
            <div>
              <span className="text-[8px] text-[#FF9F00] uppercase font-bold tracking-wider block mb-1.5">
                Combat Impact
              </span>
              <div className="flex flex-wrap gap-1">
                {impacts.map((imp, i) => (
                  <ImpactBadge key={i} impact={imp} />
                ))}
              </div>
            </div>
          )}

          {/* Removal requirements */}
          <div
            className="flex items-start gap-2 p-2 border clip-corner"
            style={{ borderColor: 'rgba(77,208,225,0.25)', background: 'rgba(77,208,225,0.05)' }}
          >
            <Shield size={13} className="text-[#4dd0e1] shrink-0 mt-0.5" />
            <div className="min-w-0">
              <span className="text-[8px] text-[#4dd0e1] uppercase font-bold tracking-wider block mb-0.5">
                Removal
              </span>
              <span className="text-[9px] text-[#8b949e] leading-relaxed">{condition.removal}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}