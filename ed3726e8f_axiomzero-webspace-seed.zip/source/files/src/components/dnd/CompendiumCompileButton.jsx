/**
 * CompendiumCompileButton — "Compile more with Merlin" button for the
 * CompendiumBrowser. Calls dndCompileEntry to retrieve additional entries
 * for a category, persists them as custom entities, and calls onCompiled
 * so the browser can refresh its merged list.
 */
import { useState } from 'react';
import { Sparkles, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function CompendiumCompileButton({ category, existingSlugs = [], onCompiled }) {
  const [compiling, setCompiling] = useState(false);

  const compile = async () => {
    setCompiling(true);
    try {
      const response = await base44.functions.invoke('dndCompileEntry', {
        category,
        count: 5,
        existingSlugs,
      });
      const data = response.data || response;
      if (data.error) throw new Error(data.error);
      const entries = data.entries || [];
      // Persist based on category
      for (const e of entries) {
        if (category === 'monsters' || category === 'villains') {
          await base44.entities.DnDCustomMonster.create({
            name: e.name, slug: e.slug, cr: e.cr || 0, xp: e.xp || 0,
            hp: e.hp || 1, ac: e.ac || 10, size: e.size || 'Medium',
            type: e.type || 'humanoid', environment: e.environment || 'any',
            role: category === 'villains' ? 'villain' : (e.role || 'custom'),
            signature_abilities_json: JSON.stringify(e.signature_abilities || []),
            description: e.description || '',
          });
        } else if (category === 'spells' || category === 'cantrips') {
          await base44.entities.DnDCustomSpell.create({
            name: e.name, slug: e.slug, level: e.level || 0, school: e.school || 'custom',
            casting_time: e.casting_time || '', range: e.range || '',
            duration: e.duration || '', components: e.components || '',
            concentration: !!e.concentration, ritual: !!e.ritual,
            description: e.description || '', classes_json: JSON.stringify(e.classes || []),
          });
        } else if (category === 'items') {
          await base44.entities.DnDCustomItem.create({
            name: e.name, slug: e.slug, type: e.type || 'custom',
            rarity: e.rarity || 'common', attunement: !!e.attunement,
            value: e.value || 0, description: e.description || '',
          });
        }
      }
      await onCompiled?.();
    } catch (e) {
      alert('Compile failed: ' + e.message);
    }
    setCompiling(false);
  };

  return (
    <button onClick={compile} disabled={compiling}
      className="flex items-center gap-1.5 px-2.5 py-1 border border-[#4dd0e1]/40 bg-[#4dd0e1]/10 text-[#4dd0e1] text-[10px] font-bold clip-corner hover:bg-[#4dd0e1]/20 transition-all touch-manipulation disabled:opacity-50 whitespace-nowrap">
      {compiling ? <Loader2 size={11} className="animate-spin" /> : <Sparkles size={11} />}
      {compiling ? 'Compiling...' : 'Compile more'}
    </button>
  );
}