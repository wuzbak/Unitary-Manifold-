/**
 * PlayHub — Unified Solo + Player entry.
 *
 * Merges the old separate "Solo" and "Player" mode buttons into one "Play" tile.
 * The user can either start a standalone solo workspace (no code) or enter a
 * campaign invite code to join as a DnDPlayer. A solo character can later enter
 * an invite code to convert into a campaign character.
 */
import { useState, useEffect, useCallback } from 'react';
import { User, Users, KeyRound, ArrowLeft, Sparkles, Link2 } from 'lucide-react';
import SoloWorkspace from '@/components/dnd/solo/SoloWorkspace';
import PlayerDashboard from '@/components/dnd/player/PlayerDashboard';
import { base44 } from '@/api/base44Client';

export default function PlayHub({
  playerRecords, campaigns, activeCampaign, setActiveCampaign,
  activePlayer, setActivePlayer, onRefresh, onLiveState,
}) {
  const [submode, setSubmode] = useState('choose'); // 'choose' | 'solo' | 'campaign'
  const [joinCode, setJoinCode] = useState('');
  const [joinName, setJoinName] = useState('');
  const [joining, setJoining] = useState(false);
  const [error, setError] = useState('');
  const [soloChars, setSoloChars] = useState([]);
  const [bringSoloId, setBringSoloId] = useState('');

  const loadSoloChars = useCallback(async () => {
    try {
      const list = await base44.entities.DnDCharacter.filter({ solo: true }, '-created_date', 20);
      setSoloChars(list || []);
    } catch { /* */ }
  }, []);

  useEffect(() => { loadSoloChars(); }, [loadSoloChars]);

  // If already in a campaign, show the player dashboard
  if (activeCampaign && activePlayer) {
    return (
      <div className="space-y-3">
        <button onClick={() => { setSubmode('choose'); }}
          className="flex items-center gap-1.5 text-[10px] text-[#8b949e] hover:text-[#FF9F00] touch-manipulation">
          <ArrowLeft size={12} /> Back to Play Hub
        </button>
        <PlayerDashboard
          playerRecords={playerRecords} campaigns={campaigns}
          activeCampaign={activeCampaign} setActiveCampaign={setActiveCampaign}
          activePlayer={activePlayer} setActivePlayer={setActivePlayer}
          onRefresh={onRefresh} onLiveState={onLiveState}
        />
      </div>
    );
  }

  if (submode === 'solo') {
    return (
      <div className="space-y-3">
        <button onClick={() => setSubmode('choose')}
          className="flex items-center gap-1.5 text-[10px] text-[#8b949e] hover:text-[#FF9F00] touch-manipulation">
          <ArrowLeft size={12} /> Back to Play Hub
        </button>
        <SoloWorkspace onLiveState={onLiveState} />
      </div>
    );
  }

  const joinCampaign = async () => {
    setJoining(true);
    setError('');
    try {
      const camp = campaigns.find((c) => c.invite_code === joinCode.toUpperCase().trim());
      if (!camp) { setError('Invalid invite code. Check with your DM.'); setJoining(false); return; }
      const player = await base44.entities.DnDPlayer.create({
        campaign_id: camp.id, display_name: joinName || 'Player', invite_code: joinCode.toUpperCase().trim(),
      });
      // Link a solo character to the campaign if selected
      if (bringSoloId) {
        await base44.entities.DnDCharacter.update(bringSoloId, {
          campaign_id: camp.id, player_id: player.id, solo: false,
        });
      }
      await onRefresh();
      setActiveCampaign(camp); setActivePlayer(player);
      setJoinCode(''); setJoinName(''); setBringSoloId('');
    } catch (e) { setError(`Failed to join: ${e.message}`); }
    setJoining(false);
  };

  // Choose screen
  const myCampaigns = playerRecords.map((p) => campaigns.find((c) => c.id === p.campaign_id)).filter(Boolean);

  return (
    <div className="space-y-4">
      <div className="glass-panel clip-corner p-3">
        <p className="text-[10px] text-[#8b949e]">
          <span className="text-[#FF9F00] font-bold">Play</span> — Choose how you want to play. Start a solo character for theorycrafting and standalone adventure, or join a live campaign with an invite code from your DM. Solo characters can join a campaign later.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 gap-3">
        {/* Solo tile */}
        <button onClick={() => setSubmode('solo')}
          className="text-left p-5 border-2 border-[#3b8bff]/40 bg-[#3b8bff]/5 clip-corner hover:border-[#3b8bff] hover:bg-[#3b8bff]/10 transition-all touch-manipulation group">
          <User size={28} className="text-[#3b8bff] mb-3 group-hover:scale-110 transition-transform" />
          <h3 className="text-sm font-bold text-[#e6edf3] font-heading">Solo Play</h3>
          <p className="text-[10px] text-[#8b949e] mt-1 leading-relaxed">
            Standalone character, inventory, encounters, and combat. No DM required. Join a campaign later via invite code.
          </p>
        </button>

        {/* Join campaign tile */}
        <div className="p-5 border-2 border-[#FF9F00]/40 bg-[#FF9F00]/5 clip-corner">
          <div className="flex items-center gap-2 mb-3">
            <Users size={28} className="text-[#FF9F00]" />
            <h3 className="text-sm font-bold text-[#e6edf3] font-heading">Join Campaign</h3>
          </div>
          <p className="text-[10px] text-[#8b949e] mb-3 leading-relaxed">
            Enter the invite code from your Dungeon Master to join a live campaign.
          </p>
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 glass-panel clip-corner px-2 py-1.5">
              <KeyRound size={12} className="text-[#FF9F00] shrink-0" />
              <input value={joinCode} onChange={(e) => setJoinCode(e.target.value.toUpperCase())} placeholder="INVITE CODE" maxLength={6}
                className="flex-1 bg-transparent text-xs font-bold text-[#FF9F00] tracking-widest focus:outline-none placeholder:text-[#484f58] font-mono min-w-0" />
            </div>
            <input value={joinName} onChange={(e) => setJoinName(e.target.value)} placeholder="Your display name"
              className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner focus:border-[#FF9F00]/40" />
            {soloChars.length > 0 && (
              <div className="flex items-center gap-1.5 glass-panel clip-corner px-2 py-1.5">
                <Link2 size={12} className="text-[#3b8bff] shrink-0" />
                <select value={bringSoloId} onChange={(e) => setBringSoloId(e.target.value)}
                  className="flex-1 bg-transparent text-[10px] text-[#e6edf3] focus:outline-none min-w-0">
                  <option value="">Start fresh (no solo char)</option>
                  {soloChars.map((c) => (
                    <option key={c.id} value={c.id}>Bring: {c.name} (L{c.level} {c.klass})</option>
                  ))}
                </select>
              </div>
            )}
            {error && <p className="text-[10px] text-[#f85149]">{error}</p>}
            <button onClick={joinCampaign} disabled={joining || !joinCode.trim()}
              className="w-full px-3 py-2 bg-[#FF9F00] text-black text-xs font-bold clip-corner disabled:opacity-50 touch-manipulation flex items-center justify-center gap-1.5">
              <Sparkles size={12} /> {joining ? 'Joining...' : 'Join Campaign'}
            </button>
          </div>
        </div>
      </div>

      {myCampaigns.length > 0 && (
        <div>
          <p className="text-[10px] text-[#8b949e] uppercase font-bold mb-1.5">Your Campaigns</p>
          <div className="space-y-1.5">
            {myCampaigns.map((c) => {
              const p = playerRecords.find((pr) => pr.campaign_id === c.id);
              return (
                <button key={c.id} onClick={() => { setActiveCampaign(c); setActivePlayer(p); }}
                  className="w-full text-left p-3 border border-[#30363d] bg-[#0d1117] clip-corner hover:border-[#FF9F00]/40 transition-all touch-manipulation">
                  <span className="text-sm font-bold text-[#e6edf3]">{c.name}</span>
                  <span className="text-[10px] text-[#8b949e] ml-2">{c.setting} · {c.rules_edition}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}