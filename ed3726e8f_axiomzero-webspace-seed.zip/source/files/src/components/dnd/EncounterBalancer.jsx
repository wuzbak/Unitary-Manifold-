/**
 * EncounterBalancer — Deterministic encounter balancer with two modes:
 * 1. Balance: DM picks monsters, engine computes live difficulty + XP budget
 * 2. Procure: DM inputs party levels + target difficulty + environment, engine
 *    auto-generates a monster set from the compendium
 *
 * Both modes share the same deterministic engine. Results can be inserted into
 * the active encounter with one click.
 */
import { useState, useEffect, useMemo } from 'react';
import { Swords, Wand2, Plus, Trash2, RefreshCw, Target, Users, Layers } from 'lucide-react';
import { computeEncounter, procureEncounter, DIFFICULTY_STYLES } from '@/lib/dnd/encounterEngine';
import { searchMonsters, MONSTER_ENVIRONMENTS, getMonster } from '@/lib/dnd/compendium';
import { encounterThresholds, ENCOUNTER_MULTIPLIER } from '@/lib/dnd/rules';

const DIFFICULTIES = ['trivial', 'easy', 'medium', 'hard', 'deadly'];

export default function EncounterBalancer({ partyLevels = [1], onInsertEncounter, accent = '#FF9F00' }) {
  const [mode, setMode] = useState('procure'); // 'procure' | 'balance'
  const [targetDifficulty, setTargetDifficulty] = useState('medium');
  const [environment, setEnvironment] = useState('');
  const [maxMonsters, setMaxMonsters] = useState(6);
  const [procured, setProcured] = useState(null);
  const [balanceMonsters, setBalanceMonsters] = useState([]);
  const [search, setSearch] = useState('');
  const [procuring, setProcuring] = useState(false);

  // Procure mode
  const handleProcure = () => {
    setProcuring(true);
    setTimeout(() => {
      const result = procureEncounter(partyLevels, targetDifficulty, environment, { maxMonsters });
      setProcured(result);
      setProcuring(false);
    }, 400);
  };

  // Balance mode — live compute
  const balanceStats = useMemo(() => computeEncounter(balanceMonsters, partyLevels), [balanceMonsters, partyLevels]);

  const thresholds = useMemo(() => encounterThresholds(partyLevels), [partyLevels]);

  const insertProcured = () => {
    if (procured) onInsertEncounter?.(procured.slugs, procured);
  };

  const insertBalanced = () => {
    if (balanceMonsters.length > 0) onInsertEncounter?.(balanceMonsters, balanceStats);
  };

  const addBalanceMonster = (slug) => setBalanceMonsters((prev) => [...prev, slug]);
  const removeBalanceMonster = (i) => setBalanceMonsters((prev) => prev.filter((_, idx) => idx !== i));

  const searchResults = useMemo(() => searchMonsters({ query: search }).slice(0, 20), [search]);

  return (
    <div className="space-y-3">
      {/* Party summary */}
      <div className="glass-panel clip-corner p-3">
        <div className="flex items-center gap-2 mb-2">
          <Users size={14} style={{ color: accent }} />
          <span className="text-[10px] font-bold uppercase" style={{ color: accent }}>Party</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {partyLevels.map((lvl, i) => (
            <span key={i} className="px-2 py-1 bg-[#0d1117] border border-[#30363d] clip-corner text-[10px] text-[#e6edf3]">
              L{lvl}
            </span>
          ))}
          {partyLevels.length === 0 && <span className="text-[10px] text-[#484f58]">No party — add characters first</span>}
        </div>
        {/* XP thresholds */}
        <div className="grid grid-cols-4 gap-1.5 mt-2 text-center text-[9px]">
          {['easy', 'medium', 'hard', 'deadly'].map((d) => (
            <div key={d} className="p-1.5 border clip-corner" style={{ borderColor: `${DIFFICULTY_STYLES[d].color}40`, background: `${DIFFICULTY_STYLES[d].color}08` }}>
              <div className="uppercase font-bold" style={{ color: DIFFICULTY_STYLES[d].color }}>{d}</div>
              <div className="text-[#8b949e]">{thresholds[d]}xp</div>
            </div>
          ))}
        </div>
      </div>

      {/* Mode toggle */}
      <div className="flex gap-1">
        <button onClick={() => setMode('procure')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold border clip-corner touch-manipulation ${mode === 'procure' ? 'border-[#FF9F00] bg-[#FF9F00]/15 text-[#FF9F00]' : 'border-[#30363d] text-[#8b949e]'}`}>
          <Wand2 size={12} /> Auto-Procure
        </button>
        <button onClick={() => setMode('balance')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold border clip-corner touch-manipulation ${mode === 'balance' ? 'border-[#FF9F00] bg-[#FF9F00]/15 text-[#FF9F00]' : 'border-[#30363d] text-[#8b949e]'}`}>
          <Target size={12} /> Balance Picks
        </button>
      </div>

      {/* Procure mode */}
      {mode === 'procure' && (
        <div className="space-y-3">
          <div className="glass-strong clip-corner p-3 space-y-2">
            <p className="text-[10px] text-[#8b949e]">
              Set the target difficulty and environment — the deterministic engine procures a balanced monster set from the compendium.
            </p>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">Target Difficulty</label>
                <select value={targetDifficulty} onChange={(e) => setTargetDifficulty(e.target.value)}
                  className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
                  {DIFFICULTIES.map((d) => <option key={d} value={d}>{DIFFICULTY_STYLES[d].label}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">Environment</label>
                <select value={environment} onChange={(e) => setEnvironment(e.target.value)}
                  className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
                  <option value="">Any</option>
                  {MONSTER_ENVIRONMENTS.map((e) => <option key={e} value={e}>{e}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">Max Monsters: {maxMonsters}</label>
              <input type="range" min={1} max={12} value={maxMonsters} onChange={(e) => setMaxMonsters(Number(e.target.value))}
                className="w-full accent-[#FF9F00]" />
            </div>
            <button onClick={handleProcure} disabled={procuring || partyLevels.length === 0}
              className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-[#FF9F00] text-black text-xs font-bold clip-corner disabled:opacity-50 touch-manipulation">
              {procuring ? <><RefreshCw size={14} className="animate-spin" /> Procuring...</> : <><Wand2 size={14} /> Procure Encounter</>}
            </button>
          </div>

          {/* Procured result */}
          {procured && (
            <div className="glass-strong clip-corner p-3" style={{ borderLeft: `3px solid ${procured.verdict.color}` }}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold font-heading" style={{ color: procured.verdict.color }}>
                  {procured.verdict.label} Encounter
                </span>
                <span className="text-[10px] text-[#8b949e]">
                  Target: {procured.targetDifficulty} ({procured.targetXp}xp) · Actual: {procured.adjustedXp}xp
                </span>
              </div>
              {/* XP budget bar */}
              <div className="h-2 bg-[#0d1117] clip-corner overflow-hidden mb-3">
                <div className="h-full transition-all" style={{ width: `${Math.min(100, (procured.adjustedXp / procured.thresholds.deadly) * 100)}%`, background: procured.verdict.color }} />
              </div>
              {/* Monster list */}
              <div className="space-y-1.5 mb-3">
                {procured.monsters.map((m, i) => (
                  <div key={i} className="flex items-center justify-between p-2 bg-[#0d1117] border border-[#30363d] clip-corner">
                    <div>
                      <span className="text-xs font-bold text-[#e6edf3]">{m.name}</span>
                      <span className="text-[9px] text-[#8b949e] ml-2">CR {m.cr} · {m.xp}xp · {m.environment}</span>
                    </div>
                    <span className="text-[9px] text-[#FF9F00] font-bold">{m.xp}xp</span>
                  </div>
                ))}
              </div>
              {/* Budget breakdown */}
              <div className="grid grid-cols-3 gap-2 text-center text-[9px] mb-3">
                <div className="bg-[#0d1117] border border-[#30363d] p-1.5 clip-corner">
                  <div className="text-[#8b949e] uppercase">Base XP</div>
                  <div className="text-[#e6edf3] font-bold">{procured.baseXp}</div>
                </div>
                <div className="bg-[#0d1117] border border-[#30363d] p-1.5 clip-corner">
                  <div className="text-[#8b949e] uppercase">Multiplier</div>
                  <div className="text-[#e6edf3] font-bold">×{procured.monsters.length <= 1 ? '1.0' : procured.monsters.length <= 2 ? '1.5' : procured.monsters.length <= 3 ? '2.0' : procured.monsters.length <= 6 ? '2.5' : procured.monsters.length <= 10 ? '3.0' : '4.0'}</div>
                </div>
                <div className="bg-[#0d1117] border border-[#30363d] p-1.5 clip-corner">
                  <div className="text-[#8b949e] uppercase">Adjusted</div>
                  <div className="font-bold" style={{ color: procured.verdict.color }}>{procured.adjustedXp}</div>
                </div>
              </div>
              <button onClick={insertProcured} disabled={!onInsertEncounter}
                className="w-full flex items-center justify-center gap-2 px-3 py-2 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-xs font-bold clip-corner disabled:opacity-50 touch-manipulation">
                <Plus size={14} /> Insert into Encounter
              </button>
            </div>
          )}
        </div>
      )}

      {/* Balance mode */}
      {mode === 'balance' && (
        <div className="space-y-3">
          {/* Difficulty verdict */}
          <div className="glass-strong clip-corner p-3" style={{ borderLeft: `3px solid ${balanceStats.difficultyStyle.color}` }}>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold font-heading" style={{ color: balanceStats.difficultyStyle.color }}>
                {balanceStats.difficultyStyle.label} Encounter
              </h3>
              <span className="text-[10px] text-[#8b949e]">{balanceStats.monsterCount} monster(s) · {balanceStats.adjustedXp} XP</span>
            </div>
            <div className="grid grid-cols-4 gap-1.5 text-center text-[9px]">
              {['easy', 'medium', 'hard', 'deadly'].map((d) => (
                <div key={d} className={`p-1.5 border clip-corner ${balanceStats.difficulty === d ? 'border-2' : 'border'}`}
                  style={{ borderColor: DIFFICULTY_STYLES[d].color, background: balanceStats.difficulty === d ? DIFFICULTY_STYLES[d].bg : 'transparent' }}>
                  <div className="uppercase font-bold" style={{ color: DIFFICULTY_STYLES[d].color }}>{d}</div>
                  <div className="text-[#8b949e]">{balanceStats.thresholds[d]}</div>
                </div>
              ))}
            </div>
            <div className="text-[9px] text-[#484f58] mt-1.5">
              Base XP: {balanceStats.baseXp} · Multiplier: ×{balanceStats.monsterCount <= 1 ? '1.0' : balanceStats.monsterCount <= 2 ? '1.5' : balanceStats.monsterCount <= 3 ? '2.0' : balanceStats.monsterCount <= 6 ? '2.5' : balanceStats.monsterCount <= 10 ? '3.0' : '4.0'}
            </div>
          </div>

          {/* Selected monsters */}
          <div className="glass-panel clip-corner p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] text-[#FF9F00] font-bold uppercase flex items-center gap-1"><Layers size={10} /> Selected ({balanceMonsters.length})</span>
              {balanceMonsters.length > 0 && (
                <button onClick={insertBalanced} disabled={!onInsertEncounter}
                  className="flex items-center gap-1 px-2 py-1 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">
                  <Plus size={10} /> Insert
                </button>
              )}
            </div>
            {balanceMonsters.length === 0 ? (
              <p className="text-[10px] text-[#484f58] text-center py-2">Click monsters below to add them</p>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {balanceMonsters.map((slug, i) => {
                  const m = balanceStats.monsters[i];
                  return (
                    <div key={i} className="flex items-center gap-1 px-2 py-1 bg-[#0d1117] border border-[#30363d] clip-corner text-[10px]">
                      <span className="text-[#e6edf3]">{m?.name || slug}</span>
                      <span className="text-[#FF9F00]">{m?.xp || 0}xp</span>
                      <button onClick={() => removeBalanceMonster(i)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={10} /></button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Monster search */}
          <div className="flex gap-2">
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search monsters..."
              className="flex-1 bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          </div>

          {/* Monster list */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5 max-h-[40vh] overflow-y-auto">
            {searchResults.map((m) => (
              <button key={m.slug} onClick={() => addBalanceMonster(m.slug)}
                className="flex flex-col p-2 border border-[#30363d] bg-[#0d1117] clip-corner hover:border-[#FF9F00]/40 text-left touch-manipulation">
                <span className="text-[10px] font-bold text-[#e6edf3] truncate">{m.name}</span>
                <span className="text-[9px] text-[#FF9F00]">CR {m.cr} · {m.xp}xp</span>
                <span className="text-[8px] text-[#484f58]">{m.type} · {m.environment}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}