import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Calendar, SkipForward, Moon } from 'lucide-react';

const PHASES = ['New', 'Waxing Crescent', 'First Quarter', 'Waxing Gibbous', 'Full', 'Waning Gibbous', 'Last Quarter', 'Waning Crescent'];

export default function CalendarTab({ campaign }) {
  const [items, setItems] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: 'Common Calendar', epoch: '', current_date: '1', holidays: '' });
  const load = useCallback(async () => { if (!campaign) return; const l = await base44.entities.DnDCalendar.filter({ campaign_id: campaign.id }, '-created_date', 20); setItems(l || []); }, [campaign]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const u = base44.entities.DnDCalendar.subscribe(() => load()); return u; }, [load]);
  const add = async () => {
    await base44.entities.DnDCalendar.create({ ...form, campaign_id: campaign.id, moon_phases_json: '[]', holidays_json: JSON.stringify(form.holidays.split(',').map((s) => s.trim()).filter(Boolean)) });
    setForm({ name: 'Common Calendar', epoch: '', current_date: '1', holidays: '' }); setShowForm(false); load();
  };
  const del = async (id) => { await base44.entities.DnDCalendar.delete(id); load(); };
  const advance = async (c) => { const day = Number(c.current_date || '1') + 1; await base44.entities.DnDCalendar.update(c.id, { current_date: String(day) }); load(); };
  return (
    <div className="space-y-2">
      <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#bc8cff]/40 bg-[#bc8cff]/10 text-[#bc8cff] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> New Calendar</button>
      {showForm && (
        <div className="glass-panel clip-corner p-3 space-y-2">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Calendar name..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <input value={form.epoch} onChange={(e) => setForm({ ...form, epoch: e.target.value })} placeholder="Epoch..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <input value={form.holidays} onChange={(e) => setForm({ ...form, holidays: e.target.value })} placeholder="Holidays (comma-separated)..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <button onClick={add} disabled={!form.name.trim()} className="px-3 py-1.5 bg-[#bc8cff] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">Add</button>
        </div>
      )}
      {items.map((c) => {
        const day = Number(c.current_date || '1');
        const phase = PHASES[day % 8];
        const holidays = (() => { try { return JSON.parse(c.holidays_json || '[]'); } catch { return []; } })();
        return (
          <div key={c.id} className="p-2.5 border border-[#30363d] bg-[#0d1117] clip-corner">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-1.5"><Calendar size={12} className="text-[#bc8cff]" /><span className="text-xs font-bold text-[#e6edf3]">{c.name}</span></div>
              <button onClick={() => del(c.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
            </div>
            <div className="flex items-center justify-between mt-1">
              <div className="text-[10px] text-[#8b949e]">Day <span className="text-[#e6edf3] font-bold font-mono">{day}</span> · <Moon size={10} className="inline text-[#4dd0e1]" /> {phase}</div>
              <button onClick={() => advance(c)} className="flex items-center gap-1 px-2 py-1 border border-[#bc8cff]/40 bg-[#bc8cff]/10 text-[#bc8cff] text-[9px] font-bold clip-corner touch-manipulation"><SkipForward size={10} /> Advance Day</button>
            </div>
            {holidays.length > 0 && <p className="text-[9px] text-[#d29922] mt-0.5">🎉 {holidays.join(', ')}</p>}
          </div>
        );
      })}
      {items.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No calendars yet</p>}
    </div>
  );
}