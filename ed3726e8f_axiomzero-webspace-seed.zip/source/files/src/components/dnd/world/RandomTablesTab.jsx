import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Dices, Shuffle } from 'lucide-react';

export default function RandomTablesTab({ campaign }) {
  const [items, setItems] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', category: 'other', dice_formula: '1d20', entries: '' });
  const [rolls, setRolls] = useState({});
  const load = useCallback(async () => { if (!campaign) return; const l = await base44.entities.DnDRandomTable.filter({ campaign_id: campaign.id }, '-created_date', 50); setItems(l || []); }, [campaign]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const u = base44.entities.DnDRandomTable.subscribe(() => load()); return u; }, [load]);
  const add = async () => {
    await base44.entities.DnDRandomTable.create({ ...form, campaign_id: campaign.id, entries_json: JSON.stringify(form.entries.split('\n').map((s) => s.trim()).filter(Boolean)) });
    setForm({ name: '', category: 'other', dice_formula: '1d20', entries: '' }); setShowForm(false); load();
  };
  const del = async (id) => { await base44.entities.DnDRandomTable.delete(id); load(); };
  const roll = (t) => {
    const entries = (() => { try { return JSON.parse(t.entries_json || '[]'); } catch { return []; } })();
    if (entries.length === 0) return;
    const result = entries[Math.floor(Math.random() * entries.length)];
    setRolls((r) => ({ ...r, [t.id]: result }));
  };
  return (
    <div className="space-y-2">
      <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#bc8cff]/40 bg-[#bc8cff]/10 text-[#bc8cff] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> New Table</button>
      {showForm && (
        <div className="glass-panel clip-corner p-3 space-y-2">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Table name (e.g. Tavern Names)..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <div className="grid grid-cols-2 gap-2">
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
              {['name', 'loot', 'tavern', 'weather', 'rumor', 'encounter', 'other'].map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
            <input value={form.dice_formula} onChange={(e) => setForm({ ...form, dice_formula: e.target.value })} placeholder="1d20" className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          </div>
          <textarea value={form.entries} onChange={(e) => setForm({ ...form, entries: e.target.value })} placeholder="One entry per line..." rows={5} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <button onClick={add} disabled={!form.name.trim()} className="px-3 py-1.5 bg-[#bc8cff] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">Add</button>
        </div>
      )}
      {items.map((t) => {
        const entries = (() => { try { return JSON.parse(t.entries_json || '[]'); } catch { return []; } })();
        return (
          <div key={t.id} className="p-2.5 border border-[#30363d] bg-[#0d1117] clip-corner">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-1.5"><Dices size={12} className="text-[#bc8cff]" /><span className="text-xs font-bold text-[#e6edf3]">{t.name}</span><span className="text-[8px] text-[#bc8cff]">{t.category} · {t.dice_formula}</span></div>
              <button onClick={() => del(t.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
            </div>
            <div className="flex items-center gap-2 mt-1.5">
              <button onClick={() => roll(t)} className="flex items-center gap-1 px-2 py-1 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[9px] font-bold clip-corner touch-manipulation"><Shuffle size={10} /> Roll</button>
              {rolls[t.id] && <span className="text-[10px] text-[#e6edf3] font-bold">→ {rolls[t.id]}</span>}
            </div>
            <p className="text-[9px] text-[#484f58] mt-1">{entries.length} entries</p>
          </div>
        );
      })}
      {items.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No random tables yet</p>}
    </div>
  );
}