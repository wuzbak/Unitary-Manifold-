import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, BookOpen, ChevronRight } from 'lucide-react';

export default function LoreTab({ campaign }) {
  const [items, setItems] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [expanded, setExpanded] = useState(null);
  const [form, setForm] = useState({ title: '', body: '', tags: '' });
  const load = useCallback(async () => { if (!campaign) return; const l = await base44.entities.DnDLoreArticle.filter({ campaign_id: campaign.id }, '-created_date', 50); setItems(l || []); }, [campaign]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const u = base44.entities.DnDLoreArticle.subscribe(() => load()); return u; }, [load]);
  const add = async () => {
    await base44.entities.DnDLoreArticle.create({ ...form, campaign_id: campaign.id, links_json: '[]', tags_json: JSON.stringify(form.tags.split(',').map((s) => s.trim()).filter(Boolean)) });
    setForm({ title: '', body: '', tags: '' }); setShowForm(false); load();
  };
  const del = async (id) => { await base44.entities.DnDLoreArticle.delete(id); load(); };
  return (
    <div className="space-y-2">
      <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#bc8cff]/40 bg-[#bc8cff]/10 text-[#bc8cff] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> New Article</button>
      {showForm && (
        <div className="glass-panel clip-corner p-3 space-y-2">
          <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Article title..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <textarea value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} placeholder="Body (wiki prose)..." rows={4} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="Tags (comma-separated)..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <button onClick={add} disabled={!form.title.trim()} className="px-3 py-1.5 bg-[#bc8cff] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">Add</button>
        </div>
      )}
      {items.map((a) => {
        const tags = (() => { try { return JSON.parse(a.tags_json || '[]'); } catch { return []; } })();
        const isOpen = expanded === a.id;
        return (
          <div key={a.id} className="p-2.5 border border-[#30363d] bg-[#0d1117] clip-corner">
            <div className="flex justify-between items-start">
              <button onClick={() => setExpanded(isOpen ? null : a.id)} className="flex items-center gap-1.5 min-w-0 text-left">
                <ChevronRight size={12} className={`text-[#bc8cff] transition-transform ${isOpen ? 'rotate-90' : ''}`} />
                <BookOpen size={12} className="text-[#bc8cff]" />
                <span className="text-xs font-bold text-[#e6edf3] truncate">{a.title}</span>
              </button>
              <button onClick={() => del(a.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
            </div>
            {isOpen && a.body && <p className="text-[10px] text-[#c9d1d9] mt-1.5 leading-relaxed whitespace-pre-wrap">{a.body}</p>}
            {tags.length > 0 && <div className="flex flex-wrap gap-1 mt-1">{tags.map((t) => <span key={t} className="text-[8px] px-1.5 py-0.5 border border-[#bc8cff]/30 text-[#bc8cff] clip-corner">{t}</span>)}</div>}
          </div>
        );
      })}
      {items.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No lore articles yet</p>}
    </div>
  );
}