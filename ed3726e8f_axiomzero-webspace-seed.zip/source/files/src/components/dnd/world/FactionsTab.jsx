import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Users } from 'lucide-react';

const REP_COLOR = { hostile: '#f85149', unfriendly: '#db6d28', neutral: '#8b949e', friendly: '#3fb950', allied: '#3b8bff' };

export default function FactionsTab({ campaign }) {
  const [items, setItems] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', type: 'guild', reputation_tier: 'neutral', goals: '', secrets: '', members: '' });
  const load = useCallback(async () => { if (!campaign) return; const l = await base44.entities.DnDFaction.filter({ campaign_id: campaign.id }, '-created_date', 50); setItems(l || []); }, [campaign]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const u = base44.entities.DnDFaction.subscribe(() => load()); return u; }, [load]);
  const add = async () => {
    await base44.entities.DnDFaction.create({ ...form, campaign_id: campaign.id, members_json: JSON.stringify(form.members.split(',').map((s) => s.trim()).filter(Boolean)) });
    setForm({ name: '', type: 'guild', reputation_tier: 'neutral', goals: '', secrets: '', members: '' }); setShowForm(false); load();
  };
  const del = async (id) => { await base44.entities.DnDFaction.delete(id); load(); };
  return (
    <div className="space-y-2">
      <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#bc8cff]/40 bg-[#bc8cff]/10 text-[#bc8cff] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> New Faction</button>
      {showForm && (
        <div className="glass-panel clip-corner p-3 space-y-2">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Faction name..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <div className="grid grid-cols-2 gap-2">
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
              {['guild', 'order', 'kingdom', 'cult', 'merchant', 'criminal', 'noble', 'other'].map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
            <select value={form.reputation_tier} onChange={(e) => setForm({ ...form, reputation_tier: e.target.value })} className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
              {['hostile', 'unfriendly', 'neutral', 'friendly', 'allied'].map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <input value={form.goals} onChange={(e) => setForm({ ...form, goals: e.target.value })} placeholder="Goals..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <input value={form.secrets} onChange={(e) => setForm({ ...form, secrets: e.target.value })} placeholder="Secrets..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <input value={form.members} onChange={(e) => setForm({ ...form, members: e.target.value })} placeholder="Members (comma-separated)..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <button onClick={add} disabled={!form.name.trim()} className="px-3 py-1.5 bg-[#bc8cff] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">Add</button>
        </div>
      )}
      {items.map((f) => {
        const members = (() => { try { return JSON.parse(f.members_json || '[]'); } catch { return []; } })();
        return (
          <div key={f.id} className="p-2.5 border border-[#30363d] bg-[#0d1117] clip-corner">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-1.5"><Users size={12} style={{ color: REP_COLOR[f.reputation_tier] }} /><span className="text-xs font-bold text-[#e6edf3]">{f.name}</span><span className="text-[8px]" style={{ color: REP_COLOR[f.reputation_tier] }}>{f.reputation_tier}</span></div>
              <button onClick={() => del(f.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
            </div>
            <p className="text-[9px] text-[#bc8cff]">{f.type}</p>
            {f.goals && <p className="text-[10px] text-[#8b949e] mt-0.5">🎯 {f.goals}</p>}
            {f.secrets && <p className="text-[10px] text-[#d29922]">🔒 {f.secrets}</p>}
            {members.length > 0 && <p className="text-[9px] text-[#484f58]">Members: {members.join(', ')}</p>}
          </div>
        );
      })}
      {items.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No factions yet</p>}
    </div>
  );
}