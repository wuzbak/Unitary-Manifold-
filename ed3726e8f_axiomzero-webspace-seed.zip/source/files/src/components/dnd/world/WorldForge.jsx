/**
 * WorldForge — tabbed shell for campaign world-building: locations, factions,
 * calendar, lore wiki, and random tables. Each sub-tab owns its CRUD.
 */
import { useState } from 'react';
import { Map, Users, Calendar, BookOpen, Dices } from 'lucide-react';
import LocationsTab from './LocationsTab';
import FactionsTab from './FactionsTab';
import CalendarTab from './CalendarTab';
import LoreTab from './LoreTab';
import RandomTablesTab from './RandomTablesTab';

const TABS = [
  { id: 'locations', label: 'Locations', icon: Map },
  { id: 'factions', label: 'Factions', icon: Users },
  { id: 'calendar', label: 'Calendar', icon: Calendar },
  { id: 'lore', label: 'Lore', icon: BookOpen },
  { id: 'tables', label: 'Random Tables', icon: Dices },
];

export default function WorldForge({ campaign }) {
  const [tab, setTab] = useState('locations');
  return (
    <div className="space-y-3">
      <div className="glass-panel clip-corner p-2.5">
        <p className="text-[10px] text-[#8b949e]"><span className="text-[#bc8cff] font-bold">World Forge</span> — Locations, factions, calendar, lore wiki, and random tables. All cross-link into Merlin's context.</p>
      </div>
      <div className="flex gap-1 overflow-x-auto pb-1">
        {TABS.map((t) => { const Icon = t.icon; const active = tab === t.id;
          return <button key={t.id} onClick={() => setTab(t.id)} className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold border clip-corner whitespace-nowrap touch-manipulation ${active ? 'border-[#bc8cff] bg-[#bc8cff]/15 text-[#bc8cff]' : 'border-[#30363d] bg-[#0d1117] text-[#8b949e]'}`}><Icon size={12} /> {t.label}</button>;
        })}
      </div>
      {tab === 'locations' && <LocationsTab campaign={campaign} />}
      {tab === 'factions' && <FactionsTab campaign={campaign} />}
      {tab === 'calendar' && <CalendarTab campaign={campaign} />}
      {tab === 'lore' && <LoreTab campaign={campaign} />}
      {tab === 'tables' && <RandomTablesTab campaign={campaign} />}
    </div>
  );
}