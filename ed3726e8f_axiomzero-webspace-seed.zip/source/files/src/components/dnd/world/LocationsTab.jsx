import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, MapPin } from 'lucide-react';

export default function LocationsTab({ campaign }) {
  const [items, setItems] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', type: 'region', parent_id: '', description: '', tags: '' });
  const load = useCallback(async () => { if (!campaign) return; const l = await base44.entities.DnDLocation.filter({ campaign_id: campaign.id }, '-created_date', 50); setItems(l || []); }, [campaign]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const u = base44.entities.DnDLocation.subscribe(() => load()); return u; }, [load]);
  const add = async () => {
    await base44.entities.DnDLocation.create({ ...form, campaign_id: campaign.id, map_pin_json: '{}', tags_json: JSON.stringify(form.tags.split(',').map((s) => s.trim()).filter(Boolean)) });
    setForm({ name: '', type: 'region', parent_id: '', description: '', tags: '' }); setShowForm(false); load();
  };
  const del = async (id) => { await base44.entities.DnDLocation.delete(id); load(); };
  const parentName = (pid) => items.find((i) => i.id === pid)?.name || '';
  return (
    <div className="space-y-2">
      <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#bc8cff]/40 bg-[#bc8cff]/10 text-[#bc8cff] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> New Location</button>
      {showForm && (
        <div className="glass-panel clip-corner p-3 space-y-2">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Location name..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <div className="grid grid-cols-2 gap-2">
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
              {['world', 'region', 'town', 'dungeon', 'landmark'].map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
            <select value={form.parent_id} onChange={(e) => setForm({ ...form, parent_id: e.target.value })} className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
              <option value="">No parent</option>
              {items.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
            </select>
          </div>
          <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Description..." rows={2} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="Tags (comma-separated)..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <button onClick={add} disabled={!form.name.trim()} className="px-3 py-1.5 bg-[#bc8cff] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">Add</button>
        </div>
      )}
      {items.map((l) => (
        <div key={l.id} className="p-2.5 border border-[#30363d] bg-[#0d1117] clip-corner">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-1.5"><MapPin size={12} className="text-[#bc8cff]" /><span className="text-xs font-bold text-[#e6edf3]">{l.name}</span><span className="text-[8px] text-[#bc8cff]">{l.type}</span></div>
            <button onClick={() => del(l.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
          </div>
          {parentName(l.parent_id) && <p className="text-[9px] text-[#484f58]">↳ within {parentName(l.parent_id)}</p>}
          {l.description && <p className="text-[10px] text-[#8b949e] mt-0.5">{l.description}</p>}
        </div>
      ))}
      {items.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No locations yet</p>}
    </div>
  );
}