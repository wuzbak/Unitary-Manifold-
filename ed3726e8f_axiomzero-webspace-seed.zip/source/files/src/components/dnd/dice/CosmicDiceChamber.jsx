/**
 * CosmicDiceChamber — Inline 3D dice panel embedded in the page.
 * Always visible, shows the last roll result + quick-select dice buttons.
 * Less disruptive than the modal — for in-context rolls.
 */
import { useState } from 'react';
import { Dices, Maximize2, Sparkles } from 'lucide-react';
import DiceCosmosEngine from './DiceCosmosEngine';
import { DICE_TYPES, rollExpression, addToHistory, getDieColor } from '@/lib/dnd/diceEngine';

export default function CosmicDiceChamber({ onOpenModal, mode = 'player', accent = '#FF9F00', onRollLogged }) {
  const [currentRoll, setCurrentRoll] = useState(null);
  const [rolling, setRolling] = useState(false);

  const quickRoll = (sides) => {
    setRolling(true);
    setTimeout(() => {
      const roll = rollExpression(`1d${sides}`, { label: `d${sides}`, mode });
      setCurrentRoll(roll);
      addToHistory(roll);
      onRollLogged?.(roll);
      setRolling(false);
    }, 800);
  };

  return (
    <div className="glass-strong clip-corner overflow-hidden" style={{ borderColor: `${accent}30` }}>
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-[#30363d]">
        <div className="flex items-center gap-1.5">
          <Dices size={14} style={{ color: accent }} />
          <span className="text-[10px] font-bold font-heading" style={{ color: accent }}>COSMIC DICE</span>
        </div>
        <button onClick={onOpenModal} className="flex items-center gap-1 text-[9px] text-[#8b949e] hover:text-[#e6edf3] border border-[#30363d] px-1.5 py-0.5 clip-corner touch-manipulation">
          <Maximize2 size={9} /> Full
        </button>
      </div>

      {/* 3D dice field */}
      <div className="relative h-32 bg-[#0B0F13]">
        <DiceCosmosEngine roll={currentRoll} rolling={rolling} accent={accent} compact />
        {/* Result overlay */}
        {currentRoll && !rolling && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center">
              <div className={`text-3xl font-bold font-heading ${currentRoll.crit ? 'text-[#3fb950]' : currentRoll.fumble ? 'text-[#f85149]' : ''}`} style={{ color: currentRoll.crit || currentRoll.fumble ? undefined : accent }}>
                {currentRoll.total}
              </div>
              <div className="text-[8px] text-[#8b949e]">{currentRoll.expr}</div>
              {currentRoll.crit && <div className="text-[9px] text-[#3fb950] font-bold">CRIT!</div>}
              {currentRoll.fumble && <div className="text-[9px] text-[#f85149] font-bold">FUMBLE</div>}
            </div>
          </div>
        )}
        {rolling && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-[9px] text-[#8b949e] animate-pulse flex items-center gap-1">
              <Sparkles size={9} style={{ color: accent }} /> Rolling...
            </div>
          </div>
        )}
      </div>

      {/* Quick-select dice */}
      <div className="flex gap-1 p-2 border-t border-[#30363d]">
        {DICE_TYPES.map((d) => (
          <button key={d.sides} onClick={() => quickRoll(d.sides)} disabled={rolling}
            className="flex-1 py-1.5 border clip-corner text-[10px] font-bold font-mono transition-all disabled:opacity-40 touch-manipulation"
            style={{ borderColor: `${d.color}40`, color: d.color, background: `${d.color}10` }}>
            {d.label}
          </button>
        ))}
      </div>
    </div>
  );
}