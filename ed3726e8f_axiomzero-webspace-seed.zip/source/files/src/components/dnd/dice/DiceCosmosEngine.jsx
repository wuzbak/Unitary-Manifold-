/**
 * DiceCosmosEngine — Shared Three.js visual engine for the cosmic dice roller.
 * Dice are metallic/geometric objects that tumble through a toroidal universe
 * field (reusing the home topology aesthetic) and settle on a face.
 *
 * Consumed by both the inline CosmicDiceChamber and the CosmicDiceModal.
 *
 * Props:
 *  - roll: the current roll result object (from diceEngine.rollExpression)
 *  - rolling: boolean — whether dice are currently tumbling
 *  - accent: hex color for the cosmic field
 *  - compact: boolean — smaller field for inline chamber
 */
import { useEffect, useRef } from 'react';
import * as THREE from 'three';

const TORUS_R = 4;  // major radius
const TORUS_r = 1.4; // minor radius

function torusPoint(u, v) {
  return new THREE.Vector3(
    (TORUS_R + TORUS_r * Math.cos(v)) * Math.cos(u),
    TORUS_r * Math.sin(v),
    (TORUS_R + TORUS_r * Math.cos(v)) * Math.sin(u)
  );
}

function makeGlowTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 64; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, 'rgba(255,255,255,1)');
  grad.addColorStop(0.3, 'rgba(255,255,255,0.5)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(canvas);
}

// Die face geometry — creates a die with N faces
function createDieGeometry(sides) {
  // Map sides to a Three.js geometry
  if (sides === 4) return new THREE.TetrahedronGeometry(0.6);
  if (sides === 6) return new THREE.BoxGeometry(0.7, 0.7, 0.7);
  if (sides === 8) return new THREE.OctahedronGeometry(0.65);
  if (sides === 10) return new THREE.DodecahedronGeometry(0.6); // approximate
  if (sides === 12) return new THREE.DodecahedronGeometry(0.65);
  if (sides === 20) return new THREE.IcosahedronGeometry(0.65);
  if (sides === 100) return new THREE.IcosahedronGeometry(0.65); // approximate
  return new THREE.IcosahedronGeometry(0.65);
}

// Face number textures — canvas-drawn numbers on each face
function makeNumberTexture(num, color = '#FF9F00') {
  const canvas = document.createElement('canvas');
  canvas.width = 128; canvas.height = 128;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(13,17,23,0.95)';
  ctx.fillRect(0, 0, 128, 128);
  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.strokeRect(4, 4, 120, 120);
  ctx.fillStyle = color;
  ctx.font = 'bold 64px "JetBrains Mono", monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(String(num), 64, 68);
  return new THREE.CanvasTexture(canvas);
}

export default function DiceCosmosEngine({ roll, rolling, accent = '#4dd0e1', compact = false }) {
  const containerRef = useRef(null);
  const rollRef = useRef(roll);
  const rollingRef = useRef(rolling);
  const accentRef = useRef(accent);
  rollRef.current = roll;
  rollingRef.current = rolling;
  accentRef.current = accent;

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const glowTex = makeGlowTexture();
    const scene = new THREE.Scene();
    scene.background = null;
    scene.fog = new THREE.FogExp2(0x0B0F13, 0.04);

    const w = container.clientWidth || 300;
    const h = container.clientHeight || 200;
    const camera = new THREE.PerspectiveCamera(50, w / h, 0.1, 100);
    camera.position.set(0, 2, 8);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(w, h);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // ── Lighting ──
    scene.add(new THREE.AmbientLight(0x1a2a3e, 0.8));
    const keyLight = new THREE.PointLight(new THREE.Color(accentRef.current), 3, 30);
    keyLight.position.set(5, 5, 5);
    scene.add(keyLight);
    const fillLight = new THREE.PointLight(0xff9f00, 1.5, 25);
    fillLight.position.set(-5, -3, -5);
    scene.add(fillLight);
    const rimLight = new THREE.PointLight(0xbc8cff, 1.2, 20);
    rimLight.position.set(0, -5, 3);
    scene.add(rimLight);

    // ── Toroidal universe field (wireframe) ──
    const torusGeo = new THREE.TorusGeometry(TORUS_R, TORUS_r, 16, 64);
    const torusMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(accentRef.current),
      transparent: true, opacity: 0.06, wireframe: true,
    });
    const torus = new THREE.Mesh(torusGeo, torusMat);
    scene.add(torus);

    // Toroidal field lines
    const fieldLines = [];
    for (let f = 0; f < 8; f++) {
      const u = (f / 8) * Math.PI * 2;
      const pts = [];
      for (let i = 0; i <= 48; i++) pts.push(torusPoint(u, (i / 48) * Math.PI * 2));
      const geo = new THREE.BufferGeometry().setFromPoints(pts);
      const mat = new THREE.LineBasicMaterial({ color: new THREE.Color(accentRef.current), transparent: true, opacity: 0.12 });
      scene.add(new THREE.Line(geo, mat));
      fieldLines.push({ mat });
    }

    // ── Starfield ──
    const starCount = compact ? 300 : 800;
    const starPositions = new Float32Array(starCount * 3);
    const starColors = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const radius = 8 + Math.random() * 15;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      starPositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      starPositions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      starPositions[i * 3 + 2] = radius * Math.cos(phi);
      const c = new THREE.Color().setHSL(0.5 + Math.random() * 0.1, 0.8, 0.5 + Math.random() * 0.4);
      starColors[i * 3] = c.r; starColors[i * 3 + 1] = c.g; starColors[i * 3 + 2] = c.b;
    }
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    starGeo.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
    const starMat = new THREE.PointsMaterial({ size: 0.08, map: glowTex, vertexColors: true, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
    const stars = new THREE.Points(starGeo, starMat);
    scene.add(stars);

    // ── Plasma particles flowing along the torus ──
    const plasmaCount = compact ? 60 : 150;
    const plasmaPositions = new Float32Array(plasmaCount * 3);
    const plasmaData = [];
    for (let i = 0; i < plasmaCount; i++) {
      const u = Math.random() * Math.PI * 2;
      const v = Math.random() * Math.PI * 2;
      const pos = torusPoint(u, v);
      plasmaPositions[i * 3] = pos.x; plasmaPositions[i * 3 + 1] = pos.y; plasmaPositions[i * 3 + 2] = pos.z;
      plasmaData.push({ u, v, uSpeed: 0.2 + Math.random() * 0.4, vSpeed: 0.1 + Math.random() * 0.3 });
    }
    const plasmaGeo = new THREE.BufferGeometry();
    plasmaGeo.setAttribute('position', new THREE.BufferAttribute(plasmaPositions, 3));
    const plasmaMat = new THREE.PointsMaterial({ size: 0.1, map: glowTex, color: new THREE.Color(accentRef.current), transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
    const plasma = new THREE.Points(plasmaGeo, plasmaMat);
    scene.add(plasma);

    // ── Dice group ──
    const diceGroup = new THREE.Group();
    scene.add(diceGroup);
    const diceMeshes = [];
    const diceState = []; // { mesh, targetRot, currentRot, settled, faceValue }

    function spawnDice(rollResult) {
      // Clear existing
      while (diceGroup.children.length > 0) {
        const child = diceGroup.children[0];
        diceGroup.remove(child);
        child.geometry?.dispose();
        if (child.material?.map) child.material.map.dispose();
        child.material?.dispose();
      }
      diceMeshes.length = 0;
      diceState.length = 0;

      if (!rollResult) return;

      const rolls = rollResult.rolls || [];
      const accentColor = new THREE.Color(accentRef.current);

      rolls.forEach((r, idx) => {
        const sides = r.die;
        const geo = createDieGeometry(sides);
        const mat = new THREE.MeshStandardMaterial({
          color: 0xd4d4d8,
          metalness: 0.85,
          roughness: 0.25,
          emissive: accentColor,
          emissiveIntensity: 0.15,
        });
        const mesh = new THREE.Mesh(geo, mat);

        // Position dice in a row
        const offset = (idx - (rolls.length - 1) / 2) * 1.6;
        mesh.position.set(offset, 0, 0);
        mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);

        // Edge glow wireframe overlay
        const edgeGeo = new THREE.EdgesGeometry(geo);
        const edgeMat = new THREE.LineBasicMaterial({ color: accentColor, transparent: true, opacity: 0.6 });
        const edges = new THREE.LineSegments(edgeGeo, edgeMat);
        mesh.add(edges);

        diceGroup.add(mesh);
        diceMeshes.push(mesh);
        diceState.push({
          mesh,
          edges,
          targetRot: new THREE.Vector3(Math.random() * Math.PI * 4, Math.random() * Math.PI * 4, Math.random() * Math.PI * 4),
          settled: false,
          faceValue: r.kept ?? r.rolls[0],
          rollPhase: 0,
        });
      });
    }

    // ── Animation loop ──
    let animId;
    let lastT = 0;
    let settleTimer = 0;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const t = performance.now() * 0.001;
      const dt = Math.min(0.05, t - lastT); lastT = t;

      // Torus rotation
      torus.rotation.y += 0.003;
      torus.rotation.x += 0.001;
      fieldLines.forEach((fl, i) => {
        fl.mat.opacity = 0.08 + Math.sin(t * 2 + i) * 0.04;
      });

      // Starfield slow rotation
      stars.rotation.y += 0.0005;

      // Plasma flow
      const plasmaPos = plasmaGeo.attributes.position.array;
      for (let i = 0; i < plasmaCount; i++) {
        const pd = plasmaData[i];
        pd.u += pd.uSpeed * dt; pd.v += pd.vSpeed * dt;
        const pos = torusPoint(pd.u, pd.v);
        plasmaPos[i * 3] = pos.x; plasmaPos[i * 3 + 1] = pos.y; plasmaPos[i * 3 + 2] = pos.z;
      }
      plasmaGeo.attributes.position.needsUpdate = true;
      plasmaMat.opacity = 0.3 + Math.sin(t * 1.5) * 0.1;

      // Dice tumbling
      const isRolling = rollingRef.current;
      if (isRolling) {
        settleTimer = 0;
        diceState.forEach((ds) => {
          ds.mesh.rotation.x += 0.15 + Math.random() * 0.05;
          ds.mesh.rotation.y += 0.12 + Math.random() * 0.05;
          ds.mesh.rotation.z += 0.1 + Math.random() * 0.05;
          ds.mesh.position.y = Math.sin(t * 4 + ds.faceValue) * 0.3;
          ds.settled = false;
          ds.rollPhase = 0;
        });
      } else {
        // Settling phase — dice decelerate and lock to target rotation
        settleTimer += dt;
        diceState.forEach((ds, i) => {
          if (!ds.settled) {
            ds.rollPhase += dt * 3;
            const ease = Math.min(1, ds.rollPhase);
            // Decelerate rotation
            const rotSpeed = 0.15 * (1 - ease);
            ds.mesh.rotation.x += rotSpeed;
            ds.mesh.rotation.y += rotSpeed * 0.8;
            ds.mesh.rotation.z += rotSpeed * 0.6;
            ds.mesh.position.y *= (1 - ease * 0.3);
            if (ds.rollPhase >= 1) {
              ds.settled = true;
              // Snap to a clean face orientation
              ds.mesh.rotation.set(
                Math.round(ds.mesh.rotation.x / (Math.PI / 2)) * (Math.PI / 2),
                Math.round(ds.mesh.rotation.y / (Math.PI / 2)) * (Math.PI / 2),
                Math.round(ds.mesh.rotation.z / (Math.PI / 2)) * (Math.PI / 2)
              );
              ds.mesh.position.y = 0;
            }
          } else {
            // Gentle float when settled
            ds.mesh.position.y = Math.sin(t * 1.5 + i) * 0.05;
            // Pulse emissive on crit/fumble
            const r = rollRef.current;
            if (r?.crit || r?.fumble) {
              ds.mesh.material.emissiveIntensity = 0.3 + Math.sin(t * 6) * 0.2;
            }
          }
        });
      }

      // Camera subtle orbit
      camera.position.x = Math.sin(t * 0.15) * 2;
      camera.position.y = 2 + Math.sin(t * 0.1) * 0.5;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
    };

    // Spawn initial dice if there's a roll
    if (rollRef.current) spawnDice(rollRef.current);
    animate();

    // Watch for roll changes
    let lastRollId = rollRef.current?.id;
    let lastRolling = rollingRef.current;
    const checkInterval = setInterval(() => {
      const currentRoll = rollRef.current;
      const currentRolling = rollingRef.current;
      if (currentRoll?.id !== lastRollId) {
        lastRollId = currentRoll?.id;
        spawnDice(currentRoll);
      }
      // When rolling transitions to false, trigger settle
      if (lastRolling && !currentRolling) {
        settleTimer = 0;
        diceState.forEach((ds) => { ds.settled = false; ds.rollPhase = 0; });
      }
      lastRolling = currentRolling;
    }, 50);

    const handleResize = () => {
      if (!container.clientWidth) return;
      const nw = container.clientWidth, nh = container.clientHeight;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      clearInterval(checkInterval);
      window.removeEventListener('resize', handleResize);
      glowTex.dispose();
      torusGeo.dispose(); torusMat.dispose();
      starGeo.dispose(); starMat.dispose();
      plasmaGeo.dispose(); plasmaMat.dispose();
      fieldLines.forEach((fl) => fl.mat.dispose());
      while (diceGroup.children.length > 0) {
        const child = diceGroup.children[0];
        child.geometry?.dispose();
        if (child.material?.map) child.material.map.dispose();
        child.material?.dispose();
      }
      renderer.dispose();
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement);
    };
  }, [compact]);

  return <div ref={containerRef} className="w-full h-full" />;
}