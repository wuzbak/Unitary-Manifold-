/**
 * CosmicDiceModal — Dedicated roll modal summoned on big rolls / DM hidden rolls.
 * Shares the DiceCosmosEngine visual with the inline chamber.
 * DM variant: supports hidden rolls (reveal-on-tap) and announced results.
 * Player variant: open with a personal roll history log.
 */
import { useState, useEffect } from 'react';
import { X, Dices, Eye, EyeOff, History, Trash2, Sparkles } from 'lucide-react';
import DiceCosmosEngine from './DiceCosmosEngine';
import { DICE_TYPES, rollExpression, getHistory, addToHistory, clearHistory, getDieColor } from '@/lib/dnd/diceEngine';

export default function CosmicDiceModal({ isOpen, onClose, mode = 'player', accent = '#FF9F00', onRollLogged }) {
  const [expr, setExpr] = useState('1d20');
  const [modifier, setModifier] = useState(0);
  const [advantage, setAdvantage] = useState(false);
  const [disadvantage, setDisadvantage] = useState(false);
  const [selectedDie, setSelectedDie] = useState(20);
  const [count, setCount] = useState(1);
  const [dc, setDc] = useState(0);
  const [label, setLabel] = useState('');
  const [currentRoll, setCurrentRoll] = useState(null);
  const [rolling, setRolling] = useState(false);
  const [hidden, setHidden] = useState(mode === 'dm');
  const [history, setHistory] = useState([]);

  useEffect(() => {
    if (isOpen) setHistory(getHistory());
  }, [isOpen]);

  useEffect(() => {
    // Build expression from controls
    const advStr = advantage ? 'adv' : disadvantage ? 'dis' : '';
    const modStr = modifier !== 0 ? (modifier >= 0 ? `+${modifier}` : `${modifier}`) : '';
    setExpr(`${count}d${selectedDie}${advStr}${modStr}`);
  }, [selectedDie, count, modifier, advantage, disadvantage]);

  const handleRoll = () => {
    setRolling(true);
    setHidden(mode === 'dm'); // DM rolls are hidden by default
    setTimeout(() => {
      const roll = rollExpression(expr, {
        label: label || `${count}d${selectedDie}`,
        hidden: mode === 'dm',
        dc: dc > 0 ? dc : undefined,
        mode,
      });
      setCurrentRoll(roll);
      addToHistory(roll);
      onRollLogged?.(roll);
      setHistory(getHistory());
      setRolling(false);
    }, 1200); // let the dice tumble through the cosmos
  };

  const setDieCount = (sides) => {
    setSelectedDie(sides);
    setCount(1);
    setAdvantage(false);
    setDisadvantage(false);
  };

  if (!isOpen) return null;

  const isDm = mode === 'dm';

  return (
    <div className="fixed inset-0 z-[60] bg-black/85 backdrop-blur-sm flex items-center justify-center p-3" onClick={onClose}>
      <div className="glass-strong clip-corner w-full max-w-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()} style={{ borderColor: `${accent}40` }}>
        {/* Header */}
        <div className="flex items-center justify-between p-3 border-b border-[#30363d] sticky top-0 bg-[#12161A] z-10">
          <div className="flex items-center gap-2">
            <Dices size={18} style={{ color: accent }} />
            <span className="text-sm font-bold font-heading" style={{ color: accent }}>
              {isDm ? 'DM Cosmic Dice' : 'Player Cosmic Dice'}
            </span>
            {isDm && (
              <button onClick={() => setHidden(!hidden)} className={`flex items-center gap-1 px-2 py-0.5 border clip-corner text-[9px] font-bold ${hidden ? 'border-[#fbbf24]/40 text-[#fbbf24] bg-[#fbbf24]/10' : 'border-[#3fb950]/40 text-[#3fb950] bg-[#3fb950]/10'}`}>
                {hidden ? <><EyeOff size={10} /> Hidden</> : <><Eye size={10} /> Shown</>}
              </button>
            )}
          </div>
          <button onClick={onClose} className="text-[#484f58] hover:text-[#e6edf3] p-1"><X size={18} /></button>
        </div>

        {/* 3D Cosmic dice field */}
        <div className="relative h-48 bg-[#0B0F13] overflow-hidden">
          <DiceCosmosEngine roll={currentRoll} rolling={rolling} accent={accent} />
          {/* Result overlay */}
          {currentRoll && !rolling && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center">
                {(!currentRoll.hidden || !hidden) ? (
                  <>
                    <div className={`text-5xl font-bold font-heading ${currentRoll.crit ? 'text-[#3fb950]' : currentRoll.fumble ? 'text-[#f85149]' : ''}`} style={{ color: currentRoll.crit || currentRoll.fumble ? undefined : accent }}>
                      {currentRoll.total}
                    </div>
                    <div className="text-[10px] text-[#8b949e] mt-1">{currentRoll.expr}</div>
                    {currentRoll.crit && <div className="text-xs text-[#3fb950] font-bold animate-pulse">CRITICAL!</div>}
                    {currentRoll.fumble && <div className="text-xs text-[#f85149] font-bold">FUMBLE</div>}
                    {currentRoll.success !== null && (
                      <div className={`text-xs font-bold ${currentRoll.success ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>
                        {currentRoll.success ? 'SUCCESS' : 'FAILURE'} vs DC {currentRoll.dc}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-2xl text-[#fbbf24] font-bold animate-pulse">HIDDEN — Tap Reveal</div>
                )}
              </div>
            </div>
          )}
          {rolling && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-xs text-[#8b949e] animate-pulse flex items-center gap-1.5">
                <Sparkles size={12} style={{ color: accent }} /> Rolling through the cosmos...
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="p-4 space-y-3">
          {/* Die selection */}
          <div>
            <p className="text-[9px] text-[#8b949e] uppercase font-bold mb-1.5">Select Die</p>
            <div className="flex gap-1.5 flex-wrap">
              {DICE_TYPES.map((d) => (
                <button key={d.sides} onClick={() => setDieCount(d.sides)}
                  className={`px-3 py-2 border clip-corner text-xs font-bold font-mono transition-all touch-manipulation ${selectedDie === d.sides ? 'border-2' : 'border'}`}
                  style={{
                    borderColor: selectedDie === d.sides ? d.color : '#30363d',
                    background: selectedDie === d.sides ? `${d.color}20` : '#0d1117',
                    color: selectedDie === d.sides ? d.color : '#8b949e',
                  }}>
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          {/* Count + modifier + advantage */}
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">Count</label>
              <input type="number" min={1} max={20} value={count} onChange={(e) => setCount(Math.max(1, Math.min(20, Number(e.target.value))))}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
            </div>
            <div>
              <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">Modifier</label>
              <input type="number" value={modifier} onChange={(e) => setModifier(Number(e.target.value))}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
            </div>
            <div>
              <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">DC (0=off)</label>
              <input type="number" value={dc} onChange={(e) => setDc(Number(e.target.value))}
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
            </div>
          </div>

          {/* Advantage / Disadvantage (d20 only) */}
          {selectedDie === 20 && count === 1 && (
            <div className="flex gap-2">
              <button onClick={() => { setAdvantage(!advantage); setDisadvantage(false); }}
              className={`flex-1 px-2 py-1.5 border clip-corner text-[10px] font-bold touch-manipulation ${advantage ? 'border-[#3fb950] bg-[#3fb950]/15 text-[#3fb950]' : 'border-[#30363d] text-[#8b949e]'}`}>
                Advantage
              </button>
              <button onClick={() => { setDisadvantage(!disadvantage); setAdvantage(false); }}
              className={`flex-1 px-2 py-1.5 border clip-corner text-[10px] font-bold touch-manipulation ${disadvantage ? 'border-[#f85149] bg-[#f85149]/15 text-[#f85149]' : 'border-[#30363d] text-[#8b949e]'}`}>
                Disadvantage
              </button>
            </div>
          )}

          {/* Label */}
          <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Roll label (e.g. Attack roll, Fireball damage)..."
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />

          {/* Roll button */}
          <button onClick={handleRoll} disabled={rolling}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 text-black text-sm font-bold clip-corner disabled:opacity-50 touch-manipulation"
            style={{ background: accent }}>
            <Dices size={16} /> {rolling ? 'Rolling...' : `Roll ${expr}`}
          </button>

          {/* Reveal button for DM hidden rolls */}
          {isDm && currentRoll?.hidden && !rolling && (
            <button onClick={() => setHidden(false)}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 border border-[#fbbf24]/40 bg-[#fbbf24]/10 text-[#fbbf24] text-xs font-bold clip-corner touch-manipulation">
              <Eye size={14} /> Reveal to Party
            </button>
          )}

          {/* History */}
          {history.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[9px] text-[#8b949e] uppercase font-bold flex items-center gap-1"><History size={10} /> Recent Rolls</span>
                <button onClick={() => { clearHistory(); setHistory([]); }} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={10} /></button>
              </div>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {history.slice(0, 10).map((r) => (
                  <div key={r.id} className="flex items-center justify-between p-1.5 bg-[#0d1117] border border-[#30363d] clip-corner text-[10px]">
                    <span className="text-[#8b949e]">{r.label || r.expr}</span>
                    <div className="flex items-center gap-2">
                      {r.hidden && <EyeOff size={9} className="text-[#fbbf24]" />}
                      <span className="text-[#e6edf3] font-bold">{r.total}</span>
                      {r.crit && <span className="text-[#3fb950]">⚡</span>}
                      {r.fumble && <span className="text-[#f85149]">💀</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}