import { useState } from 'react';
import { Download, Star, Package } from 'lucide-react';

export default function PackCard({ pack, onInstall }) {
  const [installing, setInstalling] = useState(false);
  const tags = (() => { try { return JSON.parse(pack.tags_json || '[]'); } catch { return []; } })();
  const contents = (() => { try { return JSON.parse(pack.contents_json || '{}'); } catch { return {}; } })();
  const count = (contents.monsters?.length || 0) + (contents.spells?.length || 0) + (contents.items?.length || 0) + (contents.subclasses?.length || 0);
  const handle = async () => { setInstalling(true); await onInstall(); setInstalling(false); };
  return (
    <div className="tactical-hud glass-panel clip-corner p-3 flex flex-col gap-2">
      <div className="flex items-center gap-2">
        <div className="w-9 h-9 border border-[#bc8cff]/40 bg-[#bc8cff]/10 flex items-center justify-center clip-corner shrink-0"><Package size={16} className="text-[#bc8cff]" /></div>
        <div className="min-w-0">
          <div className="text-xs font-bold text-[#e6edf3] truncate">{pack.name}</div>
          <div className="text-[9px] text-[#484f58]">by {pack.author_name || 'Unknown'} · v{pack.version}</div>
        </div>
      </div>
      {pack.description && <p className="text-[10px] text-[#8b949e] leading-snug line-clamp-2">{pack.description}</p>}
      {tags.length > 0 && <div className="flex flex-wrap gap-1">{tags.slice(0, 4).map((t) => <span key={t} className="text-[8px] px-1.5 py-0.5 border border-[#bc8cff]/30 text-[#bc8cff] clip-corner">{t}</span>)}</div>}
      <div className="flex items-center justify-between text-[9px] text-[#484f58]">
        <span>{count} items</span>
        <span className="flex items-center gap-2"><span className="flex items-center gap-0.5"><Download size={9} /> {pack.install_count || 0}</span><span className="flex items-center gap-0.5"><Star size={9} /> {pack.rating || 0}</span></span>
      </div>
      <button onClick={handle} disabled={installing} className="flex items-center justify-center gap-1.5 px-3 py-2 bg-[#bc8cff] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">
        {installing ? 'Installing...' : <><Download size={12} /> Install</>}
      </button>
    </div>
  );
}