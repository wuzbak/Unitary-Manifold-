/**
 * Marketplace — browse, search, and install community homebrew packs. Install
 * copies the pack's embedded content into the user's own custom-entity library
 * as owned derivatives (via the dndMarketplace backend function).
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Search, Loader2, Store } from 'lucide-react';
import PackCard from './PackCard';

export default function Marketplace() {
  const [packs, setPacks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [msg, setMsg] = useState('');

  const load = useCallback(async (q) => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('dndMarketplace', { action: q ? 'search' : 'list', query: q });
      const d = res.data || res;
      setPacks(d.packs || []);
    } catch (e) { setMsg(`Error: ${e.message}`); }
    setLoading(false);
  }, []);
  useEffect(() => { load(''); }, [load]);

  const install = async (pack) => {
    setMsg(`Installing "${pack.name}"...`);
    try {
      const res = await base44.functions.invoke('dndMarketplace', { action: 'install', pack_id: pack.id });
      const d = res.data || res;
      if (d.error) setMsg(`Error: ${d.error}`);
      else { const c = d.installed; setMsg(`Installed "${pack.name}": ${c.monsters} monsters, ${c.spells} spells, ${c.items} items, ${c.subclasses} subclasses.`); load(query); }
    } catch (e) { setMsg(`Error: ${e.message}`); }
  };

  return (
    <div className="space-y-3">
      <div className="glass-panel clip-corner p-2.5">
        <p className="text-[10px] text-[#8b949e]"><span className="text-[#bc8cff] font-bold">Homebrew Marketplace</span> — Browse community content packs and install them into your library. Installing copies the content as your own owned derivatives.</p>
      </div>
      <div className="flex items-center gap-1.5 glass-panel clip-corner px-2 py-1.5">
        <Search size={13} className="text-[#484f58]" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && load(query)} placeholder="Search packs, authors, tags..." className="bg-transparent text-xs text-[#e6edf3] flex-1 focus:outline-none" />
        <button onClick={() => load(query)} className="text-[9px] text-[#bc8cff] font-bold">Search</button>
      </div>
      {msg && <div className="glass-panel clip-corner p-2 text-[10px] text-[#3fb950]">{msg}</div>}
      {loading ? (
        <div className="flex justify-center py-8"><Loader2 size={20} className="animate-spin text-[#bc8cff]" /></div>
      ) : packs.length === 0 ? (
        <div className="glass-panel clip-corner p-8 text-center"><Store size={24} className="mx-auto text-[#bc8cff]/40 mb-2" /><p className="text-[10px] text-[#8b949e]">No packs found. Publish one from the Homebrew Forge library.</p></div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {packs.map((p) => <PackCard key={p.id} pack={p} onInstall={() => install(p)} />)}
        </div>
      )}
    </div>
  );
}