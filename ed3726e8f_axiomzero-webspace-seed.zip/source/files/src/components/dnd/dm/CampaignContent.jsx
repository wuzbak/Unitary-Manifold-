import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, BookOpen, Users, Map, Coins, Image, Store, X, Sparkles, Send } from 'lucide-react';
import Marketplace from '@/components/dnd/shop/Marketplace';
import SessionRecapPanel from '@/components/dnd/dm/SessionRecapPanel';

const SUB_TABS = [
  { id: 'quests', label: 'Quests', icon: BookOpen },
  { id: 'npcs', label: 'NPCs', icon: Users },
  { id: 'maps', label: 'Maps', icon: Map },
  { id: 'treasure', label: 'Treasure', icon: Coins },
  { id: 'images', label: 'Images', icon: Image },
  { id: 'merchants', label: 'Merchants', icon: Store },
  { id: 'recap', label: 'Recap', icon: Sparkles },
];

export default function CampaignContent({ campaign }) {
  const [subTab, setSubTab] = useState('quests');
  const [data, setData] = useState({ quests: [], npcs: [], maps: [], treasure: [], images: [], merchants: [] });

  const loadAll = useCallback(async () => {
    if (!campaign) return;
    try {
      const [quests, npcs, maps, treasure, images] = await Promise.all([
        base44.entities.DnDQuest.filter({ campaign_id: campaign.id }, '-created_date', 50),
        base44.entities.DnDNpc.filter({ campaign_id: campaign.id }, '-created_date', 50),
        base44.entities.DnDMap.filter({ campaign_id: campaign.id }, '-created_date', 50),
        base44.entities.DnDTreasure.filter({ campaign_id: campaign.id }, '-created_date', 50),
        base44.entities.DnDSharedImage.filter({ campaign_id: campaign.id }, '-created_date', 50),
      ]);
      setData({ quests: quests || [], npcs: npcs || [], maps: maps || [], treasure: treasure || [], images: images || [], merchants: [] });
    } catch (e) { console.error('Load content:', e); }
  }, [campaign]);

  useEffect(() => { loadAll(); }, [loadAll]);
  useEffect(() => {
    const unsubs = [
      base44.entities.DnDQuest.subscribe(() => loadAll()),
      base44.entities.DnDNpc.subscribe(() => loadAll()),
      base44.entities.DnDMap.subscribe(() => loadAll()),
      base44.entities.DnDTreasure.subscribe(() => loadAll()),
      base44.entities.DnDSharedImage.subscribe(() => loadAll()),
    ];
    return () => unsubs.forEach((u) => u());
  }, [loadAll]);

  return (
    <div className="space-y-3">
      <div className="flex gap-1 overflow-x-auto pb-1">
        {SUB_TABS.map((t) => {
          const Icon = t.icon;
          const active = subTab === t.id;
          return (
            <button key={t.id} onClick={() => setSubTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold border clip-corner whitespace-nowrap transition-all touch-manipulation ${
                active ? 'border-[#FF9F00] bg-[#FF9F00]/15 text-[#FF9F00]' : 'border-[#30363d] bg-[#0d1117] text-[#8b949e]'
              }`}>
              <Icon size={12} /> {t.label}
            </button>
          );
        })}
      </div>

      {subTab === 'quests' && <QuestsPanel campaign={campaign} quests={data.quests} onRefresh={loadAll} />}
      {subTab === 'npcs' && <NpcsPanel campaign={campaign} npcs={data.npcs} onRefresh={loadAll} />}
      {subTab === 'maps' && <MapsPanel campaign={campaign} maps={data.maps} onRefresh={loadAll} />}
      {subTab === 'treasure' && <TreasurePanel campaign={campaign} treasure={data.treasure} onRefresh={loadAll} />}
      {subTab === 'images' && <ImagesPanel campaign={campaign} images={data.images} onRefresh={loadAll} />}
      {subTab === 'merchants' && <MerchantsPanel campaign={campaign} onRefresh={loadAll} />}
      {subTab === 'recap' && <SessionRecapPanel campaign={campaign} />}
    </div>
  );
}

function QuestsPanel({ campaign, quests, onRefresh }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: '', status: 'active', objective: '', reward: '' });
  const add = async () => {
    await base44.entities.DnDQuest.create({ ...form, campaign_id: campaign.id, notes_json: '[]' });
    setForm({ title: '', status: 'active', objective: '', reward: '' }); setShowForm(false); onRefresh();
  };
  const del = async (id) => { await base44.entities.DnDQuest.delete(id); onRefresh(); };
  const setStatus = async (q, status) => { await base44.entities.DnDQuest.update(q.id, { status }); onRefresh(); };
  return (
    <div className="space-y-2">
      <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> New Quest</button>
      {showForm && (
        <div className="glass-panel clip-corner p-3 space-y-2">
          <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Quest title..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <input value={form.objective} onChange={(e) => setForm({ ...form, objective: e.target.value })} placeholder="Objective..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <input value={form.reward} onChange={(e) => setForm({ ...form, reward: e.target.value })} placeholder="Reward..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <button onClick={add} disabled={!form.title.trim()} className="px-3 py-1.5 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">Add</button>
        </div>
      )}
      {quests.map((q) => (
        <div key={q.id} className="p-2.5 border border-[#30363d] bg-[#0d1117] clip-corner">
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold text-[#e6edf3]">{q.title}</span>
            <div className="flex gap-1">
              <select value={q.status} onChange={(e) => setStatus(q, e.target.value)} className="bg-[#0d1117] border border-[#30363d] px-1 py-0.5 text-[9px] clip-corner">
                {['active', 'completed', 'failed', 'abandoned'].map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
              <button onClick={() => del(q.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
            </div>
          </div>
          {q.objective && <p className="text-[10px] text-[#8b949e] mt-0.5">🎯 {q.objective}</p>}
          {q.reward && <p className="text-[10px] text-[#d29922] mt-0.5">💰 {q.reward}</p>}
        </div>
      ))}
      {quests.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No quests yet</p>}
    </div>
  );
}

function NpcsPanel({ campaign, npcs, onRefresh }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', role: '', location: '', attitude: 'indifferent' });
  const add = async () => {
    await base44.entities.DnDNpc.create({ ...form, campaign_id: campaign.id, notes_json: '[]' });
    setForm({ name: '', role: '', location: '', attitude: 'indifferent' }); setShowForm(false); onRefresh();
  };
  const del = async (id) => { await base44.entities.DnDNpc.delete(id); onRefresh(); };
  const attColor = { hostile: '#f85149', unfriendly: '#db6d28', indifferent: '#8b949e', friendly: '#3fb950', helpful: '#3b8bff' };
  return (
    <div className="space-y-2">
      <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> New NPC</button>
      {showForm && (
        <div className="glass-panel clip-corner p-3 space-y-2">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="NPC name..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <div className="grid grid-cols-2 gap-2">
            <input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} placeholder="Role..." className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
            <input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Location..." className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          </div>
          <select value={form.attitude} onChange={(e) => setForm({ ...form, attitude: e.target.value })} className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
            {['hostile', 'unfriendly', 'indifferent', 'friendly', 'helpful'].map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
          <button onClick={add} disabled={!form.name.trim()} className="px-3 py-1.5 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">Add</button>
        </div>
      )}
      {npcs.map((n) => (
        <div key={n.id} className="flex justify-between items-center p-2.5 border border-[#30363d] bg-[#0d1117] clip-corner">
          <div>
            <span className="text-xs font-bold text-[#e6edf3]">{n.name}</span>
            <span className="text-[9px] ml-2" style={{ color: attColor[n.attitude] }}>{n.attitude}</span>
            {n.role && <p className="text-[10px] text-[#8b949e]">{n.role} · {n.location}</p>}
          </div>
          <button onClick={() => del(n.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
        </div>
      ))}
      {npcs.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No NPCs yet</p>}
    </div>
  );
}

function MapsPanel({ campaign, maps, onRefresh }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', kind: 'region', image_url: '' });
  const add = async () => {
    await base44.entities.DnDMap.create({ ...form, campaign_id: campaign.id, fog_of_war: false, zones_json: '[]', tokens_json: '[]' });
    setForm({ name: '', kind: 'region', image_url: '' }); setShowForm(false); onRefresh();
  };
  const del = async (id) => { await base44.entities.DnDMap.delete(id); onRefresh(); };
  return (
    <div className="space-y-2">
      <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> New Map</button>
      {showForm && (
        <div className="glass-panel clip-corner p-3 space-y-2">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Map name..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
            {['world', 'region', 'town', 'dungeon', 'battle'].map((k) => <option key={k} value={k}>{k}</option>)}
          </select>
          <input value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="Image URL..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <button onClick={add} disabled={!form.name.trim()} className="px-3 py-1.5 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">Add</button>
        </div>
      )}
      <div className="grid sm:grid-cols-2 gap-2">
        {maps.map((m) => (
          <div key={m.id} className="border border-[#30363d] bg-[#0d1117] clip-corner overflow-hidden">
            {m.image_url && <img src={m.image_url} alt={m.name} className="w-full h-32 object-cover" />}
            <div className="p-2 flex justify-between">
              <div><span className="text-xs font-bold text-[#e6edf3]">{m.name}</span><span className="text-[9px] text-[#8b949e] ml-2">{m.kind}</span></div>
              <button onClick={() => del(m.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
            </div>
          </div>
        ))}
      </div>
      {maps.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No maps yet</p>}
    </div>
  );
}

function TreasurePanel({ campaign, treasure, onRefresh }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: '', gold: 0, items: '', recipients: '' });
  const add = async () => {
    await base44.entities.DnDTreasure.create({
      ...form, gold: Number(form.gold), campaign_id: campaign.id,
      items_json: JSON.stringify(form.items.split(',').map((s) => s.trim()).filter(Boolean)),
      recipients_json: JSON.stringify(form.recipients.split(',').map((s) => s.trim()).filter(Boolean)),
      notes_json: '[]',
    });
    setForm({ title: '', gold: 0, items: '', recipients: '' }); setShowForm(false); onRefresh();
  };
  const del = async (id) => { await base44.entities.DnDTreasure.delete(id); onRefresh(); };
  return (
    <div className="space-y-2">
      <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> New Treasure</button>
      {showForm && (
        <div className="glass-panel clip-corner p-3 space-y-2">
          <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Treasure title..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <input type="number" value={form.gold} onChange={(e) => setForm({ ...form, gold: e.target.value })} placeholder="Gold..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <input value={form.items} onChange={(e) => setForm({ ...form, items: e.target.value })} placeholder="Items (comma-separated)..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <input value={form.recipients} onChange={(e) => setForm({ ...form, recipients: e.target.value })} placeholder="Recipients (comma-separated)..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <button onClick={add} disabled={!form.title.trim()} className="px-3 py-1.5 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">Add</button>
        </div>
      )}
      {treasure.map((t) => {
        const items = JSON.parse(t.items_json || '[]'); const recips = JSON.parse(t.recipients_json || '[]');
        return (
          <div key={t.id} className="p-2.5 border border-[#30363d] bg-[#0d1117] clip-corner">
            <div className="flex justify-between">
              <span className="text-xs font-bold text-[#e6edf3]">{t.title}</span>
              <div className="flex gap-1"><span className="text-[10px] text-[#d29922]">{t.gold}gp</span><button onClick={() => del(t.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button></div>
            </div>
            {items.length > 0 && <p className="text-[10px] text-[#8b949e] mt-0.5">📦 {items.join(', ')}</p>}
            {recips.length > 0 && <p className="text-[10px] text-[#484f58]">→ {recips.join(', ')}</p>}
          </div>
        );
      })}
      {treasure.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No treasure logged yet</p>}
    </div>
  );
}

function ImagesPanel({ campaign, images, onRefresh }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: '', image_url: '', caption: '', audience: 'all_players' });
  const [generating, setGenerating] = useState(false);

  const buildBrief = () => {
    const setting = campaign.setting || 'fantasy world';
    const tone = campaign.tone || 'heroic';
    return `${setting}; tone=${tone}; subject=${form.title || 'party scene'}; preserve gear continuity, spell effects, heraldry, and environmental storytelling. Cinematic fantasy illustration, dramatic lighting, detailed.`;
  };

  const generateImage = async () => {
    setGenerating(true);
    try {
      const prompt = buildBrief();
      const res = await base44.integrations.Core.GenerateImage({ prompt });
      setForm((p) => ({ ...p, image_url: res.url }));
    } catch (e) { alert(`Image generation failed: ${e.message}`); }
    setGenerating(false);
  };

  const add = async () => {
    await base44.entities.DnDSharedImage.create({ ...form, campaign_id: campaign.id, tags_json: '[]' });
    setForm({ title: '', image_url: '', caption: '', audience: 'all_players' }); setShowForm(false); onRefresh();
  };
  const del = async (id) => { await base44.entities.DnDSharedImage.delete(id); onRefresh(); };

  return (
    <div className="space-y-2">
      <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner touch-manipulation"><Plus size={12} /> Push Image</button>
      {showForm && (
        <div className="glass-panel clip-corner p-3 space-y-2">
          <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Image title..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <textarea value={form.caption} onChange={(e) => setForm({ ...form, caption: e.target.value })} placeholder="Caption..." rows={2} className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <div className="glass-panel clip-corner p-2 text-[9px] text-[#8b949e]">
            <span className="text-[#FF9F00] font-bold">Grounded Brief:</span> {buildBrief()}
          </div>
          <button onClick={generateImage} disabled={generating} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#4dd0e1]/40 bg-[#4dd0e1]/10 text-[#4dd0e1] text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">
            <Sparkles size={12} /> {generating ? 'Generating...' : 'Generate Image'}
          </button>
          <input value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="Or paste image URL..." className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          {form.image_url && <img src={form.image_url} alt="preview" className="w-full h-32 object-cover clip-corner" />}
          <select value={form.audience} onChange={(e) => setForm({ ...form, audience: e.target.value })} className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
            {['all_players', 'specific_player', 'dm_only'].map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
          <button onClick={add} disabled={!form.title.trim() || !form.image_url.trim()} className="flex items-center gap-1.5 px-3 py-1.5 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation"><Send size={12} /> Push to Players</button>
        </div>
      )}
      <div className="grid sm:grid-cols-2 gap-2">
        {images.map((img) => (
          <div key={img.id} className="border border-[#30363d] bg-[#0d1117] clip-corner overflow-hidden">
            {img.image_url && <img src={img.image_url} alt={img.title} className="w-full h-32 object-cover" />}
            <div className="p-2">
              <div className="flex justify-between">
                <span className="text-xs font-bold text-[#e6edf3]">{img.title}</span>
                <button onClick={() => del(img.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
              </div>
              {img.caption && <p className="text-[10px] text-[#8b949e] mt-0.5">{img.caption}</p>}
              <span className="text-[8px] text-[#484f58]">{img.audience}</span>
            </div>
          </div>
        ))}
      </div>
      {images.length === 0 && <p className="text-[10px] text-[#484f58] text-center py-4">No shared images yet</p>}
    </div>
  );
}

function MerchantsPanel({ campaign, onRefresh }) {
  return (
    <div className="space-y-2">
      <p className="text-[10px] text-[#8b949e]">
        <span className="text-[#FF9F00] font-bold">Marketplace</span> — Dynamic shops with rotating inventory and pricing. Purchases deduct party gold. Player purchase requests appear here for approval.
      </p>
      <Marketplace mode="dm" campaign={campaign} onNotify={(msg) => { onRefresh?.(); /* lightweight toast via console for now */ console.log('[Marketplace]', msg); }} />
    </div>
  );
}