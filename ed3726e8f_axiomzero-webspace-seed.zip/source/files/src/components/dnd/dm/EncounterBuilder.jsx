import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Swords, Save, Play } from 'lucide-react';
import { computeEncounter, buildEncounter, buildCombatantsFromEncounter, suggestEncounterMonsters, DIFFICULTY_STYLES } from '@/lib/dnd/encounterEngine';
import { searchMonsters, MONSTER_ENVIRONMENTS } from '@/lib/dnd/compendium';
import StatBlock from '@/components/dnd/StatBlock';

export default function EncounterBuilder({ campaign, characters, onLiveState }) {
  const [encounters, setEncounters] = useState([]);
  const [selected, setSelected] = useState([]);
  const [title, setTitle] = useState('');
  const [search, setSearch] = useState('');
  const [envFilter, setEnvFilter] = useState('');
  const [showSuggested, setShowSuggested] = useState(false);

  const loadEncounters = useCallback(async () => {
    if (!campaign) return;
    try {
      const list = await base44.entities.DnDEncounter.filter({ campaign_id: campaign.id }, '-created_date', 50);
      setEncounters(list || []);
    } catch (e) { console.error('Load encounters:', e); }
  }, [campaign]);

  useEffect(() => { loadEncounters(); }, [loadEncounters]);
  useEffect(() => {
    const unsub = base44.entities.DnDEncounter.subscribe(() => loadEncounters());
    return unsub;
  }, [loadEncounters]);

  const partyLevels = characters.map((c) => c.level).length > 0 ? characters.map((c) => c.level) : [1];
  const stats = computeEncounter(selected, partyLevels);

  useEffect(() => {
    onLiveState?.((prev) => ({ ...prev, activeEncounter: { monsters: selected, difficulty: stats.difficulty, adjustedXp: stats.adjustedXp }, partyLevels }));
  }, [selected, stats, partyLevels, onLiveState]);

  const monsters = searchMonsters({ query: search, environment: envFilter || undefined });

  const addMonster = (slug) => setSelected((prev) => [...prev, slug]);
  const removeMonster = (i) => setSelected((prev) => prev.filter((_, idx) => idx !== i));

  const saveEncounter = async () => {
    try {
      const enc = buildEncounter(campaign.id, { title: title || 'Encounter', monsterSlugs: selected, partyLevels });
      await base44.entities.DnDEncounter.create(enc);
      setSelected([]); setTitle('');
      await loadEncounters();
    } catch (e) { alert(`Failed: ${e.message}`); }
  };

  const startCombat = async (encounter) => {
    try {
      await base44.entities.DnDEncounter.update(encounter.id, { status: 'active' });
      const combatants = buildCombatantsFromEncounter(encounter, campaign.id);
      if (combatants.length > 0) {
        await base44.entities.DnDCombatant.bulkCreate(combatants);
      }
      await loadEncounters();
    } catch (e) { alert(`Failed to start combat: ${e.message}`); }
  };

  const deleteEncounter = async (enc) => {
    if (!confirm(`Delete encounter "${enc.title}"?`)) return;
    try {
      await base44.entities.DnDEncounter.delete(enc.id);
      await loadEncounters();
    } catch (e) { alert(`Failed: ${e.message}`); }
  };

  const applySuggested = (suggested) => {
    setSelected(suggested.map((m) => m.slug));
    setShowSuggested(false);
  };

  return (
    <div className="space-y-3">
      {/* Difficulty display */}
      <div className="glass-strong clip-corner p-3" style={{ borderLeft: `3px solid ${stats.difficultyStyle.color}` }}>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-bold font-heading" style={{ color: stats.difficultyStyle.color }}>
            {stats.difficultyStyle.label} Encounter
          </h3>
          <span className="text-[10px] text-[#8b949e]">{stats.monsterCount} monster(s) · {stats.adjustedXp} XP</span>
        </div>
        <div className="grid grid-cols-4 gap-1.5 text-center text-[9px]">
          {['easy', 'medium', 'hard', 'deadly'].map((d) => (
            <div key={d} className={`p-1.5 border clip-corner ${stats.difficulty === d ? 'border-2' : 'border'}`}
              style={{ borderColor: DIFFICULTY_STYLES[d].color, background: stats.difficulty === d ? DIFFICULTY_STYLES[d].bg : 'transparent' }}>
              <div className="uppercase font-bold" style={{ color: DIFFICULTY_STYLES[d].color }}>{d}</div>
              <div className="text-[#8b949e]">{stats.thresholds[d]}</div>
            </div>
          ))}
        </div>
        <div className="text-[9px] text-[#484f58] mt-1.5">Base XP: {stats.baseXp} · Multiplier: ×{stats.monsterCount <= 1 ? '1.0' : stats.monsterCount <= 2 ? '1.5' : stats.monsterCount <= 3 ? '2.0' : stats.monsterCount <= 6 ? '2.5' : stats.monsterCount <= 10 ? '3.0' : '4.0'}</div>
      </div>

      {/* Selected monsters */}
      <div className="glass-panel clip-corner p-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] text-[#FF9F00] font-bold uppercase">Selected ({selected.length})</span>
          {selected.length > 0 && (
            <div className="flex gap-1.5">
              <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Encounter title..."
                className="bg-[#0d1117] border border-[#30363d] px-2 py-1 text-[10px] text-[#e6edf3] clip-corner w-32" />
              <button onClick={saveEncounter} className="flex items-center gap-1 px-2 py-1 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner touch-manipulation"><Save size={10} /> Save</button>
            </div>
          )}
        </div>
        {selected.length === 0 ? (
          <p className="text-[10px] text-[#484f58] text-center py-2">Click monsters below to add them</p>
        ) : (
          <div className="flex flex-wrap gap-1.5">
            {selected.map((slug, i) => {
              const m = stats.monsters[i];
              return (
                <div key={i} className="flex items-center gap-1 px-2 py-1 bg-[#0d1117] border border-[#30363d] clip-corner text-[10px]">
                  <span className="text-[#e6edf3]">{m?.name || slug}</span>
                  <span className="text-[#FF9F00]">{m?.xp || 0}xp</span>
                  <button onClick={() => removeMonster(i)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={10} /></button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Suggested encounters */}
      <div className="flex gap-2">
        <button onClick={() => setShowSuggested(!showSuggested)}
          className="flex items-center gap-1.5 px-3 py-1.5 border border-[#4dd0e1]/40 bg-[#4dd0e1]/10 text-[#4dd0e1] text-[10px] font-bold clip-corner touch-manipulation">
          <Swords size={12} /> Suggest Balanced
        </button>
      </div>
      {showSuggested && (
        <div className="glass-panel clip-corner p-2 space-y-1.5">
          <p className="text-[9px] text-[#8b949e] uppercase font-bold">Suggested for {partyLevels.join('/')} party</p>
          {['easy', 'medium', 'hard', 'deadly'].map((diff) => {
            const suggested = suggestEncounterMonsters(partyLevels, diff);
            return (
              <button key={diff} onClick={() => applySuggested(suggested)}
                className="w-full text-left p-2 border border-[#30363d] bg-[#0d1117] clip-corner hover:border-[#FF9F00]/40">
                <span className="text-[10px] font-bold" style={{ color: DIFFICULTY_STYLES[diff].color }}>{diff.toUpperCase()}</span>
                <span className="text-[10px] text-[#8b949e] ml-2">{suggested.map((m) => m.name).join(', ') || '—'}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Monster search */}
      <div className="flex gap-2">
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search monsters..."
          className="flex-1 bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        <select value={envFilter} onChange={(e) => setEnvFilter(e.target.value)}
          className="bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-[10px] text-[#e6edf3] clip-corner">
          <option value="">All Env</option>
          {MONSTER_ENVIRONMENTS.map((e) => <option key={e} value={e}>{e}</option>)}
        </select>
      </div>

      {/* Monster list */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5 max-h-[50vh] overflow-y-auto">
        {monsters.map((m) => (
          <button key={m.slug} onClick={() => addMonster(m.slug)}
            className="flex flex-col p-2 border border-[#30363d] bg-[#0d1117] clip-corner hover:border-[#FF9F00]/40 text-left touch-manipulation">
            <span className="text-[10px] font-bold text-[#e6edf3] truncate">{m.name}</span>
            <span className="text-[9px] text-[#FF9F00]">CR {m.cr} · {m.xp}xp</span>
            <span className="text-[8px] text-[#484f58]">{m.type} · {m.environment}</span>
          </button>
        ))}
      </div>

      {/* Saved encounters */}
      {encounters.length > 0 && (
        <div>
          <p className="text-[10px] text-[#8b949e] uppercase font-bold mb-1.5">Saved Encounters</p>
          <div className="space-y-1.5">
            {encounters.map((enc) => {
              const encStats = computeEncounter(
                typeof enc.monster_slugs_json === 'string' ? JSON.parse(enc.monster_slugs_json) : [],
                partyLevels
              );
              return (
                <div key={enc.id} className="flex items-center justify-between p-2 border border-[#30363d] bg-[#0d1117] clip-corner">
                  <div>
                    <span className="text-xs font-bold text-[#e6edf3]">{enc.title}</span>
                    <span className="text-[9px] ml-2" style={{ color: DIFFICULTY_STYLES[enc.difficulty]?.color }}>{enc.difficulty}</span>
                    <span className="text-[9px] text-[#484f58] ml-1">· {enc.adjusted_xp}xp · {enc.status}</span>
                  </div>
                  <div className="flex gap-1">
                    {enc.status === 'planned' && (
                      <button onClick={() => startCombat(enc)} className="flex items-center gap-1 px-2 py-1 bg-[#3fb950]/20 border border-[#3fb950]/40 text-[#3fb950] text-[9px] font-bold clip-corner touch-manipulation"><Play size={10} /> Start</button>
                    )}
                    <button onClick={() => deleteEncounter(enc)} className="p-1 text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}