/**
 * SessionRecapPanel — generates a Merlin-distilled session recap and next-
 * session prep brief from recent rolls, encounters, and party state via the
 * dndSessionRecap backend function.
 */
import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Sparkles, Loader2, BookOpen, ListChecks } from 'lucide-react';

export default function SessionRecapPanel({ campaign }) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const generate = async () => {
    setLoading(true); setError(''); setResult(null);
    try {
      const res = await base44.functions.invoke('dndSessionRecap', { campaign_id: campaign.id });
      const d = res.data || res;
      if (d.error) setError(d.error); else setResult(d);
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  return (
    <div className="space-y-3">
      <div className="glass-panel clip-corner p-3">
        <p className="text-[10px] text-[#8b949e] mb-2">Merlin distills recent rolls, encounters, and party state into a session recap and a next-session prep brief.</p>
        <button onClick={generate} disabled={loading || !campaign}
          className="flex items-center gap-1.5 px-3 py-2 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner disabled:opacity-50 touch-manipulation">
          {loading ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />} Generate Session Recap
        </button>
        {error && <p className="text-[10px] text-[#f85149] mt-2">{error}</p>}
      </div>
      {result && (
        <div className="space-y-3">
          <div className="glass-strong clip-corner p-3">
            <div className="flex items-center gap-1.5 mb-2"><BookOpen size={13} className="text-[#FF9F00]" /><span className="text-[10px] font-bold text-[#FF9F00] uppercase tracking-wider">Recap</span></div>
            <p className="text-[11px] text-[#c9d1d9] leading-relaxed whitespace-pre-wrap">{result.recap}</p>
          </div>
          <div className="glass-strong clip-corner p-3">
            <div className="flex items-center gap-1.5 mb-2"><ListChecks size={13} className="text-[#4dd0e1]" /><span className="text-[10px] font-bold text-[#4dd0e1] uppercase tracking-wider">Next Session Prep</span></div>
            <p className="text-[11px] text-[#c9d1d9] leading-relaxed whitespace-pre-wrap">{result.prep_brief}</p>
            {result.open_threads?.length > 0 && (
              <div className="mt-2 space-y-1">
                {result.open_threads.map((t, i) => <div key={i} className="text-[10px] text-[#8b949e] border-l-2 border-[#4dd0e1]/40 pl-2 py-0.5">{t}</div>)}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}