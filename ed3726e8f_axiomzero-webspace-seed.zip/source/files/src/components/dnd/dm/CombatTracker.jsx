import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Play, Pause, SkipForward, Plus, Trash2, Heart, Shield, Swords, Dices, X } from 'lucide-react';
import { rollAllInitiative, makeMonsterCombatant, makeCharacterCombatant, damageCombatant, healCombatant, addCondition, removeCondition, tickConditions, getActiveCombatant } from '@/lib/dnd/combatEngine';
import { searchMonsters, CONDITIONS, getMonster } from '@/lib/dnd/compendium';
import ConditionBadges from '@/components/dnd/ConditionBadges';

export default function CombatTracker({ campaign, characters, onLiveState }) {
  const [combatants, setCombatants] = useState([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [round, setRound] = useState(1);
  const [combatActive, setCombatActive] = useState(false);
  const [showAddMonster, setShowAddMonster] = useState(false);
  const [monsterSearch, setMonsterSearch] = useState('');
  const [activeEncounter, setActiveEncounter] = useState(null);
  const [damageInput, setDamageInput] = useState({});

  const loadCombatants = useCallback(async () => {
    if (!campaign) return;
    try {
      const encounters = await base44.entities.DnDEncounter.filter({ campaign_id: campaign.id, status: 'active' }, '-created_date', 5);
      const active = encounters[0];
      setActiveEncounter(active);
      if (active) {
        const list = await base44.entities.DnDCombatant.filter({ encounter_id: active.id }, 'sort_order', 50);
        setCombatants(list || []);
        setCombatActive(true);
      } else {
        setCombatants([]);
        setCombatActive(false);
      }
    } catch (e) { console.error('Load combatants:', e); }
  }, [campaign]);

  useEffect(() => { loadCombatants(); }, [loadCombatants]);
  useEffect(() => {
    const unsub = base44.entities.DnDCombatant.subscribe(() => loadCombatants());
    return unsub;
  }, [loadCombatants]);

  const sorted = [...combatants].sort((a, b) => (b.initiative || 0) - (a.initiative || 0));
  const activeCombatant = sorted[activeIndex];

  useEffect(() => {
    onLiveState?.((prev) => ({
      ...prev,
      combatActive,
      activeEncounter: activeEncounter ? { title: activeEncounter.title, status: activeEncounter.status } : null,
      combatants: sorted.map((c) => ({ name: c.name, hp: c.hp_current, initiative: c.initiative, type: c.type })),
      round,
      activeCombatantName: activeCombatant?.name,
    }));
  }, [combatActive, activeEncounter, sorted, round, activeCombatant, onLiveState]);

  const startCombat = async () => {
    try {
      const enc = await base44.entities.DnDEncounter.create({
        campaign_id: campaign.id, title: 'Ad-hoc Combat', monster_slugs_json: '[]',
        adjusted_xp: 0, difficulty: 'trivial', battlefield_notes_json: '[]', status: 'active',
      });
      setActiveEncounter(enc);
      setCombatActive(true);
      setRound(1); setActiveIndex(0);
    } catch (e) { alert(`Failed: ${e.message}`); }
  };

  const rollInit = async () => {
    const rolled = rollAllInitiative(combatants);
    for (const c of rolled) {
      await base44.entities.DnDCombatant.update(c.id, { initiative: c.initiative, sort_order: c.sort_order });
    }
    await loadCombatants();
  };

  const addPartyToCombat = async () => {
    if (!activeEncounter) return;
    const newCombatants = characters.map((c) => makeCharacterCombatant(c, activeEncounter.id, campaign.id));
    if (newCombatants.length > 0) {
      await base44.entities.DnDCombatant.bulkCreate(newCombatants);
      await loadCombatants();
    }
  };

  const addMonster = async (slug) => {
    if (!activeEncounter) return;
    const combatant = makeMonsterCombatant(slug, activeEncounter.id, campaign.id, 1)[0];
    await base44.entities.DnDCombatant.create(combatant);
    await loadCombatants();
  };

  const applyDamage = async (combatant, dmg) => {
    const { hp_current, temp_hp } = damageCombatant(combatant, Number(dmg));
    await base44.entities.DnDCombatant.update(combatant.id, { hp_current, temp_hp });
    await loadCombatants();
  };

  const applyHeal = async (combatant, heal) => {
    const { hp_current } = healCombatant(combatant, Number(heal));
    await base44.entities.DnDCombatant.update(combatant.id, { hp_current });
    await loadCombatants();
  };

  const nextTurn = async () => {
    // Tick conditions on the current combatant
    if (activeCombatant) {
      const { conditions_json } = tickConditions(activeCombatant);
      await base44.entities.DnDCombatant.update(activeCombatant.id, { conditions_json });
    }
    let nextIdx = activeIndex + 1;
    let nextRound = round;
    if (nextIdx >= sorted.length) { nextIdx = 0; nextRound += 1; }
    setActiveIndex(nextIdx);
    setRound(nextRound);
    await loadCombatants();
  };

  const endCombat = async () => {
    if (!confirm('End combat? All combatants will be removed.')) return;
    if (activeEncounter) {
      await base44.entities.DnDEncounter.update(activeEncounter.id, { status: 'completed' });
      const ids = combatants.map((c) => c.id);
      if (ids.length > 0) await base44.entities.DnDCombatant.deleteMany({ id: { $in: ids } });
    }
    setCombatActive(false); setCombatants([]); setActiveIndex(0); setRound(1);
    await loadCombatants();
  };

  const toggleCondition = async (combatant, condName) => {
    const conditions = JSON.parse(combatant.conditions_json || '[]');
    const has = conditions.find((c) => (c.name || c) === condName);
    if (has) {
      const update = removeCondition(combatant, condName);
      await base44.entities.DnDCombatant.update(combatant.id, update);
    } else {
      const update = addCondition(combatant, condName, 0, 'DM');
      if (update) await base44.entities.DnDCombatant.update(combatant.id, update);
    }
    await loadCombatants();
  };

  const removeCombatant = async (c) => {
    await base44.entities.DnDCombatant.delete(c.id);
    await loadCombatants();
  };

  if (!combatActive) {
    return (
      <div className="glass-panel clip-corner p-6 text-center">
        <Swords size={32} className="mx-auto text-[#FF9F00]/50 mb-3" />
        <h3 className="text-sm font-bold text-[#e6edf3] mb-1">No Active Combat</h3>
        <p className="text-[10px] text-[#8b949e] mb-4">Start combat from a saved encounter, or begin an ad-hoc combat.</p>
        <button onClick={startCombat}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#FF9F00] text-black text-xs font-bold clip-corner mx-auto touch-manipulation">
          <Play size={14} /> Start Combat
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Combat header */}
      <div className="glass-strong clip-corner p-3 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="text-sm font-bold text-[#FF9F00] font-heading">Round {round}</span>
          <span className="text-[10px] text-[#8b949e]">Turn: {activeCombatant?.name || '—'}</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <button onClick={rollInit} className="flex items-center gap-1 px-2 py-1.5 border border-[#30363d] text-[#8b949e] text-[10px] clip-corner hover:text-[#FF9F00] touch-manipulation"><Dices size={12} /> Roll Init</button>
          <button onClick={addPartyToCombat} className="flex items-center gap-1 px-2 py-1.5 border border-[#30363d] text-[#8b949e] text-[10px] clip-corner hover:text-[#FF9F00] touch-manipulation"><Plus size={12} /> Party</button>
          <button onClick={() => setShowAddMonster(true)} className="flex items-center gap-1 px-2 py-1.5 border border-[#30363d] text-[#8b949e] text-[10px] clip-corner hover:text-[#FF9F00] touch-manipulation"><Plus size={12} /> Monster</button>
          <button onClick={nextTurn} className="flex items-center gap-1 px-2 py-1.5 bg-[#FF9F00] text-black text-[10px] font-bold clip-corner touch-manipulation"><SkipForward size={12} /> Next</button>
          <button onClick={endCombat} className="flex items-center gap-1 px-2 py-1.5 border border-[#f85149]/40 text-[#f85149] text-[10px] clip-corner touch-manipulation">End</button>
        </div>
      </div>

      {/* Initiative order */}
      <div className="space-y-1.5">
        {sorted.map((c, i) => {
          const isActive = i === activeIndex;
          const isDead = c.hp_current <= 0;
          const hpPct = c.hp_max > 0 ? (c.hp_current / c.hp_max) * 100 : 0;
          const hpColor = hpPct > 50 ? '#3fb950' : hpPct > 25 ? '#d29922' : '#f85149';
          return (
            <div key={c.id} className={`p-2.5 border clip-corner transition-all ${isActive ? 'border-[#FF9F00] bg-[#FF9F00]/10 neon-edge-amber' : 'border-[#30363d] bg-[#0d1117]'} ${isDead ? 'opacity-40' : ''}`}>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#FF9F00] w-8 text-center">{c.initiative}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#e6edf3] truncate">{c.name}</span>
                    {c.type === 'character' && <span className="text-[8px] px-1 border border-[#4dd0e1]/40 text-[#4dd0e1] clip-corner">PC</span>}
                    {c.type === 'monster' && <span className="text-[8px] px-1 border border-[#f85149]/40 text-[#f85149] clip-corner">NPC</span>}
                    {isDead && <span className="text-[8px] text-[#f85149] font-bold">DEAD</span>}
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[9px] text-[#8b949e] flex items-center gap-0.5"><Heart size={9} /> {c.hp_current}/{c.hp_max}</span>
                    <span className="text-[9px] text-[#8b949e] flex items-center gap-0.5"><Shield size={9} /> {c.ac}</span>
                    <ConditionBadges conditions={c.conditions_json} onRemove={(name) => toggleCondition(c, name)} />
                  </div>
                  <div className="h-1 bg-[#0d1117] mt-1 clip-corner overflow-hidden">
                    <div className="h-full transition-all" style={{ width: `${Math.max(0, hpPct)}%`, background: hpColor }} />
                  </div>
                </div>
                <button onClick={() => removeCombatant(c)} className="text-[#484f58] hover:text-[#f85149] p-1"><X size={12} /></button>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap gap-1 mt-1.5">
                <input type="number" placeholder="dmg" value={damageInput[c.id] || ''}
                  onChange={(e) => setDamageInput({ ...damageInput, [c.id]: e.target.value })}
                  className="w-14 bg-[#0d1117] border border-[#30363d] px-1 py-0.5 text-[10px] text-[#e6edf3] clip-corner" />
                <button onClick={() => { applyDamage(c, damageInput[c.id] || 0); setDamageInput({ ...damageInput, [c.id]: '' }); }}
                  className="px-1.5 py-0.5 bg-[#f85149]/20 border border-[#f85149]/40 text-[#f85149] text-[9px] font-bold clip-corner touch-manipulation">Dmg</button>
                <button onClick={() => applyHeal(c, damageInput[c.id] || 0)}
                  className="px-1.5 py-0.5 bg-[#3fb950]/20 border border-[#3fb950]/40 text-[#3fb950] text-[9px] font-bold clip-corner touch-manipulation">Heal</button>
                <select onChange={(e) => { if (e.target.value) toggleCondition(c, e.target.value); e.target.value = ''; }}
                  className="bg-[#0d1117] border border-[#30363d] px-1 py-0.5 text-[9px] text-[#8b949e] clip-corner">
                  <option value="">+Cond</option>
                  {CONDITIONS.map((cd) => <option key={cd.slug} value={cd.name}>{cd.name}</option>)}
                </select>
              </div>

              {/* Monster quick-ref */}
              {c.type === 'monster' && c.ref_id && (() => {
                const m = getMonster(c.ref_id);
                return m?.signature_abilities?.length > 0 ? (
                  <div className="mt-1 text-[8px] text-[#484f58]">
                    <span className="text-[#FF9F00]">Abilities:</span> {m.signature_abilities.join(' · ')}
                  </div>
                ) : null;
              })()}
            </div>
          );
        })}
      </div>

      {/* Add monster modal */}
      {showAddMonster && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-3" onClick={() => setShowAddMonster(false)}>
          <div className="glass-strong clip-corner w-full max-w-md max-h-[70vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="p-3 border-b border-[#30363d] flex justify-between">
              <h3 className="text-sm font-bold text-[#FF9F00]">Add Monster</h3>
              <button onClick={() => setShowAddMonster(false)} className="text-[#484f58]"><X size={16} /></button>
            </div>
            <input value={monsterSearch} onChange={(e) => setMonsterSearch(e.target.value)} placeholder="Search..."
              className="w-full m-3 p-2 bg-[#0d1117] border border-[#30363d] text-xs text-[#e6edf3] clip-corner" />
            <div className="px-3 pb-3 space-y-1">
              {searchMonsters({ query: monsterSearch }).map((m) => (
                <button key={m.slug} onClick={() => { addMonster(m.slug); }}
                  className="w-full text-left p-2 border border-[#30363d] bg-[#0d1117] clip-corner hover:border-[#FF9F00]/40">
                  <span className="text-xs font-bold text-[#e6edf3]">{m.name}</span>
                  <span className="text-[9px] text-[#FF9F00] ml-2">CR {m.cr}</span>
                  <span className="text-[9px] text-[#484f58] ml-1">· {m.hp} HP · AC {m.ac}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}