import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, ScrollText, Swords, Users, Map, BookOpen, Package, Image, Search, Copy, RefreshCw, Trash2, Dices, Globe, Hammer, Store } from 'lucide-react';
import { generateInviteCode } from '@/lib/dnd/rules';
import EncounterBuilder from '@/components/dnd/dm/EncounterBuilder';
import CombatTracker from '@/components/dnd/dm/CombatTracker';
import CampaignContent from '@/components/dnd/dm/CampaignContent';
import CharacterSheet from '@/components/dnd/CharacterSheet';
import CharacterBuilder from '@/components/dnd/CharacterBuilder';
import CompendiumBrowser from '@/components/dnd/CompendiumBrowser';
import CosmicDiceChamber from '@/components/dnd/dice/CosmicDiceChamber';
import CosmicDiceModal from '@/components/dnd/dice/CosmicDiceModal';
import BattlemapTab from '@/components/dnd/vtt/BattlemapTab';
import WorldForge from '@/components/dnd/world/WorldForge';
import HomebrewForge from '@/components/dnd/forge/HomebrewForge';
import Marketplace from '@/components/dnd/market/Marketplace';
import { logRoll } from '@/lib/dnd/rollLog';

const ACCENT = '#FF9F00';

export default function DmDashboard({ campaigns, activeCampaign, setActiveCampaign, onRefresh, onLiveState }) {
  const [tab, setTab] = useState('campaign');
  const [characters, setCharacters] = useState([]);
  const [players, setPlayers] = useState([]);
  const [showCreate, setShowCreate] = useState(false);
  const [showCharBuilder, setShowCharBuilder] = useState(false);
  const [editingChar, setEditingChar] = useState(null);
  const [diceModalOpen, setDiceModalOpen] = useState(false);

  const loadCampaignData = useCallback(async () => {
    if (!activeCampaign) { setCharacters([]); setPlayers([]); return; }
    try {
      const [chars, pls] = await Promise.all([
        base44.entities.DnDCharacter.filter({ campaign_id: activeCampaign.id }, '-created_date', 50),
        base44.entities.DnDPlayer.filter({ campaign_id: activeCampaign.id }, '-created_date', 20),
      ]);
      setCharacters(chars || []);
      setPlayers(pls || []);
    } catch (e) { console.error('Load campaign data:', e); }
  }, [activeCampaign]);

  useEffect(() => { loadCampaignData(); }, [loadCampaignData]);

  useEffect(() => {
    const unsub1 = base44.entities.DnDCharacter.subscribe(() => loadCampaignData());
    const unsub2 = base44.entities.DnDPlayer.subscribe(() => loadCampaignData());
    return () => { unsub1(); unsub2(); };
  }, [loadCampaignData]);

  useEffect(() => {
    if (activeCampaign && characters.length > 0) {
      onLiveState?.((prev) => ({ ...prev, activeCampaign: { name: activeCampaign.name, setting: activeCampaign.setting, rules_edition: activeCampaign.rules_edition, tone: activeCampaign.tone }, partyLevels: characters.map((c) => c.level), partySize: characters.length }));
    }
  }, [activeCampaign, characters, onLiveState]);

  const createCampaign = async (data) => {
    try {
      const payload = {
        ...data,
        invite_code: generateInviteCode(),
        status: 'active',
      };
      const camp = await base44.entities.DnDCampaign.create(payload);
      await onRefresh();
      setActiveCampaign(camp);
      setShowCreate(false);
    } catch (e) { alert(`Failed to create campaign: ${e.message}`); }
  };

  const regenerateCode = async () => {
    if (!activeCampaign) return;
    try {
      await base44.entities.DnDCampaign.update(activeCampaign.id, { invite_code: generateInviteCode() });
      await onRefresh();
    } catch (e) { alert(`Failed: ${e.message}`); }
  };

  const removePlayer = async (player) => {
    if (!confirm(`Remove ${player.display_name} from the campaign?`)) return;
    try {
      await base44.entities.DnDPlayer.delete(player.id);
      await loadCampaignData();
    } catch (e) { alert(`Failed: ${e.message}`); }
  };

  const copyCode = () => {
    navigator.clipboard?.writeText(activeCampaign.invite_code);
  };

  const TABS = [
    { id: 'campaign', label: 'Campaign', icon: ScrollText },
    { id: 'party', label: 'Party', icon: Users },
    { id: 'encounters', label: 'Encounters', icon: Swords },
    { id: 'combat', label: 'Combat', icon: Swords },
    { id: 'battlemap', label: 'Battlemap', icon: Map },
    { id: 'dice', label: 'Dice', icon: Dices },
    { id: 'content', label: 'Content', icon: BookOpen },
    { id: 'world', label: 'World', icon: Globe },
    { id: 'forge', label: 'Forge', icon: Hammer },
    { id: 'market', label: 'Market', icon: Store },
    { id: 'compendium', label: 'Compendium', icon: Search },
  ];

  if (!activeCampaign && !showCreate) {
    return (
      <div className="space-y-3">
        <div className="glass-panel clip-corner p-6 text-center">
          <ScrollText size={32} className="mx-auto text-[#FF9F00]/50 mb-3" />
          <h3 className="text-sm font-bold text-[#e6edf3] mb-1">No Campaign Selected</h3>
          <p className="text-[10px] text-[#8b949e] mb-4">Create a new campaign to start managing your party, encounters, and content.</p>
          <button onClick={() => setShowCreate(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#FF9F00] text-black text-xs font-bold clip-corner mx-auto touch-manipulation">
            <Plus size={14} /> Create Campaign
          </button>
        </div>
        {campaigns.length > 0 && (
          <div className="space-y-1.5">
            <p className="text-[10px] text-[#8b949e] uppercase font-bold">Your Campaigns</p>
            {campaigns.map((c) => (
              <button key={c.id} onClick={() => setActiveCampaign(c)}
                className="w-full text-left p-3 border border-[#30363d] bg-[#0d1117] clip-corner hover:border-[#FF9F00]/40 transition-all">
                <div className="flex justify-between">
                  <span className="text-sm font-bold text-[#e6edf3]">{c.name}</span>
                  <span className="text-[9px] text-[#FF9F00]">{c.rules_edition}</span>
                </div>
                <p className="text-[10px] text-[#8b949e]">{c.setting} · {c.tone}</p>
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  if (showCreate) return <CreateCampaignForm onCreate={createCampaign} onCancel={() => setShowCreate(false)} />;

  return (
    <div className="space-y-3">
      {/* Campaign header */}
      <div className="glass-strong clip-corner p-3 flex flex-wrap items-center justify-between gap-2">
        <div className="min-w-0">
          <h2 className="text-base font-bold text-[#e6edf3] font-heading">{activeCampaign.name}</h2>
          <p className="text-[10px] text-[#8b949e]">{activeCampaign.setting} · {activeCampaign.rules_edition} · {activeCampaign.tone}</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 glass-panel clip-corner px-2 py-1.5">
            <span className="text-[9px] text-[#8b949e] uppercase">Invite</span>
            <span className="text-sm font-bold text-[#FF9F00] font-mono tracking-wider">{activeCampaign.invite_code}</span>
            <button onClick={copyCode} className="text-[#484f58] hover:text-[#FF9F00]"><Copy size={12} /></button>
          </div>
          <button onClick={regenerateCode} title="Regenerate code" className="p-1.5 border border-[#30363d] text-[#8b949e] hover:text-[#FF9F00] clip-corner touch-manipulation"><RefreshCw size={12} /></button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto pb-1">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold border clip-corner whitespace-nowrap transition-all touch-manipulation ${
                active ? 'border-[#FF9F00] bg-[#FF9F00]/15 text-[#FF9F00]' : 'border-[#30363d] bg-[#0d1117] text-[#8b949e] hover:border-[#FF9F00]/30'
              }`}>
              <Icon size={12} /> {t.label}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      {tab === 'campaign' && <CampaignInfo campaign={activeCampaign} onUpdate={async (data) => { await base44.entities.DnDCampaign.update(activeCampaign.id, data); await onRefresh(); }} />}
      {tab === 'party' && (
        <div className="space-y-3">
          <div className="grid sm:grid-cols-2 gap-3">
            {characters.map((c) => (
              <CharacterSheet key={c.id} character={c} onEdit={(ch) => { setEditingChar(ch); setShowCharBuilder(true); }} />
            ))}
            {characters.length === 0 && (
              <div className="glass-panel clip-corner p-4 text-center sm:col-span-2">
                <p className="text-[10px] text-[#8b949e]">No characters yet. Share invite code <span className="text-[#FF9F00] font-bold">{activeCampaign.invite_code}</span> with players, or add an NPC character.</p>
                <button onClick={() => { setEditingChar(null); setShowCharBuilder(true); }}
                  className="mt-2 flex items-center gap-1.5 px-3 py-2 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner mx-auto touch-manipulation">
                  <Plus size={12} /> Add Character
                </button>
              </div>
            )}
          </div>
          {players.length > 0 && (
            <div>
              <p className="text-[10px] text-[#8b949e] uppercase font-bold mb-1.5">Joined Players</p>
              <div className="space-y-1">
                {players.map((p) => (
                  <div key={p.id} className="flex items-center justify-between p-2 border border-[#30363d] bg-[#0d1117] clip-corner">
                    <span className="text-xs text-[#e6edf3]">{p.display_name}</span>
                    <button onClick={() => removePlayer(p)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={12} /></button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
      {tab === 'encounters' && <EncounterBuilder campaign={activeCampaign} characters={characters} onLiveState={onLiveState} />}
      {tab === 'combat' && <CombatTracker campaign={activeCampaign} characters={characters} onLiveState={onLiveState} />}
      {tab === 'battlemap' && <BattlemapTab campaign={activeCampaign} characters={characters} />}
      {tab === 'dice' && (
        <div className="space-y-3">
          <CosmicDiceChamber onOpenModal={() => setDiceModalOpen(true)} mode="dm" accent={ACCENT} />
          <div className="glass-panel clip-corner p-3">
            <p className="text-[10px] text-[#8b949e]">
              <span className="text-[#FF9F00] font-bold">DM Cosmic Dice</span> — Roll dice through the toroidal universe. Use the inline chamber for quick rolls, or open the full modal for advantage/disadvantage, DC checks, and hidden rolls.
            </p>
          </div>
        </div>
      )}
      {tab === 'content' && <CampaignContent campaign={activeCampaign} />}
      {tab === 'world' && <WorldForge campaign={activeCampaign} />}
      {tab === 'forge' && <HomebrewForge campaignId={activeCampaign?.id} />}
      {tab === 'market' && <Marketplace />}
      {tab === 'compendium' && <CompendiumBrowser />}

      <CosmicDiceModal isOpen={diceModalOpen} onClose={() => setDiceModalOpen(false)} mode="dm" accent={ACCENT} onRollLogged={(roll) => logRoll(activeCampaign?.id, '', '', activeCampaign?.dm_name || 'DM', roll)} />

      {showCharBuilder && (
        <CharacterBuilder
          character={editingChar}
          solo={false}
          campaignId={activeCampaign.id}
          onCancel={() => setShowCharBuilder(false)}
          onSave={() => { setShowCharBuilder(false); loadCampaignData(); }}
        />
      )}
    </div>
  );
}

function CreateCampaignForm({ onCreate, onCancel }) {
  const [form, setForm] = useState({ name: '', setting: 'Original fantasy world', rules_edition: '5e-2024', tone: 'heroic', summary: '', dm_name: 'Dungeon Master' });
  const update = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  return (
    <div className="glass-strong clip-corner p-4 max-w-lg mx-auto">
      <h3 className="text-sm font-bold text-[#FF9F00] mb-3 font-heading">Create New Campaign</h3>
      <div className="space-y-3">
        <Input label="Campaign Name" value={form.name} onChange={(v) => update('name', v)} />
        <Input label="Setting" value={form.setting} onChange={(v) => update('setting', v)} />
        <div className="grid grid-cols-2 gap-2">
          <Select label="Rules Edition" value={form.rules_edition} onChange={(v) => update('rules_edition', v)}
            options={[{ value: '5e-2024', label: '5e (2024 / 5.5e)' }, { value: '5e-2014', label: '5e (2014)' }]} />
          <Select label="Tone" value={form.tone} onChange={(v) => update('tone', v)}
            options={['heroic', 'epic fantasy', 'grimdark', 'lighthearted', 'political intrigue', 'sandbox'].map((t) => ({ value: t, label: t }))} />
        </div>
        <Input label="DM Name" value={form.dm_name} onChange={(v) => update('dm_name', v)} />
        <div>
          <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">Summary</label>
          <textarea value={form.summary} onChange={(e) => update('summary', e.target.value)} rows={3}
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
        </div>
        <div className="flex gap-2">
          <button onClick={() => onCreate(form)} disabled={!form.name.trim()}
            className="flex-1 px-3 py-2.5 bg-[#FF9F00] text-black text-xs font-bold clip-corner disabled:opacity-50 touch-manipulation">Create</button>
          <button onClick={onCancel} className="px-3 py-2.5 border border-[#30363d] text-[#8b949e] text-xs clip-corner touch-manipulation">Cancel</button>
        </div>
      </div>
    </div>
  );
}

function CampaignInfo({ campaign, onUpdate }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ summary: campaign.summary, tone: campaign.tone, status: campaign.status, party_gold: campaign.party_gold, party_xp: campaign.party_xp });
  const save = async () => { await onUpdate(form); setEditing(false); };
  return (
    <div className="glass-panel clip-corner p-3 space-y-2">
      <div className="flex justify-between">
        <h3 className="text-sm font-bold text-[#e6edf3]">Campaign Details</h3>
        <button onClick={() => setEditing(!editing)} className="text-[10px] text-[#FF9F00]">{editing ? 'Cancel' : 'Edit'}</button>
      </div>
      {!editing ? (
        <>
          <p className="text-[10px] text-[#c9d1d9]">{campaign.summary || 'No summary set.'}</p>
          <div className="grid grid-cols-2 gap-2 text-[10px]">
            <Info label="Status" value={campaign.status} />
            <Info label="Tone" value={campaign.tone} />
            <Info label="Party Gold" value={campaign.party_gold} />
            <Info label="Party XP" value={campaign.party_xp} />
          </div>
        </>
      ) : (
        <div className="space-y-2">
          <textarea value={form.summary} onChange={(e) => setForm({ ...form, summary: e.target.value })} rows={3}
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
          <div className="grid grid-cols-2 gap-2">
            <Select label="Status" value={form.status} onChange={(v) => setForm({ ...form, status: v })}
              options={['active', 'on-hiatus', 'completed', 'archived'].map((s) => ({ value: s, label: s }))} />
            <Input label="Party Gold" value={form.party_gold} onChange={(v) => setForm({ ...form, party_gold: Number(v) })} type="number" />
          </div>
          <button onClick={save} className="px-3 py-2 bg-[#FF9F00] text-black text-xs font-bold clip-corner touch-manipulation">Save</button>
        </div>
      )}
    </div>
  );
}

function Input({ label, value, onChange, type = 'text' }) {
  return (
    <div>
      <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">{label}</label>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)}
        className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner" />
    </div>
  );
}
function Select({ label, value, onChange, options }) {
  return (
    <div>
      <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">{label}</label>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}
function Info({ label, value }) {
  return <div className="bg-[#0d1117] border border-[#30363d] p-1.5 clip-corner"><span className="text-[#8b949e] text-[8px] uppercase">{label}: </span><span className="text-[#e6edf3] font-bold">{value}</span></div>;
}