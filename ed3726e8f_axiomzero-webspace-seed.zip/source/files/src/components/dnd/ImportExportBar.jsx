/**
 * ImportExportBar — One IMPORT button + one EXPORT button.
 *
 * IMPORT: accepts any file (JSON export, typed notes, or a photo of a
 * handwritten sheet), uploads it, calls dndImportParse to classify and extract,
 * then shows an ImportPreviewModal for confirm-and-merge.
 *
 * EXPORT: opens an ExportModal with a format dropdown (JSON/PDF/Markdown/HTML),
 * a name field, and a download trigger.
 *
 * Merlin oversees classification and extraction on the backend.
 */
import { useState, useRef } from 'react';
import { Upload, Download, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ImportPreviewModal from '@/components/dnd/ImportPreviewModal';
import ExportModal from '@/components/dnd/ExportModal';

export default function ImportExportBar({ characterId, campaignId, onImported }) {
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const [exportOpen, setExportOpen] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef(null);

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    setError('');
    try {
      // Upload the file
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      // Parse it via backend
      const response = await base44.functions.invoke('dndImportParse', { file_url });
      const result = response.data || response;
      if (result.error) throw new Error(result.error);
      setImportResult({ ...result, characterId, campaignId });
    } catch (err) {
      setError(err.message || 'Import failed');
    }
    setImporting(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <input ref={fileInputRef} type="file" accept=".json,.txt,.md,.csv,.png,.jpg,.jpeg,.webp,.gif,.bmp" onChange={handleFileSelect} className="hidden" />
      <button
        onClick={() => fileInputRef.current?.click()}
        disabled={importing}
        className="flex items-center gap-1.5 px-3 py-2 border border-[#3b8bff]/40 bg-[#3b8bff]/10 text-[#3b8bff] text-[10px] font-bold clip-corner hover:bg-[#3b8bff]/20 transition-all touch-manipulation disabled:opacity-50"
      >
        {importing ? <Loader2 size={12} className="animate-spin" /> : <Upload size={12} />}
        {importing ? 'Parsing...' : 'IMPORT'}
      </button>
      <button
        onClick={() => setExportOpen(true)}
        className="flex items-center gap-1.5 px-3 py-2 border border-[#3fb950]/40 bg-[#3fb950]/10 text-[#3fb950] text-[10px] font-bold clip-corner hover:bg-[#3fb950]/20 transition-all touch-manipulation"
      >
        <Download size={12} /> EXPORT
      </button>
      {error && <span className="text-[10px] text-[#f85149]">{error}</span>}

      {importResult && (
        <ImportPreviewModal
          result={importResult}
          onClose={() => setImportResult(null)}
          onMerged={() => { setImportResult(null); onImported?.(); }}
        />
      )}
      <ExportModal
        isOpen={exportOpen}
        onClose={() => setExportOpen(false)}
        characterId={characterId}
        campaignId={campaignId}
      />
    </div>
  );
}