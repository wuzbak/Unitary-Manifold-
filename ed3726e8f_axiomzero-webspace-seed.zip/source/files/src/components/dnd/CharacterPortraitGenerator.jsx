/**
 * CharacterPortraitGenerator — AI portrait generator that produces a grounded
 * character image from species + class + equipment + tone using the GenerateImage
 * integration. The portrait can be saved to the character's notes or downloaded.
 */
import { useState } from 'react';
import { Sparkles, Image, Loader2, Save, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { speciesDisplayName, classDisplayName } from '@/lib/dnd/characterEngine';
import { runMerlinImageFlow } from '@/lib/merlinContextLayer';
import MerlinContextCard from '@/components/merlin-context/MerlinContextCard';

export default function CharacterPortraitGenerator({ character, onSave, accent = '#FF9F00' }) {
  const [tone, setTone] = useState('heroic');
  const [style, setStyle] = useState('oil painting');
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState(null);
  const [error, setError] = useState(null);
  const [merlinState, setMerlinState] = useState({ phase: 'idle' });
  const [pendingAnswers, setPendingAnswers] = useState(null);

  const tones = ['heroic', 'grimdark', 'mystical', 'lighthearted', 'epic fantasy', 'noir'];
  const styles = ['oil painting', 'watercolor', 'ink drawing', 'digital art', 'pencil sketch', 'concept art'];

  const buildRawPrompt = () => {
    if (!character) return '';
    const species = speciesDisplayName(character.species);
    const klass = classDisplayName(character.klass);
    const scores = typeof character.ability_scores_json === 'string'
      ? JSON.parse(character.ability_scores_json)
      : character.ability_scores_json || {};
    const alignment = character.alignment || 'unaligned';
    const level = character.level || 1;
    return `D&D character portrait: a ${species} ${klass}, level ${level}, ${alignment} alignment. ` +
      `STR ${scores.strength || 10}, DEX ${scores.dexterity || 10}, CON ${scores.constitution || 10}, ` +
      `INT ${scores.intelligence || 10}, WIS ${scores.wisdom || 10}, CHA ${scores.charisma || 10}. ` +
      `${tone} tone, ${style} style. Fantasy adventurer, detailed, atmospheric lighting, ` +
      `wearing appropriate ${klass} gear and equipment. No text, no watermark.`;
  };

  const generate = async (answers) => {
    if (!character) return;
    setLoading(true);
    setError(null);
    setImageUrl(null);
    setMerlinState({ phase: 'curating' });
    try {
      const result = await runMerlinImageFlow({
        rawPrompt: buildRawPrompt(),
        generatorType: 'dnd-portrait',
        answers: answers || pendingAnswers || undefined,
        pageContext: 'D&D Character Portrait Generator',
        onStatus: (s) => setMerlinState((prev) => ({ ...prev, phase: s.phase })),
      });
      if (result.phase === 'clarify') {
        setMerlinState({ phase: 'clarify', clarifyingQuestions: result.clarifyingQuestions });
      } else if (result.phase === 'done') {
        setImageUrl(result.imageUrl);
        setMerlinState({ phase: 'done', proof: result.proof, contextNote: result.contextNote });
      } else if (result.phase === 'error') {
        setError(result.error);
        setMerlinState({ phase: 'error', error: result.error });
      }
      setPendingAnswers(null);
    } catch (e) {
      setError(e.message || 'Failed to generate portrait');
      setMerlinState({ phase: 'error', error: e.message });
    }
    setLoading(false);
  };

  const handleAnswer = (answers) => {
    setPendingAnswers(answers);
    setMerlinState({ phase: 'idle' });
    setTimeout(() => generate(answers), 30);
  };

  const handleRecurate = (suggested) => {
    setMerlinState({ phase: 'idle' });
    setImageUrl(null);
    // Re-run with Merlin's suggested re-curation as the new raw prompt
    setTimeout(() => {
      setLoading(true);
      setError(null);
      setMerlinState({ phase: 'curating' });
      runMerlinImageFlow({
        rawPrompt: suggested,
        generatorType: 'dnd-portrait',
        pageContext: 'D&D Character Portrait Generator',
        onStatus: (s) => setMerlinState((prev) => ({ ...prev, phase: s.phase })),
      }).then((result) => {
        if (result.phase === 'done') {
          setImageUrl(result.imageUrl);
          setMerlinState({ phase: 'done', proof: result.proof, contextNote: result.contextNote });
        } else if (result.phase === 'error') {
          setError(result.error);
          setMerlinState({ phase: 'error', error: result.error });
        }
        setLoading(false);
      }).catch((e) => {
        setError(e.message);
        setMerlinState({ phase: 'error', error: e.message });
        setLoading(false);
      });
    }, 30);
  };

  const saveToCharacter = async () => {
    if (!imageUrl || !character) return;
    try {
      const notes = typeof character.notes_json === 'string'
        ? JSON.parse(character.notes_json)
        : character.notes_json || [];
      notes.push(`Portrait: ${imageUrl}`);
      await base44.entities.DnDCharacter.update(character.id, {
        notes_json: JSON.stringify(notes),
      });
      onSave?.();
    } catch (e) {
      setError(`Failed to save: ${e.message}`);
    }
  };

  return (
    <div className="glass-strong clip-corner p-3 space-y-3" style={{ borderColor: `${accent}30` }}>
      <div className="flex items-center gap-2">
        <Image size={14} style={{ color: accent }} />
        <span className="text-[10px] font-bold uppercase" style={{ color: accent }}>AI Portrait Generator</span>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">Tone</label>
          <select value={tone} onChange={(e) => setTone(e.target.value)}
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
            {tones.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div>
          <label className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">Style</label>
          <select value={style} onChange={(e) => setStyle(e.target.value)}
            className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-xs text-[#e6edf3] clip-corner">
            {styles.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <button onClick={generate} disabled={loading || !character}
        className="w-full flex items-center justify-center gap-2 px-3 py-2.5 text-black text-xs font-bold clip-corner disabled:opacity-50 touch-manipulation"
        style={{ background: accent }}>
        {loading ? <><Loader2 size={14} className="animate-spin" /> Generating...</> : <><Sparkles size={14} /> Generate Portrait</>}
      </button>

      {error && <p className="text-[10px] text-[#f85149]">{error}</p>}

      <MerlinContextCard
        state={merlinState}
        accent={accent}
        onAnswer={handleAnswer}
        onRecurate={handleRecurate}
        onDismiss={() => setMerlinState({ phase: 'idle' })}
      />

      {imageUrl && (
        <div className="space-y-2">
          <div className="border border-[#30363d] clip-corner overflow-hidden">
            <img src={imageUrl} alt="Character portrait" className="w-full h-48 object-cover" />
          </div>
          <div className="flex gap-1.5">
            <button onClick={saveToCharacter} className="flex-1 flex items-center justify-center gap-1.5 px-2 py-1.5 border border-[#3fb950]/40 bg-[#3fb950]/10 text-[#3fb950] text-[10px] font-bold clip-corner touch-manipulation">
              <Save size={12} /> Save to Character
            </button>
            <a href={imageUrl} download="portrait.png" className="flex items-center justify-center px-2 py-1.5 border border-[#30363d] text-[#8b949e] text-[10px] clip-corner touch-manipulation">
              <Image size={12} />
            </a>
          </div>
        </div>
      )}
    </div>
  );
}