import { useState, useEffect, useRef, useCallback } from 'react';
import { getDuckDB, loadEntityRecords, runQuery, exportParquet } from '@/lib/computeStack/duckdbEngine';
import { arrowToRecords, arrowColumns } from '@/lib/computeStack/arrowEngine';
import { base44 } from '@/api/base44Client';
import { Database, Play, Loader2, Table, AlertCircle, Download } from 'lucide-react';

/**
 * DuckDBAnalyticsPanel — reusable in-browser SQL analytics panel.
 *
 * Loads entity records into a DuckDB-WASM instance, lets the user run SQL
 * queries client-side, and renders results in a table. Also supports Parquet
 * export of the current result set. Used by Records Hub, System Status, and
 * (future) Filmer's Companion.
 */
export default function DuckDBAnalyticsPanel({ entityName, accent = '#4DD0E1', defaultSql = null }) {
  const [available, setAvailable] = useState(null); // null=checking, true/false
  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [sql, setSql] = useState(defaultSql || `SELECT * FROM records LIMIT 100`);
  const [results, setResults] = useState(null);
  const [columns, setColumns] = useState([]);
  const [rowCount, setRowCount] = useState(0);
  const [entityCount, setEntityCount] = useState(0);
  const initRef = useRef(false);

  // Check DuckDB availability + load records on mount
  const init = useCallback(async () => {
    if (initRef.current) return;
    initRef.current = true;
    setLoading(true);
    try {
      await getDuckDB();
      setAvailable(true);

      // Load entity records
      const records = await base44.entities[entityName]?.list('-updated_date', 5000) || [];
      setEntityCount(records.length);
      if (records.length > 0) {
        await loadEntityRecords('records', records);
        setLoaded(true);
        // Auto-run default query
        const table = await runQuery(sql);
        setColumns(arrowColumns(table));
        const recs = arrowToRecords(table);
        setResults(recs);
        setRowCount(recs.length);
      }
    } catch (e) {
      setAvailable(false);
      setError(e.message);
    }
    setLoading(false);
  }, [entityName, sql]);

  useEffect(() => { init(); }, [init]);

  const handleRun = async () => {
    if (!available || !loaded) return;
    setLoading(true);
    setError(null);
    try {
      const table = await runQuery(sql);
      setColumns(arrowColumns(table));
      const recs = arrowToRecords(table);
      setResults(recs);
      setRowCount(recs.length);
    } catch (e) {
      setError(e.message);
      setResults(null);
    }
    setLoading(false);
  };

  const handleExportParquet = async () => {
    if (!available || !loaded) return;
    setLoading(true);
    try {
      // Create a temp table from the current query, then export
      await runQuery(`CREATE OR REPLACE TABLE _export AS ${sql}`);
      const blob = await exportParquet('_export', `${entityName}_export.parquet`);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${entityName}_export.parquet`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  };

  if (available === false) {
    return (
      <div className="glass-panel clip-corner p-6 text-center">
        <AlertCircle size={24} className="text-[#FF9F00] mx-auto mb-2" />
        <p className="text-sm font-bold text-[#FF9F00] mb-1">DuckDB-WASM Unavailable</p>
        <p className="text-[11px] text-[#8b949e]">{error || 'The in-browser analytics engine could not be initialized.'}</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Status bar */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Database size={14} style={{ color: accent }} />
          <span className="text-[11px] font-bold text-[#e6edf3]">DuckDB-WASM Analytics</span>
          {available && (
            <span className="text-[9px] font-bold px-1.5 py-0.5 clip-corner" style={{ color: '#3fb950', background: '#3fb9501a', border: '1px solid #3fb95040' }}>
              ● READY
            </span>
          )}
          {loaded && (
            <span className="text-[9px] text-[#8b949e]">
              {entityName}: <span className="font-mono text-[#4DD0E1]">{entityCount.toLocaleString()}</span> rows loaded
            </span>
          )}
        </div>
        <button
          onClick={handleExportParquet}
          disabled={!loaded || loading}
          className="flex items-center gap-1 px-2 py-1 text-[10px] font-bold text-[#4DD0E1] border border-[#4DD0E1]/40 bg-[#4DD0E1]/10 clip-corner hover:bg-[#4DD0E1]/20 disabled:opacity-40 transition-colors"
        >
          <Download size={11} /> Parquet
        </button>
      </div>

      {/* SQL editor */}
      <div className="glass-panel clip-corner p-3">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[9px] font-bold uppercase tracking-wider text-[#8b949e]">SQL Query</span>
          <button
            onClick={handleRun}
            disabled={!loaded || loading}
            className="flex items-center gap-1 px-2.5 py-1 text-[10px] font-bold text-black clip-corner disabled:opacity-40 transition-opacity"
            style={{ background: accent }}
          >
            {loading ? <Loader2 size={11} className="animate-spin" /> : <Play size={11} />}
            Run
          </button>
        </div>
        <textarea
          value={sql}
          onChange={(e) => setSql(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) handleRun(); }}
          rows={4}
          className="w-full bg-[#050508] border border-[#30363d] text-[#e6edf3] text-[11px] font-mono p-2 clip-corner focus:outline-none focus:border-[#00f5ff] resize-y"
          placeholder="SELECT status, COUNT(*) as count FROM records GROUP BY status"
          spellCheck={false}
        />
        <p className="text-[8px] text-[#484f58] mt-1">Ctrl+Enter to run · Records loaded as table "records"</p>
      </div>

      {/* Error */}
      {error && (
        <div className="glass-panel clip-corner p-3 border-l-2 border-[#FF9F00]">
          <p className="text-[11px] text-[#FF9F00] font-mono">{error}</p>
        </div>
      )}

      {/* Results */}
      {results && (
        <div className="glass-panel clip-corner p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Table size={12} style={{ color: accent }} />
              <span className="text-[10px] font-bold text-[#e6edf3] uppercase tracking-wider">Results</span>
            </div>
            <span className="text-[9px] text-[#8b949e]">{rowCount} rows</span>
          </div>
          <div className="overflow-x-auto max-h-[400px] overflow-y-auto">
            <table className="w-full text-[10px]">
              <thead className="sticky top-0 bg-[#0d1117]">
                <tr>
                  {columns.map(col => (
                    <th key={col} className="text-left px-2 py-1.5 text-[#4DD0E1] font-bold font-mono border-b border-[#30363d] whitespace-nowrap">
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {results.slice(0, 500).map((row, i) => (
                  <tr key={i} className="border-b border-[#30363d]/50 hover:bg-[#00f5ff]/5">
                    {columns.map(col => (
                      <td key={col} className="px-2 py-1 text-[#8b949e] font-mono whitespace-nowrap max-w-[200px] overflow-hidden text-ellipsis">
                        {row[col] === null ? <span className="text-[#484f58]">null</span> : String(row[col])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {rowCount > 500 && (
            <p className="text-[9px] text-[#484f58] mt-1.5 text-center">Showing first 500 of {rowCount} rows</p>
          )}
        </div>
      )}
    </div>
  );
}