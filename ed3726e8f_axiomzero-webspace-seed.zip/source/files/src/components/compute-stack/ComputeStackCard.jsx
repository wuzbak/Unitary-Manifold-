import { Cpu, Database, Zap, ShieldCheck, FileText, ExternalLink } from 'lucide-react';

const CATEGORY_ICONS = {
  languages: Cpu,
  data: Database,
  compute: Zap,
  verification: ShieldCheck,
};

const FEASIBILITY_LABELS = {
  browser: { label: 'Browser', color: '#3fb950', desc: 'Runs in this webspace' },
  wasm: { label: 'WASM', color: '#4DD0E1', desc: 'Compiles to WebAssembly' },
  repository: { label: 'Repository', color: '#FF9F00', desc: 'Lives in the GitHub repo' },
};

const STATUS_LABELS = {
  shipped: { label: 'Shipped', color: '#3fb950' },
  live: { label: 'Live', color: '#3fb950' },
  emerging: { label: 'Emerging', color: '#FF9F00' },
  architecture: { label: 'Architecture', color: '#8b949e' },
};

export default function ComputeStackCard({ tech }) {
  const Icon = CATEGORY_ICONS[tech.category] || FileText;
  const feas = FEASIBILITY_LABELS[tech.feasibility] || FEASIBILITY_LABELS.repository;
  const status = STATUS_LABELS[tech.status] || STATUS_LABELS.architecture;

  return (
    <div className="glass-panel clip-corner p-4 flex flex-col gap-2 glow-hover">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 flex items-center justify-center clip-corner shrink-0" style={{ background: `${feas.color}1a`, border: `1px solid ${feas.color}40` }}>
            <Icon size={16} style={{ color: feas.color }} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#e6edf3] font-heading">{tech.name}</h3>
            <p className="text-[10px] text-[#8b949e] uppercase tracking-wider">{tech.role}</p>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1 shrink-0">
          <span className="text-[9px] font-bold px-1.5 py-0.5 clip-corner" style={{ color: feas.color, background: `${feas.color}1a`, border: `1px solid ${feas.color}40` }}>
            {feas.label}
          </span>
          <span className="text-[9px] font-bold px-1.5 py-0.5 clip-corner" style={{ color: status.color, background: `${status.color}1a`, border: `1px solid ${status.color}40` }}>
            {status.label}
          </span>
        </div>
      </div>

      <p className="text-[11px] text-[#8b949e] leading-relaxed">{tech.description}</p>

      {tech.whenToUse && (
        <div className="border-l-2 pl-2 py-1" style={{ borderColor: `${feas.color}60` }}>
          <p className="text-[9px] font-bold uppercase tracking-wider mb-0.5" style={{ color: feas.color }}>When to use</p>
          <p className="text-[10px] text-[#8b949e] leading-relaxed">{tech.whenToUse}</p>
        </div>
      )}

      {tech.tools && tech.tools.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-1">
          {tech.tools.map(tool => (
            <span key={tool} className="text-[9px] font-mono px-1.5 py-0.5 bg-[#0d1117] border border-[#30363d] text-[#4DD0E1] clip-corner">
              {tool}
            </span>
          ))}
        </div>
      )}

      {tech.repoPath && (
        <a href={`/manifold-explorer`} className="flex items-center gap-1 text-[10px] text-[#4DD0E1] hover:text-[#00f5ff] transition-colors mt-auto pt-1">
          <ExternalLink size={10} /> {tech.repoPath}
        </a>
      )}
    </div>
  );
}