import { useMemo, useState } from 'react';
import { COMPUTE_STACK_TECHNOLOGIES, COMPUTE_STACK_CATEGORIES } from '@/lib/computeStack/computeStackRegistry';
import ComputeStackCard from './ComputeStackCard';

export default function ComputeStackSection({ filterCategory = null }) {
  const [activeCategory, setActiveCategory] = useState(filterCategory || 'all');

  const filtered = useMemo(() => {
    if (activeCategory === 'all') return COMPUTE_STACK_TECHNOLOGIES;
    return COMPUTE_STACK_TECHNOLOGIES.filter(t => t.category === activeCategory);
  }, [activeCategory]);

  const counts = useMemo(() => {
    const c = { all: COMPUTE_STACK_TECHNOLOGIES.length };
    for (const cat of COMPUTE_STACK_CATEGORIES) {
      c[cat.id] = COMPUTE_STACK_TECHNOLOGIES.filter(t => t.category === cat.id).length;
    }
    return c;
  }, []);

  return (
    <div className="space-y-4">
      {/* Category filter */}
      <div className="flex flex-wrap gap-1.5">
        <button
          onClick={() => setActiveCategory('all')}
          className={`px-3 py-1.5 text-[10px] font-bold tracking-wider clip-corner transition-all ${
            activeCategory === 'all'
              ? 'bg-[#00f5ff] text-black'
              : 'bg-[#0d1117] text-[#8b949e] border border-[#30363d] hover:text-[#e6edf3]'
          }`}
        >
          ALL ({counts.all})
        </button>
        {COMPUTE_STACK_CATEGORIES.map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 text-[10px] font-bold tracking-wider clip-corner transition-all ${
              activeCategory === cat.id
                ? 'text-black'
                : 'bg-[#0d1117] text-[#8b949e] border border-[#30363d] hover:text-[#e6edf3]'
            }`}
            style={activeCategory === cat.id ? { background: cat.color } : {}}
          >
            {cat.label.toUpperCase()} ({counts[cat.id]})
          </button>
        ))}
      </div>

      {/* Technology cards grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map(tech => (
          <ComputeStackCard key={tech.id} tech={tech} />
        ))}
      </div>
    </div>
  );
}