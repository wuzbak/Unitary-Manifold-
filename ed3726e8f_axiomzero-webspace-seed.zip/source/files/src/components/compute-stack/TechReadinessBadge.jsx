import { COMPUTE_STACK_TECHNOLOGIES } from '@/lib/computeStack/computeStackRegistry';

const STATUS_COLORS = {
  shipped: '#3fb950',
  live: '#3fb950',
  emerging: '#FF9F00',
  architecture: '#8b949e',
};

const FEAS_COLORS = {
  browser: '#3fb950',
  wasm: '#4DD0E1',
  repository: '#FF9F00',
};

/**
 * TechReadinessBadge — compact readiness grid for the System Status page.
 * Shows all compute-stack technologies with their feasibility + status as
 * color-coded pills in a tactical-HUD strip.
 */
export default function TechReadinessBadge() {
  return (
    <div className="glass-panel clip-corner p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-bold text-[#e6edf3] font-heading">Compute Stack Readiness</h3>
        <span className="text-[10px] text-[#8b949e] uppercase tracking-wider">
          {COMPUTE_STACK_TECHNOLOGIES.filter(t => t.status === 'shipped' || t.status === 'live').length} live / {COMPUTE_STACK_TECHNOLOGIES.length} total
        </span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
        {COMPUTE_STACK_TECHNOLOGIES.map(tech => {
          const statusColor = STATUS_COLORS[tech.status] || '#8b949e';
          const feasColor = FEAS_COLORS[tech.feasibility] || '#8b949e';
          return (
            <div key={tech.id} className="flex items-center gap-2 px-2 py-1.5 bg-[#0d1117] border border-[#30363d] clip-corner">
              <div className="w-1.5 h-1.5 rounded-full shrink-0 glow-pulse" style={{ background: statusColor, color: statusColor }} />
              <div className="flex-1 min-w-0">
                <div className="text-[10px] font-bold text-[#e6edf3] truncate">{tech.name}</div>
                <div className="text-[8px] text-[#8b949e] uppercase tracking-wider truncate">{tech.status}</div>
              </div>
              <span className="text-[8px] font-bold px-1 py-0.5 clip-corner shrink-0" style={{ color: feasColor, background: `${feasColor}1a` }}>
                {tech.feasibility === 'browser' ? 'WEB' : tech.feasibility === 'wasm' ? 'WASM' : 'REPO'}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}