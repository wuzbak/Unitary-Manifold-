import { useState, useEffect, useRef, useCallback } from 'react';
import { ZarrClient, arrayBounds } from '@/lib/computeStack/zarrClient';
import { ZARR_DATASETS } from '@/lib/computeStack/computeStackTools';
import { Database, Download, Loader2, Layers } from 'lucide-react';

/**
 * ZarrStreamViewport — interactive N-dimensional chunked array viewer.
 *
 * Streams Zarr chunks via the zarrChunkServer backend function and renders
 * a heatmap on a canvas. Only the chunks overlapping the current viewport
 * are fetched — progressive resolution as chunks arrive. Pan/zoom adjusts
 * the viewport slice.
 */
export default function ZarrStreamViewport({ dataset: initialDataset = 'manifold-excitation', accent = '#00f5ff' }) {
  const [dataset, setDataset] = useState(initialDataset);
  const [metadata, setMetadata] = useState(null);
  const [viewport, setViewport] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [chunksFetched, setChunksFetched] = useState(0);
  const [cacheHits, setCacheHits] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [panX, setPanX] = useState(0);
  const [panY, setPanY] = useState(0);
  const canvasRef = useRef(null);
  const clientRef = useRef(null);

  // Load metadata when dataset changes
  useEffect(() => {
    let cancelled = false;
    const client = new ZarrClient(dataset);
    clientRef.current = client;
    setMetadata(null);
    setViewport(null);
    setError(null);
    setChunksFetched(0);
    setCacheHits(0);
    setZoom(1);
    setPanX(0);
    setPanY(0);

    (async () => {
      try {
        const meta = await client.loadMetadata();
        if (cancelled) return;
        setMetadata(meta);
      } catch (e) {
        if (!cancelled) setError(e.message);
      }
    })();

    return () => { cancelled = true; };
  }, [dataset]);

  // Fetch viewport when zoom/pan/metadata changes
  const fetchViewport = useCallback(async () => {
    if (!metadata || !clientRef.current) return;
    setLoading(true);
    setError(null);
    try {
      const vpSize = Math.floor(metadata.shape[0] / zoom);
      const startR = Math.floor(panX * (metadata.shape[0] - vpSize));
      const startC = Math.floor(panY * (metadata.shape[1] - vpSize));
      const slices = [
        { start: startR, stop: startR + vpSize },
        { start: startC, stop: startC + vpSize },
      ];
      const result = await clientRef.current.fetchViewport(slices);
      setViewport(result);
      setChunksFetched(result.chunksFetched);
      setCacheHits(clientRef.current.chunkCache.size);
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  }, [metadata, zoom, panX, panY]);

  useEffect(() => {
    const timer = setTimeout(fetchViewport, 200); // debounce
    return () => clearTimeout(timer);
  }, [fetchViewport]);

  // Render heatmap on canvas
  useEffect(() => {
    if (!viewport || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const [rows, cols] = viewport.shape;
    canvas.width = cols;
    canvas.height = rows;
    const { min, max } = arrayBounds(viewport.data);
    const range = max - min || 1;
    const imageData = ctx.createImageData(cols, rows);
    for (let i = 0; i < viewport.data.length; i++) {
      const normalized = (viewport.data[i] - min) / range;
      // Cyan-to-amber thermal colormap
      const r = Math.round(normalized * 255);
      const g = Math.round((1 - Math.abs(normalized - 0.5) * 2) * 200);
      const b = Math.round((1 - normalized) * 255);
      imageData.data[i * 4] = r;
      imageData.data[i * 4 + 1] = g;
      imageData.data[i * 4 + 2] = b;
      imageData.data[i * 4 + 3] = 255;
    }
    ctx.putImageData(imageData, 0, 0);
  }, [viewport]);

  return (
    <div className="space-y-3">
      {/* Dataset selector + controls */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5">
          <Database size={14} style={{ color: accent }} />
          <select
            value={dataset}
            onChange={(e) => setDataset(e.target.value)}
            className="bg-[#0d1117] border border-[#30363d] text-[#e6edf3] text-[11px] px-2 py-1 clip-corner focus:outline-none focus:border-[#00f5ff]"
          >
            {ZARR_DATASETS.map(ds => (
              <option key={ds.id} value={ds.id}>{ds.name}</option>
            ))}
          </select>
        </div>

        {metadata && (
          <div className="flex items-center gap-3 text-[10px] text-[#8b949e]">
            <span>Shape: <span className="font-mono text-[#4DD0E1]">{metadata.shape.join('×')}</span></span>
            <span>Chunks: <span className="font-mono text-[#4DD0E1]">{metadata.chunks.join('×')}</span></span>
            <span>Total: <span className="font-mono text-[#4DD0E1]">{metadata.totalChunks}</span></span>
          </div>
        )}
      </div>

      {/* Viewport controls */}
      <div className="flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-1.5 text-[10px] text-[#8b949e]">
          <span>Zoom:</span>
          <input type="range" min="1" max="8" step="0.5" value={zoom} onChange={(e) => setZoom(Number(e.target.value))} className="w-24 accent-[#00f5ff]" />
          <span className="font-mono text-[#4DD0E1] w-8">{zoom}x</span>
        </label>
        <label className="flex items-center gap-1.5 text-[10px] text-[#8b949e]">
          <span>Pan X:</span>
          <input type="range" min="0" max="1" step="0.05" value={panX} onChange={(e) => setPanX(Number(e.target.value))} className="w-24 accent-[#00f5ff]" />
        </label>
        <label className="flex items-center gap-1.5 text-[10px] text-[#8b949e]">
          <span>Pan Y:</span>
          <input type="range" min="0" max="1" step="0.05" value={panY} onChange={(e) => setPanY(Number(e.target.value))} className="w-24 accent-[#00f5ff]" />
        </label>
        <button
          onClick={() => clientRef.current?.clearCache()}
          className="text-[10px] text-[#8b949e] hover:text-[#FF9F00] transition-colors"
        >
          Clear cache ({cacheHits})
        </button>
      </div>

      {/* Canvas + status */}
      <div className="relative glass-panel clip-corner p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <Layers size={12} style={{ color: accent }} />
            <span className="text-[10px] font-bold text-[#e6edf3] uppercase tracking-wider">Chunked Array Viewport</span>
          </div>
          <div className="flex items-center gap-2 text-[9px] text-[#8b949e]">
            {loading && <Loader2 size={11} className="animate-spin text-[#00f5ff]" />}
            <span>Chunks fetched: <span className="font-mono text-[#4DD0E1]">{chunksFetched}</span></span>
          </div>
        </div>

        <div className="relative w-full bg-[#050508] border border-[#30363d] clip-corner overflow-hidden" style={{ minHeight: '300px' }}>
          {error ? (
            <div className="absolute inset-0 flex items-center justify-center text-[#FF9F00] text-xs">{error}</div>
          ) : !viewport ? (
            <div className="absolute inset-0 flex items-center justify-center text-[#8b949e] text-xs">
              {loading ? <Loader2 size={20} className="animate-spin" /> : 'Initializing Zarr stream...'}
            </div>
          ) : (
            <canvas
              ref={canvasRef}
              className="w-full h-auto"
              style={{ imageRendering: 'pixelated', maxHeight: '400px', objectFit: 'contain' }}
            />
          )}
          {loading && viewport && (
            <div className="absolute top-2 right-2 flex items-center gap-1 px-2 py-1 bg-[#0a0a12]/80 border border-[#00f5ff]/40 clip-corner">
              <Loader2 size={10} className="animate-spin text-[#00f5ff]" />
              <span className="text-[9px] text-[#00f5ff] font-bold">STREAMING</span>
            </div>
          )}
        </div>

        {metadata && (
          <p className="text-[9px] text-[#484f58] mt-2 leading-relaxed">{metadata.description}</p>
        )}
      </div>
    </div>
  );
}