import { useState, useRef } from 'react';
import { getDuckDB, loadEntityRecords, exportParquet, importParquet } from '@/lib/computeStack/duckdbEngine';
import { arrowToRecords } from '@/lib/computeStack/arrowEngine';
import { base44 } from '@/api/base44Client';
import { Upload, Download, Loader2, FileBox, AlertCircle } from 'lucide-react';

/**
 * ParquetExportImport — reusable columnar data export/import bar.
 *
 * Export: loads entity records into DuckDB-WASM, writes to Parquet (compressed
 * columnar), and downloads the file. Import: reads a Parquet file via DuckDB-WASM
 * and creates entity records from the rows.
 *
 * Mirrors the ImportExportBar pattern used in Filmer's Companion and D&D.
 */
export default function ParquetExportImport({ entityName, accent = '#4DD0E1', onImport = null }) {
  const [loading, setLoading] = useState(null); // 'export' | 'import' | null
  const [error, setError] = useState(null);
  const [info, setInfo] = useState(null);
  const fileRef = useRef(null);

  const handleExport = async () => {
    setLoading('export');
    setError(null);
    setInfo(null);
    try {
      const records = await base44.entities[entityName]?.list('-updated_date', 10000) || [];
      if (records.length === 0) {
        setError('No records to export');
        return;
      }
      await getDuckDB();
      await loadEntityRecords('_export', records);
      const blob = await exportParquet('_export', `${entityName}_export.parquet`);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${entityName}_export.parquet`;
      a.click();
      URL.revokeObjectURL(url);
      setInfo(`Exported ${records.length} records to Parquet (${(blob.size / 1024).toFixed(1)} KB)`);
    } catch (e) {
      setError(e.message);
    }
    setLoading(null);
  };

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading('import');
    setError(null);
    setInfo(null);
    try {
      const buf = await file.arrayBuffer();
      await getDuckDB();
      const records = await importParquet(new Uint8Array(buf), '_import');
      setInfo(`Read ${records.length} records from Parquet (${(file.size / 1024).toFixed(1)} KB)`);
      if (onImport) {
        await onImport(records);
      } else {
        // Default: bulk create entity records
        if (records.length > 0 && base44.entities[entityName]) {
          await base44.entities[entityName].bulkCreate(records.slice(0, 500));
          setInfo(prev => `${prev} → Created ${Math.min(records.length, 500)} ${entityName} records`);
        }
      }
    } catch (e) {
      setError(e.message);
    }
    setLoading(null);
    if (fileRef.current) fileRef.current.value = '';
  };

  return (
    <div className="glass-panel clip-corner p-3">
      <div className="flex items-center gap-2 mb-2">
        <FileBox size={14} style={{ color: accent }} />
        <span className="text-[11px] font-bold text-[#e6edf3]">Parquet Export / Import</span>
        <span className="text-[9px] text-[#8b949e]">— columnar data layer (Arrow + DuckDB)</span>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={handleExport}
          disabled={loading !== null}
          className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold text-black clip-corner disabled:opacity-50 transition-opacity"
          style={{ background: accent }}
        >
          {loading === 'export' ? <Loader2 size={12} className="animate-spin" /> : <Download size={12} />}
          Export Parquet
        </button>

        <label
          className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold clip-corner cursor-pointer transition-opacity ${
            loading !== null ? 'opacity-50' : ''
          }`}
          style={{ color: accent, background: `${accent}1a`, border: `1px solid ${accent}40` }}
        >
          {loading === 'import' ? <Loader2 size={12} className="animate-spin" /> : <Upload size={12} />}
          Import Parquet
          <input ref={fileRef} type="file" accept=".parquet" onChange={handleImport} className="hidden" disabled={loading !== null} />
        </label>
      </div>

      {error && (
        <div className="flex items-center gap-1.5 mt-2 text-[10px] text-[#FF9F00]">
          <AlertCircle size={11} /> {error}
        </div>
      )}
      {info && (
        <p className="text-[10px] text-[#3fb950] mt-2">{info}</p>
      )}
    </div>
  );
}