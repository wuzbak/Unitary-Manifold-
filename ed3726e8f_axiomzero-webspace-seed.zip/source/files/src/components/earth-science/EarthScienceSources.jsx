import { useState } from 'react';
import { ExternalLink, Database, Key, Globe, BookOpen } from 'lucide-react';
import { EARTH_SCIENCE_SOURCES, SOURCES_BY_DOMAIN, DOMAIN_COLORS } from '@/lib/earthScience/sources';

/**
 * EarthScienceSources — Displays the registry of authoritative open data
 * sources for rocks, minerals, metals, soil, and water. Each source links
 * out to the original scientific database. Used in TerraOS + LithosOS.
 */
export default function EarthScienceSources() {
  const [activeDomain, setActiveDomain] = useState('all');

  const domains = ['all', ...Object.keys(SOURCES_BY_DOMAIN)];
  const filtered = activeDomain === 'all'
    ? EARTH_SCIENCE_SOURCES
    : SOURCES_BY_DOMAIN[activeDomain] || [];

  return (
    <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
      <div className="flex items-center gap-2 mb-3">
        <Database size={14} className="text-[#00f5ff]" />
        <h3 className="text-sm font-bold text-[#e6edf3]">Open Scientific Data Sources</h3>
        <span className="text-[9px] text-[#484f58] ml-auto">{EARTH_SCIENCE_SOURCES.length} sources</span>
      </div>

      <p className="text-[10px] text-[#8b949e] mb-3 leading-relaxed">
        Authoritative, open-access databases for mineral identification, soil assessment, and water quality analysis.
        All sources are crawlable and scientifically verified. Click to access the original database.
      </p>

      {/* Domain filter */}
      <div className="flex flex-wrap gap-1.5 mb-3">
        {domains.map(d => (
          <button
            key={d}
            onClick={() => setActiveDomain(d)}
            className={`px-2 py-1 rounded text-[10px] font-bold transition-colors ${
              activeDomain === d
                ? 'bg-[#00f5ff] text-black'
                : 'bg-[#0d1117] border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'
            }`}
          >
            {d === 'all' ? 'All' : d}
          </button>
        ))}
      </div>

      {/* Source cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {filtered.map(s => {
          const color = DOMAIN_COLORS[s.domain] || '#8b949e';
          return (
            <a
              key={s.id}
              href={s.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-[#0d1117] border border-[#30363d] rounded-lg p-3 hover:border-[#00f5ff]/30 transition-colors group"
            >
              <div className="flex items-start justify-between gap-2 mb-1">
                <div>
                  <div className="text-xs font-bold text-[#e6edf3] group-hover:text-[#00f5ff] transition-colors">{s.name}</div>
                  <div className="text-[9px] font-bold uppercase tracking-wider mt-0.5" style={{ color }}>{s.domain}</div>
                </div>
                <ExternalLink size={11} className="text-[#484f58] group-hover:text-[#00f5ff] transition-colors shrink-0" />
              </div>
              <p className="text-[9px] text-[#8b949e] leading-relaxed mb-2">{s.desc}</p>
              <div className="flex flex-wrap gap-1.5">
                <span className="flex items-center gap-1 text-[8px] text-[#484f58]">
                  <Globe size={8} /> {s.access}
                </span>
                <span className="flex items-center gap-1 text-[8px] text-[#484f58]">
                  <BookOpen size={8} /> {s.authority}
                </span>
                {s.crawlable && (
                  <span className="flex items-center gap-1 text-[8px] text-[#3fb950]">
                    <Key size={8} /> {s.license}
                  </span>
                )}
              </div>
            </a>
          );
        })}
      </div>
    </div>
  );
}