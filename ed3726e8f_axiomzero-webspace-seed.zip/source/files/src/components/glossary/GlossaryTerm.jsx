export default function GlossaryTerm({ term }) {
  return (
    <div className="bg-[#161b22] border border-[#30363d] rounded-lg p-4">
      <div className="flex items-center gap-2 mb-1">
        <h3 className="text-[#58a6ff] font-bold text-sm">{term.term}</h3>
        {term.category && <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#21262d] text-[#8b949e]">{term.category}</span>}
      </div>
      <p className="text-[#8b949e] text-xs leading-relaxed">{term.definition}</p>
    </div>
  );
}