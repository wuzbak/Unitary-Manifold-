import * as THREE from 'three';
import { COSMIC_DESTINATIONS } from '@/lib/topology/cosmicDestinations';

/**
 * CosmicDestinations — renders the neutron star and exoplanet system as
 * visually distinct, emissive, clickable 3D objects in the manifold.
 *
 * The black hole, pulsar, and supernova remnant are rendered by their own
 * dedicated modules; this module adds the two new phenomena. Each object's
 * userData carries the full COSMIC_DESTINATIONS metadata so the existing
 * onElementClick → CosmicInfoCard flow displays rich scientific data.
 *
 * Returns { group, update, dispose, interactiveObjects }
 */
export function createCosmicDestinations({ scene, glowTex }) {
  const group = new THREE.Group();
  scene.add(group);
  const disposables = [];
  const interactiveObjects = [];

  const byId = Object.fromEntries(COSMIC_DESTINATIONS.map((d) => [d.id, d]));

  // ── Neutron star (PSR J0740+6620) ──
  const nsData = byId['neutron-star'];
  const nsGroup = new THREE.Group();
  nsGroup.position.set(46, -6, 42);

  const nsGeo = new THREE.SphereGeometry(0.9, 24, 24);
  const nsMat = new THREE.MeshBasicMaterial({ color: 0xd0e8ff, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending });
  const nsMesh = new THREE.Mesh(nsGeo, nsMat);
  nsGroup.add(nsMesh);

  // Polar relativistic jets
  const jetGeo = new THREE.ConeGeometry(0.25, 3, 12);
  const jetMat = new THREE.MeshBasicMaterial({ color: 0x80c0ff, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending, depthWrite: false });
  const jetUp = new THREE.Mesh(jetGeo, jetMat);
  jetUp.position.y = 1.8;
  nsGroup.add(jetUp);
  const jetDn = new THREE.Mesh(jetGeo, jetMat.clone());
  jetDn.position.y = -1.8;
  jetDn.rotation.z = Math.PI;
  nsGroup.add(jetDn);

  // Glow halo
  const nsGlowMat = new THREE.SpriteMaterial({ map: glowTex, color: 0xa0c8ff, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false });
  const nsGlow = new THREE.Sprite(nsGlowMat);
  nsGlow.scale.setScalar(5);
  nsGroup.add(nsGlow);

  // Clickable proxy
  const nsProxyGeo = new THREE.SphereGeometry(2, 12, 12);
  const nsProxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
  const nsProxy = new THREE.Mesh(nsProxyGeo, nsProxyMat);
  nsProxy.userData = { ...nsData, _cosmicMeta: nsData.cosmicMeta, groupId: 'cosmic-destinations', noHighlight: true };
  nsGroup.add(nsProxy);
  interactiveObjects.push(nsProxy);

  group.add(nsGroup);
  disposables.push(nsGeo, nsMat, jetGeo, jetMat, jetDn.material, nsGlowMat, nsProxyGeo, nsProxyMat);

  // ── Exoplanet system (TRAPPIST-1) ──
  const exData = byId['exoplanet-system'];
  const exGroup = new THREE.Group();
  exGroup.position.set(-52, 10, 38);

  // Central red-dwarf star
  const starGeo = new THREE.SphereGeometry(0.7, 20, 20);
  const starMat = new THREE.MeshBasicMaterial({ color: 0xff7755, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending });
  const star = new THREE.Mesh(starGeo, starMat);
  exGroup.add(star);

  const exGlowMat = new THREE.SpriteMaterial({ map: glowTex, color: 0xff7755, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false });
  const exGlow = new THREE.Sprite(exGlowMat);
  exGlow.scale.setScalar(4);
  exGroup.add(exGlow);

  // Orbiting planets
  const planets = [];
  const planetColors = [0x9fd8d0, 0x4dd0e1, 0xd8b88a];
  for (let p = 0; p < 3; p++) {
    const pr = 1.6 + p * 0.9;
    const pGeo = new THREE.SphereGeometry(0.12 + p * 0.04, 10, 10);
    const pMat = new THREE.MeshBasicMaterial({ color: planetColors[p], transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending });
    const pm = new THREE.Mesh(pGeo, pMat);
    exGroup.add(pm);

    // Orbit ring
    const oPts = [];
    for (let i = 0; i <= 64; i++) {
      const a = (i / 64) * Math.PI * 2;
      oPts.push(new THREE.Vector3(Math.cos(a) * pr, 0, Math.sin(a) * pr));
    }
    const oGeo = new THREE.BufferGeometry().setFromPoints(oPts);
    const oMat = new THREE.LineBasicMaterial({ color: planetColors[p], transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending });
    exGroup.add(new THREE.LineLoop(oGeo, oMat));

    disposables.push(pGeo, pMat, oGeo, oMat);
    planets.push({ mesh: pm, r: pr, speed: 0.4 - p * 0.1, phase: Math.random() * Math.PI * 2 });
  }

  const exProxyGeo = new THREE.SphereGeometry(3, 12, 12);
  const exProxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
  const exProxy = new THREE.Mesh(exProxyGeo, exProxyMat);
  exProxy.userData = { ...exData, _cosmicMeta: exData.cosmicMeta, groupId: 'cosmic-destinations', noHighlight: true };
  exGroup.add(exProxy);
  interactiveObjects.push(exProxy);

  group.add(exGroup);
  disposables.push(starGeo, starMat, exGlowMat, exProxyGeo, exProxyMat);

  function update(t) {
    nsMesh.rotation.y = t * 0.6;
    nsGlow.material.opacity = 0.5 + Math.sin(t * 2) * 0.15;
    jetUp.material.opacity = 0.3 + Math.sin(t * 3) * 0.12;
    jetDn.material.opacity = 0.3 + Math.sin(t * 3 + 1) * 0.12;
    planets.forEach((p) => {
      const a = p.phase + t * p.speed;
      p.mesh.position.set(Math.cos(a) * p.r, 0, Math.sin(a) * p.r);
    });
  }

  function dispose() {
    disposables.forEach((d) => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects };
}