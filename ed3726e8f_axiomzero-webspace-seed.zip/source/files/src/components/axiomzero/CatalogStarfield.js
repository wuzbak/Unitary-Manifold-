import * as THREE from 'three';
import { GAIA_CATALOG, gaiaToVector3 } from '@/lib/topology/gaiaCatalog';
import { starVertexShader, starFragmentShader } from '@/lib/topology/shaders/starEmission';
import { starClassIndex, SPECTRAL_CLASSES } from '@/lib/topology/spectralClasses';

/**
 * CatalogStarfield — data-accurate starfield from real Gaia DR3 coordinates.
 *
 * Two layers:
 * 1. Catalog stars: 1,300 brightest Gaia DR3 sources at real J2016 RA/Dec positions,
 *    rendered with custom physically-based emission shader (blackbody color from Teff,
 *    diffraction spikes, HDR bloom values, apparent-magnitude-driven size).
 * 2. Background fill: procedural stars using real spectral-class abundance
 *    distributions, filling the celestial sphere at configurable density.
 *
 * Returns { group, update, dispose, starfieldLayers, interactiveObjects, catalogStars }
 */
export function createCatalogStarfield({ scene, glowTex, quality = 'balanced' }) {
  const group = new THREE.Group();
  scene.add(group);
  const disposables = [];
  const interactiveObjects = [];

  // ── Layer 1: Catalog stars with custom emission shader (Gaia DR3) ──
  const catalogCount = GAIA_CATALOG.length;
  const catPositions = new Float32Array(catalogCount * 3);
  const catMagnitudes = new Float32Array(catalogCount);
  const catTemperatures = new Float32Array(catalogCount);
  const catSizes = new Float32Array(catalogCount);
  const catPhases = new Float32Array(catalogCount);
  const catNames = [];
  const catUserData = [];

  GAIA_CATALOG.forEach((star, i) => {
    const [x, y, z] = gaiaToVector3(star.ra, star.dec, 400);
    catPositions[i * 3] = x;
    catPositions[i * 3 + 1] = y;
    catPositions[i * 3 + 2] = z;
    catMagnitudes[i] = star.mag;
    catTemperatures[i] = star.teff_k;
    // Size: brighter stars (lower magnitude) are larger — scaled for 1,300-star field
    catSizes[i] = 1.2 + Math.max(0, (3.0 - star.mag)) * 0.6;
    catPhases[i] = Math.random();
    catNames.push(star.name);

    const isNamed = !star.name.startsWith('Gaia DR3');
    catUserData.push({
      id: `catalog-star-${star.source_id}`,
      type: `Star · ${star.spectral_type}`,
      name: star.name,
      description: isNamed
        ? `${star.name} (${star.spectral_type}) — apparent magnitude ${star.mag}, distance ${star.distance_ly} light-years, effective temperature ${star.teff_k.toLocaleString()} K. Catalogued by ESA's Gaia mission with precision astrometry from the Gaia DR3 release.`
        : `Gaia DR3 source ${star.source_id} — apparent magnitude ${star.mag}, distance ${star.distance_ly} light-years, effective temperature ${star.teff_k.toLocaleString()} K. One of the 1,300 brightest sources in the Gaia DR3 catalog, rendered at its real J2016 celestial position with physically-accurate blackbody color.`,
      significance: isNamed
        ? `${star.name} serves as a calibration anchor for stellar astrophysics and the cosmic distance ladder. Its spectral type (${star.spectral_type}) and luminosity test the stellar structure equations and nuclear reaction rates derived from the Unitary Manifold's compactified geometry.`
        : `This star is part of the Gaia DR3 bright-source sample. Its effective temperature (${star.teff_k.toLocaleString()} K) determines its blackbody color via the Planckian locus, and its apparent magnitude (${star.mag}) drives its rendered size and HDR brightness. The spectral class distribution of the full 1,300-star field matches real solar-neighborhood abundance statistics.`,
      links: [
        { label: 'Manifold Explorer', path: '/manifold-explorer' },
        { label: 'Repository', path: '/repository' },
      ],
      _isStarfield: true,
      _isCatalogStar: true,
      _spectralKey: star.spectral_type.charAt(0),
      _temperature: `${star.teff_k.toLocaleString()} K`,
      _mass: 'See spectral class',
      _lifetime: 'See spectral class',
      _fusion: 'Hydrogen → Helium (main sequence)',
      _catalogName: star.name,
      _distance: `${star.distance_ly} ly`,
      _apparentMag: star.mag,
      _spectralType: star.spectral_type,
      _teffK: star.teff_k,
      _distanceLy: star.distance_ly,
      _parallax: star.parallax_mas > 0 ? `${star.parallax_mas.toFixed(3)} mas` : '—',
      _sourceId: star.source_id,
    });
  });

  const catGeo = new THREE.BufferGeometry();
  catGeo.setAttribute('position', new THREE.BufferAttribute(catPositions, 3));
  catGeo.setAttribute('aMagnitude', new THREE.BufferAttribute(catMagnitudes, 1));
  catGeo.setAttribute('aTemperature', new THREE.BufferAttribute(catTemperatures, 1));
  catGeo.setAttribute('aSize', new THREE.BufferAttribute(catSizes, 1));
  catGeo.setAttribute('aPhase', new THREE.BufferAttribute(catPhases, 1));

  const catMat = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uSizeScale: { value: 1.0 },
      uPixelRatio: { value: Math.min(window.devicePixelRatio, 2) },
    },
    vertexShader: starVertexShader,
    fragmentShader: starFragmentShader,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });

  const catalogPoints = new THREE.Points(catGeo, catMat);
  group.add(catalogPoints);
  disposables.push(catGeo, catMat);

  // ── Layer 2: Background fill stars (procedural, real spectral distribution) ──
  const bgCount = quality === 'cinematic' ? 8000 : quality === 'balanced' ? 5000 : 2500;
  const bgPositions = new Float32Array(bgCount * 3);
  const bgColors = new Float32Array(bgCount * 3);
  const bgClassIndices = new Uint8Array(bgCount);

  for (let i = 0; i < bgCount; i++) {
    // Uniform distribution on celestial sphere
    const ra = Math.random() * Math.PI * 2;
    const dec = Math.acos(2 * Math.random() - 1) - Math.PI / 2;
    const radius = 350 + Math.random() * 250;
    // Inline equatorial-to-Cartesian (radians) — same transform as gaiaToVector3
    bgPositions[i * 3] = -radius * Math.cos(dec) * Math.cos(ra);
    bgPositions[i * 3 + 1] = radius * Math.sin(dec);
    bgPositions[i * 3 + 2] = radius * Math.cos(dec) * Math.sin(ra);

    const r = Math.random();
    const cls = starClassIndex(r);
    bgClassIndices[i] = cls;
    const c = new THREE.Color(SPECTRAL_CLASSES[cls].color);
    const bright = 0.4 + Math.random() * 0.6;
    bgColors[i * 3] = c.r * bright;
    bgColors[i * 3 + 1] = c.g * bright;
    bgColors[i * 3 + 2] = c.b * bright;
  }

  const bgGeo = new THREE.BufferGeometry();
  bgGeo.setAttribute('position', new THREE.BufferAttribute(bgPositions, 3));
  bgGeo.setAttribute('color', new THREE.BufferAttribute(bgColors, 3));
  const bgMat = new THREE.PointsMaterial({
    size: 1.5,
    map: glowTex,
    vertexColors: true,
    transparent: true,
    opacity: 0.6,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    sizeAttenuation: true,
  });
  const bgPoints = new THREE.Points(bgGeo, bgMat);
  group.add(bgPoints);
  disposables.push(bgGeo, bgMat);

  // ── Catalog star hit-proxies (single InstancedMesh for all 1,300 stars) ──
  // One draw call, one raycast target. Raycasting an InstancedMesh returns
  // instanceId, which maps directly to the star's catUserData entry — so every
  // Gaia star (bright OR faint) is a reliable click target with star-specific data.
  const proxyGeo = new THREE.SphereGeometry(3.0, 6, 6);
  const proxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false, colorWrite: false });
  const proxyMesh = new THREE.InstancedMesh(proxyGeo, proxyMat, catalogCount);
  const dummy = new THREE.Object3D();
  for (let i = 0; i < catalogCount; i++) {
    dummy.position.set(catPositions[i * 3], catPositions[i * 3 + 1], catPositions[i * 3 + 2]);
    dummy.updateMatrix();
    proxyMesh.setMatrixAt(i, dummy.matrix);
  }
  proxyMesh.instanceMatrix.needsUpdate = true;
  proxyMesh.userData = { id: 'catalog-starfield', isInstanced: true, noHighlight: true };
  group.add(proxyMesh);
  interactiveObjects.push(proxyMesh);
  disposables.push(proxyGeo, proxyMat, proxyMesh);

  function update(t) {
    catMat.uniforms.uTime.value = t;
    // Slow celestial rotation (precession-like)
    group.rotation.y = t * 0.00005;
  }

  function dispose() {
    disposables.forEach((d) => d.dispose());
    scene.remove(group);
  }

  // Starfield layers for spectral-class raycast fallback
  const starfieldLayers = [
    { points: bgPoints, classIndices: bgClassIndices },
  ];

  return {
    group,
    update,
    dispose,
    starfieldLayers,
    interactiveObjects,
    catalogStars: catUserData,
    catalogPoints,
    resolveStar: (i) => catUserData[i] || null,
  };
}