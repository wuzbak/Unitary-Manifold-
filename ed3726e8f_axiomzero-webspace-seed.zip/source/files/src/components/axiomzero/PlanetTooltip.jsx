import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { X, ExternalLink, Orbit, Thermometer, Weight, Ruler, Clock, Moon, Compass, Globe } from 'lucide-react';

/**
 * PlanetTooltip — high-fidelity metadata panel for planets, moons, and the Sun.
 * Appears when a body is clicked in the solar system orrery.
 * Displays scientifically rigorous geological and orbital metadata sourced from
 * NASA Planetary Fact Sheet / JPL Solar System Dynamics.
 */
function MetadataRow({ label, value, icon: Icon, colSpan }) {
  return (
    <div className={`flex items-center justify-between border-b border-[#00f5ff]/10 py-0.5 ${colSpan ? 'col-span-2' : ''}`}>
      <span className="text-[#8b949e] flex items-center gap-1 text-[9px]">
        {Icon && <Icon size={9} className="text-[#484f58]" />}
        {label}
      </span>
      <span className="text-[#00f5ff] font-bold font-mono text-[9px] text-right">{value}</span>
    </div>
  );
}

export default function PlanetTooltip({ body, onClose }) {
  useEffect(() => {
    const handleEsc = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  if (!body) return null;

  const isMoon = body._kind === 'moon';
  const isSun = body._kind === 'sun';

  return (
    <>
      {/* Click-outside backdrop */}
      <div className="absolute inset-0 z-40" onClick={onClose} />

      {/* Tooltip panel — left side to avoid right-side control panel */}
      <div className="absolute top-20 left-4 z-50 w-[calc(100vw-2.5rem)] max-w-sm p-4 clip-corner bg-[#0a0a12]/95 backdrop-blur-md border border-[#4DD0E1]/30 fade-in max-h-[72vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1 min-w-0">
            <div className="text-[#4DD0E1] text-[8px] uppercase tracking-wider mb-1">
              ▸ {isMoon ? `Moon of ${body._parentPlanet || 'Unknown'}` : body.type}
            </div>
            <div className="text-white font-bold text-base">{body.name}</div>
          </div>
          <button onClick={onClose} className="text-[#8b949e] hover:text-[#FF9F00] transition-colors ml-2 shrink-0">
            <X size={16} />
          </button>
        </div>

        {/* Physical properties */}
        <div className="mb-3">
          <div className="text-[#4DD0E1] text-[8px] uppercase tracking-wider mb-1.5">▸ Physical Properties</div>
          <div className="grid grid-cols-2 gap-x-3">
            {body.radiusKm && <MetadataRow label="Radius" value={`${body.radiusKm.toLocaleString()} km`} icon={Ruler} />}
            {body.mass && <MetadataRow label="Mass" value={body.mass} icon={Weight} />}
            {body.density && <MetadataRow label="Density" value={`${body.density} g/cm³`} />}
            {body.gravity && <MetadataRow label="Gravity" value={`${body.gravity} m/s²`} />}
            {body.tempRange && <MetadataRow label="Surface Temp" value={body.tempRange} icon={Thermometer} />}
            {body.surfaceTemp && <MetadataRow label="Surface Temp" value={body.surfaceTemp} icon={Thermometer} />}
            {body.coreTemp && <MetadataRow label="Core Temp" value={body.coreTemp} icon={Thermometer} />}
            {body.composition && <MetadataRow label="Composition" value={body.composition} colSpan />}
            {body.age && <MetadataRow label="Age" value={body.age} icon={Clock} />}
          </div>
        </div>

        {/* Orbital properties */}
        <div className="mb-3">
          <div className="text-[#FF9F00] text-[8px] uppercase tracking-wider mb-1.5">▸ Orbital Properties</div>
          <div className="grid grid-cols-2 gap-x-3">
            {body.semiMajorAxis && <MetadataRow label="Semi-Major Axis" value={body.semiMajorAxis} icon={Orbit} />}
            {body.orbitalPeriod && <MetadataRow label="Orbital Period" value={body.orbitalPeriod} icon={Clock} />}
            {body.orbitalPeriodDays && <MetadataRow label="Orbital Period" value={`${body.orbitalPeriodDays} days`} icon={Clock} />}
            {body.rotationPeriod && <MetadataRow label="Rotation" value={body.rotationPeriod} />}
            {body.axialTilt != null && <MetadataRow label="Axial Tilt" value={`${body.axialTilt}°`} icon={Compass} />}
            {body.semiMajorAxisKm && <MetadataRow label="Orbit Radius" value={`${body.semiMajorAxisKm.toLocaleString()} km`} icon={Orbit} />}
            {body.moonCount != null && <MetadataRow label="Known Moons" value={body.moonCount} icon={Moon} />}
            {isSun && body.rotationPeriod && <MetadataRow label="Rotation" value={body.rotationPeriod} />}
          </div>
        </div>

        {/* Description */}
        <p className="text-[#e6edf3] text-[11px] leading-relaxed mb-3">{body.description}</p>

        {/* Notable moons (for planets) */}
        {body.moons?.length > 0 && (
          <div className="mb-3">
            <div className="text-[#4DD0E1] text-[8px] uppercase tracking-wider mb-1.5">▸ Notable Moons ({body.moonCount} total)</div>
            <div className="space-y-1.5">
              {body.moons.map(m => (
                <div key={m.name} className="text-[10px] leading-relaxed">
                  <span className="text-[#00f5ff] font-bold">{m.name}</span>
                  <span className="text-[#8b949e]"> — {m.description}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Rings info */}
        {body.rings && (
          <div className="mb-3 text-[10px] text-[#8fa0bc] leading-relaxed">
            <span className="text-[#FF9F00] font-bold">▸ Ring System: </span>
            Span {(body.rings.outer - body.rings.inner * 0).toFixed(1)}× radius, opacity {(body.rings.opacity * 100).toFixed(0)}%.
          </div>
        )}

        {/* Scientific significance */}
        {body.significance && (
          <div className="mb-3">
            <div className="text-[#FF9F00] text-[8px] uppercase tracking-wider mb-1">▸ Scientific Significance</div>
            <p className="text-[#8fa0bc] text-[10px] leading-relaxed">{body.significance}</p>
          </div>
        )}

        {/* Links */}
        {body.links?.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {body.links.map((link, i) => (
              <Link
                key={i}
                to={link.path}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-bold bg-[#4DD0E1]/10 border border-[#4DD0E1]/30 text-[#4DD0E1] hover:bg-[#4DD0E1]/20 transition-colors"
              >
                {link.label} <ExternalLink size={10} />
              </Link>
            ))}
          </div>
        )}

        {/* Data source attribution */}
        <div className="mt-3 pt-2 border-t border-[#30363d] text-[8px] text-[#484f58] tracking-wider">
          Source: NASA Planetary Fact Sheet · JPL Solar System Dynamics
        </div>
      </div>
    </>
  );
}