import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { X, ExternalLink } from 'lucide-react';

/**
 * CosmicInfoCard — glassmorphic HUD panel that appears when a user clicks
 * an interactive torus element or cosmic body. Shows scientific description,
 * physics significance, and links to relevant work pages.
 * Dismissible via X button, Escape key, or click-outside.
 */
export default function CosmicInfoCard({ element, onClose }) {
  useEffect(() => {
    const handleEsc = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  if (!element) return null;

  return (
    <>
      {/* Click-outside backdrop */}
      <div className="absolute inset-0 z-40" onClick={onClose} />

      {/* Info card */}
      <div className="absolute bottom-5 right-5 z-50 w-[calc(100vw-2.5rem)] max-w-md p-4 clip-corner bg-[#0a0a12]/95 backdrop-blur-md border border-[#FF9F00]/30 fade-in">
        <div className="flex items-start justify-between mb-2">
          <div className="flex-1 min-w-0">
            <div className="text-[#4DD0E1] text-[8px] uppercase tracking-wider mb-1">▸ {element.type}</div>
            <div className="text-white font-bold text-sm">{element.name}</div>
          </div>
          <button onClick={onClose} className="text-[#8b949e] hover:text-[#FF9F00] transition-colors ml-2 shrink-0">
            <X size={16} />
          </button>
        </div>

        <p className="text-[#e6edf3] text-[11px] leading-relaxed mb-3">{element.description}</p>

        {element._isStarfield && (
          <div className="mb-3 grid grid-cols-2 gap-1.5 text-[9px]">
            {element._spectralType && (
              <div className="flex justify-between border-b border-[#00f5ff]/10 pb-0.5">
                <span className="text-[#8b949e]">Spectral Class</span>
                <span className="text-[#FF9F00] font-bold">{element._spectralType}</span>
              </div>
            )}
            {element._temperature && (
              <div className="flex justify-between border-b border-[#00f5ff]/10 pb-0.5">
                <span className="text-[#8b949e]">Temperature</span>
                <span className="text-[#00f5ff] font-bold">{element._temperature}</span>
              </div>
            )}
            {element._apparentMag != null && (
              <div className="flex justify-between border-b border-[#00f5ff]/10 pb-0.5">
                <span className="text-[#8b949e]">Apparent Mag</span>
                <span className="text-[#00f5ff] font-bold">{element._apparentMag.toFixed(2)}</span>
              </div>
            )}
            {element._distance && (
              <div className="flex justify-between border-b border-[#00f5ff]/10 pb-0.5">
                <span className="text-[#8b949e]">Distance</span>
                <span className="text-[#00f5ff] font-bold">{element._distance}</span>
              </div>
            )}
            {element._parallax && (
              <div className="flex justify-between border-b border-[#00f5ff]/10 pb-0.5">
                <span className="text-[#8b949e]">Parallax</span>
                <span className="text-[#00f5ff] font-bold">{element._parallax}</span>
              </div>
            )}
            {element._mass && (
              <div className="flex justify-between border-b border-[#00f5ff]/10 pb-0.5">
                <span className="text-[#8b949e]">Mass</span>
                <span className="text-[#00f5ff] font-bold">{element._mass}</span>
              </div>
            )}
            {element._lifetime && (
              <div className="flex justify-between border-b border-[#00f5ff]/10 pb-0.5">
                <span className="text-[#8b949e]">Lifetime</span>
                <span className="text-[#00f5ff] font-bold">{element._lifetime}</span>
              </div>
            )}
            {element._catalogName && (
              <div className="flex justify-between border-b border-[#00f5ff]/10 pb-0.5">
                <span className="text-[#8b949e]">Catalog</span>
                <span className="text-[#4DD0E1] font-bold">{element._catalogName}</span>
              </div>
            )}
            {element._sourceId && (
              <div className="col-span-2 flex justify-between border-b border-[#00f5ff]/10 pb-0.5">
                <span className="text-[#8b949e]">Gaia Source ID</span>
                <span className="text-[#4DD0E1] font-mono text-[8px]">{element._sourceId}</span>
              </div>
            )}
            {element._fusion && (
              <div className="col-span-2 border-b border-[#00f5ff]/10 pb-0.5">
                <span className="text-[#8b949e]">Fusion: </span>
                <span className="text-[#4DD0E1]">{element._fusion}</span>
              </div>
            )}
          </div>
        )}

        {element._missionStatus && (
          <div className="mb-3 grid grid-cols-2 gap-1.5 text-[9px]">
            <div className="flex justify-between border-b border-[#FF9F00]/10 pb-0.5">
              <span className="text-[#8b949e]">Status</span>
              <span className={`font-bold ${element._missionStatus === 'Active' ? 'text-[#3fb950]' : 'text-[#FF9F00]'}`}>{element._missionStatus}</span>
            </div>
            <div className="flex justify-between border-b border-[#FF9F00]/10 pb-0.5">
              <span className="text-[#8b949e]">Agency</span>
              <span className="text-[#00f5ff] font-bold">{element._missionAgency}</span>
            </div>
            <div className="col-span-2 flex justify-between border-b border-[#FF9F00]/10 pb-0.5">
              <span className="text-[#8b949e]">Launch</span>
              <span className="text-[#00f5ff] font-bold">{element._missionLaunch}</span>
            </div>
          </div>
        )}

        {element._cosmicMeta?.length > 0 && (
          <div className="mb-3 grid grid-cols-2 gap-1.5 text-[9px]">
            {element._cosmicMeta.map((m, i) => (
              <div key={i} className="flex justify-between border-b border-[#4DD0E1]/10 pb-0.5">
                <span className="text-[#8b949e]">{m.label}</span>
                <span className="text-[#4DD0E1] font-bold">{m.value}</span>
              </div>
            ))}
          </div>
        )}

        {element._pillarFormula && (
          <div className="mb-3 text-[9px]">
            <div className="border-b border-[#00f5ff]/10 pb-1 mb-1">
              <span className="text-[#8b949e]">Formula: </span>
              <span className="text-[#00f5ff] font-mono font-bold">{element._pillarFormula}</span>
            </div>
            <div className="flex justify-between border-b border-[#00f5ff]/10 pb-0.5">
              <span className="text-[#8b949e]">Pillar Status</span>
              <span className={`font-bold ${element._pillarStatus === 'HARDGATE' ? 'text-[#FF9F00]' : element._pillarStatus === 'CERTIFIED' ? 'text-[#3fb950]' : 'text-[#4DD0E1]'}`}>{element._pillarStatus}</span>
            </div>
          </div>
        )}

        {element.significance && (
          <div className="mb-3">
            <div className="text-[#FF9F00] text-[8px] uppercase tracking-wider mb-1">▸ Physics Significance</div>
            <p className="text-[#8fa0bc] text-[10px] leading-relaxed">{element.significance}</p>
          </div>
        )}

        {element.links?.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {element.links.map((link, i) => (
              link.href ? (
                <a
                  key={i}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-bold bg-[#FF9F00]/10 border border-[#FF9F00]/30 text-[#FF9F00] hover:bg-[#FF9F00]/20 transition-colors"
                >
                  {link.label} <ExternalLink size={10} />
                </a>
              ) : (
                <Link
                  key={i}
                  to={link.path}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-bold bg-[#FF9F00]/10 border border-[#FF9F00]/30 text-[#FF9F00] hover:bg-[#FF9F00]/20 transition-colors"
                >
                  {link.label} <ExternalLink size={10} />
                </Link>
              )
            ))}
          </div>
        )}
      </div>
    </>
  );
}