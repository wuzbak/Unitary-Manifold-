import * as THREE from 'three';
import { PLANETS, SUN_DATA } from '@/lib/topology/planetData';
import {
  makeSunTexture, makeMercuryTexture, makeVenusTexture, makeEarthTexture, makeEarthCloudTexture,
  makeMarsTexture, makeJupiterTexture, makeSaturnTexture, makeUranusTexture, makeNeptuneTexture, makeMoonTexture,
} from '@/lib/topology/planetTextures';
import { createAtmosphereShells } from '@/components/axiomzero/AtmosphereShells';
import { orbitalPosition, computeRotationSpeed } from '@/lib/topology/keplerian';

/**
 * Solar System orrery — scientifically grounded, HD textured.
 * All 8 planets with procedural textures, axial tilts, rotation, moons, and rings.
 * Accuracy: NASA Planetary Fact Sheet. Scale compressed per orrery convention.
 */

const EARTH_PERIOD_SECONDS = 90;
const SIZE_SCALE = 1.6;

export function createSolarSystem({ scene, glowTex }) {
  const group = new THREE.Group();
  group.position.set(42, -8, -52);
  group.rotation.set(0.10, 0.50, 0.05);
  group.scale.setScalar(2.5);

  const disposables = [];
  const planetMap = {};
  const interactiveBodies = [];
  const bodies = [];

  // Generate all textures once
  const textures = {
    sun: makeSunTexture(),
    mercury: makeMercuryTexture(),
    venus: makeVenusTexture(),
    earth: makeEarthTexture(),
    earthCloud: makeEarthCloudTexture(),
    mars: makeMarsTexture(),
    jupiter: makeJupiterTexture(),
    saturn: makeSaturnTexture(),
    uranus: makeUranusTexture(),
    neptune: makeNeptuneTexture(),
    moon: makeMoonTexture(),
  };
  Object.values(textures).forEach(t => disposables.push(t));

  // ── Sun ──
  const sunGeo = new THREE.SphereGeometry(2.0, 64, 64);
  // Sun stays self-lit (emissive look) but tinted dimmer so it doesn't blow out nearby planets
  const sunMat = new THREE.MeshBasicMaterial({ map: textures.sun, color: 0xffe0a0 });
  const sun = new THREE.Mesh(sunGeo, sunMat);
  sun.userData = {
    id: 'sun', type: SUN_DATA.type, name: SUN_DATA.name,
    description: SUN_DATA.description, significance: SUN_DATA.significance,
    links: SUN_DATA.links,
    visualRadius: 2.0,
    radiusKm: SUN_DATA.radiusKm, mass: SUN_DATA.mass, surfaceTemp: SUN_DATA.surfaceTemp,
  };
  group.add(sun);
  disposables.push(sunGeo, sunMat);
  interactiveBodies.push(sun);

  // Real point light at the sun — illuminates planets with day/night terminators
  // decay=0 + distance=0 → no falloff, so Neptune is lit as well as Mercury
  const sunLight = new THREE.PointLight(0xfff2d6, 3.0, 0, 0);
  group.add(sunLight);

  // Reduced glow — was opacity 0.7 / scale 6
  const sunGlowMat = new THREE.SpriteMaterial({ map: glowTex, color: 0xffe8a0, transparent: true, opacity: 0.30, blending: THREE.AdditiveBlending, depthWrite: false });
  const sunGlow = new THREE.Sprite(sunGlowMat);
  sunGlow.scale.setScalar(5);
  group.add(sunGlow);
  disposables.push(sunGlowMat);

  // Reduced halo — was opacity 0.22 / scale 12
  const sunHaloMat = new THREE.SpriteMaterial({ map: glowTex, color: 0xffcc66, transparent: true, opacity: 0.10, blending: THREE.AdditiveBlending, depthWrite: false });
  const sunHalo = new THREE.Sprite(sunHaloMat);
  sunHalo.scale.setScalar(8);
  group.add(sunHalo);
  disposables.push(sunHaloMat);

  // ── Planets ──
  PLANETS.forEach((p) => {
    // Orbit path — Keplerian ellipse with sun at focus, tilted by inclination
    const e = p.eccentricity || 0;
    const inc = (p.inclination || 0) * Math.PI / 180;
    const omega = (p.argumentOfPerihelion || 0) * Math.PI / 180;
    const aSemi = p.visualOrbit;
    const bSemi = aSemi * Math.sqrt(1 - e * e);
    const cw = Math.cos(omega), sw = Math.sin(omega);
    const si = Math.sin(inc), ci = Math.cos(inc);
    const orbitPts = [];
    for (let i = 0; i <= 256; i++) {
      const E = (i / 256) * Math.PI * 2;
      const xOrb = aSemi * (Math.cos(E) - e);
      const zOrb = bSemi * Math.sin(E);
      const xRot = xOrb * cw + zOrb * sw;
      const zRot = -xOrb * sw + zOrb * cw;
      orbitPts.push(new THREE.Vector3(xRot, zRot * si, zRot * ci));
    }
    const orbitGeo = new THREE.BufferGeometry().setFromPoints(orbitPts);
    const orbitMat = new THREE.LineBasicMaterial({ color: 0x4dd0e1, transparent: true, opacity: 0.05, blending: THREE.AdditiveBlending });
    group.add(new THREE.LineLoop(orbitGeo, orbitMat));
    disposables.push(orbitGeo, orbitMat);

    // Planet body — HD segments + texture
    const segs = p.textureType === 'gas' || p.textureType === 'ice' ? 128 : 64;
    const pGeo = new THREE.SphereGeometry(p.visualRadius * SIZE_SCALE, segs, segs);
    // Lit material — sun point light produces day/night terminator phases
    const pMat = new THREE.MeshStandardMaterial({ map: textures[p.id] || textures.moon, roughness: 0.92, metalness: 0.0 });
    const planet = new THREE.Mesh(pGeo, pMat);
    planet.userData = {
      id: `planet-${p.id}`, type: p.type, name: p.name,
      description: p.description, significance: p.significance, links: p.links,
      visualRadius: p.visualRadius * SIZE_SCALE,
      radiusKm: p.radiusKm, mass: p.mass, density: p.density, gravity: p.gravity,
      semiMajorAxis: p.semiMajorAxis, orbitalPeriod: p.orbitalPeriod,
      rotationPeriod: p.rotationPeriod, tempRange: p.tempRange, moonCount: p.moonCount,
    };
    // Axial tilt
    planet.rotation.z = (p.axialTilt || 0) * Math.PI / 180;
    group.add(planet);
    disposables.push(pGeo, pMat);
    interactiveBodies.push(planet);
    planetMap[p.id] = planet;

    // Glow
    const pGlowMat = new THREE.SpriteMaterial({ map: glowTex, color: p.color, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false });
    const pGlow = new THREE.Sprite(pGlowMat);
    pGlow.scale.setScalar(p.visualRadius * SIZE_SCALE * 3.5);
    group.add(pGlow);
    disposables.push(pGlowMat);

    // Rings
    let ringsMesh = null;
    if (p.rings) {
      const ringGeo = new THREE.RingGeometry(
        p.visualRadius * SIZE_SCALE * p.rings.inner,
        p.visualRadius * SIZE_SCALE * p.rings.outer,
        128
      );
      // Add radial color variation to ring
      const ringColorArr = new Float32Array(ringGeo.attributes.position.count * 3);
      const rc = new THREE.Color(p.rings.color);
      for (let i = 0; i < ringGeo.attributes.position.count; i++) {
        const px = ringGeo.attributes.position.getX(i), py = ringGeo.attributes.position.getY(i);
        const rad = Math.sqrt(px * px + py * py);
        const rt = (rad - p.visualRadius * SIZE_SCALE * p.rings.inner) / (p.visualRadius * SIZE_SCALE * (p.rings.outer - p.rings.inner));
        const v = 0.6 + Math.sin(rt * 30) * 0.2 + Math.random() * 0.15;
        ringColorArr[i * 3] = rc.r * v; ringColorArr[i * 3 + 1] = rc.g * v; ringColorArr[i * 3 + 2] = rc.b * v;
      }
      ringGeo.setAttribute('color', new THREE.BufferAttribute(ringColorArr, 3));
      const ringMat = new THREE.MeshBasicMaterial({
        vertexColors: true, transparent: true, opacity: p.rings.opacity, side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending, depthWrite: false,
      });
      ringsMesh = new THREE.Mesh(ringGeo, ringMat);
      ringsMesh.rotation.x = Math.PI / 2 - (p.axialTilt || 0) * Math.PI / 180;
      planet.add(ringsMesh);
      disposables.push(ringGeo, ringMat);

      // Cassini Division for Saturn
      if (p.id === 'saturn') {
        const divGeo = new THREE.RingGeometry(
          p.visualRadius * SIZE_SCALE * 1.82, p.visualRadius * SIZE_SCALE * 1.88, 128
        );
        const divMat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.7, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false });
        const div = new THREE.Mesh(divGeo, divMat);
        div.rotation.x = Math.PI / 2 - p.axialTilt * Math.PI / 180;
        planet.add(div);
        disposables.push(divGeo, divMat);
      }
    }

    // Earth cloud layer
    let cloudsMesh = null;
    if (p.id === 'earth') {
      const cloudGeo = new THREE.SphereGeometry(p.visualRadius * SIZE_SCALE * 1.02, 64, 64);
      const cloudMat = new THREE.MeshStandardMaterial({ map: textures.earthCloud, transparent: true, opacity: 0.55, roughness: 1.0, metalness: 0.0, depthWrite: false });
      cloudsMesh = new THREE.Mesh(cloudGeo, cloudMat);
      planet.add(cloudsMesh);
      disposables.push(cloudGeo, cloudMat);
    }

    // Moons
    const moonMeshes = [];
    if (p.moons && p.moons.length > 0) {
      p.moons.forEach((m, mi) => {
        const mRadius = Math.max(0.008, m.visualRadius * SIZE_SCALE);
        const mGeo = new THREE.SphereGeometry(mRadius, 24, 24);
        const mMat = new THREE.MeshStandardMaterial({
          map: m.textureType === 'cratered' ? textures.moon : null,
          color: m.textureType === 'cratered' ? 0xffffff : m.color,
          roughness: 0.95, metalness: 0.0,
        });
        const moon = new THREE.Mesh(mGeo, mMat);
        moon.userData = {
          id: `moon-${p.id}-${m.name.toLowerCase()}`,
          type: 'Moon',
          name: m.name,
          description: m.description || `${m.name}, moon of ${p.name}`,
          significance: '',
          links: p.links,
          orbitalPeriodDays: m.orbitalPeriodDays,
          semiMajorAxisKm: m.semiMajorAxisKm,
        };
        group.add(moon);
        disposables.push(mGeo, mMat);
        interactiveBodies.push(moon);
        moonMeshes.push({
          mesh: moon, orbit: m.visualOrbit, period: m.visualPeriod, phase: mi * 0.7 + 0.3,
          eccentricity: m.eccentricity || 0,
          inclination: (m.inclination || 0) * Math.PI / 180,
          argPeri: 0,
        });
      });
    }

    bodies.push({
      planet, pGlow, clouds: cloudsMesh, rings: ringsMesh,
      orbit: p.visualOrbit, period: p.visualPeriod, phase: p.visualPhase,
      eccentricity: p.eccentricity || 0,
      inclination: (p.inclination || 0) * Math.PI / 180,
      argPeri: (p.argumentOfPerihelion || 0) * Math.PI / 180,
      rotationSpeed: computeRotationSpeed(p.rotationPeriodHours),
      moons: moonMeshes,
    });
  });

  scene.add(group);

  // ── Find Titan's mesh (Saturn's largest moon — has a dense atmosphere) ──
  const titanMesh = bodies.find((b) => b.planet.userData.id === 'planet-saturn')?.moons
    .find((m) => m.mesh.userData.name === 'Titan')?.mesh;

  // ── Create physically-based atmosphere shells for atmospheric bodies ──
  const atmosphereShells = createAtmosphereShells({
    group,
    planetMap,
    sun,
    extraBodies: titanMesh ? [{ id: 'titan', mesh: titanMesh }] : [],
  });

  function update(t, camera) {
    sunGlow.material.opacity = 0.28 + Math.sin(t * 0.3) * 0.04;
    sunHalo.material.opacity = 0.09 + Math.sin(t * 0.2) * 0.02;
    sun.rotation.y += 0.001;

    bodies.forEach((b) => {
      // Keplerian orbital position — sun at one focus of the ellipse
      const M = b.phase + (t / (b.period * EARTH_PERIOD_SECONDS * 2.5)) * Math.PI * 2;
      const pos = orbitalPosition(b.orbit, b.eccentricity, b.inclination, b.argPeri, M);
      b.planet.position.set(pos.x, pos.y, pos.z);
      b.pGlow.position.copy(b.planet.position);

      // Planet rotation — scaled to true relative sidereal period
      b.planet.rotation.y += b.rotationSpeed;

      // Cloud rotation (slightly faster)
      if (b.clouds) {
        b.clouds.rotation.y += b.rotationSpeed * 1.2;
      }

      // Moon positions — Keplerian relative to planet
      b.moons.forEach((m) => {
        const ma = m.phase + (t / (m.period * EARTH_PERIOD_SECONDS * 2.5)) * Math.PI * 2;
        const mpos = orbitalPosition(m.orbit, m.eccentricity, m.inclination, m.argPeri, ma);
        m.mesh.position.set(
          b.planet.position.x + mpos.x,
          b.planet.position.y + mpos.y,
          b.planet.position.z + mpos.z
        );
        m.mesh.rotation.y += 0.005;
      });
    });

    // Update atmosphere shells — sun direction + camera position
    atmosphereShells.update(camera);
  }

  function dispose() {
    atmosphereShells.dispose();
    disposables.forEach(d => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects: interactiveBodies, planets: planetMap, atmosphereShells };
}