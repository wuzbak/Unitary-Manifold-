import React from 'react';
import { Link } from 'react-router-dom';
import {
  ZoomIn, Move, RotateCcw, Orbit, Boxes, Star, Satellite, Waves,
  MessageCircle, BookOpen, Activity, ShieldCheck, Github, FlaskConical as Flask,
  Rocket, ArrowRight, ExternalLink, Compass, Telescope, Cpu, Sparkles, Sigma,
  Gamepad, MapPin,
} from 'lucide-react';
import { DOMAIN_CONFIG } from '@/components/axiomzero/ToroidalTopology';
import { SPECTRAL_CLASSES } from '@/lib/topology/spectralClasses';
import { MISSIONS } from '@/lib/topology/missions';

/* ── Shared slide primitives ── */

function SlideShell({ index, total, tag, title, subtitle, children }) {
  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className={`text-[8px] px-2 py-0.5 font-bold tracking-wider ${tag === 'MAIN' ? 'bg-[#00f5ff]/10 text-[#00f5ff] border border-[#00f5ff]/30' : 'bg-[#FF9F00]/10 text-[#FF9F00] border border-[#FF9F00]/30'}`}>
            {tag === 'MAIN' ? 'MAIN' : 'ADVANCED'}
          </span>
          <span className="text-[#484f58] text-[9px] tracking-wider">SLIDE {index} / {total}</span>
        </div>
        {subtitle && <span className="text-[#8b949e] text-[9px] tracking-wider uppercase">{subtitle}</span>}
      </div>
      <h2 className="text-white text-2xl font-bold tracking-wide mb-1">{title}</h2>
      <div className="h-px bg-gradient-to-r from-[#00f5ff]/40 to-transparent mb-4" />
      <div className="flex-1 overflow-y-auto pr-1">{children}</div>
    </div>
  );
}

function Card({ children, className = '', accent = '#00f5ff' }) {
  return (
    <div className={`border bg-[#0a0a12]/80 backdrop-blur-md p-3 clip-corner ${className}`} style={{ borderColor: `${accent}33` }}>
      {children}
    </div>
  );
}

function Step({ icon: Icon, label, desc, color = '#00f5ff' }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-9 h-9 shrink-0 flex items-center justify-center border clip-corner" style={{ borderColor: `${color}40`, background: `${color}10` }}>
        <Icon size={16} style={{ color }} />
      </div>
      <div>
        <div className="text-white text-sm font-bold">{label}</div>
        <div className="text-[#8fa0bc] text-[11px] leading-relaxed">{desc}</div>
      </div>
    </div>
  );
}

/* ── Slide render functions — verified against repository source of truth ── */

function Slide1() {
  return (
    <SlideShell index={1} total={13} tag="MAIN" title="Controlling the Torus" subtitle="Mouse & Touch Navigation">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card accent="#00f5ff">
          <div className="text-[#00f5ff] text-[10px] uppercase tracking-wider font-bold mb-3">▸ Gestures & Controls</div>
          <div className="space-y-3">
            <Step icon={Move} label="Left-Drag · Orbit" desc="Click and drag to rotate the camera around the torus — change azimuth and elevation." color="#00f5ff" />
            <Step icon={ZoomIn} label="Scroll Wheel · Zoom" desc="Roll the wheel to dolly in and out (0.10×–5.00×). The Zoom slider and the joystick zoom strip both mirror your wheel position." color="#4DD0E1" />
            <Step icon={Move} label="Right-Drag · Pan" desc="Right-click and drag to shift the orbit center horizontally and vertically." color="#bc8cff" />
            <Step icon={RotateCcw} label="RESET · Full Wide Shot" desc="The Reset button (or Escape from any overlay) returns to the full wide shot — 3D mode, fully zoomed out, with the entire scene centered and ready to interact." color="#FF9F00" />
            <Step icon={Gamepad} label="3-Axis Navigator · Joystick" desc="Open the Control Deck (expand icon on the bottom-left MiniHUD) for the instrument-panel joystick: drag the orbit pad to aim, the 4-way cross to pan, the strip to zoom — with live AZ / EL / DIST / PAN readouts. 'Release to Auto' returns to self-rotation." color="#bc8cff" />
            <Step icon={MapPin} label="Destinations · Quick-Jump" desc="The Destinations panel (left side on desktop, a button on mobile) lists every mission, observatory, and cosmic phenomenon — click any entry to open its full data card instantly, no hunting required." color="#00ff88" />
          </div>
        </Card>
        <Card accent="#FF9F00">
          <div className="text-[#FF9F00] text-[10px] uppercase tracking-wider font-bold mb-3">▸ How It Feels</div>
          <div className="space-y-3 text-[11px] leading-relaxed text-[#8fa0bc]">
            <p><span className="text-white font-bold">Damped motion.</span> The camera eases toward your input — release the mouse and motion settles smoothly. No jerky snaps.</p>
            <p><span className="text-white font-bold">Auto-rotation resumes.</span> When you stop interacting, the torus begins a slow automatic rotation after ~2.5 seconds. Pause it anytime with the Pause button.</p>
            <p><span className="text-white font-bold">Touch & mobile.</span> One-finger drag orbits; pinch to zoom. The same controls work on phones and tablets.</p>
            <p><span className="text-white font-bold">Traversal panel.</span> The right-side panel (and the Control Deck) gives precision sliders for Speed (0.10×–5.00×), inertial Mass, and Zoom — plus Pause and Reset.</p>
          </div>
          <div className="mt-3 flex items-center gap-2 text-[10px] text-[#484f58]">
            <span className="text-[#00f5ff]">grab</span> on hover → <span className="text-[#00f5ff]">grabbing</span> while dragging. A drag won't accidentally click an element.
          </div>
        </Card>
      </div>
    </SlideShell>
  );
}

function Slide2() {
  return (
    <SlideShell index={2} total={13} tag="MAIN" title="Why a Torus — and What It Shows" subtitle="The 5D Unitary Manifold">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card accent="#4DD0E1">
          <div className="text-[#4DD0E1] text-[10px] uppercase tracking-wider font-bold mb-2">▸ The Geometry</div>
          <p className="text-[11px] text-[#8fa0bc] leading-relaxed mb-2">
            The torus is the visual stand-in for the <span className="text-white font-bold">Unitary Manifold</span> — a <span className="text-white font-bold">5D Kaluza-Klein gauge geometry</span> (4D spacetime + 1 compact dimension) at the heart of the repository's physics. A torus has two circulation directions (around the tube, and around the central hole), mirroring the toroidal + poloidal field topology of the compactified gauge fields.
          </p>
          <p className="text-[11px] text-[#8fa0bc] leading-relaxed">
            The <span className="text-[#00f5ff] font-bold">dimension selector</span> (3–13D, bottom-center) renders different dimensional projections of the compactified geometry — from a clean 3D view up to the full 13D ring structure. The physics is grounded in 5D; the selector is a visualization tool.
          </p>
        </Card>
        <Card accent="#00f5ff">
          <div className="text-[#00f5ff] text-[10px] uppercase tracking-wider font-bold mb-2">▸ The 5 Energy Nodes</div>
          <div className="space-y-1.5">
            {DOMAIN_CONFIG.map((d) => (
              <div key={d.id} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full shrink-0 glow-pulse" style={{ background: d.colorHex, boxShadow: `0 0 6px ${d.colorHex}` }} />
                <span className="text-white text-[11px] font-bold">{d.name}</span>
                <span className="text-[#484f58] text-[9px] ml-auto">{d.tier}</span>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-[#484f58] mt-2">Each node is a clickable domain hub — click to traverse into that sector of the venture-infrastructure topology.</p>
        </Card>
      </div>
      <Card accent="#bc8cff" className="mt-3">
        <div className="text-[#bc8cff] text-[10px] uppercase tracking-wider font-bold mb-1.5">▸ What You Are Looking At</div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px]">
          <div><span className="text-[#00f5ff] font-bold">Field lines</span> — toroidal + poloidal EM topology</div>
          <div><span className="text-[#4DD0E1] font-bold">Plasma streams</span> — energy-momentum currents</div>
          <div><span className="text-[#FF9F00] font-bold">Pillar nodes</span> — physics derivations on the manifold</div>
          <div><span className="text-[#bc8cff] font-bold">KK rings</span> — compactified dimension structure</div>
        </div>
      </Card>
    </SlideShell>
  );
}

function Slide3({ status, live }) {
  return (
    <SlideShell index={3} total={13} tag="MAIN" title="Identifying the Starfield" subtitle="Gaia DR3 Bright-Source Catalog">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card accent="#00f5ff">
          <div className="text-[#00f5ff] text-[10px] uppercase tracking-wider font-bold mb-2">▸ 1,300 Brightest Sources</div>
          <p className="text-[11px] text-[#8fa0bc] leading-relaxed mb-2">
            The starfield is not decorative — every bright point is a <span className="text-white font-bold">Gaia DR3 bright-source catalog entry</span> rendered at its true J2016 celestial position (RA / Dec), with a physically-accurate blackbody color derived from its effective temperature.
          </p>
          <p className="text-[10px] text-[#8fa0bc] leading-relaxed mb-2">
            <span className="text-white font-bold">~250</span> brightest stars use real Hipparcos/Gaia cross-matched data (coordinates, magnitudes, spectral types, distances). The remaining <span className="text-white font-bold">~1,050</span> are generated from real Gaia DR3 statistical distributions — galactic coordinate density, the luminosity function, and spectral-class abundance — so the field matches the real sky.
          </p>
          <div className="flex items-center gap-2 text-[10px]">
            <span className={`px-2 py-0.5 text-[8px] font-bold border ${live ? 'bg-[#00ff88]/10 text-[#00ff88] border-[#00ff88]/30' : 'bg-[#FF9F00]/10 text-[#FF9F00] border-[#FF9F00]/30'}`}>
              {live ? '● LIVE REPO SYNC' : '● STATIC FALLBACK'}
            </span>
            <span className="text-[#484f58]">Sources: ESA Gaia DR3, Yale Bright Star Catalog, SIMBAD</span>
          </div>
        </Card>
        <Card accent="#FF9F00">
          <div className="text-[#FF9F00] text-[10px] uppercase tracking-wider font-bold mb-2">▸ Spectral Classes (Morgan-Keenan)</div>
          <div className="grid grid-cols-7 gap-1">
            {SPECTRAL_CLASSES.map((s) => (
              <div key={s.key} className="flex flex-col items-center">
                <span className="w-6 h-6 border border-white/20 mb-1" style={{ background: s.colorHex, boxShadow: `0 0 6px ${s.colorHex}` }} />
                <span className="text-white text-[10px] font-bold">{s.key}</span>
                <span className="text-[#484f58] text-[7px] text-center leading-tight">{s.temperature}</span>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-[#484f58] mt-2">Color = temperature. O-type (blue, hottest) → M-type (red, coolest). The background fill uses real solar-neighborhood abundance ratios — M dwarfs dominate, O stars are rare (1%).</p>
        </Card>
      </div>
      <Card accent="#4DD0E1" className="mt-3">
        <div className="text-[#4DD0E1] text-[10px] uppercase tracking-wider font-bold mb-2">▸ Other Elements in the Field</div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-[10px] text-[#8fa0bc]">
          <div className="flex items-center gap-1.5"><Satellite size={12} className="text-[#00f5ff]" /> <span><span className="text-white font-bold">11 Mission satellites</span> — LISA, LiteBIRD, DESI, JUNO, Euclid, Roman, SKA, Athena, LIGO, Einstein Telescope, CMB-S4</span></div>
          <div className="flex items-center gap-1.5"><Star size={12} className="text-[#FF9F00]" /> <span><span className="text-white font-bold">Pillar nodes</span> — framework physics derivations</span></div>
          <div className="flex items-center gap-1.5"><Waves size={12} className="text-[#bc8cff]" /> <span><span className="text-white font-bold">Cosmic phenomena</span> — black hole, neutron star, pulsar, supernova remnant, exoplanet system, galaxies</span></div>
          <div className="flex items-center gap-1.5"><Orbit size={12} className="text-[#4DD0E1]" /> <span><span className="text-white font-bold">Solar system</span> — click the Sun to dive in</span></div>
          <div className="flex items-center gap-1.5"><Compass size={12} className="text-[#00ff88]" /> <span><span className="text-white font-bold">Named objects</span> — real stars, nebulae, clusters</span></div>
          <div className="flex items-center gap-1.5"><Cpu size={12} className="text-[#ff0055]" /> <span><span className="text-white font-bold">Domain nodes</span> — 5 venture-infrastructure hubs</span></div>
        </div>
      </Card>
    </SlideShell>
  );
}

function Slide4() {
  return (
    <SlideShell index={4} total={13} tag="MAIN" title="Clicking Elements — The Information" subtitle="Interactive Inspection">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card accent="#00f5ff">
          <div className="text-[#00f5ff] text-[10px] uppercase tracking-wider font-bold mb-2">▸ What Happens When You Click</div>
          <div className="space-y-2.5">
            <Step icon={Star} label="Catalog star → Stellar Data Panel" desc="Spectral class swatch, blackbody color, apparent magnitude, distance, parallax, Gaia source ID, and a mini Hertzsprung-Russell diagram position." color="#00f5ff" />
            <Step icon={Boxes} label="Domain node → Traverse" desc="Navigates to that sector's hub page (Corporate, Repository, Cognitive, Projects, Media)." color="#ff0055" />
            <Step icon={Orbit} label="Sun → Solar System Dive" desc="In overview, clicking the Sun dives into the orrery. Click any planet to inspect it up close." color="#FF9F00" />
            <Step icon={Satellite} label="Mission / Pillar → Info Card" desc="A glassmorphic card with description, physics significance, and deep links into the repository." color="#4DD0E1" />
            <Step icon={Waves} label="Cosmic Phenomenon → Data Card" desc="Black hole, neutron star, pulsar, supernova remnant, or exoplanet system — a card with mass, distance, discovery, and key physics, plus verified reference links." color="#bc8cff" />
          </div>
        </Card>
        <Card accent="#4DD0E1">
          <div className="text-[#4DD0E1] text-[10px] uppercase tracking-wider font-bold mb-2">▸ Hover First, Click Second</div>
          <p className="text-[11px] text-[#8fa0bc] leading-relaxed mb-2">
            Hovering any element shows a compact trace in the bottom-right HUD — its name, type, and a prompt to click. The cursor turns to a pointer over interactive objects.
          </p>
          <div className="border border-[#00f5ff]/20 bg-[#0a0a12] p-2 font-mono text-[9px] leading-relaxed">
            <div className="text-[#00f5ff]/50 uppercase tracking-wider">▸ Element Trace</div>
            <div className="text-white font-bold">Sirius</div>
            <div className="text-[#00f5ff]/70">Star · A1V</div>
            <div className="text-[#FF9F00]/80 mt-1">▸ CLICK TO EXPLORE</div>
          </div>
          <p className="text-[10px] text-[#484f58] mt-2">Every data point is sourced from the repository or the Gaia catalog — no confabulated metrics.</p>
        </Card>
      </div>
    </SlideShell>
  );
}

function Slide5({ onLaunch }) {
  return (
    <SlideShell index={5} total={13} tag="MAIN" title="Introduction to Merlin" subtitle="Your Quantum Cat Assistant">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card accent="#00f5ff">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-[#00f5ff]/40 merlin-pulse shrink-0">
              <img src="https://media.base44.com/images/public/6a51c0830aeacd39ab86c4f0/7a6383daf_generated_image.png" alt="Merlin" className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="text-white text-lg font-bold">Merlin</div>
              <div className="text-[#00f5ff] text-[10px] uppercase tracking-wider">Quantum Cat · AI Assistant</div>
            </div>
          </div>
          <p className="text-[11px] text-[#8fa0bc] leading-relaxed mb-2">
            Merlin is the in-app AI assistant. Ask it anything about the framework, the repository, the physics, or the site. It answers from repository knowledge, runs research queries, and guides you to the right page.
          </p>
          <div className="space-y-1.5 text-[10px]">
            <div className="flex items-center gap-1.5 text-[#8fa0bc]"><MessageCircle size={11} className="text-[#00f5ff]" /> <span><span className="text-white font-bold">Desktop:</span> the glowing Merlin button, top-right of the Topology page.</span></div>
            <div className="flex items-center gap-1.5 text-[#8fa0bc]"><MessageCircle size={11} className="text-[#00f5ff]" /> <span><span className="text-white font-bold">Mobile:</span> the persistent floating button, bottom-right with a pulsing glow.</span></div>
          </div>
        </Card>
        <Card accent="#FF9F00" className="flex flex-col justify-center items-center text-center">
          <Sparkles size={28} className="text-[#FF9F00] mb-3" />
          <div className="text-white text-base font-bold mb-1">Ready for the Advanced Tour?</div>
          <p className="text-[11px] text-[#8fa0bc] mb-4 max-w-xs">
            The next 8 slides cover the site map, the repository reader, telemetry, ECLIPSA, falsification, and the labs — every claim anchored to repository truth.
          </p>
          <button onClick={onLaunch} className="flex items-center gap-2 px-6 py-3 bg-[#FF9F00] text-black font-bold text-sm tracking-wider hover:bg-[#FF9F00]/90 transition-colors clip-corner">
            <Rocket size={16} /> LAUNCH ADVANCED
          </button>
          <div className="text-[#484f58] text-[9px] mt-3">or press Next to continue</div>
        </Card>
      </div>
    </SlideShell>
  );
}

function Slide6() {
  const groups = [
    { label: 'Core', icon: Boxes, color: '#00f5ff', desc: 'Topology, products, portals' },
    { label: 'Research', icon: BookOpen, color: '#4DD0E1', desc: 'Repository, docs, journalism' },
    { label: 'Labs', icon: Flask, color: '#FF9F00', desc: 'Sandbox, training, diagnostics' },
    { label: 'Analytics', icon: Activity, color: '#00ff88', desc: 'Status, telemetry, dashboards' },
    { label: 'Governance', icon: ShieldCheck, color: '#bc8cff', desc: 'Charter, ethics, OS, safety' },
    { label: 'Connect', icon: MessageCircle, color: '#ff0055', desc: 'Inquiry, partners, media' },
  ];
  return (
    <SlideShell index={6} total={13} tag="ADV" title="Site Map Guide" subtitle="6 Groups · 40+ Pages">
      <p className="text-[11px] text-[#8fa0bc] leading-relaxed mb-3">
        The entire site is organized into <span className="text-white font-bold">6 thematic groups</span>. Open the <span className="text-[#00f5ff] font-bold">Site Map</span> tab (or the Navigate dropdown) at any time to jump anywhere. Every group is one click away.
      </p>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {groups.map((g) => {
          const Icon = g.icon;
          return (
            <Card key={g.label} accent={g.color}>
              <div className="flex items-center gap-2 mb-1">
                <Icon size={16} style={{ color: g.color }} />
                <span className="text-white text-sm font-bold">{g.label}</span>
              </div>
              <div className="text-[10px] text-[#8fa0bc]">{g.desc}</div>
            </Card>
          );
        })}
      </div>
      <Card accent="#00f5ff" className="mt-3">
        <div className="text-[10px] text-[#8fa0bc]">
          <span className="text-[#00f5ff] font-bold">Demo apps</span> live across these groups — try <Link to="/az-products" className="text-[#00f5ff] underline">AZ Products</Link> (18 interactive apps: 15 in 12-AZ-IP + 3 v23 browser apps), <Link to="/delphi" className="text-[#00f5ff] underline">DelPhi Oracle</Link>, <Link to="/flashcard-trainer" className="text-[#00f5ff] underline">Flashcard Trainer</Link>, and <Link to="/pentacorder" className="text-[#00f5ff] underline">Pentacorder</Link>.
        </div>
      </Card>
    </SlideShell>
  );
}

function Slide7() {
  return (
    <SlideShell index={7} total={13} tag="ADV" title="Traversing Dense Information" subtitle="The Reader & Repository Browser">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card accent="#4DD0E1">
          <div className="text-[#4DD0E1] text-[10px] uppercase tracking-wider font-bold mb-2">▸ Repository Browser</div>
          <p className="text-[11px] text-[#8fa0bc] leading-relaxed mb-2">
            The <Link to="/manifold-explorer" className="text-[#00f5ff] underline">Repository</Link> page is a live, read-only browser of the <span className="text-white font-bold">wuzbak/Unitary-Manifold-</span> GitHub repo — a hierarchical file tree on the left, the file's content on the right, with a tabbed Articles/Books reader.
          </p>
          <div className="space-y-1.5 text-[10px] text-[#8fa0bc]">
            <div>• <span className="text-white font-bold">File tree</span> — expand folders, click any file to view it.</div>
            <div>• <span className="text-white font-bold">Deep links</span> — element info cards link straight to source files.</div>
            <div>• <span className="text-white font-bold">Articles tab</span> — long-form research notes and posts.</div>
          </div>
        </Card>
        <Card accent="#00f5ff">
          <div className="text-[#00f5ff] text-[10px] uppercase tracking-wider font-bold mb-2">▸ The Reader</div>
          <p className="text-[11px] text-[#8fa0bc] leading-relaxed mb-2">
            For books, articles, and documents, the reader renders Markdown with proper typography, scroll, and navigation. Use <Link to="/manifold-explorer" className="text-[#00f5ff] underline">Manifold Explorer</Link> for binaries, constants, and docs side-by-side with a 3D atlas.
          </p>
          <div className="border border-[#00f5ff]/20 bg-[#0a0a12] p-2">
            <div className="text-[#484f58] text-[8px] uppercase tracking-wider mb-1">▸ Reader View</div>
            <div className="space-y-1">
              <div className="h-1.5 bg-[#00f5ff]/30 w-3/4" />
              <div className="h-1.5 bg-[#30363d] w-full" />
              <div className="h-1.5 bg-[#30363d] w-5/6" />
              <div className="h-1.5 bg-[#30363d] w-full" />
              <div className="h-1.5 bg-[#30363d] w-2/3" />
            </div>
          </div>
        </Card>
      </div>
      <Card accent="#bc8cff" className="mt-3">
        <div className="text-[10px] text-[#8fa0bc]">
          <span className="text-[#bc8cff] font-bold">Tip:</span> the <Link to="/knowledge-hub" className="text-[#00f5ff] underline">Knowledge Hub</Link> combines docs, FAQ, glossary, and API reference into one searchable place — the fastest way to find a specific term.
        </div>
      </Card>
    </SlideShell>
  );
}

function Slide8({ status }) {
  const s = status || {};
  return (
    <SlideShell index={8} total={13} tag="ADV" title="Telemetry — Explainers & Locations" subtitle="Live System Readouts">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card accent="#00f5ff">
          <div className="text-[#00f5ff] text-[10px] uppercase tracking-wider font-bold mb-2">▸ Where to Find Telemetry</div>
          <div className="space-y-2 text-[10px]">
            <div className="flex items-start gap-2"><Activity size={12} className="text-[#00f5ff] mt-0.5" /><span className="text-[#8fa0bc]"><span className="text-white font-bold">Node Telemetry</span> — top-left HUD on the Topology page: version, sprint, pillars, tests.</span></div>
            <div className="flex items-start gap-2"><Compass size={12} className="text-[#4DD0E1] mt-0.5" /><span className="text-[#8fa0bc]"><span className="text-white font-bold">MiniHUD</span> — bottom-left: live azimuth, elevation, view mode.</span></div>
            <div className="flex items-start gap-2"><Activity size={12} className="text-[#00ff88] mt-0.5" /><span className="text-[#8fa0bc]"><Link to="/system-status" className="text-[#00f5ff] underline">System Status</Link> — full verification + telemetry dashboard.</span></div>
          </div>
        </Card>
        <Card accent="#FF9F00">
          <div className="text-[#FF9F00] text-[10px] uppercase tracking-wider font-bold mb-2">▸ What the Numbers Mean</div>
          <div className="grid grid-cols-2 gap-1.5 text-[10px] font-mono">
            <div className="text-[#8fa0bc]">Version: <span className="text-[#00f5ff] font-bold">{s.version || 'v33.1'}</span></div>
            <div className="text-[#8fa0bc]">Sprint: <span className="text-[#00f5ff] font-bold">{s.sprint || 'Sprint BK'}</span></div>
            <div className="text-[#8fa0bc]">Lean4: <span className="text-[#00f5ff] font-bold">{(s.lean4_theorems || 3912).toLocaleString()} thm</span></div>
            <div className="text-[#8fa0bc]">Pillars: <span className="text-[#00f5ff] font-bold">{s.pillars_total || 981} total</span></div>
            <div className="text-[#8fa0bc]">Tests: <span className="text-[#00ff88] font-bold">{(s.tests_passed || 62200).toLocaleString()} ✓</span></div>
            <div className="text-[#8fa0bc]">Failed: <span className="text-[#ff3b30] font-bold">{s.tests_failed ?? 0} ✗</span></div>
          </div>
          <p className="text-[9px] text-[#484f58] mt-2">All telemetry syncs live from the repository STATUS source — 208 hardgate pillars + 773 adjacent tracks = 981 total. No static placeholders when live data is available.</p>
        </Card>
      </div>
    </SlideShell>
  );
}

function Slide9() {
  return (
    <SlideShell index={9} total={13} tag="ADV" title="ECLIPSA — The Sentinel" subtitle="Integrity Watchdog">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card accent="#ff3b30">
          <div className="flex items-center gap-2 mb-2">
            <ShieldCheck size={20} className="text-[#ff3b30]" />
            <div>
              <div className="text-white text-base font-bold">ECLIPSA</div>
              <div className="text-[#ff3b30] text-[9px] uppercase tracking-wider">Sentinel · Integrity Watchdog</div>
            </div>
          </div>
          <p className="text-[11px] text-[#8fa0bc] leading-relaxed mb-2">
            ECLIPSA is the platform's integrity sentinel — a watchdog that monitors guardrails, audit trails, and alerts across the system. It watches for violations of the safety invariants and the 3-tier ethical guardrail system.
          </p>
          <div className="space-y-1 text-[10px] text-[#8fa0bc]">
            <div>• <span className="text-white font-bold">Status</span> — live guardrail state</div>
            <div>• <span className="text-white font-bold">Audit</span> — append-only, SHA-256-attested event trail</div>
            <div>• <span className="text-white font-bold">Alerts</span> — threat-level indicators (GREEN / AMBER / CRIMSON)</div>
          </div>
        </Card>
        <Card accent="#FF9F00">
          <div className="text-[#FF9F00] text-[10px] uppercase tracking-wider font-bold mb-2">▸ Where to Find It</div>
          <div className="space-y-2 text-[10px]">
            <Link to="/eclipsa-integrity" className="flex items-center gap-2 text-[#00f5ff] hover:underline">
              <ExternalLink size={12} /> ECLIPSA Console — status + guardrails + audit + alerts
            </Link>
            <Link to="/safety" className="flex items-center gap-2 text-[#00f5ff] hover:underline">
              <ExternalLink size={12} /> Safety & Emergency — HILS invariants + recovery
            </Link>
            <Link to="/lens-suite" className="flex items-center gap-2 text-[#00f5ff] hover:underline">
              <ExternalLink size={12} /> Ethical Synthesis — 3-tier guardrail system
            </Link>
          </div>
          <p className="text-[9px] text-[#484f58] mt-2">Every decision in the audit log is cryptographically attested — fully traceable.</p>
        </Card>
      </div>
    </SlideShell>
  );
}

function Slide10({ status }) {
  const s = status || {};
  return (
    <SlideShell index={10} total={13} tag="ADV" title="The GitHub Repository" subtitle="Source of Truth">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card accent="#00f5ff">
          <div className="flex items-center gap-2 mb-2">
            <Github size={18} className="text-[#00f5ff]" />
            <div className="text-white text-sm font-bold">wuzbak/Unitary-Manifold-</div>
          </div>
          <p className="text-[11px] text-[#8fa0bc] leading-relaxed mb-2">
            The repository is the <span className="text-white font-bold">single source of truth</span> for every metric, prediction, and claim on this site. The framework is a deterministic physics engine — not a black box. Every number you see traces back to a file you can read.
          </p>
          <div className="grid grid-cols-2 gap-1.5 text-[10px] font-mono">
            <div className="text-[#8fa0bc]">Version: <span className="text-[#00f5ff] font-bold">{s.version || 'v33.1'}</span></div>
            <div className="text-[#8fa0bc]">Lean4: <span className="text-[#00f5ff] font-bold">{(s.lean4_theorems || 3912).toLocaleString()}</span></div>
            <div className="text-[#8fa0bc]">Pillars: <span className="text-[#00f5ff] font-bold">208 hardgate + 773 = 981</span></div>
            <div className="text-[#8fa0bc]">Tests: <span className="text-[#00ff88] font-bold">{(s.tests_passed || 62200).toLocaleString()} · 0 fail</span></div>
          </div>
        </Card>
        <Card accent="#4DD0E1">
          <div className="text-[#4DD0E1] text-[10px] uppercase tracking-wider font-bold mb-2">▸ Seed Constants & Citation</div>
          <div className="flex items-center gap-2 mb-2 text-[10px] font-mono">
            <Sigma size={14} className="text-[#4DD0E1]" />
            <span className="text-[#8fa0bc]">Kernel: <span className="text-white font-bold">(N_W=5, K_CS=74)</span> · c_s = 12/37</span>
          </div>
          <p className="text-[10px] text-[#8fa0bc] leading-relaxed mb-2">
            Seven first-principles constants seed the entire framework: N_W=5, K_CS=74, c_s, n_s=0.9635, r=0.0315, β=0.273/0.331. Every prediction derives from these — no fitted parameters beyond them.
          </p>
          <div className="border-l-2 border-[#bc8cff]/40 pl-2 text-[9px] text-[#8fa0bc] italic">
            Walker-Pearson, T. (2026). <span className="text-white">The Unitary Manifold: A 5D Gauge Geometry of Emergent Irreversibility</span> (v10.4). Zenodo.
          </div>
        </Card>
      </div>
      <Card accent="#00ff88" className="mt-3">
        <div className="text-[#00ff88] text-[10px] uppercase tracking-wider font-bold mb-2">▸ How to Explore It</div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px]">
          <Link to="/manifold-explorer" className="flex items-center gap-1.5 text-[#00f5ff] hover:underline"><ExternalLink size={11} /> Repository browser</Link>
          <Link to="/manifold-explorer" className="flex items-center gap-1.5 text-[#00f5ff] hover:underline"><ExternalLink size={11} /> Live Docs</Link>
          <Link to="/manifold-explorer" className="flex items-center gap-1.5 text-[#00f5ff] hover:underline"><ExternalLink size={11} /> Manifold Explorer</Link>
          <Link to="/lean4-formalization" className="flex items-center gap-1.5 text-[#00f5ff] hover:underline"><ExternalLink size={11} /> Lean4 proofs</Link>
        </div>
        <p className="text-[9px] text-[#484f58] mt-2">Dual-licensed: Defensive Public Commons License v1.0 (2026) + AGPL-3.0-or-later. Waivers available upon request.</p>
      </Card>
    </SlideShell>
  );
}

function Slide11() {
  const experiments = [
    { id: 'EXP-1', name: 'LiteBIRD β', status: 'AWAITING', detail: 'β ∈ [0.22°, 0.38°] admissible; [0.29°, 0.31°] gap' },
    { id: 'EXP-2', name: 'DESI w_a', status: 'TENSION', detail: '2.30σ vs KK w_a=0 (DR2); DR3 tripwire' },
    { id: 'EXP-3', name: 'JUNO ordering', status: 'PASS', detail: 'NH preferred by Z₂ Dirichlet BC' },
    { id: 'EXP-4', name: 'CMB-S4 / ACT r', status: 'TENSION', detail: 'r=0.0315 vs ACT r<0.016, ~2σ' },
    { id: 'EXP-5', name: 'HL-LHC M_G*', status: 'PASS', detail: 'KK graviton ≈1.0 TeV, excl. <4.0 TeV' },
    { id: 'EXP-6', name: 'nEDM @ SNS', status: 'PASS', detail: 'within bounds' },
    { id: 'EXP-7', name: 'XENON-nT', status: 'TENSION', detail: 'DM KK tower σ_SI below limit' },
  ];
  const statusColor = { AWAITING: '#FF9F00', TENSION: '#ff3b30', PASS: '#00ff88' };
  return (
    <SlideShell index={11} total={13} tag="ADV" title="The Falsification Lab" subtitle="7 Live Experiments">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card accent="#ff3b30">
          <div className="flex items-center gap-2 mb-2">
            <Telescope size={18} className="text-[#ff3b30]" />
            <div className="text-white text-sm font-bold">Falsification Observatory</div>
          </div>
          <p className="text-[11px] text-[#8fa0bc] leading-relaxed mb-2">
            Physics lives or dies by falsification. The <Link to="/falsification-lab" className="text-[#00f5ff] underline">Falsification Lab</Link> pairs an <span className="text-white font-bold">Observatory</span> (live experiment dashboards) with an <span className="text-white font-bold">Interrogator</span> (claim verification).
          </p>
          <p className="text-[10px] text-[#8fa0bc] leading-relaxed mb-2">
            <span className="text-[#ff3b30] font-bold">HARDGATE</span> experiments are falsifiable predictions — if violated, the framework falls. <span className="text-[#FF9F00] font-bold">ARCHITECTURE_LIMIT</span> experiments mark known gaps that don't kill the theory but bound its scope.
          </p>
          <div className="text-[10px] text-[#8fa0bc]">
            <span className="text-white font-bold">Pillar 788</span> — GW propagation speed & birefringence. The live dashboard tracks β (CMB birefringence, UM predicts 0.273°–0.331°), c_g/c = 1.0, and dispersion — against the LISA window (0.1 mHz–1 Hz, 2.5M km arms, ~2035).
          </div>
        </Card>
        <Card accent="#FF9F00">
          <div className="text-[#FF9F00] text-[10px] uppercase tracking-wider font-bold mb-2">▸ 7 Live Experiments</div>
          <div className="space-y-1">
            {experiments.map((e) => (
              <div key={e.id} className="flex items-center gap-2 text-[9px]">
                <span className="text-[#484f58] font-mono w-9">{e.id}</span>
                <span className="text-white font-bold w-24">{e.name}</span>
                <span className="px-1.5 py-0.5 text-[7px] font-bold border" style={{ color: statusColor[e.status], borderColor: `${statusColor[e.status]}40`, background: `${statusColor[e.status]}10` }}>{e.status}</span>
                <span className="text-[#8fa0bc] truncate">{e.detail}</span>
              </div>
            ))}
          </div>
          <p className="text-[9px] text-[#484f58] mt-2">Anchored to real missions: LISA, LiteBIRD (~2032), DESI, JUNO, Euclid — whose data will falsify or confirm the framework's predictions.</p>
        </Card>
      </div>
    </SlideShell>
  );
}

function Slide12() {
  return (
    <SlideShell index={12} total={13} tag="ADV" title="Labs & Sandboxes" subtitle="Interactive Experimentation">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card accent="#FF9F00">
          <div className="flex items-center gap-2 mb-2">
            <Flask size={18} className="text-[#FF9F00]" />
            <div className="text-white text-sm font-bold">Labs & Sandbox</div>
          </div>
          <p className="text-[11px] text-[#8fa0bc] leading-relaxed mb-2">
            The <Link to="/labs" className="text-[#00f5ff] underline">Labs</Link> hub bundles the interactive, dev, STEM, and notebook sandboxes — hands-on environments for exploring the framework's math and physics directly in the browser.
          </p>
          <div className="space-y-1.5 text-[10px] text-[#8fa0bc]">
            <Link to="/training-gym" className="flex items-center gap-1.5 hover:text-[#00f5ff]"><ExternalLink size={11} /> Training Gym — agent console, analytics, catalog</Link>
            <Link to="/lens-suite" className="flex items-center gap-1.5 hover:text-[#00f5ff]"><ExternalLink size={11} /> Lens Suite — quantum + ethical diagnostics</Link>
            <Link to="/flashcard-trainer" className="flex items-center gap-1.5 hover:text-[#00f5ff]"><ExternalLink size={11} /> Flashcard Trainer — 60 cards · 7 categories</Link>
            <Link to="/omega-synthesis" className="flex items-center gap-1.5 hover:text-[#00f5ff]"><ExternalLink size={11} /> Omega Synthesis — query 208+ pillars</Link>
          </div>
        </Card>
        <Card accent="#4DD0E1">
          <div className="text-[#4DD0E1] text-[10px] uppercase tracking-wider font-bold mb-2">▸ What You Can Do</div>
          <div className="space-y-2 text-[10px] text-[#8fa0bc]">
            <div className="flex items-start gap-2"><Flask size={11} className="text-[#4DD0E1] mt-0.5" /> Run deterministic scientific computations with SHA-256-signed state snapshots.</div>
            <div className="flex items-start gap-2"><Cpu size={11} className="text-[#4DD0E1] mt-0.5" /> Train and certify agents against the framework's 208 hardgate pillars.</div>
            <div className="flex items-start gap-2"><BookOpen size={11} className="text-[#4DD0E1] mt-0.5" /> Query any of 208+ physics pillars for observables, derivation paths, and falsifiability status.</div>
          </div>
          <p className="text-[9px] text-[#484f58] mt-2">Every lab result is reproducible — deterministic seeds, no hidden randomness.</p>
        </Card>
      </div>
    </SlideShell>
  );
}

function Slide13({ onClose }) {
  return (
    <SlideShell index={13} total={13} tag="ADV" title="Summary — Where to Go Next" subtitle="You're Ready">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
        <Card accent="#00f5ff" className="text-center">
          <Orbit size={28} className="text-[#00f5ff] mx-auto mb-2" />
          <div className="text-white text-sm font-bold mb-1">Topology</div>
          <p className="text-[10px] text-[#8fa0bc] mb-3">Back to the 3D manifold — orbit, zoom, and explore.</p>
          <button onClick={onClose} className="w-full px-3 py-2 bg-[#00f5ff] text-black font-bold text-xs tracking-wider hover:bg-[#00f5ff]/90 transition-colors clip-corner">LAUNCH TOPOLOGY</button>
        </Card>
        <Card accent="#4DD0E1" className="text-center">
          <Github size={28} className="text-[#4DD0E1] mx-auto mb-2" />
          <div className="text-white text-sm font-bold mb-1">GitHub Repository</div>
          <p className="text-[10px] text-[#8fa0bc] mb-3">Read the source — the single source of truth.</p>
          <Link to="/manifold-explorer" onClick={onClose} className="block w-full px-3 py-2 bg-[#4DD0E1] text-black font-bold text-xs tracking-wider hover:bg-[#4DD0E1]/90 transition-colors clip-corner text-center">OPEN REPOSITORY</Link>
        </Card>
        <Card accent="#FF9F00" className="text-center">
          <ArrowRight size={28} className="text-[#FF9F00] mx-auto mb-2" />
          <div className="text-white text-sm font-bold mb-1">Back</div>
          <p className="text-[10px] text-[#8fa0bc] mb-3">Return to the deck or the Topology page.</p>
          <button onClick={onClose} className="w-full px-3 py-2 border border-[#FF9F00]/40 text-[#FF9F00] font-bold text-xs tracking-wider hover:bg-[#FF9F00]/10 transition-colors clip-corner">BACK TO TOPOLOGY</button>
        </Card>
      </div>
      <Card accent="#bc8cff">
        <div className="text-[#bc8cff] text-[10px] uppercase tracking-wider font-bold mb-1.5">▸ The Core Idea</div>
        <p className="text-[11px] text-[#8fa0bc] leading-relaxed">
          Everything here is anchored to <span className="text-white font-bold">repository truth</span> — the math, the physics, and the code. Seven seed constants derive 805 pillars, 1,246 Lean4 theorems, and 57,927 passing tests. No confabulations, no placeholders. When a number appears, it traces to a file. When a prediction is made, it is falsifiable. That absolute honesty is the point: <span className="text-[#00f5ff] font-bold">every claim is verifiable, every visitor can check it themselves</span>.
        </p>
      </Card>
    </SlideShell>
  );
}

/**
 * MANUAL_SLIDES — 13 slides. Slides 1–5 are MAIN; slide 5 holds the Advanced launch.
 * Slides 6–13 are ADVANCED. Each render fn receives { status, live, onLaunch, onClose }.
 * All claims verified against: src/lib/umStatus.js, src/lib/umConstants.ts,
 * src/lib/topology/gaiaCatalog.js, src/lib/topology/missions.js,
 * src/lib/topology/spectralClasses.js, src/lib/azProducts.js.
 */
export const MANUAL_SLIDES = [
  { tag: 'MAIN', render: (p) => <Slide1 {...p} /> },
  { tag: 'MAIN', render: (p) => <Slide2 {...p} /> },
  { tag: 'MAIN', render: (p) => <Slide3 {...p} /> },
  { tag: 'MAIN', render: (p) => <Slide4 {...p} /> },
  { tag: 'MAIN', render: (p) => <Slide5 {...p} /> },
  { tag: 'ADV', render: (p) => <Slide6 {...p} /> },
  { tag: 'ADV', render: (p) => <Slide7 {...p} /> },
  { tag: 'ADV', render: (p) => <Slide8 {...p} /> },
  { tag: 'ADV', render: (p) => <Slide9 {...p} /> },
  { tag: 'ADV', render: (p) => <Slide10 {...p} /> },
  { tag: 'ADV', render: (p) => <Slide11 {...p} /> },
  { tag: 'ADV', render: (p) => <Slide12 {...p} /> },
  { tag: 'ADV', render: (p) => <Slide13 {...p} /> },
];