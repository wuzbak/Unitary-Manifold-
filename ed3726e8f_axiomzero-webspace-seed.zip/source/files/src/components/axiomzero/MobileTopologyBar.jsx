import { BookOpen, Globe, MapPin, Sparkles } from 'lucide-react';

/**
 * MobileTopologyBar — mobile-only control bar for the Topology page.
 * Surfaces the User Manual (13-slide tutorial), Merlin chat, Earth view, and
 * Destinations entry points that are otherwise desktop-only (TopologyTabBar)
 * or a global FAB. Dispatches the same global window events the desktop tabs
 * use. Single centered row, icon-led, sized to fit narrow viewports.
 * lg:hidden — desktop TopologyTabBar is untouched.
 */
const ITEMS = [
  { event: 'user-manual-toggle', icon: BookOpen, label: 'Manual' },
  { event: 'merlin-toggle', icon: Sparkles, label: 'Merlin' },
  { event: 'earth-view-toggle', icon: Globe, label: 'Earth' },
  { event: 'destinations-toggle', icon: MapPin, label: 'Destinations' },
];

export default function MobileTopologyBar() {
  return (
    <div className="lg:hidden absolute top-12 left-0 right-0 z-30 flex justify-center pointer-events-none">
      <div className="flex items-center gap-0 px-1 py-1 clip-corner glass-panel pointer-events-auto w-full max-w-[calc(100vw-1.5rem)]">
        {ITEMS.map((item, i) => {
          const Icon = item.icon;
          return (
            <button
              key={item.event}
              onClick={() => window.dispatchEvent(new Event(item.event))}
              className={`flex items-center justify-center gap-1 px-1 py-2 text-[10px] font-bold tracking-wider text-[#00f5ff] active:bg-[#00f5ff]/15 transition-colors touch-manipulation min-h-[40px] flex-1 ${
                i > 0 ? 'border-l border-[#00f5ff]/15' : ''
              }`}
              aria-label={`Open ${item.label}`}
            >
              <Icon size={13} className="shrink-0" />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}