import { Compass, Pause, Play, Maximize2, RotateCcw } from 'lucide-react';

/**
 * MiniHUD — compact persistent orientation + quick-action HUD.
 *
 * Always-visible minimal overlay showing:
 * - 3D orientation indicator (compass/gyro showing camera heading)
 * - Current view mode
 * - Quick actions (pause/play, reset, expand to full deck)
 *
 * Designed for minimal background interference — compact and anchored
 * bottom-left on desktop, bottom-center on mobile.
 */
export default function MiniHUD({
  orientation,
  viewMode,
  paused,
  setPaused,
  onExpand,
  onReset,
  quality,
}) {
  const azimuth = orientation?.azimuth ?? 0;
  const elevation = orientation?.elevation ?? 0;
  const distance = orientation?.distance ?? 0;

  const modeLabel = viewMode === 'overview' ? 'MANIFOLD' : viewMode === 'solar-system' ? 'SOLAR SYSTEM' : viewMode === 'planet-inspect' ? 'INSPECT' : 'MANIFOLD';

  return (
    <div className="absolute bottom-5 left-5 z-20 pointer-events-auto hidden lg:block">
      <div className="flex items-center gap-3 px-3 py-2 clip-corner bg-[#0a0a12]/90 backdrop-blur-md border border-[#00f5ff]/20">
        {/* Orientation indicator */}
        <div className="relative w-12 h-12 rounded-full border border-[#00f5ff]/30 flex items-center justify-center shrink-0">
          {/* Compass rose */}
          <div className="absolute inset-1 rounded-full border border-[#00f5ff]/10" />
          {/* Azimuth needle */}
          <div
            className="absolute w-px h-5 origin-bottom"
            style={{
              transform: `rotate(${azimuth}deg)`,
              transformOrigin: 'bottom center',
              bottom: '50%',
              background: 'linear-gradient(to top, transparent, #00f5ff)',
            }}
          />
          {/* Center dot */}
          <div className="w-1.5 h-1.5 rounded-full bg-[#00f5ff] glow-pulse" />
          {/* N marker */}
          <div className="absolute -top-0.5 text-[7px] text-[#00f5ff]/50 font-bold">N</div>
        </div>

        {/* Readout */}
        <div className="text-[9px] font-mono leading-tight">
          <div className="flex items-center gap-1.5 mb-0.5">
            <Compass size={9} className="text-[#00f5ff]" />
            <span className="text-[#00f5ff] font-bold">{modeLabel}</span>
            <span className="text-[#484f58] text-[8px]">·</span>
            <span className="text-[#8b949e]">{quality?.toUpperCase()}</span>
          </div>
          <div className="text-[#8fa0bc] text-[8px] space-y-0.5">
            <div>AZ <span className="text-[#00f5ff]">{azimuth.toFixed(0).padStart(3, '0')}°</span></div>
            <div>EL <span className="text-[#00f5ff]">{elevation.toFixed(0).padStart(3, '0')}°</span></div>
          </div>
        </div>

        {/* Quick actions */}
        <div className="flex items-center gap-1 pl-2 border-l border-[#00f5ff]/10">
          <button
            onClick={() => setPaused(!paused)}
            className="w-7 h-7 flex items-center justify-center rounded border border-[#00f5ff]/20 text-[#00f5ff] hover:bg-[#00f5ff]/10 transition-colors"
            title={paused ? 'Resume' : 'Pause'}
          >
            {paused ? <Play size={12} /> : <Pause size={12} />}
          </button>
          <button
            onClick={onReset}
            className="w-7 h-7 flex items-center justify-center rounded border border-[#00f5ff]/20 text-[#4DD0E1] hover:bg-[#4DD0E1]/10 transition-colors"
            title="Reset view"
          >
            <RotateCcw size={12} />
          </button>
          <button
            onClick={onExpand}
            className="w-7 h-7 flex items-center justify-center rounded border border-[#FF9F00]/30 text-[#FF9F00] hover:bg-[#FF9F00]/10 transition-colors"
            title="Expand control deck"
          >
            <Maximize2 size={12} />
          </button>
        </div>
      </div>
    </div>
  );
}