import * as THREE from 'three';

/**
 * NodeEnergyField — residual colored energy emitted by each torus node.
 * Particles spawn at a node's current position, drift outward into the
 * starfield, and fade out (additive color → black) over their lifetime,
 * then recycle. Creates a comet-like color trail dispersing into space.
 */
export function createNodeEnergyField({ scene, glowTex, nodeState }) {
  const PER_NODE = 80;
  const count = PER_NODE * nodeState.length;
  const positions = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);
  const data = [];

  for (let i = 0; i < count; i++) {
    const nodeIndex = i % nodeState.length;
    data.push({
      nodeIndex,
      vel: new THREE.Vector3(),
      life: Math.random() * 3,
      maxLife: 2.0 + Math.random() * 2.5,
      color: nodeState[nodeIndex].color.clone(),
    });
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  const mat = new THREE.PointsMaterial({
    size: 0.3, map: glowTex, vertexColors: true, transparent: true, opacity: 0.85,
    blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true,
  });
  const points = new THREE.Points(geo, mat);
  scene.add(points);

  function update(dt) {
    for (let i = 0; i < count; i++) {
      const rd = data[i];
      rd.life -= dt;
      if (rd.life <= 0) {
        const nd = nodeState[rd.nodeIndex];
        const pos = nd.mesh.position;
        positions[i * 3] = pos.x; positions[i * 3 + 1] = pos.y; positions[i * 3 + 2] = pos.z;
        const outDir = new THREE.Vector3(pos.x, 0, pos.z).normalize();
        rd.vel.set(
          outDir.x * (0.3 + Math.random() * 0.5) + (Math.random() - 0.5) * 0.4,
          (Math.random() - 0.5) * 0.5,
          outDir.z * (0.3 + Math.random() * 0.5) + (Math.random() - 0.5) * 0.4
        );
        rd.life = rd.maxLife;
      } else {
        positions[i * 3] += rd.vel.x * dt;
        positions[i * 3 + 1] += rd.vel.y * dt;
        positions[i * 3 + 2] += rd.vel.z * dt;
      }
      const fade = Math.max(0, rd.life / rd.maxLife);
      colors[i * 3] = rd.color.r * fade;
      colors[i * 3 + 1] = rd.color.g * fade;
      colors[i * 3 + 2] = rd.color.b * fade;
    }
    geo.attributes.position.needsUpdate = true;
    geo.attributes.color.needsUpdate = true;
  }

  function dispose() {
    geo.dispose(); mat.dispose();
    scene.remove(points);
  }

  return { points, update, dispose };
}