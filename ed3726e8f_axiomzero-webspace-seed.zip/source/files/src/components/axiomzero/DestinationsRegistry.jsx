import { useState, useEffect } from 'react';
import { Telescope, Sparkles, ChevronRight, X, MapPin, Users, Layers } from 'lucide-react';
import { MISSIONS } from '@/lib/topology/missions';
import { COSMIC_DESTINATIONS } from '@/lib/topology/cosmicDestinations';
import { FATHERS_DESTINATIONS, PILLAR_DESTINATIONS } from '@/lib/topology/foundingDestinations';

/**
 * DestinationsRegistry — quick-jump list of every interactive destination in
 * the manifold: mission/observatory satellites and cosmic phenomena. Clicking
 * a destination opens its metadata in the CosmicInfoCard via onSelect.
 *
 * Desktop: a collapsible side panel (left). Mobile: a FAB + modal list.
 */
export default function DestinationsRegistry({ onSelect }) {
  const [open, setOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(true);
  const [pillarsExpanded, setPillarsExpanded] = useState(false);

  // Mobile: open the modal from the Destinations button in MobileTopologyBar
  useEffect(() => {
    const handler = () => setOpen(true);
    window.addEventListener('destinations-toggle', handler);
    return () => window.removeEventListener('destinations-toggle', handler);
  }, []);

  const handleSelect = (data) => {
    onSelect(data);
    setOpen(false);
  };

  const missionEntries = MISSIONS.map((m) => ({
    id: m.id,
    name: m.name,
    sub: m.type,
    color: `#${m.color.toString(16).padStart(6, '0')}`,
    payload: { ...m, _missionStatus: m.status, _missionAgency: m.agency, _missionLaunch: m.launchDate },
  }));

  const cosmicEntries = COSMIC_DESTINATIONS.map((c) => ({
    id: c.id,
    name: c.name,
    sub: c.type,
    color: '#FF9F00',
    payload: { ...c, _cosmicMeta: c.cosmicMeta },
  }));

  const fatherEntries = FATHERS_DESTINATIONS.map((f) => ({
    id: f.id,
    name: f.name,
    sub: f.type,
    color: f._accent,
    payload: { ...f, _cosmicMeta: f.cosmicMeta },
  }));

  const pillarEntries = PILLAR_DESTINATIONS.map((p) => ({
    id: p.id,
    name: p.name,
    sub: p.type,
    color: p._accent,
    payload: { ...p, _cosmicMeta: p.cosmicMeta },
  }));

  const List = (
    <div className="space-y-3">
      {/* Missions & observatories */}
      <div>
        <div className="flex items-center gap-1.5 mb-1.5 text-[#00f5ff] text-[9px] uppercase tracking-wider font-bold">
          <Telescope size={11} /> Missions & Observatories
          <span className="text-[#484f58] ml-auto">{missionEntries.length}</span>
        </div>
        <div className="space-y-1">
          {missionEntries.map((m) => (
            <button
              key={m.id}
              onClick={() => handleSelect(m.payload)}
              className="w-full flex items-center gap-2 px-2 py-1.5 border border-[#00f5ff]/10 hover:border-[#00f5ff]/30 hover:bg-[#00f5ff]/5 transition-colors clip-corner group text-left"
            >
              <span className="w-2 h-2 rounded-full shrink-0" style={{ background: m.color, boxShadow: `0 0 4px ${m.color}` }} />
              <div className="flex-1 min-w-0">
                <div className="text-[#e6edf3] text-[10px] font-bold group-hover:text-[#00f5ff] transition-colors truncate">{m.name}</div>
                <div className="text-[#484f58] text-[8px] truncate">{m.sub}</div>
              </div>
              <ChevronRight size={11} className="text-[#00f5ff]/30 group-hover:text-[#00f5ff] shrink-0" />
            </button>
          ))}
        </div>
      </div>

      {/* Cosmic phenomena */}
      <div>
        <div className="flex items-center gap-1.5 mb-1.5 text-[#FF9F00] text-[9px] uppercase tracking-wider font-bold">
          <Sparkles size={11} /> Cosmic Phenomena
          <span className="text-[#484f58] ml-auto">{cosmicEntries.length}</span>
        </div>
        <div className="space-y-1">
          {cosmicEntries.map((c) => (
            <button
              key={c.id}
              onClick={() => handleSelect(c.payload)}
              className="w-full flex items-center gap-2 px-2 py-1.5 border border-[#FF9F00]/10 hover:border-[#FF9F00]/30 hover:bg-[#FF9F00]/5 transition-colors clip-corner group text-left"
            >
              <span className="w-2 h-2 rounded-full shrink-0" style={{ background: c.color, boxShadow: `0 0 4px ${c.color}` }} />
              <div className="flex-1 min-w-0">
                <div className="text-[#e6edf3] text-[10px] font-bold group-hover:text-[#FF9F00] transition-colors truncate">{c.name}</div>
                <div className="text-[#484f58] text-[8px] truncate">{c.sub}</div>
              </div>
              <ChevronRight size={11} className="text-[#FF9F00]/30 group-hover:text-[#FF9F00] shrink-0" />
            </button>
          ))}
        </div>
      </div>

      {/* Founding Fathers — Kaluza & Klein */}
      <div>
        <div className="flex items-center gap-1.5 mb-1.5 text-[#ff6b9d] text-[9px] uppercase tracking-wider font-bold">
          <Users size={11} /> Founding Fathers
          <span className="text-[#484f58] ml-auto">{fatherEntries.length}</span>
        </div>
        <div className="space-y-1">
          {fatherEntries.map((f) => (
            <button
              key={f.id}
              onClick={() => handleSelect(f.payload)}
              className="w-full flex items-center gap-2 px-2 py-1.5 border border-[#ff6b9d]/10 hover:border-[#ff6b9d]/30 hover:bg-[#ff6b9d]/5 transition-colors clip-corner group text-left"
            >
              <span className="w-2 h-2 rounded-full shrink-0" style={{ background: f.color, boxShadow: `0 0 4px ${f.color}` }} />
              <div className="flex-1 min-w-0">
                <div className="text-[#e6edf3] text-[10px] font-bold group-hover:text-[#ff6b9d] transition-colors truncate">{f.name}</div>
                <div className="text-[#484f58] text-[8px] truncate">{f.sub}</div>
              </div>
              <ChevronRight size={11} className="text-[#ff6b9d]/30 group-hover:text-[#ff6b9d] shrink-0" />
            </button>
          ))}
        </div>
      </div>

      {/* Pillars — expandable group of key framework pillars */}
      <div>
        <button
          onClick={() => setPillarsExpanded((e) => !e)}
          className="w-full flex items-center gap-1.5 mb-1.5 text-[#FF9F00] text-[9px] uppercase tracking-wider font-bold hover:opacity-80 transition-opacity"
        >
          <Layers size={11} /> Pillars
          <span className="text-[#484f58] ml-auto">{pillarEntries.length}</span>
          <ChevronRight size={12} className={`text-[#484f58] transition-transform ${pillarsExpanded ? 'rotate-90' : ''}`} />
        </button>
        {pillarsExpanded && (
          <div className="space-y-1">
            {pillarEntries.map((p) => (
              <button
                key={p.id}
                onClick={() => handleSelect(p.payload)}
                className="w-full flex items-center gap-2 px-2 py-1.5 border border-[#FF9F00]/10 hover:border-[#FF9F00]/30 hover:bg-[#FF9F00]/5 transition-colors clip-corner group text-left"
              >
                <span className="w-2 h-2 rounded-full shrink-0" style={{ background: p.color, boxShadow: `0 0 4px ${p.color}` }} />
                <div className="flex-1 min-w-0">
                  <div className="text-[#e6edf3] text-[10px] font-bold group-hover:text-[#FF9F00] transition-colors truncate">{p.name}</div>
                  <div className="text-[#484f58] text-[8px] truncate">{p.sub}</div>
                </div>
                <ChevronRight size={11} className="text-[#FF9F00]/30 group-hover:text-[#FF9F00] shrink-0" />
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* ── Desktop: collapsible left side panel ── */}
      <div className="hidden lg:block absolute top-3 left-[286px] z-30 pointer-events-auto w-[200px]">
        <div className="glass-panel clip-corner">
          <button
            onClick={() => setCollapsed((c) => !c)}
            className="w-full flex items-center gap-2 px-3 py-2 border-b border-[#00f5ff]/15 bg-[#00f5ff]/5"
          >
            <MapPin size={12} className="text-[#00f5ff]" />
            <span className="text-[#00f5ff] text-[10px] font-bold uppercase tracking-wider">Destinations</span>
            <span className="text-[#484f58] text-[8px] ml-auto">{missionEntries.length + cosmicEntries.length + fatherEntries.length + pillarEntries.length}</span>
            <ChevronRight size={12} className={`text-[#484f58] transition-transform ${collapsed ? '' : 'rotate-90'}`} />
          </button>
          {!collapsed && <div className="p-2 max-h-[60vh] overflow-y-auto">{List}</div>}
        </div>
      </div>

      {/* ── Mobile: modal (opened from MobileTopologyBar Destinations button) ── */}
      <div className="lg:hidden">
        {open && (
          <div className="fixed inset-0 z-[150] bg-[#050508]/95 backdrop-blur-xl fade-in overflow-y-auto">
            <div className="sticky top-0 glass-strong border-b border-[#00f5ff]/25 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin size={15} className="text-[#00f5ff]" />
                <span className="text-[#00f5ff] text-sm font-bold tracking-wider">Destinations</span>
              </div>
              <button onClick={() => setOpen(false)} className="text-[#8b949e] hover:text-[#FF9F00] transition-colors">
                <X size={18} />
              </button>
            </div>
            <div className="p-4 max-w-md mx-auto">{List}</div>
          </div>
        )}
      </div>
    </>
  );
}