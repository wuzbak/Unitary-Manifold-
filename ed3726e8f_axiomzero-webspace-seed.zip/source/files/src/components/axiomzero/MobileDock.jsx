import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, ChevronUp, ChevronDown, Compass, Pause, Play, RotateCcw, Orbit, Maximize2, Box } from 'lucide-react';
import { DOMAIN_CONFIG } from '@/components/axiomzero/ToroidalTopology';

/**
 * MobileDock — unified bottom dock for the mobile Topology page.
 * Sits above the global MobileBottomTabBar (calc'd with safe-area). Collapsible
 * telemetry HUD + traversal controls, plus a dimension selector (3/5/7/11/13D)
 * and a domain-registry quick-jump strip — the mobile analog of the desktop HUD
 * panels that are hidden at <1024px. lg:hidden — desktop HUD/controls untouched.
 */

// Tab bar content height (52px) + safe-area + gap
const DOCK_BOTTOM = 'calc(60px + env(safe-area-inset-bottom))';
const PANEL_BOTTOM = 'calc(108px + env(safe-area-inset-bottom))';

function Metric({ label, value }) {
  return (
    <div className="flex justify-between border-b border-[#00f5ff]/10 pb-0.5">
      <span className="text-[#8b949e] text-[9px] uppercase tracking-wider">{label}</span>
      <span className="text-[#00f5ff] font-bold text-[10px]">{value}</span>
    </div>
  );
}

function CtrlButton({ onClick, label, children }) {
  return (
    <button
      onClick={onClick}
      className="flex-1 h-9 min-w-0 flex items-center justify-center text-[#00f5ff] active:bg-[#00f5ff]/15 transition-colors touch-manipulation"
      aria-label={label}
      title={label}
    >
      {children}
    </button>
  );
}

export default function MobileDock({ liveStatus, statusLive, orientation, viewMode, setViewMode, paused, setPaused, hoveredNode, onReset, onExpand, dimensions, setDimensions }) {
  const [telemetryOpen, setTelemetryOpen] = useState(false);
  const az = orientation?.azimuth ?? 0;
  const el = orientation?.elevation ?? 0;
  const modeLabel = viewMode === 'overview' ? 'MANIFOLD' : viewMode === 'solar-system' ? 'SOLAR' : 'INSPECT';
  const dims = [3, 5, 7, 11, 13];

  return (
    <>
      {/* Expanded telemetry panel — drops above the dock */}
      {telemetryOpen && (
        <div className="lg:hidden absolute left-3 right-3 z-20 pointer-events-auto" style={{ bottom: PANEL_BOTTOM }}>
          <div className="clip-corner glass-strong p-3 max-h-[55vh] overflow-y-auto fade-in">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-[#00f5ff] text-[10px] font-bold uppercase tracking-wider">
                <Activity size={12} /> Telemetry
              </div>
              <button onClick={() => setTelemetryOpen(false)} className="text-[#8b949e] active:text-[#FF9F00] p-1" aria-label="Collapse telemetry">
                <ChevronDown size={16} />
              </button>
            </div>

            <div className="flex items-center gap-1.5 mb-2">
              <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${statusLive ? 'bg-[#00ff88]/10 text-[#00ff88] border border-[#00ff88]/30' : 'bg-[#FF9F00]/10 text-[#FF9F00] border border-[#FF9F00]/30'}`}>
                {statusLive ? '● LIVE' : '● OFFLINE'}
              </span>
              <span className="text-[#484f58] text-[8px]">{statusLive ? 'repo-synced' : 'static fallback'}</span>
            </div>

            <div className="grid grid-cols-2 gap-x-2 gap-y-1 mb-2">
              <Metric label="Version" value={liveStatus.version} />
              <Metric label="Sprint" value={liveStatus.sprint} />
              <Metric label="Lean4" value={`${(liveStatus.lean4_theorems || 0).toLocaleString()}`} />
              <Metric label="Pillars" value={`${liveStatus.pillars_total || 0}`} />
              <Metric label="Tests" value={`${(liveStatus.tests_passed || 0).toLocaleString()}✓`} />
              <Metric label="Dims" value={`${dimensions}D`} />
              <Metric label="Defect" value={'<1e-7'} />
              <Metric label="Kernel" value="(5,7,74)" />
            </div>

            {/* Dimension selector — mobile analog of desktop bottom-center selector */}
            <div className="mb-2">
              <div className="text-[#00f5ff]/60 text-[8px] uppercase tracking-wider mb-1 flex items-center gap-1"><Box size={9} /> Dimension</div>
              <div className="flex items-center gap-1">
                {dims.map((d) => (
                  <button
                    key={d}
                    onClick={() => setDimensions?.(d)}
                    className={`px-2 py-1 clip-corner text-[10px] font-bold transition-colors touch-manipulation min-h-[32px] ${
                      dimensions === d ? 'bg-[#00f5ff] text-black' : 'glass-panel text-[#00f5ff]/50 active:text-[#00f5ff]'
                    }`}
                  >
                    {d}D
                  </button>
                ))}
              </div>
            </div>

            {/* Domain registry quick-jump — mobile analog of desktop bottom-left registry */}
            <div className="mb-2">
              <div className="text-[#00f5ff]/60 text-[8px] uppercase tracking-wider mb-1">▸ Domain Registry</div>
              <div className="flex gap-1.5 overflow-x-auto pb-1" style={{ WebkitOverflowScrolling: 'touch' }}>
                {DOMAIN_CONFIG.map((d) => (
                  <Link
                    key={d.id}
                    to={d.hubPath}
                    className="flex items-center gap-1.5 px-2 py-1.5 glass-panel clip-corner whitespace-nowrap shrink-0 active:bg-[#00f5ff]/10"
                  >
                    <span className="w-2 h-2 rounded-full shrink-0 glow-pulse" style={{ background: d.colorHex, boxShadow: `0 0 6px ${d.colorHex}` }} />
                    <span className="text-[#e6edf3] text-[10px] font-bold">{d.name}</span>
                  </Link>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2 mb-1 text-[10px]">
              <Compass size={11} className="text-[#00f5ff]" />
              <span className="text-[#00f5ff] font-bold">{modeLabel}</span>
              <span className="text-[#8fa0bc]">AZ <span className="text-[#00f5ff]">{az.toFixed(0)}°</span></span>
              <span className="text-[#8fa0bc]">EL <span className="text-[#00f5ff]">{el.toFixed(0)}°</span></span>
            </div>

            {hoveredNode && (
              <div className="p-2 border border-[#00f5ff]/15 clip-corner">
                <div className="text-[#00f5ff]/60 text-[8px] uppercase tracking-wider mb-0.5">▸ {hoveredNode.hubPath ? 'Active Node' : hoveredNode._isStarfield ? 'Spectral Trace' : 'Element Trace'}</div>
                <div className="text-white font-bold text-[11px]">{hoveredNode.name}</div>
                <div className="text-[#00f5ff]/70 text-[9px]">{hoveredNode.tier || hoveredNode.type}</div>
                {hoveredNode._isStarfield && (
                  <div className="text-[#8fa0bc] text-[9px] mt-1 space-y-0.5">
                    <div>Temp: <span className="text-[#00f5ff]">{hoveredNode._temperature}</span></div>
                    <div>Mass: <span className="text-[#00f5ff]">{hoveredNode._mass}</span></div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Unified bottom dock — sits above the global MobileBottomTabBar; right side reserved for the Merlin FAB */}
      <div className="lg:hidden absolute left-3 right-16 z-20 pointer-events-auto" style={{ bottom: DOCK_BOTTOM }}>
        <div className="flex items-center px-1.5 py-1.5 clip-corner glass-panel">
          {/* Telemetry toggle */}
          <button
            onClick={() => setTelemetryOpen((o) => !o)}
            className="flex items-center gap-1.5 px-2 h-9 text-[10px] font-bold text-[#00f5ff] active:bg-[#00f5ff]/15 transition-colors touch-manipulation whitespace-nowrap"
            aria-label="Toggle telemetry"
          >
            <span className={`w-2 h-2 rounded-full ${statusLive ? 'bg-[#00ff88]' : 'bg-[#FF9F00]'} glow-pulse`} />
            <span className="tracking-wider">{modeLabel}</span>
            {telemetryOpen ? <ChevronDown size={12} /> : <ChevronUp size={12} />}
          </button>
          <div className="w-px h-7 bg-[#00f5ff]/15 mx-0.5" />
          <div className="flex items-center flex-1 min-w-0">
            <CtrlButton onClick={() => setPaused(!paused)} label={paused ? 'Resume' : 'Pause'}>
              {paused ? <Play size={16} /> : <Pause size={16} />}
            </CtrlButton>
            <CtrlButton onClick={() => setViewMode(viewMode === 'overview' ? 'solar-system' : 'overview')} label="Toggle solar system">
              <Orbit size={16} />
            </CtrlButton>
            <CtrlButton onClick={onReset} label="Reset view">
              <RotateCcw size={16} />
            </CtrlButton>
            <CtrlButton onClick={onExpand} label="More controls">
              <Maximize2 size={16} />
            </CtrlButton>
          </div>
        </div>
      </div>
    </>
  );
}