import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { createSolarSystem } from './SolarSystem';
import { createNodeEnergyField } from './NodeEnergyField';
import { createCosmicField } from './CosmicField';
import { createSpiralGalaxy } from './SpiralGalaxy';
import { createPulsar } from './Pulsar';
import { createSupernovaRemnant } from './SupernovaRemnant';
import { createDarkEnergyField, createDarkMatterWeb, createGravitationalWaves, createPillarStars } from './CosmicPhenomena';
import { createFoundingFathers } from './FoundingFathers';
import { createNamedObjects } from './NamedObjects';
import { createVolumetricNebulae } from './VolumetricNebula';
import { createCatalogStarfield } from './CatalogStarfield';
import { createMissionSatellites } from './MissionSatellites';
import { createCosmicDestinations } from './CosmicDestinations';
import { createPillarNodes } from './PillarNodes';
import { createExpandedSolarSystem } from './ExpandedSolarSystem';
import { cinematicShader } from '@/lib/topology/shaders/postProcessing';
import { starClassIndex, spectralClassUserData, SPECTRAL_CLASSES } from '@/lib/topology/spectralClasses';

export const DOMAIN_CONFIG = [
  { id: 1, name: 'corp.axiomzero.spc', color: 0xff0055, colorHex: '#ff0055', size: 0.4, tier: 'Tier 1: Legal', hubPath: '/corporate', uSpeed: 0.12, vSpeed: 0.08 },
  { id: 2, name: 'lab.unitary.phys', color: 0x00f5ff, colorHex: '#00f5ff', size: 0.5, tier: 'Tier 1: Physics Core', hubPath: '/repository', uSpeed: 0.16, vSpeed: 0.11 },
  { id: 3, name: 'pentad.network', color: 0xffaa00, colorHex: '#ffaa00', size: 0.55, tier: 'Tier 2: Governance', hubPath: '/cognitive-layer', uSpeed: 0.08, vSpeed: 0.06 },
  { id: 4, name: 'eco.az.org', color: 0x00ff88, colorHex: '#00ff88', size: 0.4, tier: 'Tier 3: Ecosystems', hubPath: '/projects', uSpeed: 0.14, vSpeed: 0.09 },
  { id: 5, name: 'media.axiomzero.tv', color: 0x9900ff, colorHex: '#9900ff', size: 0.35, tier: 'Tier 3: Outreach', hubPath: '/media-archive', uSpeed: 0.10, vSpeed: 0.13 }
];

const R = 8;
const r = 2.8;
const TRAIL_LENGTH = 80;
const CONN_SEGMENTS = 50;

const DIM_COLORS = [0x4dd0e1, 0x3fb950, 0xff9f00, 0xbc8cff, 0xff0055, 0x00ff88, 0xffaa00, 0x9900ff, 0xff4444, 0x00f5ff];
const PLASMA_COLORS = [0x00f5ff, 0x4dd0e1, 0xbc8cff, 0xff00ff, 0x00ffaa];

function torusPoint(u, v) {
  return new THREE.Vector3(
    (R + r * Math.cos(v)) * Math.cos(u),
    r * Math.sin(v),
    (R + r * Math.cos(v)) * Math.sin(u)
  );
}

function lerpAngle(a, b, t) {
  let diff = b - a;
  while (diff > Math.PI) diff -= Math.PI * 2;
  while (diff < -Math.PI) diff += Math.PI * 2;
  return a + diff * t;
}

const CONNECTIONS = [[2, 1], [2, 3], [3, 4], [3, 5], [1, 5]];

// Soft radial glow texture (canvas-generated) — shared by stars, nebula, node coronas
function mkStarColor() {
  const r = Math.random();
  const c = new THREE.Color();
  if (r < 0.01) c.setHex(0x9bb0ff);       // O-type (blue)
  else if (r < 0.04) c.setHex(0xaabfff);   // B-type (blue-white)
  else if (r < 0.10) c.setHex(0xcad7ff);   // A-type (white)
  else if (r < 0.20) c.setHex(0xf8f7ff);   // F-type (yellow-white)
  else if (r < 0.35) c.setHex(0xfff4ea);   // G-type (yellow)
  else if (r < 0.55) c.setHex(0xffd2a1);   // K-type (orange)
  else c.setHex(0xffaa66);                 // M-type (red-orange)
  return c;
}

function makeGlowTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 128; canvas.height = 128;
  const ctx = canvas.getContext('2d');
  const grad = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  grad.addColorStop(0, 'rgba(255,255,255,1)');
  grad.addColorStop(0.12, 'rgba(255,255,255,0.85)');
  grad.addColorStop(0.35, 'rgba(255,255,255,0.28)');
  grad.addColorStop(0.7, 'rgba(255,255,255,0.06)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(canvas);
}

export default function ToroidalTopology({ onNodeHover, onNodeClick, onElementClick, dimensions = 13, viewMode = 'overview', onDiveRequest, traversalSpeed = 1.0, traversalZoom = 1.0, traversalPaused = false, mass = 1.0, inspectTarget = null, onInspectPlanet = null, quality = 'balanced', elementFilter = {}, onOrientationUpdate = null, manualOrientation = null, onZoomChange = null, resetSignal = 0 }) {
  const containerRef = useRef(null);
  const hoverRef = useRef(onNodeHover);
  const clickRef = useRef(onNodeClick);
  const elementClickRef = useRef(onElementClick);
  const viewModeRef = useRef(viewMode);
  const diveRequestRef = useRef(onDiveRequest);
  const speedRef = useRef(traversalSpeed);
  const zoomRef = useRef(traversalZoom);
  const pausedRef = useRef(traversalPaused);
  const massRef = useRef(mass);
  const inspectTargetRef = useRef(inspectTarget);
  const inspectPlanetRef = useRef(onInspectPlanet);
  const qualityRef = useRef(quality);
  const elementFilterRef = useRef(elementFilter);
  const orientationRef = useRef(onOrientationUpdate);
  const manualOrientationRef = useRef(manualOrientation);
  const zoomChangeRef = useRef(onZoomChange);
  const resetSignalRef = useRef(resetSignal);
  hoverRef.current = onNodeHover;
  clickRef.current = onNodeClick;
  elementClickRef.current = onElementClick;
  viewModeRef.current = viewMode;
  diveRequestRef.current = onDiveRequest;
  speedRef.current = traversalSpeed;
  zoomRef.current = traversalZoom;
  pausedRef.current = traversalPaused;
  massRef.current = mass;
  inspectTargetRef.current = inspectTarget;
  inspectPlanetRef.current = onInspectPlanet;
  qualityRef.current = quality;
  elementFilterRef.current = elementFilter;
  orientationRef.current = onOrientationUpdate;
  manualOrientationRef.current = manualOrientation;
  zoomChangeRef.current = onZoomChange;
  resetSignalRef.current = resetSignal;

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const glowTex = makeGlowTexture();

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x030308);
    scene.fog = new THREE.FogExp2(0x030308, 0.0028);

    const isMobileViewport = window.innerWidth < 1024;
    let baseRadius = isMobileViewport ? 30 : 20;
    const camera = new THREE.PerspectiveCamera(58, container.clientWidth / container.clientHeight, 0.1, 2000);
    camera.position.set(0, 8, baseRadius);

    const currentQuality = qualityRef.current || (isMobileViewport ? 'balanced' : 'cinematic');
    const mobileTier = currentQuality === 'mobile';

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance', alpha: false });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, currentQuality === 'cinematic' ? 2 : currentQuality === 'balanced' ? 1.5 : 1));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = currentQuality === 'cinematic' ? 1.1 : 1.0;
    container.appendChild(renderer.domElement);

    // ── Cinematic post-processing pipeline ──
    const composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));
    const bloomStrength = currentQuality === 'cinematic' ? 0.65 : currentQuality === 'balanced' ? 0.45 : 0.3;
    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(container.clientWidth, container.clientHeight),
      bloomStrength, 0.4, 0.92
    );
    composer.addPass(bloomPass);

    // Cinematic pass: clean vignette only (no grain, no distortion, no chromatic aberration)
    const cinematicPass = new ShaderPass(cinematicShader);
    cinematicPass.uniforms.uVignetteAmount.value = currentQuality === 'cinematic' ? 0.15 : 0.10;
    if (currentQuality !== 'performance' && !mobileTier) composer.addPass(cinematicPass);

    composer.addPass(new OutputPass());

    // ── Lighting ──
    scene.add(new THREE.AmbientLight(0x1a1a3e, 1.0));
    const keyLight = new THREE.PointLight(0x00f5ff, 3.5, 120);
    keyLight.position.set(15, 15, 15);
    scene.add(keyLight);
    const fillLight = new THREE.PointLight(0xff9f00, 2.0, 90);
    fillLight.position.set(-15, -10, -15);
    scene.add(fillLight);
    const rimLight = new THREE.PointLight(0xbc8cff, 1.8, 70);
    rimLight.position.set(0, -15, 10);
    scene.add(rimLight);
    const topLight = new THREE.PointLight(0x4dd0e1, 1.2, 60);
    topLight.position.set(0, 20, 0);
    scene.add(topLight);

    // ── Multi-layer parallax starfield ──
    function makeStarLayer(count, minR, maxR, size, opacity) {
      const positions = new Float32Array(count * 3);
      const colors = new Float32Array(count * 3);
      const classIndices = new Uint8Array(count);
      for (let i = 0; i < count; i++) {
        const radius = minR + Math.random() * (maxR - minR);
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.acos(2 * Math.random() - 1);
        positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
        positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
        positions[i * 3 + 2] = radius * Math.cos(phi);
        const r = Math.random();
        const cls = starClassIndex(r);
        classIndices[i] = cls;
        const c = new THREE.Color(SPECTRAL_CLASSES[cls].color);
        const bright = 0.6 + Math.random() * 0.4;
        colors[i * 3] = c.r * bright; colors[i * 3 + 1] = c.g * bright; colors[i * 3 + 2] = c.b * bright;
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
      const mat = new THREE.PointsMaterial({
        size, map: glowTex, vertexColors: true, transparent: true, opacity,
        blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true,
      });
      return { points: new THREE.Points(geo, mat), classIndices };
    }
    const starFarData = makeStarLayer(mobileTier ? 2500 : 6000, 350, 600, 1.4, 0.55);
    const starMidData = makeStarLayer(mobileTier ? 1500 : 3500, 160, 300, 2.2, 0.8);
    const starNearData = makeStarLayer(400, 120, 180, 3.0, 0.7);
    const starFar = starFarData.points;
    const starMid = starMidData.points;
    const starNear = starNearData.points;
    scene.add(starFar, starMid, starNear);
    // Starfield layers for click/hover spectral-class resolution
    const starfieldLayers = [
      { points: starNear, classIndices: starNearData.classIndices },
      { points: starMid, classIndices: starMidData.classIndices },
      { points: starFar, classIndices: starFarData.classIndices },
    ];
    // Near-star drift velocities (parallax sense of traversal)
    const driftDir = new THREE.Vector3(0.2, 0.08, 1.0).normalize();
    const nearVel = new Float32Array(350 * 3);
    for (let i = 0; i < 350; i++) {
      const s = 1.6 + Math.random() * 0.9;
      nearVel[i * 3] = driftDir.x * s; nearVel[i * 3 + 1] = driftDir.y * s; nearVel[i * 3 + 2] = driftDir.z * s;
    }

    // ── Nebula clouds (additive depth sprites) ──
    const nebulaColors = [0x6b2d8a, 0x1a6b7a, 0x4a2a6a, 0x2a5a7a, 0x5a1a5a];
    const nebulae = [];
    for (let i = 0; i < (mobileTier ? 5 : 11); i++) {
      const mat = new THREE.SpriteMaterial({
        map: glowTex, color: nebulaColors[i % nebulaColors.length],
        transparent: true, opacity: 0.06 + Math.random() * 0.07,
        blending: THREE.AdditiveBlending, depthWrite: false,
      });
      const sprite = new THREE.Sprite(mat);
      const rad = 200 + Math.random() * 200;
      const th = Math.random() * Math.PI * 2;
      const ph = (Math.random() - 0.5) * Math.PI * 0.5;
      sprite.position.set(rad * Math.cos(ph) * Math.cos(th), rad * Math.sin(ph), rad * Math.cos(ph) * Math.sin(th));
      sprite.scale.setScalar(90 + Math.random() * 140);
      scene.add(sprite);
      nebulae.push(sprite);
    }
    const nebulaVel = nebulae.map(() => driftDir.clone().multiplyScalar(0.12 + Math.random() * 0.08));

    // ── Enriched cosmic background (Milky Way band, deep field, galaxies, nebulae) ──
    const cosmicField = createCosmicField({ scene, glowTex });
    // Add Milky Way band + deep-field stars to the spectral-class raycast list
    if (cosmicField.starfieldLayers) {
      starfieldLayers.push(...cosmicField.starfieldLayers);
    }

    // ── Far-field black hole — HD accretion disk, Doppler beaming, lensing ──
    const bhGroup = new THREE.Group();
    bhGroup.position.set(-40, 9, -58);
    // Event horizon — opaque black shadow sphere
    const ehGeo = new THREE.SphereGeometry(4.6, 48, 48);
    const ehMat = new THREE.MeshBasicMaterial({ color: 0x000000 });
    const eventHorizon = new THREE.Mesh(ehGeo, ehMat);
    eventHorizon.userData = {
      id: 'black-hole',
      type: 'Gravitational Singularity',
      name: 'Black Hole',
      description: 'A region of spacetime where gravity is so strong that nothing — not even light — can escape. The boundary is the event horizon; the bright ring is the photon ring, where light orbits the hole in unstable circular orbits. The accretion disk shows Doppler beaming — the approaching side appears brighter due to relativistic effects. This rendering shows the shadow predicted by general relativity and confirmed by the Event Horizon Telescope.',
      significance: 'Black hole thermodynamics connects gravity, quantum mechanics, and information via the Bekenstein-Hawking entropy. In the Unitary Manifold framework, black holes provide a laboratory for quantum gravity and dark energy — the cosmological constant appears in the de Sitter horizon entropy.',
      links: [{ label: 'Black Hole Information', path: '/repository?file=7-OUTREACH/substack/posts/post-013-black-hole-information.md' }],
      groupId: 'black-hole',
    };
    bhGroup.add(eventHorizon);
    // Refined photon ring — thin, bright, with chromatic aberration (dual rings)
    const photonRingGeo = new THREE.TorusGeometry(5.0, 0.05, 16, 128);
    const photonRingMat = new THREE.MeshBasicMaterial({ color: 0xffe0a0, transparent: true, opacity: 1.0, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false });
    const photonRing = new THREE.Mesh(photonRingGeo, photonRingMat);
    bhGroup.add(photonRing);
    // Chromatic aberration inner ring — blue-shifted
    const photonChromaGeo = new THREE.TorusGeometry(4.92, 0.025, 12, 96);
    const photonChromaMat = new THREE.MeshBasicMaterial({ color: 0x80c0ff, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false });
    const photonChroma = new THREE.Mesh(photonChromaGeo, photonChromaMat);
    bhGroup.add(photonChroma);
    // Accretion disk — tilted ring with radial temperature gradient + Doppler beaming
    const diskInner = 5.3, diskOuter = 9.5;
    const diskGeo = new THREE.RingGeometry(diskInner, diskOuter, 256, 6);
    const diskColorArr = new Float32Array(diskGeo.attributes.position.count * 3);
    const diskPosAttr = diskGeo.attributes.position;
    const cInner = new THREE.Color(0xffffff);
    const cMid = new THREE.Color(0xffd060);
    const cOuter = new THREE.Color(0xff3020);
    for (let i = 0; i < diskPosAttr.count; i++) {
      const px = diskPosAttr.getX(i), py = diskPosAttr.getY(i);
      const angle = Math.atan2(py, px);
      const radius = Math.sqrt(px * px + py * py);
      const rt = Math.min(1, Math.max(0, (radius - diskInner) / (diskOuter - diskInner)));
      let c;
      if (rt < 0.5) c = cInner.clone().lerp(cMid, rt * 2);
      else c = cMid.clone().lerp(cOuter, (rt - 0.5) * 2);
      // Doppler beaming: approaching side (angle ~0, +x) brighter, receding (angle ~PI) dimmer
      const doppler = 0.5 + 0.5 * Math.cos(angle);
      const beam = 0.25 + doppler * 0.75;
      c.multiplyScalar(beam);
      diskColorArr[i * 3] = c.r; diskColorArr[i * 3 + 1] = c.g; diskColorArr[i * 3 + 2] = c.b;
    }
    diskGeo.setAttribute('color', new THREE.BufferAttribute(diskColorArr, 3));
    const diskMat = new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false });
    const accretionDisk = new THREE.Mesh(diskGeo, diskMat);
    accretionDisk.rotation.x = -Math.PI * 0.42;
    bhGroup.add(accretionDisk);
    // Gravitational lensing — Einstein ring at photon sphere radius
    const lensGeo = new THREE.TorusGeometry(6.2, 0.035, 8, 128);
    const lensMat = new THREE.MeshBasicMaterial({ color: 0xffe0b0, transparent: true, opacity: 0.45, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false });
    const lensRing = new THREE.Mesh(lensGeo, lensMat);
    bhGroup.add(lensRing);
    // Soft lensing glow halo behind the shadow
    const bhGlowMat = new THREE.SpriteMaterial({ map: glowTex, color: 0xffb066, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false });
    const bhGlow = new THREE.Sprite(bhGlowMat);
    bhGlow.scale.setScalar(16);
    bhGroup.add(bhGlow);
    scene.add(bhGroup);

    // ── Solar system orrery (enlarged, interactive) ──
    const solarSystem = createSolarSystem({ scene, glowTex });

    // ── Spiral galaxy ──
    const spiralGalaxy = createSpiralGalaxy({ scene, glowTex });

    // ── Pulsar / neutron star ──
    const pulsar = createPulsar({ scene, glowTex });

    // ── Supernova remnant ──
    const supernovaRemnant = createSupernovaRemnant({ scene, glowTex });

    // ── Dark energy field (de Sitter horizon) ──
    const darkEnergy = createDarkEnergyField({ scene, glowTex });

    // ── Dark matter cosmic web ──
    const darkMatter = createDarkMatterWeb({ scene });

    // ── Gravitational waves (binary merger) ──
    const gravWaves = createGravitationalWaves({ scene, glowTex });

    // ── Pillar stars (clickable, linked to repository pillars) ──
    const pillarStars = createPillarStars({ scene, glowTex });

    // ── Founding fathers (Kaluza & Klein memorial nodes) ──
    const foundingFathers = createFoundingFathers({ scene, glowTex });

    // ── Named notable objects (real stars, galaxies, nebulae, clusters) ──
    const namedObjects = createNamedObjects({ scene, glowTex });

    // ── Volumetric nebulae (raymarched 3D noise volumes) ──
    const volNebulae = createVolumetricNebulae({ scene, count: 4 });

    // ── Catalog-driven starfield (real Hipparcos bright-star positions) ──
    const catalogStarfield = createCatalogStarfield({ scene, glowTex, quality: currentQuality });
    if (catalogStarfield.starfieldLayers) {
      starfieldLayers.push(...catalogStarfield.starfieldLayers);
    }

    // ── Mission & observatory satellites (LISA, LiteBIRD, DESI, JUNO, Euclid, Roman, SKA, Athena, LIGO, ET, CMB-S4) ──
    const missionSats = createMissionSatellites({ scene, glowTex });

    // ── Cosmic phenomena destinations (neutron star, exoplanet system) ──
    const cosmicDests = createCosmicDestinations({ scene, glowTex });

    // ── Physics pillar nodes (framework derivations on the torus) ──
    const pillarNodes = createPillarNodes({ scene, glowTex });

    // ── Expanded solar system (dwarf planets, asteroid belt, Kuiper belt) ──
    const expandedSolar = createExpandedSolarSystem({
      group: solarSystem.group,
      disposables: solarSystem._disposables || [],
    });

    // ── Electromagnetic field lines (toroidal + poloidal) ──
    const fieldLines = [];
    const fieldLineCount = 16;
    for (let f = 0; f < fieldLineCount; f++) {
      const u = (f / fieldLineCount) * Math.PI * 2;
      const pts = [];
      for (let i = 0; i <= 64; i++) { pts.push(torusPoint(u, (i / 64) * Math.PI * 2)); }
      const geo = new THREE.BufferGeometry().setFromPoints(pts);
      const mat = new THREE.LineBasicMaterial({ color: 0x00f5ff, transparent: true, opacity: 0.08, blending: THREE.AdditiveBlending });
      const line = new THREE.Line(geo, mat);
      scene.add(line);
      fieldLines.push({ line, mat, type: 'toroidal', index: f });
    }
    for (let f = 0; f < fieldLineCount; f++) {
      const v = (f / fieldLineCount) * Math.PI * 2;
      const pts = [];
      for (let i = 0; i <= 120; i++) { pts.push(torusPoint((i / 120) * Math.PI * 2, v)); }
      const geo = new THREE.BufferGeometry().setFromPoints(pts);
      const mat = new THREE.LineBasicMaterial({ color: 0x4dd0e1, transparent: true, opacity: 0.05, blending: THREE.AdditiveBlending });
      const line = new THREE.Line(geo, mat);
      scene.add(line);
      fieldLines.push({ line, mat, type: 'poloidal', index: f });
    }

    // ── EM field flow particles ──
    const emParticleCount = 150;
    const emPositions = new Float32Array(emParticleCount * 3);
    const emColors = new Float32Array(emParticleCount * 3);
    const emData = [];
    for (let i = 0; i < emParticleCount; i++) {
      const u = Math.random() * Math.PI * 2;
      const v = Math.random() * Math.PI * 2;
      const pos = torusPoint(u, v);
      emPositions[i * 3] = pos.x; emPositions[i * 3 + 1] = pos.y; emPositions[i * 3 + 2] = pos.z;
      emData.push({ u, v, uSpeed: 0.3 + Math.random() * 0.5, vSpeed: 0.1 + Math.random() * 0.3, isToroidal: Math.random() > 0.5 });
      const c = new THREE.Color().setHSL(0.5 + Math.random() * 0.08, 0.9, 0.6);
      emColors[i * 3] = c.r; emColors[i * 3 + 1] = c.g; emColors[i * 3 + 2] = c.b;
    }
    const emGeo = new THREE.BufferGeometry();
    emGeo.setAttribute('position', new THREE.BufferAttribute(emPositions, 3));
    emGeo.setAttribute('color', new THREE.BufferAttribute(emColors, 3));
    const emMat = new THREE.PointsMaterial({ size: 0.08, vertexColors: true, transparent: true, opacity: 0.25, blending: THREE.AdditiveBlending, sizeAttenuation: true, depthWrite: false });
    scene.add(new THREE.Points(emGeo, emMat));

    // ── Plasma current streams ──
    const plasmaStreams = [];
    const streamCount = 5;
    for (let s = 0; s < streamCount; s++) {
      const points = [];
      const vRate = 1.0 + s * 0.4;
      const vOffset = (s / streamCount) * Math.PI * 2;
      const segments = 120;
      for (let i = 0; i <= segments; i++) {
        const u = (i / segments) * Math.PI * 2;
        const v = u * vRate + vOffset;
        const rVar = r * (0.85 + Math.sin(u * 6 + s) * 0.15);
        points.push(new THREE.Vector3((R + rVar * Math.cos(v)) * Math.cos(u), rVar * Math.sin(v), (R + rVar * Math.cos(v)) * Math.sin(u)));
      }
      const curve = new THREE.CatmullRomCurve3(points, true);
      const tubeGeo = new THREE.TubeGeometry(curve, 200, 0.06 + s * 0.01, 8, true);
      const tubeMat = new THREE.MeshBasicMaterial({ color: PLASMA_COLORS[s % PLASMA_COLORS.length], transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending });
      const tube = new THREE.Mesh(tubeGeo, tubeMat);
      tube.userData = {
        id: 'plasma-streams',
        type: 'Plasma Dynamics',
        name: 'Plasma Current Streams',
        description: 'Magnetized plasma flowing along the toroidal field lines of the manifold. In fusion reactors, these currents confine plasma at 100+ million degrees; in the Unitary Manifold, they represent the energy-momentum currents of the compactified field theory.',
        significance: 'Plasma dynamics on toroidal topology connects to magnetohydrodynamics, reconnection, and dynamo theory. The stability of these streams tests the manifold\'s topological protection against field decay.',
        links: [{ label: 'Theory Overview', path: '/repository?file=1-THEORY/README.md' }],
        groupId: 'plasma-streams',
      };
      scene.add(tube);
      plasmaStreams.push({ material: tubeMat, offset: s * 0.8, mesh: tube });
    }

    // ── Plasma particle cloud ──
    const plasmaParticleCount = 400;
    const plasmaPositions = new Float32Array(plasmaParticleCount * 3);
    const plasmaColors = new Float32Array(plasmaParticleCount * 3);
    const plasmaData = [];
    for (let i = 0; i < plasmaParticleCount; i++) {
      const u = Math.random() * Math.PI * 2;
      const v = Math.random() * Math.PI * 2;
      const pos = torusPoint(u, v);
      plasmaPositions[i * 3] = pos.x; plasmaPositions[i * 3 + 1] = pos.y; plasmaPositions[i * 3 + 2] = pos.z;
      plasmaData.push({ u, v, uSpeed: 0.08 + Math.random() * 0.25, vSpeed: 0.15 + Math.random() * 0.4, phase: Math.random() * Math.PI * 2 });
      const color = new THREE.Color().setHSL(0.48 + Math.random() * 0.12, 0.9, 0.5 + Math.random() * 0.3);
      plasmaColors[i * 3] = color.r; plasmaColors[i * 3 + 1] = color.g; plasmaColors[i * 3 + 2] = color.b;
    }
    const plasmaGeo = new THREE.BufferGeometry();
    plasmaGeo.setAttribute('position', new THREE.BufferAttribute(plasmaPositions, 3));
    plasmaGeo.setAttribute('color', new THREE.BufferAttribute(plasmaColors, 3));
    const plasmaMat = new THREE.PointsMaterial({ size: 0.12, vertexColors: true, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, sizeAttenuation: true, depthWrite: false });
    scene.add(new THREE.Points(plasmaGeo, plasmaMat));

    // ── Compactified KK dimension rings ──
    const dimRings = [];
    const dimParticles = [];
    const dimParticleGeo = new THREE.SphereGeometry(0.06, 6, 6);
    for (let d = 4; d <= dimensions; d++) {
      const dimIndex = d - 4;
      const ringR = R * (0.35 + (1 - dimIndex / 10) * 0.55);
      const ringTube = Math.max(0.12, r * 0.08 * (1 - dimIndex / 12));
      const ringGeo = new THREE.TorusGeometry(ringR, ringTube, 6, 48);
      const ringMat = new THREE.MeshBasicMaterial({ color: DIM_COLORS[dimIndex % DIM_COLORS.length], transparent: true, opacity: 0.04 + (1 - dimIndex / 10) * 0.03, blending: THREE.AdditiveBlending, wireframe: true });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = dimIndex * 0.4; ring.rotation.y = dimIndex * 0.3; ring.rotation.z = dimIndex * 0.2;
      ring.userData = {
        id: 'kk-dimensions',
        type: 'Compactified Dimensions',
        name: 'Kaluza-Klein Dimension Rings',
        description: 'The compactified extra dimensions of the Kaluza-Klein framework — curled up at each point of the large toroidal dimensions. Each ring represents one compactified dimension, with the full 13D manifold having 10 compact dimensions beyond our 3+1 spacetime.',
        significance: 'Kaluza-Klein compactification unifies gravity and gauge forces by encoding gauge symmetry in the geometry of extra dimensions. The spectrum of KK modes — the tower of massive states — is determined by the compactification manifold\'s topology and is a key prediction of the Unitary Manifold framework.',
        links: [{ label: 'Kaluza-Klein Compactification', path: '/compactification' }],
        groupId: 'kk-dimensions',
      };
      scene.add(ring);
      dimRings.push({ mesh: ring, speed: 0.002 + dimIndex * 0.0008, axis: dimIndex % 3 });
      const particleCount = 3 + Math.floor(dimIndex / 2);
      for (let p = 0; p < particleCount; p++) {
        const pMat = new THREE.MeshBasicMaterial({ color: DIM_COLORS[dimIndex % DIM_COLORS.length], transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending });
        const particle = new THREE.Mesh(dimParticleGeo, pMat);
        particle.userData = { ringR, phase: (p / particleCount) * Math.PI * 2, speed: 0.003 + dimIndex * 0.0005 + Math.random() * 0.002, tiltX: dimIndex * 0.4, tiltY: dimIndex * 0.3, tiltZ: dimIndex * 0.2 };
        scene.add(particle);
        dimParticles.push(particle);
      }
    }

    // ── Central radion field ──
    const radionGeo = new THREE.SphereGeometry(0.5, 24, 24);
    const radionMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending });
    const radion = new THREE.Mesh(radionGeo, radionMat);
    radion.userData = {
      id: 'radion-field',
      type: 'Scalar Field',
      name: 'Radion Field',
      description: 'The radion is the scalar degree of freedom associated with the volume of the extra dimensions in braneworld scenarios. It controls the effective size of the compactified manifold and, in the Unitary Manifold, is connected to the dark energy density through the radion-dark energy coupling.',
      significance: 'The radion provides a geometric origin for scalar fields in extra-dimensional theories. Its stabilization mechanism determines the cosmological constant, making it a bridge between compactification geometry and the observed dark energy.',
      links: [{ label: 'Radion Field & Extra Dimensions', path: '/manifold-explorer' }],
      groupId: 'radion',
    };
    scene.add(radion);
    const radionGlowGeo = new THREE.SphereGeometry(1.5, 16, 16);
    const radionGlowMat = new THREE.MeshBasicMaterial({ color: 0x00f5ff, transparent: true, opacity: 0.06, blending: THREE.AdditiveBlending });
    const radionGlow = new THREE.Mesh(radionGlowGeo, radionGlowMat);
    scene.add(radionGlow);

    // ── Energy-orb nodes (layered volumetric glow) ──
    const sphereGeo = new THREE.SphereGeometry(1, 32, 32);
    const nodes = [];
    const nodeState = [];

    DOMAIN_CONFIG.forEach((cfg, i) => {
      const baseU = (i / DOMAIN_CONFIG.length) * Math.PI * 2;
      const baseV = (i * 0.7) % (Math.PI * 2);

      // Mid layer — raycast target, node color, additive plasma
      const midMat = new THREE.MeshBasicMaterial({ color: cfg.color, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false });
      const mesh = new THREE.Mesh(sphereGeo, midMat);
      mesh.scale.setScalar(cfg.size);
      mesh.userData = { id: cfg.id, name: cfg.name, tier: cfg.tier, hubPath: cfg.hubPath, baseSize: cfg.size };
      scene.add(mesh);
      nodes.push(mesh);

      // Core — white-hot center
      const coreMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
      const core = new THREE.Mesh(sphereGeo, coreMat);
      core.scale.setScalar(cfg.size * 0.45);
      scene.add(core);

      // Corona — outer translucent shell
      const coronaMat = new THREE.MeshBasicMaterial({ color: cfg.color, transparent: true, opacity: 0.18, blending: THREE.AdditiveBlending, depthWrite: false });
      const corona = new THREE.Mesh(sphereGeo, coronaMat);
      corona.scale.setScalar(cfg.size * 2.2);
      scene.add(corona);

      // Glow sprite — wide soft halo
      const glowSpriteMat = new THREE.SpriteMaterial({ map: glowTex, color: cfg.color, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false });
      const glowSprite = new THREE.Sprite(glowSpriteMat);
      glowSprite.scale.setScalar(cfg.size * 8);
      scene.add(glowSprite);

      // Trail
      const trailPositions = new Float32Array(TRAIL_LENGTH * 3);
      const trailColors = new Float32Array(TRAIL_LENGTH * 3);
      const trailGeo = new THREE.BufferGeometry();
      trailGeo.setAttribute('position', new THREE.BufferAttribute(trailPositions, 3));
      trailGeo.setAttribute('color', new THREE.BufferAttribute(trailColors, 3));
      const trailMat = new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending });
      const trail = new THREE.Line(trailGeo, trailMat);
      scene.add(trail);

      nodeState.push({
        mesh, core, corona, glowSprite, trail, trailPositions, trailColors,
        baseU, baseV, uSpeed: cfg.uSpeed, vSpeed: cfg.vSpeed,
        color: new THREE.Color(cfg.color),
        currentU: baseU, currentV: baseV, trailHistory: []
      });
    });

    // ── Node residual energy field (fades into starfield) ──
    const nodeEnergy = createNodeEnergyField({ scene, glowTex, nodeState });

    // ── Dynamic geodesic connections ──
    const connections = CONNECTIONS.map(([fromId, toId]) => {
      const positions = new Float32Array(CONN_SEGMENTS * 3);
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      const mat = new THREE.LineBasicMaterial({ color: 0x4dd0e1, transparent: true, opacity: 0.15, blending: THREE.AdditiveBlending });
      const line = new THREE.Line(geo, mat);
      const fromDomain = DOMAIN_CONFIG.find(d => d.id === fromId);
      const toDomain = DOMAIN_CONFIG.find(d => d.id === toId);
      line.userData = {
        id: 'traversal-path',
        type: 'Geodesic Traversal Path',
        name: `${fromDomain?.name || 'Node'} ↔ ${toDomain?.name || 'Node'}`,
        description: 'A geodesic connection linking two domain nodes across the toroidal manifold. Energy and information flow along these shortest paths through the compactified geometry, binding the five-sector venture-infrastructure topology into a coherent network.',
        significance: 'Geodesic traversal paths represent the fundamental connectivity of the manifold — the shortest routes through curved spacetime. In the Unitary Manifold, these connections encode the relational structure between domains and enable cross-domain energy transfer.',
        links: [{ label: 'KK Geodesic Reduction', path: '/repository?file=src/core/kk_geodesic_reduction.py' }, { label: 'Cognitive Layer', path: '/cognitive-layer' }],
        groupId: 'traversal',
      };
      scene.add(line);
      return { line, positions, fromId, toId, geo, mat };
    });

    // ── Electric arcs ──
    const electricArcs = CONNECTIONS.map(([fromId, toId]) => {
      const arcSegs = 16;
      const positions = new Float32Array(arcSegs * 3);
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      const mat = new THREE.LineBasicMaterial({ color: 0x00f5ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending });
      const line = new THREE.Line(geo, mat);
      scene.add(line);
      return { line, positions, geo, mat, fromId, toId, arcSegs, flickerTimer: 0, active: false };
    });

    // ── Energy flow particles along connections ──
    const flowParticles = [];
    const flowParticleGeo = new THREE.SphereGeometry(0.12, 8, 8);
    connections.forEach((conn) => {
      for (let p = 0; p < 3; p++) {
        const pMat = new THREE.MeshBasicMaterial({ color: 0x00f5ff, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending });
        const particle = new THREE.Mesh(flowParticleGeo, pMat);
        particle.userData = { conn, progress: Math.random(), speed: 0.004 + Math.random() * 0.004 };
        scene.add(particle);
        flowParticles.push(particle);
      }
    });

    // ── EM field proxy torus (single raycast target — replaces 32 individual lines) ──
    // Visual field lines remain rendered but are NOT raycast targets, eliminating the
    // click-interception problem. The invisible proxy torus carries the EM field userData.
    const emProxyGeo = new THREE.TorusGeometry(R * 1.01, r * 1.12, 12, 48);
    const emProxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide });
    const emProxy = new THREE.Mesh(emProxyGeo, emProxyMat);
    emProxy.userData = {
      id: 'em-field-topology',
      type: 'Electromagnetic Topology',
      name: 'Electromagnetic Field Lines',
      description: 'The toroidal-poloidal field topology of the Unitary Manifold — electromagnetic flux circulating both around the tube (toroidal) and around the central axis (poloidal) of the 13-dimensional compactified torus. These field lines represent the gauge field configurations of the compactified theory.',
      significance: 'The toroidal-poloidal decomposition is fundamental to plasma confinement (tokamaks), magnetospheric physics, and the Unitary Manifold\'s field equations. The topology determines the spectral properties of compactified dimensions and the stability of field configurations.',
      links: [{ label: 'Maxwell KK Reduction', path: '/repository?file=src/core/maxwell_kk_reduction.py' }],
      groupId: 'em-field',
      noHighlight: true,
    };
    scene.add(emProxy);

    // ── Interactive objects collection ──
    const interactiveObjects = [...nodes];
    plasmaStreams.forEach(s => interactiveObjects.push(s.mesh));
    dimRings.forEach(dr => interactiveObjects.push(dr.mesh));
    interactiveObjects.push(radion, eventHorizon);
    interactiveObjects.push(...solarSystem.interactiveObjects);
    interactiveObjects.push(...spiralGalaxy.interactiveObjects);
    interactiveObjects.push(...cosmicField.interactiveObjects);
    interactiveObjects.push(...pulsar.interactiveObjects);
    interactiveObjects.push(...supernovaRemnant.interactiveObjects);
    interactiveObjects.push(...darkEnergy.interactiveObjects);
    interactiveObjects.push(...darkMatter.interactiveObjects);
    interactiveObjects.push(...gravWaves.interactiveObjects);
    interactiveObjects.push(...pillarStars.interactiveObjects);
    interactiveObjects.push(...foundingFathers.interactiveObjects);
    interactiveObjects.push(...namedObjects.interactiveObjects);
    interactiveObjects.push(...volNebulae.interactiveObjects);
    interactiveObjects.push(...catalogStarfield.interactiveObjects);
    interactiveObjects.push(...missionSats.interactiveObjects);
    interactiveObjects.push(...cosmicDests.interactiveObjects);
    interactiveObjects.push(...pillarNodes.interactiveObjects);
    interactiveObjects.push(...expandedSolar.interactiveObjects);
    connections.forEach(c => interactiveObjects.push(c.line));

    // Group highlight targets — materials to brighten when a group member is hovered
    const groupHighlightMap = {};
    groupHighlightMap['em-field'] = [...fieldLines.map(fl => fl.mat)];
    groupHighlightMap['plasma-streams'] = plasmaStreams.map(s => s.material);
    groupHighlightMap['kk-dimensions'] = dimRings.map(dr => dr.mesh.material);
    groupHighlightMap['radion'] = [radion.material, radionGlow.material];
    groupHighlightMap['black-hole'] = [photonRingMat, photonChromaMat, diskMat, lensMat, bhGlowMat];
    groupHighlightMap['dark-energy'] = darkEnergy.groupMaterials;
    groupHighlightMap['dark-matter'] = darkMatter.groupMaterials;
    groupHighlightMap['gravitational-waves'] = gravWaves.groupMaterials;
    groupHighlightMap['pillar-stars'] = pillarStars.groupMaterials;
    groupHighlightMap['founding-fathers'] = foundingFathers.groupMaterials;
    groupHighlightMap['traversal'] = connections.map(c => c.mat);

    const highlightStore = new Map();
    function setMaterialHighlight(mat, level) {
      if (!mat) return;
      let st = highlightStore.get(mat);
      if (level) {
        if (!st) {
          st = {};
          if (mat.color) st.color = mat.color.getHex();
          if (mat.transparent) st.opacity = mat.opacity;
          if (mat.emissiveIntensity != null) st.emissiveIntensity = mat.emissiveIntensity;
          highlightStore.set(mat, st);
        }
        if (level === 'strong') {
          if (mat.color && st.color != null) mat.color.setHex(st.color).multiplyScalar(2.0);
          if (mat.transparent && st.opacity != null) mat.opacity = Math.min(1, st.opacity * 3.5 + 0.25);
          if (st.emissiveIntensity != null) mat.emissiveIntensity = Math.min(1, st.emissiveIntensity * 4 + 0.1);
        } else { // subtle — group context, dimmer than the hovered member
          if (mat.color && st.color != null) mat.color.setHex(st.color).multiplyScalar(1.25);
          if (mat.transparent && st.opacity != null) mat.opacity = Math.min(1, st.opacity * 1.6 + 0.08);
          if (st.emissiveIntensity != null) mat.emissiveIntensity = Math.min(1, st.emissiveIntensity * 2 + 0.05);
        }
      } else if (st) {
        if (mat.color && st.color != null) mat.color.setHex(st.color);
        if (mat.transparent && st.opacity != null) mat.opacity = st.opacity;
        if (st.emissiveIntensity != null) mat.emissiveIntensity = st.emissiveIntensity;
      }
    }
    function highlightObject(obj, level) {
      if (obj.material) setMaterialHighlight(obj.material, level);
    }
    function highlightGroup(groupId, level) {
      const mats = groupHighlightMap[groupId];
      if (!mats) return;
      mats.forEach(m => setMaterialHighlight(m, level));
    }

    // ── Raycaster ──
    const raycaster = new THREE.Raycaster();
    raycaster.params.Line.threshold = 1.5;
    raycaster.params.Points.threshold = 2.0;
    const mouse = new THREE.Vector2(-9999, -9999);
    let hoveredNode = null;
    let hoveredStarActive = false;
    let lastStarKey = null;

    // ── Solar system dive state ──
    let diveTween = null;
    let lastViewMode = 'overview';
    let lastInspectTarget = null;
    let currentTarget = new THREE.Vector3(0, 0, 0);
    let overviewAngle = 0;
    let solarAngle = 0;
    let inspectAngle = 0;

    // ── Spherical orbit state (mouse-driven, damped) ──
    let orbitAzT = 0;          // target azimuth
    let orbitElT = 0.35;       // target elevation (rad)
    let orbitEl = 0.35;        // current elevation
    const orbitPan = new THREE.Vector3();      // current pan offset (world)
    const orbitPanT = new THREE.Vector3();      // target pan offset
    let mouseActive = false;   // user recently interacted (suppresses auto-rotation)
    let mouseIdleTimer = 0;
    let mouseDown = false;
    let mousePanMode = false;
    let lastMX = 0, lastMY = 0;
    let lastResetSignal = 0;
    let mouseDownPos = null;

    // ── Starfield spectral-class raycast helper ──
    function raycastStarfield() {
      const prevThreshold = raycaster.params.Points.threshold;
      raycaster.params.Points.threshold = 2.0;
      for (const layer of starfieldLayers) {
        const hits = raycaster.intersectObject(layer.points, false);
        if (hits.length > 0 && hits[0].index != null) {
          raycaster.params.Points.threshold = prevThreshold;
          return { classIndex: layer.classIndices[hits[0].index] };
        }
      }
      raycaster.params.Points.threshold = prevThreshold;
      return null;
    }

    // ── Catalog star raycast — resolve individual Gaia DR3 star data ──
    // Uses a larger threshold so all 1,300 stars are reliably clickable
    function raycastCatalogStar() {
      if (!catalogStarfield?.catalogPoints) return null;
      const prevThreshold = raycaster.params.Points.threshold;
      raycaster.params.Points.threshold = 6.0;
      const hits = raycaster.intersectObject(catalogStarfield.catalogPoints, false);
      raycaster.params.Points.threshold = prevThreshold;
      if (hits.length > 0 && hits[0].index != null) {
        return catalogStarfield.catalogStars[hits[0].index] || null;
      }
      return null;
    }

    const handleMouseMove = (e) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    };
    const handleMouseLeave = () => { mouse.x = -9999; mouse.y = -9999; };
    const handleClick = (e) => {
      // Suppress click if this followed a drag (camera orbit/pan)
      if (mouseDownPos && (Math.abs(e.clientX - mouseDownPos.x) > 5 || Math.abs(e.clientY - mouseDownPos.y) > 5)) return;
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, camera);
      const hits = raycaster.intersectObjects(interactiveObjects, false);
      if (hits.length > 0) {
        const hit0 = hits[0];
        const ud = hit0.object.userData;
        // Instanced catalog starfield — resolve the exact Gaia star by instanceId
        if (ud.isInstanced && hit0.instanceId != null) {
          const starData = catalogStarfield.resolveStar?.(hit0.instanceId);
          if (starData) { elementClickRef.current?.(starData); return; }
        }
        // Sun click in overview mode → trigger solar system dive
        if (ud.id === 'sun' && viewModeRef.current === 'overview') {
          diveRequestRef.current?.('solar-system');
          return;
        }
        if (typeof ud.id === 'string' && ud.id.startsWith('planet-') && viewModeRef.current === 'solar-system') {
          inspectPlanetRef.current?.(ud.id.replace('planet-', ''));
          return;
        }
        if (ud.hubPath) clickRef.current?.(ud);
        else elementClickRef.current?.(ud);
        return;
      }
      // Catalog star click — resolve individual Gaia DR3 star data (all 1,300 stars)
      const catStar = raycastCatalogStar();
      if (catStar) {
        elementClickRef.current?.(catStar);
        return;
      }
      // Starfield fallback — resolve spectral class from clicked star
      const starHit = raycastStarfield();
      if (starHit) {
        elementClickRef.current?.(spectralClassUserData(starHit.classIndex));
      }
    };
    container.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('mouseleave', handleMouseLeave);
    container.addEventListener('click', handleClick);

    // ── Touch gestures (mobile): one-finger drag to orbit, pinch to zoom ──
    let touchZoom = 1.0;
    let isTouchDragging = false;
    let lastTouchX = 0;
    let lastTouchY = 0;
    let lastTouchDist = 0;
    const handleTouchStart = (e) => {
      if (e.touches.length === 1) { isTouchDragging = true; lastTouchX = e.touches[0].clientX; lastTouchY = e.touches[0].clientY; mouseActive = true; mouseIdleTimer = 0; }
      else if (e.touches.length === 2) {
        isTouchDragging = false;
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        lastTouchDist = Math.sqrt(dx * dx + dy * dy);
      }
    };
    const handleTouchMove = (e) => {
      if (e.touches.length === 1 && isTouchDragging) {
        e.preventDefault();
        const dx = e.touches[0].clientX - lastTouchX;
        const dy = e.touches[0].clientY - lastTouchY;
        lastTouchX = e.touches[0].clientX; lastTouchY = e.touches[0].clientY;
        mouseIdleTimer = 0;
        orbitAzT -= dx * 0.005;
        orbitElT -= dy * 0.005;
        orbitElT = Math.max(-1.3, Math.min(1.3, orbitElT));
      } else if (e.touches.length === 2) {
        e.preventDefault();
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (lastTouchDist > 0) {
          const scale = dist / lastTouchDist;
          touchZoom = Math.max(0.1, Math.min(5, touchZoom * scale));
        }
        lastTouchDist = dist;
      }
    };
    const handleTouchEnd = () => { isTouchDragging = false; lastTouchDist = 0; };
    container.addEventListener('touchstart', handleTouchStart, { passive: true });
    container.addEventListener('touchmove', handleTouchMove, { passive: false });
    container.addEventListener('touchend', handleTouchEnd, { passive: true });

    // ── Mouse navigation (OrbitControls-style): drag = orbit, wheel = zoom, right-drag = pan ──
    const handleMouseDown = (e) => {
      mouseDown = true;
      mousePanMode = (e.button === 2);
      lastMX = e.clientX; lastMY = e.clientY;
      mouseDownPos = { x: e.clientX, y: e.clientY };
      mouseActive = true;
      mouseIdleTimer = 0;
      container.style.cursor = 'grabbing';
    };
    const handleMouseUp = () => {
      mouseDown = false;
      mousePanMode = false;
      container.style.cursor = 'grab';
    };
    const handleMouseDrag = (e) => {
      if (!mouseDown) return;
      const dx = e.clientX - lastMX;
      const dy = e.clientY - lastMY;
      lastMX = e.clientX; lastMY = e.clientY;
      mouseIdleTimer = 0;
      const curDist = baseRadius * zoomRef.current * touchZoom;
      if (mousePanMode) {
        // Pan in the camera's right/up directions (shifts the orbit center)
        const fwd = new THREE.Vector3();
        camera.getWorldDirection(fwd);
        const worldUp = new THREE.Vector3(0, 1, 0);
        const camRight = new THREE.Vector3().crossVectors(fwd, worldUp).normalize();
        const camUp = new THREE.Vector3().crossVectors(camRight, fwd).normalize();
        const panSpeed = 0.012 * curDist;
        orbitPanT.addScaledVector(camRight, -dx * panSpeed);
        orbitPanT.addScaledVector(camUp, dy * panSpeed);
      } else {
        orbitAzT -= dx * 0.005;
        orbitElT -= dy * 0.005;
        orbitElT = Math.max(-1.3, Math.min(1.3, orbitElT));
      }
    };
    const handleWheel = (e) => {
      e.preventDefault();
      mouseActive = true;
      mouseIdleTimer = 0;
      const cur = zoomRef.current;
      const factor = e.deltaY > 0 ? 0.92 : 1.08;
      const next = Math.max(0.1, Math.min(5.0, cur * factor));
      if (zoomChangeRef.current) zoomChangeRef.current(next);
    };
    const handleContextMenu = (e) => e.preventDefault();
    container.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('mousemove', handleMouseDrag);
    container.addEventListener('wheel', handleWheel, { passive: false });
    container.addEventListener('contextmenu', handleContextMenu);
    container.style.cursor = 'grab';

    const handleResize = () => {
      if (!container.clientWidth) return;
      const w = container.clientWidth, h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      composer.setSize(w, h);
      bloomPass.setSize(w, h);
      baseRadius = window.innerWidth < 1024 ? 30 : 20;
    };
    window.addEventListener('resize', handleResize);

    let animId;
    let lastT = 0;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      const t = performance.now() * 0.001;
      const dt = Math.min(0.05, t - lastT); lastT = t;

      // Reset signal → snap orbit to the zoomed-out default framing
      if (resetSignalRef.current !== lastResetSignal) {
        lastResetSignal = resetSignalRef.current;
        orbitAzT = 0; overviewAngle = 0;
        orbitElT = 0.35; orbitEl = 0.35;
        orbitPanT.set(0, 0, 0); orbitPan.set(0, 0, 0);
      }
      // Idle timer — resume auto-rotation 2.5s after the user stops interacting
      if (mouseActive && !mouseDown) {
        mouseIdleTimer += dt;
        if (mouseIdleTimer > 2.5) mouseActive = false;
      }

      // Starfield — subtle drift + twinkle (sped up — non-interactive background)
      starFar.rotation.y += 0.00012;
      starMid.rotation.y += 0.00021;
      starNear.material.opacity = 0.9 + Math.sin(t * 0.7) * 0.08;
      // Near-star parallax drift — torus traveling through the universe
      const nearPos = starNear.geometry.attributes.position.array;
      for (let i = 0; i < 350; i++) {
        nearPos[i * 3] += nearVel[i * 3] * dt;
        nearPos[i * 3 + 1] += nearVel[i * 3 + 1] * dt;
        nearPos[i * 3 + 2] += nearVel[i * 3 + 2] * dt;
        const dx = nearPos[i * 3], dy = nearPos[i * 3 + 1], dz = nearPos[i * 3 + 2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist > 180) { const f = -120 / dist; nearPos[i * 3] *= f; nearPos[i * 3 + 1] *= f; nearPos[i * 3 + 2] *= f; }
      }
      starNear.geometry.attributes.position.needsUpdate = true;
      // Nebula drift
      nebulae.forEach((n, i) => {
        n.position.x += nebulaVel[i].x * dt; n.position.y += nebulaVel[i].y * dt; n.position.z += nebulaVel[i].z * dt;
        const d = n.position.length();
        if (d > 420) { const f = -200 / d; n.position.multiplyScalar(f); }
      });
      // Cosmic background — distant drift
      cosmicField.update(t);

      // Black hole — accretion disk rotation, photon ring shimmer, lensing pulse
      accretionDisk.rotation.z += 0.004;
      photonRing.rotation.z += 0.002;
      photonChroma.rotation.z -= 0.003;
      lensRing.rotation.z += 0.001;
      bhGlow.material.opacity = 0.28 + Math.sin(t * 0.5) * 0.06;

      // Solar system orrery — Kepler-accurate orbital motion + atmosphere scattering
      solarSystem.update(t, camera);
      // New cosmic objects
      spiralGalaxy.update(t);
      pulsar.update(t);
      supernovaRemnant.update(t);
      // Cosmic phenomena — dark energy, dark matter, gravitational waves, pillar stars
      darkEnergy.update(t);
      darkMatter.update(t);
      gravWaves.update(t);
      pillarStars.update(t);
      foundingFathers.update(t);
      namedObjects.update(t);
      volNebulae.update(t);
      catalogStarfield.update(t);
      missionSats.update(t);
      cosmicDests.update(t);
      pillarNodes.update(t);
      expandedSolar.update(t);

      // EM field lines pulse (sped up + dimmed — non-interactive)
      fieldLines.forEach((fl, i) => {
        fl.mat.opacity = (fl.type === 'toroidal' ? 0.035 : 0.022) + Math.sin(t * 3.0 + i * 0.3) * 0.018;
      });
      for (let i = 0; i < emParticleCount; i++) {
        const ed = emData[i];
        if (ed.isToroidal) { ed.v += ed.vSpeed * 0.01; } else { ed.u += ed.uSpeed * 0.01; }
        const pos = torusPoint(ed.u, ed.v);
        emPositions[i * 3] = pos.x; emPositions[i * 3 + 1] = pos.y; emPositions[i * 3 + 2] = pos.z;
      }
      emGeo.attributes.position.needsUpdate = true;
      emMat.opacity = 0.2 + Math.sin(t * 2.4) * 0.08;

      // Plasma streams (sped up + dimmed — non-interactive visual)
      plasmaStreams.forEach((stream, i) => {
        const pulse = 0.05 + Math.sin(t * 3.0 + stream.offset) * 0.035 + Math.sin(t * 6 + stream.offset * 2) * 0.018;
        stream.material.opacity = Math.max(0.02, pulse);
        const hue = (t * 0.03 + i * 0.2) % 1;
        stream.material.color.setHSL(0.48 + Math.sin(hue * Math.PI * 2) * 0.12, 0.9, 0.55);
      });

      // Plasma particle cloud
      for (let i = 0; i < plasmaParticleCount; i++) {
        const pd = plasmaData[i];
        pd.u += pd.uSpeed * 0.008; pd.v += pd.vSpeed * 0.008;
        const pos = torusPoint(pd.u, pd.v);
        const breathe = 1 + Math.sin(t * 2 + pd.phase) * 0.03;
        plasmaPositions[i * 3] = pos.x * breathe; plasmaPositions[i * 3 + 1] = pos.y * breathe; plasmaPositions[i * 3 + 2] = pos.z * breathe;
      }
      plasmaGeo.attributes.position.needsUpdate = true;
      plasmaMat.opacity = 0.3 + Math.sin(t * 1.6) * 0.1;

      // Dimension rings (sped up — non-interactive visual)
      dimRings.forEach((dr) => {
        if (dr.axis === 0) dr.mesh.rotation.x += dr.speed * 3;
        else if (dr.axis === 1) dr.mesh.rotation.y += dr.speed * 3;
        else dr.mesh.rotation.z += dr.speed * 3;
      });
      dimParticles.forEach((p) => {
        p.userData.phase += p.userData.speed;
        const angle = p.userData.phase;
        const lx = Math.cos(angle) * p.userData.ringR;
        const ly = Math.sin(angle) * p.userData.ringR * 0.3;
        const lz = Math.sin(angle) * p.userData.ringR;
        p.position.set(lx, ly, lz);
        p.position.applyEuler(new THREE.Euler(p.userData.tiltX, p.userData.tiltY, p.userData.tiltZ));
        p.material.opacity = 0.4 + Math.sin(t * 2 + angle) * 0.3;
      });

      // Energy-orb nodes — layered pulse (slowed down — interactive)
      nodeState.forEach((nd) => {
        nd.currentU = nd.baseU + t * nd.uSpeed * 0.4;
        nd.currentV = nd.baseV + t * nd.vSpeed * 0.4;
        const pos = torusPoint(nd.currentU, nd.currentV);
        nd.mesh.position.copy(pos);
        nd.core.position.copy(pos);
        nd.corona.position.copy(pos);
        nd.glowSprite.position.copy(pos);
        const pulse = 1.0 + Math.sin(t * 2 + nd.mesh.userData.id) * 0.12;
        const base = nd.mesh.userData.baseSize;
        nd.mesh.scale.setScalar(pulse * base);
        nd.core.scale.setScalar(pulse * base * 0.45);
        nd.corona.scale.setScalar(pulse * base * 2.2);
        nd.glowSprite.scale.setScalar(pulse * base * 8);
        nd.core.material.opacity = 0.8 + Math.sin(t * 5 + nd.mesh.userData.id) * 0.15;
        nd.corona.material.opacity = 0.16 + Math.sin(t * 1.5 + nd.mesh.userData.id) * 0.06;

        nd.trailHistory.unshift(pos.clone());
        if (nd.trailHistory.length > TRAIL_LENGTH) nd.trailHistory.pop();
        for (let j = 0; j < TRAIL_LENGTH; j++) {
          const histPos = nd.trailHistory[j] || pos;
          nd.trailPositions[j * 3] = histPos.x; nd.trailPositions[j * 3 + 1] = histPos.y; nd.trailPositions[j * 3 + 2] = histPos.z;
          const fade = 1 - (j / TRAIL_LENGTH);
          nd.trailColors[j * 3] = nd.color.r * fade; nd.trailColors[j * 3 + 1] = nd.color.g * fade; nd.trailColors[j * 3 + 2] = nd.color.b * fade;
        }
        nd.trail.geometry.attributes.position.needsUpdate = true;
        nd.trail.geometry.attributes.color.needsUpdate = true;
      });
      // Node residual energy field — spawn at current node positions
      nodeEnergy.update(dt);

      // Geodesic connections
      connections.forEach((conn) => {
        const from = nodeState.find((n) => n.mesh.userData.id === conn.fromId);
        const to = nodeState.find((n) => n.mesh.userData.id === conn.toId);
        if (!from || !to) return;
        for (let i = 0; i < CONN_SEGMENTS; i++) {
          const tFrac = i / (CONN_SEGMENTS - 1);
          const u = lerpAngle(from.currentU, to.currentU, tFrac);
          const v = lerpAngle(from.currentV, to.currentV, tFrac);
          const bulge = Math.sin(tFrac * Math.PI) * 0.3;
          const pos = torusPoint(u, v);
          const outDir = new THREE.Vector3(pos.x, 0, pos.z).normalize().multiplyScalar(bulge);
          pos.add(outDir); pos.y += bulge * 0.5;
          conn.positions[i * 3] = pos.x; conn.positions[i * 3 + 1] = pos.y; conn.positions[i * 3 + 2] = pos.z;
        }
        conn.geo.attributes.position.needsUpdate = true;
        conn.line.material.opacity = 0.15 + Math.abs(Math.sin(t * 2 + conn.fromId)) * 0.25;
      });

      // Electric arcs
      electricArcs.forEach((arc) => {
        const from = nodeState.find((n) => n.mesh.userData.id === arc.fromId);
        const to = nodeState.find((n) => n.mesh.userData.id === arc.toId);
        if (!from || !to) return;
        arc.flickerTimer -= 0.016;
        if (arc.flickerTimer <= 0) { arc.active = Math.random() > 0.65; arc.flickerTimer = 0.04 + Math.random() * 0.15; }
        if (arc.active) {
          const fromPos = from.mesh.position, toPos = to.mesh.position;
          const direction = new THREE.Vector3().subVectors(toPos, fromPos);
          const perpendicular = new THREE.Vector3(-direction.y, direction.x, 0).normalize();
          if (perpendicular.lengthSq() < 0.01) perpendicular.set(0, 0, 1);
          for (let i = 0; i < arc.arcSegs; i++) {
            const tFrac = i / (arc.arcSegs - 1);
            const pos = new THREE.Vector3().lerpVectors(fromPos, toPos, tFrac);
            const jitter = (Math.random() - 0.5) * 0.6 * Math.sin(tFrac * Math.PI);
            pos.add(perpendicular.clone().multiplyScalar(jitter));
            pos.y += (Math.random() - 0.5) * 0.4 * Math.sin(tFrac * Math.PI);
            arc.positions[i * 3] = pos.x; arc.positions[i * 3 + 1] = pos.y; arc.positions[i * 3 + 2] = pos.z;
          }
          arc.geo.attributes.position.needsUpdate = true;
          arc.mat.opacity = 0.5 + Math.random() * 0.5;
          arc.mat.color.setHex(Math.random() > 0.5 ? 0x00f5ff : 0xffffff);
        } else { arc.mat.opacity = 0; }
      });

      // Flow particles
      flowParticles.forEach((particle) => {
        particle.userData.progress += particle.userData.speed;
        if (particle.userData.progress > 1) particle.userData.progress = 0;
        const conn = particle.userData.conn;
        const idx = Math.floor(particle.userData.progress * (CONN_SEGMENTS - 1));
        particle.position.set(conn.positions[idx * 3], conn.positions[idx * 3 + 1], conn.positions[idx * 3 + 2]);
        particle.material.opacity = 0.9 * Math.sin(particle.userData.progress * Math.PI);
      });

      // Central radion (slowed down — interactive)
      const radionPulse = 0.8 + Math.sin(t * 1.2) * 0.3;
      radion.scale.setScalar(radionPulse);
      radion.material.opacity = 0.3 + Math.sin(t * 1.2) * 0.15;
      radionGlow.scale.setScalar(radionPulse * 1.5);
      radionGlow.material.opacity = 0.05 + Math.sin(t * 1.2) * 0.04;

      // ── Camera: solar system dive state machine ──
      const currentViewMode = viewModeRef.current;
      if (currentViewMode !== lastViewMode) {
        const sunWorldPos = new THREE.Vector3();
        solarSystem.group.getWorldPosition(sunWorldPos);
        if (currentViewMode === 'solar-system') {
          diveTween = {
            fromPos: camera.position.clone(),
            toPos: sunWorldPos.clone().add(new THREE.Vector3(0, 4, 22)),
            fromTarget: currentTarget.clone(),
            toTarget: sunWorldPos.clone(),
            fromScale: solarSystem.group.scale.x,
            toScale: 7,
            progress: 0,
            duration: 1.5,
          };
        } else if (currentViewMode === 'planet-inspect' && inspectTargetRef.current) {
          const mesh = solarSystem.planets[inspectTargetRef.current];
          if (mesh) {
            const wp = new THREE.Vector3();
            mesh.getWorldPosition(wp);
            const pSize = mesh.userData.visualRadius || 0.5;
            diveTween = {
              fromPos: camera.position.clone(),
              toPos: wp.clone().add(new THREE.Vector3(0, pSize * 3, pSize * 8)),
              fromTarget: currentTarget.clone(),
              toTarget: wp.clone(),
              fromScale: solarSystem.group.scale.x,
              toScale: solarSystem.group.scale.x,
              progress: 0,
              duration: 1.5,
            };
          }
        } else {
          diveTween = {
            fromPos: camera.position.clone(),
            toPos: new THREE.Vector3(Math.sin(overviewAngle) * baseRadius * zoomRef.current * touchZoom, 8, Math.cos(overviewAngle) * baseRadius * zoomRef.current * touchZoom),
            fromTarget: currentTarget.clone(),
            toTarget: new THREE.Vector3(0, 0, 0),
            fromScale: solarSystem.group.scale.x,
            toScale: 2.5,
            progress: 0,
            duration: 1.5,
          };
        }
        lastViewMode = currentViewMode;
        lastInspectTarget = inspectTargetRef.current;
      }

      // ── Planet switch: dive to a new planet while already in planet-inspect mode ──
      if (currentViewMode === 'planet-inspect' && inspectTargetRef.current !== lastInspectTarget) {
        const mesh = solarSystem.planets[inspectTargetRef.current];
        if (mesh) {
          const wp = new THREE.Vector3();
          mesh.getWorldPosition(wp);
          const pSize = mesh.userData.visualRadius || 0.5;
          diveTween = {
            fromPos: camera.position.clone(),
            toPos: wp.clone().add(new THREE.Vector3(0, pSize * 3, pSize * 8)),
            fromTarget: currentTarget.clone(),
            toTarget: wp.clone(),
            fromScale: solarSystem.group.scale.x,
            toScale: solarSystem.group.scale.x,
            progress: 0,
            duration: 1.2,
          };
        }
        lastInspectTarget = inspectTargetRef.current;
      }

      if (diveTween) {
        diveTween.progress += dt / diveTween.duration;
        const p = Math.min(1, diveTween.progress);
        const eased = p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2;
        camera.position.lerpVectors(diveTween.fromPos, diveTween.toPos, eased);
        const target = new THREE.Vector3().lerpVectors(diveTween.fromTarget, diveTween.toTarget, eased);
        camera.lookAt(target);
        currentTarget.copy(target);
        solarSystem.group.scale.setScalar(diveTween.fromScale + (diveTween.toScale - diveTween.fromScale) * eased);
        if (p >= 1) {
          diveTween = null;
          // Sync spherical orbit state to the camera's landed position so mouse
          // orbit continues smoothly from where the dive tween ended.
          const offsetSync = new THREE.Vector3().subVectors(camera.position, currentTarget);
          const distSync = Math.max(0.001, offsetSync.length());
          orbitElT = orbitEl = Math.asin(Math.max(-1, Math.min(1, offsetSync.y / distSync)));
          orbitAzT = overviewAngle = Math.atan2(offsetSync.x, offsetSync.z);
        }
      } else if (viewModeRef.current === 'overview') {
        if (manualOrientationRef.current) {
          // ── Manual orientation: precise slider control of camera angle ──
          const az = manualOrientationRef.current.azimuth * Math.PI / 180;
          const el = Math.max(-80, Math.min(80, manualOrientationRef.current.elevation)) * Math.PI / 180;
          const dist = manualOrientationRef.current.distance || (baseRadius * zoomRef.current * touchZoom);
          const panX = manualOrientationRef.current.panX || 0;
          const panY = manualOrientationRef.current.panY || 0;
          camera.position.x = Math.sin(az) * Math.cos(el) * dist + panX;
          camera.position.y = Math.sin(el) * dist + panY;
          camera.position.z = Math.cos(az) * Math.cos(el) * dist;
          camera.lookAt(panX, panY, 0);
          currentTarget.set(panX, panY, 0);
        } else {
          // ── Spherical orbit: drag = orbit, wheel = zoom, right-drag = pan (damped) ──
          const damp = 1 - Math.exp(-dt * 9);
          overviewAngle = lerpAngle(overviewAngle, orbitAzT, damp);
          orbitEl += (orbitElT - orbitEl) * damp;
          orbitPan.lerp(orbitPanT, damp);
          if (!mouseActive && !pausedRef.current && !isTouchDragging) {
            orbitAzT += 0.03 * speedRef.current * dt / massRef.current;
          }
          const radius = baseRadius * zoomRef.current * touchZoom;
          const el = Math.max(-1.3, Math.min(1.3, orbitEl));
          const cosEl = Math.cos(el);
          camera.position.x = Math.sin(overviewAngle) * cosEl * radius + orbitPan.x;
          camera.position.y = Math.sin(el) * radius + orbitPan.y;
          camera.position.z = Math.cos(overviewAngle) * cosEl * radius + orbitPan.z;
          camera.lookAt(orbitPan.x, orbitPan.y, orbitPan.z);
          currentTarget.set(orbitPan.x, orbitPan.y, orbitPan.z);
        }
      } else if (viewModeRef.current === 'planet-inspect' && inspectTargetRef.current) {
        const mesh = solarSystem.planets[inspectTargetRef.current];
        if (mesh) {
          const wp = new THREE.Vector3();
          mesh.getWorldPosition(wp);
          const pSize = mesh.userData.visualRadius || 0.5;
          const damp = 1 - Math.exp(-dt * 9);
          overviewAngle = lerpAngle(overviewAngle, orbitAzT, damp);
          orbitEl += (orbitElT - orbitEl) * damp;
          orbitPan.lerp(orbitPanT, damp);
          if (!mouseActive && !pausedRef.current && !isTouchDragging) {
            orbitAzT += 0.01 * speedRef.current * dt / massRef.current;
          }
          const inspectDist = Math.max(pSize * 6, 2) * zoomRef.current * touchZoom;
          const el = Math.max(-1.3, Math.min(1.3, orbitEl));
          const cosEl = Math.cos(el);
          const tx = wp.x + orbitPan.x, ty = wp.y + orbitPan.y, tz = wp.z + orbitPan.z;
          camera.position.x = tx + Math.sin(overviewAngle) * cosEl * inspectDist;
          camera.position.y = ty + Math.sin(el) * inspectDist;
          camera.position.z = tz + Math.cos(overviewAngle) * cosEl * inspectDist;
          camera.lookAt(tx, ty, tz);
          currentTarget.set(tx, ty, tz);
        }
      } else {
        // Solar system mode — spherical orbit around the sun
        const damp = 1 - Math.exp(-dt * 9);
        overviewAngle = lerpAngle(overviewAngle, orbitAzT, damp);
        orbitEl += (orbitElT - orbitEl) * damp;
        orbitPan.lerp(orbitPanT, damp);
        if (!mouseActive && !pausedRef.current && !isTouchDragging) {
          orbitAzT += 0.008 * speedRef.current * dt / massRef.current;
        }
        const sunWorldPos = new THREE.Vector3();
        solarSystem.group.getWorldPosition(sunWorldPos);
        const driftRadius = 24 * zoomRef.current * touchZoom;
        const el = Math.max(-1.3, Math.min(1.3, orbitEl));
        const cosEl = Math.cos(el);
        const tx = sunWorldPos.x + orbitPan.x, ty = sunWorldPos.y + orbitPan.y, tz = sunWorldPos.z + orbitPan.z;
        camera.position.x = tx + Math.sin(overviewAngle) * cosEl * driftRadius;
        camera.position.y = ty + Math.sin(el) * driftRadius;
        camera.position.z = tz + Math.cos(overviewAngle) * cosEl * driftRadius;
        camera.lookAt(tx, ty, tz);
        currentTarget.set(tx, ty, tz);
      }

      // ── Element filter: toggle visibility of object categories ──
      const filter = elementFilterRef.current;
      if (volNebulae.group) volNebulae.group.visible = filter.nebulae !== false;
      if (missionSats.group) missionSats.group.visible = filter.missions !== false;
      if (cosmicDests.group) cosmicDests.group.visible = filter.celestial !== false;
      if (pillarNodes.group) pillarNodes.group.visible = filter.pillars !== false;
      if (solarSystem.group) solarSystem.group.visible = filter.solarSystem !== false;
      // Celestial objects (named objects, cosmic field, etc.) — toggle as a group
      if (namedObjects.group) namedObjects.group.visible = filter.celestial !== false;
      if (cosmicField.group) cosmicField.group.visible = filter.celestial !== false;
      if (spiralGalaxy.group) spiralGalaxy.group.visible = filter.celestial !== false;
      if (pulsar.group) pulsar.group.visible = filter.celestial !== false;
      if (supernovaRemnant.group) supernovaRemnant.group.visible = filter.celestial !== false;
      if (catalogStarfield.group) catalogStarfield.group.visible = filter.celestial !== false;

      // ── Cinematic pass time update ──
      if (cinematicPass && cinematicPass.uniforms) {
        cinematicPass.uniforms.uTime.value = t;
      }

      // ── Orientation update callback ──
      if (orientationRef.current) {
        const camDir = new THREE.Vector3();
        camera.getWorldDirection(camDir);
        const azimuth = (Math.atan2(camDir.x, camDir.z) * 180 / Math.PI + 360) % 360;
        const elevation = Math.asin(camDir.y) * 180 / Math.PI;
        const distance = camera.position.length();
        orientationRef.current({ azimuth, elevation, distance, viewMode: viewModeRef.current });
      }

      raycaster.setFromCamera(mouse, camera);
      const hits = raycaster.intersectObjects(interactiveObjects, false);
      if (hits.length > 0) {
        const hit0 = hits[0];
        const obj = hit0.object;
        const ud = obj.userData;
        // Instanced catalog starfield — resolve exact star, track by star id
        if (ud.isInstanced && hit0.instanceId != null) {
          const starData = catalogStarfield.resolveStar?.(hit0.instanceId);
          if (starData) {
            if (hoveredNode) {
              if (hoveredNode.userData.groupId) highlightGroup(hoveredNode.userData.groupId, false);
              else highlightObject(hoveredNode, false);
              hoveredNode = null;
            }
            hoveredStarActive = true;
            container.style.cursor = 'pointer';
            if (lastStarKey !== starData.id) {
              lastStarKey = starData.id;
              hoverRef.current?.(starData);
            }
          }
        } else if (hoveredNode !== obj) {
          if (hoveredNode) {
            if (hoveredNode.userData.groupId) highlightGroup(hoveredNode.userData.groupId, false);
            else highlightObject(hoveredNode, false);
          }
          // Group members: subtle highlight on the whole group, strong on the hovered member — clear separation
          if (obj.userData.groupId) {
            highlightGroup(obj.userData.groupId, 'subtle');
            if (!obj.userData.noHighlight) highlightObject(obj, 'strong');
          } else if (!obj.userData.noHighlight) {
            highlightObject(obj, 'strong');
          }
          hoveredNode = obj;
          hoveredStarActive = false;
          lastStarKey = null;
          container.style.cursor = 'pointer';
          hoverRef.current?.(obj.userData);
        }
      } else {
        // No interactive object hit — check catalog stars first, then starfield for spectral-class hover
        // (skip when mouse is off-screen to avoid false hits on mouseleave)
        const mouseOffscreen = Math.abs(mouse.x) > 1.5 || Math.abs(mouse.y) > 1.5;
        if (mouseOffscreen) {
          if (hoveredNode) {
            if (hoveredNode.userData.groupId) highlightGroup(hoveredNode.userData.groupId, false);
            else highlightObject(hoveredNode, false);
            hoveredNode = null;
          }
          if (hoveredStarActive) {
            hoveredStarActive = false;
            lastStarKey = null;
            container.style.cursor = 'default';
            hoverRef.current?.(null);
          }
        } else {
          // Check catalog stars first (individual star data)
          const catStar = raycastCatalogStar();
          if (catStar) {
            if (hoveredNode) {
              if (hoveredNode.userData.groupId) highlightGroup(hoveredNode.userData.groupId, false);
              else highlightObject(hoveredNode, false);
              hoveredNode = null;
            }
            hoveredStarActive = true;
            container.style.cursor = 'pointer';
            if (lastStarKey !== catStar.id) {
              lastStarKey = catStar.id;
              hoverRef.current?.(catStar);
            }
          } else {
            // Fall back to spectral-class starfield hover
            const starHit = raycastStarfield();
            if (starHit) {
          if (hoveredNode) {
            if (hoveredNode.userData.groupId) highlightGroup(hoveredNode.userData.groupId, false);
            else highlightObject(hoveredNode, false);
            hoveredNode = null;
          }
          hoveredStarActive = true;
          container.style.cursor = 'pointer';
          if (lastStarKey !== starHit.classIndex) {
            lastStarKey = starHit.classIndex;
            hoverRef.current?.(spectralClassUserData(starHit.classIndex));
          }
        } else {
          if (hoveredNode) {
            if (hoveredNode.userData.groupId) highlightGroup(hoveredNode.userData.groupId, false);
            else highlightObject(hoveredNode, false);
            hoveredNode = null;
          }
          if (hoveredStarActive) {
            hoveredStarActive = false;
            lastStarKey = null;
            container.style.cursor = 'default';
            hoverRef.current?.(null);
          }
        }
        }
      }
      }

      composer.render();
    };
    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('mouseleave', handleMouseLeave);
      container.removeEventListener('click', handleClick);
      container.removeEventListener('touchstart', handleTouchStart);
      container.removeEventListener('touchmove', handleTouchMove);
      container.removeEventListener('touchend', handleTouchEnd);
      container.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('mousemove', handleMouseDrag);
      container.removeEventListener('wheel', handleWheel);
      container.removeEventListener('contextmenu', handleContextMenu);
      glowTex.dispose();
      sphereGeo.dispose(); flowParticleGeo.dispose(); dimParticleGeo.dispose(); radionGeo.dispose(); radionGlowGeo.dispose();
      ehGeo.dispose(); photonRingGeo.dispose(); photonChromaGeo.dispose(); diskGeo.dispose(); lensGeo.dispose();
      [starFar, starMid, starNear].forEach((s) => { s.geometry.dispose(); s.material.dispose(); });
      nebulae.forEach((n) => n.material.dispose());
      ehMat.dispose(); photonRingMat.dispose(); photonChromaMat.dispose(); diskMat.dispose(); lensMat.dispose(); bhGlowMat.dispose();
      solarSystem.dispose();
      spiralGalaxy.dispose();
      pulsar.dispose();
      supernovaRemnant.dispose();
      darkEnergy.dispose();
      darkMatter.dispose();
      gravWaves.dispose();
      pillarStars.dispose();
      nodeEnergy.dispose();
      cosmicField.dispose();
      fieldLines.forEach((fl) => fl.mat.dispose());
      emProxyGeo.dispose(); emProxyMat.dispose();
      emGeo.dispose(); emMat.dispose();
      plasmaGeo.dispose(); plasmaMat.dispose();
      plasmaStreams.forEach((s) => s.material.dispose());
      nodes.forEach((n) => n.material.dispose());
      nodeState.forEach((nd) => { nd.core.material.dispose(); nd.corona.material.dispose(); nd.glowSprite.material.dispose(); nd.trail.geometry.dispose(); nd.trail.material.dispose(); });
      connections.forEach((c) => { c.geo.dispose(); c.line.material.dispose(); });
      foundingFathers.dispose();
      namedObjects.dispose();
      volNebulae.dispose();
      catalogStarfield.dispose();
      missionSats.dispose();
      cosmicDests.dispose();
      pillarNodes.dispose();
      expandedSolar.dispose();
      electricArcs.forEach((a) => { a.geo.dispose(); a.mat.dispose(); });
      flowParticles.forEach((p) => p.material.dispose());
      dimRings.forEach((dr) => { dr.mesh.geometry.dispose(); dr.mesh.material.dispose(); });
      dimParticles.forEach((p) => p.material.dispose());
      radionMat.dispose(); radionGlowMat.dispose();
      composer.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement);
    };
  }, [dimensions]);

  return <div ref={containerRef} className="w-full h-full" />;
}