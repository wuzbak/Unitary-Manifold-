import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { X, ExternalLink } from 'lucide-react';

/**
 * MobileCosmicInfoCard — mobile bottom-sheet variant of CosmicInfoCard.
 * Full-width, large readable type, scrollable, swipe-down or X to dismiss.
 * Same element data shape as the desktop card. lg:hidden — desktop card untouched.
 */
export default function MobileCosmicInfoCard({ element, onClose }) {
  const startY = useRef(null);

  useEffect(() => {
    const handleEsc = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  if (!element) return null;

  const onTouchStart = (e) => { startY.current = e.touches[0].clientY; };
  const onTouchMove = (e) => {
    if (startY.current == null) return;
    if (e.touches[0].clientY - startY.current > 90) { onClose(); startY.current = null; }
  };

  return (
    <>
      <div className="lg:hidden fixed inset-0 z-[160] bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div
        className="lg:hidden fixed bottom-0 left-0 right-0 z-[170] max-h-[82vh] overflow-y-auto clip-corner bg-[#0a0a12]/97 backdrop-blur-xl border-t-2 border-[#FF9F00]/30 fade-in"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
      >
        <div className="flex justify-center pt-2.5 pb-1 shrink-0"><div className="w-10 h-1 rounded-full bg-[#00f5ff]/30" /></div>
        <div className="sticky top-0 flex items-center justify-between px-4 py-3 bg-[#0a0a12]/95 backdrop-blur-xl border-b border-[#FF9F00]/15 z-10">
          <div className="flex-1 min-w-0">
            <div className="text-[#4DD0E1] text-[10px] uppercase tracking-wider mb-0.5">▸ {element.type}</div>
            <div className="text-white font-bold text-base">{element.name}</div>
          </div>
          <button onClick={onClose} className="text-[#8b949e] active:text-[#FF9F00] ml-2 shrink-0 p-2" aria-label="Close">
            <X size={22} />
          </button>
        </div>

        <div className="px-4 py-3 pb-8 space-y-3">
          <p className="text-[#e6edf3] text-sm leading-relaxed">{element.description}</p>

          {element._isStarfield && (
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              {element._spectralType && <Field label="Spectral Class" value={element._spectralType} accent="#FF9F00" />}
              {element._temperature && <Field label="Temperature" value={element._temperature} />}
              {element._mass && <Field label="Mass" value={element._mass} />}
              {element._lifetime && <Field label="Lifetime" value={element._lifetime} />}
            </div>
          )}

          {element._cosmicMeta?.length > 0 && (
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              {element._cosmicMeta.map((m, i) => (
                <div key={i} className="flex justify-between border-b border-[#4DD0E1]/10 pb-1">
                  <span className="text-[#8b949e]">{m.label}</span>
                  <span className="text-[#4DD0E1] font-bold">{m.value}</span>
                </div>
              ))}
            </div>
          )}

          {element._missionStatus && (
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="flex justify-between border-b border-[#FF9F00]/10 pb-1">
                <span className="text-[#8b949e]">Status</span>
                <span className={`font-bold ${element._missionStatus === 'Active' ? 'text-[#3fb950]' : 'text-[#FF9F00]'}`}>{element._missionStatus}</span>
              </div>
              <div className="flex justify-between border-b border-[#FF9F00]/10 pb-1">
                <span className="text-[#8b949e]">Agency</span>
                <span className="text-[#00f5ff] font-bold">{element._missionAgency}</span>
              </div>
              <div className="col-span-2 flex justify-between border-b border-[#FF9F00]/10 pb-1">
                <span className="text-[#8b949e]">Launch</span>
                <span className="text-[#00f5ff] font-bold">{element._missionLaunch}</span>
              </div>
            </div>
          )}

          {element._pillarFormula && (
            <div className="text-[11px]">
              <div className="border-b border-[#00f5ff]/10 pb-1 mb-1">
                <span className="text-[#8b949e]">Formula: </span>
                <span className="text-[#00f5ff] font-mono font-bold">{element._pillarFormula}</span>
              </div>
              <div className="flex justify-between border-b border-[#00f5ff]/10 pb-1">
                <span className="text-[#8b949e]">Pillar Status</span>
                <span className={`font-bold ${element._pillarStatus === 'HARDGATE' ? 'text-[#FF9F00]' : element._pillarStatus === 'CERTIFIED' ? 'text-[#3fb950]' : 'text-[#4DD0E1]'}`}>{element._pillarStatus}</span>
              </div>
            </div>
          )}

          {element.significance && (
            <div>
              <div className="text-[#FF9F00] text-[10px] uppercase tracking-wider mb-1">▸ Physics Significance</div>
              <p className="text-[#8fa0bc] text-[12px] leading-relaxed">{element.significance}</p>
            </div>
          )}

          {element.links?.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {element.links.map((link, i) => (
                link.href ? (
                  <a key={i} href={link.href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 px-3 py-2 text-[11px] font-bold bg-[#FF9F00]/10 border border-[#FF9F00]/30 text-[#FF9F00] active:bg-[#FF9F00]/20">
                    {link.label} <ExternalLink size={11} />
                  </a>
                ) : (
                  <Link key={i} to={link.path} className="flex items-center gap-1.5 px-3 py-2 text-[11px] font-bold bg-[#FF9F00]/10 border border-[#FF9F00]/30 text-[#FF9F00] active:bg-[#FF9F00]/20">
                    {link.label} <ExternalLink size={11} />
                  </Link>
                )
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

function Field({ label, value, accent = '#00f5ff' }) {
  return (
    <div className="flex justify-between border-b border-[#00f5ff]/10 pb-1">
      <span className="text-[#8b949e]">{label}</span>
      <span className="font-bold" style={{ color: accent }}>{value}</span>
    </div>
  );
}