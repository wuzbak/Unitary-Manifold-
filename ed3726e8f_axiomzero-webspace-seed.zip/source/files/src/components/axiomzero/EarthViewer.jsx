import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { X, Globe, RotateCw, ZoomIn, MapPin } from 'lucide-react';
import { makeEarthTexture, makeEarthCloudTexture, makeMoonTexture } from '@/lib/topology/planetTextures';

/**
 * EarthViewer — full-screen Google Earth-like Earth visualization.
 * Ultra-HD 4096×2048 procedural Earth with geographic detail (mountains, rivers, lakes, forests).
 * Momentum drag, eased zoom, clickable Duvall WA marker linking to corporate page.
 */
export default function EarthViewer({ onClose }) {
  const navigate = useNavigate();
  const containerRef = useRef(null);
  const labelRef = useRef(null);
  const [rotating, setRotating] = useState(true);
  const [info, setInfo] = useState(true);
  const [fadeReady, setFadeReady] = useState(false);
  const [markerVisible, setMarkerVisible] = useState(false);
  const markerVisibleRef = useRef(false);
  const rotatingRef = useRef(true);
  useEffect(() => { rotatingRef.current = rotating; }, [rotating]);
  useEffect(() => { const t = setTimeout(() => setFadeReady(true), 60); return () => clearTimeout(t); }, []);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x030308);

    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.01, 1000);
    camera.position.set(0, 0, 8);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    container.appendChild(renderer.domElement);

    // Bloom
    const composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));
    const bloom = new UnrealBloomPass(new THREE.Vector2(container.clientWidth, container.clientHeight), 0.3, 0.3, 0.8);
    composer.addPass(bloom);
    composer.addPass(new OutputPass());

    // Lighting
    scene.add(new THREE.AmbientLight(0x334455, 0.4));
    const sunLight = new THREE.DirectionalLight(0xfff5e6, 2.5);
    sunLight.position.set(10, 3, 5);
    scene.add(sunLight);

    // Starfield
    const starGeo = new THREE.BufferGeometry();
    const starCount = 5000;
    const starPos = new Float32Array(starCount * 3);
    const starCol = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const r = 200 + Math.random() * 300;
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      starPos[i * 3] = r * Math.sin(ph) * Math.cos(th);
      starPos[i * 3 + 1] = r * Math.sin(ph) * Math.sin(th);
      starPos[i * 3 + 2] = r * Math.cos(ph);
      const b = 0.5 + Math.random() * 0.5;
      starCol[i * 3] = b; starCol[i * 3 + 1] = b; starCol[i * 3 + 2] = b * (0.8 + Math.random() * 0.2);
    }
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    starGeo.setAttribute('color', new THREE.BufferAttribute(starCol, 3));
    const starMat = new THREE.PointsMaterial({ size: 0.8, vertexColors: true, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false });
    scene.add(new THREE.Points(starGeo, starMat));

    // ── Earth — 128 segments initially, LOD upgrade to 256 after mount ──
    const earthTex = makeEarthTexture();
    const earthGeo = new THREE.SphereGeometry(2, 128, 128);
    const earthMat = new THREE.MeshPhongMaterial({ map: earthTex, shininess: 8, specular: 0x222233 });
    const earth = new THREE.Mesh(earthGeo, earthMat);
    earth.rotation.z = 23.44 * Math.PI / 180;
    scene.add(earth);

    // Clouds
    const cloudTex = makeEarthCloudTexture();
    const cloudGeo = new THREE.SphereGeometry(2.04, 96, 96);
    const cloudMat = new THREE.MeshPhongMaterial({ map: cloudTex, transparent: true, opacity: 0.45, blending: THREE.AdditiveBlending, depthWrite: false });
    const clouds = new THREE.Mesh(cloudGeo, cloudMat);
    clouds.rotation.z = 23.44 * Math.PI / 180;
    scene.add(clouds);

    // Atmosphere glow (fresnel shader)
    const atmGeo = new THREE.SphereGeometry(2.15, 96, 96);
    const atmMat = new THREE.ShaderMaterial({
      uniforms: { glowColor: { value: new THREE.Color(0x4488ff) } },
      vertexShader: `varying vec3 vNormal; void main() { vNormal = normalize(normalMatrix * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `varying vec3 vNormal; uniform vec3 glowColor; void main() { float intensity = pow(0.65 - dot(vNormal, vec3(0,0,1.0)), 2.0); gl_FragColor = vec4(glowColor, 1.0) * intensity; }`,
      blending: THREE.AdditiveBlending, side: THREE.BackSide, transparent: true, depthWrite: false,
    });
    scene.add(new THREE.Mesh(atmGeo, atmMat));

    // ── Duvall, WA marker — clickable link to corporate page ──
    // Duvall, WA: 47.74°N, 121.99°W
    const DUVALL_LAT = 47.74, DUVALL_LON = -121.99;
    const u = (DUVALL_LON + 180) / 360;
    const v = (90 - DUVALL_LAT) / 180;
    const theta = u * 2 * Math.PI;
    const phi = v * Math.PI;
    const markerR = 2.01; // slightly above surface
    const markerPos = new THREE.Vector3(
      -markerR * Math.cos(theta) * Math.sin(phi),
      markerR * Math.cos(phi),
      markerR * Math.sin(theta) * Math.sin(phi)
    );
    const outDir = markerPos.clone().normalize();

    const markerGroup = new THREE.Group();

    // Pin sphere (raycast target)
    const pinGeo = new THREE.SphereGeometry(0.03, 16, 16);
    const pinMat = new THREE.MeshBasicMaterial({ color: 0xFF9F00, transparent: true, opacity: 0.95 });
    const pin = new THREE.Mesh(pinGeo, pinMat);
    pin.position.copy(markerPos);
    markerGroup.add(pin);

    // Vertical beam
    const beamGeo = new THREE.CylinderGeometry(0.004, 0.004, 0.12, 8);
    const beamMat = new THREE.MeshBasicMaterial({ color: 0xFF9F00, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending });
    const beam = new THREE.Mesh(beamGeo, beamMat);
    beam.position.copy(markerPos).add(outDir.clone().multiplyScalar(0.06));
    beam.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), outDir);
    markerGroup.add(beam);

    // Pulsing ring on surface
    const ringGeo = new THREE.RingGeometry(0.035, 0.06, 32);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xFF9F00, transparent: true, opacity: 0.5, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.copy(markerPos);
    ring.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), outDir);
    markerGroup.add(ring);

    // Glow sprite
    const markerGlowMat = new THREE.SpriteMaterial({ color: 0xFF9F00, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending, depthWrite: false });
    const markerGlow = new THREE.Sprite(markerGlowMat);
    markerGlow.position.copy(markerPos);
    markerGlow.scale.setScalar(0.12);
    markerGroup.add(markerGlow);

    earth.add(markerGroup);

    // Moon
    const moonTex = makeMoonTexture();
    const moonGeo = new THREE.SphereGeometry(0.27, 64, 64);
    const moonMat = new THREE.MeshPhongMaterial({ map: moonTex, shininess: 2 });
    const moon = new THREE.Mesh(moonGeo, moonMat);
    moon.position.set(6, 1, -3);
    scene.add(moon);

    // ── Camera controls: momentum drag + eased zoom (Google Earth-like) ──
    let isDragging = false, prevX = 0, prevY = 0;
    let earthRotY = 0, earthRotX = 0;
    let velX = 0, velY = 0;
    let targetCamDist = 8;
    let camDist = 8;

    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2(-9999, -9999);
    let hoveringMarker = false;

    const updateMouse = (e) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    };

    const onMouseDown = (e) => {
      isDragging = true; prevX = e.clientX; prevY = e.clientY;
      velX = 0; velY = 0;
    };
    const onMouseUp = () => { isDragging = false; };
    const onMouseMove = (e) => {
      updateMouse(e);
      if (isDragging) {
        velY = (e.clientX - prevX) * 0.006;
        velX = (e.clientY - prevY) * 0.006;
        prevX = e.clientX; prevY = e.clientY;
      }
    };
    const onWheel = (e) => {
      e.preventDefault();
      const zoomFactor = e.deltaY > 0 ? 1.12 : 0.89;
      targetCamDist = Math.max(2.2, Math.min(15, targetCamDist * zoomFactor));
    };
    const onClick = (e) => {
      updateMouse(e);
      raycaster.setFromCamera(mouse, camera);
      const hits = raycaster.intersectObject(pin, false);
      if (hits.length > 0) navigate('/corporate');
    };

    container.addEventListener('mousedown', onMouseDown);
    container.addEventListener('mouseup', onMouseUp);
    container.addEventListener('mousemove', onMouseMove);
    container.addEventListener('click', onClick);
    container.addEventListener('wheel', onWheel, { passive: false });

    const onResize = () => {
      if (!container.clientWidth) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
      composer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', onResize);

    // LOD upgrade — swap to HD geometry after 3 frames
    let frameCount = 0;
    let hdUpgraded = false;
    let hdEarthGeo = null;
    let hdCloudGeo = null;

    let animId;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      const t = performance.now() * 0.001;

      // Eased zoom — smooth lerp toward target
      camDist += (targetCamDist - camDist) * 0.12;

      // Momentum drag — velocity decays when not dragging
      if (!isDragging) {
        velX *= 0.93;
        velY *= 0.93;
      }
      earthRotY += velY;
      earthRotX += velX;
      earthRotX = Math.max(-1.2, Math.min(1.2, earthRotX));

      // Auto-rotate when idle
      if (rotatingRef.current && !isDragging && Math.abs(velX) < 0.0008 && Math.abs(velY) < 0.0008) {
        velY += 0.0006;
      }

      earth.rotation.y = earthRotY;
      earth.rotation.x = earthRotX;
      clouds.rotation.y = earthRotY * 1.15;
      clouds.rotation.x = earthRotX;
      moon.position.x = Math.cos(t * 0.05) * 6;
      moon.position.z = Math.sin(t * 0.05) * 6;
      moon.rotation.y += 0.002;
      camera.position.z = camDist;
      camera.lookAt(0, 0, 0);
      composer.render();

      // Marker pulse
      const pulse = 1 + Math.sin(t * 3) * 0.25;
      ring.scale.setScalar(pulse);
      ring.material.opacity = 0.25 + Math.sin(t * 3) * 0.2;
      markerGlow.material.opacity = 0.3 + Math.sin(t * 2) * 0.15;

      // Marker hover detection
      raycaster.setFromCamera(mouse, camera);
      const markerHits = raycaster.intersectObject(pin, false);
      const nowHovering = markerHits.length > 0;
      if (nowHovering !== hoveringMarker) {
        hoveringMarker = nowHovering;
        container.style.cursor = nowHovering ? 'pointer' : (isDragging ? 'grabbing' : 'grab');
      }

      // Project marker to screen for HTML label
      const markerWorld = new THREE.Vector3();
      pin.getWorldPosition(markerWorld);
      const screenPos = markerWorld.clone().project(camera);
      const onNearSide = screenPos.z < 1 && markerWorld.dot(
        new THREE.Vector3().subVectors(camera.position, new THREE.Vector3(0, 0, 0)).normalize()
      ) > 0;
      const labelEl = labelRef.current;
      if (labelEl) {
        if (onNearSide) {
          const x = (screenPos.x + 1) / 2 * container.clientWidth;
          const y = (-screenPos.y + 1) / 2 * container.clientHeight;
          labelEl.style.transform = `translate(-50%, -100%) translate(${x}px, ${y}px)`;
          labelEl.style.opacity = '1';
          if (!markerVisibleRef.current) { markerVisibleRef.current = true; setMarkerVisible(true); }
        } else {
          labelEl.style.opacity = '0';
          if (markerVisibleRef.current) { markerVisibleRef.current = false; setMarkerVisible(false); }
        }
      }

      // Upgrade to HD geometry after initial frames
      frameCount++;
      if (!hdUpgraded && frameCount >= 3) {
        hdUpgraded = true;
        hdEarthGeo = new THREE.SphereGeometry(2, 256, 256);
        hdCloudGeo = new THREE.SphereGeometry(2.04, 128, 128);
        const oldEarthGeo = earth.geometry;
        const oldCloudGeo = clouds.geometry;
        earth.geometry = hdEarthGeo;
        clouds.geometry = hdCloudGeo;
        oldEarthGeo.dispose();
        oldCloudGeo.dispose();
      }
    };
    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', onResize);
      container.removeEventListener('mousedown', onMouseDown);
      container.removeEventListener('mouseup', onMouseUp);
      container.removeEventListener('mousemove', onMouseMove);
      container.removeEventListener('click', onClick);
      container.removeEventListener('wheel', onWheel);
      earthTex.dispose(); earthGeo.dispose(); earthMat.dispose();
      cloudTex.dispose(); cloudGeo.dispose(); cloudMat.dispose();
      atmGeo.dispose(); atmMat.dispose();
      if (hdEarthGeo) hdEarthGeo.dispose();
      if (hdCloudGeo) hdCloudGeo.dispose();
      pinGeo.dispose(); pinMat.dispose();
      beamGeo.dispose(); beamMat.dispose();
      ringGeo.dispose(); ringMat.dispose();
      markerGlowMat.dispose();
      moonTex.dispose(); moonGeo.dispose(); moonMat.dispose();
      starGeo.dispose(); starMat.dispose();
      composer.dispose(); renderer.dispose();
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[300] bg-[#030308] transition-opacity duration-700" style={{ opacity: fadeReady ? 1 : 0 }}>
      <div ref={containerRef} className="absolute inset-0 cursor-grab active:cursor-grabbing" />

      {/* Duvall WA marker label — follows the 3D pin, clickable */}
      {markerVisible && (
        <div
          ref={labelRef}
          className="absolute top-0 left-0 z-20 pointer-events-auto cursor-pointer transition-opacity duration-200"
          onClick={() => navigate('/corporate')}
          style={{ opacity: 0 }}
        >
          <div className="flex flex-col items-center">
            <div className="px-2.5 py-1.5 rounded-md border border-[#FF9F00]/50 bg-[#0a0a12]/95 backdrop-blur-md shadow-lg shadow-[#FF9F00]/10 whitespace-nowrap">
              <div className="flex items-center gap-1.5">
                <MapPin size={10} className="text-[#FF9F00]" />
                <span className="text-[#FF9F00] text-[10px] font-bold tracking-wider">AXIOMZERO SPC</span>
              </div>
              <div className="text-[#8b949e] text-[7px] tracking-wider mt-0.5">Duvall, WA · Click to visit →</div>
            </div>
            <div className="w-px h-3 bg-[#FF9F00]/40" />
          </div>
        </div>
      )}

      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 flex items-center justify-between p-4 z-10 pointer-events-none">
        <div className="pointer-events-auto">
          <div className="flex items-center gap-2 px-3 py-2 rounded-md border border-[#4DD0E1]/30 bg-[#0a0a12]/85 backdrop-blur-md">
            <Globe size={16} className="text-[#4DD0E1]" />
            <div>
              <div className="text-[#4DD0E1] text-sm font-bold tracking-wider">EARTH · TERRA</div>
              <div className="text-[#8b949e] text-[9px] tracking-wider">Ultra-HD Geographic Inspection · 4096×2048</div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={() => setRotating(r => !r)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-md border backdrop-blur-md text-xs font-bold tracking-wider transition-colors ${rotating ? 'border-[#4DD0E1]/40 bg-[#4DD0E1]/10 text-[#4DD0E1]' : 'border-[#30363d] bg-[#0a0a12]/85 text-[#8b949e]'}`}
          >
            <RotateCw size={14} /> {rotating ? 'Auto-Rotate ON' : 'Auto-Rotate OFF'}
          </button>
          <button
            onClick={() => setInfo(i => !i)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-md border backdrop-blur-md text-xs font-bold tracking-wider transition-colors ${info ? 'border-[#4DD0E1]/40 bg-[#4DD0E1]/10 text-[#4DD0E1]' : 'border-[#30363d] bg-[#0a0a12]/85 text-[#8b949e]'}`}
          >
            <ZoomIn size={14} /> Info
          </button>
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-2 rounded-md border border-[#FF9F00]/40 bg-[#0a0a12]/85 backdrop-blur-md text-[#FF9F00] text-xs font-bold tracking-wider hover:bg-[#FF9F00]/10 transition-colors"
          >
            <X size={14} /> Exit Earth View
          </button>
        </div>
      </div>

      {/* Info panel */}
      {info && (
        <div className="absolute top-20 left-4 max-w-[280px] p-4 rounded-lg border border-[#4DD0E1]/20 bg-[#0a0a12]/85 backdrop-blur-md text-[10px] leading-relaxed pointer-events-auto">
          <div className="text-[#4DD0E1] font-bold text-xs uppercase tracking-wider mb-2">▸ Planetary Profile</div>
          <div className="space-y-1 text-[#8fa0bc]">
            <div>Radius: <span className="text-[#4DD0E1]">6,371 km</span></div>
            <div>Mass: <span className="text-[#4DD0E1]">5.972 × 10²⁴ kg</span></div>
            <div>Density: <span className="text-[#4DD0E1]">5.514 g/cm³</span></div>
            <div>Gravity: <span className="text-[#4DD0E1]">9.807 m/s²</span></div>
            <div>Axial Tilt: <span className="text-[#4DD0E1]">23.44°</span></div>
            <div>Rotation: <span className="text-[#4DD0E1]">23.93 hours</span></div>
            <div>Orbit: <span className="text-[#4DD0E1]">365.25 days (1 AU)</span></div>
            <div>Atmosphere: <span className="text-[#4DD0E1]">78% N₂, 21% O₂</span></div>
            <div>Surface Temp: <span className="text-[#4DD0E1]">-89°C to 58°C</span></div>
            <div>Moon: <span className="text-[#4DD0E1]">1 (Luna)</span></div>
          </div>
          <hr className="border-[#30363d] my-2" />
          <div className="text-[#FF9F00] text-[9px] font-bold mb-1">▸ Headquarters Marker</div>
          <div className="text-[#8b949e] text-[9px]">A glowing pin at Duvall, WA (47.74°N, 121.99°W) marks the home of AxiomZero Technologies & Consulting, SPC. Click the pin to visit the corporate page.</div>
          <hr className="border-[#30363d] my-2" />
          <div className="text-[#8b949e] text-[9px]">Geographic detail only — mountains, rivers, lakes, forests, deserts, ice caps. No cities or roads.</div>
          <div className="text-[#484f58] text-[8px] mt-2">▸ Drag to rotate · Scroll to zoom · Click pin to navigate</div>
        </div>
      )}

      {/* Hint */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-[#484f58] text-[9px] tracking-wider pointer-events-none">
        DRAG TO ROTATE · SCROLL TO ZOOM · CLICK 📍 PIN FOR CORPORATE · {rotating ? 'AUTO-ROTATING' : 'MANUAL CONTROL'}
      </div>
    </div>
  );
}