import * as THREE from 'three';
import { starClassIndex, SPECTRAL_CLASSES } from '@/lib/topology/spectralClasses';

/**
 * CosmicField — enriched, NASA-accurate deep-space background.
 *
 * Contents (all dim/distant so the torus remains the focal point):
 *  - Milky Way band: dense star layer concentrated along a tilted galactic
 *    equator (gaussian spread from the plane), like the real Milky Way.
 *  - Deep-field stars: very far, tiny, dense star points.
 *  - Distant galaxies: dim sprite discs with varied colors (spiral blue-white,
 *    elliptical golden) and random aspect ratios.
 *  - Extra nebulae: H-alpha pinks, OIII green-teal, reflection blues, dust golds
 *    (Orion, Eagle, Carina, Lagoon, Crab, Trifid palette).
 *
 * Parallax accuracy: distant objects (band, deep, galaxies, nebulae) are
 * essentially fixed; only near stars stream past — matching real traversal.
 */
function mkStarColor() {
  const r = Math.random();
  const cls = starClassIndex(r);
  return new THREE.Color(SPECTRAL_CLASSES[cls].color);
}

export function createCosmicField({ scene, glowTex }) {
  const group = new THREE.Group();
  scene.add(group);
  const disposables = [];

  // ── Milky Way band ──
  const bandTilt = new THREE.Euler(0.5, 0.3, 0.1);
  const bandNormal = new THREE.Vector3(0, 1, 0).applyEuler(bandTilt);
  const bandRef1 = new THREE.Vector3(1, 0, 0).applyEuler(bandTilt);
  const bandRef2 = new THREE.Vector3(0, 0, 1).applyEuler(bandTilt);

  const bandCount = 4000;
  const bandPos = new Float32Array(bandCount * 3);
  const bandCol = new Float32Array(bandCount * 3);
  const bandClassIndices = new Uint8Array(bandCount);
  for (let i = 0; i < bandCount; i++) {
    const radius = 320 + Math.random() * 280;
    const angle = Math.random() * Math.PI * 2;
    const spread = ((Math.random() + Math.random() + Math.random()) - 1.5) * 60;
    const p = new THREE.Vector3()
      .addScaledVector(bandRef1, Math.cos(angle) * radius)
      .addScaledVector(bandRef2, Math.sin(angle) * radius)
      .addScaledVector(bandNormal, spread);
    bandPos[i * 3] = p.x; bandPos[i * 3 + 1] = p.y; bandPos[i * 3 + 2] = p.z;
    const r = Math.random();
    const cls = starClassIndex(r);
    bandClassIndices[i] = cls;
    const c = new THREE.Color(SPECTRAL_CLASSES[cls].color);
    const bright = 0.5 + Math.random() * 0.5;
    bandCol[i * 3] = c.r * bright; bandCol[i * 3 + 1] = c.g * bright; bandCol[i * 3 + 2] = c.b * bright;
  }
  const bandGeo = new THREE.BufferGeometry();
  bandGeo.setAttribute('position', new THREE.BufferAttribute(bandPos, 3));
  bandGeo.setAttribute('color', new THREE.BufferAttribute(bandCol, 3));
  const bandMat = new THREE.PointsMaterial({ size: 1.6, map: glowTex, vertexColors: true, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
  const band = new THREE.Points(bandGeo, bandMat);
  group.add(band);
  disposables.push(bandGeo, bandMat);

  // ── Deep-field stars ──
  const deepCount = 3000;
  const deepPos = new Float32Array(deepCount * 3);
  const deepCol = new Float32Array(deepCount * 3);
  const deepClassIndices = new Uint8Array(deepCount);
  for (let i = 0; i < deepCount; i++) {
    const radius = 500 + Math.random() * 300;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    deepPos[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
    deepPos[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
    deepPos[i * 3 + 2] = radius * Math.cos(phi);
    const r = Math.random();
    const cls = starClassIndex(r);
    deepClassIndices[i] = cls;
    const c = new THREE.Color(SPECTRAL_CLASSES[cls].color);
    const bright = 0.4 + Math.random() * 0.6;
    deepCol[i * 3] = c.r * bright; deepCol[i * 3 + 1] = c.g * bright; deepCol[i * 3 + 2] = c.b * bright;
  }
  const deepGeo = new THREE.BufferGeometry();
  deepGeo.setAttribute('position', new THREE.BufferAttribute(deepPos, 3));
  deepGeo.setAttribute('color', new THREE.BufferAttribute(deepCol, 3));
  const deepMat = new THREE.PointsMaterial({ size: 1.0, map: glowTex, vertexColors: true, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
  const deep = new THREE.Points(deepGeo, deepMat);
  group.add(deep);
  disposables.push(deepGeo, deepMat);

  const interactiveObjects = [];

  // ── Distant galaxies ──
  const GALAXY_COLORS = [0xdfe7ff, 0xffe9c0, 0xcfd6e8, 0xffd9a0, 0xbcd0ff];
  const GALAXY_TYPES = [
    { type: 'Galaxy · Distant Spiral', name: 'Distant Spiral Galaxy', desc: 'A distant spiral galaxy — a rotating disk of stars, gas, and dust with density-wave spiral arms. The blue-white color indicates young, hot O and B stars in the arms, while the yellow-white core contains older stellar populations. Hundreds of billions of stars orbit within it.', sig: 'Spiral galaxies are the primary sites of ongoing star formation in the universe. Their rotation curves provide key evidence for dark matter, and their structure tests the density-wave theory of spiral arm formation — connecting to the Unitary Manifold\'s dark matter and cosmological structure pillars.' },
    { type: 'Galaxy · Distant Elliptical', name: 'Distant Elliptical Galaxy', desc: 'A distant elliptical galaxy — a smooth, featureless ellipsoid of older red and yellow stars. Ellipticals contain little gas or dust and have minimal ongoing star formation. They are among the most massive galaxies, often found in galaxy cluster centers.', sig: 'Elliptical galaxies represent the end-state of galaxy evolution — often the result of galaxy mergers that consume all available gas. Their stellar populations test the aging of stellar systems and the mass-to-light ratios that constrain dark matter halo models.' },
  ];
  for (let i = 0; i < 8; i++) {
    const mat = new THREE.SpriteMaterial({ map: glowTex, color: GALAXY_COLORS[i % GALAXY_COLORS.length], transparent: true, opacity: 0.12 + Math.random() * 0.08, blending: THREE.AdditiveBlending, depthWrite: false });
    const sp = new THREE.Sprite(mat);
    const rad = 380 + Math.random() * 200;
    const th = Math.random() * Math.PI * 2;
    const ph = (Math.random() - 0.5) * Math.PI;
    sp.position.set(rad * Math.cos(ph) * Math.cos(th), rad * Math.sin(ph), rad * Math.cos(ph) * Math.sin(th));
    const base = 18 + Math.random() * 24;
    sp.scale.set(base * (1.4 + Math.random() * 0.6), base * (0.5 + Math.random() * 0.3), 1);
    group.add(sp);
    disposables.push(mat);

    // Invisible hit-proxy for clickability
    const gType = GALAXY_TYPES[i % 2];
    const proxyGeo = new THREE.SphereGeometry(20, 8, 8);
    const proxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
    const proxy = new THREE.Mesh(proxyGeo, proxyMat);
    proxy.position.copy(sp.position);
    proxy.userData = {
      id: `cosmic-galaxy-${i}`,
      type: gType.type,
      name: gType.name,
      description: gType.desc,
      significance: gType.sig,
      links: [{ label: 'Dark Matter KK Tower', path: '/repository?file=src/core/pillar790_dark_matter_kk_tower.py' }, { label: 'Manifold Explorer', path: '/manifold-explorer' }],
      groupId: 'cosmic-field',
      noHighlight: true,
    };
    group.add(proxy);
    interactiveObjects.push(proxy);
    disposables.push(proxyGeo, proxyMat);
  }

  // ── Extra nebulae (NASA-accurate H-alpha / OIII / reflection palette) ──
  const NEBULA_PALETTE = [0xc44a7a, 0x4fae8a, 0xe0a85a, 0xd96a3a, 0xb86aa0, 0x6a8ad0, 0x8a5a9a, 0x3a6a9a];
  const NEBULA_TYPES = [
    { type: 'Nebula · Emission (HII)', name: 'Emission Nebula', desc: 'An emission nebula — a cloud of ionized interstellar gas glowing with its own light. Hot O and B stars emit ultraviolet radiation that strips electrons from hydrogen and oxygen atoms; the recombination produces the characteristic red (H-alpha), green (OIII), and blue (reflection) palette visible here.', sig: 'Emission nebulae are the birthplaces of stars — the ionized gas surrounds young stellar nurseries. Their spectra test the atomic physics of recombination and the metallicity of the interstellar medium, connecting to the Unitary Manifold\'s atomic structure pillar.' },
    { type: 'Nebula · Reflection / Dark', name: 'Reflection Nebula', desc: 'A reflection nebula — interstellar dust scattering and reflecting the light of nearby stars. Unlike emission nebulae, the gas is not ionized; the blue color comes from dust grains preferentially scattering blue light (the same effect that makes the sky blue). Dark lanes of opaque dust may also be visible.', sig: 'Reflection nebulae test interstellar dust models — grain size distributions, compositions, and scattering properties. The dust-to-gas ratio and metallicity constrain the chemical evolution of galaxies and the material science that the Unitary Manifold derives from compactified geometry.' },
  ];
  for (let i = 0; i < 8; i++) {
    const mat = new THREE.SpriteMaterial({ map: glowTex, color: NEBULA_PALETTE[i % NEBULA_PALETTE.length], transparent: true, opacity: 0.08 + Math.random() * 0.1, blending: THREE.AdditiveBlending, depthWrite: false });
    const sp = new THREE.Sprite(mat);
    const rad = 220 + Math.random() * 180;
    const th = Math.random() * Math.PI * 2;
    const ph = (Math.random() - 0.5) * Math.PI * 0.6;
    sp.position.set(rad * Math.cos(ph) * Math.cos(th), rad * Math.sin(ph), rad * Math.cos(ph) * Math.sin(th));
    sp.scale.setScalar(100 + Math.random() * 160);
    group.add(sp);
    disposables.push(mat);

    // Invisible hit-proxy for clickability
    const nType = NEBULA_TYPES[i % 2];
    const proxyGeo = new THREE.SphereGeometry(30, 8, 8);
    const proxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
    const proxy = new THREE.Mesh(proxyGeo, proxyMat);
    proxy.position.copy(sp.position);
    proxy.userData = {
      id: `cosmic-nebula-${i}`,
      type: nType.type,
      name: nType.name,
      description: nType.desc,
      significance: nType.sig,
      links: [{ label: 'Stellar Nucleosynthesis', path: '/repository?file=7-OUTREACH/substack/posts/post-031-standard-model-particles.md' }, { label: 'Manifold Explorer', path: '/manifold-explorer' }],
      groupId: 'cosmic-field',
      noHighlight: true,
    };
    group.add(proxy);
    interactiveObjects.push(proxy);
    disposables.push(proxyGeo, proxyMat);
  }

  function update(t) {
    // Distant objects: ultra-slow rotation only (parallax-negligible, accurate).
    band.rotation.y += 0.00002;
    deep.rotation.y += 0.00001;
  }

  function dispose() {
    disposables.forEach((d) => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects, starfieldLayers: [{ points: band, classIndices: bandClassIndices }, { points: deep, classIndices: deepClassIndices }] };
}