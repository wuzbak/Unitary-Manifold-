import { useEffect, useRef } from 'react';
import * as THREE from 'three';

export const DOMAIN_CONFIG = [
  { id: 1, name: 'corp.axiomzero.spc', pos: [-12, 4, 0], color: 0xff0055, colorHex: '#ff0055', size: 1.2, tier: 'Tier 1: Legal', hubPath: '/corporate' },
  { id: 2, name: 'lab.unitary.phys', pos: [0, 8, 4], color: 0x00f5ff, colorHex: '#00f5ff', size: 1.5, tier: 'Tier 1: Physics Core', hubPath: '/repository' },
  { id: 3, name: 'pentad.network', pos: [0, 0, 0], color: 0xffaa00, colorHex: '#ffaa00', size: 1.8, tier: 'Tier 2: Governance', hubPath: '/cognitive-layer' },
  { id: 4, name: 'eco.az.org', pos: [12, 4, -2], color: 0x00ff88, colorHex: '#00ff88', size: 1.2, tier: 'Tier 3: Ecosystems', hubPath: '/projects' },
  { id: 5, name: 'media.axiomzero.tv', pos: [6, -6, 2], color: 0x9900ff, colorHex: '#9900ff', size: 1.0, tier: 'Tier 3: Outreach', hubPath: '/media-archive' }
];

const CONNECTIONS = [[2, 1], [2, 3], [3, 4], [3, 5], [1, 5]];

export default function TopologyEngine({ onNodeHover, onNodeClick }) {
  const containerRef = useRef(null);
  const hoverRef = useRef(onNodeHover);
  const clickRef = useRef(onNodeClick);
  hoverRef.current = onNodeHover;
  clickRef.current = onNodeClick;

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x050508);
    scene.fog = new THREE.FogExp2(0x050508, 0.012);

    const camera = new THREE.PerspectiveCamera(60, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 5, 30);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0x1a1a2e, 1.5));
    const pointLight = new THREE.PointLight(0x00f5ff, 2, 50);
    pointLight.position.set(0, 10, 10);
    scene.add(pointLight);

    // 5D Manifold wireframe (background structure)
    const manifoldGeo = new THREE.IcosahedronGeometry(20, 1);
    const manifoldMat = new THREE.MeshBasicMaterial({ color: 0x0a1a3e, wireframe: true, transparent: true, opacity: 0.08 });
    const manifold = new THREE.Mesh(manifoldGeo, manifoldMat);
    scene.add(manifold);

    // Central Radion field
    const radionGeo = new THREE.SphereGeometry(0.4, 16, 16);
    const radionMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5 });
    const radion = new THREE.Mesh(radionGeo, radionMat);
    scene.add(radion);

    // Nodes with Kaluza-Klein compactification torus
    const sphereGeo = new THREE.SphereGeometry(1, 32, 32);
    const torusGeo = new THREE.TorusGeometry(1, 0.06, 8, 40);
    const nodes = [];
    const toruses = [];

    DOMAIN_CONFIG.forEach((cfg) => {
      const material = new THREE.MeshPhongMaterial({
        color: cfg.color, emissive: cfg.color, emissiveIntensity: 0.4, shininess: 100, transparent: true, opacity: 0.95
      });
      const mesh = new THREE.Mesh(sphereGeo, material);
      mesh.scale.setScalar(cfg.size);
      mesh.position.set(...cfg.pos);
      mesh.userData = { id: cfg.id, name: cfg.name, tier: cfg.tier, hubPath: cfg.hubPath, baseSize: cfg.size };
      scene.add(mesh);
      nodes.push(mesh);

      const torusMat = new THREE.MeshBasicMaterial({ color: cfg.color, transparent: true, opacity: 0.25, blending: THREE.AdditiveBlending });
      const torus = new THREE.Mesh(torusGeo, torusMat);
      torus.scale.setScalar(cfg.size * 1.8);
      torus.position.set(...cfg.pos);
      torus.userData = { offset: Math.random() * Math.PI };
      scene.add(torus);
      toruses.push(torus);
    });

    // Braided curved connections + particle flow
    const connections = [];
    const particles = [];
    const particleGeo = new THREE.SphereGeometry(0.08, 8, 8);

    CONNECTIONS.forEach(([fromId, toId]) => {
      const from = nodes.find((n) => n.userData.id === fromId);
      const to = nodes.find((n) => n.userData.id === toId);
      if (!from || !to) return;

      const mid = new THREE.Vector3(
        (from.position.x + to.position.x) / 2,
        (from.position.y + to.position.y) / 2 + 4,
        (from.position.z + to.position.z) / 2
      );
      const curve = new THREE.QuadraticBezierCurve3(from.position.clone(), mid, to.position.clone());
      const points = curve.getPoints(30);
      const geo = new THREE.BufferGeometry().setFromPoints(points);
      const mat = new THREE.LineBasicMaterial({ color: 0x334466, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending });
      const line = new THREE.Line(geo, mat);
      scene.add(line);
      connections.push({ line, curve, pulseOffset: Math.random() * Math.PI });

      for (let p = 0; p < 2; p++) {
        const particleMat = new THREE.MeshBasicMaterial({ color: 0x00f5ff, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending });
        const particle = new THREE.Mesh(particleGeo, particleMat);
        particle.userData = { curve, progress: Math.random(), speed: 0.003 + Math.random() * 0.003 };
        scene.add(particle);
        particles.push(particle);
      }
    });

    // Raycaster (hover + click)
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2(-9999, -9999);
    let hoveredNode = null;

    const handleMouseMove = (e) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    };
    const handleMouseLeave = () => { mouse.x = -9999; mouse.y = -9999; };
    const handleClick = (e) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, camera);
      const hits = raycaster.intersectObjects(nodes);
      if (hits.length > 0) clickRef.current?.(hits[0].object.userData);
    };
    container.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('mouseleave', handleMouseLeave);
    container.addEventListener('click', handleClick);

    const handleResize = () => {
      if (!container.clientWidth) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    let animId;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      const t = performance.now() * 0.001;

      nodes.forEach((node) => {
        node.rotation.y += 0.01;
        const pulse = 1.0 + Math.sin(t * 2 + node.userData.id) * 0.08;
        node.scale.setScalar(pulse * node.userData.baseSize);
      });

      toruses.forEach((torus) => {
        torus.rotation.x += 0.015;
        torus.rotation.y += 0.008;
        torus.rotation.z = Math.sin(t * 0.5 + torus.userData.offset) * 0.3;
      });

      connections.forEach((conn) => {
        const intensity = 0.3 + Math.abs(Math.sin(t * 3 + conn.pulseOffset)) * 0.4;
        conn.line.material.opacity = intensity;
        conn.line.material.color.setHex(intensity > 0.6 ? 0x00f5ff : 0x334466);
      });

      particles.forEach((particle) => {
        particle.userData.progress += particle.userData.speed;
        if (particle.userData.progress > 1) particle.userData.progress = 0;
        const pos = particle.userData.curve.getPoint(particle.userData.progress);
        particle.position.copy(pos);
        particle.material.opacity = 0.8 * Math.sin(particle.userData.progress * Math.PI);
      });

      radion.scale.setScalar(0.8 + Math.sin(t * 4) * 0.3);
      radion.material.opacity = 0.3 + Math.sin(t * 4) * 0.2;

      manifold.rotation.y += 0.001;
      manifold.rotation.x += 0.0005;

      camera.position.x = Math.sin(t * 0.1) * 30;
      camera.position.z = Math.cos(t * 0.1) * 30;
      camera.position.y = 5 + Math.sin(t * 0.05) * 3;
      camera.lookAt(0, 2, 0);

      raycaster.setFromCamera(mouse, camera);
      const hits = raycaster.intersectObjects(nodes);
      if (hits.length > 0) {
        const node = hits[0].object;
        if (hoveredNode !== node) {
          hoveredNode = node;
          container.style.cursor = 'pointer';
          hoverRef.current?.(node.userData);
        }
      } else if (hoveredNode) {
        hoveredNode = null;
        container.style.cursor = 'default';
        hoverRef.current?.(null);
      }

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('mouseleave', handleMouseLeave);
      container.removeEventListener('click', handleClick);
      sphereGeo.dispose(); torusGeo.dispose(); manifoldGeo.dispose(); radionGeo.dispose(); particleGeo.dispose();
      nodes.forEach((n) => n.material.dispose());
      toruses.forEach((t) => t.material.dispose());
      connections.forEach((c) => { c.line.geometry.dispose(); c.line.material.dispose(); });
      particles.forEach((p) => p.material.dispose());
      radionMat.dispose(); manifoldMat.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={containerRef} className="w-full h-full" />;
}