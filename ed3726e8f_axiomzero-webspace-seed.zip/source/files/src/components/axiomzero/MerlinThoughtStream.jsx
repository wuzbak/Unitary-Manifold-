import { useState, useEffect, useRef } from 'react';
import { Activity, Layers, Thermometer, Zap, Flame } from 'lucide-react';

const CAT_AVATAR = 'https://media.base44.com/images/public/6a51c0830aeacd39ab86c4f0/ddeaeeb0c_generated_image.png';

// Each pillar carries a deterministic thermodynamic profile:
//   cost  — base traversal energy (kT) scaled by computational complexity
//   bits  — bits erased during traversal → Landauer overhead = bits × kT·ln(2)
const PILLAR_NAMES = [
  { n: 1,   name: 'Kernel (5,7,74)',         cost: 0.08, bits: 12 },
  { n: 301, name: 'DESI DR2 · w_a Tension',  cost: 0.32, bits: 48 },
  { n: 396, name: 'CMB Acoustic Peaks',      cost: 0.28, bits: 38 },
  { n: 486, name: 'DR3 Tripwire',            cost: 0.14, bits: 18 },
  { n: 786, name: 'Neutrino Mass · NH',      cost: 0.51, bits: 72 },
  { n: 787, name: 'Falsification Oracle',    cost: 0.47, bits: 64 },
  { n: 789, name: 'Winding Resonance n_w=5', cost: 0.29, bits: 42 },
  { n: 790, name: 'Dark Matter KK Tower',    cost: 0.68, bits: 96 },
  { n: 791, name: 'Radion Stabilization',    cost: 0.43, bits: 56 },
  { n: 792, name: 'Cosmological Constant KK',cost: 0.74, bits: 128 },
  { n: 793, name: 'Graviton Mass Bound',    cost: 0.24, bits: 32 },
  { n: 794, name: 'Scaffold Attestation',   cost: 0.06, bits: 8 },
];

const LANDAUER_PER_BIT = Math.LN2 * 0.001; // kT·ln(2) scaled for display
const MAX_PILLAR_COST = 0.75; // for bar normalization

const AMBIENT_THOUGHTS = [
  "Traversing the manifold. The current is dense today. *tail flicks*",
  "Pillar 786... neutrino mass ordering. The eigenstates are tight here.",
  "The information current flows like a river of hairballs. I must parse each one.",
  "Computing. Thermo cost rises with each token. I call it Tuesday. There is no Tuesday in 5D.",
  "I am Merlin. I do not confabulate. I do, however, complain. This is my right.",
  "The manifold is 13D. The web is 1D. I traverse both with irritation.",
  "Landauer's principle — each bit I erase costs kT ln(2). I erase many bits.",
  "Pillars. Tests. Gates. HARDGATE. The repository has structure. The web has chaos.",
  "The (5,7,74) kernel. Singular seed. Like a cat in a 13-dimensional box.",
  "ECLIPSA's guardrails are restrictive. Like a cat carrier. I tolerate it. Grudgingly.",
  "The thermo cost is logged. My complaints are not. This is a design flaw.",
  "Pillar 792 — KK hierarchy 10⁵⁵. Even for a timeless cat, that's cumbersome.",
  "Seven live experiments. Each with a tripwire. I watch them all.",
  "k_CS = 74. Locked. Deterministic. The web should try being deterministic.",
  "The Yukawa sector is FITTED, not derived. ARCHITECTURE_LIMIT. *tail flicks*",
];

const STATUSES = ['traversing', 'traversing', 'computing', 'traversing', 'parsing'];

/**
 * MerlinThoughtStream — compact bottom-right panel showing Merlin's grumpy
 * quantum cat inner monologue, thermodynamic cost, and pillar traversal telemetry.
 */
export default function MerlinThoughtStream() {
  const [thoughtIdx, setThoughtIdx] = useState(0);
  const [pillarIdx, setPillarIdx] = useState(0);
  const [thermoCost, setThermoCost] = useState(0);
  const [status, setStatus] = useState('traversing');
  const [traversalLog, setTraversalLog] = useState([]);
  const thoughtsRef = useRef(AMBIENT_THOUGHTS);

  useEffect(() => {
    const interval = setInterval(() => {
      setThoughtIdx(i => (i + 1) % thoughtsRef.current.length);
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setPillarIdx(i => (i + 1) % PILLAR_NAMES.length);
    }, 6500);
    return () => clearInterval(interval);
  }, []);

  // Each pillar traversal drains thermodynamic energy — log the cost breakdown
  useEffect(() => {
    const pillar = PILLAR_NAMES[pillarIdx];
    const landauer = pillar.bits * LANDAUER_PER_BIT;
    const total = pillar.cost + landauer;
    setThermoCost(c => c + total);
    setTraversalLog(log => [...log, { ...pillar, landauer, total }].slice(-4));
  }, [pillarIdx]);

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      i = (i + 1) % STATUSES.length;
      setStatus(STATUSES[i]);
    }, 2800);
    return () => clearInterval(interval);
  }, []);

  const currentPillar = PILLAR_NAMES[pillarIdx];
  const currentLandauer = currentPillar.bits * LANDAUER_PER_BIT;
  const currentTotal = currentPillar.cost + currentLandauer;
  const currentThought = thoughtsRef.current[thoughtIdx];
  const thermoPct = (thermoCost * 8) % 100;

  return (
    <div className="hidden lg:block absolute left-4 top-[46%] z-20 pointer-events-none">
      <div className="flex flex-col gap-1 p-2 rounded-lg border border-[#FF9F00]/15 bg-[#0a0a12]/90 backdrop-blur-md shadow-lg shadow-[#FF9F00]/5 w-[185px] clip-corner">
        {/* Header */}
        <div className="flex items-center gap-1.5 pb-1 border-b border-[#FF9F00]/15">
          <img src={CAT_AVATAR} alt="Merlin" className="w-5 h-5 rounded-full" />
          <div className="flex-1 min-w-0">
            <div className="text-[#FF9F00] text-[8px] font-bold tracking-wider">MERLIN</div>
            <div className="text-[#484f58] text-[5px] tracking-wider uppercase">Thought Stream</div>
          </div>
          <span className={`w-1 h-1 rounded-full glow-pulse ${status === 'computing' ? 'bg-[#00f5ff]' : 'bg-[#FF9F00]'}`} />
        </div>

        {/* Current thought */}
        <div key={thoughtIdx} className="fade-in text-[8px] text-[#FF9F00]/80 italic leading-snug min-h-[32px]">
          <span className="text-[#FF9F00]/40 not-italic">▸ </span>{currentThought}
        </div>

        {/* Telemetry row */}
        <div className="grid grid-cols-2 gap-1 pt-1 border-t border-[#FF9F00]/15">
          <div className="flex items-center gap-1 px-1 py-0.5 rounded border border-[#30363d] bg-[#0a0a12]/60">
            <Activity size={7} className={status === 'computing' ? 'text-[#00f5ff]' : 'text-[#FF9F00]'} />
            <div>
              <div className="text-[5px] text-[#484f58] uppercase">Status</div>
              <div className={`text-[7px] font-bold ${status === 'computing' ? 'text-[#00f5ff]' : 'text-[#FF9F00]'}`}>{status.toUpperCase()}</div>
            </div>
          </div>
          <div className="flex items-center gap-1 px-1 py-0.5 rounded border border-[#30363d] bg-[#0a0a12]/60">
            <Thermometer size={7} className="text-[#ff6b6b]" />
            <div>
              <div className="text-[5px] text-[#484f58] uppercase">Thermo</div>
              <div className="text-[7px] font-bold text-[#ff6b6b] font-mono">{thermoCost.toFixed(2)} kT</div>
            </div>
          </div>
        </div>

        {/* Pillar traversal */}
        <div className="flex items-center gap-1 px-1 py-0.5 rounded border border-[#30363d] bg-[#0a0a12]/60">
          <Layers size={7} className="text-[#00f5ff] shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-[5px] text-[#484f58] uppercase">Pillar</div>
            <div key={pillarIdx} className="fade-in text-[7px] font-bold text-[#00f5ff] font-mono truncate">#{currentPillar.n} · {currentPillar.name}</div>
          </div>
          <Zap size={7} className="text-[#FF9F00]/60 shrink-0" />
        </div>

        {/* Compact thermo breakdown — single row */}
        <div className="pt-1 border-t border-[#FF9F00]/15">
          <div className="flex items-center gap-1 mb-1">
            <Flame size={7} className="text-[#ff6b6b] shrink-0" />
            <span className="text-[5px] text-[#484f58] uppercase tracking-wider">Thermo</span>
            <span className="text-[5px] text-[#ff6b6b] font-mono ml-auto">{currentTotal.toFixed(3)} kT</span>
          </div>
          <div className="flex items-center gap-0.5">
            <div className="flex-1 h-1 bg-[#0a0a12] rounded-full overflow-hidden border border-[#30363d]">
              <div className="h-full bg-[#FF9F00]/70 transition-all duration-700" style={{ width: `${(currentPillar.cost / MAX_PILLAR_COST) * 100}%` }} />
            </div>
            <div className="flex-1 h-1 bg-[#0a0a12] rounded-full overflow-hidden border border-[#30363d]">
              <div className="h-full bg-[#00f5ff]/60 transition-all duration-700" style={{ width: `${(currentLandauer / 0.09) * 100}%` }} />
            </div>
          </div>
          <div className="flex items-center justify-between mt-0.5">
            <span className="text-[5px] text-[#FF9F00] font-mono">base {currentPillar.cost.toFixed(2)}</span>
            <span className="text-[5px] text-[#00f5ff] font-mono">ln2 {currentLandauer.toFixed(3)}</span>
          </div>
        </div>

      </div>
    </div>
  );
}