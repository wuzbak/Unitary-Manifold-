import * as THREE from 'three';
import { nebulaVertexShader, nebulaFragmentShader } from '@/lib/topology/shaders/nebulaVolume';

/**
 * VolumetricNebula — raymarched 3D noise nebula volumes.
 *
 * Replaces sprite-based nebulae with physically-inspired volumetric rendering:
 * - Fragment-shader raymarching through a box volume
 * - fBm noise density field with time drift
 * - Emission + absorption light transport
 * - Color gradient between two palette colors
 *
 * Returns { group, update, dispose, interactiveObjects }
 */
export function createVolumetricNebulae({ scene, count = 4 }) {
  const group = new THREE.Group();
  scene.add(group);
  const disposables = [];
  const interactiveObjects = [];
  const nebulae = [];

  // Color palettes inspired by real nebulae
  const PALETTES = [
    { a: new THREE.Color(0x4a1a5a), b: new THREE.Color(0xc44a7a), name: 'Emission Nebula', type: 'Nebula · Emission (HII)', desc: 'A volumetric emission nebula — ionized hydrogen gas glowing with H-alpha red and OIII green. Hot O and B stars emit UV radiation that strips electrons from the surrounding gas; recombination produces the characteristic emission lines.', sig: 'Emission nebulae are stellar nurseries — the ionized gas surrounds newly forming stars. Their spectra test the atomic physics of recombination and the metallicity of the interstellar medium.' },
    { a: new THREE.Color(0x1a3a6a), b: new THREE.Color(0x4fae8a), name: 'Planetary Nebula', type: 'Nebula · Planetary', desc: 'A planetary nebula — the ejected envelope of a dying low-mass star, ionized by the exposed hot stellar core. The green color comes from OIII forbidden lines at 500.7 nm.', sig: 'Planetary nebulae trace the late evolution of Sun-like stars and enrich the interstellar medium with processed material — carbon, nitrogen, and oxygen.' },
    { a: new THREE.Color(0x5a2a1a), b: new THREE.Color(0xe0a85a), name: 'Supernova Remnant', type: 'Nebula · Supernova Remnant', desc: 'A supernova remnant — the expanding debris of a massive star\'s explosion, heated to millions of degrees. The filamentary structure shows shock-heated gas and ejected stellar material.', sig: 'Supernova remnants are the primary source of heavy elements (iron, calcium, silicon) in the galaxy. They drive the chemical enrichment that makes rocky planets and life possible.' },
    { a: new THREE.Color(0x2a1a4a), b: new THREE.Color(0x6a8ad0), name: 'Reflection Nebula', type: 'Nebula · Reflection', desc: 'A reflection nebula — interstellar dust scattering and reflecting the light of nearby stars. The blue color comes from dust grains preferentially scattering blue light (Rayleigh scattering).', sig: 'Reflection nebulae test interstellar dust grain models — size distributions, compositions, and scattering phase functions that constrain the chemical evolution of galaxies.' },
  ];

  const boxGeo = new THREE.BoxGeometry(1, 1, 1);
  disposables.push(boxGeo);

  for (let i = 0; i < count; i++) {
    const palette = PALETTES[i % PALETTES.length];

    const material = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uColorA: { value: palette.a.clone() },
        uColorB: { value: palette.b.clone() },
        uDensity: { value: 0.8 + Math.random() * 0.4 },
        uOpacity: { value: 0.15 + Math.random() * 0.1 },
        uThreshold: { value: 0.0 + Math.random() * 0.2 },
        uInvModel: { value: new THREE.Matrix4() },
      },
      vertexShader: nebulaVertexShader,
      fragmentShader: nebulaFragmentShader,
      transparent: true,
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      depthWrite: false,
    });

    const mesh = new THREE.Mesh(boxGeo, material);

    // Position in a sphere shell around the torus
    const rad = 180 + Math.random() * 120;
    const theta = Math.random() * Math.PI * 2;
    const phi = (Math.random() - 0.5) * Math.PI * 0.6;
    mesh.position.set(
      rad * Math.cos(phi) * Math.cos(theta),
      rad * Math.sin(phi),
      rad * Math.cos(phi) * Math.sin(theta)
    );
    mesh.scale.setScalar(60 + Math.random() * 80);
    mesh.userData = {
      id: `vol-nebula-${i}`,
      type: palette.type,
      name: palette.name,
      description: palette.desc,
      significance: palette.sig,
      links: [
        { label: 'Stellar Nucleosynthesis', path: '/repository?file=7-OUTREACH/substack/posts/post-031-standard-model-particles.md' },
        { label: 'Manifold Explorer', path: '/manifold-explorer' },
      ],
      groupId: 'volumetric-nebulae',
      noHighlight: true,
    };
    group.add(mesh);
    interactiveObjects.push(mesh);
    disposables.push(material);

    // Invisible hit-proxy for reliable clicking
    const proxyGeo = new THREE.SphereGeometry(mesh.scale.x * 0.5, 8, 8);
    const proxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
    const proxy = new THREE.Mesh(proxyGeo, proxyMat);
    proxy.position.copy(mesh.position);
    proxy.userData = { ...mesh.userData };
    group.add(proxy);
    interactiveObjects.push(proxy);
    disposables.push(proxyGeo, proxyMat);

    nebulae.push({ mesh, material, proxy, drift: new THREE.Vector3((Math.random() - 0.5) * 0.02, (Math.random() - 0.5) * 0.02, (Math.random() - 0.5) * 0.02) });
  }

  function update(t) {
    nebulae.forEach((n, i) => {
      n.material.uniforms.uTime.value = t;
      // Update inverse model matrix for ray-box intersection
      n.mesh.updateMatrix();
      n.material.uniforms.uInvModel.value.copy(n.mesh.matrix).invert();
      // Slow drift
      n.mesh.position.x += n.drift.x * 0.016;
      n.mesh.position.y += n.drift.y * 0.016;
      n.mesh.position.z += n.drift.z * 0.016;
      n.proxy.position.copy(n.mesh.position);
      // Wrap around
      const d = n.mesh.position.length();
      if (d > 350) {
        n.mesh.position.multiplyScalar(-300 / d);
        n.proxy.position.copy(n.mesh.position);
      }
    });
  }

  function dispose() {
    disposables.forEach((d) => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects };
}