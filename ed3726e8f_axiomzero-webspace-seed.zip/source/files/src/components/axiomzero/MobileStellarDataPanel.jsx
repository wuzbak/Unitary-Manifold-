import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { X, ExternalLink } from 'lucide-react';
import { SPECTRAL_CLASSES } from '@/lib/topology/spectralClasses';

/**
 * MobileStellarDataPanel — mobile bottom-sheet variant of StellarDataPanel.
 * Shows spectral/blackbody swatches, astrometric grid, HR diagram, and links
 * with large readable type. Same element data shape as the desktop panel.
 * lg:hidden — desktop StellarDataPanel is untouched.
 */
function teffToRGB(kelvin) {
  const t = Math.max(1000, Math.min(40000, kelvin)) / 100;
  let r, g, b;
  if (t <= 66) r = 255;
  else { r = 329.698727446 * Math.pow(t - 60, -0.1332047592); r = Math.max(0, Math.min(255, r)); }
  if (t <= 66) { g = 99.4708025861 * Math.log(t) - 161.1195681661; }
  else { g = 288.1221695283 * Math.pow(t - 60, -0.0755148492); }
  g = Math.max(0, Math.min(255, g));
  if (t >= 66) b = 255;
  else if (t <= 19) b = 0;
  else { b = 138.5177312231 * Math.log(t - 10) - 305.0447927307; b = Math.max(0, Math.min(255, b)); }
  return `rgb(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)})`;
}

function luminosityFromMag(mag, distLy) {
  if (!distLy || distLy <= 0) return null;
  const dPc = distLy / 3.2616;
  const M = mag - 5 * Math.log10(dPc) + 5;
  return Math.pow(10, (4.83 - M) / 2.5);
}

const TEFF_MAX = 40000, TEFF_MIN = 2500, LUM_MAX = 1e6, LUM_MIN = 1e-4;
function hrCoords(teff, lum, w, h) {
  const xLog = Math.log10(Math.max(TEFF_MIN, Math.min(TEFF_MAX, teff)));
  const yLog = lum > 0 ? Math.log10(lum) : -4;
  const x = ((Math.log10(TEFF_MAX) - xLog) / (Math.log10(TEFF_MAX) - Math.log10(TEFF_MIN))) * w;
  const y = ((Math.log10(LUM_MAX) - yLog) / (Math.log10(LUM_MAX) - Math.log10(LUM_MIN))) * h;
  return { x, y };
}

function Field({ label, value, accent = '#00f5ff' }) {
  return (
    <div className="flex justify-between items-center border-b border-[#00f5ff]/10 pb-1">
      <span className="text-[#8b949e] text-[10px] uppercase tracking-wider">{label}</span>
      <span className="font-bold text-[11px]" style={{ color: accent }}>{value}</span>
    </div>
  );
}

export default function MobileStellarDataPanel({ element, onClose }) {
  const startY = useRef(null);

  useEffect(() => {
    const handleEsc = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  if (!element) return null;

  const specKey = element._spectralKey || (element._spectralType?.charAt(0) || 'G');
  const specClass = SPECTRAL_CLASSES.find((s) => s.key === specKey) || SPECTRAL_CLASSES[4];
  const teff = element._teffK || 0;
  const bbColor = teff > 0 ? teffToRGB(teff) : 'rgb(255,255,255)';
  const lum = luminosityFromMag(element._apparentMag, element._distanceLy);

  const W = 220, H = 130;
  const starPos = hrCoords(teff, lum, W, H);
  const msHot = hrCoords(30000, 1e5, W, H);
  const msCool = hrCoords(3000, 1e-3, W, H);

  const onTouchStart = (e) => { startY.current = e.touches[0].clientY; };
  const onTouchMove = (e) => {
    if (startY.current == null) return;
    if (e.touches[0].clientY - startY.current > 90) { onClose(); startY.current = null; }
  };

  return (
    <>
      <div className="lg:hidden fixed inset-0 z-[160] bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div
        className="lg:hidden fixed bottom-0 left-0 right-0 z-[170] max-h-[82vh] overflow-y-auto clip-corner bg-[#0a0a12]/97 backdrop-blur-xl border-t-2 border-[#4DD0E1]/30 fade-in"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
      >
        <div className="flex justify-center pt-2.5 pb-1 shrink-0"><div className="w-10 h-1 rounded-full bg-[#00f5ff]/30" /></div>
        <div className="sticky top-0 flex items-center justify-between px-4 py-3 bg-[#0a0a12]/95 backdrop-blur-xl border-b border-[#4DD0E1]/15 z-10">
          <div className="flex-1 min-w-0">
            <div className="text-[#4DD0E1] text-[10px] uppercase tracking-wider mb-0.5">▸ {element.type}</div>
            <div className="text-white font-bold text-base">{element.name}</div>
            <div className="text-[#484f58] text-[9px] mt-0.5 font-mono">{element._sourceId}</div>
          </div>
          <button onClick={onClose} className="text-[#8b949e] active:text-[#FF9F00] ml-2 shrink-0 p-2" aria-label="Close">
            <X size={22} />
          </button>
        </div>

        <div className="px-4 py-3 pb-8 space-y-3">
          <div className="flex gap-2">
            <div className="flex-1 border border-[#00f5ff]/20 p-2">
              <div className="text-[#8b949e] text-[9px] uppercase tracking-wider mb-1.5">Spectral Class</div>
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 shrink-0 border border-white/20" style={{ background: specClass.colorHex, boxShadow: `0 0 8px ${specClass.colorHex}` }} />
                <div>
                  <div className="text-white font-bold text-sm">{element._spectralType}</div>
                  <div className="text-[#484f58] text-[9px]">{specClass.name}</div>
                </div>
              </div>
            </div>
            <div className="flex-1 border border-[#FF9F00]/20 p-2">
              <div className="text-[#8b949e] text-[9px] uppercase tracking-wider mb-1.5">Blackbody · {teff.toLocaleString()} K</div>
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 shrink-0 border border-white/20" style={{ background: bbColor, boxShadow: `0 0 10px ${bbColor}` }} />
                <div className="text-[#FF9F00] font-mono text-[10px] leading-tight">
                  <div>Planckian</div>
                  <div className="text-[#484f58]">Teff → RGB</div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-x-3 gap-y-1">
            <Field label="Apparent Mag" value={element._apparentMag?.toFixed(2)} />
            <Field label="Temperature" value={`${teff.toLocaleString()} K`} />
            <Field label="Distance" value={element._distance} />
            <Field label="Parallax" value={element._parallax} />
            {lum != null && <Field label="Luminosity" value={`${lum < 0.01 ? lum.toExponential(2) : lum.toFixed(2)} L☉`} accent="#FF9F00" />}
            {lum != null && <Field label="Abs. Mag" value={(element._apparentMag - 5 * Math.log10((element._distanceLy / 3.2616)) + 5).toFixed(2)} />}
          </div>

          <div className="border border-[#4DD0E1]/20 p-2">
            <div className="text-[#4DD0E1] text-[9px] uppercase tracking-wider mb-1">▸ Hertzsprung-Russell Position</div>
            <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto" style={{ maxHeight: 140 }}>
              <line x1="0" y1={H} x2={W} y2={H} stroke="#30363d" strokeWidth="0.5" />
              <line x1="0" y1="0" x2="0" y2={H} stroke="#30363d" strokeWidth="0.5" />
              <line x1={msHot.x} y1={msHot.y} x2={msCool.x} y2={msCool.y} stroke="#4DD0E1" strokeWidth="0.8" strokeOpacity="0.35" strokeDasharray="2 2" />
              <text x={W / 2} y={H - 2} fill="#484f58" fontSize="6" textAnchor="middle">← hotter · Teff (K) · cooler →</text>
              <text x="3" y="8" fill="#484f58" fontSize="6" transform="rotate(-90 3 8)">log L/L☉</text>
              <circle cx={starPos.x} cy={starPos.y} r="3" fill={bbColor} stroke="#fff" strokeWidth="0.5">
                <animate attributeName="r" values="3;4.5;3" dur="2s" repeatCount="indefinite" />
              </circle>
              <circle cx={starPos.x} cy={starPos.y} r="6" fill="none" stroke={bbColor} strokeWidth="0.4" strokeOpacity="0.4" />
            </svg>
          </div>

          <p className="text-[#e6edf3] text-sm leading-relaxed">{element.description}</p>

          {element.significance && (
            <div>
              <div className="text-[#FF9F00] text-[10px] uppercase tracking-wider mb-1">▸ Physics Significance</div>
              <p className="text-[#8fa0bc] text-[12px] leading-relaxed">{element.significance}</p>
            </div>
          )}

          {element.links?.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {element.links.map((link, i) => (
                link.href ? (
                  <a key={i} href={link.href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 px-3 py-2 text-[11px] font-bold bg-[#FF9F00]/10 border border-[#FF9F00]/30 text-[#FF9F00] active:bg-[#FF9F00]/20">
                    {link.label} <ExternalLink size={11} />
                  </a>
                ) : (
                  <Link key={i} to={link.path} className="flex items-center gap-1.5 px-3 py-2 text-[11px] font-bold bg-[#FF9F00]/10 border border-[#FF9F00]/30 text-[#FF9F00] active:bg-[#FF9F00]/20">
                    {link.label} <ExternalLink size={11} />
                  </Link>
                )
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}