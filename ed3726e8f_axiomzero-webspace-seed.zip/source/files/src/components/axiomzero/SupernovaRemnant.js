import * as THREE from 'three';

/**
 * SupernovaRemnant — expanding shell of stellar ejecta.
 *
 * Scientific grounding:
 *  - Shell: ~10–30 light-years across (compressed scale)
 *  - Colors: H-alpha (red/pink), OIII (green-teal), reflection (blue),
 *    dust (gold) — matching real nebula palette (Crab, Orion, Carina)
 *  - Central remnant: neutron star or black hole left by the progenitor
 *  - Expansion: slow, with filamentary structure from instabilities
 */
export function createSupernovaRemnant({ scene, glowTex }) {
  const group = new THREE.Group();
  group.position.set(80, 20, 45);

  const disposables = [];

  // ── Expanding shell — particle cloud ──
  const shellCount = 5000;
  const shellPos = new Float32Array(shellCount * 3);
  const shellCol = new Float32Array(shellCount * 3);

  const PALETTE = [
    new THREE.Color(0xff4466), // H-alpha red-pink
    new THREE.Color(0x44aa88), // OIII green-teal
    new THREE.Color(0x6688ff), // reflection blue
    new THREE.Color(0xffaa44), // warm dust gold
    new THREE.Color(0xcc66ff), // magenta
  ];

  for (let i = 0; i < shellCount; i++) {
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    // Filamentary radial distribution — noise-like clumping for organic shell
    const filament = Math.sin(theta * 4 + phi * 3) * 0.4 + Math.cos(theta * 6 - phi * 2) * 0.3;
    const r = 13 + filament * 2.5 + (Math.random() - 0.5) * 3;
    shellPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    shellPos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    shellPos[i * 3 + 2] = r * Math.cos(phi);

    // Filamentary color distribution
    const colorIdx = Math.floor(Math.abs(Math.sin(theta * 3 + phi * 2)) * PALETTE.length) % PALETTE.length;
    const c = PALETTE[colorIdx];
    const bright = 0.6 + Math.random() * 0.4;
    shellCol[i * 3] = c.r * bright;
    shellCol[i * 3 + 1] = c.g * bright;
    shellCol[i * 3 + 2] = c.b * bright;
  }

  const shellGeo = new THREE.BufferGeometry();
  shellGeo.setAttribute('position', new THREE.BufferAttribute(shellPos, 3));
  shellGeo.setAttribute('color', new THREE.BufferAttribute(shellCol, 3));
  const shellMat = new THREE.PointsMaterial({ size: 0.22, map: glowTex, vertexColors: true, transparent: true, opacity: 0.45, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true, alphaTest: 0.02 });
  const shell = new THREE.Points(shellGeo, shellMat);
  group.add(shell);
  disposables.push(shellGeo, shellMat);

  // ── Central neutron star remnant ──
  const nsGeo = new THREE.SphereGeometry(0.35, 24, 24);
  const nsMat = new THREE.MeshBasicMaterial({ color: 0xe0f0ff });
  const ns = new THREE.Mesh(nsGeo, nsMat);
  group.add(ns);
  disposables.push(nsGeo, nsMat);

  const nsGlowMat = new THREE.SpriteMaterial({ map: glowTex, color: 0x88aaff, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false });
  const nsGlow = new THREE.Sprite(nsGlowMat);
  nsGlow.scale.setScalar(3.5);
  group.add(nsGlow);
  disposables.push(nsGlowMat);

  // ── Interactive proxy ──
  const proxyGeo = new THREE.SphereGeometry(15, 16, 16);
  const proxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
  const proxy = new THREE.Mesh(proxyGeo, proxyMat);
  proxy.userData = {
    id: 'supernova-remnant',
    type: 'Stellar Remnant',
    name: 'Supernova Remnant',
    description: 'The expanding shell of stellar ejecta from a supernova explosion — one of the most energetic events in the universe. The remnant contains heavy elements forged in the stellar core and dispersed into the interstellar medium, enriching the galaxy for future generations of star formation.',
    significance: 'Supernova nucleosynthesis is the primary source of elements heavier than iron in the universe. Type Ia supernovae serve as standard candles for measuring cosmic distances, providing the key evidence for the accelerating expansion of the universe driven by dark energy.',
    links: [{ label: 'Manifold Explorer', path: '/manifold-explorer' }],
    groupId: 'supernova-remnant',
  };
  group.add(proxy);
  disposables.push(proxyGeo, proxyMat);

  scene.add(group);

  function update(t) {
    group.rotation.y += 0.0004;
    shell.material.opacity = 0.4 + Math.sin(t * 0.2) * 0.06;
    nsGlow.material.opacity = 0.3 + Math.sin(t * 1.2) * 0.06;
  }

  function dispose() {
    disposables.forEach(d => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects: [proxy] };
}