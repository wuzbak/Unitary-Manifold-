import { Component } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, Globe, BookOpen, FlaskConical, Shield } from 'lucide-react';

/**
 * TopologyErrorBoundary — catches WebGL/Three.js crashes and renders a
 * lightweight 2D fallback instead of a blank black screen.
 *
 * Wraps <ToroidalTopology /> on the AxiomZero home page.
 */
export default class TopologyErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('[TopologyErrorBoundary] 3D render failed:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="absolute inset-0 flex items-center justify-center bg-[#050508] font-mono text-center px-4">
          <div className="max-w-md">
            {/* Static torus illustration — CSS-only fallback */}
            <div className="relative w-32 h-32 mx-auto mb-6">
              <div className="absolute inset-0 rounded-full border-4 border-[#00f5ff]/20" />
              <div className="absolute inset-4 rounded-full border-4 border-[#00f5ff]/30 rotate-45" />
              <div className="absolute inset-8 rounded-full border-2 border-[#00f5ff]/40" />
              <div className="absolute inset-0 flex items-center justify-center">
                <AlertTriangle size={28} className="text-[#FF9F00]" />
              </div>
            </div>

            <h2 className="text-[#00f5ff] text-lg font-bold tracking-wider mb-2">3D TOPOLOGY UNAVAILABLE</h2>
            <p className="text-[#8b949e] text-xs leading-relaxed mb-6">
              The interactive 3D manifold requires WebGL, which isn't available in your browser
              or has crashed. You can still explore the platform — all other pages work normally.
            </p>

            <div className="grid grid-cols-2 gap-2">
              <Link to="/manifold-explorer" className="flex items-center gap-2 px-3 py-2.5 border border-[#00f5ff]/30 bg-[#00f5ff]/5 text-[#00f5ff] text-xs font-bold clip-corner hover:bg-[#00f5ff]/10 transition-colors">
                <Globe size={14} /> Manifold Explorer
              </Link>
              <Link to="/system-status" className="flex items-center gap-2 px-3 py-2.5 border border-[#00f5ff]/30 bg-[#00f5ff]/5 text-[#00f5ff] text-xs font-bold clip-corner hover:bg-[#00f5ff]/10 transition-colors">
                <Shield size={14} /> System Status
              </Link>
              <Link to="/knowledge-hub" className="flex items-center gap-2 px-3 py-2.5 border border-[#00f5ff]/30 bg-[#00f5ff]/5 text-[#00f5ff] text-xs font-bold clip-corner hover:bg-[#00f5ff]/10 transition-colors">
                <BookOpen size={14} /> Knowledge Hub
              </Link>
              <Link to="/labs" className="flex items-center gap-2 px-3 py-2.5 border border-[#00f5ff]/30 bg-[#00f5ff]/5 text-[#00f5ff] text-xs font-bold clip-corner hover:bg-[#00f5ff]/10 transition-colors">
                <FlaskConical size={14} /> Labs & Sandbox
              </Link>
            </div>

            <button
              onClick={() => this.setState({ hasError: false, error: null })}
              className="mt-4 text-[#484f58] text-[10px] hover:text-[#8b949e] transition-colors"
            >
              ↻ Try reloading the 3D view
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}