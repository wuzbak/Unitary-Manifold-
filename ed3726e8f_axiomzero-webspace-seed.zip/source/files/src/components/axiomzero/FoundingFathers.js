import * as THREE from 'three';

/**
 * FoundingFathers — two distinct, bright, vibrant, pulsating cosmic dust clouds
 * memorializing Theodor Kaluza and Oskar Klein, the physicists whose 5D unified
 * field theory (1919–1926) is the direct ancestor of the Unitary Manifold's
 * compactified geometry.
 *
 * Each cloud is a dense particle system (350 particles) with additive blending,
 * a spectral color palette distinct from the gold pillar stars, drift animation,
 * and rhythmic pulsation. Each cloud is independently raycastable via THREE.Points
 * (with raycaster.params.Points.threshold set in ToroidalTopology).
 *
 * Returns { group, update, dispose, interactiveObjects, groupMaterials }.
 */
export const FATHERS_DATA = [
  {
    id: 'kaluza',
    name: 'Theodor Kaluza (1885–1954)',
    type: 'Founding Father · 5D Unified Field Theory',
    position: [-28, 14, -22],
    color: 0xff6b9d,      // warm magenta-rose
    color2: 0xffd700,     // gold accent
    bio: 'German mathematician and physicist. In 1919, Kaluza proposed unifying gravity and electromagnetism by adding a fourth spatial dimension to Einstein\'s general relativity — creating the first five-dimensional unified field theory. His 1921 paper "Zum Unitätsproblem der Physik" showed that the 5D vacuum Einstein equations yield both 4D gravity and Maxwell\'s electromagnetism from a single geometric source. This insight — that extra dimensions can unify forces — is the foundational idea behind the Unitary Manifold.',
    significance: 'Kaluza\'s leap of imagination — adding an invisible dimension to unify physics — launched the entire enterprise of extra-dimensional geometry that culminates in the Unitary Manifold. Without his 1919 insight, there would be no Kaluza-Klein compactification, no 5D metric ansatz, and no (5, 7, 74) kernel. He is the geometric ancestor of this framework.',
    links: [
      { label: 'Kaluza-Klein Theory', path: '/repository?file=7-OUTREACH/substack/posts/post-004-kaluza-klein.md' },
      { label: 'Compactification Kernel', path: '/repository?file=COMPACTIFICATION/KERNEL_README.md' },
    ],
  },
  {
    id: 'klein',
    name: 'Oskar Klein (1894–1977)',
    type: 'Founding Father · Compactification',
    position: [28, 14, -22],
    color: 0x6bffd1,      // vibrant aqua-cyan
    color2: 0xbc8cff,      // iridescent violet
    bio: 'Swedish theoretical physicist. In 1926, Klein independently developed the five-dimensional theory and introduced the crucial idea of compactification — that the extra dimension is curled up into a circle so small it is unobservable, explaining why we experience only four dimensions. His paper "Quantentheorie und fünfdimensionale Relativitätstheorie" completed the Kaluza-Klein framework by adding the quantum-mechanical interpretation of the fifth dimension. Klein is also renowned for the Klein-Gordon equation and the Klein-Nishina formula.',
    significance: 'Klein\'s compactification — the idea that extra dimensions can be rolled up invisibly small — is the mechanism that makes Kaluza-Klein theory physically viable. The Unitary Manifold\'s entire architecture rests on this: the 5th dimension is compactified on a Z₂ orbifold with winding number n_w = 5, and all observable physics emerges from this compactified geometry. Klein gave Kaluza\'s vision a physical foundation.',
    links: [
      { label: 'Kaluza-Klein Theory', path: '/repository?file=7-OUTREACH/substack/posts/post-004-kaluza-klein.md' },
      { label: 'Winding Number Derivation', path: '/repository?file=1-THEORY/WINDING_NUMBER_DERIVATION.md' },
    ],
  },
];

export function createFoundingFathers({ scene, glowTex }) {
  const group = new THREE.Group();
  scene.add(group);
  const disposables = [];
  const interactiveObjects = [];
  const groupMaterials = [];

  const clouds = [];

  FATHERS_DATA.forEach((f, i) => {
    const particleCount = 500;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const particleData = [];

    const baseColor = new THREE.Color(f.color);
    const accentColor = new THREE.Color(f.color2);

    for (let j = 0; j < particleCount; j++) {
      // Distribute in a roughly spherical cloud with slight elongation
      const r = Math.pow(Math.random(), 0.5) * 5.0;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = r * Math.sin(phi) * Math.sin(theta) * 0.8;
      const z = r * Math.cos(phi);
      positions[j * 3] = x;
      positions[j * 3 + 1] = y;
      positions[j * 3 + 2] = z;

      // Spectral color gradient: base → accent
      const mix = Math.random();
      const c = baseColor.clone().lerp(accentColor, mix);
      const bright = 0.7 + Math.random() * 0.3;
      colors[j * 3] = c.r * bright;
      colors[j * 3 + 1] = c.g * bright;
      colors[j * 3 + 2] = c.b * bright;

      particleData.push({
        baseX: x, baseY: y, baseZ: z,
        driftPhase: Math.random() * Math.PI * 2,
        driftSpeed: 0.4 + Math.random() * 0.6,
        driftAmp: 0.12 + Math.random() * 0.28,
      });
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const mat = new THREE.PointsMaterial({
      size: 0.28,
      map: glowTex,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      sizeAttenuation: true,
    });

    const points = new THREE.Points(geo, mat);
    points.position.set(...f.position);
    points.userData = {
      id: f.id,
      type: f.type,
      name: f.name,
      description: f.bio,
      significance: f.significance,
      links: f.links,
      groupId: 'founding-fathers',
    };
    group.add(points);
    interactiveObjects.push(points);
    groupMaterials.push(mat);
    disposables.push(geo, mat);

    // Central bright core glow — anchors the cloud visually
    const coreGlowMat = new THREE.SpriteMaterial({
      map: glowTex, color: f.color, transparent: true, opacity: 0.35,
      blending: THREE.AdditiveBlending, depthWrite: false,
    });
    const coreGlow = new THREE.Sprite(coreGlowMat);
    coreGlow.position.set(...f.position);
    coreGlow.scale.setScalar(14);
    group.add(coreGlow);
    disposables.push(coreGlowMat);
    groupMaterials.push(coreGlowMat);

    clouds.push({ points, mat, coreGlow, coreGlowMat, particleData, positions, phase: i * Math.PI });
  });

  function update(t) {
    clouds.forEach((cloud) => {
      // Rhythmic pulsation — whole cloud breathes
      const pulse = 0.85 + Math.sin(t * 0.6 + cloud.phase) * 0.15;
      cloud.mat.opacity = 0.6 + Math.sin(t * 0.6 + cloud.phase) * 0.3;
      cloud.mat.size = 0.28 * pulse;
      cloud.coreGlowMat.opacity = 0.25 + Math.sin(t * 0.6 + cloud.phase) * 0.2;
      cloud.coreGlow.scale.setScalar(14 * pulse);

      // Particle drift — each particle oscillates around its base position
      const pos = cloud.positions;
      for (let i = 0; i < cloud.particleData.length; i++) {
        const pd = cloud.particleData[i];
        pos[i * 3] = pd.baseX + Math.sin(t * pd.driftSpeed + pd.driftPhase) * pd.driftAmp;
        pos[i * 3 + 1] = pd.baseY + Math.cos(t * pd.driftSpeed * 0.8 + pd.driftPhase) * pd.driftAmp;
        pos[i * 3 + 2] = pd.baseZ + Math.sin(t * pd.driftSpeed * 1.2 + pd.driftPhase) * pd.driftAmp;
      }
      cloud.points.geometry.attributes.position.needsUpdate = true;
    });
  }

  function dispose() {
    disposables.forEach(d => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects, groupMaterials };
}