import * as THREE from 'three';
import { atmosphereVertexShader, atmosphereFragmentShader } from '@/lib/topology/shaders/atmosphereScatter';
import { getAtmosphereParams, ATMOSPHERIC_BODIES } from '@/lib/topology/atmosphereData';

/**
 * AtmosphereShells — physically-based atmospheric scattering halos for planets.
 *
 * Creates a view-space halo shell (slightly larger sphere with BackSide rendering
 * and additive blending) around each atmospheric body. The shader computes
 * single-scattering Rayleigh + Mie scattering that responds dynamically to
 * the sun's position as the planet orbits.
 *
 * Airless bodies (Mercury, Moon, Io, Europa, Ceres, Pluto, etc.) get no shell.
 *
 * @param {Object} opts
 * @param {THREE.Group} opts.group — the solar system group to add shells to
 * @param {Object<string, THREE.Mesh>} opts.planetMap — planet id → mesh
 * @param {THREE.Mesh} opts.sun — the sun mesh (for direction computation)
 * @param {Array<{id: string, mesh: THREE.Mesh}>} opts.extraBodies — additional atmospheric bodies (e.g., Titan moon)
 * @returns {{ update: Function, dispose: Function, shells: Object }}
 */
export function createAtmosphereShells({ group, planetMap, sun, extraBodies = [] }) {
  const disposables = [];
  const shells = {};

  // Shared unit sphere geometry (scaled per-planet)
  const shellGeo = new THREE.SphereGeometry(1, 64, 64);
  disposables.push(shellGeo);

  // Create an atmosphere shell for each atmospheric planet
  Object.keys(planetMap).forEach((planetId) => {
    const params = getAtmosphereParams(planetId);
    if (!params) return; // Airless body — skip

    const planet = planetMap[planetId];
    const planetRadius = planet.userData.visualRadius;

    // Atmosphere shell radius
    const atmoRadius = planetRadius * (1 + params.atmosphereHeight);

    // Shader material with physical scattering parameters
    const mat = new THREE.ShaderMaterial({
      uniforms: {
        uSunDir: { value: new THREE.Vector3(1, 0, 0) },
        uCameraPos: { value: new THREE.Vector3() },
        uPlanetCenter: { value: new THREE.Vector3() },
        uPlanetRadius: { value: planetRadius },
        uAtmosphereRadius: { value: atmoRadius },
        uRayleighCoeff: { value: new THREE.Vector3(...params.rayleighCoeff) },
        uMieCoeff: { value: params.mieCoeff },
        uMieG: { value: params.mieG },
        uAtmoColor: { value: new THREE.Color(...params.atmoColor) },
        uIntensity: { value: params.intensity },
      },
      vertexShader: atmosphereVertexShader,
      fragmentShader: atmosphereFragmentShader,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.BackSide,
    });

    const shell = new THREE.Mesh(shellGeo, mat);
    shell.scale.setScalar(atmoRadius);
    shell.userData = { planetId, planetRadius, atmoRadius, params };
    group.add(shell);
    disposables.push(mat);

    shells[planetId] = { mesh: shell, material: mat, planet };
  });

  // ── Extra atmospheric bodies (moons like Titan) ──
  extraBodies.forEach(({ id, mesh: bodyMesh }) => {
    const params = getAtmosphereParams(id);
    if (!params) return;

    const bodyRadius = bodyMesh.userData.visualRadius || 0.04;
    const atmoRadius = bodyRadius * (1 + params.atmosphereHeight);

    const mat = new THREE.ShaderMaterial({
      uniforms: {
        uSunDir: { value: new THREE.Vector3(1, 0, 0) },
        uCameraPos: { value: new THREE.Vector3() },
        uPlanetCenter: { value: new THREE.Vector3() },
        uPlanetRadius: { value: bodyRadius },
        uAtmosphereRadius: { value: atmoRadius },
        uRayleighCoeff: { value: new THREE.Vector3(...params.rayleighCoeff) },
        uMieCoeff: { value: params.mieCoeff },
        uMieG: { value: params.mieG },
        uAtmoColor: { value: new THREE.Color(...params.atmoColor) },
        uIntensity: { value: params.intensity },
      },
      vertexShader: atmosphereVertexShader,
      fragmentShader: atmosphereFragmentShader,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.BackSide,
    });

    const shell = new THREE.Mesh(shellGeo, mat);
    shell.scale.setScalar(atmoRadius);
    shell.userData = { planetId: id, planetRadius: bodyRadius, atmoRadius, params };
    group.add(shell);
    disposables.push(mat);

    shells[id] = { mesh: shell, material: mat, planet: bodyMesh };
  });

  // ── Update: compute sun direction and camera position each frame ──
  const sunWorldPos = new THREE.Vector3();
  const planetWorldPos = new THREE.Vector3();
  const sunDir = new THREE.Vector3();
  const cameraPos = new THREE.Vector3();

  function update(camera) {
    // Get sun world position
    sun.getWorldPosition(sunWorldPos);

    // Get camera world position
    if (camera) {
      camera.getWorldPosition(cameraPos);
    }

    // Group scale (may change during dive tweens — read each frame)
    const groupScale = group.scale.x;

    Object.values(shells).forEach(({ mesh, material, planet }) => {
      // Get planet world position (for shader uniforms — world space)
      planet.getWorldPosition(planetWorldPos);

      // Sun direction: from planet toward sun (normalized, world space)
      sunDir.subVectors(sunWorldPos, planetWorldPos).normalize();

      // Convert local radii to world space (group scale multiplies all children)
      const worldPlanetRadius = mesh.userData.planetRadius * groupScale;
      const worldAtmoRadius = mesh.userData.atmoRadius * groupScale;

      // Update uniforms (all in world space for the shader)
      material.uniforms.uSunDir.value.copy(sunDir);
      material.uniforms.uPlanetCenter.value.copy(planetWorldPos);
      material.uniforms.uPlanetRadius.value = worldPlanetRadius;
      material.uniforms.uAtmosphereRadius.value = worldAtmoRadius;
      if (camera) {
        material.uniforms.uCameraPos.value.copy(cameraPos);
      }

      // Position the shell at the planet's LOCAL position within the group
      // (shell is a child of the group, so use local coords to avoid double-transform)
      mesh.position.copy(planet.position);

      // LOD: hide atmosphere when planet is very small on screen
      if (camera) {
        const dist = cameraPos.distanceTo(planetWorldPos);
        const angularSize = (worldPlanetRadius / dist) * 800;
        mesh.visible = angularSize > 2;
      }
    });
  }

  function dispose() {
    disposables.forEach((d) => d.dispose());
  }

  return { update, dispose, shells };
}

/**
 * Check if a body (by planet ID) has an atmosphere.
 */
export function hasAtmosphere(planetId) {
  return ATMOSPHERIC_BODIES.has(planetId);
}