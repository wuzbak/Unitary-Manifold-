import { X, Gauge, ZoomIn, Pause, Play, Orbit, Focus, Layers, Zap, Eye, EyeOff, Compass, Crosshair, Globe } from 'lucide-react';
import JoystickNavigator from './JoystickNavigator';

/**
 * ControlDeck — full navigation control deck (desktop).
 *
 * Expandable from the MiniHUD. Provides full control over:
 * - Camera orientation & traversal speed
 * - Precise manual orientation (azimuth/elevation sliders)
 * - Celestial target navigation (atmospheric planets)
 * - Time controls (pause/play, speed)
 * - Focus-target selector (overview, solar system, planets)
 * - Quality toggle (Cinematic / Balanced / Performance)
 * - Element-filter (toggle visibility of object categories)
 *
 * Design: spacecraft HUD / mission control aesthetic — monospace,
 * thin luminous borders, data-readout labels, elegant and uncluttered.
 */
export default function ControlDeck({
  open,
  onClose,
  speed, setSpeed,
  zoom, setZoom,
  paused, setPaused,
  mass, setMass,
  viewMode, setViewMode,
  setInspectTarget,
  quality, setQuality,
  elementFilter, setElementFilter,
  manualOrientation, setManualOrientation,
  orientation,
}) {
  if (!open) return null;

  const QUALITIES = [
    { key: 'cinematic', label: 'Cinematic', desc: 'Max fidelity · all effects', color: '#FF9F00' },
    { key: 'balanced', label: 'Balanced', desc: 'Recommended · adaptive', color: '#4DD0E1' },
    { key: 'performance', label: 'Performance', desc: 'Max FPS · minimal FX', color: '#3fb950' },
  ];

  const ELEMENTS = [
    { key: 'celestial', label: 'Celestial Objects', icon: Orbit },
    { key: 'pillars', label: 'Pillar Nodes', icon: Zap },
    { key: 'missions', label: 'Mission Satellites', icon: Focus },
    { key: 'solarSystem', label: 'Solar System', icon: Gauge },
    { key: 'nebulae', label: 'Volumetric Nebulae', icon: Layers },
  ];

  const FOCUS_TARGETS = [
    { key: 'overview', label: 'Manifold Overview', desc: 'Full torus view' },
    { key: 'solar-system', label: 'Solar System', desc: 'Dive into orrery' },
  ];

  // Atmospheric planets — clickable for direct planet-inspect navigation
  const ATMOSPHERIC_PLANETS = [
    { id: 'mercury', label: 'Mercury', color: '#a0826d', atmo: false },
    { id: 'venus', label: 'Venus', color: '#e8c87a', atmo: true },
    { id: 'earth', label: 'Earth', color: '#4d7ec8', atmo: true },
    { id: 'mars', label: 'Mars', color: '#c1440e', atmo: true },
    { id: 'jupiter', label: 'Jupiter', color: '#d4a373', atmo: true },
    { id: 'saturn', label: 'Saturn', color: '#e3d5a0', atmo: true },
    { id: 'uranus', label: 'Uranus', color: '#7fd4d4', atmo: true },
    { id: 'neptune', label: 'Neptune', color: '#4060e0', atmo: true },
  ];

  const isManual = manualOrientation != null;
  const handleAzimuth = (val) => {
    const cur = manualOrientation || { azimuth: orientation?.azimuth ?? 0, elevation: orientation?.elevation ?? 0 };
    setManualOrientation({ ...cur, azimuth: val });
  };
  const handleElevation = (val) => {
    const cur = manualOrientation || { azimuth: orientation?.azimuth ?? 0, elevation: orientation?.elevation ?? 0 };
    setManualOrientation({ ...cur, elevation: val });
  };
  const handleResumeAuto = () => setManualOrientation(null);

  const handlePlanetSelect = (planetId) => {
    setViewMode('planet-inspect');
    setInspectTarget(planetId);
  };

  return (
    <>
      {/* Backdrop */}
      <div className="absolute inset-0 z-40 bg-black/40 backdrop-blur-sm" onClick={onClose} />

      {/* Deck panel — right side, slides in */}
      <div className="absolute top-16 right-5 bottom-5 z-50 w-72 clip-corner bg-[#0a0a12]/95 backdrop-blur-xl border border-[#00f5ff]/30 fade-in overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#00f5ff]/15 sticky top-0 bg-[#0a0a12]/95 backdrop-blur-xl z-10">
          <div className="flex items-center gap-2">
            <Gauge size={14} className="text-[#00f5ff]" />
            <span className="text-[#00f5ff] text-xs font-bold uppercase tracking-wider">Navigation Deck</span>
          </div>
          <button onClick={onClose} className="text-[#8b949e] hover:text-[#FF9F00] transition-colors">
            <X size={16} />
          </button>
        </div>

        <div className="p-4 space-y-5">
          {/* ── Traversal Controls ── */}
          <div>
            <div className="text-[#484f58] text-[9px] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Orbit size={10} /> Traversal
            </div>
            <div className="space-y-3">
              {/* Speed */}
              <div>
                <div className="flex justify-between text-[9px] mb-1">
                  <span className="text-[#8b949e]">Speed</span>
                  <span className="text-[#00f5ff] font-mono">{speed.toFixed(2)}×</span>
                </div>
                <input
                  type="range" min="0.1" max="5" step="0.05" value={speed}
                  onChange={(e) => setSpeed(parseFloat(e.target.value))}
                  className="w-full h-1 bg-[#30363d] rounded-lg appearance-none cursor-pointer accent-[#00f5ff]"
                />
              </div>
              {/* Zoom */}
              <div>
                <div className="flex justify-between text-[9px] mb-1">
                  <span className="text-[#8b949e] flex items-center gap-1"><ZoomIn size={9} /> Zoom</span>
                  <span className="text-[#00f5ff] font-mono">{zoom.toFixed(2)}×</span>
                </div>
                <input
                  type="range" min="0.1" max="5" step="0.05" value={zoom}
                  onChange={(e) => setZoom(parseFloat(e.target.value))}
                  className="w-full h-1 bg-[#30363d] rounded-lg appearance-none cursor-pointer accent-[#00f5ff]"
                />
              </div>
              {/* Mass (inertia) */}
              <div>
                <div className="flex justify-between text-[9px] mb-1">
                  <span className="text-[#8b949e]">Inertial Mass</span>
                  <span className="text-[#00f5ff] font-mono">{mass.toFixed(1)} M</span>
                </div>
                <input
                  type="range" min="0.5" max="5" step="0.1" value={mass}
                  onChange={(e) => setMass(parseFloat(e.target.value))}
                  className="w-full h-1 bg-[#30363d] rounded-lg appearance-none cursor-pointer accent-[#00f5ff]"
                />
              </div>
              {/* Pause/Play */}
              <button
                onClick={() => setPaused(!paused)}
                className={`w-full flex items-center justify-center gap-2 py-2 rounded border text-[10px] font-bold tracking-wider transition-colors ${paused ? 'border-[#3fb950]/40 bg-[#3fb950]/10 text-[#3fb950]' : 'border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00]'}`}
              >
                {paused ? <Play size={11} /> : <Pause size={11} />}
                {paused ? 'RESUME TRAVERSAL' : 'PAUSE TRAVERSAL'}
              </button>
            </div>
          </div>

          {/* ── Camera Orientation (precise manual control) ── */}
          <div>
            <div className="text-[#484f58] text-[9px] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Compass size={10} /> Camera Orientation
              {isManual && (
                <button
                  onClick={handleResumeAuto}
                  className="ml-auto text-[8px] px-2 py-0.5 rounded border border-[#3fb950]/40 bg-[#3fb950]/10 text-[#3fb950] hover:bg-[#3fb950]/20 transition-colors font-bold"
                >
                  RESUME AUTO
                </button>
              )}
            </div>
            <div className="space-y-3">
              {/* Azimuth */}
              <div>
                <div className="flex justify-between text-[9px] mb-1">
                  <span className="text-[#8b949e]">Azimuth</span>
                  <span className="text-[#00f5ff] font-mono">{isManual ? `${manualOrientation.azimuth.toFixed(0)}°` : 'AUTO'}</span>
                </div>
                <input
                  type="range" min="0" max="360" step="1"
                  value={isManual ? manualOrientation.azimuth : (orientation?.azimuth ?? 0)}
                  onChange={(e) => handleAzimuth(parseFloat(e.target.value))}
                  className={`w-full h-1 bg-[#30363d] rounded-lg appearance-none cursor-pointer ${isManual ? 'accent-[#00f5ff]' : 'accent-[#484f58]'}`}
                />
              </div>
              {/* Elevation */}
              <div>
                <div className="flex justify-between text-[9px] mb-1">
                  <span className="text-[#8b949e]">Elevation</span>
                  <span className="text-[#00f5ff] font-mono">{isManual ? `${manualOrientation.elevation.toFixed(0)}°` : 'AUTO'}</span>
                </div>
                <input
                  type="range" min="-80" max="80" step="1"
                  value={isManual ? manualOrientation.elevation : (orientation?.elevation ?? 0)}
                  onChange={(e) => handleElevation(parseFloat(e.target.value))}
                  className={`w-full h-1 bg-[#30363d] rounded-lg appearance-none cursor-pointer ${isManual ? 'accent-[#00f5ff]' : 'accent-[#484f58]'}`}
                />
              </div>
              {!isManual && (
                <div className="text-[#484f58] text-[8px] text-center italic">Drag a slider to take manual control</div>
              )}
            </div>
          </div>

          {/* ── 3-Axis Navigator (joystick) ── */}
          <div>
            <div className="text-[#484f58] text-[9px] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Crosshair size={10} /> 3-Axis Navigator
            </div>
            <JoystickNavigator
              orientation={orientation}
              manualOrientation={manualOrientation}
              setManualOrientation={setManualOrientation}
              zoom={zoom}
              setZoom={setZoom}
            />
          </div>

          {/* ── Focus Target ── */}
          <div>
            <div className="text-[#484f58] text-[9px] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Focus size={10} /> Focus Target
            </div>
            <div className="space-y-1.5">
              {FOCUS_TARGETS.map((target) => (
                <button
                  key={target.key}
                  onClick={() => { setViewMode(target.key); setInspectTarget(null); }}
                  className={`w-full text-left px-3 py-2 rounded border text-[10px] transition-colors ${viewMode === target.key ? 'border-[#00f5ff]/40 bg-[#00f5ff]/10 text-[#00f5ff]' : 'border-[#30363d] text-[#8b949e] hover:bg-[#161b22]'}`}
                >
                  <div className="font-bold">{target.label}</div>
                  <div className="text-[8px] text-[#484f58]">{target.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* ── Celestial Targets (atmospheric planets) ── */}
          <div>
            <div className="text-[#484f58] text-[9px] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Globe size={10} /> Celestial Targets
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {ATMOSPHERIC_PLANETS.map((planet) => {
                const isActive = viewMode === 'planet-inspect' && setInspectTarget && false; // inspectTarget not available here, use visual cue only
                return (
                  <button
                    key={planet.id}
                    onClick={() => handlePlanetSelect(planet.id)}
                    className={`flex items-center gap-1.5 px-2 py-1.5 rounded border text-[9px] transition-colors ${isActive ? 'border-[#00f5ff]/40 bg-[#00f5ff]/10' : 'border-[#30363d] hover:bg-[#161b22]'}`}
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ background: planet.color, boxShadow: planet.atmo ? `0 0 4px ${planet.color}80` : 'none' }}
                    />
                    <span className="text-[#e6edf3] font-bold">{planet.label}</span>
                    {planet.atmo && <span className="ml-auto text-[6px] text-[#4DD0E1]">ATM</span>}
                  </button>
                );
              })}
            </div>
            <div className="text-[#484f58] text-[8px] mt-1.5 italic">Click any planet to dive in · ATM = has atmosphere</div>
          </div>

          {/* ── Quality ── */}
          <div>
            <div className="text-[#484f58] text-[9px] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Layers size={10} /> Render Quality
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {QUALITIES.map((q) => (
                <button
                  key={q.key}
                  onClick={() => setQuality(q.key)}
                  className={`px-2 py-2 rounded border text-center transition-colors ${quality === q.key ? 'border-2' : 'border border-[#30363d] hover:bg-[#161b22]'}`}
                  style={quality === q.key ? { borderColor: q.color, background: `${q.color}15`, color: q.color } : {}}
                >
                  <div className="text-[9px] font-bold">{q.label}</div>
                  <div className="text-[7px] text-[#484f58] mt-0.5">{q.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* ── Element Filter ── */}
          <div>
            <div className="text-[#484f58] text-[9px] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Eye size={10} /> Element Visibility
            </div>
            <div className="space-y-1.5">
              {ELEMENTS.map((el) => {
                const Icon = el.icon;
                const visible = elementFilter[el.key] !== false;
                return (
                  <button
                    key={el.key}
                    onClick={() => setElementFilter({ ...elementFilter, [el.key]: !visible })}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded border text-[10px] transition-colors ${visible ? 'border-[#00f5ff]/20 bg-[#00f5ff]/5 text-[#e6edf3]' : 'border-[#30363d] text-[#484f58]'}`}
                  >
                    <Icon size={11} className={visible ? 'text-[#00f5ff]' : ''} />
                    <span className="flex-1 text-left">{el.label}</span>
                    {visible ? <Eye size={11} className="text-[#00f5ff]" /> : <EyeOff size={11} />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}