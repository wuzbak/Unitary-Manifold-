import { useEffect } from 'react';
import { Volume2, VolumeX, Radio, Play } from 'lucide-react';
import { initSomaFm, destroySomaFm, useSomaFm, setVolume, toggleMute, handlePlayClick } from '@/lib/somaFmAudio';
import FidelitySlider from '@/components/shared/FidelitySlider';

/**
 * SomaFmPlayer — SomaFM Mission Control live stream soundscape for the topology page.
 *
 * Owns the singleton audio lifecycle (init on mount, destroy on unmount) and renders
 * the DESKTOP control panel only. The mobile audio controls now live inside the global
 * MobileBottomTabBar (driven by the same shared somaFmAudio store) so the slider is
 * integrated into the bottom navigation bar on mobile.
 */
export default function SomaFmPlayer({ hudVisible = true, deckOpen = false }) {
  const s = useSomaFm();

  useEffect(() => {
    initSomaFm();
    return () => destroySomaFm();
  }, []);

  const statusLabel = s.error ? 'SIGNAL LOST' : s.loading ? 'BUFFERING…' : '● LIVE';
  const statusColor = s.error ? '#FF9F00' : s.loading ? '#8b949e' : '#00ff88';
  const sliderColor = s.muted ? '#FF9F00' : '#00f5ff';
  const desktopHidden = !hudVisible || deckOpen;

  return (
    <div
      className="hidden lg:block absolute right-4 z-30 pointer-events-auto"
      style={{ top: 'calc(15% + 300px)', display: desktopHidden ? 'none' : undefined }}
    >
      <div className="flex flex-col gap-1.5 p-3 rounded-lg border border-[#00f5ff]/15 bg-[#0a0a12]/90 backdrop-blur-md shadow-lg shadow-[#00f5ff]/5 w-[210px] clip-corner">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 min-w-0">
            <Radio size={10} className={s.error ? 'text-[#FF9F00] shrink-0' : 'text-[#00f5ff] shrink-0'} />
            <span className="text-[8px] uppercase tracking-wider text-[#00f5ff]/50 font-bold truncate">SOMAFM · MISSION CONTROL</span>
          </div>
          {s.loading && !s.error && <span className="w-1.5 h-1.5 rounded-full bg-[#00f5ff] glow-pulse shrink-0" />}
        </div>

        <div className="text-[8px] tracking-wider font-bold" style={{ color: statusColor }}>{statusLabel}</div>

        {s.playBlocked && !s.error ? (
          <button onClick={handlePlayClick} className="merlin-pulse flex items-center justify-center gap-1.5 px-3 py-2 rounded border-2 border-[#FF9F00]/60 bg-[#FF9F00]/15 text-[#FF9F00] text-[10px] font-bold tracking-wider hover:bg-[#FF9F00]/25 transition-colors clip-corner w-full">
            <Play size={12} /> TAP TO PLAY
          </button>
        ) : !s.error && (
          <div className="flex items-center gap-2 mt-0.5">
            <button onClick={toggleMute} className={`shrink-0 transition-transform hover:scale-110 ${s.muted ? 'text-[#FF9F00]' : 'text-[#00f5ff]'}`} title={s.muted ? 'Unmute' : 'Mute'} aria-label={s.muted ? 'Unmute SomaFM' : 'Mute SomaFM'}>
              {s.muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
            <div className="flex-1">
              <FidelitySlider value={s.volume} onChange={setVolume} min={0} max={1} step={0.01} color={sliderColor} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}