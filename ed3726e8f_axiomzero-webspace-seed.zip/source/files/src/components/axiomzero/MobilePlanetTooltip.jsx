import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { X, ExternalLink, Orbit, Thermometer, Weight, Ruler, Clock, Moon, Compass } from 'lucide-react';

/**
 * MobilePlanetTooltip — mobile bottom-sheet variant of PlanetTooltip.
 * Full-width, large readable type, scrollable, swipe-down or X to dismiss.
 * Same body data shape as the desktop tooltip. lg:hidden — desktop tooltip untouched.
 */
function Row({ label, value, icon: Icon, colSpan }) {
  return (
    <div className={`flex items-center justify-between border-b border-[#00f5ff]/10 py-1 ${colSpan ? 'col-span-2' : ''}`}>
      <span className="text-[#8b949e] flex items-center gap-1 text-[11px]">
        {Icon && <Icon size={11} className="text-[#484f58]" />}
        {label}
      </span>
      <span className="text-[#00f5ff] font-bold font-mono text-[11px] text-right">{value}</span>
    </div>
  );
}

export default function MobilePlanetTooltip({ body, onClose }) {
  const startY = useRef(null);

  useEffect(() => {
    const handleEsc = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  if (!body) return null;

  const isMoon = body._kind === 'moon';
  const isSun = body._kind === 'sun';

  const onTouchStart = (e) => { startY.current = e.touches[0].clientY; };
  const onTouchMove = (e) => {
    if (startY.current == null) return;
    if (e.touches[0].clientY - startY.current > 90) { onClose(); startY.current = null; }
  };

  return (
    <>
      <div className="lg:hidden fixed inset-0 z-[160] bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div
        className="lg:hidden fixed bottom-0 left-0 right-0 z-[170] max-h-[82vh] overflow-y-auto clip-corner bg-[#0a0a12]/97 backdrop-blur-xl border-t-2 border-[#4DD0E1]/30 fade-in"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
      >
        <div className="flex justify-center pt-2.5 pb-1 shrink-0"><div className="w-10 h-1 rounded-full bg-[#00f5ff]/30" /></div>
        <div className="sticky top-0 flex items-center justify-between px-4 py-3 bg-[#0a0a12]/95 backdrop-blur-xl border-b border-[#4DD0E1]/15 z-10">
          <div className="flex-1 min-w-0">
            <div className="text-[#4DD0E1] text-[10px] uppercase tracking-wider mb-0.5">
              ▸ {isMoon ? `Moon of ${body._parentPlanet || 'Unknown'}` : body.type}
            </div>
            <div className="text-white font-bold text-base">{body.name}</div>
          </div>
          <button onClick={onClose} className="text-[#8b949e] active:text-[#FF9F00] ml-2 shrink-0 p-2" aria-label="Close">
            <X size={22} />
          </button>
        </div>

        <div className="px-4 py-3 pb-8 space-y-3">
          <div>
            <div className="text-[#4DD0E1] text-[10px] uppercase tracking-wider mb-1.5">▸ Physical Properties</div>
            <div className="grid grid-cols-2 gap-x-3">
              {body.radiusKm && <Row label="Radius" value={`${body.radiusKm.toLocaleString()} km`} icon={Ruler} />}
              {body.mass && <Row label="Mass" value={body.mass} icon={Weight} />}
              {body.density && <Row label="Density" value={`${body.density} g/cm³`} />}
              {body.gravity && <Row label="Gravity" value={`${body.gravity} m/s²`} />}
              {body.tempRange && <Row label="Surface Temp" value={body.tempRange} icon={Thermometer} />}
              {body.surfaceTemp && <Row label="Surface Temp" value={body.surfaceTemp} icon={Thermometer} />}
              {body.coreTemp && <Row label="Core Temp" value={body.coreTemp} icon={Thermometer} />}
              {body.composition && <Row label="Composition" value={body.composition} colSpan />}
              {body.age && <Row label="Age" value={body.age} icon={Clock} />}
            </div>
          </div>

          <div>
            <div className="text-[#FF9F00] text-[10px] uppercase tracking-wider mb-1.5">▸ Orbital Properties</div>
            <div className="grid grid-cols-2 gap-x-3">
              {body.semiMajorAxis && <Row label="Semi-Major Axis" value={body.semiMajorAxis} icon={Orbit} />}
              {body.orbitalPeriod && <Row label="Orbital Period" value={body.orbitalPeriod} icon={Clock} />}
              {body.orbitalPeriodDays && <Row label="Orbital Period" value={`${body.orbitalPeriodDays} days`} icon={Clock} />}
              {body.rotationPeriod && <Row label="Rotation" value={body.rotationPeriod} />}
              {body.axialTilt != null && <Row label="Axial Tilt" value={`${body.axialTilt}°`} icon={Compass} />}
              {body.semiMajorAxisKm && <Row label="Orbit Radius" value={`${body.semiMajorAxisKm.toLocaleString()} km`} icon={Orbit} />}
              {body.moonCount != null && <Row label="Known Moons" value={body.moonCount} icon={Moon} />}
              {isSun && body.rotationPeriod && <Row label="Rotation" value={body.rotationPeriod} />}
            </div>
          </div>

          <p className="text-[#e6edf3] text-sm leading-relaxed">{body.description}</p>

          {body.moons?.length > 0 && (
            <div>
              <div className="text-[#4DD0E1] text-[10px] uppercase tracking-wider mb-1.5">▸ Notable Moons ({body.moonCount} total)</div>
              <div className="space-y-1.5">
                {body.moons.map((m) => (
                  <div key={m.name} className="text-[12px] leading-relaxed">
                    <span className="text-[#00f5ff] font-bold">{m.name}</span>
                    <span className="text-[#8b949e]"> — {m.description}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {body.rings && (
            <div className="text-[12px] text-[#8fa0bc] leading-relaxed">
              <span className="text-[#FF9F00] font-bold">▸ Ring System: </span>
              Span {(body.rings.outer - body.rings.inner * 0).toFixed(1)}× radius, opacity {(body.rings.opacity * 100).toFixed(0)}%.
            </div>
          )}

          {body.significance && (
            <div>
              <div className="text-[#FF9F00] text-[10px] uppercase tracking-wider mb-1">▸ Scientific Significance</div>
              <p className="text-[#8fa0bc] text-[12px] leading-relaxed">{body.significance}</p>
            </div>
          )}

          {body.links?.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {body.links.map((link, i) => (
                <Link key={i} to={link.path} className="flex items-center gap-1.5 px-3 py-2 text-[11px] font-bold bg-[#4DD0E1]/10 border border-[#4DD0E1]/30 text-[#4DD0E1] active:bg-[#4DD0E1]/20">
                  {link.label} <ExternalLink size={11} />
                </Link>
              ))}
            </div>
          )}

          <div className="pt-2 border-t border-[#30363d] text-[9px] text-[#484f58] tracking-wider">
            Source: NASA Planetary Fact Sheet · JPL Solar System Dynamics
          </div>
        </div>
      </div>
    </>
  );
}