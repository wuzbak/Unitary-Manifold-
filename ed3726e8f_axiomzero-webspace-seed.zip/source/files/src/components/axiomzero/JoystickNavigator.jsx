import { useRef, useState, useEffect } from 'react';
import { ZoomIn, Move3d, RotateCcw } from 'lucide-react';

/**
 * JoystickNavigator — instrument-panel-style 3-axis navigator widget.
 *
 * Combines orbit (drag on the circular pad), pan (4-way cross), and zoom
 * (vertical strip) into one control, with live degree-of-freedom readouts.
 * Wired into the existing manualOrientation + zoom system shared with the
 * ControlDeck's azimuth/elevation sliders. A "release to auto" toggle
 * clears manualOrientation to return to automated camera tracking.
 *
 * Mounted inside the ControlDeck — not a separate floating panel.
 */
export default function JoystickNavigator({ orientation, manualOrientation, setManualOrientation, zoom, setZoom }) {
  const padRef = useRef(null);
  const dragRef = useRef(null);
  const [active, setActive] = useState(false);

  const az = manualOrientation?.azimuth ?? orientation?.azimuth ?? 0;
  const el = manualOrientation?.elevation ?? orientation?.elevation ?? 0;
  const dist = manualOrientation?.distance ?? orientation?.distance ?? 0;
  const panX = manualOrientation?.panX ?? 0;
  const panY = manualOrientation?.panY ?? 0;
  const isManual = manualOrientation != null;

  // Keep a ref of the latest manual state so pointer-move handlers read fresh values
  const stateRef = useRef({ azimuth: az, elevation: el, panX, panY });
  stateRef.current = { azimuth: az, elevation: el, panX, panY };

  const takeControl = () => {
    if (!isManual) {
      setManualOrientation({ azimuth: stateRef.current.azimuth, elevation: stateRef.current.elevation, panX: 0, panY: 0 });
    }
  };

  const onPadDown = (e) => {
    e.preventDefault();
    e.stopPropagation();
    takeControl();
    dragRef.current = { x: e.clientX, y: e.clientY };
    setActive(true);
  };
  const onPadMove = (e) => {
    if (!dragRef.current) return;
    const dx = e.clientX - dragRef.current.x;
    const dy = e.clientY - dragRef.current.y;
    dragRef.current = { x: e.clientX, y: e.clientY };
    const cur = stateRef.current;
    let naz = (cur.azimuth + dx * 0.4) % 360;
    if (naz < 0) naz += 360;
    const nel = Math.max(-80, Math.min(80, cur.elevation - dy * 0.4));
    setManualOrientation({ ...cur, azimuth: naz, elevation: nel });
  };
  const onPadUp = () => { dragRef.current = null; setActive(false); };

  // Global listeners so drag continues outside the pad
  useEffect(() => {
    if (!active) return;
    const move = (e) => onPadMove(e);
    const up = () => onPadUp();
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    return () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
  }, [active]);

  const pan = (dir) => {
    takeControl();
    const cur = stateRef.current;
    const step = 0.6;
    if (dir === 'left') setManualOrientation({ ...cur, panX: cur.panX - step });
    else if (dir === 'right') setManualOrientation({ ...cur, panX: cur.panX + step });
    else if (dir === 'up') setManualOrientation({ ...cur, panY: cur.panY + step });
    else if (dir === 'down') setManualOrientation({ ...cur, panY: cur.panY - step });
  };

  const releaseAuto = () => setManualOrientation(null);

  // Knob position on the orbit pad (derived from az/el)
  const knobX = Math.sin((az * Math.PI) / 180) * 38;
  const knobY = -Math.sin((el * Math.PI) / 180) * 38;

  return (
    <div className="space-y-3">
      {/* Widget body */}
      <div className="flex items-stretch gap-2.5">
        {/* Orbit pad */}
        <div className="relative shrink-0">
          <div
            ref={padRef}
            onMouseDown={onPadDown}
            className="relative w-[104px] h-[104px] rounded-full border border-[#00f5ff]/30 bg-[#0a0a12] cursor-grab touch-none clip-corner overflow-hidden"
            style={{ cursor: active ? 'grabbing' : 'grab' }}
            title="Drag to orbit · Azimuth + Elevation"
          >
            {/* Reticle rings */}
            <div className="absolute inset-2 rounded-full border border-[#00f5ff]/15" />
            <div className="absolute inset-5 rounded-full border border-[#00f5ff]/10" />
            {/* Crosshair */}
            <div className="absolute left-1/2 top-2 bottom-2 w-px bg-[#00f5ff]/15 -translate-x-1/2" />
            <div className="absolute top-1/2 left-2 right-2 h-px bg-[#00f5ff]/15 -translate-y-1/2" />
            {/* Knob */}
            <div
              className="absolute w-3 h-3 rounded-full border-2 border-[#00f5ff] bg-[#00f5ff]/20 transition-transform duration-75"
              style={{
                left: '50%', top: '50%',
                transform: `translate(calc(-50% + ${knobX}px), calc(-50% + ${knobY}px))`,
                boxShadow: '0 0 8px #00f5ff',
              }}
            />
            {/* Center dot */}
            <div className="absolute left-1/2 top-1/2 w-1 h-1 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#00f5ff]/50" />
            {/* Label */}
            <div className="absolute top-1 left-1/2 -translate-x-1/2 text-[7px] text-[#00f5ff]/50 font-bold tracking-wider">ORBIT</div>
          </div>
        </div>

        {/* Zoom strip + pan cross */}
        <div className="flex flex-col gap-2 flex-1 min-w-0">
          {/* Zoom */}
          <div className="flex items-center gap-2">
            <ZoomIn size={11} className="text-[#4DD0E1] shrink-0" />
            <input
              type="range" min="0.1" max="5" step="0.05" value={zoom}
              onChange={(e) => setZoom(parseFloat(e.target.value))}
              className="flex-1 h-1 bg-[#30363d] rounded-lg appearance-none cursor-pointer accent-[#4DD0E1] min-w-0"
            />
          </div>
          {/* Pan cross */}
          <div className="flex flex-col items-center gap-1">
            <div className="text-[7px] text-[#484f58] uppercase tracking-wider flex items-center gap-1"><Move3d size={8} /> Pan</div>
            <div className="grid grid-cols-3 gap-1">
              <span />
              <button onMouseDown={() => pan('up')} className="w-7 h-7 flex items-center justify-center border border-[#00f5ff]/25 bg-[#00f5ff]/5 text-[#00f5ff] hover:bg-[#00f5ff]/15 transition-colors clip-corner text-xs">▲</button>
              <span />
              <button onMouseDown={() => pan('left')} className="w-7 h-7 flex items-center justify-center border border-[#00f5ff]/25 bg-[#00f5ff]/5 text-[#00f5ff] hover:bg-[#00f5ff]/15 transition-colors clip-corner text-xs">◀</button>
              <button onMouseDown={() => pan('down')} className="w-7 h-7 flex items-center justify-center border border-[#00f5ff]/25 bg-[#00f5ff]/5 text-[#00f5ff] hover:bg-[#00f5ff]/15 transition-colors clip-corner text-xs">▼</button>
              <button onMouseDown={() => pan('right')} className="w-7 h-7 flex items-center justify-center border border-[#00f5ff]/25 bg-[#00f5ff]/5 text-[#00f5ff] hover:bg-[#00f5ff]/15 transition-colors clip-corner text-xs">▶</button>
            </div>
          </div>
        </div>
      </div>

      {/* DOF readouts */}
      <div className="grid grid-cols-3 gap-1 text-[8px] font-mono">
        <Readout label="AZ" value={`${az.toFixed(0).padStart(3, '0')}°`} color="#00f5ff" />
        <Readout label="EL" value={`${el.toFixed(0).padStart(3, '0')}°`} color="#00f5ff" />
        <Readout label="DIST" value={dist.toFixed(1)} color="#4DD0E1" />
        <Readout label="PAN-X" value={panX.toFixed(1)} color="#00f5ff" />
        <Readout label="PAN-Y" value={panY.toFixed(1)} color="#00f5ff" />
        <Readout label="ZOOM" value={`${zoom.toFixed(2)}×`} color="#4DD0E1" />
      </div>

      {/* Release to auto */}
      <button
        onClick={releaseAuto}
        disabled={!isManual}
        className={`w-full flex items-center justify-center gap-2 py-2 border text-[10px] font-bold tracking-wider transition-colors clip-corner ${isManual ? 'border-[#3fb950]/40 bg-[#3fb950]/10 text-[#3fb950] hover:bg-[#3fb950]/20' : 'border-[#30363d] text-[#484f58] cursor-not-allowed'}`}
      >
        <RotateCcw size={11} /> RELEASE TO AUTO
      </button>
      {!isManual && <div className="text-[#484f58] text-[8px] text-center italic">Drag the pad or pan to take manual control</div>}
    </div>
  );
}

function Readout({ label, value, color }) {
  return (
    <div className="flex flex-col items-center px-1 py-1 border border-[#00f5ff]/10 bg-[#0a0a12]/60 clip-corner">
      <span className="text-[#484f58] text-[7px] tracking-wider">{label}</span>
      <span className="font-bold" style={{ color }}>{value}</span>
    </div>
  );
}