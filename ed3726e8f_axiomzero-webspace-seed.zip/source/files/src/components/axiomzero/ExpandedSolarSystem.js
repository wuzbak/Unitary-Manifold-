import * as THREE from 'three';
import { DWARF_PLANETS, ASTEROID_BELT, KUIPER_BELT } from '@/lib/topology/expandedPlanets';
import { makeMoonTexture, makeUranusTexture } from '@/lib/topology/planetTextures';

/**
 * ExpandedSolarSystem — adds dwarf planets, asteroid belt, and Kuiper belt
 * to an existing solar system group.
 *
 * Extends the 8-planet orrery with:
 * - 5 dwarf planets (Ceres, Pluto, Haumea, Makemake, Eris) with moons
 * - Asteroid belt (200 rocks between Mars and Jupiter)
 * - Kuiper belt (300 icy bodies beyond Neptune)
 *
 * Returns { update, dispose, interactiveObjects }
 */
export function createExpandedSolarSystem({ group, disposables: externalDisposables = [] }) {
  const interactiveObjects = [];
  const bodies = [];
  const belts = [];
  const disposables = [];

  // Generate textures for dwarf planets
  const craterTex = makeMoonTexture();
  const iceTex = makeUranusTexture();
  disposables.push(craterTex, iceTex);

  const SIZE_SCALE = 1.6;
  const EARTH_PERIOD_SECONDS = 90;

  // ── Dwarf planets ──
  DWARF_PLANETS.forEach((p) => {
    // Orbit path
    const orbitPts = [];
    for (let i = 0; i <= 128; i++) {
      const a = (i / 128) * Math.PI * 2;
      orbitPts.push(new THREE.Vector3(Math.cos(a) * p.visualOrbit, 0, Math.sin(a) * p.visualOrbit));
    }
    const orbitGeo = new THREE.BufferGeometry().setFromPoints(orbitPts);
    const orbitMat = new THREE.LineBasicMaterial({ color: 0x4dd0e1, transparent: true, opacity: 0.04, blending: THREE.AdditiveBlending });
    group.add(new THREE.LineLoop(orbitGeo, orbitMat));
    disposables.push(orbitGeo, orbitMat);

    // Planet body
    const pGeo = new THREE.SphereGeometry(p.visualRadius * SIZE_SCALE, 32, 32);
    const tex = p.textureType === 'ice' ? iceTex : craterTex;
    const pMat = new THREE.MeshStandardMaterial({ map: tex, color: p.color, roughness: 0.95, metalness: 0.0 });
    const planet = new THREE.Mesh(pGeo, pMat);
    planet.userData = {
      id: `planet-${p.id}`, type: p.type, name: p.name,
      description: p.description, significance: p.significance, links: p.links,
      visualRadius: p.visualRadius * SIZE_SCALE,
      radiusKm: p.radiusKm, mass: p.mass, density: p.density, gravity: p.gravity,
      semiMajorAxis: p.semiMajorAxis, orbitalPeriod: p.orbitalPeriod,
      rotationPeriod: p.rotationPeriod, tempRange: p.tempRange, moonCount: p.moonCount,
    };
    planet.rotation.z = (p.axialTilt || 0) * Math.PI / 180;
    group.add(planet);
    disposables.push(pGeo, pMat);
    interactiveObjects.push(planet);

    // Glow
    const pGlowMat = new THREE.SpriteMaterial({ color: p.color, transparent: true, opacity: 0.25, blending: THREE.AdditiveBlending, depthWrite: false });
    const pGlow = new THREE.Sprite(pGlowMat);
    pGlow.scale.setScalar(p.visualRadius * SIZE_SCALE * 3);
    group.add(pGlow);
    disposables.push(pGlowMat);

    // Moons
    const moonMeshes = [];
    if (p.moons && p.moons.length > 0) {
      p.moons.forEach((m, mi) => {
        const mRadius = Math.max(0.008, m.visualRadius * SIZE_SCALE);
        const mGeo = new THREE.SphereGeometry(mRadius, 16, 16);
        const mMat = new THREE.MeshStandardMaterial({ map: craterTex, color: 0xffffff, roughness: 0.95, metalness: 0.0 });
        const moon = new THREE.Mesh(mGeo, mMat);
        moon.userData = {
          id: `moon-${p.id}-${m.name.toLowerCase()}`,
          type: 'Moon',
          name: m.name,
          description: m.description || `${m.name}, moon of ${p.name}`,
          significance: '',
          links: p.links,
          orbitalPeriodDays: m.orbitalPeriodDays,
          semiMajorAxisKm: m.semiMajorAxisKm,
        };
        group.add(moon);
        disposables.push(mGeo, mMat);
        interactiveObjects.push(moon);
        moonMeshes.push({ mesh: moon, orbit: m.visualOrbit, period: m.visualPeriod, phase: mi * 0.7 + 0.3 });
      });
    }

    bodies.push({
      planet, pGlow,
      orbit: p.visualOrbit, period: p.visualPeriod, phase: p.visualPhase,
      rotationSpeed: p.rotationSpeed || 0.01,
      moons: moonMeshes,
    });
  });

  // ── Asteroid belt ──
  const asteroidGroup = new THREE.Group();
  group.add(asteroidGroup);
  const asteroidGeo = new THREE.DodecahedronGeometry(0.02, 0);
  const asteroidData = [];
  for (let i = 0; i < ASTEROID_BELT.count; i++) {
    const angle = Math.random() * Math.PI * 2;
    const radius = ASTEROID_BELT.innerRadius + Math.random() * (ASTEROID_BELT.outerRadius - ASTEROID_BELT.innerRadius);
    const yOffset = (Math.random() - 0.5) * 0.3;
    const color = ASTEROID_BELT.colorVariation[i % ASTEROID_BELT.colorVariation.length];
    const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.6 });
    const rock = new THREE.Mesh(asteroidGeo, mat);
    rock.scale.setScalar(0.5 + Math.random() * 1.5);
    rock.position.set(Math.cos(angle) * radius, yOffset, Math.sin(angle) * radius);
    asteroidGroup.add(rock);
    disposables.push(mat);
    asteroidData.push({ angle, radius, yOffset, speed: 0.0005 + Math.random() * 0.001, rotSpeed: 0.01 + Math.random() * 0.02, mesh: rock });
  }
  disposables.push(asteroidGeo);

  // ── Kuiper belt ──
  const kuiperGroup = new THREE.Group();
  group.add(kuiperGroup);
  const kuiperGeo = new THREE.OctahedronGeometry(0.03, 0);
  const kuiperData = [];
  for (let i = 0; i < KUIPER_BELT.count; i++) {
    const angle = Math.random() * Math.PI * 2;
    const radius = KUIPER_BELT.innerRadius + Math.random() * (KUIPER_BELT.outerRadius - KUIPER_BELT.innerRadius);
    const yOffset = (Math.random() - 0.5) * 1.5;
    const color = KUIPER_BELT.colorVariation[i % KUIPER_BELT.colorVariation.length];
    const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.4 });
    const rock = new THREE.Mesh(kuiperGeo, mat);
    rock.scale.setScalar(0.4 + Math.random() * 1.2);
    rock.position.set(Math.cos(angle) * radius, yOffset, Math.sin(angle) * radius);
    kuiperGroup.add(rock);
    disposables.push(mat);
    kuiperData.push({ angle, radius, yOffset, speed: 0.0002 + Math.random() * 0.0005, rotSpeed: 0.005 + Math.random() * 0.01, mesh: rock });
  }
  disposables.push(kuiperGeo);

  // Interactive proxy for asteroid belt
  const beltProxyGeo = new THREE.RingGeometry(ASTEROID_BELT.innerRadius * SIZE_SCALE, ASTEROID_BELT.outerRadius * SIZE_SCALE, 64);
  const beltProxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false });
  const beltProxy = new THREE.Mesh(beltProxyGeo, beltProxyMat);
  beltProxy.rotation.x = Math.PI / 2;
  beltProxy.userData = {
    id: 'asteroid-belt',
    type: 'Asteroid Belt',
    name: 'Main Asteroid Belt',
    description: ASTEROID_BELT.description,
    significance: ASTEROID_BELT.significance,
    links: [{ label: 'Manifold Explorer', path: '/manifold-explorer' }],
    groupId: 'asteroid-belt',
    noHighlight: true,
  };
  group.add(beltProxy);
  interactiveObjects.push(beltProxy);
  disposables.push(beltProxyGeo, beltProxyMat);

  // Interactive proxy for Kuiper belt
  const kuiperProxyGeo = new THREE.RingGeometry(KUIPER_BELT.innerRadius * SIZE_SCALE, KUIPER_BELT.outerRadius * SIZE_SCALE, 64);
  const kuiperProxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false });
  const kuiperProxy = new THREE.Mesh(kuiperProxyGeo, kuiperProxyMat);
  kuiperProxy.rotation.x = Math.PI / 2;
  kuiperProxy.userData = {
    id: 'kuiper-belt',
    type: 'Kuiper Belt',
    name: 'Kuiper Belt',
    description: KUIPER_BELT.description,
    significance: KUIPER_BELT.significance,
    links: [{ label: 'Manifold Explorer', path: '/manifold-explorer' }],
    groupId: 'kuiper-belt',
    noHighlight: true,
  };
  group.add(kuiperProxy);
  interactiveObjects.push(kuiperProxy);
  disposables.push(kuiperProxyGeo, kuiperProxyMat);

  function update(t) {
    bodies.forEach((b) => {
      const angle = b.phase + (t / (b.period * EARTH_PERIOD_SECONDS * 2.5)) * Math.PI * 2;
      b.planet.position.set(Math.cos(angle) * b.orbit, 0, Math.sin(angle) * b.orbit);
      b.pGlow.position.copy(b.planet.position);
      b.planet.rotation.y += b.rotationSpeed;
      b.moons.forEach((m) => {
        const ma = m.phase + (t / (m.period * EARTH_PERIOD_SECONDS * 2.5)) * Math.PI * 2;
        m.mesh.position.set(
          b.planet.position.x + Math.cos(ma) * m.orbit,
          b.planet.position.y,
          b.planet.position.z + Math.sin(ma) * m.orbit
        );
        m.mesh.rotation.y += 0.005;
      });
    });
    asteroidData.forEach((a) => {
      a.angle += a.speed;
      a.mesh.position.set(Math.cos(a.angle) * a.radius, a.yOffset, Math.sin(a.angle) * a.radius);
      a.mesh.rotation.x += a.rotSpeed;
      a.mesh.rotation.y += a.rotSpeed * 0.7;
    });
    kuiperData.forEach((k) => {
      k.angle += k.speed;
      k.mesh.position.set(Math.cos(k.angle) * k.radius, k.yOffset, Math.sin(k.angle) * k.radius);
      k.mesh.rotation.x += k.rotSpeed;
    });
  }

  function dispose() {
    disposables.forEach((d) => d.dispose());
  }

  return { update, dispose, interactiveObjects };
}