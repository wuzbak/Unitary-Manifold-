import { useState, useEffect, useCallback } from 'react';
import { ChevronLeft, ChevronRight, X, Rocket } from 'lucide-react';
import { useLiveStatus } from '@/hooks/useLiveStatus';
import { MANUAL_SLIDES } from '@/components/axiomzero/manualSlides';

/**
 * UserManualDeck — full-screen slide deck overlay for the Topology page.
 *
 * 13 slides: 1–5 MAIN (slide 5 has the "Launch Advanced" button), 6–13 ADVANCED.
 * Next/Back navigation, slide counter, Escape always returns to the Topology
 * page. The 3D scene stays mounted underneath so return is instant.
 */
export default function UserManualDeck({ onClose }) {
  const { status, live } = useLiveStatus();
  const [slide, setSlide] = useState(0);
  const [advanced, setAdvanced] = useState(false);
  const total = MANUAL_SLIDES.length;

  const next = useCallback(() => {
    setSlide((s) => {
      // Gate at slide 5 (index 4) until Advanced is launched
      if (s === 4 && !advanced) return s;
      return Math.min(total - 1, s + 1);
    });
  }, [advanced, total]);

  const back = useCallback(() => {
    setSlide((s) => Math.max(0, s - 1));
  }, []);

  const launchAdvanced = useCallback(() => {
    setAdvanced(true);
    setSlide(5);
  }, []);

  // Keyboard navigation — Escape closes (handled globally too), arrows navigate
  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'Escape') { onClose(); return; }
      if (e.key === 'ArrowRight') next();
      else if (e.key === 'ArrowLeft') back();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [next, back, onClose]);

  const current = MANUAL_SLIDES[slide];
  const isLast = slide === total - 1;
  const atGate = slide === 4 && !advanced;

  return (
    <div className="fixed inset-0 z-[200] bg-[#050508]/97 backdrop-blur-md fade-in flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-3 bg-[#0a0a12]/95 backdrop-blur-md border-b border-[#00f5ff]/20 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-1.5 h-1.5 rounded-full bg-[#00f5ff] glow-pulse" />
          <div>
            <div className="text-[#00f5ff] text-[9px] uppercase tracking-wider">▸ AxiomZero · User Manual</div>
            <div className="text-white text-base font-bold tracking-wide">Topology Visualizer Guide</div>
          </div>
        </div>
        <button onClick={onClose} className="flex items-center gap-2 px-4 py-1.5 border border-[#00f5ff]/30 text-[#00f5ff] text-xs font-bold tracking-wider hover:bg-[#00f5ff]/10 transition-colors clip-corner">
          <X size={13} /> Close · Esc
        </button>
      </div>

      {/* Slide content */}
      <div className="flex-1 min-h-0 px-6 py-5">
        <div className="max-w-5xl mx-auto h-full">
          {current.render({ status, live, onLaunch: launchAdvanced, onClose })}
        </div>
      </div>

      {/* Navigation footer */}
      <div className="flex items-center justify-between px-6 py-3 bg-[#0a0a12]/95 backdrop-blur-md border-t border-[#00f5ff]/20 shrink-0">
        <button
          onClick={back}
          disabled={slide === 0}
          className="flex items-center gap-1.5 px-4 py-2 border border-[#00f5ff]/20 text-[#00f5ff] text-xs font-bold tracking-wider hover:bg-[#00f5ff]/10 transition-colors disabled:opacity-30 disabled:cursor-not-allowed clip-corner"
        >
          <ChevronLeft size={14} /> Back
        </button>

        {/* Slide dots */}
        <div className="flex items-center gap-1.5">
          {MANUAL_SLIDES.map((s, i) => (
            <button
              key={i}
              onClick={() => {
                // Don't jump past the gate into advanced slides before launching
                if (i > 4 && !advanced) return;
                setSlide(i);
              }}
              className={`h-1.5 transition-all ${i === slide ? 'w-6 bg-[#00f5ff]' : i > 4 && !advanced ? 'w-1.5 bg-[#30363d]' : 'w-1.5 bg-[#00f5ff]/30 hover:bg-[#00f5ff]/60'}`}
              aria-label={`Slide ${i + 1}`}
            />
          ))}
        </div>

        {isLast ? (
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-4 py-2 bg-[#00f5ff] text-black text-xs font-bold tracking-wider hover:bg-[#00f5ff]/90 transition-colors clip-corner"
          >
            <Rocket size={14} /> Launch Topology
          </button>
        ) : atGate ? (
          <button
            onClick={launchAdvanced}
            className="flex items-center gap-1.5 px-4 py-2 bg-[#FF9F00] text-black text-xs font-bold tracking-wider hover:bg-[#FF9F00]/90 transition-colors clip-corner"
          >
            <Rocket size={14} /> Launch Advanced
          </button>
        ) : (
          <button
            onClick={next}
            className="flex items-center gap-1.5 px-4 py-2 border border-[#00f5ff]/30 text-[#00f5ff] text-xs font-bold tracking-wider hover:bg-[#00f5ff]/10 transition-colors clip-corner"
          >
            Next <ChevronRight size={14} />
          </button>
        )}
      </div>
    </div>
  );
}