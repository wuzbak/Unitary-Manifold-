import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { X, ChevronRight, ChevronDown, Search, BookOpen } from 'lucide-react';
import { NAV_GROUPS, GROUP_ICONS } from '@/components/shared/SiteNav';
import { UM_STATUS } from '@/lib/umStatus';

/**
 * SiteMapOverlay — full-screen Maximum-futuristic isomorphic-glass site map.
 * Prime navigation: every page grouped with a clear one-line description,
 * a sticky live-filter search, and a pinned User Manual quick-link.
 * On mobile, groups are collapsible (tap header to expand/collapse) to reduce
 * the 40+ item scroll. Desktop keeps all groups expanded in a 3-column grid.
 * Escape, close button, or selecting a link dismisses it.
 * Rendered globally via GlobalOverlays.
 */
export default function SiteMapOverlay({ onClose }) {
  const [query, setQuery] = useState('');
  const [collapsedGroups, setCollapsedGroups] = useState(() => {
    // On mobile, start with all groups collapsed; desktop always expanded
    const map = {};
    NAV_GROUPS.forEach((g) => (map[g.label] = false));
    return map;
  });

  useEffect(() => {
    const handleEsc = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  const allItems = useMemo(
    () => NAV_GROUPS.flatMap((g) => g.items.map((i) => ({ ...i, group: g.label }))),
    []
  );
  const q = query.trim().toLowerCase();
  const filtered = q
    ? allItems.filter((i) => i.label.toLowerCase().includes(q) || i.desc.toLowerCase().includes(q))
    : [];
  const totalCount = allItems.length;

  const openManual = () => {
    onClose();
    window.dispatchEvent(new Event('user-manual-toggle'));
  };

  const toggleGroup = (label) =>
    setCollapsedGroups((prev) => ({ ...prev, [label]: !prev[label] }));

  return (
    <div className="fixed inset-0 z-[200] bg-[#050508]/95 backdrop-blur-xl fade-in overflow-y-auto">
      {/* Sticky header */}
      <div className="sticky top-0 z-10 glass-strong border-b border-[#00f5ff]/25">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 sm:py-4">
          <div className="flex items-center justify-between gap-2 sm:gap-3 mb-3">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              <div className="w-2 h-2 rounded-full bg-[#00f5ff] glow-pulse shrink-0" />
              <div className="min-w-0">
                <div className="text-[#00f5ff] text-[9px] sm:text-[10px] uppercase tracking-[0.2em] sm:tracking-[0.3em] font-bold truncate">▸ AxiomZero · {UM_STATUS.version}</div>
                <div className="text-white text-base sm:text-2xl font-bold tracking-wide">Site Map</div>
              </div>
            </div>
            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              <button
                onClick={openManual}
                className="flex items-center gap-1.5 px-2.5 sm:px-4 py-2 border border-[#FF9F00]/50 bg-[#FF9F00]/10 text-[#FF9F00] text-[11px] sm:text-xs font-bold tracking-wider hover:bg-[#FF9F00]/20 glow-hover-amber transition-all clip-corner touch-manipulation min-h-[44px]"
                aria-label="Open User Manual"
              >
                <BookOpen size={14} /> <span className="hidden sm:inline">Manual</span>
              </button>
              <button
                onClick={onClose}
                className="flex items-center gap-1.5 px-2.5 sm:px-4 py-2 border border-[#00f5ff]/50 bg-[#00f5ff]/10 text-[#00f5ff] text-[11px] sm:text-xs font-bold tracking-wider hover:bg-[#00f5ff]/20 glow-hover transition-all clip-corner touch-manipulation min-h-[44px]"
                aria-label="Close Site Map"
              >
                <X size={14} /> <span className="hidden sm:inline">Close</span>
              </button>
            </div>
          </div>

          {/* Live-filter search */}
          <div className="flex items-center gap-2 glass-panel glow-focus clip-corner transition-all px-3 py-2.5 sm:py-3">
            <Search size={16} className="text-[#00f5ff]/60 shrink-0" />
            <input
              autoFocus
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search all pages by name or function..."
              className="bg-transparent text-sm sm:text-base text-[#e6edf3] flex-1 focus:outline-none placeholder:text-[#484f58] min-w-0"
            />
            {query && (
              <button onClick={() => setQuery('')} className="text-[#484f58] hover:text-[#00f5ff] transition-colors shrink-0" aria-label="Clear search">
                <X size={16} />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
        {q ? (
          <div className="space-y-2">
            <div className="text-[#00f5ff]/70 text-xs uppercase tracking-wider mb-2">
              {filtered.length} result{filtered.length !== 1 && 's'} for "{query}"
            </div>
            {filtered.length === 0 ? (
              <div className="text-[#484f58] text-sm py-16 text-center">No pages match "{query}"</div>
            ) : (
              filtered.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={onClose}
                  className="flex items-center gap-3 px-4 py-3.5 glass-panel glow-hover clip-corner group min-h-[56px]"
                >
                  <ChevronRight size={16} className="text-[#00f5ff]/40 group-hover:text-[#00f5ff] transition-colors shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-[#e6edf3] text-base font-bold group-hover:text-[#00f5ff] transition-colors">{item.label}</div>
                    <div className="text-[#8b949e] text-xs mt-0.5 leading-snug">{item.desc}</div>
                  </div>
                  <span className="text-[#484f58] text-[10px] shrink-0 hidden sm:block uppercase tracking-wider">{item.group}</span>
                </Link>
              ))
            )}
          </div>
        ) : (
          <>
            {/* Mobile: collapsible single-column list */}
            <div className="lg:hidden space-y-2">
              {NAV_GROUPS.map((group) => {
                const GroupIcon = GROUP_ICONS[group.label];
                const isCollapsed = collapsedGroups[group.label];
                return (
                  <div key={group.label} className="glass-panel clip-corner overflow-hidden">
                    <button
                      onClick={() => toggleGroup(group.label)}
                      className="w-full px-4 py-3 border-b border-[#00f5ff]/15 bg-[#00f5ff]/5 flex items-center gap-2 touch-manipulation min-h-[48px]"
                    >
                      <GroupIcon size={16} className="text-[#00f5ff] shrink-0" />
                      <span className="text-[#00f5ff] text-sm font-bold uppercase tracking-wider flex-1 text-left">{group.label}</span>
                      <span className="text-[#484f58] text-[10px]">{group.items.length}</span>
                      {isCollapsed ? <ChevronRight size={14} className="text-[#484f58]" /> : <ChevronDown size={14} className="text-[#484f58]" />}
                    </button>
                    {!isCollapsed && (
                      <div className="py-1">
                        {group.items.map((item) => (
                          <Link
                            key={item.to}
                            to={item.to}
                            onClick={onClose}
                            className="flex items-center gap-3 px-4 py-3 active:bg-[#00f5ff]/10 transition-colors group min-h-[52px]"
                          >
                            <ChevronRight size={14} className="text-[#00f5ff]/40 group-active:text-[#00f5ff] transition-colors shrink-0" />
                            <div className="flex-1 min-w-0">
                              <div className="text-[#e6edf3] text-sm font-bold group-active:text-[#00f5ff] transition-colors">{item.label}</div>
                              <div className="text-[#8b949e] text-[11px] mt-0.5 leading-snug">{item.desc}</div>
                            </div>
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Desktop: 3-column grid, all expanded */}
            <div className="hidden lg:grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {NAV_GROUPS.map((group) => {
                const GroupIcon = GROUP_ICONS[group.label];
                return (
                  <div key={group.label} className="glass-panel clip-corner">
                    <div className="px-4 py-3 border-b border-[#00f5ff]/15 bg-[#00f5ff]/5 flex items-center gap-2">
                      <GroupIcon size={16} className="text-[#00f5ff]" />
                      <span className="text-[#00f5ff] text-sm font-bold uppercase tracking-wider">{group.label}</span>
                      <span className="text-[#484f58] text-[10px] ml-auto">{group.items.length}</span>
                    </div>
                    <div className="py-1">
                      {group.items.map((item) => (
                        <Link
                          key={item.to}
                          to={item.to}
                          onClick={onClose}
                          className="flex items-center gap-3 px-4 py-3 hover:bg-[#00f5ff]/10 transition-colors group min-h-[56px]"
                        >
                          <ChevronRight size={14} className="text-[#00f5ff]/40 group-hover:text-[#00f5ff] transition-colors shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="text-[#e6edf3] text-sm sm:text-base font-bold group-hover:text-[#00f5ff] transition-colors">{item.label}</div>
                            <div className="text-[#8b949e] text-[11px] sm:text-xs mt-0.5 leading-snug">{item.desc}</div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        <div className="text-center text-[#484f58] text-[10px] tracking-wider mt-6">
          {totalCount} pages · {NAV_GROUPS.length} groups · click any link to navigate
        </div>
      </div>
    </div>
  );
}