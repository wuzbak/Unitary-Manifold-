import * as THREE from 'three';

/**
 * SpiralGalaxy — a barred spiral galaxy with visible arm structure.
 *
 * Scientific grounding:
 *  - Central bulge: dense older stars (yellow-orange, K/M giants)
 *  - Spiral arms: density waves with younger, bluer stars (O/B/A types)
 *  - Halo: sparse old stars
 *  - Rotation: differential — inner regions rotate faster than outer
 */
export function createSpiralGalaxy({ scene, glowTex }) {
  const group = new THREE.Group();
  group.position.set(-95, 15, -65);
  group.rotation.set(0.15, 0.3, 0);

  const disposables = [];

  // ── Central bulge ──
  const bulgeCount = 1200;
  const bulgePos = new Float32Array(bulgeCount * 3);
  const bulgeCol = new Float32Array(bulgeCount * 3);
  for (let i = 0; i < bulgeCount; i++) {
    const r = Math.pow(Math.random(), 2.5) * 9;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    bulgePos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    bulgePos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta) * 0.25;
    bulgePos[i * 3 + 2] = r * Math.cos(phi);
    const c = new THREE.Color().setHSL(0.08 + Math.random() * 0.05, 0.75, 0.4 + Math.random() * 0.25);
    bulgeCol[i * 3] = c.r; bulgeCol[i * 3 + 1] = c.g; bulgeCol[i * 3 + 2] = c.b;
  }
  const bulgeGeo = new THREE.BufferGeometry();
  bulgeGeo.setAttribute('position', new THREE.BufferAttribute(bulgePos, 3));
  bulgeGeo.setAttribute('color', new THREE.BufferAttribute(bulgeCol, 3));
  const bulgeMat = new THREE.PointsMaterial({ size: 0.4, map: glowTex, vertexColors: true, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
  const bulge = new THREE.Points(bulgeGeo, bulgeMat);
  group.add(bulge);
  disposables.push(bulgeGeo, bulgeMat);

  // ── Spiral arms — density wave particles ──
  const armCount = 3;
  const armParticleCount = 7000;
  const armPos = new Float32Array(armParticleCount * 3);
  const armCol = new Float32Array(armParticleCount * 3);
  for (let i = 0; i < armParticleCount; i++) {
    const arm = i % armCount;
    const t = Math.random();
    const radius = 9 + t * 38;
    const armAngle = (arm / armCount) * Math.PI * 2;
    const spiralAngle = radius * 0.14 + armAngle;
    const spread = (Math.random() - 0.5) * 5 * (1 + t * 0.5);
    const angle = spiralAngle + spread * 0.08;
    armPos[i * 3] = Math.cos(angle) * radius + (Math.random() - 0.5) * 3;
    armPos[i * 3 + 1] = (Math.random() - 0.5) * 1.5 * (1 - t * 0.4);
    armPos[i * 3 + 2] = Math.sin(angle) * radius + (Math.random() - 0.5) * 3;
    // Arm colors: blue-white outer (young stars), yellow-white inner
    const c = new THREE.Color();
    if (t < 0.25) c.setHSL(0.1, 0.4, 0.7);
    else if (t < 0.6) c.setHSL(0.6, 0.5, 0.75);
    else c.setHSL(0.62, 0.6, 0.6 + Math.random() * 0.3);
    armCol[i * 3] = c.r; armCol[i * 3 + 1] = c.g; armCol[i * 3 + 2] = c.b;
  }
  const armGeo = new THREE.BufferGeometry();
  armGeo.setAttribute('position', new THREE.BufferAttribute(armPos, 3));
  armGeo.setAttribute('color', new THREE.BufferAttribute(armCol, 3));
  const armMat = new THREE.PointsMaterial({ size: 0.55, map: glowTex, vertexColors: true, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
  const arms = new THREE.Points(armGeo, armMat);
  group.add(arms);
  disposables.push(armGeo, armMat);

  // ── Halo — sparse old stars ──
  const haloCount = 500;
  const haloPos = new Float32Array(haloCount * 3);
  for (let i = 0; i < haloCount; i++) {
    const r = 18 + Math.random() * 17;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    haloPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    haloPos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    haloPos[i * 3 + 2] = r * Math.cos(phi);
  }
  const haloGeo = new THREE.BufferGeometry();
  haloGeo.setAttribute('position', new THREE.BufferAttribute(haloPos, 3));
  const haloMat = new THREE.PointsMaterial({ size: 0.3, map: glowTex, color: 0xffeecc, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
  const halo = new THREE.Points(haloGeo, haloMat);
  group.add(halo);
  disposables.push(haloGeo, haloMat);

  // ── Core glow ──
  const coreGlowMat = new THREE.SpriteMaterial({ map: glowTex, color: 0xffaa55, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false });
  const coreGlow = new THREE.Sprite(coreGlowMat);
  coreGlow.scale.setScalar(5);
  group.add(coreGlow);
  disposables.push(coreGlowMat);

  // ── Interactive proxy — invisible sphere for raycasting ──
  const proxyGeo = new THREE.SphereGeometry(42, 16, 16);
  const proxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
  const proxy = new THREE.Mesh(proxyGeo, proxyMat);
  proxy.userData = {
    id: 'spiral-galaxy',
    type: 'Galactic Structure',
    name: 'Spiral Galaxy',
    description: 'A barred spiral galaxy containing 100–400 billion stars, with density-wave spiral arms, a central bulge of older stars, and a dark matter halo. The arms are not fixed structures but density waves — stars pass through them, compressing gas and triggering star formation.',
    significance: 'Galactic rotation curves provide key evidence for dark matter — the flat rotation curves at large radii require a massive halo of non-luminous matter. In the Unitary Manifold framework, this constrains cosmological models including dark energy dynamics and large-scale structure formation.',
    links: [{ label: 'Cosmology & Large-Scale Structure', path: '/manifold-explorer' }],
    groupId: 'spiral-galaxy',
    noHighlight: true,
  };
  group.add(proxy);
  disposables.push(proxyGeo, proxyMat);

  scene.add(group);

  function update(t) {
    group.rotation.y += 0.0024;
    bulge.material.opacity = 0.4 + Math.sin(t * 1.0) * 0.06;
  }

  function dispose() {
    disposables.forEach(d => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects: [proxy] };
}