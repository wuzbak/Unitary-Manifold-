import * as THREE from 'three';
import { UM_STATUS } from '@/lib/umStatus';

/**
 * PillarNodes — clickable physics pillar nodes distributed on the torus.
 *
 * Represents the 981 framework pillars / 208 hardgate derivations as
 * glowing nodes positioned along the torus surface. Each is clickable
 * with an info card showing the pillar formula, status, and falsification
 * gate.
 *
 * Uses a representative subset (every Nth pillar) for visual clarity —
 * rendering all 981 as individual nodes would be visually overwhelming.
 *
 * Returns { group, update, dispose, interactiveObjects }
 */

const R = 8;
const r = 2.8;

function torusPoint(u, v) {
  return new THREE.Vector3(
    (R + r * Math.cos(v)) * Math.cos(u),
    r * Math.sin(v),
    (R + r * Math.cos(v)) * Math.sin(u)
  );
}

// Representative pillars — a curated subset showing key physics derivations
export const PILLAR_SUBSET = [
  { slot: 1, name: 'Gauge Unification', formula: 'g_U(1) = g_2 = g_3 at M_U', status: 'HARDGATE', desc: 'The unification of electromagnetic, weak, and strong coupling constants at the GUT scale, derived from the compactification geometry.' },
  { slot: 786, name: 'Neutrino Mass Ordering', formula: 'm_ν ∝ Δm²₂₁ / E', status: 'HARDGATE', desc: 'The neutrino mass hierarchy derived from Z₂ Dirichlet boundary conditions on the compactified dimensions.' },
  { slot: 788, name: 'Gravitational Wave Speed', formula: 'c_GW = c (to 10⁻¹⁵)', status: 'HARDGATE', desc: 'The speed of gravitational waves equals the speed of light, tested by LIGO/Virgo observations of neutron star mergers.' },
  { slot: 790, name: 'Dark Matter KK Tower', formula: 'ρ_DM = Σ_n m_n |ψ_n|²', status: 'HARDGATE', desc: 'Dark matter as Kaluza-Klein tower states — the mass spectrum and abundance from compactified geometry.' },
  { slot: 792, name: 'Inflation φ₀ Attractor', formula: 'V(φ) = φ₀⁴ (1 - cos(φ/φ₀))', status: 'HARDGATE', desc: 'The inflationary potential with the φ₀ attractor — predicts the spectral index and tensor-to-scalar ratio.' },
  { slot: 794, name: 'Cosmological Constant', formula: 'Λ = 3 / L_Λ² (de Sitter)', status: 'HARDGATE', desc: 'The cosmological constant from the de Sitter horizon entropy, connecting dark energy to compactification geometry.' },
  { slot: 796, name: 'Yukawa Sector', formula: 'Y_ij = f(κ_ij, θ_CKM)', status: 'FITTED', desc: 'The Yukawa couplings — currently fitted rather than top-down derived (ARCHITECTURE_LIMIT).' },
  { slot: 798, name: 'Δm²₂₁ Residual', formula: 'Δm²₂₁ ~ 1.07σ', status: 'NNLO_LIMIT', desc: 'The solar neutrino mass-squared difference residual tension at next-to-next-to-leading order.' },
  { slot: 800, name: 'MAS Wave Engine', formula: 'Λ_QCD ~ 10⁷ (mismatch)', status: 'ARCHITECTURE_LIMIT', desc: 'The MAS Wave Engine Λ_QCD order mismatch — classified as an architecture limit requiring further development.' },
  { slot: 805, name: 'Lean4 Formalization', formula: '3912 theorems verified', status: 'CERTIFIED', desc: 'The Lean4 formalization of the framework — 3,912 theorems machine-verified for mathematical rigor.' },
];

export function createPillarNodes({ scene, glowTex }) {
  const group = new THREE.Group();
  scene.add(group);
  const disposables = [];
  const interactiveObjects = [];
  const nodes = [];

  const sphereGeo = new THREE.SphereGeometry(0.15, 12, 12);
  disposables.push(sphereGeo);

  PILLAR_SUBSET.forEach((pillar, i) => {
    // Distribute around the torus
    const u = (i / PILLAR_SUBSET.length) * Math.PI * 2 + 0.3;
    const v = (i * 0.7) % (Math.PI * 2);

    const isHardgate = pillar.status === 'HARDGATE';
    const color = isHardgate ? 0xff9f00 : pillar.status === 'CERTIFIED' ? 0x3fb950 : 0x4dd0e1;

    const mat = new THREE.MeshBasicMaterial({
      color,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const mesh = new THREE.Mesh(sphereGeo, mat);
    const pos = torusPoint(u, v);
    mesh.position.copy(pos);
    mesh.scale.setScalar(0.8 + Math.random() * 0.4);
    mesh.userData = {
      id: `pillar-${pillar.slot}`,
      type: `Framework Pillar · ${pillar.status}`,
      name: `Pillar ${pillar.slot}: ${pillar.name}`,
      description: `${pillar.desc} Formula: ${pillar.formula}`,
      significance: `This is pillar ${pillar.slot} of ${UM_STATUS.pillars_total} in the Unitary Manifold framework. Status: ${pillar.status}. The full framework has ${UM_STATUS.pillars_hardgate} hardgate derivations and ${UM_STATUS.lean4_theorems.toLocaleString()} Lean4-verified theorems.`,
      links: [
        { label: 'Repository', path: '/repository' },
        { label: 'Lean4 Formalization', path: '/lean4-formalization' },
        { label: 'Falsification Lab', path: '/falsification-lab' },
      ],
      groupId: 'pillar-nodes',
      _pillarSlot: pillar.slot,
      _pillarStatus: pillar.status,
      _pillarFormula: pillar.formula,
    };
    group.add(mesh);
    interactiveObjects.push(mesh);
    disposables.push(mat);

    // Glow sprite
    const glowMat = new THREE.SpriteMaterial({
      map: glowTex,
      color,
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const glow = new THREE.Sprite(glowMat);
    glow.position.copy(pos);
    glow.scale.setScalar(1.5);
    group.add(glow);
    disposables.push(glowMat);

    nodes.push({ mesh, glow, glowMat, basePos: pos.clone(), phase: Math.random() * Math.PI * 2, color });
  });

  function update(t) {
    nodes.forEach((n) => {
      const pulse = 0.8 + Math.sin(t * 1.5 + n.phase) * 0.2;
      n.mesh.scale.setScalar(pulse * 0.9);
      n.glowMat.opacity = 0.3 + Math.sin(t * 2 + n.phase) * 0.12;
      n.glow.scale.setScalar(1.5 * pulse);
    });
  }

  function dispose() {
    disposables.forEach((d) => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects };
}