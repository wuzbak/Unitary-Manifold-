import * as THREE from 'three';
import { NAMED_OBJECTS } from '@/lib/topology/namedObjects';

/**
 * NamedObjects — distinct clickable nodes for real stars, galaxies, nebulae,
 * and clusters placed in the topology starfield. Each is a small bright sphere
 * with a glow sprite, raycastable via its core mesh.
 *
 * Returns { group, update, dispose, interactiveObjects }.
 */
export function createNamedObjects({ scene, glowTex }) {
  const group = new THREE.Group();
  scene.add(group);
  const disposables = [];
  const interactiveObjects = [];
  const objects = [];

  const sphereGeo = new THREE.SphereGeometry(0.5, 12, 12);

  NAMED_OBJECTS.forEach((obj) => {
    const [x, y, z] = obj.position;
    const baseScale = obj.scale;

    // Core — bright sphere (interactive raycast target)
    const coreMat = new THREE.MeshBasicMaterial({
      color: obj.color,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const core = new THREE.Mesh(sphereGeo, coreMat);
    core.scale.setScalar(baseScale);
    core.position.set(x, y, z);
    core.userData = {
      id: `named-${obj.name}`,
      type: obj.type,
      name: obj.name,
      description: obj.description,
      significance: obj.significance,
      links: obj.links,
      groupId: 'named-objects',
      baseScale,
      _isNamed: true,
    };
    group.add(core);
    interactiveObjects.push(core);
    disposables.push(coreMat);

    // Glow sprite
    const glowMat = new THREE.SpriteMaterial({
      map: glowTex,
      color: obj.color,
      transparent: true,
      opacity: 0.4,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const glow = new THREE.Sprite(glowMat);
    glow.position.set(x, y, z);
    glow.scale.setScalar(baseScale * 4);
    group.add(glow);
    disposables.push(glowMat);

    // Invisible hit-proxy — larger sphere for reliable clicking
    const proxyGeo = new THREE.SphereGeometry(baseScale * 2.5, 8, 8);
    const proxyMat = new THREE.MeshBasicMaterial({
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    const proxy = new THREE.Mesh(proxyGeo, proxyMat);
    proxy.position.set(x, y, z);
    proxy.userData = { ...core.userData, noHighlight: true };
    group.add(proxy);
    interactiveObjects.push(proxy);
    disposables.push(proxyGeo, proxyMat);

    objects.push({ core, glow, glowMat, baseScale, phase: Math.random() * Math.PI * 2 });
  });

  disposables.push(sphereGeo);

  function update(t) {
    objects.forEach((o) => {
      const pulse = 0.9 + Math.sin(t * 0.4 + o.phase) * 0.1;
      o.core.scale.setScalar(o.baseScale * pulse);
      o.glowMat.opacity = 0.3 + Math.sin(t * 0.8 + o.phase) * 0.12;
      o.glow.scale.setScalar(o.baseScale * 4 * pulse);
    });
  }

  function dispose() {
    disposables.forEach((d) => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects };
}