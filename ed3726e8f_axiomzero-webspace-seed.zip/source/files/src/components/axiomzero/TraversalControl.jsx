import { Pause, Play, RotateCcw } from 'lucide-react';

const PLANET_BUTTONS = [
  { id: 'sun', label: 'Sun', color: '#fff2d6' },
  { id: 'mercury', label: 'Mer', color: '#9a8c7e' },
  { id: 'venus', label: 'Ven', color: '#e6c882' },
  { id: 'earth', label: 'Earth', color: '#2e6fb8' },
  { id: 'mars', label: 'Mars', color: '#c1502e' },
  { id: 'jupiter', label: 'Jup', color: '#d8b88a' },
  { id: 'saturn', label: 'Sat', color: '#e0c896' },
  { id: 'uranus', label: 'Ura', color: '#9fd8d0' },
  { id: 'neptune', label: 'Nep', color: '#3b5bdb' },
];

function massLabel(m) {
  if (m < 0.4) return 'Light · Agile';
  if (m < 0.8) return 'Swift';
  if (m < 1.3) return 'Normal';
  if (m < 2.5) return 'Heavy · Deliberate';
  if (m < 5) return 'Massive · Inertial';
  return 'Singularity · Near-Static';
}

/**
 * FidelitySlider — custom high-fidelity slider with glow, live track fill,
 * and a scaling thumb. Uses a transparent native range input for interaction.
 */
function FidelitySlider({ value, onChange, min, max, step, color }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="relative h-4 flex items-center group">
      {/* Track */}
      <div className="absolute inset-x-0 h-1.5 rounded-full bg-[#0a0a12] border border-[#30363d]" />
      {/* Filled portion */}
      <div
        className="absolute h-1.5 rounded-full transition-all duration-75"
        style={{ width: `${pct}%`, background: color, boxShadow: `0 0 6px ${color}` }}
      />
      {/* Thumb */}
      <div
        className="absolute w-3 h-3 rounded-full border-2 bg-[#0a0a12] transition-all duration-75 group-hover:scale-125 group-active:scale-150"
        style={{ left: `calc(${pct}% - 6px)`, borderColor: color, boxShadow: `0 0 8px ${color}` }}
      />
      {/* Invisible native input */}
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
      />
    </div>
  );
}

/**
 * TraversalControl — high-fidelity control panel for toroidal topology traversal
 * and solar system inspection. Features precision sliders for speed, mass-based
 * movement inertia, and zoom. Plus planet selector (in solar system modes) and reset.
 */
export default function TraversalControl({ speed, setSpeed, zoom, setZoom, paused, setPaused, viewMode, setViewMode, setInspectTarget, mass = 1.0, setMass, onReset }) {
  const showInspect = viewMode === 'solar-system' || viewMode === 'planet-inspect';

  const handlePlanetSelect = (id) => {
    if (id === 'sun') {
      setViewMode('solar-system');
      setInspectTarget(null);
    } else {
      setInspectTarget(id);
      setViewMode('planet-inspect');
    }
  };

  return (
    <div className="hidden lg:block absolute right-4 top-[15%] z-30 pointer-events-auto">
      <div className="flex flex-col gap-2.5 p-3 rounded-lg border border-[#00f5ff]/15 bg-[#0a0a12]/90 backdrop-blur-md shadow-lg shadow-[#00f5ff]/5 w-[210px] clip-corner">
        {/* ── Traverse section ── */}
        <div>
          <div className="text-[8px] uppercase tracking-wider text-[#00f5ff]/50 font-bold mb-2 text-center">Traverse</div>

          {/* Speed slider */}
          <div className="mb-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[8px] text-[#8b949e] uppercase tracking-wider">Speed</span>
              <span className="text-[9px] text-[#00f5ff] font-mono font-bold">{speed.toFixed(2)}×</span>
            </div>
            <FidelitySlider value={speed} onChange={setSpeed} min={0.1} max={5} step={0.01} color="#00f5ff" />
          </div>

          {/* Mass slider */}
          <div className="mb-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[8px] text-[#8b949e] uppercase tracking-wider">Mass</span>
              <span className="text-[9px] text-[#FF9F00] font-mono font-bold">{mass.toFixed(1)} M</span>
            </div>
            <FidelitySlider value={mass} onChange={setMass} min={0.1} max={10} step={0.1} color="#FF9F00" />
            <div className="text-[7px] text-[#484f58] text-center mt-0.5 tracking-wider">{massLabel(mass)}</div>
          </div>

          {/* Zoom slider */}
          <div className="mb-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[8px] text-[#8b949e] uppercase tracking-wider">Zoom</span>
              <span className="text-[9px] text-[#00f5ff] font-mono font-bold">{zoom.toFixed(2)}×</span>
            </div>
            <FidelitySlider value={zoom} onChange={setZoom} min={0.1} max={5} step={0.01} color="#4DD0E1" />
          </div>

          {/* Pause/Play button */}
          <button
            onClick={() => setPaused(p => !p)}
            className={`w-full flex items-center justify-center gap-1.5 px-2 py-1.5 rounded border text-[9px] font-bold tracking-wider transition-colors ${paused ? 'border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00]' : 'border-[#00f5ff]/20 bg-[#0a0a12]/60 text-[#00f5ff]/70 hover:bg-[#00f5ff]/10 hover:text-[#00f5ff]'}`}
          >
            {paused ? <><Play size={11} /> Resume</> : <><Pause size={11} /> Pause</>}
          </button>
        </div>

        {/* ── Inspect section ── */}
        {showInspect && (
          <>
            <div className="h-px bg-[#00f5ff]/15" />
            <div>
              <div className="text-[8px] uppercase tracking-wider text-[#FF9F00]/50 font-bold mb-1.5 text-center">Inspect</div>
              <div className="grid grid-cols-3 gap-1">
                {PLANET_BUTTONS.map(p => (
                  <button
                    key={p.id}
                    onClick={() => handlePlanetSelect(p.id)}
                    className="flex flex-col items-center gap-0.5 px-1 py-1.5 rounded border border-[#30363d] bg-[#0a0a12]/60 hover:border-[#FF9F00]/40 hover:bg-[#FF9F00]/5 transition-colors group"
                    title={p.label}
                  >
                    <span
                      className="w-3 h-3 rounded-full transition-transform group-hover:scale-125"
                      style={{ background: p.color, boxShadow: `0 0 4px ${p.color}` }}
                    />
                    <span className="text-[7px] text-[#8b949e] group-hover:text-[#FF9F00] transition-colors">{p.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* ── Reset ── */}
        <div className="h-px bg-[#00f5ff]/15" />
        <button
          onClick={() => { if (onReset) onReset(); else { setViewMode('overview'); setInspectTarget(null); } }}
          className="flex items-center justify-center gap-1 px-2 py-1.5 rounded border border-[#00f5ff]/20 text-[#00f5ff]/70 hover:bg-[#00f5ff]/10 hover:text-[#00f5ff] transition-colors text-[8px] font-bold tracking-wider"
          title="Reset to fully-zoomed-out overview"
        >
          <RotateCcw size={10} /> RESET
        </button>
      </div>
    </div>
  );
}