import * as THREE from 'three';
import { MISSIONS } from '@/lib/topology/missions';

/**
 * MissionSatellites — interactive orbiting mission/observatory markers.
 *
 * Renders LISA, LiteBIRD, DESI, JUNO, Euclid as satellite models orbiting
 * the torus at different radii and tilts. Each is clickable with a rich
 * info card showing mission status, physics significance, and falsification
 * routing.
 *
 * Returns { group, update, dispose, interactiveObjects }
 */
export function createMissionSatellites({ scene, glowTex }) {
  const group = new THREE.Group();
  scene.add(group);
  const disposables = [];
  const interactiveObjects = [];
  const satellites = [];

  const bodyGeo = new THREE.OctahedronGeometry(0.3, 0);
  disposables.push(bodyGeo);

  const panelGeo = new THREE.BoxGeometry(0.8, 0.02, 0.3);
  disposables.push(panelGeo);

  MISSIONS.forEach((mission) => {
    const satGroup = new THREE.Group();

    // Main body — octahedron (satellite bus)
    const bodyMat = new THREE.MeshBasicMaterial({
      color: mission.color,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
    });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    satGroup.add(body);
    disposables.push(bodyMat);

    // Solar panels — two flat boxes on sides
    const panelMat = new THREE.MeshBasicMaterial({
      color: 0x4dd0e1,
      transparent: true,
      opacity: 0.5,
      blending: THREE.AdditiveBlending,
    });
    const panelL = new THREE.Mesh(panelGeo, panelMat);
    panelL.position.x = -0.55;
    satGroup.add(panelL);
    const panelR = new THREE.Mesh(panelGeo, panelMat.clone());
    panelR.position.x = 0.55;
    satGroup.add(panelR);
    disposables.push(panelMat, panelR.material);

    // Glow sprite
    const glowMat = new THREE.SpriteMaterial({
      map: glowTex,
      color: mission.color,
      transparent: true,
      opacity: 0.5,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const glow = new THREE.Sprite(glowMat);
    glow.scale.setScalar(mission.scale * 5);
    satGroup.add(glow);
    disposables.push(glowMat);

    // Orbit ring path
    const orbitPts = [];
    for (let i = 0; i <= 128; i++) {
      const a = (i / 128) * Math.PI * 2;
      orbitPts.push(new THREE.Vector3(
        Math.cos(a) * mission.orbitRadius,
        0,
        Math.sin(a) * mission.orbitRadius
      ));
    }
    const orbitGeo = new THREE.BufferGeometry().setFromPoints(orbitPts);
    const orbitMat = new THREE.LineBasicMaterial({
      color: mission.color,
      transparent: true,
      opacity: 0.08,
      blending: THREE.AdditiveBlending,
    });
    const orbitLine = new THREE.LineLoop(orbitGeo, orbitMat);
    orbitLine.rotation.x = mission.orbitTilt;
    group.add(orbitLine);
    disposables.push(orbitGeo, orbitMat);

    // Interactive hit-proxy
    const proxyGeo = new THREE.SphereGeometry(mission.scale * 1.5, 8, 8);
    const proxyMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
    const proxy = new THREE.Mesh(proxyGeo, proxyMat);
    proxy.userData = {
      id: `mission-${mission.id}`,
      type: mission.type,
      name: mission.name,
      description: mission.description,
      significance: mission.significance,
      links: mission.links,
      _missionStatus: mission.status,
      _missionAgency: mission.agency,
      _missionLaunch: mission.launchDate,
      groupId: 'missions',
      noHighlight: true,
    };
    satGroup.add(proxy);
    interactiveObjects.push(proxy);
    disposables.push(proxyGeo, proxyMat);

    group.add(satGroup);

    satellites.push({
      satGroup,
      body,
      glow,
      glowMat,
      orbitRadius: mission.orbitRadius,
      orbitSpeed: mission.orbitSpeed,
      orbitTilt: mission.orbitTilt,
      phase: mission.phase,
      scale: mission.scale,
      color: mission.color,
    });
  });

  function update(t) {
    satellites.forEach((s) => {
      const angle = s.phase + t * s.orbitSpeed;
      const x = Math.cos(angle) * s.orbitRadius;
      const z = Math.sin(angle) * s.orbitRadius;
      // Apply orbit tilt
      const y = z * Math.sin(s.orbitTilt);
      const zTilted = z * Math.cos(s.orbitTilt);
      s.satGroup.position.set(x, y, zTilted);
      s.body.rotation.y = t * 0.5;
      s.body.rotation.x = t * 0.3;
      const pulse = 0.9 + Math.sin(t * 2 + s.phase) * 0.1;
      s.glowMat.opacity = 0.4 + Math.sin(t * 1.5 + s.phase) * 0.15;
      s.glow.scale.setScalar(s.scale * 5 * pulse);
    });
  }

  function dispose() {
    disposables.forEach((d) => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects };
}