import { Orbit, Target, BookOpen, Map, Globe } from 'lucide-react';

/**
 * TopologyTabBar — the Topology page's in-scene tab controls.
 * Left-to-right: Topology · Mission · User Manual · Site Map.
 *
 * The "Navigate" dropdown has been removed — the global Site Map button (in
 * SiteNav) is now the prime navigation menu. The Site Map and User Manual
 * tabs dispatch global window events handled by GlobalOverlays.
 */
export default function TopologyTabBar({ onReset, onMission, onUserManual, onSiteMap, onEarth, earthActive, missionActive }) {
  const tabBase = 'px-3 py-1 pb-1 flex items-center gap-1.5 text-[10px] font-mono tracking-wider transition-colors border-b';

  return (
    <div className="hidden lg:flex absolute top-3 left-1/2 -translate-x-1/2 z-30 gap-0.5 pointer-events-auto items-center">
      {/* Topology — resets the view */}
      <button onClick={onReset} className={`${tabBase} text-white border-[#00f5ff] hover:text-[#00f5ff]`}>
        <Orbit size={11} className="text-[#00f5ff]" /> Topology
      </button>

      {/* Mission */}
      <button onClick={onMission} className={`${tabBase} ${missionActive ? 'text-[#00f5ff] border-[#00f5ff]' : 'text-white/40 border-transparent hover:text-[#00f5ff]'}`}>
        <Target size={11} /> Mission
      </button>

      {/* Earth — live hazard map view */}
      <button onClick={onEarth} className={`${tabBase} ${earthActive ? 'text-[#00f5ff] border-[#00f5ff]' : 'text-white/40 border-transparent hover:text-[#00f5ff]'}`}>
        <Globe size={11} /> Earth
      </button>

      {/* User Manual — global overlay */}
      <button onClick={onUserManual} className={`${tabBase} text-white/40 border-transparent hover:text-[#00f5ff]`}>
        <BookOpen size={11} /> User Manual
      </button>

      {/* Site Map — global overlay */}
      <button onClick={onSiteMap} className={`${tabBase} text-white/40 border-transparent hover:text-[#00f5ff]`}>
        <Map size={11} /> Site Map
      </button>
    </div>
  );
}