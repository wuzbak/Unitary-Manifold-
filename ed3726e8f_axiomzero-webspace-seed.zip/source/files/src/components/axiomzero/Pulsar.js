import * as THREE from 'three';

/**
 * Pulsar — a rapidly rotating, highly magnetized neutron star.
 *
 * Scientific grounding:
 *  - Core: ~10 km radius, ~1.4 solar masses (compressed scale)
 *  - Twin beams: radiation channeled by magnetic field, sweeping like a lighthouse
 *  - Rotation period: milliseconds to seconds (visual: ~3 rad/s)
 *  - Magnetic axis tilted from rotation axis (common in real pulsars)
 */
export function createPulsar({ scene, glowTex }) {
  const group = new THREE.Group();
  group.position.set(65, -12, -75);

  const disposables = [];

  // ── Neutron star core ──
  const coreGeo = new THREE.SphereGeometry(0.9, 24, 24);
  const coreMat = new THREE.MeshBasicMaterial({ color: 0xe0f0ff });
  const core = new THREE.Mesh(coreGeo, coreMat);
  group.add(core);
  disposables.push(coreGeo, coreMat);

  // ── Inner glow ──
  const glowMat = new THREE.SpriteMaterial({ map: glowTex, color: 0xaaccff, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false });
  const glow = new THREE.Sprite(glowMat);
  glow.scale.setScalar(4.5);
  group.add(glow);
  disposables.push(glowMat);

  // ── Outer halo ──
  const haloMat = new THREE.SpriteMaterial({ map: glowTex, color: 0x6688ff, transparent: true, opacity: 0.2, blending: THREE.AdditiveBlending, depthWrite: false });
  const halo = new THREE.Sprite(haloMat);
  halo.scale.setScalar(11);
  group.add(halo);
  disposables.push(haloMat);

  // ── Twin cone beams — lighthouse effect ──
  const beamGroup = new THREE.Group();
  group.add(beamGroup);

  const beamGeo = new THREE.ConeGeometry(2.8, 28, 32, 1, true);
  beamGeo.translate(0, 14, 0);

  const beam1Mat = new THREE.MeshBasicMaterial({ color: 0x88aaff, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false });
  const beam1 = new THREE.Mesh(beamGeo, beam1Mat);
  beamGroup.add(beam1);

  const beam2Mat = new THREE.MeshBasicMaterial({ color: 0x88aaff, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false });
  const beam2 = new THREE.Mesh(beamGeo, beam2Mat);
  beam2.rotation.x = Math.PI;
  beamGroup.add(beam2);
  disposables.push(beamGeo, beam1Mat, beam2Mat);

  // Tilt the beam axis (magnetic axis ≠ rotation axis)
  beamGroup.rotation.z = 0.45;

  // ── Interactive ──
  core.userData = {
    id: 'pulsar',
    type: 'Compact Object',
    name: 'Pulsar / Neutron Star',
    description: 'A rapidly rotating, highly magnetized neutron star — the collapsed core of a massive star after a supernova. With a radius of ~10 km and a mass of ~1.4 solar masses, it is one of the densest objects in the universe. Its magnetic field channels radiation along two beams that sweep through space like a lighthouse as the star rotates.',
    significance: 'Pulsars provide precision tests of general relativity, including gravitational wave detection via pulsar timing arrays. In the Unitary Manifold framework, neutron star structure constrains the nuclear equation of state and tests strong-field gravity predictions.',
    links: [{ label: 'Manifold Explorer', path: '/manifold-explorer' }],
    groupId: 'pulsar',
  };

  scene.add(group);

  function update(t) {
    beamGroup.rotation.y = t * 0.8;
    glow.material.opacity = 0.55 + Math.sin(t * 3) * 0.08;
    halo.material.opacity = 0.18 + Math.sin(t * 1.5) * 0.04;
  }

  function dispose() {
    disposables.forEach(d => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects: [core] };
}