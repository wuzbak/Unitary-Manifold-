import * as THREE from 'three';

/**
 * CosmicPhenomena — interactive deep-space phenomena using existing human
 * knowledge of the cosmos: dark energy (de Sitter horizon), dark matter
 * (cosmic web filaments), gravitational waves (binary merger ripples), and
 * pillar stars (clickable stars linked to Unitary-Manifold repository pillars).
 *
 * All objects are dim/distant so the torus remains the focal point.
 * Each function returns { group, update, dispose, interactiveObjects, groupMaterials }.
 */

// ── Repository pillar data (from UM_STATUS — wuzbak/Unitary-Manifold-) ──
// Early hardgate pillars (1–208) — the foundational core of the framework
// repoFile: the specific repository file to deep-link to when clicked
export const PILLAR_STARS_DATA = [
  { pillar: 4, name: 'Holographic Boundary', repoFile: 'manuscript/ch26_holographic_duality.md', description: 'The holographic principle applied to the 5D manifold boundary. The entropy-area relationship (S = A/4) constrains information capacity on the manifold boundary, connecting bulk geometry to boundary degrees of freedom.', significance: 'Holography is a cornerstone of modern theoretical physics — the idea that the information in a volume of space can be encoded on its boundary. In the Unitary Manifold, this constrains how the 5D bulk encodes 4D physics.' },
  { pillar: 5, name: 'FTUM Fixed-Point', repoFile: '1-THEORY/pillars/PILLAR_05_DERIVATION.md', description: 'The Fixed-Point Theoretical Universe Model (FTUM) — the iterative fixed-point solver that converges the 5D metric ansatz to a self-consistent solution. This pillar establishes the mathematical engine driving the manifold self-consistency.', significance: 'The FTUM is the computational heart of the framework — it iterates the metric until all fields are mutually consistent, ensuring the manifold is not just postulated but derived.' },
  { pillar: 9, name: 'Brain-Universe Attractor', repoFile: '1-THEORY/README.md', description: 'A coupled attractor model linking consciousness dynamics to cosmological geometry. The brain-universe coupling probes whether the Ξ_c consciousness constant has a geometric origin in the compactified manifold.', significance: 'This pillar explores the deep question of whether consciousness has a geometric structure — coupling neural dynamics to cosmological evolution through the manifold topology.' },
  { pillar: 10, name: 'Atomic Structure', repoFile: '1-THEORY/README.md', description: 'Geometric derivation of atomic structure from the 5D Kaluza-Klein metric. This pillar extends the manifold predictions to atomic-scale physics, testing whether the compactified geometry constrains atomic properties.', significance: 'If atomic structure can be derived from the 5D geometry rather than fitted parameters, it would be a profound confirmation that the extra dimension shapes the physical world at every scale.' },
  { pillar: 15, name: 'Cold Fusion (COP)', repoFile: '1-THEORY/README.md', description: 'A falsifiable prediction of the coefficient of performance (COP) for low-energy nuclear reactions (LENR), derived from the manifold lattice dynamics. Explicitly framed as a falsifiable prediction — NOT a confirmation that LENR occurs.', significance: 'This pillar demonstrates scientific integrity: the framework makes a testable, falsifiable prediction about a controversial phenomenon, pre-registering the conditions under which it would be disproven.' },
  { pillar: 16, name: 'φ-Debt Entropy', repoFile: 'manuscript/ch35_entropy_functional_second_law.md', description: 'The φ-debt entropy accounting framework — a recycling mechanism tracking entropy production and debt across the manifold evolution. Connects the golden ratio (φ) to thermodynamic bookkeeping in the compactified geometry.', significance: 'Entropy and the arrow of time are among the deepest puzzles in physics. This pillar links the golden ratio to entropy accounting, suggesting a geometric origin for thermodynamic irreversibility.' },
  { pillar: 17, name: 'Medicine', repoFile: '1-THEORY/README.md', description: 'Geometric medicine — applying the Unitary Manifold mathematical structure to biological and medical systems. This adjacent track explores whether the manifold topology constrains physiological and therapeutic processes.', significance: 'An adjacent research track connecting the 5D geometry to biology and medicine — a bold exploration of whether the framework that describes the cosmos can also describe living systems.' },
  { pillar: 20, name: 'Neuroscience', repoFile: '1-THEORY/README.md', description: 'Neuroscience from the manifold — the coupled brain-universe attractor extended to neural dynamics. This pillar explores whether the compactified geometry provides a framework for understanding consciousness and neural computation.', significance: 'The geometric approach to neuroscience asks whether the same topology that shapes the universe also shapes the brain — a radical hypothesis about the structure of cognition.' },
  { pillar: 24, name: 'Psychology', repoFile: '1-THEORY/README.md', description: 'Psychological structures derived from the manifold topology. This adjacent track investigates whether the geometric framework of the Unitary Manifold can model cognitive and psychological phenomena.', significance: 'An exploration of whether mathematical geometry can describe the architecture of the mind — extending the framework beyond physics into the domain of human experience.' },
  { pillar: 26, name: 'Materials', repoFile: '1-THEORY/README.md', description: 'Materials science from the 5D geometry — predicting material properties from the compactified manifold lattice dynamics. This pillar connects the KK framework to condensed matter physics.', significance: 'If material properties can be predicted from the 5D geometry, it would bridge particle physics and condensed matter — two domains that have remained largely separate in traditional physics.' },
  { pillar: 56, name: 'φ₀ Self-Consistency (CLOSED)', repoFile: 'src/core/phi0_closure.py', description: 'The φ₀ self-consistency problem — CLOSED. This pillar proved that the φ₀ attractor is self-consistent within the 5D metric ansatz, retiring a previously open problem via src/core/phi0_closure.py.', significance: 'A solved problem — the φ₀ attractor that drives inflationary dynamics was shown to be mathematically self-consistent, removing a key uncertainty from the framework.' },
  { pillar: 57, name: 'CMB Peak Amplitude', repoFile: '7-OUTREACH/substack/posts/post-065-cmb-amplitude-gap.md', description: 'The CMB acoustic peak amplitude suppression — a ×4–7 mismatch between the manifold prediction and the observed CMB power spectrum amplitude. Certified as an ARCHITECTURE_LIMIT, addressed jointly with Pillar 63.', significance: 'The CMB power spectrum is the most precise snapshot of the early universe. The amplitude mismatch is the framework most significant open empirical tension — honestly documented in FALLIBILITY.md.' },
  { pillar: 63, name: 'CMB Peak Decomposition', repoFile: '7-OUTREACH/substack/posts/post-240-s03e019-cmb-amplitude-gap-complete-accounting.md', description: 'Decomposition of the CMB peak residual into KK truncation (≤1.35%), Silk damping (0.002%), and A_s mismatch (33.6%). The irreducible A_s mismatch is certified as an ARCHITECTURE_LIMIT of the framework.', significance: 'Rather than hiding the CMB amplitude problem, this pillar decomposes it into quantified components — showing exactly how much is understood and how much remains an architectural limit.' },
  { pillar: 67, name: 'n_w = 5 Uniqueness', repoFile: '1-THEORY/WINDING_NUMBER_DERIVATION.md', description: 'The winding number n_w = 5 uniqueness proof. Steps 1–3 narrow the admissible set to {5, 7}, with Planck n_s providing the final selection. The (5, 7) braid is the unique survivor — upgrading k_CS/c_s/r from empirically selected to algebraically derived.', significance: 'The winding number n_w = 5 is the geometric seed of the entire framework. Proving its uniqueness from first principles (rather than fitting to data) is a foundational result — the (5, 7) braid is not a choice but a necessity.' },
  // Later sprint pillars (209–794)
  { pillar: 396, name: 'CMB Tensor Ratio (r)', repoFile: 'src/core/pillar396_act_r_tension_architecture_limit.py', description: 'The tensor-to-scalar ratio r = 0.0315 predicted by the Unitary Manifold sits in ~2σ tension with ACT DR6 bounds (r < 0.016). This pillar certifies the tension as an ARCHITECTURE_LIMIT — decidable by CMB-S4 (~2030).', significance: 'r measures primordial gravitational waves from inflation. Its value constrains the energy scale of inflation and the topology of the compactified manifold. A detection would confirm quantum gravitational effects in the early universe.' },
  { pillar: 486, name: 'DESI DR3 Tripwire', repoFile: 'src/core/pillar486_desi_dr3_final_prep.py', description: 'A pre-registered tripwire for the DESI DR3 measurement of the dark energy equation of state parameter w_a. If DESI DR3 confirms w_a ≠ 0 beyond 3σ, the KK prediction w_a = 0 faces falsification.', significance: 'The time-varying dark energy equation of state w_a is a critical test of whether dark energy is a pure cosmological constant (Λ) or a dynamical field. This tripwire ensures the prediction is falsifiable.' },
  { pillar: 301, name: 'DESI w_a Tension', repoFile: 'src/core/pillar301_rolling_radion_dark_energy.py', description: 'The Unitary Manifold predicts w_a = 0 (pure cosmological constant). DESI DR2 measures w_a ≠ 0 at 2.30σ tension — certified as an ARCHITECTURE_LIMIT pending DESI DR3.', significance: 'w_a parameterizes the time evolution of the dark energy equation of state. A non-zero value would challenge the pure Λ prediction and probe the geometric origin of dark energy in the compactified manifold.' },
  { pillar: 774, name: 'Neutrino Δm²₂₁', repoFile: 'src/core/pillar774_np_bc1_ac_tightening.py', description: 'The solar neutrino mass-squared difference Δm²₂₁ carries a 1.07σ residual tension above the closure threshold — classified as NNLO_ARCHITECTURE_LIMIT.', significance: 'Neutrino mass splittings probe the neutrino mass matrix structure and the Z₂ Dirichlet boundary conditions of the compactified manifold. Precision measurements test the topological origin of neutrino masses.' },
  { pillar: 792, name: 'Cosmological Constant Hierarchy', repoFile: 'src/core/pillar792_cosmological_constant_kk_vacuum.py', description: 'The 10⁵⁵ hierarchy between the Kaluza-Klein vacuum energy and the observed cosmological constant — an ARCHITECTURE_LIMIT addressed by the RS1 suppression mechanism (e⁻⁷⁴ warp factor).', significance: 'The cosmological constant problem — the enormous mismatch between quantum vacuum energy and observed dark energy — is the deepest unsolved problem in theoretical physics. The Unitary Manifold addresses it geometrically.' },
  { pillar: 793, name: 'KK Graviton Mass', repoFile: 'src/core/pillar793_graviton_mass_bound_kk.py', description: 'The first Kaluza-Klein graviton mode M_G* ≈ 1.0 TeV, with HL-LHC exclusion < 4.0 TeV — verdict PASS. The graviton mass tower is a key prediction of the compactified manifold.', significance: 'KK gravitons are massive modes of the graviton arising from extra dimensions. Their mass spectrum tests the compactification geometry and the scale of extra dimensions. LHC searches directly probe this prediction.' },
  { pillar: 790, name: 'Dark Matter KK Tower', repoFile: 'src/core/pillar790_dark_matter_kk_tower.py', description: 'A Kaluza-Klein dark matter candidate at ~1.0 TeV with scattering cross-section σ_SI = 6×10⁻⁴⁷ cm², consistent with Ω_DM ∈ [0.09, 0.14] and XENON-nT limits.', significance: 'The KK dark matter tower provides a geometric origin for dark matter — stable KK modes from the compactified extra dimensions. Direct detection experiments like XENON-nT test this prediction.' },
  { pillar: 786, name: 'Neutrino Mass Hierarchy', repoFile: 'src/core/pillar786_neutrino_mass_ordering_forward_model.py', description: 'Normal hierarchy preferred by Z₂ Dirichlet boundary conditions: m₁ = 0, m₂ = 8.6 meV, m₃ = 50.9 meV, Σmν = 0.0596 eV (Planck bound: 0.12 eV). JUNO confirms NH.', significance: 'The neutrino mass ordering and absolute mass scale probe the fundamental neutrino mass generation mechanism. The Z₂ boundary conditions of the manifold determine the hierarchy.' },
  { pillar: 787, name: 'Falsification Routing Oracle', repoFile: 'src/core/pillar787_falsification_routing_oracle.py', description: 'A routing oracle that maps 7 live experiments (LiteBIRD, DESI, JUNO, CMB-S4, HL-LHC, nEDM, XENON-nT) to their falsification targets and decision thresholds.', significance: 'Pre-registration of falsification routes ensures scientific integrity — every prediction has a defined experimental test and decision criterion. This is the Karl Popper principle made operational.' },
  { pillar: 788, name: 'Falsification Observatory', repoFile: 'src/core/pillar788_sprint_v23_regression_certificate.py', description: 'The observatory tracks the status of all 7 falsification experiments — AWAITING, TENSION, or PASS — against their target dates and decision thresholds.', significance: 'Systematic tracking of experimental tests ensures the framework remains falsifiable and empirically grounded. No prediction is left untested.' },
  { pillar: 789, name: 'Winding Stability', repoFile: 'src/core/pillar789_winding_resonance_stability_basin.py', description: 'The winding stability of the compactified manifold — topological protection against field decay through winding number conservation on the toroidal geometry.', significance: 'Winding stability ensures the topological protection of the compactified dimensions and the stability of field configurations. It is a key topological invariant of the manifold.' },
  { pillar: 791, name: 'Interrogator Module', repoFile: 'src/core/pillar791_sprint_v231_regression_certificate.py', description: 'An interrogation module for systematic scientific questioning and hypothesis testing against the Unitary Manifold framework — the v23.1 Sprint AQ engine.', significance: 'Systematic interrogation ensures rigorous testing of every prediction against empirical data and internal consistency. It automates the scientific method within the framework.' },
];

// ── Dark Energy Field — de Sitter horizon + diffuse violet cloud ──
export function createDarkEnergyField({ scene, glowTex }) {
  const group = new THREE.Group();
  group.position.set(65, 18, -85);
  scene.add(group);
  const disposables = [];
  const interactiveObjects = [];
  const groupMaterials = [];

  // de Sitter horizon — wireframe sphere (interactive)
  const horizonGeo = new THREE.SphereGeometry(14, 24, 16);
  const horizonMat = new THREE.MeshBasicMaterial({
    color: 0x9d4edd, wireframe: true, transparent: true, opacity: 0.12,
    blending: THREE.AdditiveBlending, depthWrite: false,
  });
  const horizon = new THREE.Mesh(horizonGeo, horizonMat);
  horizon.userData = {
    id: 'dark-energy',
    type: 'Cosmological Constant (Λ)',
    name: 'Dark Energy Field',
    description: 'Dark energy — the cosmological constant Λ — drives the accelerated expansion of the universe. Constituting ~68% of the total energy density, it is modeled as a uniform vacuum energy permeating all of space. This rendering shows the de Sitter horizon, the causal boundary imposed by exponential expansion.',
    significance: 'The cosmological constant problem — the 10⁵⁵ mismatch between quantum vacuum energy and observed dark energy — is the deepest unsolved problem in theoretical physics. The Unitary Manifold addresses it via the RS1 warp factor suppression (e⁻⁷⁴). DESI DR2 measures w_a ≠ 0 at 2.30σ tension against the pure Λ prediction (Pillar 301).',
    links: [
      { label: 'Radion Dark Energy', path: '/repository?file=src/core/kk_radion_dark_energy.py' },
      { label: 'Cosmological Constant', path: '/repository?file=src/core/pillar792_cosmological_constant_kk_vacuum.py' },
    ],
    groupId: 'dark-energy',
  };
  group.add(horizon);
  interactiveObjects.push(horizon);
  groupMaterials.push(horizonMat);
  disposables.push(horizonGeo, horizonMat);

  // Inner glow sphere
  const innerGeo = new THREE.SphereGeometry(10, 16, 12);
  const innerMat = new THREE.MeshBasicMaterial({
    color: 0x7b2cbf, transparent: true, opacity: 0.06,
    blending: THREE.AdditiveBlending, depthWrite: false,
  });
  const inner = new THREE.Mesh(innerGeo, innerMat);
  group.add(inner);
  groupMaterials.push(innerMat);
  disposables.push(innerGeo, innerMat);

  // Diffuse violet glow sprites
  for (let i = 0; i < 6; i++) {
    const mat = new THREE.SpriteMaterial({
      map: glowTex, color: i % 2 === 0 ? 0x9d4edd : 0xc77dff,
      transparent: true, opacity: 0.08 + Math.random() * 0.06,
      blending: THREE.AdditiveBlending, depthWrite: false,
    });
    const sp = new THREE.Sprite(mat);
    sp.position.set((Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20);
    sp.scale.setScalar(25 + Math.random() * 20);
    group.add(sp);
    disposables.push(mat);
  }

  // Expanding shell particles (accelerated expansion visualization)
  const shellCount = 200;
  const shellPos = new Float32Array(shellCount * 3);
  const shellData = [];
  for (let i = 0; i < shellCount; i++) {
    const r = 12 + Math.random() * 8;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    shellPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    shellPos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    shellPos[i * 3 + 2] = r * Math.cos(phi);
    shellData.push({ r0: r, theta, phi, speed: 0.3 + Math.random() * 0.5, phase: Math.random() });
  }
  const shellGeo = new THREE.BufferGeometry();
  shellGeo.setAttribute('position', new THREE.BufferAttribute(shellPos, 3));
  const shellMat = new THREE.PointsMaterial({
    size: 0.4, map: glowTex, color: 0xc77dff, transparent: true, opacity: 0.4,
    blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true,
  });
  const shells = new THREE.Points(shellGeo, shellMat);
  group.add(shells);
  disposables.push(shellGeo, shellMat);

  function update(t) {
    horizon.rotation.y += 0.0004;
    horizon.rotation.x += 0.0002;
    const breathe = 1 + Math.sin(t * 0.12) * 0.04;
    horizon.scale.setScalar(breathe);
    inner.scale.setScalar(breathe * 0.95);
    innerMat.opacity = 0.05 + Math.sin(t * 0.3) * 0.025;

    // Expanding shells — accelerated expansion
    const pos = shellGeo.attributes.position.array;
    for (let i = 0; i < shellCount; i++) {
      const sd = shellData[i];
      const cycle = (t * sd.speed + sd.phase) % 4;
      const r = sd.r0 + cycle * 3;
      pos[i * 3] = r * Math.sin(sd.phi) * Math.cos(sd.theta);
      pos[i * 3 + 1] = r * Math.sin(sd.phi) * Math.sin(sd.theta);
      pos[i * 3 + 2] = r * Math.cos(sd.phi);
    }
    shellGeo.attributes.position.needsUpdate = true;
    shellMat.opacity = 0.3 + Math.sin(t * 0.4) * 0.1;
  }

  function dispose() {
    disposables.forEach(d => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects, groupMaterials };
}

// ── Dark Matter Web — cosmic web filaments + halo nodes ──
export function createDarkMatterWeb({ scene }) {
  const group = new THREE.Group();
  group.position.set(-55, -22, -65);
  scene.add(group);
  const disposables = [];
  const interactiveObjects = [];
  const groupMaterials = [];

  // Generate web nodes
  const nodeCount = 18;
  const nodes = [];
  for (let i = 0; i < nodeCount; i++) {
    const r = 8 + Math.random() * 18;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    nodes.push(new THREE.Vector3(
      r * Math.sin(phi) * Math.cos(theta),
      r * Math.sin(phi) * Math.sin(theta),
      r * Math.cos(phi)
    ));
  }

  // Filaments — connect nearby nodes
  const filaments = [];
  const filamentMats = [];
  for (let i = 0; i < nodeCount; i++) {
    for (let j = i + 1; j < nodeCount; j++) {
      const dist = nodes[i].distanceTo(nodes[j]);
      if (dist < 14) {
        const pts = [nodes[i], nodes[j]];
        const geo = new THREE.BufferGeometry().setFromPoints(pts);
        const mat = new THREE.LineBasicMaterial({
          color: 0x3a1a6a, transparent: true, opacity: 0.08 + Math.random() * 0.05,
          blending: THREE.AdditiveBlending, depthWrite: false,
        });
        const line = new THREE.Line(geo, mat);
        group.add(line);
        filaments.push({ line, mat, baseOpacity: mat.opacity });
        filamentMats.push(mat);
        disposables.push(geo, mat);
      }
    }
  }

  // Interactive halo nodes (4 key halos)
  const haloGeo = new THREE.SphereGeometry(0.8, 12, 12);
  const haloData = [
    { idx: 0, name: 'Halo Alpha', mass: '~10¹² M☉' },
    { idx: 5, name: 'Halo Beta', mass: '~10¹³ M☉' },
    { idx: 10, name: 'Halo Gamma', mass: '~10¹¹ M☉' },
    { idx: 15, name: 'Halo Delta', mass: '~10¹² M☉' },
  ];
  haloData.forEach((hd) => {
    const nodePos = nodes[hd.idx];
    const mat = new THREE.MeshBasicMaterial({
      color: 0x7b2cbf, transparent: true, opacity: 0.5,
      blending: THREE.AdditiveBlending, depthWrite: false,
    });
    const halo = new THREE.Mesh(haloGeo, mat);
    halo.position.copy(nodePos);
    halo.userData = {
      id: 'dark-matter',
      type: 'Dark Matter Halo',
      name: `Dark Matter ${hd.name}`,
      description: `A gravitationally bound dark matter halo with estimated mass ${hd.mass}. Dark matter constitutes ~27% of the universe — it does not emit, absorb, or reflect light, but its gravitational effects are visible in galaxy rotation curves, gravitational lensing, and the cosmic web structure. This halo is a node in the cosmic web filament network.`,
      significance: 'The Unitary Manifold predicts a Kaluza-Klein dark matter candidate at ~1.0 TeV (Pillar 790) — stable KK modes from compactified extra dimensions provide a geometric origin for dark matter. Direct detection experiments like XENON-nT test this prediction.',
      links: [
        { label: 'Dark Matter KK Tower', path: '/repository?file=src/core/pillar790_dark_matter_kk_tower.py' },
        { label: 'Dark Matter Geometry', path: '/repository?file=src/core/dark_matter_geometry.py' },
      ],
      groupId: 'dark-matter',
    };
    group.add(halo);
    interactiveObjects.push(halo);
    groupMaterials.push(mat);
    disposables.push(mat);
  });
  disposables.push(haloGeo);

  function update(t) {
    group.rotation.y += 0.0024;
    group.rotation.z += 0.0009;
    // Filament pulse
    filaments.forEach((f, i) => {
      f.mat.opacity = f.baseOpacity + Math.sin(t * 0.8 + i * 0.4) * 0.05;
    });
    // Halo pulse
    interactiveObjects.forEach((h, i) => {
      h.material.opacity = 0.4 + Math.sin(t * 1.2 + i * 1.5) * 0.15;
      const s = 1 + Math.sin(t * 1.5 + i * 2) * 0.1;
      h.scale.setScalar(s);
    });
  }

  function dispose() {
    disposables.forEach(d => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects, groupMaterials };
}

// ── Gravitational Waves — expanding ripples from binary merger ──
export function createGravitationalWaves({ scene, glowTex }) {
  const group = new THREE.Group();
  group.position.set(48, -16, 52);
  scene.add(group);
  const disposables = [];
  const interactiveObjects = [];
  const groupMaterials = [];

  // Binary merger core (interactive)
  const coreGeo = new THREE.SphereGeometry(0.6, 16, 16);
  const coreMat = new THREE.MeshBasicMaterial({
    color: 0x00f5ff, transparent: true, opacity: 0.9,
    blending: THREE.AdditiveBlending, depthWrite: false,
  });
  const core = new THREE.Mesh(coreGeo, coreMat);
  core.userData = {
    id: 'gravitational-waves',
    type: 'Gravitational Wave Source',
    name: 'Binary Compact Merger',
    description: 'Gravitational waves — ripples in the fabric of spacetime — produced by the inspiral and merger of compact objects (black holes or neutron stars). First detected by LIGO on September 14, 2015 (GW150914), confirming Einstein\'s 1916 prediction. The expanding rings show the wavefronts propagating outward at the speed of light.',
    significance: 'Gravitational waves open a new window to the universe — multi-messenger astronomy. They probe strong-field gravity, neutron star equation of state, and the Hubble constant. The Unitary Manifold\'s graviton mass prediction (Pillar 793: M_G* ≈ 1.0 TeV) is tested by LIGO/Virgo observations of gravitational wave dispersion.',
    links: [
      { label: 'Gravitational Waves Post', path: '/repository?file=7-OUTREACH/substack/posts/post-035-gravitational-waves.md' },
      { label: 'KK Graviton Mass', path: '/repository?file=src/core/pillar793_graviton_mass_bound_kk.py' },
    ],
    groupId: 'gravitational-waves',
  };
  group.add(core);
  interactiveObjects.push(core);
  groupMaterials.push(coreMat);
  disposables.push(coreGeo, coreMat);

  // Core glow
  const glowMat = new THREE.SpriteMaterial({
    map: glowTex, color: 0x00f5ff, transparent: true, opacity: 0.5,
    blending: THREE.AdditiveBlending, depthWrite: false,
  });
  const glow = new THREE.Sprite(glowMat);
  glow.scale.setScalar(5);
  group.add(glow);
  disposables.push(glowMat);

  // Expanding ripple rings (3 phases)
  const ringCount = 4;
  const rings = [];
  const ringGeo = new THREE.RingGeometry(0.8, 1.0, 64);
  for (let i = 0; i < ringCount; i++) {
    const mat = new THREE.MeshBasicMaterial({
      color: 0x00f5ff, transparent: true, opacity: 0,
      blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false,
    });
    const ring = new THREE.Mesh(ringGeo, mat);
    ring.rotation.x = Math.PI / 2 + (Math.random() - 0.5) * 0.3;
    ring.rotation.y = Math.random() * Math.PI;
    group.add(ring);
    rings.push({ mesh: ring, mat, phase: i / ringCount });
    groupMaterials.push(mat);
    disposables.push(mat);
  }
  disposables.push(ringGeo);

  // Wave particle distortion field
  const waveCount = 150;
  const wavePos = new Float32Array(waveCount * 3);
  const waveData = [];
  for (let i = 0; i < waveCount; i++) {
    const r = 2 + Math.random() * 12;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    wavePos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    wavePos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    wavePos[i * 3 + 2] = r * Math.cos(phi);
    waveData.push({ r0: r, theta, phi });
  }
  const waveGeo = new THREE.BufferGeometry();
  waveGeo.setAttribute('position', new THREE.BufferAttribute(wavePos, 3));
  const waveMat = new THREE.PointsMaterial({
    size: 0.15, map: glowTex, color: 0x4dd0e1, transparent: true, opacity: 0.3,
    blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true,
  });
  const wavePoints = new THREE.Points(waveGeo, waveMat);
  group.add(wavePoints);
  disposables.push(waveGeo, waveMat);

  function update(t) {
    // Core pulse (slowed — interactive)
    const corePulse = 1 + Math.sin(t * 1.6) * 0.2;
    core.scale.setScalar(corePulse);
    coreMat.opacity = 0.7 + Math.sin(t * 1.6) * 0.2;
    glow.scale.setScalar(5 * corePulse);
    glowMat.opacity = 0.4 + Math.sin(t * 1.6) * 0.15;

    // Expanding ripple rings
    rings.forEach((r) => {
      const cycle = ((t * 0.3 + r.phase) % 1);
      const scale = 1 + cycle * 14;
      r.mesh.scale.setScalar(scale);
      r.mat.opacity = (1 - cycle) * 0.4;
    });

    // Wave distortion — particles oscillate radially
    const pos = waveGeo.attributes.position.array;
    for (let i = 0; i < waveCount; i++) {
      const wd = waveData[i];
      const wave = Math.sin(t * 2 - wd.r0 * 0.3) * 0.5;
      const r = wd.r0 + wave;
      pos[i * 3] = r * Math.sin(wd.phi) * Math.cos(wd.theta);
      pos[i * 3 + 1] = r * Math.sin(wd.phi) * Math.sin(wd.theta);
      pos[i * 3 + 2] = r * Math.cos(wd.phi);
    }
    waveGeo.attributes.position.needsUpdate = true;
  }

  function dispose() {
    disposables.forEach(d => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects, groupMaterials };
}

// ── Pillar Stars — clickable gold stars linked to repository pillars ──
export function createPillarStars({ scene, glowTex }) {
  const group = new THREE.Group();
  scene.add(group);
  const disposables = [];
  const interactiveObjects = [];
  const groupMaterials = [];

  const sphereGeo = new THREE.SphereGeometry(0.5, 12, 12);
  const stars = [];

  PILLAR_STARS_DATA.forEach((p, i) => {
    // Distribute in starfield at various distances
    const radius = 110 + Math.random() * 140;
    const theta = (i / PILLAR_STARS_DATA.length) * Math.PI * 2 + (Math.random() - 0.5) * 0.4;
    const phi = Math.acos(2 * Math.random() - 1);
    const x = radius * Math.sin(phi) * Math.cos(theta);
    const y = radius * Math.sin(phi) * Math.sin(theta);
    const z = radius * Math.cos(phi);

    const baseScale = 0.7 + Math.random() * 0.4;

    // Core — gold star (interactive)
    const coreMat = new THREE.MeshBasicMaterial({
      color: 0xffd700, transparent: true, opacity: 0.85,
      blending: THREE.AdditiveBlending, depthWrite: false,
    });
    const core = new THREE.Mesh(sphereGeo, coreMat);
    core.scale.setScalar(baseScale);
    core.position.set(x, y, z);
    core.userData = {
      id: `pillar-${p.pillar}`,
      type: 'Repository Pillar',
      name: `Pillar ${p.pillar} · ${p.name}`,
      description: p.description,
      significance: p.significance,
      links: [{ label: `Open Pillar File`, path: `/repository?file=${p.repoFile}` }],
      groupId: 'pillar-stars',
      baseScale,
    };
    group.add(core);
    interactiveObjects.push(core);
    groupMaterials.push(coreMat);
    disposables.push(coreMat);

    // Glow sprite
    const glowMat = new THREE.SpriteMaterial({
      map: glowTex, color: 0xffd700, transparent: true, opacity: 0.35,
      blending: THREE.AdditiveBlending, depthWrite: false,
    });
    const glow = new THREE.Sprite(glowMat);
    glow.position.copy(core.position);
    glow.scale.setScalar(3.5);
    group.add(glow);
    disposables.push(glowMat);

    stars.push({ core, glow, glowMat, baseScale, phase: Math.random() * Math.PI * 2 });
  });
  disposables.push(sphereGeo);

  function update(t) {
    stars.forEach((s) => {
      const pulse = 0.85 + Math.sin(t * 0.5 + s.phase) * 0.15;
      s.core.scale.setScalar(s.baseScale * pulse);
      s.glowMat.opacity = 0.25 + Math.sin(t * 1.2 + s.phase) * 0.12;
      s.glow.scale.setScalar(3.5 * pulse);
    });
  }

  function dispose() {
    disposables.forEach(d => d.dispose());
    scene.remove(group);
  }

  return { group, update, dispose, interactiveObjects, groupMaterials };
}