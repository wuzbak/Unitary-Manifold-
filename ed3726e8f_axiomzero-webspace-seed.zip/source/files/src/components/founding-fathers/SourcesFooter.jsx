export default function SourcesFooter() {
  const sources = [
    { label: 'University of St Andrews — MacTutor (Kaluza)', url: 'https://mathshistory.st-andrews.ac.uk/Biographies/Kaluza/' },
    { label: 'University of St Andrews — MacTutor (Klein)', url: 'https://mathshistory.st-andrews.ac.uk/Biographies/Klein_Oskar/' },
    { label: 'Dictionary of Scientific Biography — Kaluza (V.V. Raman, Scribner\'s, 1970–90)', url: 'https://mathshistory.st-andrews.ac.uk/DSB/Kaluza.pdf' },
    { label: 'Physics Today — "Oskar Klein" obituary (S. Deser, AIP, June 1977)', url: 'https://doi.org/10.1063/1.3037609' },
    { label: 'Klein (1926) — "Quantentheorie und fünfdimensionale Relativitätstheorie", Z. Phys. 37:895', url: 'https://doi.org/10.1007/BF01397481' },
    { label: 'Oskar Klein Centre, Stockholm University', url: 'https://www.su.se/english/divisions/oskar-klein-centre/about-the-okc/biography-of-oskar-klein' },
    { label: 'CERN Courier — Oskar Klein Memorial Lectures', url: 'https://cerncourier.com/a/the-oskar-klein-memorial-lectures-1988-1999/' },
    { label: 'Ravndal, F. — "Oskar Klein and the fifth dimension" (arXiv:1309.4113)', url: 'https://arxiv.org/abs/1309.4113' },
    { label: 'Kaku, M. — Hyperspace (Oxford, 1994), pp. 99–107', url: 'https://global.oup.com/' },
  ];

  return (
    <footer className="mt-12 pt-6 border-t border-[#30363d]">
      <div className="text-[#00f5ff] text-xs font-bold uppercase tracking-wider mb-3">▸ Sources & Verification</div>
      <p className="text-[10px] text-[#8b949e] leading-relaxed mb-4">
        Every biographical claim on this page was checked against the primary sources below. Where the author's original
        draft contained unverifiable or incorrect statements — including Kaluza's training at Göttingen under
        Hilbert/Minkowski (he studied at Königsberg under Meyer), Max Kaluza being a "phonetics master" (he was an
        English-language and Chaucer scholar), a WWI sound-ranging posting near Reims (unverified, omitted), and Klein
        "sheltering Walter Gordon" (he aided many refugees and Bohr's 1943 escape; Gordon is not a documented case) —
        they have been corrected or removed.
      </p>
      <ul className="grid sm:grid-cols-2 gap-1.5">
        {sources.map((s) => (
          <li key={s.url}>
            <a href={s.url} target="_blank" rel="noopener noreferrer" className="text-[10px] text-[#8b949e] hover:text-[#00f5ff] transition-colors block truncate">
              <span className="text-[#00f5ff]/60">▸</span> {s.label}
            </a>
          </li>
        ))}
      </ul>
      <div className="text-[9px] text-[#484f58] mt-4 font-mono">
        Historical images: public domain via Wikimedia Commons (Kaluza d. 1954; Klein d. 1977). Conceptual diagrams: AI-generated 2026, labeled as such.
      </div>
    </footer>
  );
}