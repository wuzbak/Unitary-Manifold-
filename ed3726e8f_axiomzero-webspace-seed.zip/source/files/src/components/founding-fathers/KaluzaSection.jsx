import { Image } from '@/components/ui/image';

export default function KaluzaSection() {
  return (
    <section className="mb-16">
      <div className="flex items-center gap-3 mb-6">
        <span className="text-[10px] font-mono text-[#00f5ff] bg-[#00f5ff]/10 border border-[#00f5ff]/30 px-2 py-1">02</span>
        <h2 className="text-xl sm:text-2xl font-bold text-[#e6edf3]">Theodor Franz Eduard Kaluza</h2>
        <span className="text-[#8b949e] text-xs font-mono hidden sm:inline">1885 – 1954 · The Classical Genesis</span>
      </div>

      {/* Portrait + intro */}
      <div className="grid md:grid-cols-3 gap-6 mb-6">
        <figure className="md:col-span-1">
          <Image
            src="https://upload.wikimedia.org/wikipedia/commons/e/e0/Theodor_Franz_Eduard_Kaluza.jpg"
            alt="Portrait of Theodor Kaluza"
            className="w-full h-72 object-cover border border-[#30363d] grayscale-[0.15]"
            fittingType="fill"
          />
          <figcaption className="text-[9px] text-[#8b949e] mt-1.5">Portrait, ca. early 20th century. Public domain.</figcaption>
        </figure>
        <div className="md:col-span-2 text-sm text-[#c9d1d9] leading-relaxed space-y-4">
          <p>
            Kaluza was born on <span className="font-mono text-[#00f5ff]">9 November 1885</span> in Wilhelmsthal, a village in
            Silesia's Prussian Province (incorporated into Oppeln — now Opole, Poland — in 1899). He was the only child of
            <strong className="text-[#e6edf3]"> Max Kaluza</strong>, a professor of the English language and a leading scholar
            of <em>Geoffrey Chaucer</em>. The elder Kaluza's discipline of linguistic structure — not, as is sometimes
            claimed, "phonetics" — shaped his son's lifelong instinct that the laws of physics were a grammar to be parsed.
          </p>
          <p>
            Kaluza entered the <strong className="text-[#e6edf3]">University of Königsberg</strong> — not Göttingen, despite a
            common misconception — and took his doctorate on <em>Tschirnhaus transformations</em> under the supervision of
            Meyer, habilitating in 1910. He then remained a <em>Privatdozent</em>, an unsalaried lecturer, for twenty years.
            The position left him with hardly any income; one person who saw far more in him was Albert Einstein.
          </p>
        </div>
      </div>

      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        In <span className="font-mono text-[#00f5ff]">April 1919</span>, teaching at Königsberg, Kaluza wrote to Einstein
        with an extraordinary idea: solve the vacuum field equations of general relativity in <em>five</em> dimensions, and
        Maxwell's electromagnetism emerges spontaneously alongside Einstein's gravity. Einstein replied that he found the
        theory "enormously" appealing — yet hesitated. The notion of a physical fifth dimension was so radical that two
        full years passed before Einstein, finally convinced, communicated Kaluza's paper to the Prussian Academy on
        <span className="font-mono text-[#00f5ff]"> 8 December 1921</span>. It appeared as
        <em className="text-[#e6edf3]"> "Zum Unitätsproblem der Physik"</em> ("On the Unity Problem of Physics").
      </p>

      {/* Pull quote */}
      <blockquote className="my-6 border-l-2 border-[#FF9F00] pl-4 py-2 bg-[#FF9F00]/5 text-[#e6edf3] italic text-sm sm:text-base">
        "…virtually unsurpassed formal unity… which could not amount to the mere alluring play of a capricious accident."
        <footer className="not-italic text-[10px] text-[#8b949e] mt-2">— Kaluza, <em>Zum Unitätsproblem der Physik</em> (1921)</footer>
      </blockquote>

      {/* The 5D miracle */}
      <h3 className="text-[#00f5ff] text-sm font-bold uppercase tracking-wider mb-3">The Five-Dimensional Miracle</h3>
      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        Kaluza imposed the <strong className="text-[#e6edf3]">cylinder condition</strong> — that no physical quantity may
        depend on the fifth coordinate — and wrote the five-dimensional line element as:
      </p>
      <div className="bg-[#0d1117] border border-[#30363d] p-4 my-4 text-center font-mono text-[#00f5ff] text-sm sm:text-base overflow-x-auto">
        ds² = g<sub>μν</sub> dx<sup>μ</sup> dx<sup>ν</sup> + φ² (A<sub>ν</sub> dx<sup>ν</sup> + dx<sup>5</sup>)²
      </div>
      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        The 5D metric spontaneously decomposes into three pieces: the 4D metric tensor <em>g<sub>μν</sub></em> (Einstein's
        gravity), the vector potential <em>A<sub>α</sub></em> (Maxwell's electromagnetism), and a scalar field
        <em> φ</em> — later called the <strong className="text-[#e6edf3]">radion</strong> or dilaton — governing the size of
        the fifth dimension. Kaluza and early readers set φ constant; as Jordan and Thiry later showed, the field equations
        actually demand a <em>dynamic</em> radion whenever the electromagnetic invariant is non-zero.
      </p>

      {/* AI diagram */}
      <figure className="my-6 border border-[#bc8cff]/20 bg-[#12161A] clip-corner">
        <Image
          src="https://media.base44.com/images/public/6a51c0830aeacd39ab86c4f0/d3f19c96e_generated_image.png"
          alt="Conceptual diagram of the Kaluza 5D metric decomposition into gravity, electromagnetism, and the radion"
          className="w-full h-56 sm:h-72 object-cover"
          fittingType="fill"
        />
        <figcaption className="px-3 py-2 text-[9px] sm:text-[10px] text-[#8b949e] border-t border-[#30363d]">
          The 5D metric splits into gravity (g<sub>μν</sub>), electromagnetism (A<sub>μ</sub>), and the radion (φ).
          <span className="text-[#bc8cff]"> Modern rendering — AI-generated conceptual diagram (2026).</span>
        </figcaption>
      </figure>

      {/* Later years */}
      <h3 className="text-[#00f5ff] text-sm font-bold uppercase tracking-wider mb-3 mt-6">Later Years & Cognitive Discipline</h3>
      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        Recognition came slowly. Only in <span className="font-mono text-[#00f5ff]">1929</span> — two decades into his
        Privatdozentship — was Kaluza appointed professor at Kiel, and in <span className="font-mono text-[#00f5ff]">1935</span> a
        full professor at Göttingen, where he remained until his death. He refused Nazi ideology; his Göttingen appointment
        was secured only with difficulty and the assistance of his colleague <strong className="text-[#e6edf3]">Helmut Hasse</strong>.
        His finest mathematical work was the textbook <em>Höhere Mathematik für den Praktiker</em> (1938), co-written with Georg Joos.
      </p>
      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        Kaluza was a man of "wide-ranging interests" — in his son's account, he studied <strong className="text-[#e6edf3]">more
        than fifteen languages</strong>, including Hebrew, Hungarian, Arabic, and Lithuanian, and possessed "a keen sense of
        humour." The most famous anecdote captures his faith in theory over practice: a nonswimmer into his thirties, he
        read a book on swimming, then demonstrated, in his son's words, "the power of theoretical knowledge" by swimming
        successfully on his first attempt in the water. He died in Göttingen on
        <span className="font-mono text-[#00f5ff]"> 19 January 1954</span>, two months before he was due to retire.
      </p>
    </section>
  );
}