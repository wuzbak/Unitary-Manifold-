import { Link } from 'react-router-dom';
import { useLiveStatus } from '@/hooks/useLiveStatus';

export default function LegacySection() {
  const { status } = useLiveStatus();

  return (
    <section className="mb-16">
      <div className="flex items-center gap-3 mb-6">
        <span className="text-[10px] font-mono text-[#00f5ff] bg-[#00f5ff]/10 border border-[#00f5ff]/30 px-2 py-1">04</span>
        <h2 className="text-xl sm:text-2xl font-bold text-[#e6edf3]">The Synthesis, Its Limits, and the Living Legacy</h2>
      </div>

      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        The label <em>"Kaluza-Klein"</em> now describes <em>any</em> theory that compactifies extra dimensions. Their
        synthesis married the large-scale geometry of Einstein with the small-scale reality of the atom: forces of nature
        as the shadows of a higher-dimensional geometry. But the original 5D theory could not become a complete "Theory of
        Everything." Three roadblocks stand in the way:
      </p>

      <div className="grid sm:grid-cols-3 gap-3 my-6">
        <div className="border border-[#ff3b30]/30 bg-[#ff3b30]/5 p-4">
          <div className="text-[#ff3b30] text-xs font-bold uppercase tracking-wider mb-2">Mass Hierarchy</div>
          <div className="text-[11px] text-[#c9d1d9] leading-relaxed">
            The KK tower places excited modes near the compactification scale (~10¹⁹ GeV), billions of times the observed
            electron mass of 0.5 MeV.
          </div>
        </div>
        <div className="border border-[#ff9f0a]/30 bg-[#ff9f0a]/5 p-4">
          <div className="text-[#ff9f0a] text-xs font-bold uppercase tracking-wider mb-2">Chiral Fermions</div>
          <div className="text-[11px] text-[#c9d1d9] leading-relaxed">
            Five-dimensional reductions yield parity-preserving (non-chiral) theories. Our universe is chiral and
            parity-violating — a mismatch the original model cannot easily resolve.
          </div>
        </div>
        <div className="border border-[#bc8cff]/30 bg-[#bc8cff]/5 p-4">
          <div className="text-[#bc8cff] text-xs font-bold uppercase tracking-wider mb-2">Non-Abelian Gauge</div>
          <div className="text-[11px] text-[#c9d1d9] leading-relaxed">
            A single extra dimension yields only U(1). The SU(2) and SU(3) of the weak and strong forces require more — the
            thrust of Witten's 1981 "Search for a Realistic Kaluza-Klein Theory."
          </div>
        </div>
      </div>

      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        Modern descendants bypass these limits with richer compactification spaces: string theory's six-dimensional
        <em> Calabi-Yau</em> manifolds, M-theory's seven-dimensional <em>G₂</em> holonomy spaces. The architectural insight of
        Kaluza and Klein — that gauge symmetry is the geometry of hidden dimensions — remains the load-bearing wall of
        theoretical physics to this day.
      </p>

      {/* Bridge to Unitary Manifold */}
      <div className="mt-8 border-l-2 border-[#FF9F00] pl-4 sm:pl-6 py-2">
        <div className="text-[10px] text-[#FF9F00] tracking-[0.3em] font-bold mb-2 uppercase">From 1921 to the Unitary Manifold</div>
        <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
          The <strong className="text-[#e6edf3]">Unitary Manifold</strong> framework — the repository at the heart of this
          platform — is a direct descendant of the Kaluza-Klein programme. It models physics as a 5D Kaluza-Klein gauge
          geometry, treats the <em>radion/dilaton</em> field φ as a live dynamical degree of freedom (visualized as the
          central radion node in the Topology), and carries the founding fathers' memorial nodes within the toroidal
          manifold itself. The current build stands at version
          <span className="font-mono text-[#00f5ff]"> {status.version}</span>, with
          <span className="font-mono text-[#00f5ff]"> {status.lean4_theorems?.toLocaleString()}</span> Lean4-verified theorems
          and <span className="font-mono text-[#00f5ff]">{status.pillars_total}</span> derivation pillars.
        </p>
        <div className="flex flex-wrap gap-2 mt-4">
          <Link to="/manifold-explorer" className="px-3 py-2 border border-[#00f5ff]/40 bg-[#00f5ff]/5 text-[#00f5ff] text-xs font-bold hover:bg-[#00f5ff]/10 transition-colors">▸ Repository</Link>
          <Link to="/manifold-explorer" className="px-3 py-2 border border-[#00f5ff]/40 bg-[#00f5ff]/5 text-[#00f5ff] text-xs font-bold hover:bg-[#00f5ff]/10 transition-colors">▸ Manifold Explorer</Link>
          <Link to="/axiom-os-core" className="px-3 py-2 border border-[#00f5ff]/40 bg-[#00f5ff]/5 text-[#00f5ff] text-xs font-bold hover:bg-[#00f5ff]/10 transition-colors">▸ Compactification</Link>
        </div>
        <div className="text-[10px] text-[#8b949e] mt-4 font-mono">
          Citation: Walker-Pearson (2026), Unitary Manifold v{status.version} · Zenodo DOI · github.com/Unitary-Manifold
        </div>
      </div>
    </section>
  );
}