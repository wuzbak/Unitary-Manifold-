import { Image } from '@/components/ui/image';

export default function KleinSection() {
  return (
    <section className="mb-16">
      <div className="flex items-center gap-3 mb-6">
        <span className="text-[10px] font-mono text-[#00f5ff] bg-[#00f5ff]/10 border border-[#00f5ff]/30 px-2 py-1">03</span>
        <h2 className="text-xl sm:text-2xl font-bold text-[#e6edf3]">Oskar Benjamin Klein</h2>
        <span className="text-[#8b949e] text-xs font-mono hidden sm:inline">1894 – 1977 · The Quantum Transition</span>
      </div>

      {/* Portrait + intro */}
      <div className="grid md:grid-cols-3 gap-6 mb-6">
        <figure className="md:col-span-1">
          <Image
            src="https://upload.wikimedia.org/wikipedia/commons/5/54/OskarKlein.jpg"
            alt="Portrait of Oskar Klein"
            className="w-full h-72 object-cover border border-[#30363d] grayscale-[0.15]"
            fittingType="fill"
          />
          <figcaption className="text-[9px] text-[#8b949e] mt-1.5">Portrait. Public domain.</figcaption>
        </figure>
        <div className="md:col-span-2 text-sm text-[#c9d1d9] leading-relaxed space-y-4">
          <p>
            If Kaluza supplied the classical blueprint, <strong className="text-[#e6edf3]">Oskar Klein</strong> supplied the
            physical mechanism — turning the fifth dimension from a mathematical convenience into a quantized reality. Klein
            was born on <span className="font-mono text-[#00f5ff]">15 September 1894</span> in Mörby (Danderyd, outside
            Stockholm), the son of <strong className="text-[#e6edf3]">Gottlieb Klein</strong>, the chief rabbi of Stockholm
            (originally from Humenné in the Kingdom of Hungary, now Slovakia), and Antonie (Toni) Lévy.
          </p>
          <p>
            He became a student of <strong className="text-[#e6edf3]">Svante Arrhenius</strong> at the Nobel Institute while
            still young, and was en route to Jean-Baptiste Perrin in France when the First World War broke out and he was
            drafted into the military. From <span className="font-mono text-[#00f5ff]">1917</span> he worked with
            <strong className="text-[#e6edf3]"> Niels Bohr</strong> in Copenhagen — the heart of the "Copenhagen Circle" — and
            took his doctorate at the University College of Stockholm in <span className="font-mono text-[#00f5ff]">1921</span>,
            the same year as his work with Rosseland on "collisions of the second kind."
          </p>
        </div>
      </div>

      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        Between <span className="font-mono text-[#00f5ff]">1923 and 1925</span>, Klein held a professorship at the
        <strong className="text-[#e6edf3]"> University of Michigan</strong> in Ann Arbor, moving there with his new wife
        Gerda Koch of Denmark. This period of distance from the Copenhagen debates proved remarkably fertile: away from the
        epicenter, he independently formulated a five-dimensional wave equation and grasped that the fifth dimension held the
        key to quantization through periodic boundary conditions.
      </p>

      {/* The 1926 compactification */}
      <h3 className="text-[#00f5ff] text-sm font-bold uppercase tracking-wider mb-3">The 1926 Compactification</h3>
      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        Klein's enduring contribution was to propose that the fifth dimension is a <strong className="text-[#e6edf3]">circle
        (S¹)</strong> curled up at every point in spacetime — compact, periodic, and microscopic. Identifying electric charge
        with motion in the fifth dimension, and applying periodic boundary conditions, momentum in that direction becomes
        quantized:
      </p>
      <div className="bg-[#0d1117] border border-[#30363d] p-4 my-4 text-center font-mono text-[#00f5ff] text-sm sm:text-base overflow-x-auto">
        mU⁵ = cq / G<sup>1/2</sup> = h / λ⁵ &nbsp;⟹&nbsp; λ⁵ ~ 10⁻³⁰ cm
      </div>
      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        Klein found the circumference of the hidden dimension to be of order <span className="font-mono text-[#00f5ff]">10⁻³⁰
        cm</span> — comparable to the Planck length (~10⁻³³ cm) — thereby explaining why the cylinder condition holds: the
        fifth dimension is simply too small to observe. Only the <em>n = 0</em> (massless) mode appears at low energies; the
        higher Fourier modes — the <strong className="text-[#e6edf3]">Kaluza-Klein tower</strong>, with masses
        <span className="font-mono"> M<sub>n</sub> = nh / Rc</span> — sit near the Planck scale, far beyond detection.
      </p>

      {/* AI diagram */}
      <figure className="my-6 border border-[#bc8cff]/20 bg-[#12161A] clip-corner">
        <Image
          src="https://media.base44.com/images/public/6a51c0830aeacd39ab86c4f0/bb1fd0a20_generated_image.png"
          alt="Conceptual diagram of Klein's compactified S¹ fifth dimension and the Kaluza-Klein mass tower"
          className="w-full h-56 sm:h-72 object-cover"
          fittingType="fill"
        />
        <figcaption className="px-3 py-2 text-[9px] sm:text-[10px] text-[#8b949e] border-t border-[#30363d]">
          The compactified S¹ dimension and the Kaluza-Klein tower of massive modes.
          <span className="text-[#bc8cff]"> Modern rendering — AI-generated conceptual diagram (2026).</span>
        </figcaption>
      </figure>

      {/* Klein-Gordon + other work */}
      <h3 className="text-[#00f5ff] text-sm font-bold uppercase tracking-wider mb-3 mt-6">Quantum Equations & Cross-Sections</h3>
      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        In <span className="font-mono text-[#00f5ff]">1926</span> Klein discovered the relativistic wave equation now called
        the <strong className="text-[#e6edf3]">Klein-Gordon equation</strong> — independently of Walter Gordon and Vladimir
        Fock, and (a case of Stigler's law) after Erwin Schrödinger, who had found it first but withheld publication because
        it failed to reproduce hydrogen's fine structure. Three years later, with Yoshio Nishina, Klein derived the
        <strong className="text-[#e6edf3]"> Klein-Nishina formula</strong> — the quantum-electrodynamic cross-section for
        Compton scattering that remains a cornerstone of high-energy physics.
      </p>

      {/* 1938 gauge + humanitarian */}
      <h3 className="text-[#00f5ff] text-sm font-bold uppercase tracking-wider mb-3 mt-6">Gauge Anticipation & Humanitarian Leadership</h3>
      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        In <span className="font-mono text-[#00f5ff]">1938</span>, a few years after Hideki Yukawa's meson proposal, Klein put
        forward a <strong className="text-[#e6edf3]">boson-exchange model for the weak interaction</strong> grounded in a local
        isotropic gauge symmetry — quietly anticipating the Yang-Mills theory that would, decades later, become the
        Standard Model's backbone.
      </p>
      <p className="text-sm text-[#c9d1d9] leading-relaxed mb-4">
        Klein's ethics matched his theoretical rigor. During the 1930s he helped many refugee physicists expelled from
        Germany and elsewhere on account of their Jewish heritage, and in <span className="font-mono text-[#00f5ff]">1943</span>
        he aided in <strong className="text-[#e6edf3]">Niels Bohr's escape</strong> from occupied Copenhagen. He accepted the
        professorial chair at Stockholm University College in 1930 (previously held by Erik Ivar Fredholm), was awarded the
        <strong className="text-[#e6edf3]"> Max Planck Medal</strong> in 1959, and retired in 1962. He died in Stockholm on
        <span className="font-mono text-[#00f5ff]"> 5 February 1977</span>. The annual Oskar Klein Memorial Lecture and the
        Oskar Klein Centre for Cosmoparticle Physics in Stockholm bear his name.
      </p>

      {/* Bohr commemoration group photo */}
      <figure className="my-6 border border-[#30363d] bg-[#12161A] clip-corner">
        <Image
          src="https://upload.wikimedia.org/wikipedia/commons/6/6e/Bohr%2CNiels_Commemoration_Meeting_1963_Copenhagen_no_annotation.jpg"
          alt="Group photograph from the 1963 Niels Bohr commemoration meeting in Copenhagen, with Oskar Klein in the first row"
          className="w-full h-48 sm:h-64 object-cover grayscale-[0.1]"
          fittingType="fill"
        />
        <figcaption className="px-3 py-2 text-[9px] sm:text-[10px] text-[#8b949e] border-t border-[#30363d]">
          The Niels Bohr commemoration meeting, Copenhagen, 1963. Oskar Klein is seated in the first row. Public domain, Wikimedia Commons.
        </figcaption>
      </figure>
    </section>
  );
}