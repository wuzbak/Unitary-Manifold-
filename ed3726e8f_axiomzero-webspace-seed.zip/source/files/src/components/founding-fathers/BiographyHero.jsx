import { Image } from '@/components/ui/image';

export default function BiographyHero() {
  return (
    <header className="relative mb-12">
      {/* Portrait plates */}
      <div className="grid grid-cols-2 gap-3 sm:gap-6 mb-8">
        <figure className="border border-[#00f5ff]/20 bg-[#12161A] clip-corner overflow-hidden">
          <Image
            src="https://upload.wikimedia.org/wikipedia/commons/e/e0/Theodor_Franz_Eduard_Kaluza.jpg"
            alt="Theodor Franz Eduard Kaluza (1885–1954), German mathematician and physicist"
            className="w-full h-64 sm:h-80 object-cover grayscale-[0.2]"
            fittingType="fill"
          />
          <figcaption className="px-3 py-2 text-[9px] sm:text-[10px] text-[#8b949e] border-t border-[#30363d]">
            <span className="text-[#e6edf3] font-bold">Theodor Kaluza</span> · 1885–1954 · Public domain, Wikimedia Commons
          </figcaption>
        </figure>
        <figure className="border border-[#00f5ff]/20 bg-[#12161A] clip-corner overflow-hidden">
          <Image
            src="https://upload.wikimedia.org/wikipedia/commons/5/54/OskarKlein.jpg"
            alt="Oskar Benjamin Klein (1894–1977), Swedish theoretical physicist"
            className="w-full h-64 sm:h-80 object-cover grayscale-[0.2]"
            fittingType="fill"
          />
          <figcaption className="px-3 py-2 text-[9px] sm:text-[10px] text-[#8b949e] border-t border-[#30363d]">
            <span className="text-[#e6edf3] font-bold">Oskar Klein</span> · 1894–1977 · Public domain, Wikimedia Commons
          </figcaption>
        </figure>
      </div>

      {/* Title block */}
      <div className="border-l-2 border-[#FF9F00] pl-4 sm:pl-6">
        <div className="text-[10px] text-[#FF9F00] tracking-[0.3em] font-bold mb-2 uppercase">A Scientific Biography</div>
        <h1 className="text-2xl sm:text-4xl font-bold text-[#e6edf3] leading-tight tracking-tight">
          The Architects of Extra-Dimensionality
        </h1>
        <div className="text-[#00f5ff]/60 text-xs sm:text-sm mt-2 font-mono">Theodor Kaluza & Oskar Klein — the founders of higher-dimensional unification</div>
      </div>

      {/* Thesis paragraph */}
      <p className="mt-6 text-sm sm:text-base text-[#c9d1d9] leading-relaxed">
        The early twentieth century was defined by a singular pursuit: the <em>unification</em> of physical law.
        After Einstein's 1915 triumph — gravity geometrized as the curvature of a four-dimensional spacetime —
        the scientific community sought a commensurate geometric origin for electromagnetism. The answer, when it came,
        arrived not in three dimensions plus time, but in five. Gunnar Nordström's 1914 scalar precursor failed because it
        could not bend light; Theodor Kaluza's 1919 insight succeeded by extending Einstein's own tensor equations into a
        fifth dimension; and Oskar Klein's 1926 compactification made that dimension quantum-mechanically real, curled
        to a radius near the Planck length. This is the story of the two men who taught physics that the forces of nature
        are the shadows of a higher-dimensional geometry.
      </p>
    </header>
  );
}