import { AlertTriangle, ShieldOff, ShieldCheck } from 'lucide-react';

const CONFIG = {
  HARD_CONTAINMENT: {
    icon: ShieldOff,
    border: 'border-[#f85149]',
    bg: 'bg-[#2d1010]',
    label: 'CRIMSON LOCKDOWN',
    labelColor: 'text-[#f85149]',
    codeColor: 'text-[#f85149]'
  },
  SOFT_WARNING_EDGING: {
    icon: AlertTriangle,
    border: 'border-[#d29922]',
    bg: 'bg-[#2d250a]',
    label: 'AMBER ALERT',
    labelColor: 'text-[#d29922]',
    codeColor: 'text-[#d29922]'
  },
  VERIFIED_CLEAN: {
    icon: ShieldCheck,
    border: 'border-[#3fb950]',
    bg: 'bg-[#0d2010]',
    label: 'VERIFIED CLEAN',
    labelColor: 'text-[#3fb950]',
    codeColor: 'text-[#3fb950]'
  }
};

export default function EclipsaAlert({ result, onDismiss }) {
  if (!result || result.status === 'VERIFIED_CLEAN') return null;
  const cfg = CONFIG[result.status] || CONFIG.SOFT_WARNING_EDGING;
  const Icon = cfg.icon;

  return (
    <div className={`border rounded-md p-3 ${cfg.border} ${cfg.bg} font-mono text-xs`}>
      <div className="flex items-start gap-2">
        <Icon size={14} className={cfg.labelColor + ' shrink-0 mt-0.5'} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className={`font-bold tracking-wider ${cfg.labelColor}`}>ECLIPSA · {cfg.label}</span>
            {result.alert_code && <span className={`text-[10px] ${cfg.codeColor}`}>[{result.alert_code}]</span>}
          </div>
          <p className="text-[#8b949e] leading-relaxed">{result.log_message}</p>
          {result.status === 'HARD_CONTAINMENT' && (
            <p className="text-[#f85149] mt-1 text-[10px]">▸ Session interface frozen. Reset input to continue.</p>
          )}
          {result.status === 'SOFT_WARNING_EDGING' && (
            <p className="text-[#d29922] mt-1 text-[10px]">▸ Redirect parameter trajectory to resolve warning state.</p>
          )}
        </div>
        {onDismiss && result.status === 'SOFT_WARNING_EDGING' && (
          <button onClick={onDismiss} className="text-[#8b949e] hover:text-[#e6edf3] text-[10px] shrink-0">DISMISS</button>
        )}
      </div>
    </div>
  );
}