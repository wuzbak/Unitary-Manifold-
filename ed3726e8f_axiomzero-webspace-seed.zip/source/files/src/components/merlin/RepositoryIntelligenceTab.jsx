import { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { GitBranch, Search, Sparkles, Loader2, FileCode2, Wrench, Languages, Plug, BookOpen, FlaskConical, Server, Box, ExternalLink, MessageSquare } from 'lucide-react';

/**
 * RepositoryIntelligenceTab — browsable, queryable surface for PsiCat's
 * GitHub training growth. Consumes the deep repo-sync MerlinNotes produced
 * by the upgraded merlinRepoTrainingSync (tagged 'repo-sync' + 'change-type:*').
 *
 * Renders a timeline of syncs, classifies changes by type (tool / language /
 * integration / docs / test / infra), shows commit provenance, and lets the
 * user ask PsiCat "what new capabilities did I gain this sprint?" — which
 * dispatches a merlin-analyze event that the QuantumCat companion answers
 * from the real ingested content.
 */
const CHANGE_TYPE_META = {
  tool:        { label: 'Tools',        icon: Wrench,        color: '#FF9F00' },
  language:    { label: 'Languages',   icon: Languages,     color: '#bc8cff' },
  integration: { label: 'Integrations', icon: Plug,          color: '#4DD0E1' },
  docs:        { label: 'Docs',         icon: BookOpen,      color: '#3fb950' },
  test:        { label: 'Tests',        icon: FlaskConical,  color: '#f85149' },
  infra:       { label: 'Infra',        icon: Server,        color: '#8b949e' },
  other:       { label: 'Other',        icon: Box,           color: '#484f58' },
};

function parseTags(note) {
  try { return JSON.parse(note.tags_json || '[]'); } catch { return []; }
}

function extractChangeTypes(note) {
  const tags = parseTags(note);
  return tags
    .filter((t) => t.startsWith('change-type:'))
    .map((t) => t.slice('change-type:'.length));
}

function extractCommits(note) {
  const tags = parseTags(note);
  return tags.filter((t) => t.startsWith('commit:')).map((t) => t.slice('commit:'.length));
}

export default function RepositoryIntelligenceTab() {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        // Pull a generous window; filter client-side by the repo-sync tag
        const all = await base44.entities.MerlinNote.list('-created_date', 120);
        const synced = (all || []).filter((n) => {
          const tags = parseTags(n);
          return tags.includes('repo-sync');
        });
        setNotes(synced);
      } catch {
        setNotes([]);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const typeCounts = useMemo(() => {
    const counts = {};
    notes.forEach((n) => extractChangeTypes(n).forEach((t) => { counts[t] = (counts[t] || 0) + 1; }));
    return counts;
  }, [notes]);

  const filtered = useMemo(() => {
    let result = notes;
    if (typeFilter !== 'all') {
      result = result.filter((n) => extractChangeTypes(n).includes(typeFilter));
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter((n) =>
        (n.title || '').toLowerCase().includes(q) ||
        (n.content || '').toLowerCase().includes(q));
    }
    return result;
  }, [notes, typeFilter, search]);

  const askPsiCat = (prompt) => {
    window.dispatchEvent(new CustomEvent('merlin-analyze', { detail: { prompt } }));
  };

  const latestSprint = notes[0];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <GitBranch size={16} className="text-[#4DD0E1]" />
        <h2 className="text-sm font-bold text-[#e6edf3] uppercase tracking-wider">Repository Intelligence</h2>
        <span className="text-[10px] text-[#484f58] ml-auto">{notes.length} syncs ingested</span>
      </div>

      <div className="glass-panel clip-corner p-3 border-l-2 border-[#4DD0E1]">
        <p className="text-[10px] text-[#8b949e] leading-relaxed">
          PsiCat's GitHub training bridge runs every 6 hours, pulling the actual changed-file content
          (not just commit titles) from <span className="text-[#4DD0E1] font-bold">wuzbak/Unitary-Manifold-</span>,
          classifying each change by type, and distilling a deep insight into persistent memory.
          This surface makes that growth browsable, queryable, and answerable — the real content of
          new tools, languages, and integrations, with commit provenance.
        </p>
      </div>

      {/* Quick ask */}
      <div className="glass-panel clip-corner p-3 flex flex-col sm:flex-row sm:items-center gap-2">
        <div className="flex items-center gap-2 shrink-0">
          <Sparkles size={14} className="text-[#FF9F00]" />
          <span className="text-[10px] font-bold text-[#e6edf3] uppercase tracking-wider">Ask PsiCat</span>
        </div>
        <button
          onClick={() => askPsiCat('What new tools, languages, and integration capabilities did I gain in my most recent repository training sync? Cite commit SHAs and the specific files that changed.')}
          className="flex items-center gap-1.5 px-3 py-2 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner hover:bg-[#FF9F00]/20 transition-colors min-h-[40px]"
        >
          <MessageSquare size={11} /> What did I gain this sync?
        </button>
        <button
          onClick={() => askPsiCat('Trace my repository training growth across the last several syncs — what is the arc of my capability evolution, and which webspace features should each new ability integrate into?')}
          className="flex items-center gap-1.5 px-3 py-2 border border-[#4DD0E1]/40 bg-[#4DD0E1]/10 text-[#4DD0E1] text-[10px] font-bold clip-corner hover:bg-[#4DD0E1]/20 transition-colors min-h-[40px]"
        >
          <GitBranch size={11} /> Trace my growth arc
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#484f58]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search syncs by title or content..."
            className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] pl-8 pr-3 py-2 text-xs clip-corner focus:outline-none focus:border-[#00f5ff]/40"
          />
        </div>
        <div className="flex gap-1 overflow-x-auto pb-1">
          <button
            onClick={() => setTypeFilter('all')}
            className={`px-2 py-1 text-[9px] font-bold uppercase tracking-wider clip-corner transition-colors shrink-0 ${typeFilter === 'all' ? 'bg-[#4DD0E1] text-black' : 'border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}
          >
            All ({notes.length})
          </button>
          {Object.entries(CHANGE_TYPE_META).map(([key, meta]) => {
            const count = typeCounts[key] || 0;
            if (count === 0) return null;
            const Icon = meta.icon;
            return (
              <button
                key={key}
                onClick={() => setTypeFilter(key)}
                className={`flex items-center gap-1 px-2 py-1 text-[9px] font-bold uppercase tracking-wider clip-corner transition-colors shrink-0 ${typeFilter === key ? 'text-black' : 'border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}
                style={typeFilter === key ? { background: meta.color } : {}}
              >
                <Icon size={10} /> {meta.label} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* Timeline */}
      {loading ? (
        <div className="flex justify-center py-8">
          <Loader2 size={20} className="text-[#4DD0E1] animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="glass-panel clip-corner p-6 text-center">
          <GitBranch size={24} className="text-[#484f58] mx-auto mb-2" />
          <p className="text-xs text-[#8b949e] mb-1">No repository training syncs ingested yet.</p>
          <p className="text-[10px] text-[#484f58] leading-relaxed">
            The deep training bridge runs every 6 hours. Once it completes, PsiCat's GitHub growth
            will appear here as a browsable timeline with real changed-file content.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((n) => {
            const types = extractChangeTypes(n);
            const commits = extractCommits(n);
            const isOpen = expanded === n.id;
            const date = new Date(n.created_date).toLocaleString();
            return (
              <div key={n.id} className="glass-panel clip-corner overflow-hidden">
                <button
                  onClick={() => setExpanded(isOpen ? null : n.id)}
                  className="w-full text-left px-3 py-2.5 hover:bg-[#4DD0E1]/5 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap mb-1">
                        {types.map((t) => {
                          const meta = CHANGE_TYPE_META[t] || CHANGE_TYPE_META.other;
                          const Icon = meta.icon;
                          return (
                            <span key={t} className="inline-flex items-center gap-0.5 text-[8px] px-1 py-0.5 rounded border" style={{ color: meta.color, borderColor: `${meta.color}33`, background: `${meta.color}10` }}>
                              <Icon size={8} /> {meta.label}
                            </span>
                          );
                        })}
                      </div>
                      <div className="text-xs font-bold text-[#e6edf3] truncate">{n.title}</div>
                      <div className="text-[9px] text-[#484f58] mt-0.5">{date} · {commits.length} commits · {types.length} change types</div>
                    </div>
                    <span className={`text-[#484f58] text-[10px] shrink-0 transition-transform ${isOpen ? 'rotate-90' : ''}`}>▸</span>
                  </div>
                </button>
                {isOpen && (
                  <div className="px-3 pb-3 border-t border-[#30363d]/50 pt-2">
                    <p className="text-[10px] text-[#8b949e] leading-relaxed whitespace-pre-wrap">{n.content}</p>
                    {commits.length > 0 && (
                      <div className="flex items-center gap-1 flex-wrap mt-2">
                        <span className="text-[9px] text-[#484f58] uppercase tracking-wider">Commits:</span>
                        {commits.map((sha) => (
                          <a
                            key={sha}
                            href={`https://github.com/wuzbak/Unitary-Manifold-/commit/${sha}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-0.5 text-[9px] text-[#4DD0E1] hover:opacity-70 font-mono"
                          >
                            <FileCode2 size={9} /> {sha} <ExternalLink size={8} />
                          </a>
                        ))}
                      </div>
                    )}
                    {n.source_url && (
                      <a href={n.source_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-[9px] text-[#4DD0E1] hover:opacity-70 mt-2">
                        <GitBranch size={9} /> View full commit history <ExternalLink size={8} />
                      </a>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}