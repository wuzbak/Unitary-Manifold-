/**
 * MerlinAgentRunner — Autonomous agent task runner with live progress stream.
 *
 * Implements the client-driven agent loop for live UX:
 *   Phase 1 (Plan): InvokeLLM decides the first tool call
 *   Phase 2 (Execute): agentInvoke runs each tool, results feed back
 *   Phase 3 (Report): InvokeLLM generates a structured summary
 *
 * The user sees: plan → tool call receipts → results → summary
 * Tool calls go through agentInvoke (server-side, authenticated).
 * LLM calls go through InvokeLLM (server-side).
 *
 * Props:
 *  - task: string (the task to run)
 *  - context: string (project data, page state)
 *  - tools: array (tool manifest from merlinAgentTools)
 *  - accent: string (hex color)
 *  - onComplete: function(summary, actions)
 *  - model: string (LLM model, default claude_sonnet_4_6)
 */
import { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, Loader2, Check, X, Play, RotateCcw } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ToolCallReceipt from './ToolCallReceipt';

const MAX_ITERATIONS = 8;

export default function MerlinAgentRunner({ task: initialTask, context = '', tools = [], accent = '#fbbf24', onComplete, model = 'claude_sonnet_4_6' }) {
  const [task, setTask] = useState(initialTask || '');
  const [running, setRunning] = useState(false);
  const [actions, setActions] = useState([]);
  const [summary, setSummary] = useState(null);
  const [phase, setPhase] = useState(null); // 'plan' | 'execute' | 'report' | null
  const [reasoning, setReasoning] = useState('');
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [actions, summary, reasoning]);

  const toolList = tools.map(t => `- ${t.name}: ${t.desc} | args: ${t.args || '{}'}`).join('\n');

  const run = async () => {
    const t = (task || '').trim();
    if (!t || running) return;
    setRunning(true);
    setActions([]);
    setSummary(null);
    setReasoning('');
    setPhase('plan');

    let accumulatedContext = context;
    const allActions = [];

    for (let i = 0; i < MAX_ITERATIONS; i++) {
      setPhase(i === 0 ? 'plan' : 'execute');

      const systemPrompt = `You are PsiCat (Merlin), an autonomous agent. A user assigned you a task. You have tools. Decide what tool to call, or if the task is complete.

AVAILABLE TOOLS:
${toolList}

RULES:
1. Call ONE tool per step. Choose the tool that makes the most progress.
2. After each tool result, decide if you need another tool or if you're done.
3. When the task is complete, return action: "done" with a summary.
4. If a tool fails, try an alternative or report the failure.
5. For entity creates, include project_id when the task is project-scoped.
6. Be specific with tool args — use exact field names.

TASK: ${t}

CONTEXT:
${accumulatedContext}

PREVIOUS ACTIONS:
${allActions.map((a, idx) => `${idx + 1}. ${a.tool} → ${a.ok ? 'OK' : 'FAILED'}`).join('\n') || 'None yet'}

Respond with JSON only.`;

      let decision;
      try {
        const llmRes = await base44.integrations.Core.InvokeLLM({
          prompt: systemPrompt,
          model,
          response_json_schema: {
            type: 'object',
            properties: {
              action: { type: 'string', enum: ['call_tool', 'done'] },
              tool: { type: 'string' },
              args: { type: 'object' },
              reasoning: { type: 'string' },
              summary: { type: 'string' },
            },
            required: ['action'],
          },
        });
        decision = typeof llmRes === 'string' ? JSON.parse(llmRes) : llmRes;
      } catch (e) {
        setSummary(`Agent reasoning failed: ${e.message}`);
        setPhase(null);
        setRunning(false);
        return;
      }

      if (!decision || !decision.action) {
        setSummary('Agent could not determine next action.');
        setPhase(null);
        setRunning(false);
        return;
      }

      setReasoning(decision.reasoning || '');

      if (decision.action === 'done') {
        setSummary(decision.summary || decision.reasoning || 'Task complete.');
        setPhase('report');
        setRunning(false);
        if (onComplete) onComplete(decision.summary || '', allActions);
        return;
      }

      if (decision.action === 'call_tool' && decision.tool) {
        const stepAction = {
          iteration: i + 1,
          tool: decision.tool,
          args: decision.args || {},
          reasoning: decision.reasoning || '',
          ok: true,
          _running: true,
        };
        allActions.push(stepAction);
        setActions([...allActions]);

        const start = Date.now();
        let toolResult;
        try {
          const invokeRes = await base44.functions.invoke('agentInvoke', {
            tool: decision.tool,
            args: decision.args || {},
          });
          toolResult = invokeRes?.data || invokeRes;
        } catch (e) {
          toolResult = { ok: false, error: e.message };
        }
        const duration_ms = Date.now() - start;
        const ok = toolResult?.ok !== false;

        stepAction._running = false;
        stepAction.ok = ok;
        stepAction.duration_ms = duration_ms;
        stepAction.result = ok ? summarizeResult(toolResult?.result) : null;
        stepAction.error = ok ? null : toolResult?.error;
        setActions([...allActions]);

        const resultStr = ok
          ? JSON.stringify(summarizeResult(toolResult?.result)).slice(0, 2000)
          : `Error: ${toolResult?.error}`;
        accumulatedContext += `\n\n[Tool ${decision.tool} result]: ${resultStr}`;
      }
    }

    setSummary(`Reached max iterations (${MAX_ITERATIONS}). ${allActions.length} actions taken.`);
    setPhase('report');
    setRunning(false);
    if (onComplete) onComplete(`Max iterations reached. ${allActions.length} actions taken.`, allActions);
  };

  const reset = () => {
    setActions([]);
    setSummary(null);
    setReasoning('');
    setPhase(null);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Task input */}
      <div className="p-3 border-b border-[#30363d] shrink-0">
        <div className="flex gap-2">
          <input
            value={task}
            onChange={(e) => setTask(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !running && run()}
            disabled={running}
            placeholder="Assign Merlin a task… (e.g. 'break down scene 12' or 'build a call sheet for day 3')"
            className="flex-1 bg-[#0B0F13] border border-[#30363d] rounded px-2.5 py-2 text-[11px] text-[#e6edf3] focus:border-[${accent}]/40 focus:outline-none disabled:opacity-50 placeholder:text-[#484f58]"
          />
          <button
            onClick={run}
            disabled={running || !task.trim()}
            className="flex items-center gap-1 px-3 py-2 rounded text-xs font-bold disabled:opacity-40 transition-opacity shrink-0"
            style={{ background: accent, color: '#000' }}
          >
            {running ? <Loader2 size={12} className="animate-spin" /> : <Play size={12} />}
            <span className="hidden sm:inline">{running ? 'Running' : 'Run'}</span>
          </button>
          {(actions.length > 0 || summary) && !running && (
            <button onClick={reset} className="px-2 py-2 rounded text-xs border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] shrink-0">
              <RotateCcw size={12} />
            </button>
          )}
        </div>
        {tools.length > 0 && (
          <div className="text-[8px] text-[#484f58] mt-1.5">
            {tools.length} tools available · {running ? `Phase: ${phase}` : 'Ready'}
          </div>
        )}
      </div>

      {/* Progress stream */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 min-h-0">
        {actions.length === 0 && !summary && !running && (
          <div className="text-center py-6">
            <Sparkles size={20} style={{ color: accent }} className="mx-auto mb-2" />
            <p className="text-[10px] text-[#8b949e] mb-3">Assign me a task and I'll plan, execute, and report back autonomously.</p>
            <div className="flex flex-col gap-1.5 max-w-sm mx-auto">
              {[
                'Break down scene 12 and create the breakdown review items',
                'Build a call sheet for day 3',
                'Check turnaround compliance and flag violations',
                'Generate cast DOOD from scene appearances',
              ].map((s) => (
                <button key={s} onClick={() => setTask(s)} className="text-left text-[10px] text-[#e6edf3] bg-[#161b22] border border-[#30363d] rounded p-2 hover:border-[${accent}]/40 transition-colors">
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {reasoning && running && (
          <div className="glass-panel clip-corner p-2.5 mb-2 fade-in">
            <div className="flex items-center gap-2">
              <Sparkles size={10} style={{ color: accent }} className="shrink-0" />
              <div className="text-[9px] text-[#8b949e] italic leading-relaxed">{reasoning}</div>
            </div>
          </div>
        )}

        {actions.map((a, i) => (
          <ToolCallReceipt key={i} action={a} accent={accent} />
        ))}

        {summary && (
          <div className="glass-strong clip-corner p-3 mt-2 fade-in" style={{ borderLeft: `2px solid ${accent}` }}>
            <div className="flex items-center gap-2 mb-2">
              <Check size={12} style={{ color: '#3fb950' }} />
              <span className="text-[10px] font-bold text-[#e6edf3]">Task Report</span>
            </div>
            <div className="text-[10px] text-[#e6edf3] whitespace-pre-wrap leading-relaxed">{summary}</div>
            {actions.length > 0 && (
              <div className="text-[8px] text-[#484f58] mt-2 pt-2 border-t border-[#30363d]">
                {actions.length} action{actions.length !== 1 ? 's' : ''} · {actions.filter(a => a.ok).length} succeeded · {actions.filter(a => !a.ok).length} failed
              </div>
            )}
          </div>
        )}

        {running && actions.length === 0 && (
          <div className="flex items-center gap-2 text-[10px] text-[#8b949e]">
            <Loader2 size={12} className="animate-spin" style={{ color: accent }} /> PsiCat is planning…
          </div>
        )}
      </div>
    </div>
  );
}

function summarizeResult(result) {
  if (!result) return null;
  if (Array.isArray(result)) return `[${result.length} items]`;
  if (typeof result === 'object') {
    if (result.id) {
      const { id, created_date, updated_date, created_by_id, ...fields } = result;
      const keys = Object.keys(fields).slice(0, 8);
      const compact = {};
      keys.forEach(k => {
        const v = fields[k];
        if (typeof v === 'string' && v.length > 200) compact[k] = v.slice(0, 200) + '…';
        else compact[k] = v;
      });
      return { id, ...compact };
    }
    return result;
  }
  return String(result).slice(0, 1000);
}