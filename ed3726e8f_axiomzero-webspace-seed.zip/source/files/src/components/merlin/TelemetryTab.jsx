import { useMerlinNavigator } from '@/hooks/useMerlinNavigator';
import { Activity, Clock, Zap, DollarSign, Cpu, Radar, GitBranch } from 'lucide-react';
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts';
import HeartbeatWidget from './HeartbeatWidget';

const PENTAD_KERNELS = [
  { id: 'kernel_p', priority: 4, name: 'Proof / Lean4', color: '#bc8cff', keywords: ['lean', 'theorem', 'proof', 'formal', 'verify'], desc: 'Lean4 formal verification kernel — proof obligations and the critique-to-proof matrix.' },
  { id: 'kernel_r', priority: 3, name: 'Routing / Tools', color: '#4DD0E1', keywords: ['tool', 'route', 'schema', 'orchestrate', 'invoke'], desc: 'Tool-routing kernel — agent backend space orchestration and multi-step tool chains.' },
  { id: 'kernel_a', priority: 2, name: 'Audit / Memory', color: '#FF9F00', keywords: ['memory', 'contradiction', 'audit', 'recall', 'drift'], desc: 'Audit/memory kernel — contradiction tracking against the 208 hardgate pillars and distilled insight recall.' },
  { id: 'kernel_g', priority: 1, name: 'Governance / Safety', color: '#f85149', keywords: ['governance', 'refusal', 'safety', 'boundary', 'privilege', 'sentinel', 'policy'], desc: 'Governance kernel — ECLIPSA sentinel enforcement, privilege authorization, and separation-boundary control.' },
  { id: 'kernel_s', priority: 0, name: 'Standard (default)', color: '#8b949e', keywords: ['(fallback — no keyword match)'], desc: 'Standard sovereign-local model lane — the default kernel when no kernel-specific keywords are detected.' },
];

/**
 * TelemetryTab — Per-run telemetry for the Merlin Navigator v1 program.
 * Shows live run summaries (latency, tokens, cost, energy, routing lane,
 * provider) from the repo's engine output, the telemetry-related toolkit
 * functions from the v1 program summary, and a markdown fallback when no
 * structured data exists.
 */
export default function TelemetryTab() {
  const { data, isLoading, error } = useMerlinNavigator();

  if (isLoading) return <LoadingState />;
  if (error) return <ErrorState error={error} />;

  const telemetry = data?.telemetry;
  const summary = data?.programSummary;
  const program = data?.program?.content;

  const runs = parseTelemetryRuns(telemetry);
  const telemetryFns = (summary?.toolkitFunctions || []).filter(fn =>
    /telemetry|control|longitudinal|receipt|run/i.test(fn));

  return (
    <div className="space-y-4">
      <HeartbeatWidget />

      <div className="flex items-center gap-2">
        <Activity size={16} className="text-[#4DD0E1]" />
        <h2 className="text-sm font-bold text-[#e6edf3] uppercase tracking-wider">Per-Run Telemetry</h2>
      </div>

      {runs.length > 0 ? (
        <>
          {/* Sparkline charts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <SparklineCard
              title="Latency Trend"
              icon={Clock}
              data={runs.map((r, i) => ({ x: i, y: r.latency_ms || 0 }))}
              color="#4DD0E1"
              unit="ms"
            />
            <SparklineCard
              title="Token Trend"
              icon={Zap}
              data={runs.map((r, i) => ({ x: i, y: r.tokens || 0 }))}
              color="#FF9F00"
              unit="tok"
            />
          </div>

          {/* Run summaries list */}
          <div className="glass-panel clip-corner overflow-hidden">
            <div className="border-b border-[#00f5ff]/15 px-3 py-2">
              <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Recent Runs</h3>
            </div>
            <div className="max-h-[400px] overflow-y-auto">
              {runs.map((run, i) => (
                <div key={i} className="border-b border-[#00f5ff]/5 px-3 py-2.5 hover:bg-[#00f5ff]/5 transition-colors">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs font-bold text-[#e6edf3]">{run.timestamp || `Run ${i + 1}`}</span>
                    <span className="text-[10px] text-[#FF9F00] font-bold uppercase tracking-wider">{run.lane || 'sovereign'}</span>
                  </div>
                  <div className="grid grid-cols-4 gap-2 text-[10px]">
                    <Metric icon={Clock} label="lat" value={`${run.latency_ms || '—'}ms`} color="#4DD0E1" />
                    <Metric icon={Zap} label="tok" value={run.tokens || '—'} color="#FF9F00" />
                    <Metric icon={DollarSign} label="cost" value={run.cost_usd ? `$${run.cost_usd}` : '—'} color="#3fb950" />
                    <Metric icon={Cpu} label="prov" value={run.provider || '—'} color="#8b949e" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : (
        <div className="glass-panel clip-corner p-4">
          <p className="text-xs text-[#8b949e] mb-3">
            No structured telemetry JSON committed in the repository yet. The v1 program instruments every inference with latency, token, cost, energy, routing lane, and provider tracking. Here's the program context:
          </p>
          {program ? (
            <pre className="text-[10px] text-[#484f58] whitespace-pre-wrap font-mono max-h-[400px] overflow-y-auto leading-relaxed">
              {extractTelemetrySection(program)}
            </pre>
          ) : (
            <p className="text-xs text-[#484f58] italic">Program content not available.</p>
          )}
        </div>
      )}

      {/* Pentad Kernel Routing distribution panel */}
      {summary?.hasPentadKernelRouting && (
        <div className="glass-panel clip-corner p-4 tactical-hud">
          <div className="flex items-center gap-2 mb-3">
            <GitBranch size={14} className="text-[#bc8cff]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">
              Pentad Kernel Routing
            </h3>
            <span className="text-[9px] text-[#484f58] font-mono ml-auto">merlin_kernel_routing.py</span>
          </div>
          <p className="text-[10px] text-[#8b949e] mb-3 leading-relaxed">
            Every query is routed to one of five specialized kernels based on keyword analysis. Routing is deterministic and kernel-gated — the telemetry records which kernel handled each inference.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
            {PENTAD_KERNELS.map((k) => (
              <div key={k.id} className="border bg-[#0d1117] p-2.5 clip-corner group hover:bg-[#0a0d11] transition-colors"
                style={{ borderColor: `${k.color}30` }}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-mono font-bold" style={{ color: k.color }}>{k.id}</span>
                  <span className="text-[8px] font-mono px-1.5 py-0.5 border clip-corner"
                    style={{ color: k.color, borderColor: `${k.color}40`, background: `${k.color}10` }}>
                    P{k.priority}
                  </span>
                </div>
                <div className="text-[10px] font-bold text-[#e6edf3] mb-1">{k.name}</div>
                <div className="text-[8px] text-[#484f58] leading-relaxed mb-1.5">{k.desc}</div>
                <div className="flex flex-wrap gap-1">
                  {k.keywords.map((kw) => (
                    <span key={kw} className="text-[7px] font-mono px-1 py-0.5 border border-[#30363d] text-[#8b949e] bg-[#0a0d11] clip-corner">
                      {kw}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="text-[9px] text-[#484f58] mt-2 italic">
            Pentad integration and separation-boundary controls: <span className="text-[#bc8cff] font-mono">get_governance_integration_policy()</span>
          </div>
        </div>
      )}

      {/* Telemetry toolkit functions from v1 program */}
      {telemetryFns.length > 0 && (
        <div className="glass-panel clip-corner p-4">
          <div className="flex items-center gap-2 mb-3">
            <Radar size={14} className="text-[#4DD0E1]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">
              Telemetry Surfaces <span className="text-[#484f58] font-normal">({telemetryFns.length})</span>
            </h3>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {telemetryFns.map((fn) => (
              <span key={fn} className="text-[10px] font-mono px-2 py-1 border border-[#4DD0E1]/30 text-[#4DD0E1] bg-[#4DD0E1]/8 clip-corner">
                {fn}
              </span>
            ))}
          </div>
          <p className="text-[10px] text-[#484f58] mt-2">Exposed via /api/agentInvoke. The Control Tower provides live operational telemetry; longitudinal acceptance evaluates sustained performance over time.</p>
        </div>
      )}
    </div>
  );
}

function SparklineCard({ title, icon: Icon, data, color, unit }) {
  return (
    <div className="glass-panel clip-corner p-3">
      <div className="flex items-center gap-1.5 mb-2">
        <Icon size={12} style={{ color }} />
        <span className="text-[10px] font-bold text-[#8b949e] uppercase tracking-wider">{title}</span>
      </div>
      <div className="h-16">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <XAxis dataKey="x" hide />
            <YAxis hide />
            <Tooltip
              contentStyle={{ background: '#0d1117', border: `1px solid ${color}40`, fontSize: '10px', borderRadius: 0 }}
              labelStyle={{ display: 'none' }}
              formatter={(v) => [`${v} ${unit}`, '']}
            />
            <Line type="monotone" dataKey="y" stroke={color} strokeWidth={1.5} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function Metric({ icon: Icon, label, value, color }) {
  return (
    <div className="flex items-center gap-1">
      <Icon size={10} style={{ color }} />
      <span className="text-[#484f58] uppercase">{label}:</span>
      <span className="text-[#e6edf3] font-mono">{value}</span>
    </div>
  );
}

function parseTelemetryRuns(telemetry) {
  if (!telemetry) return [];
  if (telemetry.data) {
    if (Array.isArray(telemetry.data)) return telemetry.data;
    if (telemetry.data.runs) return telemetry.data.runs;
  }
  if (Array.isArray(telemetry)) return telemetry;
  return [];
}

function extractTelemetrySection(program) {
  const lines = program.split('\n');
  let capturing = false;
  let result = [];
  for (const line of lines) {
    if (/telemetry|instrument|per-run|energy/i.test(line) && /^#/.test(line)) {
      capturing = true;
      result = [];
    }
    if (capturing) {
      result.push(line);
      if (result.length > 60) break;
    }
  }
  return result.length > 0 ? result.join('\n') : program.slice(0, 3000);
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center py-12">
      <div className="w-6 h-6 border-2 border-[#4DD0E1]/30 border-t-[#4DD0E1] rounded-full animate-spin" />
    </div>
  );
}

function ErrorState({ error }) {
  return (
    <div className="glass-panel clip-corner p-4 text-center">
      <p className="text-xs text-[#f85149]">Failed to load telemetry data: {error?.message || 'Unknown error'}</p>
    </div>
  );
}