import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Database, Trash2, Search, Cloud, AlertTriangle, BookOpen, Globe, Sparkles, ShieldCheck, Fingerprint, Layers, Waves } from 'lucide-react';

/**
 * MemoryTab — Sovereign multi-tier memory for the Merlin Navigator.
 *
 * Sprint CH sovereign architecture: the browser holds zero conversation
 * history. Memory lives in two platform-side tiers:
 *   Tier 1 — Sovereign Ephemeral (volatile RAM, wiped on exit)
 *   Tier 2 — Durable Library (MerlinSession entity, cross-device, RLS)
 *   Tier 3 — Distilled Insights (MerlinNote, autonomous session-close distillation)
 *   Tier 4 — Contradiction Events (ECLIPSA gate flags)
 */
export default function MemoryTab() {
  const [durableSessions, setDurableSessions] = useState([]);
  const [loadingDurable, setLoadingDurable] = useState(true);
  const [notes, setNotes] = useState([]);
  const [loadingNotes, setLoadingNotes] = useState(true);
  const [search, setSearch] = useState('');
  const [domainFilter, setDomainFilter] = useState('all');

  useEffect(() => {
    (async () => {
      try {
        const sessions = await base44.entities.MerlinSession.list('-updated_date', 50);
        setDurableSessions(sessions || []);
      } catch {} finally {
        setLoadingDurable(false);
      }
    })();

    (async () => {
      try {
        const learned = await base44.entities.MerlinNote.list('-updated_date', 50);
        setNotes(learned || []);
      } catch {} finally {
        setLoadingNotes(false);
      }
    })();
  }, []);

  const filteredDurable = search.trim()
    ? durableSessions.filter(s =>
        (s.title || '').toLowerCase().includes(search.toLowerCase()) ||
        (s.context_type || '').toLowerCase().includes(search.toLowerCase()))
    : durableSessions;

  const filteredNotes = (() => {
    let result = notes;
    if (domainFilter !== 'all') {
      result = result.filter(n => n.domain === domainFilter);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(n =>
        (n.title || '').toLowerCase().includes(q) ||
        (n.content || '').toLowerCase().includes(q));
    }
    return result;
  })();

  const flaggedCount = notes.filter(n => n.contradiction_flag === 'flagged').length;
  const distilledCount = notes.filter(n => n.source === 'distillation').length;
  const decoherenceEvents = notes.filter(n => n.uncertainty_bounds === 'DECOHERENCE_EVENT');

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Database size={16} className="text-[#4DD0E1]" />
        <h2 className="text-sm font-bold text-[#e6edf3] uppercase tracking-wider">Sovereign Multi-Tier Memory</h2>
      </div>

      {/* Tier 1: Sovereign Ephemeral (volatile RAM) */}
      <div className="glass-panel clip-corner p-4 border-l-2 border-[#4DD0E1]">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Fingerprint size={14} className="text-[#4DD0E1]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Tier 1 — Sovereign Ephemeral</h3>
          </div>
          <span className="text-[10px] text-[#4DD0E1] font-bold uppercase tracking-wider">Active</span>
        </div>
        <p className="text-[10px] text-[#8b949e] leading-relaxed">
          The browser holds zero conversation history. No localStorage, sessionStorage, IndexedDB, or cookies.
          The active conversation lives only in volatile RAM and wipes to absolute zero on tab close. An
          ephemeral blinded session token (SHA-256) links the session to distilled insights on the platform
          side without PII. This is the sovereign sanctum — the client is a dumb terminal.
        </p>
        <div className="flex items-center gap-2 mt-2 text-[9px] text-[#484f58]">
          <ShieldCheck size={10} className="text-[#3fb950]" />
          <span>Zero-trace · PII sanitized by ECLIPSA gate before durable commit</span>
        </div>
      </div>

      {/* Tier 2: Durable Sessions (MerlinSession entity) */}
      <div className="glass-panel clip-corner p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Cloud size={14} className="text-[#3fb950]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Tier 2 — Durable Library (Cross-Device)</h3>
          </div>
          <span className="text-[10px] text-[#484f58]">{durableSessions.length} sessions · RLS-protected</span>
        </div>
        <div className="relative mb-3">
          <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#484f58]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search sessions..."
            className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] pl-8 pr-3 py-2 text-xs clip-corner focus:outline-none focus:border-[#00f5ff]/40"
          />
        </div>
        {loadingDurable ? (
          <div className="flex justify-center py-4">
            <div className="w-5 h-5 border-2 border-[#00f5ff]/30 border-t-[#00f5ff] rounded-full animate-spin" />
          </div>
        ) : filteredDurable.length > 0 ? (
          <div className="space-y-1.5 max-h-[250px] overflow-y-auto">
            {filteredDurable.map((s) => (
              <div key={s.id} className="border border-[#00f5ff]/10 clip-corner px-3 py-2 hover:bg-[#00f5ff]/5 transition-colors">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-[#e6edf3] truncate">{s.title || 'Untitled'}</span>
                  <span className="text-[9px] text-[#484f58] uppercase tracking-wider shrink-0">{s.context_type}</span>
                </div>
                <div className="text-[10px] text-[#484f58] mt-0.5">
                  {new Date(s.updated_date || s.created_date).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-[#484f58] italic">No durable sessions. Save a session from the Chat tab to persist it cross-device.</p>
        )}
      </div>

      {/* Tier 3: Distilled Insights (MerlinNote — autonomous distillation) */}
      <div className="glass-panel clip-corner p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sparkles size={14} className="text-[#7c4dff]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Tier 3 — Distilled Insights</h3>
          </div>
          <div className="flex items-center gap-2 text-[10px] text-[#484f58]">
            <span>{distilledCount} distilled</span>
            <span className="text-[#f85149]">{flaggedCount} flagged</span>
          </div>
        </div>
        <p className="text-[10px] text-[#484f58] mb-3 leading-relaxed">
          Insights compiled autonomously on session close through the ECLIPSA distillation gate. Each
          conversation is sanitized (PII stripped), distilled into semantic primitives (tensions,
          conjectures, constraints, heuristics), and contradiction-checked against the 208 hardgate
          pillars before committing. These are injected into Merlin's system prompt as accumulated
          learnings — this is how Merlin remembers even when the browser doesn't.
        </p>

        {/* Domain filter */}
        <div className="flex gap-1 mb-3 flex-wrap">
          {['all', 'physics', 'film', 'journalism', 'earth-science', 'dnd', 'general'].map(d => (
            <button
              key={d}
              onClick={() => setDomainFilter(d)}
              className={`px-2 py-1 text-[9px] font-bold uppercase tracking-wider clip-corner transition-colors ${
                domainFilter === d ? 'bg-[#7c4dff] text-white' : 'border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'
              }`}
            >
              {d}
            </button>
          ))}
        </div>

        {loadingNotes ? (
          <div className="flex justify-center py-4">
            <div className="w-5 h-5 border-2 border-[#7c4dff]/30 border-t-[#7c4dff] rounded-full animate-spin" />
          </div>
        ) : filteredNotes.length > 0 ? (
          <div className="space-y-1.5 max-h-[320px] overflow-y-auto">
            {filteredNotes.map((n) => (
              <div
                key={n.id}
                className={`border clip-corner px-3 py-2 hover:bg-[#7c4dff]/5 transition-colors ${
                  n.contradiction_flag === 'flagged' ? 'border-[#f85149]/30 bg-[#f85149]/5' : 'border-[#7c4dff]/15'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-0.5">
                  <span className="text-xs font-bold text-[#e6edf3] truncate">{n.title || 'Untitled'}</span>
                  <div className="flex items-center gap-1 shrink-0">
                    {n.domain && (
                      <span className="inline-flex items-center gap-0.5 text-[8px] px-1 py-0.5 rounded bg-[#4DD0E1]/10 text-[#4DD0E1] border border-[#4DD0E1]/20">
                        <Layers size={8} /> {n.domain}
                      </span>
                    )}
                    {n.contradiction_flag === 'flagged' && (
                      <span className="inline-flex items-center gap-0.5 text-[8px] px-1 py-0.5 rounded bg-[#f85149]/10 text-[#f85149] border border-[#f85149]/20">
                        <AlertTriangle size={8} /> FLAGGED
                      </span>
                    )}
                    {n.source === 'distillation' && (
                      <span className="inline-flex items-center gap-0.5 text-[8px] px-1 py-0.5 rounded bg-[#7c4dff]/10 text-[#7c4dff] border border-[#7c4dff]/20">
                        <Sparkles size={8} /> distilled
                      </span>
                    )}
                    {n.epistemic_confidence != null && (
                      <span className="inline-flex items-center gap-0.5 text-[8px] px-1 py-0.5 rounded bg-[#FF9F00]/10 text-[#FF9F00] border border-[#FF9F00]/20" title={`Confidence: ${n.epistemic_confidence} · ${n.uncertainty_bounds || ''}`}>
                        <AlertTriangle size={8} /> {n.epistemic_confidence}
                      </span>
                    )}
                    {n.source === 'internal' && (
                      <span className="inline-flex items-center gap-0.5 text-[8px] px-1 py-0.5 rounded bg-[#3fb950]/10 text-[#3fb950] border border-[#3fb950]/20">
                        <ShieldCheck size={8} /> seed
                      </span>
                    )}
                  </div>
                </div>
                <p className="text-[10px] text-[#8b949e] leading-relaxed line-clamp-2">{n.content}</p>
                {n.uncertainty_bounds && n.uncertainty_bounds !== 'DECOHERENCE_EVENT' && (
                  <p className="text-[9px] text-[#FF9F00]/80 mt-1 leading-relaxed font-bold uppercase tracking-wider">{n.uncertainty_bounds}</p>
                )}
                {n.contradiction_flag === 'flagged' && n.contradiction_detail && (
                  <p className="text-[9px] text-[#f85149]/80 mt-1 leading-relaxed">{n.contradiction_detail}</p>
                )}
                <div className="flex items-center gap-2 mt-1">
                  {n.source_url && (
                    <a href={n.source_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-[9px] text-[#4DD0E1] hover:opacity-70 truncate">
                      <Globe size={9} /> {n.source_url.length > 40 ? n.source_url.slice(0, 40) + '…' : n.source_url}
                    </a>
                  )}
                  <span className="text-[9px] text-[#484f58] ml-auto">{new Date(n.updated_date || n.created_date).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-[#484f58] italic">No distilled insights yet. Have a conversation with Merlin — on session close, the distillation gate compiles it into a persistent insight.</p>
        )}
      </div>

      {/* Tier 3.5: Quantum Decoherence Log */}
      <div className="glass-panel clip-corner p-4">
        <div className="flex items-center gap-2 mb-3">
          <Waves size={14} className="text-[#bc8cff]" />
          <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Quantum Decoherence Log</h3>
          <span className="text-[10px] text-[#484f58] ml-auto">{decoherenceEvents.length} events</span>
        </div>
        <p className="text-[10px] text-[#484f58] leading-relaxed mb-2">
          Tracks when Merlin's reasoning crosses domain boundaries within a single session —
          a 'decoherence event.' Each domain crossing is logged to make epistemic boundary
          transitions explicit for the ECLIPSA firewall, preventing silent contamination
          between creative and physics reasoning.
        </p>
        {decoherenceEvents.length > 0 ? (
          <div className="space-y-1.5 max-h-[200px] overflow-y-auto">
            {decoherenceEvents.map((n) => (
              <div key={n.id} className="border border-[#bc8cff]/15 clip-corner px-3 py-2 hover:bg-[#bc8cff]/5 transition-colors">
                <div className="flex items-center justify-between gap-2 mb-0.5">
                  <span className="text-xs font-bold text-[#e6edf3] truncate">{n.domain_transition_path || n.title}</span>
                  <span className="inline-flex items-center gap-0.5 text-[8px] px-1 py-0.5 rounded bg-[#bc8cff]/10 text-[#bc8cff] border border-[#bc8cff]/20 shrink-0">
                    <Waves size={8} /> {n.decoherence_count}x
                  </span>
                </div>
                <p className="text-[10px] text-[#8b949e] leading-relaxed line-clamp-1">{n.content}</p>
                <span className="text-[9px] text-[#484f58]">{new Date(n.updated_date || n.created_date).toLocaleString()}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-[#484f58] italic">No decoherence events. Merlin's reasoning has stayed within domain boundaries.</p>
        )}
      </div>

      {/* Tier 4: Contradiction Events */}
      <div className="glass-panel clip-corner p-4">
        <div className="flex items-center gap-2 mb-3">
          <AlertTriangle size={14} className="text-[#FF9F00]" />
          <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Tier 4 — Contradiction Events</h3>
          <span className="text-[10px] text-[#484f58] ml-auto">{flaggedCount} flagged</span>
        </div>
        <p className="text-[10px] text-[#484f58] leading-relaxed mb-2">
          The ECLIPSA contradiction gate checks every distilled premise against the 208 hardgate pillars.
          If a premise conflicts with a certified invariant (e.g., asserting w_a ≠ 0 or k_CS ≠ 74), it is
          tagged [CONTRADICTION_FLAGGED] and routed to [Falsification Lab](/falsification-lab) rather than
          quietly integrated into persistent memory.
        </p>
        {flaggedCount > 0 ? (
          <div className="text-[10px] text-[#f85149]">
            {flaggedCount} contradiction-flagged insight{flaggedCount !== 1 ? 's' : ''} detected. See the Counterexamples tab for details.
          </div>
        ) : (
          <p className="text-xs text-[#484f58] italic">No contradiction events. The gate is clear.</p>
        )}
      </div>
    </div>
  );
}