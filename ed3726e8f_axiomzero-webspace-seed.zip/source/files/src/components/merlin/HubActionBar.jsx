/**
 * HubActionBar — on-demand action buttons for the PsiCat Hub.
 *
 * "Run PsiCat in Gym" invokes merlinTrainingHeartbeat (the distill →
 * consolidate → self-audit pipeline) and displays the live result inline.
 * "Sync Repo" invokes merlinRepoTrainingSync (pulls latest GitHub commits
 * into PsiCat's accumulated learnings) and displays the sync result inline.
 *
 * Both buttons show loading, result, and error states — never a silent blank.
 */
import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Cpu, GitBranch, Loader2, CheckCircle, AlertCircle } from 'lucide-react';

export default function HubActionBar() {
  const [gymRunning, setGymRunning] = useState(false);
  const [gymResult, setGymResult] = useState(null);
  const [gymError, setGymError] = useState(null);
  const [syncRunning, setSyncRunning] = useState(false);
  const [syncResult, setSyncResult] = useState(null);
  const [syncError, setSyncError] = useState(null);

  const runGym = async () => {
    setGymRunning(true);
    setGymError(null);
    setGymResult(null);
    try {
      const res = await base44.functions.invoke('merlinTrainingHeartbeat', {});
      const r = res?.data || res;
      if (r?.error) throw new Error(r.error);
      setGymResult(r);
    } catch (e) {
      setGymError(e.message || 'Training heartbeat failed');
    } finally {
      setGymRunning(false);
    }
  };

  const runSync = async () => {
    setSyncRunning(true);
    setSyncError(null);
    setSyncResult(null);
    try {
      const res = await base44.functions.invoke('merlinRepoTrainingSync', {});
      const r = res?.data || res;
      if (r?.error) throw new Error(r.error);
      setSyncResult(r);
    } catch (e) {
      setSyncError(e.message || 'Repo sync failed');
    } finally {
      setSyncRunning(false);
    }
  };

  return (
    <div className="mb-4 glass-panel clip-corner p-3">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-[9px] font-bold text-[#484f58] uppercase tracking-[0.2em] mr-1">PsiCat Actions</span>
        <button
          onClick={runGym}
          disabled={gymRunning}
          className="flex items-center gap-1.5 px-3 py-2 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner hover:bg-[#FF9F00]/20 transition-colors disabled:opacity-50 min-h-[36px]"
        >
          {gymRunning ? <Loader2 size={12} className="animate-spin" /> : <Cpu size={12} />}
          {gymRunning ? 'Running...' : 'Run PsiCat in Gym'}
        </button>
        <button
          onClick={runSync}
          disabled={syncRunning}
          className="flex items-center gap-1.5 px-3 py-2 border border-[#4DD0E1]/40 bg-[#4DD0E1]/10 text-[#4DD0E1] text-[10px] font-bold clip-corner hover:bg-[#4DD0E1]/20 transition-colors disabled:opacity-50 min-h-[36px]"
        >
          {syncRunning ? <Loader2 size={12} className="animate-spin" /> : <GitBranch size={12} />}
          {syncRunning ? 'Syncing...' : 'Sync Repo'}
        </button>
      </div>

      {/* Gym result */}
      {gymError && (
        <div className="mt-2 flex items-center gap-2 text-[10px] text-[#f85149]">
          <AlertCircle size={11} /> Gym run failed: {gymError}
        </div>
      )}
      {gymResult && (
        <div className="mt-2 border border-[#FF9F00]/20 clip-corner p-2 bg-[#FF9F00]/5">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle size={11} className={gymResult.result?.passed ? 'text-[#3fb950]' : 'text-[#d29922]'} />
            <span className="text-[10px] font-bold text-[#FF9F00] uppercase tracking-wider">Gym Epoch {gymResult.epoch} Complete</span>
            <span className="text-[9px] text-[#484f58] ml-auto font-mono">{new Date(gymResult.started_at).toLocaleTimeString()}</span>
          </div>
          {/* Real challenge + score + tier change */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px] mb-2">
            <div>
              <div className="text-[#484f58] text-[9px]">CHALLENGE</div>
              <div className="text-[#e6edf3] truncate">P{gymResult.challenge?.pillar_id} — {gymResult.challenge?.name}</div>
            </div>
            <div>
              <div className="text-[#484f58] text-[9px]">SCORE</div>
              <div className={gymResult.result?.passed ? 'text-[#3fb950]' : 'text-[#f85149]'}>
                {gymResult.result?.final_score} {gymResult.result?.passed ? '✓ PASS' : '✗ FAIL'}
              </div>
            </div>
            <div>
              <div className="text-[#484f58] text-[9px]">TIER</div>
              <div className="text-[#00f5ff]">
                {gymResult.difficulty?.new_tier}/{gymResult.difficulty?.new_sub_tier}
                {gymResult.difficulty?.tier_changed && gymResult.difficulty.tier_changed !== 'none' && (
                  <span className="ml-1 text-[#FF9F00]">({gymResult.difficulty.tier_changed})</span>
                )}
              </div>
            </div>
            <div>
              <div className="text-[#484f58] text-[9px]">LEDGER HASH</div>
              <div className="text-[#3fb950] font-mono truncate">{gymResult.ledger?.hash}</div>
            </div>
          </div>
          {/* Pipeline steps */}
          <div className="flex flex-wrap gap-3 text-[10px]">
            {gymResult.steps?.map((s, i) => (
              <span key={i} className="flex items-center gap-1">
                {s.status === 'error' ? <AlertCircle size={9} className="text-[#f85149]" /> : <CheckCircle size={9} className="text-[#3fb950]" />}
                <span className="text-[#8b949e]">{s.step}:</span>
                <span className="text-[#e6edf3] font-mono">
                  {s.consolidated != null ? `${s.consolidated} consolidated${s.gate_failures ? `, ${s.gate_failures} gate fails` : ''}${s.falsification_failures ? `, ${s.falsification_failures} falsified` : ''}` : s.quality || s.tier_changed || s.status}
                </span>
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Sync result */}
      {syncError && (
        <div className="mt-2 flex items-center gap-2 text-[10px] text-[#f85149]">
          <AlertCircle size={11} /> Repo sync failed: {syncError}
        </div>
      )}
      {syncResult && (
        <div className="mt-2 border border-[#4DD0E1]/20 clip-corner p-2 bg-[#4DD0E1]/5">
          <div className="flex items-center gap-2 mb-1">
            <CheckCircle size={11} className="text-[#3fb950]" />
            <span className="text-[10px] font-bold text-[#4DD0E1] uppercase tracking-wider">Repo Sync Complete</span>
            <span className="text-[9px] text-[#484f58] ml-auto font-mono">{new Date(syncResult.syncedAt).toLocaleTimeString()}</span>
          </div>
          <div className="flex flex-wrap gap-3 text-[10px]">
            <span className="text-[#8b949e]">Commits: <span className="text-[#e6edf3] font-mono">{syncResult.commitsAnalyzed}</span></span>
            <span className="text-[#8b949e]">Files: <span className="text-[#e6edf3] font-mono">{syncResult.changedFilesAnalyzed}</span></span>
            {syncResult.noteTitle && (
              <span className="text-[#8b949e]">Insight: <span className="text-[#4DD0E1] truncate max-w-[300px]">{syncResult.noteTitle}</span></span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}