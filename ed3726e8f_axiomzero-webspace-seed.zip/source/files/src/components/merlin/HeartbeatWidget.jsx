/**
 * HeartbeatWidget — surfaces the autonomous training heartbeat cycles in the
 * Merlin Hub Telemetry tab. Reads MerlinNote records tagged 'training-heartbeat'
 * (session_token filter) and renders: last run, next run (4h cadence),
 * monotonic consolidation count, latest self-audit quality verdict, and a
 * collapsible live cycle log.
 *
 * Per Merlin's shaping: single-card, relative timestamps, no gauges/sparklines —
 * just truth. Read-only — no state mutation.
 */
import { useState, useEffect } from 'react';
import { Heart, ChevronDown, ChevronRight, Clock, CheckCircle2, AlertCircle, Loader2, RotateCw } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const HEARTBEAT_CADENCE_HOURS = 4;

function relativeTime(iso) {
  if (!iso) return '—';
  const now = Date.now();
  const then = new Date(iso).getTime();
  const diff = now - then;
  if (diff < 0) {
    const abs = -diff;
    const h = Math.floor(abs / 3600000);
    const m = Math.floor((abs % 3600000) / 60000);
    return h > 0 ? `in ${h}h ${m}m` : `in ${m}m`;
  }
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  if (h > 24) {
    const d = Math.floor(h / 24);
    return `${d}d ${h % 24}h ago`;
  }
  return h > 0 ? `${h}h ${m}m ago` : `${m}m ago`;
}

export default function HeartbeatWidget() {
  const [cycles, setCycles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expanded, setExpanded] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const fetchCycles = async () => {
    try {
      const notes = await base44.entities.MerlinNote.filter({ session_token: 'training-heartbeat' }, '-created_date', 20);
      setCycles(notes || []);
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    let mounted = true;
    base44.entities.MerlinNote.filter({ session_token: 'training-heartbeat' }, '-created_date', 20)
      .then((notes) => {
        if (!mounted) return;
        setCycles(notes || []);
        setLoading(false);
      })
      .catch((e) => {
        if (!mounted) return;
        setError(e.message);
        setLoading(false);
      });
    return () => { mounted = false; };
  }, []);

  if (loading) {
    return (
      <div className="glass-panel clip-corner p-3 flex items-center gap-2">
        <Loader2 size={12} className="animate-spin text-[#FF9F00]" />
        <span className="text-[10px] text-[#8b949e]">Loading heartbeat…</span>
      </div>
    );
  }

  if (error || cycles.length === 0) {
    return (
      <div className="glass-panel clip-corner p-3 flex items-center gap-2">
        <Heart size={12} className="text-[#484f58]" />
        <span className="text-[10px] text-[#484f58]">
          {error ? 'Heartbeat unavailable' : 'No heartbeat cycles yet — first run pending'}
        </span>
      </div>
    );
  }

  // Parse cycle data from distilled_primitives_json
  const parsed = cycles.map((c) => {
    let steps = [];
    try {
      const prims = JSON.parse(c.distilled_primitives_json || '{}');
      steps = prims.steps || [];
    } catch { /* malformed JSON — skip */ }
    return { id: c.id, created: c.created_date, steps };
  });

  const lastCycle = parsed[0];
  const lastRun = lastCycle?.created;
  const nextRun = lastRun
    ? new Date(new Date(lastRun).getTime() + HEARTBEAT_CADENCE_HOURS * 3600000).toISOString()
    : null;

  // Monotonic consolidation count across all cycles
  const totalConsolidations = parsed.reduce((sum, c) => {
    const conStep = c.steps.find((s) => s.step === 'consolidate');
    return sum + (conStep?.consolidated || 0);
  }, 0);

  // Latest audit quality verdict
  const latestAuditCycle = parsed.find((c) =>
    c.steps.find((s) => s.step === 'self-audit' && s.quality));
  const auditStep = latestAuditCycle?.steps.find((s) => s.step === 'self-audit');
  const auditQuality = auditStep?.quality || 'unknown';

  const qualityColor =
    auditQuality === 'well-calibrated' ? '#3fb950' :
    auditQuality === 'unknown' ? '#8b949e' : '#f85149';

  return (
    <div className="glass-panel clip-corner p-4 tactical-hud">
      <div className="flex items-center gap-2 mb-3">
        <Heart size={14} className="text-[#FF9F00] glow-pulse" />
        <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Training Heartbeat</h3>
        <span className="text-[9px] text-[#484f58] ml-auto font-mono">
          4h cadence · {cycles.length} cycle{cycles.length !== 1 ? 's' : ''} logged
        </span>
        <button
          onClick={() => { setRefreshing(true); fetchCycles(); }}
          className="text-[#4DD0E1] hover:text-[#00f5ff] transition-colors touch-manipulation"
          aria-label="Refresh heartbeat cycles"
          title="Refresh heartbeat cycles"
        >
          <RotateCw size={12} className={refreshing ? 'animate-spin' : ''} />
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-3">
        <div className="border border-[#30363d] clip-corner p-2.5">
          <div className="flex items-center gap-1.5 mb-1">
            <Clock size={10} className="text-[#4DD0E1]" />
            <span className="text-[9px] text-[#8b949e] uppercase font-bold">Last run</span>
          </div>
          <span className="text-sm font-mono text-[#e6edf3]">{relativeTime(lastRun)}</span>
        </div>
        <div className="border border-[#30363d] clip-corner p-2.5">
          <div className="flex items-center gap-1.5 mb-1">
            <Clock size={10} className="text-[#FF9F00]" />
            <span className="text-[9px] text-[#8b949e] uppercase font-bold">Next run</span>
          </div>
          <span className="text-sm font-mono text-[#e6edf3]">{relativeTime(nextRun)}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-3">
        <div className="border border-[#30363d] clip-corner p-2.5">
          <span className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">Consolidations</span>
          <span className="text-sm font-mono text-[#FF9F00]">{totalConsolidations}</span>
          <span className="text-[9px] text-[#484f58] ml-1">monotonic</span>
        </div>
        <div className="border border-[#30363d] clip-corner p-2.5">
          <span className="text-[9px] text-[#8b949e] uppercase font-bold block mb-1">Audit quality</span>
          <span className="text-sm font-mono" style={{ color: qualityColor }}>{auditQuality}</span>
        </div>
      </div>

      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-1.5 text-[10px] text-[#4DD0E1] hover:text-[#00f5ff] transition-colors touch-manipulation"
      >
        {expanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
        {expanded ? 'Collapse cycle log' : `Expand cycle log (${parsed.length})`}
      </button>

      {expanded && (
        <div className="mt-2 space-y-1.5 max-h-[300px] overflow-y-auto">
          {parsed.map((c) => {
            const conStep = c.steps.find((s) => s.step === 'consolidate');
            const audStep = c.steps.find((s) => s.step === 'self-audit');
            return (
              <div key={c.id} className="border border-[#30363d] clip-corner p-2 bg-[#0a0d11]">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-mono text-[#8b949e]">
                    {new Date(c.created).toISOString().slice(0, 16).replace('T', ' ')}
                  </span>
                  <span className="text-[9px] text-[#484f58]">{relativeTime(c.created)}</span>
                </div>
                <div className="flex items-center gap-3 text-[10px]">
                  <span className="flex items-center gap-1">
                    {conStep?.status === 'done'
                      ? <CheckCircle2 size={9} className="text-[#3fb950]" />
                      : <AlertCircle size={9} className="text-[#f85149]" />}
                    <span className="text-[#8b949e]">consolidate:</span>
                    <span className="text-[#e6edf3] font-mono">{conStep?.consolidated ?? 0}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    {audStep?.status === 'done'
                      ? <CheckCircle2 size={9} className="text-[#3fb950]" />
                      : <AlertCircle size={9} className="text-[#f85149]" />}
                    <span className="text-[#8b949e]">audit:</span>
                    <span className="font-mono" style={{
                      color: audStep?.quality === 'well-calibrated' ? '#3fb950' : '#8b949e'
                    }}>
                      {audStep?.quality || audStep?.status || '—'}
                    </span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}