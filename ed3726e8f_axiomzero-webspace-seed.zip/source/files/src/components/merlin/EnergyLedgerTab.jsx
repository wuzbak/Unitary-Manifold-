/**
 * EnergyLedgerTab — Sprint CH energy accounting surface.
 * Shows the getMerlinEnergyLedger data from the live repository, giving
 * visibility into energy-per-successful-task across all routing lanes.
 *
 * Action button: "Refresh Energy Ledger" force-refreshes the live program data
 * from the repo and renders the telemetry/energy data + last-refreshed
 * timestamp inline.
 */
import { useState } from 'react';
import { useMerlinNavigator } from '@/hooks/useMerlinNavigator';
import { Zap, Gauge, CheckCircle, AlertTriangle, ExternalLink, TrendingDown, RefreshCw } from 'lucide-react';

export default function EnergyLedgerTab() {
  const { data, isLoading, error, runStageA, isFetching } = useMerlinNavigator();
  const [lastRefreshed, setLastRefreshed] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const programSummary = data?.programSummary;
  const toolkitFunctions = programSummary?.toolkitFunctions || [];
  const hasEnergySurface = toolkitFunctions.includes('getMerlinEnergyLedger');

  const telemetry = data?.telemetry;
  const telemetryData = telemetry?.data || (telemetry?.isMarkdown ? null : null);

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await runStageA();
      setLastRefreshed(new Date().toISOString());
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Zap size={16} className="text-[#FF9F00]" />
        <h2 className="text-sm font-bold text-[#e6edf3] uppercase tracking-wider">Energy Ledger</h2>
        <span className="text-[10px] text-[#484f58] ml-auto">Sprint CH · Energy-Per-Successful-Task</span>
      </div>

      {/* Action bar */}
      <div className="glass-panel clip-corner p-3 flex flex-col sm:flex-row sm:items-center gap-2">
        <button
          onClick={handleRefresh}
          disabled={refreshing || isFetching}
          className="flex items-center gap-1.5 px-3 py-2 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner hover:bg-[#FF9F00]/20 transition-colors disabled:opacity-50 min-h-[36px]"
        >
          <RefreshCw size={12} className={refreshing || isFetching ? 'animate-spin' : ''} />
          {refreshing || isFetching ? 'Refreshing...' : 'Refresh Energy Ledger'}
        </button>
        {lastRefreshed && (
          <span className="text-[9px] text-[#484f58] font-mono">
            Last refreshed: {new Date(lastRefreshed).toLocaleTimeString()}
          </span>
        )}
      </div>

      {/* Sprint CH capability description */}
      <div className="glass-strong clip-corner p-4 border-l-2 border-[#FF9F00]">
        <div className="flex items-center gap-2 mb-2">
          <TrendingDown size={14} className="text-[#FF9F00]" />
          <h3 className="text-xs font-bold text-[#FF9F00] uppercase tracking-wider">Lower Energy-Per-Successful-Task</h3>
        </div>
        <p className="text-[11px] text-[#8b949e] leading-relaxed">
          The v1 Replacement Program's goal is lower energy-per-successful-task than the incumbent
          external-model path. The energy ledger tracks every inference's energy estimate, routing lane,
          provider, and success outcome. Sprint CH added this surface so the control tower can make
          deployment-eligibility decisions based on actual energy efficiency, not just latency.
        </p>
      </div>

      {/* Inline result */}
      {error ? (
        <div className="glass-panel clip-corner p-4 text-center">
          <p className="text-xs text-[#f85149]">Failed to load: {error?.message || 'Unknown error'}</p>
        </div>
      ) : isLoading ? (
        <div className="flex justify-center py-8">
          <div className="w-5 h-5 border-2 border-[#FF9F00]/30 border-t-[#FF9F00] rounded-full animate-spin" />
        </div>
      ) : (
        <>
          {/* Telemetry data (if available from fetchMerlinNavigator) */}
          {telemetryData && typeof telemetryData === 'object' && (
            <div className="glass-panel clip-corner p-4">
              <div className="flex items-center gap-2 mb-3">
                <Gauge size={14} className="text-[#00f5ff]" />
                <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Live Telemetry</h3>
              </div>
              <pre className="text-[10px] text-[#8b949e] font-mono overflow-x-auto max-h-[300px]">
                {JSON.stringify(telemetryData, null, 2).slice(0, 3000)}
              </pre>
            </div>
          )}
          {!telemetryData && (
            <div className="glass-panel clip-corner p-4">
              <div className="flex items-center gap-2 text-[11px] text-[#8b949e]">
                <AlertTriangle size={12} className="text-[#FF9F00]" />
                <span>No structured telemetry JSON committed in the repository yet. Press "Refresh Energy Ledger" to pull the latest.</span>
              </div>
            </div>
          )}

          {/* Available surfaces */}
          <div className="glass-panel clip-corner p-4">
            <div className="flex items-center gap-2 mb-3">
              <Zap size={14} className="text-[#00f5ff]" />
              <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Toolkit Surfaces</h3>
            </div>
            {hasEnergySurface ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2 border border-[#FF9F00]/15 clip-corner px-3 py-2">
                  <CheckCircle size={12} className="text-[#3fb950] shrink-0" />
                  <code className="text-[11px] text-[#FF9F00] font-mono">getMerlinEnergyLedger</code>
                </div>
                <div className="flex items-center gap-2 border border-[#FF9F00]/15 clip-corner px-3 py-2">
                  <CheckCircle size={12} className="text-[#3fb950] shrink-0" />
                  <code className="text-[11px] text-[#FF9F00] font-mono">GET /api/merlin/energy-ledger</code>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-[11px] text-[#8b949e]">
                <AlertTriangle size={12} className="text-[#FF9F00]" />
                <span>Energy ledger surface not yet detected in the live program summary.</span>
              </div>
            )}
          </div>
        </>
      )}

      {/* Link to repo */}
      <div className="glass-panel clip-corner p-3">
        <a
          href="https://github.com/wuzbak/Unitary-Manifold-/blob/main/12-AZ-IP/20-psicat-navigator/PSICAT_PROGRAM.md"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 text-[10px] text-[#FF9F00] hover:opacity-70"
        >
          <ExternalLink size={10} /> View PSICAT_PROGRAM.md (v1 Replacement Program)
        </a>
      </div>
    </div>
  );
}