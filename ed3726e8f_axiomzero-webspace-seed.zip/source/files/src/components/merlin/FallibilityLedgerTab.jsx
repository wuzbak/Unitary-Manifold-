/**
 * FallibilityLedgerTab — PsiCat's ledger of errors, gaps, and broken things
 * on the webspace. Pulls up an overlay of his tracked issues to fix.
 *
 * Features:
 *  - View all fallibility entries (open, in_progress, resolved)
 *  - Add a new entry (manual or from Merlin auto-scan)
 *  - Update status (open → in_progress → resolved)
 *  - Filter by category, severity, status
 *  - Merlin can auto-scan for issues using the agent loop
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Loader2, AlertCircle, AlertTriangle, Info, Check, X, Bug, Filter, RefreshCw, Sparkles, Brain } from 'lucide-react';

const CATEGORIES = ['ui', 'ux', 'function', 'broken_link', 'error', 'gap', 'performance', 'content', 'other'];
const SEVERITIES = {
  critical: { label: 'Critical', color: '#f85149', icon: AlertCircle },
  warning: { label: 'Warning', color: '#fbbf24', icon: AlertTriangle },
  info: { label: 'Info', color: '#4dd0e1', icon: Info },
};
const STATUSES = {
  open: { label: 'Open', color: '#f85149' },
  in_progress: { label: 'In Progress', color: '#fbbf24' },
  resolved: { label: 'Resolved', color: '#3fb950' },
  wont_fix: { label: "Won't Fix", color: '#484f58' },
};

export default function FallibilityLedgerTab() {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [newEntry, setNewEntry] = useState({ title: '', description: '', category: 'other', severity: 'warning', page_path: '', component: '' });
  const [suggesting, setSuggesting] = useState({});

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const list = await base44.entities.FallibilityEntry.list('-created_date', 200);
      setEntries(list);
    } catch { setEntries([]); }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = entries.filter(e => {
    if (filterStatus !== 'all' && e.status !== filterStatus) return false;
    if (filterCategory !== 'all' && e.category !== filterCategory) return false;
    return true;
  });

  const summary = {
    total: entries.length,
    open: entries.filter(e => e.status === 'open').length,
    in_progress: entries.filter(e => e.status === 'in_progress').length,
    resolved: entries.filter(e => e.status === 'resolved').length,
    critical: entries.filter(e => e.severity === 'critical' && e.status === 'open').length,
  };

  const handleAdd = async () => {
    if (!newEntry.title.trim()) return;
    try {
      await base44.entities.FallibilityEntry.create({
        ...newEntry,
        status: 'open',
        discovered_by: 'manual',
      });
      setNewEntry({ title: '', description: '', category: 'other', severity: 'warning', page_path: '', component: '' });
      setShowAdd(false);
      load();
    } catch (e) { alert('Failed to add entry: ' + e.message); }
  };

  const updateStatus = async (id, status) => {
    try {
      const patch = { status };
      if (status === 'resolved') patch.resolved_date = new Date().toISOString().split('T')[0];
      await base44.entities.FallibilityEntry.update(id, patch);
      load();
    } catch (e) { alert('Failed to update: ' + e.message); }
  };

  const deleteEntry = async (id) => {
    try {
      await base44.entities.FallibilityEntry.delete(id);
      load();
    } catch (e) { alert('Failed to delete: ' + e.message); }
  };

  const getSuggestion = async (entry) => {
    setSuggesting(prev => ({ ...prev, [entry.id]: true }));
    try {
      await base44.functions.invoke('merlinFallibilitySuggest', { entry_id: entry.id });
      load();
    } catch (e) { alert('Failed to get suggestion: ' + e.message); }
    setSuggesting(prev => { const next = { ...prev }; delete next[entry.id]; return next; });
  };

  return (
    <div className="space-y-3">
      {/* Header + summary */}
      <div className="glass-strong clip-corner p-3">
        <div className="flex items-center justify-between gap-2 flex-wrap mb-3">
          <div className="flex items-center gap-2">
            <Bug size={14} className="text-[#f85149]" />
            <span className="text-xs font-bold text-[#e6edf3]">Website Fallibility Ledger</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={load} className="flex items-center gap-1 px-2 py-1.5 border border-[#30363d] rounded text-[9px] text-[#8b949e] hover:text-[#e6edf3]">
              <RefreshCw size={10} /> Refresh
            </button>
            <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[9px] font-bold bg-[#f85149] text-black">
              <Plus size={10} /> Add Issue
            </button>
          </div>
        </div>

        {/* Summary stats */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#0B0F13] border border-[#30363d] rounded">
            <span className="text-[10px] font-bold text-[#e6edf3]">{summary.total}</span>
            <span className="text-[8px] text-[#484f58]">total</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#0B0F13] border border-[#f85149]/30 rounded">
            <span className="text-[10px] font-bold text-[#f85149]">{summary.open}</span>
            <span className="text-[8px] text-[#484f58]">open</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#0B0F13] border border-[#fbbf24]/30 rounded">
            <span className="text-[10px] font-bold text-[#fbbf24]">{summary.in_progress}</span>
            <span className="text-[8px] text-[#484f58]">in progress</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#0B0F13] border border-[#3fb950]/30 rounded">
            <span className="text-[10px] font-bold text-[#3fb950]">{summary.resolved}</span>
            <span className="text-[8px] text-[#484f58]">resolved</span>
          </div>
          {summary.critical > 0 && (
            <div className="flex items-center gap-1.5 px-2 py-1 bg-[#f85149]/10 border border-[#f85149]/40 rounded">
              <AlertCircle size={10} className="text-[#f85149]" />
              <span className="text-[9px] font-bold text-[#f85149]">{summary.critical} critical open</span>
            </div>
          )}
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 flex-wrap mt-2 pt-2 border-t border-[#30363d]">
          <Filter size={10} className="text-[#484f58]" />
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded text-[9px] text-[#e6edf3] px-2 py-1">
            <option value="all">All Status</option>
            {Object.entries(STATUSES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
          <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded text-[9px] text-[#e6edf3] px-2 py-1">
            <option value="all">All Categories</option>
            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <span className="text-[8px] text-[#484f58] ml-auto">{filtered.length} shown</span>
        </div>
      </div>

      {/* Add new entry form */}
      {showAdd && (
        <div className="glass-strong clip-corner p-3 fade-in">
          <div className="text-[10px] font-bold text-[#e6edf3] mb-2">Log New Issue</div>
          <input
            value={newEntry.title}
            onChange={(e) => setNewEntry({ ...newEntry, title: e.target.value })}
            placeholder="Issue title (e.g. 'Export button not working on Cast tab')"
            className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2.5 py-2 text-[10px] text-[#e6edf3] mb-2 focus:border-[#f85149]/40 focus:outline-none"
          />
          <textarea
            value={newEntry.description}
            onChange={(e) => setNewEntry({ ...newEntry, description: e.target.value })}
            placeholder="What's wrong? What was expected? What happened?"
            className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2.5 py-2 text-[10px] text-[#e6edf3] mb-2 focus:border-[#f85149]/40 focus:outline-none resize-y"
            rows={3}
          />
          <div className="flex items-center gap-2 flex-wrap mb-2">
            <select value={newEntry.category} onChange={(e) => setNewEntry({ ...newEntry, category: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded text-[9px] text-[#e6edf3] px-2 py-1.5">
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={newEntry.severity} onChange={(e) => setNewEntry({ ...newEntry, severity: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded text-[9px] text-[#e6edf3] px-2 py-1.5">
              {Object.entries(SEVERITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
            <input
              value={newEntry.page_path}
              onChange={(e) => setNewEntry({ ...newEntry, page_path: e.target.value })}
              placeholder="/page-path"
              className="flex-1 min-w-[100px] bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[9px] text-[#e6edf3]"
            />
          </div>
          <div className="flex items-center gap-2">
            <button onClick={handleAdd} disabled={!newEntry.title.trim()} className="px-3 py-1.5 rounded text-[9px] font-bold bg-[#f85149] text-black disabled:opacity-40">
              <Plus size={10} className="inline mr-1" /> Add to Ledger
            </button>
            <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 rounded text-[9px] border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]">
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Entries list */}
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 size={16} className="animate-spin text-[#484f58]" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="glass-panel clip-corner p-6 text-center">
          <Bug size={20} className="text-[#484f58] mx-auto mb-2" />
          <p className="text-[10px] text-[#8b949e]">{entries.length === 0 ? 'No issues logged. The webspace looks clean.' : 'No issues match the current filters.'}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((entry) => {
            const sev = SEVERITIES[entry.severity] || SEVERITIES.info;
            const status = STATUSES[entry.status] || STATUSES.open;
            const SevIcon = sev.icon;
            return (
              <div key={entry.id} className="glass-panel clip-corner p-3 fade-in" style={{ borderLeft: `2px solid ${sev.color}` }}>
                <div className="flex items-start gap-2">
                  <SevIcon size={12} style={{ color: sev.color }} className="shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="text-[10px] font-bold text-[#e6edf3]">{entry.title}</span>
                      <span className="text-[7px] px-1 rounded font-bold" style={{ background: status.color, color: '#000' }}>{status.label}</span>
                      <span className="text-[7px] px-1 rounded border border-[#30363d] text-[#8b949e]">{entry.category}</span>
                      {entry.page_path && <span className="text-[7px] text-[#484f58] font-mono">{entry.page_path}</span>}
                      {entry.discovered_by === 'merlin_auto' && <Sparkles size={8} className="text-[#fbbf24]" />}
                    </div>
                    {entry.description && <p className="text-[9px] text-[#8b949e] leading-relaxed mb-2">{entry.description}</p>}
                    {entry.component && <p className="text-[8px] text-[#484f58] mb-1">Component: {entry.component}</p>}
                    {entry.resolution_notes && <p className="text-[8px] text-[#3fb950] leading-relaxed">✓ {entry.resolution_notes}</p>}

                    {/* Status actions */}
                    <div className="flex items-center gap-1.5 mt-2">
                      <button
                        onClick={() => getSuggestion(entry)}
                        disabled={suggesting[entry.id]}
                        className="flex items-center gap-1 px-1.5 py-0.5 text-[7px] border border-[#FF9F00]/30 text-[#FF9F00] hover:bg-[#FF9F00]/10 rounded disabled:opacity-40"
                      >
                        {suggesting[entry.id] ? <Loader2 size={8} className="animate-spin" /> : <Brain size={8} />} PsiCat
                      </button>
                      {entry.status !== 'open' && (
                        <button onClick={() => updateStatus(entry.id, 'open')} className="px-1.5 py-0.5 rounded text-[7px] border border-[#30363d] text-[#8b949e] hover:text-[#f85149]">Reopen</button>
                      )}
                      {entry.status === 'open' && (
                        <button onClick={() => updateStatus(entry.id, 'in_progress')} className="px-1.5 py-0.5 rounded text-[7px] border border-[#fbbf24]/30 text-[#fbbf24] hover:bg-[#fbbf24]/10">Start</button>
                      )}
                      {entry.status !== 'resolved' && (
                        <button onClick={() => updateStatus(entry.id, 'resolved')} className="px-1.5 py-0.5 rounded text-[7px] border border-[#3fb950]/30 text-[#3fb950] hover:bg-[#3fb950]/10">Resolve</button>
                      )}
                      {entry.status !== 'wont_fix' && (
                        <button onClick={() => updateStatus(entry.id, 'wont_fix')} className="px-1.5 py-0.5 rounded text-[7px] border border-[#30363d] text-[#484f58] hover:text-[#8b949e]">Won't Fix</button>
                      )}
                      <button onClick={() => deleteEntry(entry.id)} className="px-1.5 py-0.5 rounded text-[7px] border border-[#30363d] text-[#484f58] hover:text-[#f85149] ml-auto">
                        <X size={9} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}