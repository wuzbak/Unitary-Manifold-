/**
 * SessionLibrary — collapsible left rail showing saved Merlin sessions.
 * Lists sessions from the MerlinSession entity (cross-device library),
 * grouped by context type. Users can load, search, and delete sessions.
 *
 * Also shows the active (localStorage) session with a "Save to Library" action.
 */
import { useState, useEffect, useCallback } from 'react';
import { listSavedSessions, deleteSavedSession, loadActiveSession, saveActiveSession, autoTitle, saveSessionToLibrary } from '@/lib/merlinMemory';
import { MessageSquare, Shield, Layers, Globe, FlaskConical, Search, Trash2, Save, Loader2, Library } from 'lucide-react';

const TYPE_META = {
  chat: { icon: MessageSquare, color: '#00f5ff', label: 'Chat' },
  interrogation: { icon: Shield, color: '#ff3b30', label: 'Interrogation' },
  flashcards: { icon: Layers, color: '#bc8cff', label: 'Flashcards' },
  'geo-interpretation': { icon: Globe, color: '#4dd0e1', label: 'Geo-Interpretation' },
  falsification: { icon: FlaskConical, color: '#ff9f0a', label: 'Falsification' },
};

export default function SessionLibrary({ onSessionLoad }) {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [saving, setSaving] = useState(false);
  const [activeSession, setActiveSession] = useState(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    const saved = await listSavedSessions();
    setSessions(saved);
    setActiveSession(loadActiveSession());
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  // Listen for active session changes
  useEffect(() => {
    const handler = () => setActiveSession(loadActiveSession());
    window.addEventListener('merlin-session-updated', handler);
    window.addEventListener('storage', handler);
    return () => {
      window.removeEventListener('merlin-session-updated', handler);
      window.removeEventListener('storage', handler);
    };
  }, []);

  const handleLoad = (session) => {
    // Load saved session into active localStorage
    const loaded = {
      title: session.title,
      context_type: session.context_type,
      messages: session.messages_json ? JSON.parse(session.messages_json) : (session.messages || []),
      deck: session.deck_json ? JSON.parse(session.deck_json) : (session.deck || []),
    };
    saveActiveSession(loaded);
    setActiveSession(loaded);
    // Notify MerlinInterface to reload — pass session data in detail
    // (sovereign ephemeral: no localStorage, data flows through event)
    window.dispatchEvent(new CustomEvent('merlin-session-loaded', { detail: loaded }));
    onSessionLoad?.(loaded);
  };

  const handleDelete = async (session) => {
    const id = session.entityId || session.id;
    await deleteSavedSession(id);
    refresh();
  };

  const handleSaveActive = async () => {
    if (!activeSession || !activeSession.messages?.length) return;
    setSaving(true);
    try {
      const title = autoTitle(activeSession.messages);
      await saveSessionToLibrary({ ...activeSession, title });
      refresh();
    } catch { /* noop */ }
    setSaving(false);
  };

  // Filter sessions
  const filtered = sessions.filter(s => {
    const type = s.context_type || 'chat';
    if (filter !== 'all' && type !== filter) return false;
    if (search.trim()) {
      const title = (s.title || '').toLowerCase();
      return title.includes(search.toLowerCase());
    }
    return true;
  });

  // Group by type
  const grouped = filtered.reduce((acc, s) => {
    const type = s.context_type || 'chat';
    if (!acc[type]) acc[type] = [];
    acc[type].push(s);
    return acc;
  }, {});

  return (
    <div className="glass-strong clip-corner p-3 h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-2 mb-3 pb-2 border-b border-[#30363d]">
        <Library size={14} className="text-[#00f5ff]" />
        <span className="text-xs font-bold text-[#00f5ff] uppercase tracking-wider">Session Library</span>
      </div>

      {/* Active session */}
      {activeSession && activeSession.messages?.length > 0 && (
        <div className="mb-3 pb-3 border-b border-[#30363d]">
          <div className="text-[9px] text-[#484f58] uppercase tracking-wider mb-1.5">Active Session</div>
          <div className="glass-panel clip-corner p-2">
            <div className="text-[10px] text-[#e6edf3] font-bold truncate">{autoTitle(activeSession.messages)}</div>
            <div className="text-[9px] text-[#484f58] mt-0.5">{activeSession.messages.length} messages · {activeSession.context_type}</div>
            <button
              onClick={handleSaveActive}
              disabled={saving}
              className="mt-2 w-full flex items-center justify-center gap-1.5 px-2 py-1.5 text-[9px] font-bold text-[#3fb950] border border-[#3fb950]/30 bg-[#3fb950]/5 hover:bg-[#3fb950]/10 clip-corner disabled:opacity-50"
            >
              {saving ? <Loader2 size={10} className="animate-spin" /> : <Save size={10} />}
              Save to Library
            </button>
          </div>
        </div>
      )}

      {/* Search */}
      <input
        value={search}
        onChange={e => setSearch(e.target.value)}
        placeholder="Search sessions..."
        className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] mb-2 focus:outline-none focus:border-[#00f5ff]/40"
      />

      {/* Filter chips */}
      <div className="flex flex-wrap gap-1 mb-3">
        <button
          onClick={() => setFilter('all')}
          className={`px-2 py-0.5 text-[9px] font-bold clip-corner ${filter === 'all' ? 'bg-[#00f5ff] text-black' : 'text-[#8b949e] border border-[#30363d]'}`}
        >
          All
        </button>
        {Object.entries(TYPE_META).map(([key, meta]) => (
          <button
            key={key}
            onClick={() => setFilter(key)}
            className={`px-2 py-0.5 text-[9px] font-bold clip-corner ${filter === key ? 'text-black' : 'text-[#8b949e] border border-[#30363d]'}`}
            style={filter === key ? { background: meta.color } : {}}
          >
            {meta.label}
          </button>
        ))}
      </div>

      {/* Session list */}
      <div className="flex-1 overflow-y-auto space-y-1.5 min-h-0">
        {loading ? (
          <div className="flex items-center justify-center py-4">
            <Loader2 size={14} className="animate-spin text-[#484f58]" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-4 text-[10px] text-[#484f58]">
            {search ? 'No sessions match your search' : 'No saved sessions yet. Use "Save to Library" to persist a session.'}
          </div>
        ) : (
          Object.entries(grouped).map(([type, items]) => {
            const meta = TYPE_META[type] || TYPE_META.chat;
            const Icon = meta.icon;
            return (
              <div key={type}>
                <div className="flex items-center gap-1.5 mb-1 mt-2">
                  <Icon size={10} style={{ color: meta.color }} />
                  <span className="text-[9px] font-bold uppercase tracking-wider" style={{ color: meta.color }}>
                    {meta.label} ({items.length})
                  </span>
                </div>
                {items.map(s => (
                  <div
                    key={s.id || s.entityId}
                    className="group flex items-center gap-1.5 glass-panel clip-corner p-2 hover:border-[#00f5ff]/30 transition-colors"
                  >
                    <button
                      onClick={() => handleLoad(s)}
                      className="flex-1 text-left min-w-0"
                    >
                      <div className="text-[10px] text-[#e6edf3] font-bold truncate">{s.title}</div>
                      <div className="text-[9px] text-[#484f58]">
                        {new Date(s.updated_date || s.created_date || Date.now()).toLocaleDateString()}
                      </div>
                    </button>
                    <button
                      onClick={() => handleDelete(s)}
                      className="text-[#484f58] hover:text-[#ff3b30] transition-colors shrink-0 p-1"
                    >
                      <Trash2 size={11} />
                    </button>
                  </div>
                ))}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}