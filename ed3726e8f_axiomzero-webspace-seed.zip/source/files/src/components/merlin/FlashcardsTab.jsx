/**
 * FlashcardsTab — Merlin's AI-generated flashcard deck builder.
 * Generates flashcard decks on demand from live repository content via the
 * oxQuery backend. Each card: front (question/term), back (answer + pillar
 * citation + gate badge). Decks are cached in localStorage and can be saved
 * to the cross-device library.
 *
 * Replaces the OX Navigator's static 8-card flashcard trainer with dynamic,
 * repository-grounded decks that stay current with the framework.
 */
import { useState, useCallback, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { saveActiveSession, saveSessionToLibrary } from '@/lib/merlinMemory';
import GateBadge from '@/components/quantum-cat/GateBadge';
import { Layers, Loader2, Sparkles, RefreshCw, Save, ChevronLeft, ChevronRight, BookOpen } from 'lucide-react';

const CACHE_KEY = 'merlin_flashcard_decks';

function loadCachedDecks() {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function cacheDeck(deck) {
  try {
    const decks = loadCachedDecks();
    // Keep last 10 decks
    decks.unshift(deck);
    localStorage.setItem(CACHE_KEY, JSON.stringify(decks.slice(0, 10)));
  } catch { /* noop */ }
}

const TOPIC_SUGGESTIONS = [
  'Kaluza-Klein compactification',
  'Pillar 396 braided radius',
  'The (5,7,74) kernel',
  'Neutrino mass hierarchy',
  'CMB birefringence prediction',
  'KK dark matter candidate',
  'DESI w_a tension',
  'Winding resonance stability',
];

export default function FlashcardsTab() {
  const [topic, setTopic] = useState('');
  const [deck, setDeck] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [idx, setIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [savedDecks, setSavedDecks] = useState([]);
  const [saveStatus, setSaveStatus] = useState('');

  useEffect(() => {
    setSavedDecks(loadCachedDecks());
  }, []);

  const generate = useCallback(async (topicText) => {
    const t = (topicText || topic).trim();
    if (!t || loading) return;
    setLoading(true);
    setError(null);
    setDeck(null);
    setIdx(0);
    setFlipped(false);
    try {
      const res = await base44.functions.invoke('oxQuery', {
        query: `Generate 8 educational flashcards about: "${t}". For each card provide: front (a concise question or term), back (a 1-2 sentence answer), pillar (the pillar number if applicable, or 0), gate (one of: HARDGATE, ADJACENT_TRACK, DERIVED, OPEN_GAP, ARCHITECTURE_LIMIT). Format the answer field as a JSON array: [{"front":"...","back":"...","pillar":396,"gate":"HARDGATE"}].`,
        contextTier: 'full',
        systemPromptPrefix: 'You are the Merlin Flashcard Generator. Generate educational flashcards from the repository context. Return the flashcards as a JSON array in the answer field. Each card must have a front, back, pillar number, and gate label.',
      });
      const data = res.data || res;
      if (data.error) throw new Error(data.error);

      // Parse the answer field as JSON array of flashcards
      let cards = [];
      try {
        const parsed = JSON.parse(data.answer);
        if (Array.isArray(parsed)) cards = parsed;
      } catch {
        // Try extracting JSON from the answer
        const match = data.answer.match(/\[[\s\S]*\]/);
        if (match) {
          try { cards = JSON.parse(match[0]); } catch { /* fall through */ }
        }
      }

      if (cards.length === 0) throw new Error('No flashcards parsed from response');

      const newDeck = {
        topic: t,
        cards,
        generatedAt: new Date().toISOString(),
        model: data.model,
        caveat: data.caveat,
      };

      setDeck(newDeck);
      cacheDeck(newDeck);
      setSavedDecks(loadCachedDecks());

      // Save to active session memory
      saveActiveSession({
        title: `Flashcards: ${t}`,
        context_type: 'flashcards',
        messages: [{ role: 'user', text: t, time: Date.now() }],
        deck: cards,
      });
    } catch (e) {
      setError(e.message || 'Flashcard generation failed');
    }
    setLoading(false);
  }, [topic, loading]);

  const saveToLibrary = async () => {
    if (!deck) return;
    setSaveStatus('Saving...');
    try {
      await saveSessionToLibrary({
        title: `Flashcards: ${deck.topic}`,
        context_type: 'flashcards',
        messages: [],
        deck: deck.cards,
      });
      setSaveStatus('Saved to library ✓');
      setTimeout(() => setSaveStatus(''), 2000);
    } catch {
      setSaveStatus('Save failed — try again');
      setTimeout(() => setSaveStatus(''), 2000);
    }
  };

  const card = deck && deck.cards[idx];

  return (
    <div className="space-y-4 fade-in">
      {/* Topic input */}
      <div className="glass-panel clip-corner p-4">
        <div className="flex items-center gap-2 mb-3">
          <Layers size={14} className="text-[#bc8cff]" />
          <span className="text-xs font-bold text-[#bc8cff] uppercase tracking-wider">AI Flashcard Generator</span>
        </div>
        <div className="flex gap-2">
          <input
            value={topic}
            onChange={e => setTopic(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && generate()}
            placeholder="Enter a topic (e.g. 'Kaluza-Klein compactification')"
            className="flex-1 bg-[#0d1117] border border-[#30363d] rounded px-3 py-2.5 text-xs text-[#e6edf3] focus:outline-none focus:border-[#bc8cff]/50"
          />
          <button
            onClick={() => generate()}
            disabled={loading || !topic.trim()}
            className="flex items-center gap-1.5 px-5 py-2.5 bg-gradient-to-r from-[#bc8cff] to-[#7c4dff] text-white text-xs font-bold clip-corner disabled:opacity-40 min-h-[44px]"
          >
            {loading ? <><Loader2 size={12} className="animate-spin" /> Generating...</> : <><Sparkles size={12} /> Generate Deck</>}
          </button>
        </div>
        {/* Topic suggestions */}
        <div className="flex flex-wrap gap-1.5 mt-3">
          {TOPIC_SUGGESTIONS.map(s => (
            <button
              key={s}
              onClick={() => { setTopic(s); generate(s); }}
              className="px-2.5 py-1 text-[10px] text-[#bc8cff] border border-[#bc8cff]/20 bg-[#bc8cff]/5 hover:bg-[#bc8cff]/10 clip-corner transition-colors"
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="glass-strong clip-corner p-8 flex flex-col items-center gap-3">
          <Loader2 size={24} className="animate-spin text-[#bc8cff]" />
          <div className="text-xs text-[#8b949e]">Merlin is generating flashcards from the live repository...</div>
        </div>
      )}

      {/* Error */}
      {error && !loading && (
        <div className="bg-[#2a1a0a] border border-[#f85149]/30 clip-corner p-3">
          <p className="text-[#f85149] text-xs">{error}</p>
        </div>
      )}

      {/* Flashcard display */}
      {deck && !loading && card && (
        <div className="max-w-2xl mx-auto space-y-4">
          {/* Card counter + save */}
          <div className="flex items-center justify-between">
            <div className="text-[10px] text-[#8b949e]">
              Card {idx + 1} / {deck.cards.length} · <span className="text-[#bc8cff]">{deck.topic}</span>
            </div>
            <button
              onClick={saveToLibrary}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-[#3fb950]/30 text-[#3fb950] text-[10px] font-bold clip-corner hover:bg-[#3fb950]/10"
            >
              <Save size={11} /> {saveStatus || 'Save to Library'}
            </button>
          </div>

          {/* Flip card */}
          <button
            onClick={() => setFlipped(!flipped)}
            className="w-full glass-strong clip-corner p-8 min-h-[220px] flex items-center justify-center text-center glow-hover transition-all"
          >
            <div className="space-y-3">
              {card.gate && <GateBadge gate={card.gate} size="sm" />}
              <div className="text-lg text-[#e6edf3] font-body leading-relaxed">
                {flipped ? card.back : card.front}
              </div>
              {flipped && card.pillar > 0 && (
                <div className="text-[10px] text-[#4dd0e1]">Pillar {card.pillar}</div>
              )}
              <div className="text-[9px] text-[#484f58]">
                {flipped ? 'Click to flip back' : 'Click to reveal answer'}
              </div>
            </div>
          </button>

          {/* Navigation */}
          <div className="flex justify-between items-center">
            <button
              onClick={() => { setIdx((idx - 1 + deck.cards.length) % deck.cards.length); setFlipped(false); }}
              className="flex items-center gap-1.5 px-4 py-2 border border-[#30363d] text-xs text-[#8b949e] hover:text-[#e6edf3] clip-corner"
            >
              <ChevronLeft size={14} /> Prev
            </button>
            <button
              onClick={() => generate(deck.topic)}
              className="flex items-center gap-1.5 px-4 py-2 border border-[#bc8cff]/30 text-[#bc8cff] text-xs hover:bg-[#bc8cff]/10 clip-corner"
            >
              <RefreshCw size={12} /> Regenerate
            </button>
            <button
              onClick={() => { setIdx((idx + 1) % deck.cards.length); setFlipped(false); }}
              className="flex items-center gap-1.5 px-4 py-2 bg-[#bc8cff] text-white text-xs font-bold clip-corner"
            >
              Next <ChevronRight size={14} />
            </button>
          </div>

          {/* Caveat */}
          {deck.caveat && (
            <div className="text-[9px] text-[#484f58] italic text-center border-t border-[#30363d] pt-2">
              {deck.caveat}
            </div>
          )}
        </div>
      )}

      {/* Empty state */}
      {!deck && !loading && !error && (
        <div className="glass-panel clip-corner p-8 text-center">
          <BookOpen size={32} className="mx-auto text-[#bc8cff]/40 mb-3" />
          <div className="text-xs text-[#8b949e] max-w-md mx-auto mb-2">
            Generate flashcard decks on any Unitary Manifold topic. Merlin creates them from the live repository —
            every card carries a gate badge and pillar citation. Decks are cached locally and can be saved to your
            cross-device library.
          </div>
          {savedDecks.length > 0 && (
            <div className="mt-4">
              <div className="text-[10px] text-[#484f58] mb-2">Recently generated decks (cached locally):</div>
              <div className="flex flex-wrap gap-1.5 justify-center">
                {savedDecks.slice(0, 5).map((d, i) => (
                  <button
                    key={i}
                    onClick={() => { setDeck(d); setIdx(0); setFlipped(false); }}
                    className="px-2.5 py-1 text-[10px] text-[#bc8cff] border border-[#bc8cff]/20 bg-[#bc8cff]/5 hover:bg-[#bc8cff]/10 clip-corner"
                  >
                    {d.topic}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}