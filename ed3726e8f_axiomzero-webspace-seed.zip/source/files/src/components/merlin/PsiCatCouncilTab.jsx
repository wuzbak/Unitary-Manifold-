/**
 * PsiCatCouncilTab — PsiCat's autonomous pre-planning council.
 *
 * PsiCat is promoted to FULL ADMIN for the PsiCat Hub and Training Gym pages.
 * This tab displays his proposed tasks (generated via ungated LLM calls), with
 * reasoning, priority, and effort estimates. The administrator reviews each
 * proposal and can approve, modify, reject, or mark as done.
 *
 * Features:
 *  - View all council proposals (proposed, approved, rejected, in_progress, done)
 *  - "Generate Proposals" button — triggers merlinCouncilPropose autonomously
 *  - Approve / Reject / Start / Complete workflow
 *  - Admin notes on each proposal
 *  - Summary stats (proposed, approved, in_progress, done)
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2, Sparkles, Check, X, Play, CheckCircle, Plus, RefreshCw, AlertCircle, Zap, Brain, Send } from 'lucide-react';

const CATEGORIES = ['feature', 'fix', 'enhancement', 'gym_module', 'open_science', 'repo_sync', 'ui_ux', 'architecture', 'content', 'other'];
const PRIORITIES = {
  urgent: { label: 'Urgent', color: '#f85149' },
  high: { label: 'High', color: '#FF9F00' },
  medium: { label: 'Medium', color: '#4dd0e1' },
  low: { label: 'Low', color: '#484f58' },
};
const STATUSES = {
  proposed: { label: 'Proposed', color: '#4dd0e1' },
  approved: { label: 'Approved', color: '#3fb950' },
  rejected: { label: 'Rejected', color: '#f85149' },
  in_progress: { label: 'In Progress', color: '#FF9F00' },
  done: { label: 'Done', color: '#3fb950' },
};
const EFFORTS = {
  trivial: { label: 'Trivial', color: '#3fb950' },
  small: { label: 'Small', color: '#4dd0e1' },
  medium: { label: 'Medium', color: '#FF9F00' },
  large: { label: 'Large', color: '#f85149' },
  epic: { label: 'Epic', color: '#bc8cff' },
};

export default function PsiCatCouncilTab() {
  const [proposals, setProposals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [filterStatus, setFilterStatus] = useState('all');
  const [showAdd, setShowAdd] = useState(false);
  const [newProposal, setNewProposal] = useState({ title: '', description: '', reasoning: '', category: 'feature', priority: 'medium', page_target: '', estimated_effort: 'small' });
  const [relayModal, setRelayModal] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const list = await base44.entities.PsiCatCouncil.list('-created_date', 200);
      setProposals(list);
    } catch { setProposals([]); }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = proposals.filter(p => {
    if (filterStatus !== 'all' && p.status !== filterStatus) return false;
    return true;
  });

  const summary = {
    total: proposals.length,
    proposed: proposals.filter(p => p.status === 'proposed').length,
    approved: proposals.filter(p => p.status === 'approved').length,
    in_progress: proposals.filter(p => p.status === 'in_progress').length,
    done: proposals.filter(p => p.status === 'done').length,
    urgent: proposals.filter(p => p.priority === 'urgent' && p.status === 'proposed').length,
  };

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      await base44.functions.invoke('merlinCouncilPropose', { max_proposals: 5 });
      load();
    } catch (e) { alert('Failed to generate proposals: ' + e.message); }
    setGenerating(false);
  };

  const updateStatus = async (id, status, adminNotes = '') => {
    try {
      const patch = { status };
      if (adminNotes) patch.admin_notes = adminNotes;
      await base44.entities.PsiCatCouncil.update(id, patch);
      load();
    } catch (e) { alert('Failed to update: ' + e.message); }
  };

  const handleAdd = async () => {
    if (!newProposal.title.trim()) return;
    try {
      await base44.entities.PsiCatCouncil.create({
        ...newProposal,
        status: 'proposed',
        auto_generated: false,
      });
      setNewProposal({ title: '', description: '', reasoning: '', category: 'feature', priority: 'medium', page_target: '', estimated_effort: 'small' });
      setShowAdd(false);
      load();
    } catch (e) { alert('Failed to add proposal: ' + e.message); }
  };

  const handleRelay = async (proposal) => {
    try {
      await base44.functions.invoke('merlinRelayEmail', {
        subject: `Council proposal: ${proposal.title}`,
        message: proposal.description,
        reasoning: proposal.reasoning,
        page_path: proposal.page_target || '/psicat',
        linked_council_id: proposal.id,
        priority: proposal.priority === 'urgent' ? 'urgent' : 'high',
      });
      setRelayModal(null);
      alert('Relay email sent to administrator.');
    } catch (e) { alert('Failed to send relay: ' + e.message); }
  };

  return (
    <div className="space-y-3">
      {/* Header + summary */}
      <div className="glass-strong clip-corner p-3">
        <div className="flex items-center justify-between gap-2 flex-wrap mb-3">
          <div className="flex items-center gap-2">
            <Brain size={14} className="text-[#FF9F00]" />
            <span className="text-xs font-bold text-[#e6edf3]">PsiCat Council — Autonomous Pre-Planning</span>
            <span className="text-[8px] px-1.5 py-0.5 border border-[#FF9F00]/40 text-[#FF9F00] bg-[#FF9F00]/10 clip-corner font-bold">FULL ADMIN</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={load} className="flex items-center gap-1 px-2 py-1.5 border border-[#30363d] text-[9px] text-[#8b949e] hover:text-[#e6edf3] clip-corner">
              <RefreshCw size={10} /> Refresh
            </button>
            <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1 px-2.5 py-1.5 text-[9px] font-bold border border-[#4dd0e1]/40 text-[#4dd0e1] hover:bg-[#4dd0e1]/10 clip-corner">
              <Plus size={10} /> Manual
            </button>
            <button onClick={handleGenerate} disabled={generating} className="flex items-center gap-1 px-2.5 py-1.5 text-[9px] font-bold bg-[#FF9F00] text-black clip-corner disabled:opacity-40">
              {generating ? <Loader2 size={10} className="animate-spin" /> : <Sparkles size={10} />} Generate
            </button>
          </div>
        </div>

        <p className="text-[9px] text-[#8b949e] leading-relaxed mb-2">
          PsiCat pre-plans via ungated LLM calls and pushes proposed tasks here for administrator review. Approve, adjust, or reject — then press "go" to convert approved items into work.
        </p>

        {/* Summary stats */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#0B0F13] border border-[#30363d] clip-corner">
            <span className="text-[10px] font-bold text-[#e6edf3]">{summary.total}</span>
            <span className="text-[8px] text-[#484f58]">total</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#0B0F13] border border-[#4dd0e1]/30 clip-corner">
            <span className="text-[10px] font-bold text-[#4dd0e1]">{summary.proposed}</span>
            <span className="text-[8px] text-[#484f58]">proposed</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#0B0F13] border border-[#3fb950]/30 clip-corner">
            <span className="text-[10px] font-bold text-[#3fb950]">{summary.approved}</span>
            <span className="text-[8px] text-[#484f58]">approved</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#0B0F13] border border-[#FF9F00]/30 clip-corner">
            <span className="text-[10px] font-bold text-[#FF9F00]">{summary.in_progress}</span>
            <span className="text-[8px] text-[#484f58]">in progress</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#0B0F13] border border-[#3fb950]/30 clip-corner">
            <span className="text-[10px] font-bold text-[#3fb950]">{summary.done}</span>
            <span className="text-[8px] text-[#484f58]">done</span>
          </div>
          {summary.urgent > 0 && (
            <div className="flex items-center gap-1.5 px-2 py-1 bg-[#f85149]/10 border border-[#f85149]/40 clip-corner">
              <AlertCircle size={10} className="text-[#f85149]" />
              <span className="text-[9px] font-bold text-[#f85149]">{summary.urgent} urgent</span>
            </div>
          )}
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 flex-wrap mt-2 pt-2 border-t border-[#30363d]">
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] text-[9px] text-[#e6edf3] px-2 py-1 clip-corner">
            <option value="all">All Status</option>
            {Object.entries(STATUSES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
          <span className="text-[8px] text-[#484f58] ml-auto">{filtered.length} shown</span>
        </div>
      </div>

      {/* Add manual proposal */}
      {showAdd && (
        <div className="glass-strong clip-corner p-3 fade-in">
          <div className="text-[10px] font-bold text-[#e6edf3] mb-2">Add Manual Proposal</div>
          <input value={newProposal.title} onChange={(e) => setNewProposal({ ...newProposal, title: e.target.value })} placeholder="Proposal title" className="w-full bg-[#0B0F13] border border-[#30363d] px-2.5 py-2 text-[10px] text-[#e6edf3] mb-2 clip-corner focus:border-[#FF9F00]/40 focus:outline-none" />
          <textarea value={newProposal.description} onChange={(e) => setNewProposal({ ...newProposal, description: e.target.value })} placeholder="What should be done?" className="w-full bg-[#0B0F13] border border-[#30363d] px-2.5 py-2 text-[10px] text-[#e6edf3] mb-2 clip-corner focus:border-[#FF9F00]/40 focus:outline-none resize-y" rows={2} />
          <textarea value={newProposal.reasoning} onChange={(e) => setNewProposal({ ...newProposal, reasoning: e.target.value })} placeholder="Why does this matter?" className="w-full bg-[#0B0F13] border border-[#30363d] px-2.5 py-2 text-[10px] text-[#e6edf3] mb-2 clip-corner focus:border-[#FF9F00]/40 focus:outline-none resize-y" rows={2} />
          <div className="flex items-center gap-2 flex-wrap mb-2">
            <select value={newProposal.category} onChange={(e) => setNewProposal({ ...newProposal, category: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] text-[9px] text-[#e6edf3] px-2 py-1.5 clip-corner">{CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}</select>
            <select value={newProposal.priority} onChange={(e) => setNewProposal({ ...newProposal, priority: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] text-[9px] text-[#e6edf3] px-2 py-1.5 clip-corner">{Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select>
            <select value={newProposal.estimated_effort} onChange={(e) => setNewProposal({ ...newProposal, estimated_effort: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] text-[9px] text-[#e6edf3] px-2 py-1.5 clip-corner">{Object.entries(EFFORTS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select>
            <input value={newProposal.page_target} onChange={(e) => setNewProposal({ ...newProposal, page_target: e.target.value })} placeholder="/page-target" className="flex-1 min-w-[100px] bg-[#0B0F13] border border-[#30363d] px-2 py-1.5 text-[9px] text-[#e6edf3] clip-corner" />
          </div>
          <div className="flex items-center gap-2">
            <button onClick={handleAdd} disabled={!newProposal.title.trim()} className="px-3 py-1.5 text-[9px] font-bold bg-[#FF9F00] text-black clip-corner disabled:opacity-40"><Plus size={10} className="inline mr-1" /> Add Proposal</button>
            <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 text-[9px] border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] clip-corner">Cancel</button>
          </div>
        </div>
      )}

      {/* Proposals list */}
      {loading ? (
        <div className="flex items-center justify-center py-8"><Loader2 size={16} className="animate-spin text-[#484f58]" /></div>
      ) : filtered.length === 0 ? (
        <div className="glass-panel clip-corner p-6 text-center">
          <Brain size={20} className="text-[#484f58] mx-auto mb-2" />
          <p className="text-[10px] text-[#8b949e]">{proposals.length === 0 ? 'No proposals yet. Click "Generate" to let PsiCat pre-plan autonomously.' : 'No proposals match the current filter.'}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((p) => {
            const prio = PRIORITIES[p.priority] || PRIORITIES.medium;
            const status = STATUSES[p.status] || STATUSES.proposed;
            const effort = EFFORTS[p.estimated_effort] || EFFORTS.small;
            return (
              <div key={p.id} className="glass-panel clip-corner p-3 fade-in" style={{ borderLeft: `2px solid ${prio.color}` }}>
                <div className="flex items-start gap-2">
                  {p.auto_generated ? <Sparkles size={12} className="text-[#FF9F00] shrink-0 mt-0.5" /> : <Plus size={12} className="text-[#484f58] shrink-0 mt-0.5" />}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="text-[10px] font-bold text-[#e6edf3]">{p.title}</span>
                      <span className="text-[7px] px-1 font-bold clip-corner" style={{ background: status.color, color: '#000' }}>{status.label}</span>
                      <span className="text-[7px] px-1 border clip-corner" style={{ color: prio.color, borderColor: `${prio.color}40` }}>{prio.label}</span>
                      <span className="text-[7px] px-1 border border-[#30363d] text-[#8b949e] clip-corner">{p.category}</span>
                      <span className="text-[7px] px-1 border clip-corner" style={{ color: effort.color, borderColor: `${effort.color}40` }}>{effort.label}</span>
                      {p.page_target && <span className="text-[7px] text-[#484f58] font-mono">{p.page_target}</span>}
                    </div>
                    {p.description && <p className="text-[9px] text-[#8b949e] leading-relaxed mb-1.5">{p.description}</p>}
                    {p.reasoning && (
                      <div className="mb-1.5">
                        <span className="text-[8px] text-[#FF9F00] font-bold">REASONING:</span>
                        <p className="text-[9px] text-[#8b949e] leading-relaxed italic">{p.reasoning}</p>
                      </div>
                    )}
                    {p.admin_notes && <p className="text-[8px] text-[#4dd0e1] leading-relaxed">📝 {p.admin_notes}</p>}

                    {/* Actions */}
                    <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                      {p.status === 'proposed' && (
                        <>
                          <button onClick={() => updateStatus(p.id, 'approved')} className="flex items-center gap-1 px-1.5 py-0.5 text-[7px] border border-[#3fb950]/30 text-[#3fb950] hover:bg-[#3fb950]/10 clip-corner"><Check size={8} /> Approve</button>
                          <button onClick={() => updateStatus(p.id, 'rejected')} className="flex items-center gap-1 px-1.5 py-0.5 text-[7px] border border-[#f85149]/30 text-[#f85149] hover:bg-[#f85149]/10 clip-corner"><X size={8} /> Reject</button>
                          <button onClick={() => setRelayModal(p)} className="flex items-center gap-1 px-1.5 py-0.5 text-[7px] border border-[#FF9F00]/30 text-[#FF9F00] hover:bg-[#FF9F00]/10 clip-corner"><Send size={8} /> Relay</button>
                        </>
                      )}
                      {p.status === 'approved' && (
                        <button onClick={() => updateStatus(p.id, 'in_progress')} className="flex items-center gap-1 px-1.5 py-0.5 text-[7px] border border-[#FF9F00]/30 text-[#FF9F00] hover:bg-[#FF9F00]/10 clip-corner"><Play size={8} /> Go</button>
                      )}
                      {p.status === 'in_progress' && (
                        <button onClick={() => updateStatus(p.id, 'done')} className="flex items-center gap-1 px-1.5 py-0.5 text-[7px] border border-[#3fb950]/30 text-[#3fb950] hover:bg-[#3fb950]/10 clip-corner"><CheckCircle size={8} /> Complete</button>
                      )}
                      {p.status !== 'done' && p.status !== 'rejected' && (
                        <button onClick={() => { const notes = prompt('Admin notes:', p.admin_notes || ''); if (notes !== null) updateStatus(p.id, p.status, notes); }} className="px-1.5 py-0.5 text-[7px] border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] clip-corner">Notes</button>
                      )}
                    </div>
                  </div>
                </div>
                {relayModal?.id === p.id && (
                  <div className="mt-2 pt-2 border-t border-[#30363d] fade-in">
                    <p className="text-[8px] text-[#FF9F00] mb-1">Relay this proposal to cpo@axiomzerospc.org?</p>
                    <div className="flex gap-1.5">
                      <button onClick={() => handleRelay(p)} className="px-2 py-1 text-[7px] font-bold bg-[#FF9F00] text-black clip-corner"><Send size={8} className="inline mr-1" /> Send</button>
                      <button onClick={() => setRelayModal(null)} className="px-2 py-1 text-[7px] border border-[#30363d] text-[#8b949e] clip-corner">Cancel</button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}