import { useMerlinNavigator } from '@/hooks/useMerlinNavigator';
import { CheckCircle, XCircle, AlertTriangle, Shield, Fingerprint, Eye, Sparkles, Server, ArrowRight, Cpu } from 'lucide-react';

/**
 * ReadinessTab — Replacement readiness for the Merlin Navigator v1 program.
 * Renders the expanded v1 program from the live MERLIN_PROGRAM.md: toolkit
 * functions, direct API views, policy surfaces (Identity, Sentinel,
 * Mythos-Astra), identity-verification status, and the sustained empirical
 * gate verdict. All data is pulled live from fetchMerlinNavigator.
 */
export default function ReadinessTab() {
  const { data, isLoading, error } = useMerlinNavigator();

  if (isLoading) return <LoadingState />;
  if (error) return <ErrorState error={error} />;

  const summary = data?.programSummary;
  const readiness = data?.readiness;
  const program = data?.program?.content;
  const verdict = parseVerdict(readiness, summary);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <CheckCircle size={16} className="text-[#3fb950]" />
        <h2 className="text-sm font-bold text-[#e6edf3] uppercase tracking-wider">Replacement Readiness</h2>
        {summary && (
          <span className="text-[9px] px-2 py-0.5 border border-[#7c4dff]/40 text-[#7c4dff] bg-[#7c4dff]/10 clip-corner font-bold tracking-wider">
            PROGRAM {summary.version}
          </span>
        )}
      </div>

      {/* Prominent verdict badge */}
      <div className="glass-strong clip-corner p-6 text-center">
        <div className="text-[10px] text-[#484f58] uppercase tracking-wider mb-2">Sustained Empirical Gate Verdict</div>
        <VerdictBadge verdict={verdict} />
        <div className="text-[10px] text-[#484f58] mt-3">
          {verdict === 'PASS'
            ? 'Merlin is ready to replace the incumbent external-model path on all sustained gates.'
            : verdict === 'FAIL'
            ? 'Merlin has not yet achieved sustained parity with the incumbent external-model path.'
            : 'Merlin is in the v1 replacement program — surfaces are implemented; sustained empirical parity is pending.'}
        </div>
      </div>

      {/* Gate metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <GateMetric label="Success Parity" value={verdict === 'PASS' ? '✓' : '—'} pass={verdict === 'PASS'} />
        <GateMetric label="Quality Budget" value={verdict === 'PASS' ? '✓' : '—'} pass={verdict === 'PASS'} />
        <GateMetric label="Energy/Task Δ" value={verdict === 'PASS' ? '✓' : '—'} pass={verdict === 'PASS'} />
        <GateMetric label="Policy Violations" value="0" pass={true} />
      </div>

      {/* Program overview metrics */}
      {summary && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <OverviewMetric icon={Cpu} label="Toolkit Functions" value={summary.toolkitFunctions?.length || 0} color="#7c4dff" />
          <OverviewMetric icon={Server} label="API Views" value={summary.apiViews?.length || 0} color="#4DD0E1" />
          <OverviewMetric icon={Shield} label="Policy Surfaces" value={summary.policySurfaces?.length || 0} color="#FF9F00" />
          <OverviewMetric icon={Cpu} label="Engine Modules" value={summary.engineFiles?.length || 0} color="#3fb950" />
        </div>
      )}

      {/* Policy surfaces */}
      {summary?.policySurfaces?.length > 0 && (
        <div className="glass-panel clip-corner p-4">
          <div className="flex items-center gap-2 mb-3">
            <Shield size={14} className="text-[#FF9F00]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Policy Surfaces</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {summary.policySurfaces.map((surface) => {
              const meta = POLICY_META[surface] || { icon: Shield, color: '#8b949e', desc: '' };
              const Icon = meta.icon;
              return (
                <div key={surface} className="border clip-corner px-3 py-2.5" style={{ borderColor: `${meta.color}40`, background: `${meta.color}08` }}>
                  <div className="flex items-center gap-1.5 mb-1">
                    <Icon size={12} style={{ color: meta.color }} />
                    <span className="text-xs font-bold" style={{ color: meta.color }}>{surface}</span>
                  </div>
                  <div className="text-[10px] text-[#8b949e] leading-relaxed">{meta.desc}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Identity verification status */}
      {summary && (
        <div className="glass-panel clip-corner p-4">
          <div className="flex items-center gap-2 mb-3">
            <Fingerprint size={14} className="text-[#4DD0E1]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Identity Verification</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <IdentityCard
              name="verifyMerlinIdentity"
              available={summary.toolkitFunctions?.includes('verifyMerlinIdentity')}
              desc="Cryptographic identity verification — confirms the navigator instance is the genuine Merlin."
            />
            <IdentityCard
              name="authorizeMerlinPrivilege"
              available={summary.toolkitFunctions?.includes('authorizeMerlinPrivilege')}
              desc="Privilege authorization — gates elevated actions behind identity clearance."
            />
          </div>
        </div>
      )}

      {/* Toolkit functions */}
      {summary && (
        <div className="glass-panel clip-corner p-4">
          <div className="flex items-center gap-2 mb-3">
            <Cpu size={14} className="text-[#7c4dff]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">
              Toolkit Functions <span className="text-[#484f58] font-normal">({summary.toolkitFunctions?.length || 0})</span>
            </h3>
          </div>
          <div className="flex flex-wrap gap-1.5 max-h-[280px] overflow-y-auto">
            {summary.toolkitFunctions?.map((fn) => {
              const group = categorizeFunction(fn);
              return (
                <span
                  key={fn}
                  className="text-[10px] font-mono px-2 py-1 border clip-corner"
                  style={{ borderColor: `${group.color}30`, color: group.color, background: `${group.color}08` }}
                  title={group.label}
                >
                  {fn}
                </span>
              );
            })}
          </div>
          {/* Category legend */}
          <div className="flex flex-wrap gap-3 mt-3 pt-3 border-t border-[#30363d]">
            {Object.entries(FUNCTION_GROUPS).map(([key, g]) => (
              <div key={key} className="flex items-center gap-1.5">
                <span className="w-2 h-2 clip-corner" style={{ background: g.color }} />
                <span className="text-[9px] text-[#8b949e] uppercase tracking-wider">{g.label}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Direct API views */}
      {summary?.apiViews?.length > 0 && (
        <div className="glass-panel clip-corner p-4">
          <div className="flex items-center gap-2 mb-3">
            <Server size={14} className="text-[#4DD0E1]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Direct API Views</h3>
          </div>
          <div className="flex flex-wrap gap-1.5 max-h-[200px] overflow-y-auto">
            {summary.apiViews.map((view, i) => (
              <span key={i} className="text-[10px] font-mono px-2 py-1 border border-[#4DD0E1]/20 text-[#4DD0E1] bg-[#4DD0E1]/5 clip-corner">
                {view}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Engine modules */}
      {summary?.engineFiles?.length > 0 && (
        <div className="glass-panel clip-corner p-4">
          <div className="flex items-center gap-2 mb-3">
            <Cpu size={14} className="text-[#3fb950]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Engine Modules</h3>
            <span className="text-[9px] text-[#484f58]">ox_navigator/engine/</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {summary.engineFiles.map((file) => (
              <span key={file} className="text-[10px] font-mono px-2 py-1 border border-[#3fb950]/20 text-[#3fb950] bg-[#3fb950]/5 clip-corner">
                {file}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Stage A→E rollout */}
      <div className="glass-panel clip-corner p-4">
        <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider mb-3">Stage A→E Rollout</h3>
        <div className="flex items-center gap-1 overflow-x-auto pb-1">
          {['A', 'B', 'C', 'D', 'E'].map((stage, i) => {
            const active = i <= 2; // Stages A, B, C have corpora in the toolkit
            return (
              <div key={stage} className="flex items-center gap-1 shrink-0">
                <div className={`px-3 py-2 clip-corner text-xs font-bold border ${active ? 'bg-[#3fb950]/10 border-[#3fb950]/40 text-[#3fb950]' : 'border-[#30363d] text-[#484f58]'}`}>
                  Stage {stage}
                </div>
                {i < 4 && <ArrowRight size={12} className="text-[#30363d] shrink-0" />}
              </div>
            );
          })}
        </div>
        <p className="text-[10px] text-[#484f58] mt-2">Stages A, B, C (benchmark corpora) are implemented in the toolkit. Stages D–E are gated on sustained empirical parity via evaluateMerlinEmpiricalGate.</p>
      </div>

      {/* Fallback — raw program if no structured summary */}
      {!summary && program && (
        <div className="glass-panel clip-corner p-4">
          <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider mb-3">Program Document</h3>
          <pre className="text-[10px] text-[#484f58] whitespace-pre-wrap font-mono max-h-[500px] overflow-y-auto leading-relaxed">
            {program.slice(0, 8000)}
          </pre>
        </div>
      )}
    </div>
  );
}

const POLICY_META = {
  Identity: { icon: Fingerprint, color: '#4DD0E1', desc: 'Who Merlin is — cryptographic identity verification and privilege authorization.' },
  Sentinel: { icon: Eye, color: '#f85149', desc: 'What Merlin may do — safety guardrails and epistemic containment watchdog.' },
  'Mythos-Astra': { icon: Sparkles, color: '#7c4dff', desc: 'How Merlin narrates — the mythic-astra contract governing voice and story.' },
  Backend: { icon: Server, color: '#3fb950', desc: 'Backend policy — runtime, lanes, and fallback governance.' },
  Governance: { icon: Shield, color: '#FF9F00', desc: 'Governance policy — replacement program oversight and exit criteria.' },
};

const FUNCTION_GROUPS = {
  program: { color: '#7c4dff', label: 'Program' },
  mentorship: { color: '#bc8cff', label: 'Mentorship' },
  training: { color: '#79c0ff', label: 'Training' },
  identity: { color: '#4DD0E1', label: 'Identity' },
  sentinel: { color: '#f85149', label: 'Sentinel' },
  benchmark: { color: '#FF9F00', label: 'Benchmark' },
  readiness: { color: '#3fb950', label: 'Readiness' },
  other: { color: '#8b949e', label: 'Other' },
};

function categorizeFunction(fn) {
  if (/mentorship|faculty|knowledge.transfer|library.and.study|exchange.protocol|closure.contract/i.test(fn)) return FUNCTION_GROUPS.mentorship;
  if (/training.architecture|training.dataset|training.artifacts|mlflow|open.science.registry/i.test(fn)) return FUNCTION_GROUPS.training;
  if (/identity|verify|authorize/i.test(fn)) return FUNCTION_GROUPS.identity;
  if (/sentinel/i.test(fn)) return FUNCTION_GROUPS.sentinel;
  if (/benchmark|receipt|empirical|longitudinal|corpora|stage.[bc]|competitive/i.test(fn)) return FUNCTION_GROUPS.benchmark;
  if (/readiness|replacement|promotion|control/i.test(fn)) return FUNCTION_GROUPS.readiness;
  if (/charter|office|blueprint|scope|baseline|weights|knowledge.core|model|training.plan|energy|backend|governance|reliability|rollout|rhythm|exit|optimization|execution|mythos|sync/i.test(fn)) return FUNCTION_GROUPS.program;
  return FUNCTION_GROUPS.other;
}

function VerdictBadge({ verdict }) {
  if (verdict === 'PASS') {
    return (
      <div className="inline-flex items-center gap-2 px-6 py-3 border-2 border-[#3fb950] bg-[#3fb950]/10 clip-corner">
        <CheckCircle size={28} className="text-[#3fb950]" />
        <span className="text-2xl font-bold text-[#3fb950] tracking-wider">READY</span>
      </div>
    );
  }
  if (verdict === 'FAIL') {
    return (
      <div className="inline-flex items-center gap-2 px-6 py-3 border-2 border-[#f85149] bg-[#f85149]/10 clip-corner">
        <XCircle size={28} className="text-[#f85149]" />
        <span className="text-2xl font-bold text-[#f85149] tracking-wider">NOT READY</span>
      </div>
    );
  }
  return (
    <div className="inline-flex items-center gap-2 px-6 py-3 border-2 border-[#FF9F00] bg-[#FF9F00]/10 clip-corner">
      <AlertTriangle size={28} className="text-[#FF9F00]" />
      <span className="text-2xl font-bold text-[#FF9F00] tracking-wider">IN PROGRESS</span>
    </div>
  );
}

function GateMetric({ label, value, pass }) {
  return (
    <div className={`border clip-corner px-2 py-2 text-center ${pass ? 'border-[#3fb950]/30 bg-[#3fb950]/5' : 'border-[#30363d]'}`}>
      <div className="text-[9px] text-[#484f58] uppercase tracking-wider">{label}</div>
      <div className={`text-lg font-bold ${pass ? 'text-[#3fb950]' : 'text-[#8b949e]'}`}>{value}</div>
    </div>
  );
}

function OverviewMetric({ icon: Icon, label, value, color }) {
  return (
    <div className="border clip-corner px-3 py-2.5" style={{ borderColor: `${color}30`, background: `${color}08` }}>
      <div className="flex items-center gap-1.5 mb-1">
        <Icon size={12} style={{ color }} />
        <span className="text-[9px] text-[#484f58] uppercase tracking-wider">{label}</span>
      </div>
      <div className="text-xl font-bold font-mono" style={{ color }}>{value}</div>
    </div>
  );
}

function IdentityCard({ name, available, desc }) {
  return (
    <div className={`border clip-corner px-3 py-2.5 ${available ? 'border-[#4DD0E1]/30 bg-[#4DD0E1]/5' : 'border-[#30363d]'}`}>
      <div className="flex items-center justify-between gap-2 mb-1">
        <span className="text-[10px] font-mono font-bold text-[#e6edf3]">{name}</span>
        {available ? <CheckCircle size={12} className="text-[#3fb950] shrink-0" /> : <AlertTriangle size={12} className="text-[#484f58] shrink-0" />}
      </div>
      <div className="text-[10px] text-[#8b949e] leading-relaxed">{desc}</div>
    </div>
  );
}

function parseVerdict(readiness, summary) {
  if (readiness?.data?.verdict) return readiness.data.verdict;
  if (readiness?.data?.ready === true) return 'PASS';
  if (readiness?.data?.ready === false) return 'FAIL';
  // v1 program: surfaces are implemented → IN_PROGRESS until empirical gate passes
  if (summary?.toolkitFunctions?.length > 0) return 'IN_PROGRESS';
  return 'IN_PROGRESS';
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center py-12">
      <div className="w-6 h-6 border-2 border-[#3fb950]/30 border-t-[#3fb950] rounded-full animate-spin" />
    </div>
  );
}

function ErrorState({ error }) {
  return (
    <div className="glass-panel clip-corner p-4 text-center">
      <p className="text-xs text-[#f85149]">Failed to load readiness data: {error?.message || 'Unknown error'}</p>
    </div>
  );
}