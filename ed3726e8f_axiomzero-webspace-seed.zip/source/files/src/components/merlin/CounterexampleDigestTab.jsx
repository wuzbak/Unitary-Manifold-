/**
 * CounterexampleDigestTab — Sprint CH counterexample tracking surface.
 * Shows the getMerlinCounterexampleDigest data from the live repository,
 * giving visibility into proof failures and counterexample tracking — the
 * executable critique-to-proof matrix.
 *
 * Action button: "Refresh Digest" re-fetches the ECLIPSA contradiction-flagged
 * insights from persistent memory and renders them inline with a live count.
 */
import { useState, useEffect, useCallback } from 'react';
import { useMerlinNavigator } from '@/hooks/useMerlinNavigator';
import { base44 } from '@/api/base44Client';
import { Shield, Bug, CheckCircle, AlertTriangle, ExternalLink, FileWarning, RefreshCw, Loader2 } from 'lucide-react';

export default function CounterexampleDigestTab() {
  const { data, isLoading } = useMerlinNavigator();

  const programSummary = data?.programSummary;
  const toolkitFunctions = programSummary?.toolkitFunctions || [];
  const hasCounterexampleSurface = toolkitFunctions.includes('getMerlinCounterexampleDigest');

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Shield size={16} className="text-[#f85149]" />
        <h2 className="text-sm font-bold text-[#e6edf3] uppercase tracking-wider">Counterexample Digest</h2>
        <span className="text-[10px] text-[#484f58] ml-auto">Sprint CH · Critique-to-Proof Matrix</span>
      </div>

      {/* Sprint CH capability description */}
      <div className="glass-strong clip-corner p-4 border-l-2 border-[#f85149]">
        <div className="flex items-center gap-2 mb-2">
          <FileWarning size={14} className="text-[#f85149]" />
          <h3 className="text-xs font-bold text-[#f85149] uppercase tracking-wider">Executable Critique-to-Proof Matrix</h3>
        </div>
        <p className="text-[11px] text-[#8b949e] leading-relaxed">
          Sprint CH introduced the executable critique-to-proof matrix. Critiques are no longer just
          feedback — they are converted into formal proof obligations. When a proof fails, the
          counterexample is logged in the digest with its full context: the conjecture, the failing
          case, the Lean4 verdict, and the pillar it impacts. This is how Merlin learns from failure
          rather than hiding it.
        </p>
      </div>

      {/* Contradiction-gated insights from MerlinNote — with refresh button */}
      <ContradictionFlaggedInsights />

      {/* Available surfaces */}
      <div className="glass-panel clip-corner p-4">
        <div className="flex items-center gap-2 mb-3">
          <Bug size={14} className="text-[#00f5ff]" />
          <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Toolkit Surfaces</h3>
        </div>
        {isLoading ? (
          <div className="flex justify-center py-4">
            <div className="w-5 h-5 border-2 border-[#f85149]/30 border-t-[#f85149] rounded-full animate-spin" />
          </div>
        ) : hasCounterexampleSurface ? (
          <div className="space-y-2">
            <div className="flex items-center gap-2 border border-[#f85149]/15 clip-corner px-3 py-2">
              <CheckCircle size={12} className="text-[#3fb950] shrink-0" />
              <code className="text-[11px] text-[#f85149] font-mono">getMerlinCounterexampleDigest</code>
            </div>
            <div className="flex items-center gap-2 border border-[#f85149]/15 clip-corner px-3 py-2">
              <CheckCircle size={12} className="text-[#3fb950] shrink-0" />
              <code className="text-[11px] text-[#f85149] font-mono">GET /api/merlin/counterexample-digest</code>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-[11px] text-[#8b949e]">
            <AlertTriangle size={12} className="text-[#FF9F00]" />
            <span>Counterexample surface not yet detected in the live program summary.</span>
          </div>
        )}
      </div>

      {/* Link to repo */}
      <div className="glass-panel clip-corner p-3">
        <a
          href="https://github.com/wuzbak/Unitary-Manifold-/blob/main/12-AZ-IP/20-psicat-navigator/ox_navigator/engine/merlin_benchmark.py"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 text-[10px] text-[#f85149] hover:opacity-70"
        >
          <ExternalLink size={10} /> View benchmark engine source (merlin_benchmark.py)
        </a>
      </div>
    </div>
  );
}

/**
 * ContradictionFlaggedInsights — shows MerlinNote records that were flagged
 * by the ECLIPSA contradiction gate during distillation. Includes a refresh
 * button so the digest can be re-pulled on demand.
 */
function ContradictionFlaggedInsights() {
  const [flagged, setFlagged] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const fetchFlagged = useCallback(async () => {
    setRefreshing(true);
    setError(null);
    try {
      const notes = await base44.entities.MerlinNote.list('-updated_date', 50);
      const flaggedNotes = (notes || []).filter(n => n.contradiction_flag === 'flagged');
      setFlagged(flaggedNotes);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { fetchFlagged(); }, [fetchFlagged]);

  return (
    <div className="glass-panel clip-corner p-4">
      <div className="flex items-center gap-2 mb-3">
        <AlertTriangle size={14} className="text-[#f85149]" />
        <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">ECLIPSA Contradiction Flags</h3>
        <span className="text-[10px] text-[#484f58] ml-auto">{flagged.length} flagged</span>
        <button
          onClick={fetchFlagged}
          disabled={refreshing}
          className="text-[#f85149] hover:text-[#ff7a6b] transition-colors disabled:opacity-50 touch-manipulation"
          aria-label="Refresh counterexample digest"
          title="Refresh counterexample digest"
        >
          <RefreshCw size={12} className={refreshing ? 'animate-spin' : ''} />
        </button>
      </div>
      <p className="text-[10px] text-[#484f58] mb-3 leading-relaxed">
        Insights flagged by the contradiction gate during autonomous distillation. These conflict with
        certified hardgate pillars and were routed here rather than quietly integrated into persistent memory.
      </p>
      {error ? (
        <p className="text-xs text-[#f85149]">Failed to load: {error}</p>
      ) : loading ? (
        <div className="flex justify-center py-4">
          <Loader2 size={16} className="text-[#f85149] animate-spin" />
        </div>
      ) : flagged.length > 0 ? (
        <div className="space-y-2 max-h-[300px] overflow-y-auto">
          {flagged.map(n => (
            <div key={n.id} className="border border-[#f85149]/30 clip-corner px-3 py-2 bg-[#f85149]/5">
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="text-xs font-bold text-[#e6edf3] truncate">{n.title}</span>
                <span className="text-[9px] text-[#f85149] font-bold uppercase shrink-0">FLAGGED</span>
              </div>
              {n.contradiction_detail && (
                <p className="text-[10px] text-[#f85149]/80 leading-relaxed">{n.contradiction_detail}</p>
              )}
              <div className="text-[9px] text-[#484f58] mt-1">
                {n.domain} · {new Date(n.created_date).toLocaleDateString()}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-xs text-[#484f58] italic">No contradiction-flagged insights. The gate is clear.</p>
      )}
    </div>
  );
}