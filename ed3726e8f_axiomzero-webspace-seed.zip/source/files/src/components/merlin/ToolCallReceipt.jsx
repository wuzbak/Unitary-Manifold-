/**
 * ToolCallReceipt — Compact receipt showing a tool call made by the autonomous agent.
 * Displays: tool name, args summary, result status, duration.
 * Used in the MerlinAgentRunner live stream so the user can audit what Merlin did.
 */
import { Check, X, Loader2, ChevronDown, ChevronRight } from 'lucide-react';
import { useState } from 'react';

export default function ToolCallReceipt({ action, accent = '#fbbf24' }) {
  const [expanded, setExpanded] = useState(false);
  const ok = action.ok !== false;
  const statusColor = action._running ? accent : ok ? '#3fb950' : '#f85149';
  const StatusIcon = action._running ? Loader2 : ok ? Check : X;

  return (
    <div className="glass-panel clip-corner p-2.5 mb-2 fade-in" style={{ borderLeft: `2px solid ${statusColor}` }}>
      <div className="flex items-start gap-2">
        <StatusIcon size={12} style={{ color: statusColor }} className={`shrink-0 mt-0.5 ${action._running ? 'animate-spin' : ''}`} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] font-bold text-[#e6edf3] font-mono">{action.tool}</span>
            <span className="text-[8px] text-[#484f58]">·</span>
            <span className="text-[8px] text-[#8b949e]">{action._running ? 'running…' : ok ? 'success' : 'failed'}</span>
            {action.duration_ms != null && !action._running && (
              <span className="text-[8px] text-[#484f58]">{action.duration_ms}ms</span>
            )}
            {action.iteration && (
              <span className="text-[7px] px-1 rounded text-[#484f58] border border-[#30363d]">step {action.iteration}</span>
            )}
          </div>
          {action.reasoning && (
            <div className="text-[9px] text-[#8b949e] mt-1 italic leading-relaxed">{action.reasoning}</div>
          )}
          {action.args && Object.keys(action.args).length > 0 && (
            <button onClick={() => setExpanded(!expanded)} className="flex items-center gap-1 text-[8px] text-[#484f58] hover:text-[#8b949e] mt-1">
              {expanded ? <ChevronDown size={9} /> : <ChevronRight size={9} />} args
            </button>
          )}
          {expanded && action.args && (
            <pre className="text-[8px] text-[#8b949e] mt-1 p-1.5 bg-[#0B0F13] rounded overflow-x-auto max-h-32 overflow-y-auto">{JSON.stringify(action.args, null, 1)}</pre>
          )}
          {action.error && (
            <div className="text-[9px] text-[#f85149] mt-1 leading-relaxed">⚠ {action.error}</div>
          )}
          {action.result && expanded && (
            <div className="mt-1">
              <div className="text-[8px] text-[#484f58] mb-0.5">result</div>
              <pre className="text-[8px] text-[#3fb950] p-1.5 bg-[#0B0F13] rounded overflow-x-auto max-h-40 overflow-y-auto">{typeof action.result === 'string' ? action.result : JSON.stringify(action.result, null, 1)}</pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}