import { useState } from 'react';
import { useMerlinNavigator } from '@/hooks/useMerlinNavigator';
import { Gauge, RefreshCw, CheckCircle, XCircle, Clock, ArrowRight, Cpu } from 'lucide-react';

/**
 * BenchmarksTab — Stage A benchmark corpus for the Merlin Navigator v1 program.
 * Shows live benchmark tracks (latency, tokens, cost, energy, routing lane,
 * provider) from the repo's engine output, the benchmark-related toolkit
 * functions from the v1 program summary, and a markdown fallback when no
 * structured data exists.
 */
export default function BenchmarksTab() {
  const { data, isLoading, error, runStageA, isFetching } = useMerlinNavigator();
  const [running, setRunning] = useState(false);

  const handleRun = async () => {
    setRunning(true);
    try { await runStageA(); } finally { setRunning(false); }
  };

  if (isLoading) return <LoadingState />;
  if (error) return <ErrorState error={error} />;

  const benchmarks = data?.benchmarks;
  const summary = data?.programSummary;
  const program = data?.program?.content;

  const tracks = parseBenchmarkTracks(benchmarks);
  const benchmarkFns = (summary?.toolkitFunctions || []).filter(fn =>
    /benchmark|receipt|empirical|longitudinal|corpora|stage.[bc]|competitive/i.test(fn));

  return (
    <div className="space-y-4">
      {/* Header row */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <Gauge size={16} className="text-[#FF9F00]" />
          <h2 className="text-sm font-bold text-[#e6edf3] uppercase tracking-wider">Multi-Stage Benchmark Corpus (A · B · C)</h2>
        </div>
        <button
          onClick={handleRun}
          disabled={running || isFetching}
          className="flex items-center gap-1.5 px-3 py-2 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner hover:bg-[#FF9F00]/20 transition-colors disabled:opacity-50 min-h-[36px]"
        >
          <RefreshCw size={12} className={running || isFetching ? 'animate-spin' : ''} />
          {running || isFetching ? 'Running...' : 'Run Stage A Receipts'}
        </button>
      </div>

      {/* Benchmark tracks table */}
      {tracks.length > 0 ? (
        <div className="glass-panel clip-corner overflow-hidden">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-[#00f5ff]/15 text-[#8b949e] uppercase tracking-wider">
                <th className="text-left px-3 py-2 font-bold">Track</th>
                <th className="text-left px-3 py-2 font-bold">Status</th>
                <th className="text-right px-3 py-2 font-bold">Latency</th>
                <th className="text-right px-3 py-2 font-bold">Tokens</th>
                <th className="text-right px-3 py-2 font-bold">Cost</th>
                <th className="text-left px-3 py-2 font-bold">Lane</th>
                <th className="text-left px-3 py-2 font-bold">Provider</th>
              </tr>
            </thead>
            <tbody>
              {tracks.map((track, i) => (
                <tr key={i} className="border-b border-[#00f5ff]/5 hover:bg-[#00f5ff]/5 transition-colors">
                  <td className="px-3 py-2.5 text-[#e6edf3] font-bold">{track.name}</td>
                  <td className="px-3 py-2.5"><StatusBadge status={track.status} /></td>
                  <td className="px-3 py-2.5 text-right text-[#4DD0E1] font-mono">{track.latency || '—'}</td>
                  <td className="px-3 py-2.5 text-right text-[#8b949e] font-mono">{track.tokens || '—'}</td>
                  <td className="px-3 py-2.5 text-right text-[#8b949e] font-mono">{track.cost || '—'}</td>
                  <td className="px-3 py-2.5 text-[#FF9F00]">{track.lane || '—'}</td>
                  <td className="px-3 py-2.5 text-[#8b949e]">{track.provider || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="glass-panel clip-corner p-4">
          <div className="flex items-center gap-2 mb-3">
            <ArrowRight size={14} className="text-[#4DD0E1]" />
            <p className="text-xs text-[#8b949e]">
              No structured benchmark JSON committed in the repository yet. The v1 program defines the benchmark surfaces below; run Stage A receipts to generate live output.
            </p>
          </div>
          {program ? (
            <pre className="text-[10px] text-[#8b949e] whitespace-pre-wrap font-mono max-h-[400px] overflow-y-auto leading-relaxed">
              {extractBenchmarkSection(program)}
            </pre>
          ) : (
            <p className="text-xs text-[#484f58] italic">Program content not available.</p>
          )}
        </div>
      )}

      {/* Benchmark toolkit functions from v1 program */}
      {benchmarkFns.length > 0 && (
        <div className="glass-panel clip-corner p-4">
          <div className="flex items-center gap-2 mb-3">
            <Cpu size={14} className="text-[#FF9F00]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">
              Benchmark Surfaces <span className="text-[#484f58] font-normal">({benchmarkFns.length})</span>
            </h3>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {benchmarkFns.map((fn) => (
              <span key={fn} className="text-[10px] font-mono px-2 py-1 border border-[#FF9F00]/30 text-[#FF9F00] bg-[#FF9F00]/8 clip-corner">
                {fn}
              </span>
            ))}
          </div>
          <p className="text-[10px] text-[#484f58] mt-2">Exposed via /api/agentInvoke. These surfaces run the Stage A corpus and evaluate the empirical + longitudinal acceptance gates.</p>
        </div>
      )}

      {/* Head-to-head comparison */}
      <div className="glass-panel clip-corner p-4">
        <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider mb-3">Head-to-Head: Merlin vs Incumbent</h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="border border-[#00f5ff]/20 clip-corner p-3">
            <div className="text-[10px] text-[#00f5ff] font-bold uppercase tracking-wider mb-1">Merlin (Sovereign Local)</div>
            <div className="text-xs text-[#8b949e]">Primary lane · OpenRouter fallback · Gate-badge epistemics · Multi-tier memory · v1 program</div>
          </div>
          <div className="border border-[#30363d] clip-corner p-3">
            <div className="text-[10px] text-[#8b949e] font-bold uppercase tracking-wider mb-1">Incumbent (External Model)</div>
            <div className="text-xs text-[#484f58]">Cloud API · Per-token cost · No sovereign lane · No gate badges</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const config = {
    PASS: { color: '#3fb950', icon: CheckCircle },
    FAIL: { color: '#f85149', icon: XCircle },
    pending: { color: '#FF9F00', icon: Clock },
  };
  const c = config[status] || config.pending;
  const Icon = c.icon;
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider" style={{ color: c.color }}>
      <Icon size={11} /> {status || 'pending'}
    </span>
  );
}

function parseBenchmarkTracks(benchmarks) {
  if (!benchmarks) return [];
  if (benchmarks.data) {
    if (Array.isArray(benchmarks.data)) return benchmarks.data;
    if (benchmarks.data.tracks) return benchmarks.data.tracks;
  }
  if (Array.isArray(benchmarks)) return benchmarks;
  return [];
}

function extractBenchmarkSection(program) {
  const lines = program.split('\n');
  let capturing = false;
  let result = [];
  for (const line of lines) {
    if (/benchmark|stage a|receipt/i.test(line) && /^#/.test(line)) {
      capturing = true;
      result = [];
    }
    if (capturing) {
      result.push(line);
      if (result.length > 80) break;
    }
  }
  return result.length > 0 ? result.join('\n') : program.slice(0, 3000);
}

function LoadingState() {
  return (
    <div className="flex items-center justify-center py-12">
      <div className="w-6 h-6 border-2 border-[#00f5ff]/30 border-t-[#00f5ff] rounded-full animate-spin" />
    </div>
  );
}

function ErrorState({ error }) {
  return (
    <div className="glass-panel clip-corner p-4 text-center">
      <p className="text-xs text-[#f85149]">Failed to load benchmark data: {error?.message || 'Unknown error'}</p>
    </div>
  );
}