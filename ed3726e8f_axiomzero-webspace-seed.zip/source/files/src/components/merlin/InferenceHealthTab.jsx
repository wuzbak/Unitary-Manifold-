/**
 * InferenceHealthTab — Sprint CH inference provider health surface.
 * Shows the getMerlinInferenceProviders / getMerlinInferenceHealth data
 * from the live repository, giving visibility into the deterministic lane
 * routing (small/medium/heavy) and per-provider health status.
 *
 * Action button: "Refresh from Repository" force-refreshes the live program
 * data from the repo and renders the inference surfaces + last-refreshed
 * timestamp inline.
 */
import { useState } from 'react';
import { useMerlinNavigator } from '@/hooks/useMerlinNavigator';
import { Activity, Server, CheckCircle, AlertTriangle, Zap, ExternalLink, RefreshCw } from 'lucide-react';

export default function InferenceHealthTab() {
  const { data, isLoading, error, runStageA, isFetching } = useMerlinNavigator();
  const [lastRefreshed, setLastRefreshed] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const programSummary = data?.programSummary;
  const toolkitFunctions = programSummary?.toolkitFunctions || [];
  const hasInferenceSurface = toolkitFunctions.includes('getMerlinInferenceProviders') ||
    toolkitFunctions.includes('getMerlinInferenceHealth');

  const inferenceFunctions = toolkitFunctions.filter(f =>
    f.toLowerCase().includes('inference') || f.toLowerCase().includes('provider'));

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await runStageA();
      setLastRefreshed(new Date().toISOString());
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Activity size={16} className="text-[#4DD0E1]" />
        <h2 className="text-sm font-bold text-[#e6edf3] uppercase tracking-wider">Inference Health</h2>
        <span className="text-[10px] text-[#484f58] ml-auto">Sprint CH · Deterministic Lane Routing</span>
      </div>

      {/* Action bar */}
      <div className="glass-panel clip-corner p-3 flex flex-col sm:flex-row sm:items-center gap-2">
        <button
          onClick={handleRefresh}
          disabled={refreshing || isFetching}
          className="flex items-center gap-1.5 px-3 py-2 border border-[#4DD0E1]/40 bg-[#4DD0E1]/10 text-[#4DD0E1] text-[10px] font-bold clip-corner hover:bg-[#4DD0E1]/20 transition-colors disabled:opacity-50 min-h-[36px]"
        >
          <RefreshCw size={12} className={refreshing || isFetching ? 'animate-spin' : ''} />
          {refreshing || isFetching ? 'Refreshing...' : 'Refresh Inference Health'}
        </button>
        {lastRefreshed && (
          <span className="text-[9px] text-[#484f58] font-mono">
            Last refreshed: {new Date(lastRefreshed).toLocaleTimeString()}
          </span>
        )}
      </div>

      {/* Inline result */}
      {error ? (
        <div className="glass-panel clip-corner p-4 text-center">
          <p className="text-xs text-[#f85149]">Failed to load: {error?.message || 'Unknown error'}</p>
        </div>
      ) : isLoading ? (
        <div className="flex justify-center py-8">
          <div className="w-5 h-5 border-2 border-[#4DD0E1]/30 border-t-[#4DD0E1] rounded-full animate-spin" />
        </div>
      ) : (
        <>
          {/* Sprint CH capability description */}
          <div className="glass-strong clip-corner p-4 border-l-2 border-[#4DD0E1]">
            <div className="flex items-center gap-2 mb-2">
              <Zap size={14} className="text-[#4DD0E1]" />
              <h3 className="text-xs font-bold text-[#4DD0E1] uppercase tracking-wider">Deterministic Lane Routing</h3>
            </div>
            <p className="text-[11px] text-[#8b949e] leading-relaxed">
              Sprint CH introduced deterministic lane routing — queries are routed to small, medium, or heavy
              model lanes based on task complexity, not heuristic guesswork. The inference health surface
              tracks per-provider latency, token cost, energy estimate, and routing lane across every inference.
              This is the surface that moves Merlin toward lower energy-per-successful-task than the incumbent
              external-model path.
            </p>
          </div>

          {/* Available surfaces */}
          <div className="glass-panel clip-corner p-4">
            <div className="flex items-center gap-2 mb-3">
              <Server size={14} className="text-[#00f5ff]" />
              <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Toolkit Surfaces</h3>
            </div>
            {hasInferenceSurface ? (
              <div className="space-y-2">
                {inferenceFunctions.map(fn => (
                  <div key={fn} className="flex items-center gap-2 border border-[#4DD0E1]/15 clip-corner px-3 py-2">
                    <CheckCircle size={12} className="text-[#3fb950] shrink-0" />
                    <code className="text-[11px] text-[#4DD0E1] font-mono">{fn}</code>
                    <span className="text-[9px] text-[#484f58] ml-auto">exposed via /api/agentInvoke</span>
                  </div>
                ))}
                <div className="flex items-center gap-2 border border-[#4DD0E1]/15 clip-corner px-3 py-2">
                  <CheckCircle size={12} className="text-[#3fb950] shrink-0" />
                  <code className="text-[11px] text-[#4DD0E1] font-mono">GET /api/merlin/inference/providers</code>
                </div>
                <div className="flex items-center gap-2 border border-[#4DD0E1]/15 clip-corner px-3 py-2">
                  <CheckCircle size={12} className="text-[#3fb950] shrink-0" />
                  <code className="text-[11px] text-[#4DD0E1] font-mono">GET /api/merlin/inference/health</code>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-[11px] text-[#8b949e]">
                <AlertTriangle size={12} className="text-[#FF9F00]" />
                <span>Inference surface not yet detected in the live program summary. The repository may still be syncing.</span>
              </div>
            )}
          </div>

          {/* Link to repo */}
          <div className="glass-panel clip-corner p-3">
            <a
              href="https://github.com/wuzbak/Unitary-Manifold-/blob/main/12-AZ-IP/20-psicat-navigator/ox_navigator/engine/merlin_telemetry.py"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-[10px] text-[#4DD0E1] hover:opacity-70"
            >
              <ExternalLink size={10} /> View telemetry engine source (merlin_telemetry.py)
            </a>
          </div>
        </>
      )}
    </div>
  );
}