/**
 * ReasoningChainTab — Sprint CH reasoning chain surface.
 * Shows the getMerlinReasoningChain / runMerlinResearchCycle data from the
 * live repository, giving visibility into Merlin's autonomous research-cycle
 * execution and reasoning chain provenance.
 *
 * Action button: "Run Research Cycle" invokes merlinAgentLoop (the server-side
 * autonomous agent loop) with a research task and tool manifest, then renders
 * the returned summary + full action log (reasoning chain) inline.
 */
import { useState } from 'react';
import { useMerlinNavigator } from '@/hooks/useMerlinNavigator';
import { base44 } from '@/api/base44Client';
import { GitBranch, Play, CheckCircle, AlertTriangle, ExternalLink, Cpu, Loader2 } from 'lucide-react';

const DEFAULT_TASK = 'Research the current state of the Unitary Manifold framework: fetch the live repository context, summarize the version/sprint/pillar status, and identify the most recent capability changes.';

const RESEARCH_TOOLS = [
  { name: 'fetchRepoContext', desc: 'Live repository vital signs (version, sprint, tests, pillars, Lean4 theorems)', args: '{}' },
  { name: 'fetchMerlinNavigator', desc: 'PsiCat Navigator v1 program summary, toolkit, engine modules', args: '{}' },
  { name: 'fetchRepoReadme', desc: 'Repository root README', args: '{}' },
];

export default function ReasoningChainTab() {
  const { data, isLoading } = useMerlinNavigator();
  const [task, setTask] = useState(DEFAULT_TASK);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const programSummary = data?.programSummary;
  const toolkitFunctions = programSummary?.toolkitFunctions || [];
  const hasReasoningSurface = toolkitFunctions.includes('getMerlinReasoningChain') ||
    toolkitFunctions.includes('runMerlinResearchCycle');

  const reasoningFunctions = toolkitFunctions.filter(f =>
    f.toLowerCase().includes('reasoning') || f.toLowerCase().includes('research'));

  const handleRun = async () => {
    setRunning(true);
    setError(null);
    setResult(null);
    try {
      const res = await base44.functions.invoke('merlinAgentLoop', {
        task,
        tools: RESEARCH_TOOLS,
        max_iterations: 5,
      });
      const r = res?.data || res;
      if (r?.ok === false) throw new Error(r.error || 'Agent loop failed');
      setResult(r);
    } catch (e) {
      setError(e.message || 'Research cycle failed');
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <GitBranch size={16} className="text-[#bc8cff]" />
        <h2 className="text-sm font-bold text-[#e6edf3] uppercase tracking-wider">Reasoning Chain</h2>
        <span className="text-[10px] text-[#484f58] ml-auto">Sprint CH · Autonomous Research Cycle</span>
      </div>

      {/* Sprint CH capability description */}
      <div className="glass-strong clip-corner p-4 border-l-2 border-[#bc8cff]">
        <div className="flex items-center gap-2 mb-2">
          <Play size={14} className="text-[#bc8cff]" />
          <h3 className="text-xs font-bold text-[#bc8cff] uppercase tracking-wider">Autonomous Research Cycle</h3>
        </div>
        <p className="text-[11px] text-[#8b949e] leading-relaxed">
          Sprint CH introduced autonomous research-cycle execution. PsiCat can dispatch a research cycle
          that chains tool calls, web searches, and reasoning steps into a verifiable chain. Each step
          carries typed provenance — the reasoning chain surface exposes the full execution graph, so
          every claim PsiCat makes can be traced back to its source step.
        </p>
      </div>

      {/* Action bar — run a research cycle */}
      <div className="glass-panel clip-corner p-3 space-y-2">
        <div className="flex items-center gap-2">
          <Play size={12} className="text-[#bc8cff]" />
          <span className="text-[10px] font-bold text-[#e6edf3] uppercase tracking-wider">Run Research Cycle</span>
        </div>
        <textarea
          value={task}
          onChange={(e) => setTask(e.target.value)}
          rows={2}
          className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-3 py-2 text-xs clip-corner focus:outline-none focus:border-[#bc8cff]/40 resize-none"
          placeholder="Describe the research task for PsiCat..."
        />
        <button
          onClick={handleRun}
          disabled={running || !task.trim()}
          className="flex items-center gap-1.5 px-3 py-2 border border-[#bc8cff]/40 bg-[#bc8cff]/10 text-[#bc8cff] text-[10px] font-bold clip-corner hover:bg-[#bc8cff]/20 transition-colors disabled:opacity-50 min-h-[36px]"
        >
          {running ? <Loader2 size={12} className="animate-spin" /> : <Play size={12} />}
          {running ? 'Running cycle...' : 'Run Research Cycle'}
        </button>
      </div>

      {/* Inline result — reasoning chain */}
      {error && (
        <div className="glass-panel clip-corner p-4 text-center">
          <p className="text-xs text-[#f85149]">Research cycle failed: {error}</p>
        </div>
      )}
      {result && (
        <div className="glass-panel clip-corner p-4 space-y-3">
          <div className="flex items-center gap-2">
            <CheckCircle size={14} className="text-[#3fb950]" />
            <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Research Cycle Result</h3>
            <span className="text-[9px] text-[#484f58] ml-auto font-mono">
              {result.iterations} iterations · {result.actions?.length || 0} actions
            </span>
          </div>
          <div className="border border-[#bc8cff]/20 clip-corner p-3 bg-[#bc8cff]/5">
            <div className="text-[9px] text-[#bc8cff] font-bold uppercase tracking-wider mb-1">Summary</div>
            <p className="text-[11px] text-[#e6edf3] leading-relaxed whitespace-pre-wrap">{result.summary}</p>
          </div>
          {result.actions?.length > 0 && (
            <div>
              <div className="text-[9px] text-[#484f58] font-bold uppercase tracking-wider mb-2">Reasoning Chain — Action Log</div>
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {result.actions.map((a, i) => (
                  <div key={i} className="border border-[#30363d] clip-corner p-2 bg-[#0a0d11]">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="text-[10px] font-mono text-[#bc8cff] font-bold">Step {a.iteration}: {a.tool}</span>
                      <span className={`text-[9px] font-bold uppercase ${a.ok ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>
                        {a.ok ? '✓ OK' : '✗ FAILED'} · {a.duration_ms}ms
                      </span>
                    </div>
                    {a.reasoning && (
                      <p className="text-[10px] text-[#8b949e] italic mb-1 leading-relaxed">{a.reasoning}</p>
                    )}
                    {a.error && (
                      <p className="text-[10px] text-[#f85149]">{a.error}</p>
                    )}
                    {a.result && (
                      <pre className="text-[9px] text-[#484f58] font-mono whitespace-pre-wrap overflow-x-auto max-h-[100px]">
                        {JSON.stringify(a.result).slice(0, 500)}
                      </pre>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Available surfaces from program */}
      <div className="glass-panel clip-corner p-4">
        <div className="flex items-center gap-2 mb-3">
          <Cpu size={14} className="text-[#00f5ff]" />
          <h3 className="text-xs font-bold text-[#e6edf3] uppercase tracking-wider">Toolkit Surfaces</h3>
        </div>
        {isLoading ? (
          <div className="flex justify-center py-4">
            <div className="w-5 h-5 border-2 border-[#bc8cff]/30 border-t-[#bc8cff] rounded-full animate-spin" />
          </div>
        ) : hasReasoningSurface ? (
          <div className="space-y-2">
            {reasoningFunctions.map(fn => (
              <div key={fn} className="flex items-center gap-2 border border-[#bc8cff]/15 clip-corner px-3 py-2">
                <CheckCircle size={12} className="text-[#3fb950] shrink-0" />
                <code className="text-[11px] text-[#bc8cff] font-mono">{fn}</code>
                <span className="text-[9px] text-[#484f58] ml-auto">
                  {fn.includes('run') ? 'action' : 'query'}
                </span>
              </div>
            ))}
            <div className="flex items-center gap-2 border border-[#bc8cff]/15 clip-corner px-3 py-2">
              <CheckCircle size={12} className="text-[#3fb950] shrink-0" />
              <code className="text-[11px] text-[#bc8cff] font-mono">GET /api/merlin/reasoning-chain</code>
            </div>
            <div className="flex items-center gap-2 border border-[#bc8cff]/15 clip-corner px-3 py-2">
              <CheckCircle size={12} className="text-[#3fb950] shrink-0" />
              <code className="text-[11px] text-[#bc8cff] font-mono">POST /api/merlin/research-cycle</code>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-[11px] text-[#8b949e]">
            <AlertTriangle size={12} className="text-[#FF9F00]" />
            <span>Reasoning surface not yet detected in the live program summary.</span>
          </div>
        )}
      </div>

      {/* Link to repo */}
      <div className="glass-panel clip-corner p-3">
        <a
          href="https://github.com/wuzbak/Unitary-Manifold-/blob/main/12-AZ-IP/20-psicat-navigator/ox_navigator/engine/merlin_runtime.py"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 text-[10px] text-[#bc8cff] hover:opacity-70"
        >
          <ExternalLink size={10} /> View runtime engine source (merlin_runtime.py)
        </a>
      </div>
    </div>
  );
}