/**
 * InterrogateTab — Merlin's structured claim interrogation tool.
 * Routes claims through the oxQuery backend (live repo context, pillar
 * citations, gate status, confidence, caveat). Renders a structured verdict
 * card with export capability. Saves to Merlin's memory system.
 *
 * Absorbed from the OX Navigator's Interrogator tab — now unified under
 * Merlin's persona and memory.
 */
import { useState, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { UM_CONSTANTS } from '@/lib/umConstants';
import { autoTitle, saveActiveSession } from '@/lib/merlinMemory';
import GateBadge, { GateBadgeRow } from '@/components/quantum-cat/GateBadge';
import { Download, Loader2, Shield, Sparkles, AlertTriangle, FileJson } from 'lucide-react';

const OFFLINE_FALLBACK = {
  answer: `Offline mode — the live interrogation engine is unavailable. Static framework constants: N_W=${UM_CONSTANTS.N_W}, K_CS=${UM_CONSTANTS.K_CS}, C_S=${UM_CONSTANTS.C_S.toFixed(4)}, n_s=${UM_CONSTANTS.N_S}, r=${UM_CONSTANTS.R_BRAIDED}. For full interrogation with pillar citations, please retry when the engine is available.`,
  pillarCitations: [],
  gateStatus: 'OFFLINE',
  confidence: 0,
  caveat: 'Offline data — response from local static constants only.',
  _offline: true,
};

export default function InterrogateTab() {
  const [claim, setClaim] = useState('');
  const [contextTier, setContextTier] = useState('trimmed');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const interrogate = useCallback(async () => {
    if (!claim.trim() || loading) return;
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await base44.functions.invoke('oxQuery', {
        query: `Interrogate this claim: "${claim.trim()}". Provide the gate status, supporting pillar citations, confidence, and epistemic caveat.`,
        contextTier,
        systemPromptPrefix: 'You are the Merlin Interrogator. Given a claim, determine its gate status (HARDGATE/ADJACENT_TRACK/DERIVED/OPEN_GAP/ARCHITECTURE_LIMIT), the supporting pillars, the falsification condition, and your confidence. Be rigorous and honest.',
      });
      const data = res.data || res;
      if (data.error) throw new Error(data.error);
      setResult(data);

      // Save to memory
      const messages = [
        { role: 'user', text: claim.trim(), time: Date.now() },
        { role: 'cat', text: `[${data.gateStatus}] ${data.answer}\n\nConfidence: ${(data.confidence * 100).toFixed(0)}%\nCaveat: ${data.caveat}`, time: Date.now() },
      ];
      saveActiveSession({ title: autoTitle(messages), context_type: 'interrogation', messages });
    } catch (e) {
      // Offline fallback
      setResult(OFFLINE_FALLBACK);
      setError(e.message || 'Interrogation failed — showing offline fallback');
    }
    setLoading(false);
  }, [claim, contextTier, loading]);

  const exportResult = () => {
    if (!result) return;
    const data = {
      tool: 'Merlin Interrogator',
      claim,
      context_tier: contextTier,
      exported_at: new Date().toISOString(),
      ...result,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `merlin_interrogation_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4 fade-in">
      {/* Input panel */}
      <div className="glass-panel clip-corner p-4">
        <div className="flex items-center gap-2 mb-3">
          <Shield size={14} className="text-[#ff3b30]" />
          <span className="text-xs font-bold text-[#ff3b30] uppercase tracking-wider">Claim Interrogation</span>
        </div>
        <textarea
          value={claim}
          onChange={e => setClaim(e.target.value)}
          placeholder="Enter a claim to interrogate (e.g. 'The UM predicts r = 0.0315 as a hardgate')"
          className="w-full bg-[#0d1117] border border-[#30363d] rounded px-3 py-2.5 text-xs text-[#e6edf3] resize-y min-h-[100px] focus:outline-none focus:border-[#ff3b30]/50"
        />
        <div className="flex items-center gap-3 mt-3 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-[#8b949e]">Context</span>
            <button
              onClick={() => setContextTier('trimmed')}
              className={`px-2.5 py-1 text-[10px] font-bold clip-corner transition-all ${contextTier === 'trimmed' ? 'bg-[#00f5ff] text-black' : 'glass-panel text-[#8b949e] hover:text-[#e6edf3]'}`}
            >
              Trimmed
            </button>
            <button
              onClick={() => setContextTier('full')}
              className={`px-2.5 py-1 text-[10px] font-bold clip-corner transition-all ${contextTier === 'full' ? 'bg-[#00f5ff] text-black' : 'glass-panel text-[#8b949e] hover:text-[#e6edf3]'}`}
            >
              Full (~85k tokens)
            </button>
          </div>
          <button
            onClick={interrogate}
            disabled={loading || !claim.trim()}
            className="ml-auto flex items-center gap-1.5 px-5 py-2 bg-gradient-to-r from-[#ff3b30] to-[#ff9f0a] text-white text-xs font-bold clip-corner disabled:opacity-40 min-h-[44px]"
          >
            {loading ? <><Loader2 size={12} className="animate-spin" /> Interrogating...</> : <><Sparkles size={12} /> Interrogate Claim</>}
          </button>
        </div>
      </div>

      {/* Results */}
      {loading && (
        <div className="glass-strong clip-corner p-6 flex items-center gap-3">
          <Loader2 size={20} className="animate-spin text-[#ff3b30]" />
          <span className="text-xs text-[#8b949e]">Merlin is interrogating the claim against the live repository...</span>
        </div>
      )}

      {result && !loading && (
        <div className="glass-strong clip-corner p-4 space-y-4 fade-in">
          {/* Header: gate status + confidence + export */}
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-3">
              <GateBadge gate={result.gateStatus} size="sm" />
              {typeof result.confidence === 'number' && (
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-[#8b949e] uppercase tracking-wider">Confidence</span>
                  <div className="w-24 h-1.5 bg-[#30363d] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#ff3b30] to-[#3fb950]"
                      style={{ width: `${Math.min(result.confidence * 100, 100)}%` }}
                    />
                  </div>
                  <span className="text-xs font-bold text-[#e6edf3]">{(result.confidence * 100).toFixed(0)}%</span>
                </div>
              )}
            </div>
            <button
              onClick={exportResult}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-[#30363d] text-[#3fb950] text-[10px] font-bold clip-corner hover:border-[#3fb950]/40"
            >
              <Download size={11} /> Export JSON
            </button>
          </div>

          {/* Answer */}
          <div>
            <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-1.5">Verdict</div>
            <div className="text-xs text-[#e6edf3] leading-relaxed whitespace-pre-wrap">{result.answer}</div>
          </div>

          {/* Pillar citations */}
          {result.pillarCitations && result.pillarCitations.length > 0 && (
            <div>
              <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-2">Pillar Citations</div>
              <div className="space-y-1.5">
                {result.pillarCitations.map((c, i) => (
                  <div key={i} className="flex items-start gap-2 bg-[#0d1117] border border-[#30363d] rounded p-2">
                    <span className="text-[10px] font-bold text-[#4dd0e1] shrink-0">Pillar {c.pillar}</span>
                    <span className="text-[10px] text-[#c9d1d9]">{c.claim}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Caveat */}
          {result.caveat && (
            <div className="bg-[#0d1117] border border-[#d29922]/20 rounded p-3">
              <div className="flex items-center gap-1.5 mb-1">
                <AlertTriangle size={11} className="text-[#d29922]" />
                <span className="text-[10px] text-[#d29922] uppercase tracking-wider">Epistemic Caveat</span>
              </div>
              <p className="text-[10px] text-[#8b949e] italic">{result.caveat}</p>
            </div>
          )}

          {/* Model + tier metadata */}
          <div className="flex items-center gap-3 text-[9px] text-[#484f58] border-t border-[#30363d] pt-2">
            {result.model && <span>Model: {result.model}</span>}
            {result.contextTier && <span>Context: {result.contextTier}</span>}
            {result._offline && <span className="text-[#ff9f0a]">⚠ OFFLINE — static fallback</span>}
          </div>
        </div>
      )}

      {!result && !loading && (
        <div className="glass-panel clip-corner p-8 text-center">
          <Shield size={32} className="mx-auto text-[#ff3b30]/40 mb-3" />
          <div className="text-xs text-[#8b949e] max-w-md mx-auto">
            Enter a claim to interrogate its gate status, supporting pillars, confidence, and falsification condition.
            Merlin routes through the live repository context for grounded, pillar-cited verdicts.
          </div>
        </div>
      )}

      {error && !result?._offline && (
        <div className="bg-[#2a1a0a] border border-[#f85149]/30 clip-corner p-3">
          <AlertTriangle size={14} className="text-[#f85149] mb-1" />
          <p className="text-[#f85149] text-xs">{error}</p>
        </div>
      )}
    </div>
  );
}