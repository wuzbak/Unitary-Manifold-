import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

export default function FaqItem({ item }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="bg-[#161b22] border border-[#30363d] rounded-lg overflow-hidden">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between gap-3 px-4 py-3 text-left hover:bg-[#21262d] transition-colors">
        <span className="text-[#e6edf3] text-sm font-bold">{item.question}</span>
        <ChevronDown size={16} className={`text-[#8b949e] shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="px-4 pb-4 text-[#8b949e] text-sm leading-relaxed">{item.answer}</div>
      )}
    </div>
  );
}