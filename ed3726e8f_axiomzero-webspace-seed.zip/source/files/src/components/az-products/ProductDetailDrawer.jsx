/**
 * ProductDetailDrawer — rich "dossier" view for a single AZ product.
 * Opens as a slide-in Sheet from the right (desktop) / full screen (mobile).
 * Shows architecture overview, capabilities, interactive preview, and curated repo links.
 */
import { Link } from 'react-router-dom';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { ExternalLink, Play, Github, Layers, Cpu, CheckCircle2, FileCode } from 'lucide-react';
import { REPO_URL, GATE_COLORS, CATEGORY_COLORS } from '@/lib/azProducts';
import InteractivePreview from './InteractivePreview';
import RepoLinks from './RepoLinks';

export default function ProductDetailDrawer({ product, open, onOpenChange }) {
  if (!product) return null;

  const path = product.existingPath || product.newPath;
  const color = CATEGORY_COLORS[product.category] || '#8b949e';
  const gateColor = GATE_COLORS[product.epistemicGate] || '#8b949e';
  const folderUrl = product.repo ? `${REPO_URL}/tree/main/${product.repo}` : null;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="w-full sm:max-w-2xl md:max-w-3xl bg-[#0B0F13] border-l border-[#00f5ff]/20 p-0 overflow-y-auto"
      >
        {/* Header section */}
        <div className="sticky top-0 z-10 bg-[#0B0F13]/95 backdrop-blur-md border-b border-[#00f5ff]/15 p-5 pb-4">
          <div className="flex items-start gap-3 mb-3">
            <div className="text-3xl shrink-0">{product.icon}</div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[9px] text-[#484f58] font-mono">
                  {product.num === '∞' || product.num === '★' ? `Extra · ${product.id}` : `Product ${product.num}`}
                </span>
                <span className="text-[9px] px-1.5 py-0.5 clip-corner border" style={{
                  color: gateColor,
                  borderColor: gateColor + '40',
                  background: gateColor + '10',
                }}>{product.epistemicGate}</span>
              </div>
              <SheetTitle className="text-base font-bold text-[#e6edf3] font-mono">
                {product.name}
              </SheetTitle>
            </div>
          </div>
          <SheetDescription className="text-[11px] text-[#8b949e] leading-relaxed">
            {product.desc}
          </SheetDescription>

          {/* Metadata badges */}
          <div className="flex items-center gap-2 mt-3 flex-wrap">
            <span className="text-[10px] text-[#58a6ff] font-bold">{product.version}</span>
            <span className="text-[#484f58]">·</span>
            <span className="text-[10px] text-[#f0883e]">{product.trl}</span>
            {product.tests > 0 && (
              <>
                <span className="text-[#484f58]">·</span>
                <span className="text-[10px] text-[#3fb950]">{product.tests} tests</span>
              </>
            )}
            <span className="text-[#484f58]">·</span>
            <span className="text-[10px] text-[#bc8cff] font-mono">{product.tech}</span>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 mt-3">
            {path && (
              <Link to={path} onClick={() => onOpenChange(false)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#3fb950] text-black text-[10px] font-bold clip-corner hover:opacity-80 transition-opacity">
                <Play size={11} /> Launch
              </Link>
            )}
            {folderUrl && (
              <a href={folderUrl} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 border border-[#00f5ff]/30 text-[#00f5ff] bg-[#00f5ff]/5 hover:bg-[#00f5ff]/10 text-[10px] font-bold clip-corner transition-colors">
                <Github size={11} /> Repository
              </a>
            )}
          </div>
        </div>

        {/* Body content */}
        <div className="p-5 space-y-4">
          {/* Architecture overview */}
          {product.architecture && (
            <div className="bg-[#12161A] border border-[#30363d] p-3.5 clip-corner">
              <div className="flex items-center gap-1.5 mb-2">
                <Layers size={12} className="text-[#bc8cff]" />
                <span className="text-[10px] font-bold text-[#bc8cff] uppercase tracking-wider">Architecture</span>
              </div>
              <p className="text-[10px] text-[#8b949e] leading-relaxed">{product.architecture}</p>
            </div>
          )}

          {/* Capabilities */}
          {product.capabilities && product.capabilities.length > 0 && (
            <div className="bg-[#12161A] border border-[#30363d] p-3.5 clip-corner">
              <div className="flex items-center gap-1.5 mb-2.5">
                <CheckCircle2 size={12} className="text-[#3fb950]" />
                <span className="text-[10px] font-bold text-[#3fb950] uppercase tracking-wider">Capabilities</span>
                <span className="text-[8px] text-[#484f58] ml-auto">{product.capabilities.length} features</span>
              </div>
              <div className="space-y-1.5">
                {product.capabilities.map((cap, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <span className="text-[#3fb950] mt-0.5 shrink-0">▸</span>
                    <span className="text-[10px] text-[#e6edf3] leading-relaxed">{cap}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Interactive preview */}
          <InteractivePreview product={product} />

          {/* Tags */}
          {product.tags && product.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {product.tags.map(tag => (
                <span key={tag} className="text-[9px] px-2 py-0.5 clip-corner border" style={{
                  color,
                  borderColor: color + '40',
                  background: color + '10',
                }}>{tag}</span>
              ))}
            </div>
          )}

          {/* Curated repo links */}
          <div>
            <div className="flex items-center gap-1.5 mb-2.5">
              <FileCode size={12} className="text-[#00f5ff]" />
              <span className="text-[10px] font-bold text-[#00f5ff] uppercase tracking-wider">Repository Links</span>
              <span className="text-[8px] text-[#484f58] ml-auto">12-AZ-IP folder</span>
            </div>
            <RepoLinks product={product} />
          </div>

          {/* Epistemic note */}
          <div className="bg-[#12161A] border border-[#30363d]/50 p-3 clip-corner">
            <div className="flex items-center gap-1.5 mb-1">
              <Cpu size={11} className="text-[#484f58]" />
              <span className="text-[9px] font-bold text-[#484f58] uppercase tracking-wider">Epistemic Status</span>
            </div>
            <p className="text-[9px] text-[#8b949e] leading-relaxed">
              <strong className="text-[#e6edf3]">{product.epistemicGate}</strong> —
              {product.epistemicGate === 'HARDGATE'
                ? ' Core physics derivation from the 5D metric ansatz. External empirical confirmation pending.'
                : product.epistemicGate === 'ADJACENT_TRACK'
                ? ' Quantitative application of the Unitary Manifold geometry to a non-physics domain. Outputs are mathematical models — interpret accordingly.'
                : ' Framework application with known architectural limitations.'
              }
            </p>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}