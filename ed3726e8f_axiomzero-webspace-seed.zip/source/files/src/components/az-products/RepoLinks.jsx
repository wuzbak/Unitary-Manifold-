/**
 * RepoLinks — curated links to a product's 12-AZ-IP repository folder.
 * Statically defined per product in azProducts.js — no live API calls.
 */
import { ExternalLink, FileText, Folder } from 'lucide-react';
import { REPO_URL } from '@/lib/azProducts';

export default function RepoLinks({ product }) {
  if (!product.repoLinks || product.repoLinks.length === 0) {
    return (
      <div className="text-[10px] text-[#484f58] italic">
        No curated repository links for this entry.
      </div>
    );
  }

  const folderUrl = product.repo ? `${REPO_URL}/tree/main/${product.repo}` : null;

  return (
    <div className="space-y-2">
      {/* Folder root link */}
      {folderUrl && (
        <a
          href={folderUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 p-2.5 clip-corner border border-[#00f5ff]/20 bg-[#00f5ff]/5 hover:bg-[#00f5ff]/10 hover:border-[#00f5ff]/40 transition-colors group"
        >
          <Folder size={14} className="text-[#00f5ff] shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-[11px] font-bold text-[#00f5ff] group-hover:text-[#00f5ff]">
              {product.repo}
            </div>
            <div className="text-[9px] text-[#8b949e]">Repository folder root</div>
          </div>
          <ExternalLink size={11} className="text-[#484f58] group-hover:text-[#00f5ff] shrink-0" />
        </a>
      )}

      {/* Curated file links */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
        {product.repoLinks.map((link) => {
          const url = product.repo
            ? `${REPO_URL}/tree/main/${product.repo}/${link.path}`
            : `${REPO_URL}/tree/main/${link.path}`;
          return (
            <a
              key={link.label}
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-start gap-2 p-2 clip-corner border border-[#30363d] hover:border-[#00f5ff]/30 hover:bg-[#00f5ff]/5 transition-colors group"
            >
              <FileText size={11} className="text-[#484f58] group-hover:text-[#00f5ff] mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-[10px] font-bold text-[#e6edf3] group-hover:text-[#00f5ff] font-mono">
                  {link.label}
                </div>
                <div className="text-[9px] text-[#8b949e] leading-tight">{link.desc}</div>
              </div>
              <ExternalLink size={9} className="text-[#484f58] group-hover:text-[#00f5ff] shrink-0 mt-0.5" />
            </a>
          );
        })}
      </div>
    </div>
  );
}