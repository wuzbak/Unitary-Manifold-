/**
 * InteractivePreview — renders a product-specific interactive preview
 * inside the detail drawer. Supports 4 preview types:
 *   calculator     — mini computation (OmegaSynthesis, HolonZero, OmegaOracle)
 *   data-monitor   — live/static status snapshot (Falsification, Geo, Pentacorder, etc.)
 *   governance-sim — simulation summary (EIGE, AZ-SGE)
 *   os-overview    — architecture tree (AxiomOS, Delphi, Merlin, etc.)
 */
import { useState } from 'react';
import { Play, RefreshCw, Activity, ChevronRight } from 'lucide-react';
import { UM_STATUS } from '@/lib/umStatus';

// ── Omega Synthesis Calculator ─────────────────────────────────────
function OmegaSynthesisPreview({ pillars }) {
  const [pillarKey, setPillarKey] = useState(pillars[0].key);
  const [nw, setNw] = useState(5);
  const [e, setE] = useState(0.018);
  const [kt, setKt] = useState(0.1);
  const [result, setResult] = useState(null);
  const [computing, setComputing] = useState(false);
  const selectedPillar = pillars.find(p => p.key === pillarKey);

  const compute = () => {
    setComputing(true);
    const fn = new Function('nw', 'e', 'kt', 'Math', `return ${selectedPillar.fn};`);
    const val = fn(nw, e, kt, Math);
    setResult({ name: selectedPillar.name, val: typeof val === 'number' ? val.toFixed(5) : val, exp: selectedPillar.exp, unit: selectedPillar.unit });
    setComputing(false);
  };

  return (
    <div className="space-y-3">
      <div>
        <label className="text-[10px] text-[#8b949e] block mb-1">Observable</label>
        <select value={pillarKey} onChange={ev => setPillarKey(ev.target.value)}
          className="w-full bg-[#0d1117] border border-[#30363d] px-2.5 py-2 text-[11px] text-[#e6edf3] focus:outline-none focus:border-[#30d158] clip-corner">
          {pillars.map(p => <option key={p.key} value={p.key}>{p.name}</option>)}
        </select>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <div>
          <label className="text-[9px] text-[#8b949e] block mb-0.5">n_w</label>
          <input type="range" min="1" max="9" step="1" value={nw} onChange={ev => setNw(+ev.target.value)} className="w-full accent-[#30d158]" />
          <div className="text-[9px] text-[#30d158] font-bold text-center">{nw}</div>
        </div>
        <div>
          <label className="text-[9px] text-[#8b949e] block mb-0.5">ε_SR</label>
          <input type="range" min="0.001" max="0.05" step="0.001" value={e} onChange={ev => setE(+ev.target.value)} className="w-full accent-[#30d158]" />
          <div className="text-[9px] text-[#30d158] font-bold text-center">{e.toFixed(3)}</div>
        </div>
        <div>
          <label className="text-[9px] text-[#8b949e] block mb-0.5">k̃</label>
          <input type="range" min="0.01" max="0.20" step="0.005" value={kt} onChange={ev => setKt(+ev.target.value)} className="w-full accent-[#30d158]" />
          <div className="text-[9px] text-[#30d158] font-bold text-center">{kt.toFixed(2)}</div>
        </div>
      </div>
      <button onClick={compute} disabled={computing}
        className="w-full bg-[#30d158] text-black py-2 text-[11px] font-bold hover:opacity-80 disabled:opacity-40 clip-corner flex items-center justify-center gap-1.5">
        <Play size={11} /> Compute
      </button>
      {result && (
        <div className="bg-[#0d1117] border border-[#30d158]/30 p-3 clip-corner">
          <div className="text-[9px] text-[#8b949e]">{result.name}</div>
          <div className="text-xl font-bold text-[#f0c040]">{result.val}<span className="text-xs text-[#8b949e] ml-1">{result.unit}</span></div>
          <div className="text-[9px] text-[#8b949e] mt-1">Experimental: {result.exp}</div>
        </div>
      )}
    </div>
  );
}

// ── Holon Zero Calculator ──────────────────────────────────────────
function HolonZeroPreview({ domains }) {
  const [domainKey, setDomainKey] = useState(domains[0].key);
  const [phi0, setPhi0] = useState(0.73);
  const [entropy, setEntropy] = useState(0.20);
  const [result, setResult] = useState(null);
  const [computing, setComputing] = useState(false);
  const XI_C = 35 / 74;
  const domain = domains.find(d => d.key === domainKey);

  const compute = () => {
    setComputing(true);
    const phi_trust = Math.max(0, domain.phi_base * phi0 - entropy * (1 - XI_C));
    const coherence = phi_trust > XI_C ? 'COHERENT' : 'SUB-THRESHOLD';
    setResult({ phi_trust, coherence, domain: domain.label });
    setComputing(false);
  };

  return (
    <div className="space-y-3">
      <div>
        <label className="text-[10px] text-[#8b949e] block mb-1">Domain</label>
        <select value={domainKey} onChange={ev => setDomainKey(ev.target.value)}
          className="w-full bg-[#0d1117] border border-[#30363d] px-2.5 py-2 text-[11px] text-[#e6edf3] focus:outline-none focus:border-[#30d158] clip-corner">
          {domains.map(d => <option key={d.key} value={d.key}>{d.icon} {d.label}</option>)}
        </select>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-[9px] text-[#8b949e] block mb-0.5">φ₀ seed</label>
          <input type="range" min="0" max="1" step="0.01" value={phi0} onChange={ev => setPhi0(+ev.target.value)} className="w-full accent-[#30d158]" />
          <div className="text-[9px] text-[#30d158] font-bold text-center">{phi0.toFixed(2)}</div>
        </div>
        <div>
          <label className="text-[9px] text-[#8b949e] block mb-0.5">Entropy S</label>
          <input type="range" min="0" max="1" step="0.01" value={entropy} onChange={ev => setEntropy(+ev.target.value)} className="w-full accent-[#30d158]" />
          <div className="text-[9px] text-[#30d158] font-bold text-center">{entropy.toFixed(2)}</div>
        </div>
      </div>
      <button onClick={compute} disabled={computing}
        className="w-full bg-[#30d158] text-black py-2 text-[11px] font-bold hover:opacity-80 disabled:opacity-40 clip-corner flex items-center justify-center gap-1.5">
        <Play size={11} /> Compute Ground State
      </button>
      {result && (
        <div className="bg-[#0d1117] border border-[#30d158]/30 p-3 clip-corner">
          <div className="text-[9px] text-[#8b949e]">{result.domain} Ground State</div>
          <div className="text-xl font-bold text-[#f0c040]">{result.phi_trust.toFixed(5)}</div>
          <div className="text-[9px] text-[#8b949e]">φ-trust</div>
          <div className="mt-1.5">
            <span className="text-[9px] px-2 py-0.5 clip-corner border" style={{
              color: result.coherence === 'COHERENT' ? '#30d158' : '#ff9f0a',
              borderColor: result.coherence === 'COHERENT' ? '#30d15840' : '#ff9f0a40',
              background: result.coherence === 'COHERENT' ? '#30d15810' : '#ff9f0a10',
            }}>{result.coherence}</span>
          </div>
          <div className="text-[9px] text-[#8b949e] mt-1">Ξ_c threshold: {XI_C.toFixed(6)}</div>
        </div>
      )}
    </div>
  );
}

// ── Omega Oracle Calculator ───────────────────────────────────────
function OmegaOraclePreview({ sectors }) {
  const [scores, setScores] = useState(sectors.reduce((acc, s) => ({ ...acc, [s.key]: 0.7 }), {}));
  const [result, setResult] = useState(null);
  const [computing, setComputing] = useState(false);

  const compute = () => {
    setComputing(true);
    const vals = Object.values(scores);
    const omega = vals.reduce((a, b) => a + b, 0) / vals.length;
    const min = Math.min(...vals);
    const entropy_debt = (1 - omega) * (1 - min) * 0.5;
    const emergence = omega * (1 - entropy_debt);
    setResult({ omega, entropy_debt, emergence, min });
    setComputing(false);
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-5 gap-1.5">
        {sectors.map(s => (
          <div key={s.key} className="text-center">
            <div className="text-lg">{s.icon}</div>
            <div className="text-[8px] text-[#8b949e] mb-0.5">{s.label}</div>
            <input type="range" min="0" max="1" step="0.05" value={scores[s.key]}
              onChange={ev => setScores({ ...scores, [s.key]: +ev.target.value })}
              className="w-full accent-[#7c4dff]" />
            <div className="text-[8px] text-[#7c4dff] font-bold">{scores[s.key].toFixed(2)}</div>
          </div>
        ))}
      </div>
      <button onClick={compute} disabled={computing}
        className="w-full bg-gradient-to-r from-[#3b8bff] to-[#7c4dff] text-white py-2 text-[11px] font-bold hover:opacity-80 disabled:opacity-40 clip-corner flex items-center justify-center gap-1.5">
        <Play size={11} /> Compute Omega Score
      </button>
      {result && (
        <div className="bg-[#0d1117] border border-[#7c4dff]/30 p-3 clip-corner">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <div className="text-[8px] text-[#8b949e]">Ω Score</div>
              <div className="text-lg font-bold text-[#7c4dff]">{result.omega.toFixed(4)}</div>
            </div>
            <div>
              <div className="text-[8px] text-[#8b949e]">Entropy Debt</div>
              <div className="text-lg font-bold text-[#ff9f0a]">{result.entropy_debt.toFixed(4)}</div>
            </div>
            <div>
              <div className="text-[8px] text-[#8b949e]">Emergence</div>
              <div className="text-lg font-bold text-[#30d158]">{result.emergence.toFixed(4)}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Calculator Preview (dispatcher) ────────────────────────────────
function CalculatorPreview({ product }) {
  const { computeType, pillars, domains, sectors } = product.previewConfig;
  if (computeType === 'omega-synthesis') return <OmegaSynthesisPreview pillars={pillars} />;
  if (computeType === 'holon-zero') return <HolonZeroPreview domains={domains} />;
  if (computeType === 'omega-oracle') return <OmegaOraclePreview sectors={sectors} />;
  return null;
}

// ── Pentacorder Sensor Monitor ─────────────────────────────────────
function PentacorderPreview({ sensors }) {
  const [readings, setReadings] = useState(() => {
    const r = {};
    sensors.forEach(s => { r[s.id] = s.theoretical; });
    return r;
  });
  const [refreshing, setRefreshing] = useState(false);

  const refresh = () => {
    setRefreshing(true);
    const newR = {};
    sensors.forEach(s => {
      const noise = (Math.random() - 0.5) * Math.abs(s.theoretical) * 0.02;
      newR[s.id] = s.theoretical + noise;
    });
    setReadings(newR);
    setTimeout(() => setRefreshing(false), 300);
  };

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-1 gap-1.5">
        {sensors.map(s => {
          const val = readings[s.id] ?? s.theoretical;
          const dev = Math.abs(val - s.theoretical);
          const verdict = dev < Math.abs(s.theoretical) * 0.01 ? 'PASS' : 'TENSION';
          return (
            <div key={s.id} className="flex items-center gap-2 p-2 bg-[#0d1117] border border-[#30363d] clip-corner">
              <span className="w-2 h-2 rounded-full shrink-0" style={{ background: s.color }} />
              <div className="flex-1 min-w-0">
                <div className="text-[10px] font-bold text-[#e6edf3]">{s.name}</div>
                <div className="text-[8px] text-[#8b949e]">Pillar {s.pillar} · {s.unit}</div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-[11px] font-bold" style={{ color: s.color }}>{val.toFixed(2)}</div>
                <div className="text-[8px] text-[#8b949e]">theo: {s.theoretical}</div>
              </div>
              <span className="text-[8px] px-1.5 py-0.5 clip-corner border shrink-0" style={{
                color: verdict === 'PASS' ? '#3fb950' : '#ff9f0a',
                borderColor: verdict === 'PASS' ? '#3fb95040' : '#ff9f0a40',
                background: verdict === 'PASS' ? '#3fb95010' : '#ff9f0a10',
              }}>{verdict}</span>
            </div>
          );
        })}
      </div>
      <button onClick={refresh} disabled={refreshing}
        className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] py-1.5 text-[10px] font-bold hover:border-[#3b8bff]/40 clip-corner flex items-center justify-center gap-1.5">
        <RefreshCw size={10} className={refreshing ? 'animate-spin' : ''} /> Refresh Readings
      </button>
    </div>
  );
}

// ── Data Monitor Preview (dispatcher) ──────────────────────────────
function DataMonitorPreview({ product }) {
  const { monitorType, sensors, stats, dataSources, tabs } = product.previewConfig;

  // Falsification Observatory — 7 experiments from UM_STATUS
  if (monitorType === 'falsification') {
    const experiments = UM_STATUS.falsification_experiments || [];
    const statusColors = {
      FIRST_DETECTION_CANDIDATE: '#3fb950',
      DATASET_DEPENDENT: '#ff9f0a',
      TENSION_ESCALATED: '#ff6b6b',
      PASS: '#3fb950',
    };
    return (
      <div className="space-y-1.5">
        {experiments.map(exp => (
          <div key={exp.id} className="flex items-center gap-2 p-2 bg-[#0d1117] border border-[#30363d] clip-corner">
            <span className="text-[9px] font-bold text-[#484f58] shrink-0">{exp.id}</span>
            <div className="flex-1 min-w-0">
              <div className="text-[10px] font-bold text-[#e6edf3] truncate">{exp.name}</div>
              <div className="text-[8px] text-[#8b949e] truncate">{exp.detail}</div>
            </div>
            <span className="text-[8px] px-1.5 py-0.5 clip-corner border shrink-0" style={{
              color: statusColors[exp.status] || '#8b949e',
              borderColor: (statusColors[exp.status] || '#8b949e') + '40',
              background: (statusColors[exp.status] || '#8b949e') + '10',
            }}>{exp.status.replace(/_/g, ' ')}</span>
          </div>
        ))}
      </div>
    );
  }

  // Pentacorder — 5 sensor readings (needs hooks → own component)
  if (monitorType === 'pentacorder') return <PentacorderPreview sensors={sensors} />;

  // Geo Monitor — data source list
  if (monitorType === 'geo') {
    return (
      <div className="space-y-2">
        <div className="flex items-center gap-2 p-2.5 bg-[#0d1117] border border-[#ff6b6b]/20 clip-corner">
          <Activity size={14} className="text-[#ff6b6b]" />
          <div className="text-[10px] text-[#e6edf3]">
            <strong className="text-[#ff6b6b]">{dataSources.length}</strong> live data feeds integrated
          </div>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          {dataSources.map(src => (
            <div key={src} className="flex items-center gap-1.5 p-1.5 bg-[#0d1117] border border-[#30363d] clip-corner">
              <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] glow-pulse shrink-0" />
              <span className="text-[9px] text-[#8b949e] truncate">{src}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // TerraOS — tab list + stats
  if (monitorType === 'terra-os') {
    return (
      <div className="space-y-2">
        <div className="grid grid-cols-4 gap-1.5">
          {stats.map(s => (
            <div key={s.label} className="bg-[#0d1117] border border-[#30363d] p-2 text-center clip-corner">
              <div className="text-lg font-bold text-[#30d158]">{s.value}</div>
              <div className="text-[8px] text-[#8b949e]">{s.label}</div>
            </div>
          ))}
        </div>
        <div className="flex flex-wrap gap-1">
          {tabs.map((tab, i) => (
            <span key={i} className="text-[8px] px-1.5 py-0.5 bg-[#0d1117] border border-[#30363d] text-[#8b949e] clip-corner">{tab}</span>
          ))}
        </div>
      </div>
    );
  }

  // Generic data monitor — stats display
  if (stats) {
    return (
      <div className="grid grid-cols-2 gap-2">
        {stats.map(s => (
          <div key={s.label} className="bg-[#0d1117] border border-[#30363d] p-2.5 text-center clip-corner">
            <div className="text-xl font-bold text-[#00f5ff]">{s.value}</div>
            <div className="text-[9px] text-[#8b949e]">{s.label}</div>
          </div>
        ))}
      </div>
    );
  }

  return null;
}

// ── Governance Sim Preview ──────────────────────────────────────────
function GovernanceSimPreview({ product }) {
  const { simType, counties, tiers, kCS, phi0, modules } = product.previewConfig;

  // EIGE — election mesh summary
  if (simType === 'eige') {
    return (
      <div className="space-y-2">
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-[#0d1117] border border-[#3b8bff]/30 p-2.5 text-center clip-corner">
            <div className="text-xl font-bold text-[#3b8bff]">{counties}</div>
            <div className="text-[9px] text-[#8b949e]">WA Counties</div>
          </div>
          <div className="bg-[#0d1117] border border-[#3b8bff]/30 p-2.5 text-center clip-corner">
            <div className="text-xl font-bold text-[#3fb950]">4</div>
            <div className="text-[9px] text-[#8b949e]">Tiers</div>
          </div>
        </div>
        <div className="flex flex-wrap gap-1">
          {tiers.map(t => (
            <span key={t} className="text-[9px] px-2 py-0.5 bg-[#3b8bff]/10 border border-[#3b8bff]/30 text-[#3b8bff] clip-corner">{t}</span>
          ))}
        </div>
        <div className="flex items-center justify-between p-2 bg-[#0d1117] border border-[#30363d] clip-corner">
          <span className="text-[9px] text-[#8b949e]">k_CS invariant</span>
          <span className="text-[11px] font-bold text-[#ff9f00]">{kCS}</span>
        </div>
        <div className="flex items-center justify-between p-2 bg-[#0d1117] border border-[#30363d] clip-corner">
          <span className="text-[9px] text-[#8b949e]">φ₀ attractor</span>
          <span className="text-[11px] font-bold text-[#00f5ff]">{phi0}</span>
        </div>
        <div className="text-[9px] text-[#8b949e] leading-relaxed">
          Chaos injection modes: BITFLIP, ZERO_OUT, RANDOMIZE, STOCHASTIC. ZK certificates for federal tier. Freedom floor enforcement at {'>'}50% participation.
        </div>
      </div>
    );
  }

  // AZ-SGE — security modules
  if (simType === 'az-sge') {
    return (
      <div className="space-y-1.5">
        {modules.map(m => (
          <div key={m.name} className="flex items-center gap-2 p-2 bg-[#0d1117] border border-[#3fb950]/20 clip-corner">
            <span className="w-2 h-2 rounded-full bg-[#3fb950] glow-pulse shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="text-[10px] font-bold text-[#e6edf3]">{m.name}</div>
              <div className="text-[8px] text-[#8b949e]">{m.desc}</div>
            </div>
            <span className="text-[8px] px-1.5 py-0.5 clip-corner border border-[#3fb950]/30 bg-[#3fb950]/10 text-[#3fb950] shrink-0">{m.status}</span>
          </div>
        ))}
        <div className="flex items-center justify-between p-2 bg-[#0d1117] border border-[#30363d] clip-corner mt-2">
          <span className="text-[9px] text-[#8b949e]">Test suite</span>
          <span className="text-[11px] font-bold text-[#3fb950]">229 tests · 0 failures</span>
        </div>
      </div>
    );
  }

  return null;
}

// ── OS Overview Preview ─────────────────────────────────────────────
function OsOverviewPreview({ product }) {
  const { nodes } = product.previewConfig;
  if (!nodes) return null;

  return (
    <div className="space-y-1">
      {nodes.map((node, i) => (
        <div key={node.id} className="flex items-start gap-2">
          {i < nodes.length - 1 ? (
            <div className="flex flex-col items-center shrink-0 mt-1">
              <span className="w-2 h-2 bg-[#00f5ff] clip-corner" />
              <span className="w-px h-6 bg-[#00f5ff]/20 mt-0.5" />
            </div>
          ) : (
            <span className="w-2 h-2 bg-[#00f5ff] clip-corner mt-1 shrink-0" />
          )}
          <div className="flex-1 pb-1">
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-bold text-[#00f5ff] font-mono">{node.id}</span>
              <ChevronRight size={9} className="text-[#484f58]" />
              <span className="text-[10px] font-bold text-[#e6edf3]">{node.name}</span>
            </div>
            <div className="text-[9px] text-[#8b949e] ml-5">{node.desc}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Main Export ─────────────────────────────────────────────────────
export default function InteractivePreview({ product }) {
  const { previewType } = product;
  if (!previewType || previewType === 'none') return null;

  return (
    <div className="bg-[#12161A] border border-[#30363d] p-3.5 clip-corner">
      <div className="flex items-center gap-1.5 mb-3">
        <Activity size={12} className="text-[#00f5ff]" />
        <span className="text-[10px] font-bold text-[#00f5ff] uppercase tracking-wider">Interactive Preview</span>
        <span className="text-[8px] text-[#484f58] ml-auto">{previewType.replace('-', ' ')}</span>
      </div>
      {previewType === 'calculator' && <CalculatorPreview product={product} />}
      {previewType === 'data-monitor' && <DataMonitorPreview product={product} />}
      {previewType === 'governance-sim' && <GovernanceSimPreview product={product} />}
      {previewType === 'os-overview' && <OsOverviewPreview product={product} />}
    </div>
  );
}