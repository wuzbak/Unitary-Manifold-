/**
 * ProductCard — enhanced product card for the AZ Products hub grid.
 * Shows full visibility: icon, name, desc, version/TRL/tests, tech stack,
 * top capabilities, tags, epistemic gate, and action buttons.
 * Clicking the card opens the detail drawer.
 */
import { Link } from 'react-router-dom';
import { Github, Play, ChevronRight } from 'lucide-react';
import { REPO_URL, CATEGORY_COLORS, GATE_COLORS } from '@/lib/azProducts';

export default function ProductCard({ product, onSelect }) {
  const color = CATEGORY_COLORS[product.category] || '#8b949e';
  const gateColor = GATE_COLORS[product.epistemicGate] || '#8b949e';
  const path = product.existingPath || product.newPath;
  const folderUrl = product.repo ? `${REPO_URL}/tree/main/${product.repo}` : null;

  return (
    <div
      className="glass-panel clip-corner p-4 glow-hover transition-all flex flex-col cursor-pointer group"
      onClick={() => onSelect(product)}
    >
      {/* Header row */}
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <span className="text-[9px] text-[#484f58] font-mono">
            {product.num === '∞' || product.num === '★' ? `Extra` : `P${product.num}`}
          </span>
          <span className="text-[8px] px-1 py-0.5 clip-corner border" style={{
            color: gateColor,
            borderColor: gateColor + '40',
            background: gateColor + '10',
          }}>{product.epistemicGate}</span>
        </div>
        <span className="text-2xl">{product.icon}</span>
      </div>

      {/* Name */}
      <div className="text-sm font-bold text-[#e6edf3] group-hover:text-[#00f5ff] transition-colors mb-1">
        {product.name}
      </div>

      {/* Description */}
      <p className="text-[10px] text-[#8b949e] leading-relaxed mb-2.5 flex-1 line-clamp-3">{product.desc}</p>

      {/* Top capabilities (first 2) */}
      {product.capabilities && product.capabilities.length > 0 && (
        <div className="mb-2.5 space-y-0.5">
          {product.capabilities.slice(0, 2).map((cap, i) => (
            <div key={i} className="flex items-start gap-1">
              <span className="text-[#3fb950] text-[8px] mt-0.5 shrink-0">▸</span>
              <span className="text-[9px] text-[#8b949e] leading-tight line-clamp-1">{cap}</span>
            </div>
          ))}
          {product.capabilities.length > 2 && (
            <div className="text-[8px] text-[#484f58] ml-3">+{product.capabilities.length - 2} more</div>
          )}
        </div>
      )}

      {/* Metadata row */}
      <div className="flex items-center gap-1.5 mb-2 text-[9px] flex-wrap">
        <span className="text-[#58a6ff] font-bold">{product.version}</span>
        <span className="text-[#484f58]">·</span>
        <span className="text-[#f0883e]">{product.trl}</span>
        {product.tests > 0 && (
          <>
            <span className="text-[#484f58]">·</span>
            <span className="text-[#3fb950]">{product.tests}t</span>
          </>
        )}
      </div>

      {/* Tech stack */}
      {product.tech && product.tech !== '—' && (
        <div className="text-[9px] text-[#bc8cff] font-mono mb-2 truncate">{product.tech}</div>
      )}

      {/* Tags */}
      <div className="flex gap-1 flex-wrap mb-2">
        {product.tags.slice(0, 3).map(tag => (
          <span key={tag} className="text-[8px] px-1.5 py-0.5 clip-corner border" style={{
            color,
            borderColor: color + '40',
            background: color + '10',
          }}>{tag}</span>
        ))}
      </div>

      {/* Action row */}
      <div className="flex items-center gap-2 pt-2 border-t border-[#00f5ff]/5">
        <button
          onClick={(e) => { e.stopPropagation(); onSelect(product); }}
          className="flex items-center gap-1 text-[#00f5ff] text-[10px] font-bold hover:underline"
        >
          <ChevronRight size={11} /> Details
        </button>
        {folderUrl && (
          <a
            href={folderUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="flex items-center gap-1 text-[#58a6ff] text-[10px] hover:underline"
          >
            <Github size={10} /> Source
          </a>
        )}
        {path && (
          <Link
            to={path}
            onClick={(e) => e.stopPropagation()}
            className="flex items-center gap-1 text-[#3fb950] text-[10px] hover:underline ml-auto"
          >
            <Play size={10} /> Launch
          </Link>
        )}
      </div>
    </div>
  );
}