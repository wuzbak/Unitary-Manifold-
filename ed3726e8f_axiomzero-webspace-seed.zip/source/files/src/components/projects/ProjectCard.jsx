const SECTOR_COLORS = {
  'Energy': 'text-[#ffaa00] bg-[#3a2d0a]',
  'Water Systems': 'text-[#58a6ff] bg-[#0d2040]',
  'Transit': 'text-[#bc8cff] bg-[#2a1a3a]',
  'Digital': 'text-[#00f5ff] bg-[#0a2a30]',
  'Materials': 'text-[#3fb950] bg-[#1a3a25]',
  'Urban': 'text-[#ff7eb6] bg-[#3a1a2a]'
};

const STATUS_COLORS = {
  'Active': 'text-[#3fb950] bg-[#1a3a25]',
  'Completed': 'text-[#8b949e] bg-[#21262d]',
  'Planning': 'text-[#d29922] bg-[#3a2d0a]'
};

export default function ProjectCard({ project }) {
  return (
    <div className="bg-[#161b22] border border-[#30363d] rounded-lg overflow-hidden hover:border-[#58a6ff] transition-colors">
      {project.image_url && (
        <img src={project.image_url} alt={project.title} className="w-full h-40 object-cover" />
      )}
      <div className="p-4">
        <div className="flex flex-wrap gap-1.5 mb-2">
          <span className={`px-2 py-0.5 rounded text-xs font-bold ${SECTOR_COLORS[project.sector] || 'bg-[#21262d] text-[#8b949e]'}`}>{project.sector}</span>
          <span className={`px-2 py-0.5 rounded text-xs font-bold ${STATUS_COLORS[project.status] || 'bg-[#21262d] text-[#8b949e]'}`}>{project.status}</span>
          <span className="px-2 py-0.5 rounded text-xs font-bold bg-[#21262d] text-[#8b949e]">{project.region}</span>
        </div>
        <h3 className="text-[#e6edf3] font-bold text-base mb-1">{project.title}</h3>
        {project.description && <p className="text-[#8b949e] text-sm mb-2 leading-relaxed">{project.description}</p>}
        <div className="flex items-center gap-2 text-xs text-[#8b949e]">
          <span className="text-[#bc8cff] font-bold">{project.impact}</span>
          {project.year && <span>· {project.year}</span>}
          {project.client && <span>· {project.client}</span>}
        </div>
      </div>
    </div>
  );
}