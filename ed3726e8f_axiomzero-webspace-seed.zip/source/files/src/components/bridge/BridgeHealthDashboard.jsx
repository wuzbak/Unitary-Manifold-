import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Activity, Loader2, CheckCircle, AlertTriangle, FileCode } from 'lucide-react';
import FidelityBadge from '@/components/shared/FidelityBadge';

const VERDICT_COLORS = {
  PASS: '#3fb950',
  TENSION: '#FF9F00',
  FALSIFIED: '#f85149',
};

export default function BridgeHealthDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await base44.functions.invoke('leanPythonBridgeHealth', {});
        const r = res?.data || res;
        if (r?.ok) setData(r);
        else setError(r?.error || 'Failed to load bridge health');
      } catch (e) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-8 text-[10px] text-[#484f58]">
        <Loader2 size={14} className="animate-spin" /> Fetching bridge health from repo…
      </div>
    );
  }

  if (error) {
    return <div className="text-[10px] text-[#f85149] text-center py-4">{error}</div>;
  }

  const { bridge, modules, summary, residual_gates } = data;

  return (
    <div className="space-y-3">
      {/* Bridge summary */}
      <div className="glass-panel clip-corner p-3 tactical-hud">
        <div className="flex items-center gap-2 mb-2">
          <Activity size={13} className="text-[#4dd0e1]" />
          <span className="text-[10px] font-bold text-[#4dd0e1] tracking-wider">{bridge.lane}</span>
          <FidelityBadge tier="repo_mirror" className="ml-auto" />
        </div>
        <p className="text-[9px] text-[#8b949e] leading-relaxed mb-2">{bridge.description}</p>
        <div className="flex items-center gap-2 text-[8px]">
          <span className="text-[#484f58]">Sprint:</span>
          <span className="text-[#bc8cff] font-mono">{bridge.sprint}</span>
          <span className="text-[#484f58] ml-auto">Status:</span>
          <span
            className="font-bold px-1.5 py-0.5 clip-corner border"
            style={{
              color: bridge.overall_status === 'HEALTHY' ? '#3fb950' : '#FF9F00',
              borderColor: bridge.overall_status === 'HEALTHY' ? '#3fb95040' : '#FF9F0040',
              backgroundColor: bridge.overall_status === 'HEALTHY' ? '#3fb95010' : '#FF9F0010',
            }}
          >
            {bridge.overall_status}
          </span>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-2">
        <div className="glass-panel clip-corner p-2 text-center">
          <div className="text-[8px] text-[#484f58] uppercase">READY</div>
          <div className="text-[#3fb950] font-mono text-xl">{summary.ready}</div>
        </div>
        <div className="glass-panel clip-corner p-2 text-center">
          <div className="text-[8px] text-[#484f58] uppercase">TENSION</div>
          <div className="text-[#FF9F00] font-mono text-xl">{summary.tension}</div>
        </div>
        <div className="glass-panel clip-corner p-2 text-center">
          <div className="text-[8px] text-[#484f58] uppercase">BLOCKED</div>
          <div className="text-[#f85149] font-mono text-xl">{summary.blocked_not_yet_derivable}</div>
        </div>
      </div>

      {/* Audit modules */}
      <div className="glass-panel clip-corner p-3 tactical-hud">
        <div className="flex items-center gap-2 mb-2">
          <FileCode size={13} className="text-[#bc8cff]" />
          <span className="text-[10px] font-bold text-[#bc8cff] tracking-wider">AUDIT MODULES</span>
        </div>
        <div className="space-y-1.5">
          {modules.map((m) => {
            const color = VERDICT_COLORS[m.verdict] || '#484f58';
            return (
              <div key={m.id} className="flex items-start gap-2 p-2 border border-[#30363d] clip-corner">
                {m.verdict === 'PASS' ? (
                  <CheckCircle size={12} className="text-[#3fb950] shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle size={12} className="text-[#FF9F00] shrink-0 mt-0.5" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-[9px] font-bold text-[#e6edf3]">{m.name}</span>
                    <span className="text-[7px] text-[#484f58] font-mono">[{m.gate}]</span>
                    <span
                      className="text-[7px] font-bold px-1 py-0.5 clip-corner border ml-auto shrink-0"
                      style={{ color, borderColor: `${color}40`, backgroundColor: `${color}10` }}
                    >
                      {m.verdict}
                    </span>
                  </div>
                  <div className="text-[8px] text-[#8b949e] leading-relaxed mb-1">{m.description}</div>
                  <div className="text-[8px] text-[#484f58] font-mono truncate">{m.file}</div>
                  <div className="text-[8px] text-[#8b949e] italic mt-1">{m.last_result}</div>
                  {m.file_exists !== undefined && (
                    <div className="text-[7px] text-[#484f58] mt-0.5">
                      File in repo: {m.file_exists ? `✓ (${m.file_size || '?'} bytes)` : '✗ not found'}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Residual gates */}
      <div className="glass-panel clip-corner p-3 tactical-hud">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[10px] font-bold text-[#FF9F00] tracking-wider">RESIDUAL GATES</span>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          {residual_gates.map((g, i) => {
            const color = VERDICT_COLORS[g.verdict] || '#484f58';
            return (
              <div key={i} className="flex items-center gap-2 p-1.5 border border-[#30363d] clip-corner">
                <span className="text-[9px] font-mono text-[#4dd0e1] font-bold">{g.gate}</span>
                <span
                  className="text-[7px] font-bold px-1 py-0.5 clip-corner border ml-auto"
                  style={{ color, borderColor: `${color}40`, backgroundColor: `${color}10` }}
                >
                  {g.verdict}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}