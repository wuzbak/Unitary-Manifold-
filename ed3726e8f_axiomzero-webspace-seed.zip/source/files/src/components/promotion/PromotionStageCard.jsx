import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Award, Loader2, Lock, Unlock, TrendingUp, CheckCircle, XCircle } from 'lucide-react';
import FidelityBadge from '@/components/shared/FidelityBadge';

const STAGES = ['A', 'B', 'C', 'D', 'E'];
const PHASES = [
  { id: 'frozen', label: 'FROZEN', color: '#f85149' },
  { id: 'phase_0', label: 'PHASE 0', color: '#484f58' },
  { id: 'phase_1', label: 'PHASE 1', color: '#4dd0e1' },
  { id: 'phase_2', label: 'PHASE 2', color: '#FF9F00' },
  { id: 'receipt_cleared', label: 'RECEIPT CLEARED', color: '#3fb950' },
];

export default function PromotionStageCard() {
  const [state, setState] = useState(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  const loadState = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.PsiCatPromotionState.list('-created_date', 1);
      setState(list[0] || null);
    } catch (e) {
      // empty
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadState();
  }, []);

  const advanceStage = async () => {
    if (!state) return;
    setUpdating(true);
    try {
      const currentIdx = STAGES.indexOf(state.stage);
      const nextStage = STAGES[(currentIdx + 1) % STAGES.length];
      await base44.entities.PsiCatPromotionState.update(state.id, {
        stage: nextStage,
        last_updated: new Date().toISOString(),
      });
      await loadState();
    } catch (e) {
      // empty
    } finally {
      setUpdating(false);
    }
  };

  const toggleGate = async (gate) => {
    if (!state) return;
    setUpdating(true);
    try {
      const updates = { [gate]: !state[gate], last_updated: new Date().toISOString() };
      // Recompute promotion_eligible
      const newTraining = gate === 'training_gates_clear' ? !state.training_gates_clear : state.training_gates_clear;
      const newBenchmark = gate === 'benchmark_gates_clear' ? !state.benchmark_gates_clear : state.benchmark_gates_clear;
      const newFrontier = gate === 'frontier_blockers_clear' ? !state.frontier_blockers_clear : state.frontier_blockers_clear;
      updates.promotion_eligible = newTraining && newBenchmark && newFrontier;
      updates.promotion_phase = updates.promotion_eligible ? 'receipt_cleared' : 'frozen';
      updates.frozen_reason = updates.promotion_eligible ? '' : 'Gates not yet clear';
      await base44.entities.PsiCatPromotionState.update(state.id, updates);
      await loadState();
    } catch (e) {
      // empty
    } finally {
      setUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-6 text-[10px] text-[#484f58]">
        <Loader2 size={14} className="animate-spin" /> Loading PsiCat promotion state…
      </div>
    );
  }

  // If no state exists, create one
  if (!state) {
    return (
      <div className="glass-panel clip-corner p-3 tactical-hud text-center">
        <Award size={20} className="mx-auto mb-2 text-[#484f58]" />
        <p className="text-[10px] text-[#8b949e] mb-3">No promotion state initialized.</p>
        <button
          onClick={async () => {
            try {
              await base44.entities.PsiCatPromotionState.create({
                stage: 'A',
                promotion_phase: 'frozen',
                frozen_reason: 'Initial state — no receipts earned yet',
              });
              await loadState();
            } catch (e) {}
          }}
          className="px-3 py-2 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner hover:bg-[#FF9F00]/20 transition-colors touch-manipulation"
        >
          Initialize Promotion State
        </button>
      </div>
    );
  }

  const phaseConfig = PHASES.find((p) => p.id === state.promotion_phase) || PHASES[0];

  return (
    <div className="glass-panel clip-corner p-3 tactical-hud border-[#FF9F00]/30">
      {/* Header */}
      <div className="flex items-center gap-2 mb-3">
        <Award size={13} className="text-[#FF9F00]" />
        <span className="text-[10px] font-bold text-[#FF9F00] tracking-wider">PSICAT PROMOTION STATE</span>
        <FidelityBadge tier="live" className="ml-auto" />
      </div>

      {/* Stage pipeline A→E */}
      <div className="mb-3">
        <div className="text-[8px] text-[#484f58] uppercase tracking-wider mb-1.5">Stage Pipeline (A → E)</div>
        <div className="flex items-center gap-1">
          {STAGES.map((s, i) => {
            const currentIdx = STAGES.indexOf(state.stage);
            const isActive = i === currentIdx;
            const isPassed = i < currentIdx;
            return (
              <div key={s} className="flex items-center gap-1 flex-1">
                <div
                  className={`flex items-center justify-center w-7 h-7 clip-corner border text-[10px] font-bold ${
                    isActive
                      ? 'border-[#FF9F00] bg-[#FF9F00]/20 text-[#FF9F00]'
                      : isPassed
                      ? 'border-[#3fb950]/40 bg-[#3fb950]/10 text-[#3fb950]'
                      : 'border-[#30363d] text-[#484f58]'
                  }`}
                >
                  {s}
                </div>
                {i < STAGES.length - 1 && (
                  <div className={`h-px flex-1 ${isPassed ? 'bg-[#3fb950]/40' : 'bg-[#30363d]'}`} />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Promotion phase */}
      <div className="mb-3 p-2 border clip-corner" style={{ borderColor: `${phaseConfig.color}40`, backgroundColor: `${phaseConfig.color}10` }}>
        <div className="flex items-center gap-2">
          {state.promotion_phase === 'frozen' ? <Lock size={12} style={{ color: phaseConfig.color }} /> : <Unlock size={12} style={{ color: phaseConfig.color }} />}
          <span className="text-[9px] font-bold tracking-wider" style={{ color: phaseConfig.color }}>
            {phaseConfig.label}
          </span>
          {state.frozen_reason && (
            <span className="text-[8px] text-[#f85149] ml-auto">{state.frozen_reason}</span>
          )}
        </div>
      </div>

      {/* Receipt gates */}
      <div className="mb-3">
        <div className="text-[8px] text-[#484f58] uppercase tracking-wider mb-1.5">Receipt Gates</div>
        <div className="space-y-1">
          {[
            { key: 'training_gates_clear', label: 'Training Gates' },
            { key: 'benchmark_gates_clear', label: 'Benchmark Gates' },
            { key: 'frontier_blockers_clear', label: 'Frontier Blockers' },
          ].map((g) => {
            const clear = state[g.key];
            return (
              <button
                key={g.key}
                onClick={() => toggleGate(g.key)}
                disabled={updating}
                className="w-full flex items-center gap-2 p-1.5 border border-[#30363d] clip-corner hover:border-[#4dd0e1]/30 transition-colors text-left touch-manipulation"
              >
                {clear ? <CheckCircle size={11} className="text-[#3fb950] shrink-0" /> : <XCircle size={11} className="text-[#f85149] shrink-0" />}
                <span className="text-[9px] text-[#e6edf3]">{g.label}</span>
                <span className={`text-[7px] ml-auto font-bold ${clear ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>
                  {clear ? 'CLEAR' : 'BLOCKED'}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Promotion eligible */}
      <div className={`p-2 border clip-corner mb-3 ${state.promotion_eligible ? 'border-[#3fb950]/40 bg-[#3fb950]/5' : 'border-[#30363d]'}`}>
        <div className="flex items-center gap-2">
          <TrendingUp size={12} className={state.promotion_eligible ? 'text-[#3fb950]' : 'text-[#484f58]'} />
          <span className={`text-[9px] font-bold ${state.promotion_eligible ? 'text-[#3fb950]' : 'text-[#484f58]'}`}>
            {state.promotion_eligible ? 'ELIGIBLE FOR PHASE-2 PROMOTION' : 'NOT ELIGIBLE — gates must clear'}
          </span>
        </div>
      </div>

      {/* Queue stats */}
      <div className="grid grid-cols-3 gap-1.5 mb-3">
        <div className="border border-[#30363d] clip-corner p-1.5 text-center">
          <div className="text-[7px] text-[#484f58] uppercase">Queue Before</div>
          <div className="text-[#4dd0e1] font-mono text-sm">{state.queue_before}</div>
        </div>
        <div className="border border-[#30363d] clip-corner p-1.5 text-center">
          <div className="text-[7px] text-[#484f58] uppercase">Processed</div>
          <div className="text-[#FF9F00] font-mono text-sm">{state.cycle_processing_count}</div>
        </div>
        <div className="border border-[#30363d] clip-corner p-1.5 text-center">
          <div className="text-[7px] text-[#484f58] uppercase">Queue After</div>
          <div className="text-[#3fb950] font-mono text-sm">{state.queue_after}</div>
        </div>
      </div>

      {/* Autonomous actions */}
      <div className="flex items-center gap-2 text-[8px] text-[#484f58]">
        <span>Autonomous actions executed:</span>
        <span className="text-[#FF9F00] font-mono font-bold">{state.autonomous_actions_executed}</span>
      </div>

      {/* Advance button */}
      <button
        onClick={advanceStage}
        disabled={updating}
        className="w-full mt-3 flex items-center justify-center gap-2 px-3 py-2 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner hover:bg-[#FF9F00]/20 transition-colors disabled:opacity-50 touch-manipulation"
      >
        {updating ? <Loader2 size={12} className="animate-spin" /> : <TrendingUp size={12} />}
        Advance Stage
      </button>
    </div>
  );
}