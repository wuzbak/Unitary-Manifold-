/**
 * TopStoriesBySource — collapsible per-outlet tab accordion for the Trusted
 * News Ticker. Each of the 12 trusted outlets is a tab button; clicking opens
 * a panel with that outlet's live top stories (each linking to the article) and
 * a "Visit Site" link to the outlet homepage. Outlets without a public live
 * feed show a muted note + the visit link. Single-open accordion.
 *
 * Matches the app's tactical expand/collapse pattern (clip-corner, glass-panel,
 * chevron toggles, category chips).
 */
import { useState, useMemo } from 'react';
import { ChevronDown, ChevronUp, ExternalLink, Clock, Newspaper, FileText } from 'lucide-react';
import { TRUSTED_SOURCES, CATEGORY_META } from '@/lib/geo/trustedNews';

const FALLBACK_CAT = { short: 'NEWS', color: '#8b949e', label: 'Unknown' };

export default function TopStoriesBySource({ headlines }) {
  const [active, setActive] = useState(null);

  const bySource = useMemo(() => {
    const map = {};
    headlines.forEach((h) => {
      if (!h.id) return;
      if (!map[h.id]) map[h.id] = [];
      map[h.id].push(h);
    });
    return map;
  }, [headlines]);

  const toggle = (id) => setActive((cur) => (cur === id ? null : id));

  return (
    <div className="mt-3 tactical-hud glass-panel clip-corner overflow-hidden">
      <div className="flex items-center gap-2 px-3 py-2 border-b border-[#30363d] bg-[#0a0d11]">
        <Newspaper size={13} className="text-[#00f5ff]" />
        <span className="text-[10px] font-bold text-[#00f5ff] uppercase tracking-wider">Top Stories by Source</span>
        <span className="text-[8px] text-[#484f58] ml-auto hidden sm:inline">{TRUSTED_SOURCES.length} outlets · click to expand</span>
      </div>

      {/* Outlet tab buttons */}
      <div className="flex flex-wrap gap-1.5 p-3">
        {TRUSTED_SOURCES.map((s) => {
          const cat = CATEGORY_META[s.category] || FALLBACK_CAT;
          const count = bySource[s.id]?.length || 0;
          const isOpen = active === s.id;
          return (
            <button key={s.id} onClick={() => toggle(s.id)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 border rounded text-[10px] transition-all min-h-[36px] ${isOpen ? '' : 'border-[#30363d] bg-[#0d1117] text-[#8b949e] hover:border-[#00f5ff]/40 hover:text-[#e6edf3]'}`}
              style={isOpen ? { borderColor: cat.color, background: `${cat.color}15`, color: cat.color } : {}}>
              <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: cat.color }} />
              <span className="font-bold whitespace-nowrap">{s.name}</span>
              <span className="text-[8px] opacity-70">{count > 0 ? count : '—'}</span>
              {isOpen ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
            </button>
          );
        })}
      </div>

      {/* Active outlet stories panel */}
      {active && (() => {
        const s = TRUSTED_SOURCES.find((x) => x.id === active);
        const cat = CATEGORY_META[s.category] || FALLBACK_CAT;
        const stories = bySource[s.id] || [];
        return (
          <div className="border-t border-[#30363d] p-3 fade-in">
            <div className="flex items-center justify-between mb-2 gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <span className="px-2 py-0.5 rounded font-bold uppercase tracking-wider text-[8px] shrink-0"
                  style={{ background: `${cat.color}20`, color: cat.color, border: `1px solid ${cat.color}40` }}>{cat.label}</span>
                <span className="text-[11px] font-bold text-[#e6edf3] truncate">{s.name}</span>
              </div>
              <a href={s.url} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-1 px-2.5 py-1.5 border border-[#00f5ff]/30 bg-[#00f5ff]/10 text-[#00f5ff] text-[9px] font-bold rounded hover:bg-[#00f5ff]/20 transition-colors min-h-[32px] shrink-0">
                Visit Site <ExternalLink size={10} />
              </a>
            </div>
            <div className="text-[9px] text-[#8b949e] mb-2 italic">{s.trustTag}</div>
            {stories.length > 0 ? (
              <div className="space-y-1.5 max-h-[280px] overflow-y-auto pr-1">
                {stories.map((st, i) => (
                  <a key={i} href={st.url || '#'} target="_blank" rel="noopener noreferrer"
                    className="flex items-start gap-2 p-2 border border-[#30363d] bg-[#0d1117] rounded hover:border-[#00f5ff]/40 transition-colors group">
                    <FileText size={11} className="text-[#484f58] shrink-0 mt-0.5 group-hover:text-[#00f5ff]" />
                    <div className="min-w-0 flex-1">
                      <div className="text-[10px] text-[#e6edf3] group-hover:text-[#00f5ff] leading-snug">{st.title}</div>
                      {st.published && (
                        <div className="text-[8px] text-[#484f58] mt-0.5 flex items-center gap-1"><Clock size={8} /> {st.published}</div>
                      )}
                    </div>
                    <ExternalLink size={10} className="text-[#484f58] shrink-0 mt-0.5 group-hover:text-[#00f5ff]" />
                  </a>
                ))}
              </div>
            ) : (
              <div className="text-[10px] text-[#8b949e] italic p-2 border border-dashed border-[#30363d] rounded">
                No public live feed for this outlet — visit the site for the latest.
              </div>
            )}
          </div>
        );
      })()}
    </div>
  );
}