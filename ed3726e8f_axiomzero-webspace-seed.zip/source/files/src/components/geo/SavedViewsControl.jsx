/**
 * SavedViewsControl — save / list / apply / delete Geo Monitor views.
 * Views are persisted to the GeoMonitorView entity (owner-only RLS). Each
 * view stores a config bundle: activeFeeds, filters, basemap, viewport, and
 * optional watchlist thresholds. Calls onViewsChange so the parent can
 * compute watchlist hits from the loaded views + live events.
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Bookmark, ChevronDown, Save, Trash2, Check, X, Loader2 } from 'lucide-react';

export default function SavedViewsControl({ currentConfig, onApply, onViewsChange }) {
  const [views, setViews] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [naming, setNaming] = useState(false);
  const [name, setName] = useState('');
  const [error, setError] = useState(null);

  const loadViews = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await base44.entities.GeoMonitorView.list('-updated_date', 50);
      setViews(list || []);
      onViewsChange?.(list || []);
    } catch (e) {
      setError(e.message || 'Failed to load views');
    }
    setLoading(false);
  }, [onViewsChange]);

  useEffect(() => { loadViews(); }, [loadViews]);

  const saveView = async () => {
    if (!name.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const created = await base44.entities.GeoMonitorView.create({
        name: name.trim(),
        config_json: JSON.stringify(currentConfig),
      });
      setViews((v) => [created, ...v]);
      onViewsChange?.([created, ...views]);
      setName('');
      setNaming(false);
    } catch (e) {
      setError(e.message || 'Failed to save view');
    }
    setLoading(false);
  };

  const applyView = (v) => {
    try {
      const cfg = JSON.parse(v.config_json || '{}');
      onApply?.(cfg);
      setOpen(false);
    } catch {
      setError('Invalid view config');
    }
  };

  const deleteView = async (id) => {
    try {
      await base44.entities.GeoMonitorView.delete(id);
      const next = views.filter((v) => v.id !== id);
      setViews(next);
      onViewsChange?.(next);
    } catch (e) {
      setError(e.message || 'Failed to delete view');
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => { setOpen((o) => !o); if (!open) loadViews(); }}
        className="glass-strong clip-corner px-3 py-2 text-[10px] font-bold tracking-wide flex items-center gap-1.5 text-[#8b949e] hover:text-[#e6edf3] border border-[#30363d] transition-all min-h-[36px]"
      >
        <Bookmark size={12} /> Views
        <span className="text-[8px] text-[#484f58]">({views.length})</span>
        <ChevronDown size={10} className={open ? 'rotate-180 transition-transform' : 'transition-transform'} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-[399]" onClick={() => setOpen(false)} />
          <div className="absolute top-full right-0 mt-1 w-56 glass-strong clip-corner overflow-hidden z-[400] fade-in">
            <div className="flex items-center justify-between px-3 py-2 border-b border-[#30363d]">
              <span className="text-[10px] font-bold text-[#e6edf3] uppercase tracking-wider">Saved Views</span>
              {!naming ? (
                <button onClick={() => setNaming(true)} className="flex items-center gap-1 text-[9px] text-[#30d158] hover:text-[#3fb950]">
                  <Save size={10} /> New
                </button>
              ) : (
                <button onClick={() => setNaming(false)} className="text-[#484f58] hover:text-[#e6edf3]"><X size={11} /></button>
              )}
            </div>

            {naming && (
              <div className="px-3 py-2 border-b border-[#30363d] bg-[#0d1117]">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && saveView()}
                  placeholder="View name…"
                  autoFocus
                  className="w-full bg-[#161b22] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] focus:border-[#30d158]/40 focus:outline-none"
                />
                <button onClick={saveView} disabled={loading || !name.trim()}
                  className="w-full mt-1.5 bg-[#30d158]/20 border border-[#30d158]/40 text-[#30d158] rounded py-1.5 text-[10px] font-bold disabled:opacity-50 flex items-center justify-center gap-1">
                  {loading ? <Loader2 size={10} className="animate-spin" /> : <Check size={10} />} Save Current
                </button>
              </div>
            )}

            {error && <div className="px-3 py-1.5 text-[9px] text-[#ff6b6b]">{error}</div>}

            <div className="max-h-64 overflow-y-auto">
              {loading && views.length === 0 ? (
                <div className="flex items-center justify-center py-4"><Loader2 size={12} className="animate-spin text-[#8b949e]" /></div>
              ) : views.length === 0 ? (
                <div className="px-3 py-4 text-[10px] text-[#484f58] text-center">No saved views yet. Configure overlays + filters, then save.</div>
              ) : (
                views.map((v) => (
                  <div key={v.id} className="flex items-center gap-1 px-3 py-2 border-b border-[#30363d] last:border-b-0 hover:bg-[#00f5ff]/5 group">
                    <button onClick={() => applyView(v)} className="flex-1 text-left min-w-0">
                      <div className="text-[10px] font-bold text-[#e6edf3] truncate">{v.name}</div>
                      <div className="text-[8px] text-[#484f58]">{new Date(v.updated_date || v.created_date).toLocaleDateString()}</div>
                    </button>
                    <button onClick={() => deleteView(v.id)} className="text-[#484f58] hover:text-[#ff6b6b] opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                      <Trash2 size={11} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}