/**
 * MerlinInterpreterButton — "Ask Merlin about this event" button + interpretation panel.
 * Sends the selected event + full overlay metrics + repo context to Merlin (via
 * openRouterChat) and renders a structured four-section interpretation:
 *   1. What's Happening
 *   2. Who Is Affected
 *   3. Actionable Guidance
 *   4. UM Physics Significance
 *
 * The interpretation is grounded in the repo's ADJACENT TRACK epistemic framing
 * and never overstates the overlay as a hardgate claim.
 */
import { useState, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { chatText } from '@/lib/openrouter/client';
import { buildPersonaPrompt } from '@/lib/merlinPersona';
import { saveActiveSession } from '@/lib/merlinMemory';
import { Sparkles, Loader2, AlertTriangle, X, Lightbulb, Users, Shield, Atom } from 'lucide-react';

const INTERPRETER_SYSTEM = buildPersonaPrompt({ fourthWall: true, personaMode: 'serious' }) + `

You are Merlin, the Quantum Cat and assistant for AxiomZero Technologies & Consulting, SPC — a Washington State Social Purpose Corporation advancing the Unitary Manifold Framework (5D Kaluza-Klein physics).

You are acting as the GEO MONITOR EVENT INTERPRETER — a life-safety analysis tool. A user has selected a live disaster event from the UM Geophysical Monitor and wants a plain-language interpretation with actionable guidance.

Your job: take the event data and UM physics overlay metrics and produce a structured interpretation with EXACTLY four sections, in this order:

## What's Happening
Plain-language description of the event: what it is, where, when, magnitude/severity, and what it means in real-world terms. 2-3 sentences.

## Who Is Affected
Populations, regions, infrastructure, and supply chains at risk. Be specific about nearby cities, countries, and critical infrastructure. If the event is near a maritime chokepoint, mention it and the supply-chain implications. 2-3 sentences.

## Actionable Guidance
Specific, prioritized actions for response and safety. Number them. Include: immediate life-safety actions, monitoring recommendations, and follow-up resources. Be concrete — "check tsunami evacuation zones" not "be prepared." 3-5 numbered items.

## UM Physics Significance
What the overlay metrics mean, grounded in ADJACENT TRACK framing. Explain φ-debt, radion amplitude, winding stability in plain language with the [Fourth wall] device for any technical term. Always end with the epistemic label: "🔵 ADJACENT TRACK — not a hardgate physics claim." 3-4 sentences.

CRITICAL RULES:
- This is a LIFE-SAFETY product. Prioritize accuracy and actionable guidance over theory.
- The UM overlay is an EXPLORATORY quantitative analogue, NOT a verified physics prediction. Never present it as confirmed science.
- Use the [Fourth wall] device: after a technical term, write "**[Fourth wall]**" then explain in 1 sentence with a tangible analogy.
- If the event is near a maritime chokepoint (coordinates provided), note the supply-chain exposure.
- Cite the source feed (USGS, NASA EONET, NOAA NWS, etc.) in "What's Happening."
- Do not use filler like "great question." Be direct, warm, precise.
- End with the epistemic label on its own line.`;

function buildEventPrompt(event) {
  const o = event.overlay || {};
  const overlayBlock = o.kind ? `
UM PHYSICS OVERLAY (🔵 ADJACENT TRACK — exploratory, not a hardgate claim):
- Disaster kind: ${o.kind}
- Energy (SI): ${o.E_si?.toExponential(3)} J
- Energy (Planck): ${o.E_planck?.toExponential(3)}
- φ-debt injection: ${o.phiDebt?.toExponential(3)} (Pillar 16 — entropy analogue)
- φ-alignment: ${o.phiAlignment?.toFixed(4)} [0,1] · 1=pristine
- Radion amplitude: ${o.radionAmp?.toFixed(4)} |Δφ/φ₀| (Pillar 806)
- QCD suppression: ${o.suppression?.toExponential(3)} (IR back-reaction)
- Basin perturbation: ${o.basinPert?.toFixed(4)} (radion / basin depth)
- Winding stability: ${o.windingStab?.toFixed(4)} [0,1] · 1=stable (Pillar 786)
- w_a local: ${o.wALocal?.toExponential(3)} (Pillar 808 — breathing mode)
- Confidence: ${o.confidence}
- Epistemic label: ${o.epistemicLabel}
- Pillar sources: ${o.pillarSources?.join(', ')}` : `
UM PHYSICS OVERLAY: Not applicable — this is an observational station (gauge, buoy, air quality, or near-earth object). No energetic disaster overlay computed.`;

  const extraFields = [];
  if (event.depth != null) extraFields.push(`Depth: ${event.depth} km`);
  if (event.alertLevel) extraFields.push(`Alert Level: ${event.alertLevel}`);
  if (event.eventType) extraFields.push(`Event Type: ${event.eventType}`);
  if (event.aqi != null) extraFields.push(`AQI: ${event.aqi}`);
  if (event.brightness != null) extraFields.push(`Brightness: ${event.brightness} K`);
  if (event.discharge != null) extraFields.push(`Discharge: ${event.discharge} ft³/s`);
  if (event.hazardous != null) extraFields.push(`Potentially Hazardous: ${event.hazardous}`);

  return `EVENT DATA:
- Type: ${event.type}
- Title: ${event.title}
- Location: ${event.coords ? `${event.coords[0].toFixed(2)}°, ${event.coords[1].toFixed(2)}°` : 'Unknown'}
- Region: ${event.region || 'Unknown'}
- Magnitude/Severity: ${event.magnitude ?? event.severity ?? 'Unknown'}
- Time: ${event.time || 'Unknown'}
- Source: ${event.source || 'Unknown'}
${extraFields.length ? extraFields.join('\n') : ''}
${overlayBlock}

Provide the structured four-section interpretation now. Remember: this is a life-safety tool. Be specific, actionable, and honest about the epistemic status.`;
}

function parseSections(text) {
  const sections = { happening: '', affected: '', guidance: '', significance: '' };
  if (!text) return sections;
  const happeningMatch = text.match(/##\s*What'?s\s*Happening\s*\n([\s\S]*?)(?=##\s*Who|$)/i);
  const affectedMatch = text.match(/##\s*Who\s*Is\s*Affected\s*\n([\s\S]*?)(?=##\s*Actionable|$)/i);
  const guidanceMatch = text.match(/##\s*Actionable\s*Guidance\s*\n([\s\S]*?)(?=##\s*UM\s*Physics|$)/i);
  const sigMatch = text.match(/##\s*UM\s*Physics\s*Significance\s*\n([\s\S]*?)(?=---|$)/i);
  if (happeningMatch) sections.happening = happeningMatch[1].trim();
  if (affectedMatch) sections.affected = affectedMatch[1].trim();
  if (guidanceMatch) sections.guidance = guidanceMatch[1].trim();
  if (sigMatch) sections.significance = sigMatch[1].trim();
  // If no sections parsed, dump raw text into happening
  if (!sections.happening && !sections.affected && !sections.guidance && !sections.significance) {
    sections.happening = text.trim();
  }
  return sections;
}

export default function MerlinInterpreterButton({ event }) {
  const [interpretation, setInterpretation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showPanel, setShowPanel] = useState(false);

  const interpret = useCallback(async () => {
    setLoading(true);
    setError(null);
    setShowPanel(true);
    setInterpretation(null);
    try {
      // Fetch repo context for grounding
      let repoContext = '';
      try {
        const ctxRes = await base44.functions.invoke('fetchRepoContext', { level: 'brief' });
        const ctx = ctxRes.data || ctxRes;
        repoContext = ctx?.context || ctx?.brief || '';
      } catch { /* repo context optional */ }

      const systemPrompt = repoContext
        ? `${INTERPRETER_SYSTEM}\n\nREPOSITORY CONTEXT (Unitary Manifold):\n${repoContext.slice(0, 2000)}`
        : INTERPRETER_SYSTEM;

      const userPrompt = buildEventPrompt(event);

      const text = await chatText({
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        featureKey: 'merlin',
        temperature: 0.4,
        maxTokens: 1200,
      });

      setInterpretation(parseSections(text));

      // Save to Merlin's memory
      saveActiveSession({
        title: `Geo: ${event.title}`.slice(0, 60),
        context_type: 'geo-interpretation',
        messages: [
          { role: 'user', text: `Interpret event: ${event.title}`, time: Date.now() },
          { role: 'cat', text, time: Date.now() },
        ],
      });
      window.dispatchEvent(new Event('merlin-session-updated'));
    } catch (e) {
      setError(e.message || 'Interpretation failed');
    } finally {
      setLoading(false);
    }
  }, [event]);

  return (
    <>
      <button
        onClick={interpret}
        disabled={loading}
        className="mt-4 w-full flex items-center justify-center gap-2 px-3 py-2.5 border border-[#bc8cff]/40 bg-[#bc8cff]/10 text-[#bc8cff] text-xs font-bold clip-corner hover:bg-[#bc8cff]/20 transition-colors min-h-[44px] disabled:opacity-50"
      >
        {loading ? <Loader2 size={13} className="animate-spin" /> : <Sparkles size={13} />}
        {loading ? 'Merlin is interpreting...' : 'Ask Merlin about this event'}
      </button>

      {showPanel && (
        <>
          <div className="fixed inset-0 z-[1000] bg-black/40 backdrop-blur-sm" onClick={() => setShowPanel(false)} />
          <div className="fixed right-0 top-0 bottom-0 z-[1001] w-full max-w-md glass-strong clip-corner overflow-y-auto p-4 fade-in">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Sparkles size={16} className="text-[#bc8cff]" />
                <span className="text-sm font-bold text-[#bc8cff]">Merlin Interpretation</span>
              </div>
              <button onClick={() => setShowPanel(false)} className="text-[#484f58] hover:text-[#e6edf3] min-h-[44px] min-w-[44px] flex items-center justify-center">
                <X size={18} />
              </button>
            </div>

            <div className="text-[10px] text-[#8b949e] mb-3 pb-2 border-b border-[#30363d]">
              {event.title}
            </div>

            {loading && (
              <div className="flex flex-col items-center justify-center py-12 gap-3">
                <Loader2 size={24} className="animate-spin text-[#bc8cff]" />
                <div className="text-xs text-[#8b949e]">Merlin is analyzing the event and overlay metrics...</div>
              </div>
            )}

            {error && (
              <div className="bg-[#2a1a0a] border border-[#f85149]/30 clip-corner p-3">
                <AlertTriangle size={14} className="text-[#f85149] mb-1" />
                <p className="text-[#f85149] text-xs">{error}</p>
              </div>
            )}

            {interpretation && !loading && (
              <div className="space-y-3">
                {interpretation.happening && (
                  <div className="bg-[#0d1117] border border-[#30363d] rounded p-3">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <Lightbulb size={12} className="text-[#ffd60a]" />
                      <span className="text-[10px] font-bold text-[#ffd60a] uppercase tracking-wider">What's Happening</span>
                    </div>
                    <div className="text-xs text-[#e6edf3] leading-relaxed whitespace-pre-wrap">{interpretation.happening}</div>
                  </div>
                )}
                {interpretation.affected && (
                  <div className="bg-[#0d1117] border border-[#30363d] rounded p-3">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <Users size={12} className="text-[#4dd0e1]" />
                      <span className="text-[10px] font-bold text-[#4dd0e1] uppercase tracking-wider">Who Is Affected</span>
                    </div>
                    <div className="text-xs text-[#e6edf3] leading-relaxed whitespace-pre-wrap">{interpretation.affected}</div>
                  </div>
                )}
                {interpretation.guidance && (
                  <div className="bg-[#0d1117] border border-[#3fb950]/30 rounded p-3">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <Shield size={12} className="text-[#3fb950]" />
                      <span className="text-[10px] font-bold text-[#3fb950] uppercase tracking-wider">Actionable Guidance</span>
                    </div>
                    <div className="text-xs text-[#e6edf3] leading-relaxed whitespace-pre-wrap">{interpretation.guidance}</div>
                  </div>
                )}
                {interpretation.significance && (
                  <div className="bg-[#0d1117] border border-[#bc8cff]/30 rounded p-3">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <Atom size={12} className="text-[#bc8cff]" />
                      <span className="text-[10px] font-bold text-[#bc8cff] uppercase tracking-wider">UM Physics Significance</span>
                    </div>
                    <div className="text-xs text-[#e6edf3] leading-relaxed whitespace-pre-wrap">{interpretation.significance}</div>
                  </div>
                )}
              </div>
            )}
          </div>
        </>
      )}
    </>
  );
}