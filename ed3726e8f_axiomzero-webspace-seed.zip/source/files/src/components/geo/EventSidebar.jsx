/**
 * EventSidebar — searchable, sortable event registry with region + magnitude filters.
 * Presentational: all filter state is owned by the parent and passed as props.
 */
import { Search, ArrowUpDown, MapPin, X } from 'lucide-react';
import { FEEDS, REGIONS, feedForType } from '@/lib/geoFeeds';

export default function EventSidebar({
  events, selected, onSelect, onClose,
  search, setSearch, minMag, setMinMag,
  regions, toggleRegion, sortBy, setSortBy, sortDir, setSortDir,
}) {
  return (
    <div className="glass-panel clip-corner p-3 flex flex-col h-full">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-bold text-[#00f5ff] uppercase tracking-wider">Event Registry</span>
        {onClose && (
          <button onClick={onClose} className="text-[#484f58] hover:text-[#e6edf3] min-h-[36px] min-w-[36px] flex items-center justify-center">
            <X size={14} />
          </button>
        )}
      </div>

      {/* Search */}
      <div className="relative mb-2">
        <Search size={12} className="absolute left-2 top-2.5 text-[#484f58]" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search title or place..."
          className="w-full bg-[#0d1117] border border-[#30363d] rounded pl-7 pr-2 py-1.5 text-xs text-[#e6edf3] focus:border-[#4dd0e1]/40 focus:outline-none"
        />
      </div>

      {/* Magnitude slider */}
      <div className="mb-2">
        <div className="flex items-center justify-between text-[9px] text-[#8b949e] mb-1">
          <span>Min Magnitude</span>
          <span className="text-[#ff6b6b] font-bold">{minMag.toFixed(1)}</span>
        </div>
        <input
          type="range" min="0" max="9" step="0.5"
          value={minMag}
          onChange={(e) => setMinMag(parseFloat(e.target.value))}
          className="w-full accent-[#ff6b6b]"
        />
      </div>

      {/* Region chips */}
      <div className="mb-2">
        <div className="text-[9px] text-[#8b949e] mb-1">Region Filter</div>
        <div className="flex flex-wrap gap-1">
          {REGIONS.map(r => (
            <button
              key={r}
              onClick={() => toggleRegion(r)}
              className={`text-[9px] px-1.5 py-0.5 border clip-corner transition-colors ${
                regions.includes(r)
                  ? 'bg-[#00f5ff]/15 border-[#00f5ff]/40 text-[#00f5ff]'
                  : 'border-[#30363d] text-[#484f58] hover:text-[#8b949e]'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Sort controls */}
      <div className="flex items-center gap-2 mb-2">
        <button
          onClick={() => setSortBy(s => s === 'time' ? 'magnitude' : 'time')}
          className="flex items-center gap-1 text-[9px] px-2 py-1 border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] clip-corner min-h-[32px]"
        >
          <ArrowUpDown size={9} /> {sortBy === 'time' ? 'Time' : 'Magnitude'}
        </button>
        <button
          onClick={() => setSortDir(d => d === 'desc' ? 'asc' : 'desc')}
          className="text-[9px] px-2 py-1 border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] clip-corner min-h-[32px]"
        >
          {sortDir === 'desc' ? '↓ Desc' : '↑ Asc'}
        </button>
      </div>

      <div className="text-[9px] text-[#484f58] mb-1">{events.length} events</div>

      {/* Event list */}
      <div className="flex-1 overflow-y-auto space-y-1 min-h-0">
        {events.slice(0, 200).map(e => {
          const feed = feedForType(e.type);
          return (
            <button
              key={e.id}
              onClick={() => onSelect(e)}
              className={`w-full text-left px-2 py-1.5 rounded text-xs transition-colors border ${
                selected?.id === e.id
                  ? 'bg-[#00f5ff]/10 border-[#00f5ff]/30'
                  : 'border-transparent hover:bg-[#00f5ff]/5'
              }`}
            >
              <div className="flex items-start gap-1.5">
                <span className="text-sm shrink-0">{feed?.icon || '•'}</span>
                <div className="min-w-0 flex-1">
                  <div className="text-[#e6edf3] truncate font-bold">{e.title}</div>
                  <div className="text-[9px] text-[#484f58] flex items-center gap-1">
                    {typeof e.magnitude === 'number' && (
                      <span className="text-[#ff6b6b]">
                        {e.type === 'earthquake' ? `M${e.magnitude}` : e.type === 'airQuality' ? `AQI ${e.magnitude}` : `${e.magnitude}`}
                      </span>
                    )}
                    {e.overlay && (
                      <span className="text-[#bc8cff]" title={`Winding stability: ${e.overlay.windingStab?.toFixed(2)}`}>
                        {e.overlay.confidence === 'HIGH' ? '◆' : e.overlay.confidence === 'MEDIUM' ? '◇' : '○'}
                      </span>
                    )}
                    <MapPin size={8} /> {e.region || 'Unknown'}
                  </div>
                </div>
              </div>
            </button>
          );
        })}
        {events.length === 0 && (
          <div className="text-center text-[10px] text-[#484f58] py-4">No events match filters</div>
        )}
      </div>
    </div>
  );
}