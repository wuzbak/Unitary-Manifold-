/**
 * SwpcAlertsCard — recent NOAA SWPC alerts (last 15, newest first).
 */
import { Bell } from 'lucide-react';
import SpaceCardShell from './SpaceCardShell';

export default function SwpcAlertsCard({ data, on, onToggle, loading }) {
  const alerts = data?.alerts || [];
  return (
    <SpaceCardShell icon={<Bell size={13} />} color="#ffd60a" label="SWPC Alerts" on={on} onToggle={onToggle} loading={loading && !data}>
      <div className="space-y-1 max-h-32 overflow-y-auto">
        {alerts.length ? alerts.map((a, i) => (
          <div key={i} className="text-[9px] text-[#8b949e] border-l-2 border-[#ffd60a]/40 pl-2 py-0.5">
            <span className="text-[#e6edf3] font-bold">{a.product_id || 'Alert'}</span>
            <div className="text-[#484f58] truncate">{a.message ? a.message.slice(0, 90) : ''}</div>
          </div>
        )) : <div className="text-[9px] text-[#484f58]">No active alerts</div>}
      </div>
    </SpaceCardShell>
  );
}