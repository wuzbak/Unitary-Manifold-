/**
 * SolarFluxCard — GOES primary X-ray flux, classified A/B/C/M/X with a
 * severity ramp. Source: NOAA SWPC xrays-6-hour (0.05–0.4nm channel).
 */
import { Sun } from 'lucide-react';
import SpaceCardShell from './SpaceCardShell';
import UnavailableCard from '@/components/shared/UnavailableCard';
import { flareClass } from '@/hooks/useSpaceWeather';

export default function SolarFluxCard({ data, on, onToggle, loading }) {
  const flux = data?.xray?.flux;
  const fc = flareClass(flux);
  return (
    <SpaceCardShell icon={<Sun size={13} />} color="#ff9f0a" label="Solar X-Ray Flux" on={on} onToggle={onToggle} loading={loading && !data}>
      {flux == null ? (
        <UnavailableCard message="Solar flux unavailable" compact />
      ) : (
        <div className="space-y-1.5">
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono leading-none" style={{ color: fc.color }}>{fc.letter}</span>
            <span className="text-[10px] text-[#8b949e]">{fc.label}</span>
          </div>
          <div className="text-[9px] text-[#484f58] font-mono">{flux.toExponential(2)} W/m²</div>
          <div className="flex gap-0.5 mt-1">
            {['A', 'B', 'C', 'M', 'X'].map((l, i) => (
              <div key={l} className="flex-1 h-1.5" style={{ background: i <= fc.scale ? fc.color : '#30363d' }} />
            ))}
          </div>
        </div>
      )}
    </SpaceCardShell>
  );
}