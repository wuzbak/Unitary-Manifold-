/**
 * SdoImageryCard — live NASA SDO/AIA solar imagery thumbnails (171, 193,
 * 304, 211 Å). URLs are static near-real-time "latest" frames from
 * sdo.gsfc.nasa.gov. A compact 2×2 grid with channel labels.
 */
import { useState } from 'react';
import { Image as ImageIcon } from 'lucide-react';
import SpaceCardShell from './SpaceCardShell';
import UnavailableCard from '@/components/shared/UnavailableCard';

export default function SdoImageryCard({ data, on, onToggle, loading }) {
  const channels = data?.sdo?.channels || [];
  const [active, setActive] = useState(0);
  const current = channels[active] || channels[0];

  return (
    <SpaceCardShell icon={<ImageIcon size={13} />} color="#ff9f0a" label="SDO Solar Imagery" on={on} onToggle={onToggle} loading={loading && !data}>
      {channels.length === 0 ? (
        <UnavailableCard message="SDO imagery unavailable" compact />
      ) : (
        <div className="space-y-1.5">
          {current && (
            <div className="relative aspect-square w-full overflow-hidden clip-corner border border-[#30363d] bg-black">
              <img src={current.url} alt={current.label} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              <span className="absolute bottom-0.5 left-1 text-[8px] text-[#e6edf3] font-mono bg-black/60 px-1">{current.label}</span>
            </div>
          )}
          <div className="grid grid-cols-4 gap-1">
            {channels.map((c, i) => (
              <button key={c.label} onClick={() => setActive(i)} className={`aspect-square overflow-hidden clip-corner border touch-manipulation ${i === active ? 'border-[#ff9f0a]' : 'border-[#30363d] opacity-70'}`}>
                <img src={c.url} alt={c.label} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </button>
            ))}
          </div>
          <div className="text-[8px] text-[#484f58]">NASA SDO/AIA · near-real-time</div>
        </div>
      )}
    </SpaceCardShell>
  );
}