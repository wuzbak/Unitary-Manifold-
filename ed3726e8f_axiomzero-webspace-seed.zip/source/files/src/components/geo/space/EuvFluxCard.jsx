/**
 * EuvFluxCard — GOES EUVS extreme-ultraviolet photon flux (the ionizing
 * photon output that drives the ionosphere). Source: SWPC EUVS via proxy.
 */
import { Sun } from 'lucide-react';
import SpaceCardShell from './SpaceCardShell';
import UnavailableCard from '@/components/shared/UnavailableCard';

export default function EuvFluxCard({ data, on, onToggle, loading }) {
  const euv = data?.euv;
  const flux = euv?.flux;
  const band = euv?.band || 'EUV';
  const level = flux == null ? null : flux >= 5e-2 ? 'severe' : flux >= 1e-2 ? 'moderate' : 'minor';
  const color = level === 'severe' ? '#ff6b6b' : level === 'moderate' ? '#ff9f0a' : '#4dd0e1';
  return (
    <SpaceCardShell icon={<Sun size={13} />} color="#4dd0e1" label="EUV Photon Flux" on={on} onToggle={onToggle} loading={loading && !data}>
      {flux == null ? (
        <UnavailableCard message="EUV photon flux unavailable" compact />
      ) : (
        <div className="space-y-1.5">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono leading-none" style={{ color }}>{flux.toExponential(2)}</span>
            <span className="text-[9px] text-[#484f58]">W/m²</span>
          </div>
          <div className="text-[9px] text-[#8b949e]">{band}</div>
          <div className="flex gap-0.5 mt-1">
            {['low', 'mod', 'high'].map((l, i) => (
              <div key={l} className="flex-1 h-1.5" style={{ background: (level === 'severe' && i <= 2) || (level === 'moderate' && i <= 1) || (level === 'minor' && i <= 0) ? color : '#30363d' }} />
            ))}
          </div>
          <div className="text-[8px] text-[#484f58]">GOES EUVS · ionizing photon output</div>
        </div>
      )}
    </SpaceCardShell>
  );
}