/**
 * GeomagneticKpCard — NOAA planetary K-index, mapped to the G0–G5 storm
 * scale with a 0–9 progress bar. Source: NOAA SWPC planetary-k-index.
 */
import { Compass } from 'lucide-react';
import SpaceCardShell from './SpaceCardShell';
import UnavailableCard from '@/components/shared/UnavailableCard';
import { kpInfo } from '@/hooks/useSpaceWeather';

export default function GeomagneticKpCard({ data, on, onToggle, loading }) {
  const kp = data?.kp;
  const ki = kp ? kpInfo(kp.value) : null;
  return (
    <SpaceCardShell icon={<Compass size={13} />} color="#4dd0e1" label="Geomagnetic Kp" on={on} onToggle={onToggle} loading={loading && !data}>
      {!kp ? (
        <UnavailableCard message="Kp index unavailable" compact />
      ) : (
        <div className="space-y-1.5">
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono leading-none" style={{ color: ki.color }}>{ki.level}</span>
            <span className="text-[10px] text-[#8b949e]">{ki.label} · Kp {kp.value}</span>
          </div>
          <div className="h-2 bg-[#161b22] overflow-hidden">
            <div className="h-full transition-all" style={{ width: `${Math.min((kp.value / 9) * 100, 100)}%`, background: ki.color }} />
          </div>
          <div className="flex justify-between text-[8px] text-[#484f58] font-mono">
            <span>G0</span><span>G3</span><span>G5</span>
          </div>
        </div>
      )}
    </SpaceCardShell>
  );
}