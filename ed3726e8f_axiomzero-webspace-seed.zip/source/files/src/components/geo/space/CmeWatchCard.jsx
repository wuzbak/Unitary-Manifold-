/**
 * CmeWatchCard — NASA DONKI CME events (7-day) with flare/storm counts.
 * Source: nasaDonki backend function (Tier 2).
 */
import { Rocket } from 'lucide-react';
import SpaceCardShell from './SpaceCardShell';

export default function CmeWatchCard({ data, on, onToggle, loading }) {
  const donki = data?.donki;
  const cmes = donki?.cmes || [];
  return (
    <SpaceCardShell icon={<Rocket size={13} />} color="#bc8cff" label="CME Watch · DONKI" on={on} onToggle={onToggle} loading={loading && !donki}>
      <div className="space-y-1 max-h-32 overflow-y-auto">
        {cmes.length ? cmes.slice(0, 8).map((c) => (
          <div key={c.id} className="text-[9px] text-[#8b949e] border-l-2 border-[#bc8cff]/40 pl-2 py-0.5">
            <span className="text-[#e6edf3]">{new Date(c.startTime).toUTCString().slice(5, 22)}</span>
            <div className="text-[#484f58] truncate">{c.note || 'CME analysis'}</div>
          </div>
        )) : <div className="text-[9px] text-[#484f58]">No CMEs in 7-day window</div>}
      </div>
      <div className="text-[8px] text-[#484f58] mt-1.5">Flares: {donki?.flares?.length || 0} · Storms: {donki?.storms?.length || 0}</div>
    </SpaceCardShell>
  );
}