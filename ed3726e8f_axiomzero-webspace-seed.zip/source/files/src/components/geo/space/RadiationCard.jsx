/**
 * RadiationCard — GOES integral proton flux (>10 MeV), mapped to the S1–S5
 * solar radiation storm scale. Relevant to aviation HF radio and satellite
 * risk. Source: SWPC goes-primary-proton-flux.
 */
import { Radiation } from 'lucide-react';
import SpaceCardShell from './SpaceCardShell';
import UnavailableCard from '@/components/shared/UnavailableCard';

export default function RadiationCard({ data, on, onToggle, loading }) {
  const rad = data?.radiation;
  return (
    <SpaceCardShell icon={<Radiation size={13} />} color="#bc8cff" label="Radiation · Proton Flux" on={on} onToggle={onToggle} loading={loading && !data}>
      {!rad ? (
        <UnavailableCard message="Proton flux unavailable" compact />
      ) : (
        <div className="space-y-1.5">
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono leading-none" style={{ color: rad.sLevel.color }}>{rad.sLevel.level}</span>
            <span className="text-[10px] text-[#8b949e]">{rad.sLevel.label}</span>
          </div>
          <div className="text-[9px] text-[#484f58] font-mono">{rad.flux10.toExponential(1)} pfu (&gt;10 MeV)</div>
          <div className="flex gap-0.5 mt-1">
            {['S1', 'S2', 'S3', 'S4', 'S5'].map((l) => {
              const active = parseInt(rad.sLevel.level.slice(1)) >= parseInt(l.slice(1));
              return <div key={l} className="flex-1 h-1.5" style={{ background: active ? rad.sLevel.color : '#30363d' }} />;
            })}
          </div>
        </div>
      )}
    </SpaceCardShell>
  );
}