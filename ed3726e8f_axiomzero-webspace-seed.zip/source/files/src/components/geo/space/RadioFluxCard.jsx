/**
 * RadioFluxCard — Penticton F10.7 cm solar radio flux (the canonical solar
 * activity index, 10.7cm). Source: SWPC via proxy. Units: solar flux units (sfu).
 */
import { Radio } from 'lucide-react';
import SpaceCardShell from './SpaceCardShell';
import UnavailableCard from '@/components/shared/UnavailableCard';

export default function RadioFluxCard({ data, on, onToggle, loading }) {
  const f = data?.f107?.flux;
  const level = f == null ? null : f >= 200 ? 'severe' : f >= 130 ? 'moderate' : f >= 70 ? 'low' : 'quiet';
  const color = level === 'severe' ? '#ff6b6b' : level === 'moderate' ? '#ff9f0a' : level === 'low' ? '#4dd0e1' : '#3fb950';
  return (
    <SpaceCardShell icon={<Radio size={13} />} color="#bc8cff" label="F10.7 Radio Flux" on={on} onToggle={onToggle} loading={loading && !data}>
      {f == null ? (
        <UnavailableCard message="F10.7 radio flux unavailable" compact />
      ) : (
        <div className="space-y-1.5">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono leading-none" style={{ color }}>{f.toFixed(1)}</span>
            <span className="text-[9px] text-[#484f58]">sfu</span>
          </div>
          <div className="text-[10px] font-bold" style={{ color }}>{level === 'severe' ? 'High activity' : level === 'moderate' ? 'Moderate' : level === 'low' ? 'Low' : 'Quiet'}</div>
          <div className="flex gap-0.5 mt-1">
            {['Q', 'L', 'M', 'H'].map((l, i) => {
              const active = (level === 'severe') || (level === 'moderate' && i <= 2) || (level === 'low' && i <= 1) || (level === 'quiet' && i <= 0);
              return <div key={l} className="flex-1 h-1.5" style={{ background: active ? color : '#30363d' }} />;
            })}
          </div>
          <div className="text-[8px] text-[#484f58]">Penticton 10.7cm · solar activity index</div>
        </div>
      )}
    </SpaceCardShell>
  );
}