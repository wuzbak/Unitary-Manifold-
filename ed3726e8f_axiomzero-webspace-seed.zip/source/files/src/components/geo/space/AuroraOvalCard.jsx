/**
 * AuroraOvalCard — NOAA OVATION aurora forecast. Shows the lowest visible
 * latitude for each hemisphere (north/south) — the further equatorward, the
 * more people can see aurora. Source: SWPC ovation_aurora_latest.
 */
import { Sparkles } from 'lucide-react';
import SpaceCardShell from './SpaceCardShell';
import UnavailableCard from '@/components/shared/UnavailableCard';

export default function AuroraOvalCard({ data, on, onToggle, loading }) {
  const aurora = data?.aurora;
  return (
    <SpaceCardShell icon={<Sparkles size={13} />} color="#3fb950" label="Aurora Oval · OVATION" on={on} onToggle={onToggle} loading={loading && !data}>
      {!aurora ? (
        <UnavailableCard message="Aurora forecast unavailable" compact />
      ) : (
        <div className="space-y-1.5">
          <div className="flex items-center justify-center gap-3">
            <div className="text-center">
              <div className="text-[9px] text-[#484f58] uppercase">North</div>
              <div className="text-lg font-bold font-mono text-[#3fb950]">{aurora.northMin != null ? `${aurora.northMin.toFixed(0)}°N` : '—'}</div>
            </div>
            <div className="w-px h-8 bg-[#30363d]" />
            <div className="text-center">
              <div className="text-[9px] text-[#484f58] uppercase">South</div>
              <div className="text-lg font-bold font-mono text-[#3fb950]">{aurora.southMax != null ? `${Math.abs(aurora.southMax).toFixed(0)}°S` : '—'}</div>
            </div>
          </div>
          <div className="text-[9px] text-[#8b949e] text-center">
            Visible down to <span className="text-[#3fb950] font-bold font-mono">{aurora.visibilityLat != null ? `${aurora.visibilityLat.toFixed(0)}°` : '—'}</span> latitude
          </div>
          {aurora.forecastTime && <div className="text-[8px] text-[#484f58] text-center truncate">Forecast: {aurora.forecastTime}</div>}
        </div>
      )}
    </SpaceCardShell>
  );
}