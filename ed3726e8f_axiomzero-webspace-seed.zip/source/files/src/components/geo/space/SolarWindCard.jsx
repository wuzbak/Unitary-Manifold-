/**
 * SolarWindCard — ACE/DSCOVR real-time solar wind speed, density, and IMF Bz.
 * Southward Bz (negative) is the key geomagnetic-storm driver — colored red.
 * Sources: SWPC plasma-7-day + mag-1-day.
 */
import { Wind } from 'lucide-react';
import SpaceCardShell from './SpaceCardShell';
import UnavailableCard from '@/components/shared/UnavailableCard';

function Metric({ label, value, unit, color }) {
  return (
    <div className="bg-[#0d1117] border border-[#30363d] p-1.5 text-center">
      <div className="text-[8px] text-[#484f58] uppercase">{label}</div>
      <div className="text-sm font-bold font-mono" style={{ color }}>{value}</div>
      <div className="text-[7px] text-[#484f58]">{unit}</div>
    </div>
  );
}

export default function SolarWindCard({ data, on, onToggle, loading }) {
  const sw = data?.solarWind;
  return (
    <SpaceCardShell icon={<Wind size={13} />} color="#00f5ff" label="Solar Wind · IMF" on={on} onToggle={onToggle} loading={loading && !data}>
      {!sw ? (
        <UnavailableCard message="Solar wind telemetry unavailable" compact />
      ) : (
        <div className="space-y-1.5">
          <div className="grid grid-cols-3 gap-1.5">
            <Metric label="Speed" value={sw.speed != null ? sw.speed.toFixed(0) : '—'} unit="km/s" color={sw.speed != null && sw.speed >= 500 ? '#ff9f0a' : '#4dd0e1'} />
            <Metric label="Density" value={sw.density != null ? sw.density.toFixed(1) : '—'} unit="/cm³" color="#4dd0e1" />
            <Metric label="Bz" value={sw.bz != null ? sw.bz.toFixed(1) : '—'} unit="nT" color={sw.bz != null && sw.bz < 0 ? '#ff6b6b' : '#4dd0e1'} />
          </div>
          <div className="text-[8px] text-[#484f58]">
            {sw.bz != null && sw.bz < -5 ? '⚠ Southward Bz — storm driver active' : 'IMF nominal'}
          </div>
        </div>
      )}
    </SpaceCardShell>
  );
}