/**
 * SpaceDomainConsole — unified Space Domain section below the map.
 * Tactical-HUD section header with a master on/off toggle, active-count, and
 * last-updated timestamp. Responsive grid of compact cards, each with its own
 * on/off toggle. Card toggle state is owned by the parent (EarthMapConsole)
 * so it persists into saved-view configs.
 */
import { Satellite, RefreshCw, Power } from 'lucide-react';
import SolarFluxCard from './SolarFluxCard';
import GeomagneticKpCard from './GeomagneticKpCard';
import SolarWindCard from './SolarWindCard';
import RadiationCard from './RadiationCard';
import AuroraOvalCard from './AuroraOvalCard';
import CmeWatchCard from './CmeWatchCard';
import SwpcAlertsCard from './SwpcAlertsCard';
import EuvFluxCard from './EuvFluxCard';
import RadioFluxCard from './RadioFluxCard';
import SdoImageryCard from './SdoImageryCard';
import ScienceNewsCard from './ScienceNewsCard';

const CARD_KEYS = ['solarFlux', 'euv', 'f107', 'sdo', 'kp', 'solarWind', 'radiation', 'aurora', 'cme', 'alerts', 'scienceNews'];

export default function SpaceDomainConsole({ data, loading, lastUpdated, cards, setCards, onRefresh }) {
  const toggle = (k) => setCards((c) => ({ ...c, [k]: !c[k] }));
  const allOn = CARD_KEYS.every((k) => cards[k]);
  const masterToggle = () => setCards(Object.fromEntries(CARD_KEYS.map((k) => [k, !allOn])));
  const activeCount = CARD_KEYS.filter((k) => cards[k]).length;

  return (
    <div className="mt-4">
      <div className="tactical-hud glass-strong clip-corner p-2.5 mb-3 flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <Satellite size={15} className="text-[#bc8cff] glow-pulse" />
          <span className="text-xs font-bold text-[#bc8cff] uppercase tracking-wider">Space Domain Console</span>
          <span className="text-[8px] text-[#484f58]">P16 · Sentinel Capacity</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[9px] text-[#484f58] font-mono">{activeCount}/{CARD_KEYS.length} active</span>
          {lastUpdated && (
            <span className="flex items-center gap-1 text-[9px] text-[#484f58] font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-[#30d158] glow-pulse" />
              {lastUpdated.toLocaleTimeString()}
            </span>
          )}
          <button onClick={onRefresh} className="text-[#484f58] hover:text-[#e6edf3] min-h-[28px] min-w-[28px] flex items-center justify-center" aria-label="Refresh space weather">
            <RefreshCw size={11} />
          </button>
          <button onClick={masterToggle} className="flex items-center gap-1 px-2 py-1 border border-[#bc8cff]/40 bg-[#bc8cff]/10 text-[#bc8cff] text-[9px] font-bold clip-corner hover:bg-[#bc8cff]/20 transition-colors touch-manipulation">
            <Power size={10} /> {allOn ? 'All Off' : 'All On'}
          </button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        <SolarFluxCard data={data} on={cards.solarFlux} onToggle={() => toggle('solarFlux')} loading={loading} />
        <EuvFluxCard data={data} on={cards.euv} onToggle={() => toggle('euv')} loading={loading} />
        <RadioFluxCard data={data} on={cards.f107} onToggle={() => toggle('f107')} loading={loading} />
        <SdoImageryCard data={data} on={cards.sdo} onToggle={() => toggle('sdo')} loading={loading} />
        <GeomagneticKpCard data={data} on={cards.kp} onToggle={() => toggle('kp')} loading={loading} />
        <SolarWindCard data={data} on={cards.solarWind} onToggle={() => toggle('solarWind')} loading={loading} />
        <RadiationCard data={data} on={cards.radiation} onToggle={() => toggle('radiation')} loading={loading} />
        <AuroraOvalCard data={data} on={cards.aurora} onToggle={() => toggle('aurora')} loading={loading} />
        <CmeWatchCard data={data} on={cards.cme} onToggle={() => toggle('cme')} loading={loading} />
        <SwpcAlertsCard data={data} on={cards.alerts} onToggle={() => toggle('alerts')} loading={loading} />
        <ScienceNewsCard on={cards.scienceNews} onToggle={() => toggle('scienceNews')} />
      </div>
    </div>
  );
}