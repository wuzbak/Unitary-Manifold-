/**
 * SpaceCardShell — shared wrapper for a Space Domain console card.
 * Renders the tactical-HUD frame, a colored icon + uppercase label header,
 * an on/off toggle switch, and a collapsible body (scanlined). When `on` is
 * false the body collapses to a slim stub so the operator curates the grid.
 */
import { Loader2 } from 'lucide-react';

export default function SpaceCardShell({ icon, color, label, on, onToggle, loading, children, rightAdornment }) {
  return (
    <div className={`tactical-hud glass-panel clip-corner p-2.5 transition-opacity ${on ? '' : 'opacity-50'}`}>
      <div className="flex items-center justify-between mb-2 gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="shrink-0" style={{ color }}>{icon}</span>
          <span className="text-[10px] font-bold uppercase tracking-wider truncate" style={{ color }}>{label}</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {rightAdornment}
          <button
            onClick={onToggle}
            aria-label={on ? 'Turn card off' : 'Turn card on'}
            className={`relative w-8 h-4 clip-corner border transition-colors touch-manipulation ${on ? 'bg-[#00f5ff]/20 border-[#00f5ff]/50' : 'bg-[#161b22] border-[#30363d]'}`}
          >
            <span className={`absolute top-0.5 w-2.5 h-2.5 transition-all ${on ? 'left-5 bg-[#00f5ff]' : 'left-0.5 bg-[#484f58]'}`} />
          </button>
        </div>
      </div>
      {on && (
        <div className="hud-scanline min-h-[72px]">
          {loading ? (
            <div className="flex items-center justify-center py-5 relative z-[2]">
              <Loader2 size={14} className="animate-spin" style={{ color }} />
            </div>
          ) : (
            <div className="relative z-[2]">{children}</div>
          )}
        </div>
      )}
    </div>
  );
}