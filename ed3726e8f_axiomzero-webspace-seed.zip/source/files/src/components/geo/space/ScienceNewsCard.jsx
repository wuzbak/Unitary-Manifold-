/**
 * ScienceNewsCard — Space Domain console card showing live headlines from
 * NASA JPL, NASA Main, NASA CNEOS, and ScienceDaily Space & Time.
 *
 * Self-contained: fetches its own data from the `nasaFeeds` backend function
 * on mount + every 10 min. Displays the latest headlines in a scrollable
 * list with outlet chips and external links. Degrades gracefully on failure.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Newspaper, ExternalLink, Clock } from 'lucide-react';
import SpaceCardShell from './SpaceCardShell';

const OUTLET_COLORS = {
  'NASA JPL': '#4dd0e1',
  'NASA': '#3b8bff',
  'NASA CNEOS': '#bc8cff',
  'ScienceDaily': '#3fb950',
};

export default function ScienceNewsCard({ on, onToggle }) {
  const [headlines, setHeadlines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('loading');

  useEffect(() => {
    if (!on) return;
    let cancelled = false;
    const load = async () => {
      try {
        const res = await base44.functions.invoke('nasaFeeds', {});
        const d = res.data || res;
        if (cancelled) return;
        setHeadlines(d.headlines || []);
        setStatus(d.status || (d.headlines?.length ? 'live' : 'unavailable'));
      } catch {
        if (!cancelled) { setHeadlines([]); setStatus('unavailable'); }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    load();
    const id = setInterval(load, 600000);
    return () => { cancelled = true; clearInterval(id); };
  }, [on]);

  const statusColor = status === 'live' ? '#3fb950' : status === 'partial' ? '#FF9F00' : '#8b949e';

  return (
    <SpaceCardShell
      icon={<Newspaper size={12} />}
      color="#bc8cff"
      label="Science & Space News"
      on={on}
      onToggle={onToggle}
      loading={loading}
      rightAdornment={on && !loading && headlines.length > 0 && (
        <span className="flex items-center gap-1 text-[8px] font-mono" style={{ color: statusColor }}>
          <span className="w-1.5 h-1.5 rounded-full glow-pulse" style={{ background: statusColor }} />
          {status === 'live' ? 'LIVE' : status === 'partial' ? 'PARTIAL' : 'OFFLINE'}
        </span>
      )}
    >
      {headlines.length === 0 ? (
        <div className="text-[10px] text-[#8b949e] italic py-2 text-center">
          {status === 'unavailable' ? 'Feed temporarily unavailable' : 'No headlines'}
        </div>
      ) : (
        <div className="space-y-1.5 max-h-[180px] overflow-y-auto pr-1">
          {headlines.slice(0, 8).map((h, i) => {
            const color = OUTLET_COLORS[h.outlet] || '#8b949e';
            return (
              <a key={i} href={h.url || '#'} target="_blank" rel="noopener noreferrer"
                className="flex items-start gap-1.5 p-1.5 border border-[#30363d] bg-[#0d1117] rounded hover:border-[#bc8cff]/40 transition-colors group">
                <span className="w-1 h-1 rounded-full shrink-0 mt-1.5" style={{ background: color }} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1 mb-0.5">
                    <span className="text-[7px] font-bold uppercase tracking-wider px-1 rounded shrink-0"
                      style={{ color, background: `${color}15` }}>{h.outlet}</span>
                  </div>
                  <div className="text-[9px] text-[#e6edf3] group-hover:text-[#bc8cff] leading-snug line-clamp-2">{h.title}</div>
                </div>
                <ExternalLink size={9} className="text-[#484f58] shrink-0 mt-0.5 group-hover:text-[#bc8cff]" />
              </a>
            );
          })}
        </div>
      )}
    </SpaceCardShell>
  );
}