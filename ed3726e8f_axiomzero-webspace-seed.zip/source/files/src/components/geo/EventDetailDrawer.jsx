/**
 * EventDetailDrawer — right-side sheet showing full event metadata + source links.
 */
import { X, ExternalLink, Clock, MapPin, Activity, Layers, Globe, Ship } from 'lucide-react';
import { feedForType } from '@/lib/geoFeeds';
import OverlayCard from '@/components/geo/OverlayCard';
import MerlinInterpreterButton from '@/components/geo/MerlinInterpreterButton';
import { nearbyChokepoints } from '@/lib/geo/chokepoints';

function fmtTime(t) {
  if (!t) return 'Unknown';
  try {
    return new Date(typeof t === 'number' ? t : t).toLocaleString();
  } catch {
    return String(t);
  }
}

export default function EventDetailDrawer({ event, onClose }) {
  if (!event) return null;
  const feed = feedForType(event.type);

  return (
    <>
      <div className="fixed inset-0 z-[1000] bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed right-0 top-0 bottom-0 z-[1001] w-full max-w-md glass-strong clip-corner overflow-y-auto p-4 fade-in">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-2xl shrink-0">{feed?.icon}</span>
            <div className="min-w-0">
              <div className="text-[9px] uppercase tracking-wider truncate" style={{ color: feed?.color }}>{feed?.label}</div>
              <div className="text-[10px] text-[#484f58]">{feed?.pillar}</div>
            </div>
          </div>
          <button onClick={onClose} className="text-[#484f58] hover:text-[#e6edf3] min-h-[44px] min-w-[44px] flex items-center justify-center shrink-0">
            <X size={18} />
          </button>
        </div>

        <h2 className="text-lg font-bold text-[#e6edf3] mb-3 leading-tight">{event.title}</h2>

        <div className="space-y-2 text-xs">
          {typeof event.magnitude === 'number' && (
            <div className="flex items-center gap-2 text-[#e6edf3]">
              <Activity size={12} className="text-[#ff6b6b] shrink-0" />
              <span className="text-[#8b949e]">Magnitude:</span>
              <span className="font-bold text-[#ff6b6b]">{event.magnitude}</span>
            </div>
          )}
          {event.depth != null && (
            <div className="flex items-center gap-2 text-[#e6edf3]">
              <Layers size={12} className="text-[#4dd0e1] shrink-0" />
              <span className="text-[#8b949e]">Depth:</span>
              <span>{event.depth} km</span>
            </div>
          )}
          {event.place && (
            <div className="flex items-start gap-2 text-[#e6edf3]">
              <MapPin size={12} className="text-[#ffd60a] mt-0.5 shrink-0" />
              <span className="text-[#8b949e]">Location:</span>
              <span>{event.place}</span>
            </div>
          )}
          <div className="flex items-center gap-2 text-[#e6edf3]">
            <Clock size={12} className="text-[#30d158] shrink-0" />
            <span className="text-[#8b949e]">Time:</span>
            <span>{fmtTime(event.time)}</span>
          </div>
          {event.region && (
            <div className="flex items-center gap-2 text-[#e6edf3]">
              <Globe size={12} className="text-[#00f5ff] shrink-0" />
              <span className="text-[#8b949e]">Region:</span>
              <span>{event.region}</span>
            </div>
          )}
          {event.source && (
            <div className="flex items-center gap-2 text-[#e6edf3]">
              <span className="text-[#8b949e]">Source:</span>
              <span>{event.source}</span>
            </div>
          )}
          {event.coords && (
            <div className="flex items-center gap-2 text-[#e6edf3]">
              <span className="text-[#8b949e]">Coords:</span>
              <span className="font-mono text-[11px]">{event.coords[0].toFixed(2)}, {event.coords[1].toFixed(2)}</span>
            </div>
          )}
        </div>

        {event.url && (
          <a href={event.url} target="_blank" rel="noopener noreferrer"
            className="mt-4 flex items-center gap-2 px-3 py-2.5 border border-[#00f5ff]/30 bg-[#00f5ff]/10 text-[#00f5ff] text-xs font-bold clip-corner hover:bg-[#00f5ff]/20 transition-colors min-h-[44px]">
            <ExternalLink size={12} /> View Source Details
          </a>
        )}

        {(() => {
          const extras = [];
          if (event.alertLevel) extras.push(['Alert Level', event.alertLevel]);
          if (event.eventType) extras.push(['Event Type', event.eventType]);
          if (event.brightness != null) extras.push(['Brightness (K)', event.brightness]);
          if (event.confidence) extras.push(['Confidence', event.confidence]);
          if (event.aqi != null) extras.push(['AQI', event.aqi]);
          if (event.category) extras.push(['Category', event.category]);
          if (event.parameterName) extras.push(['Parameter', event.parameterName]);
          if (event.discharge != null) extras.push(['Discharge', `${event.discharge} ft³/s`]);
          if (event.siteCode) extras.push(['Site Code', event.siteCode]);
          if (event.diameter != null) extras.push(['Diameter', `${event.diameter.toFixed(3)} km`]);
          if (event.velocity != null) extras.push(['Velocity', `${Math.round(event.velocity)} km/h`]);
          if (event.missDistance != null) extras.push(['Miss Distance', `${Math.round(Number(event.missDistance)).toLocaleString()} km`]);
          if (event.hazardous != null) extras.push(['Potentially Hazardous', event.hazardous ? 'Yes' : 'No']);
          if (event.stationType) extras.push(['Station Type', event.stationType]);
          if (event.owner) extras.push(['Owner / Program', event.owner]);
          if (event.state) extras.push(['State / Territory', event.state]);
          if (!extras.length) return null;
          return (
            <div className="mt-4 pt-3 border-t border-[#30363d]">
              <div className="text-[9px] text-[#484f58] uppercase tracking-wider mb-2">Event Metadata</div>
              <div className="space-y-1">
                {extras.map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between text-xs">
                    <span className="text-[#8b949e]">{k}:</span>
                    <span className="text-[#e6edf3] font-mono text-[11px]">{String(v)}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })()}

        <div className="mt-4 pt-3 border-t border-[#30363d]">
          <div className="text-[9px] text-[#484f58] uppercase tracking-wider mb-1">UM Pillar Mapping</div>
          <div className="text-xs font-bold" style={{ color: feed?.color }}>{feed?.pillar}</div>
          <div className="text-[10px] text-[#8b949e] mt-1">{feed?.desc}</div>
        </div>

        {/* UM Physics Overlay breakdown */}
        <OverlayCard overlay={event.overlay} />

        {/* Supply-chain proximity (if event has coords) */}
        {event.coords && event.type !== 'chokepoint' && (() => {
          const nearby = nearbyChokepoints(event.coords[0], event.coords[1], 800);
          if (!nearby.length) return null;
          return (
            <div className="mt-4 pt-3 border-t border-[#30363d]">
              <div className="text-[9px] text-[#ff9f0a] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Ship size={11} /> Nearby Supply-Chain Chokepoints
              </div>
              <div className="space-y-1.5">
                {nearby.map((cp) => (
                  <div key={cp.id} className="bg-[#0d1117] border border-[#ff9f0a]/20 rounded p-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-[#e6edf3]">{cp.name}</span>
                      <span className="text-[9px] text-[#ff9f0a]">{cp.distanceKm} km</span>
                    </div>
                    <div className="text-[9px] text-[#8b949e] mt-0.5">{cp.notes}</div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {cp.commodities.map((c) => (
                        <span key={c} className="text-[8px] px-1 py-0.5 border border-[#30363d] text-[#8b949e] clip-corner">{c}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })()}

        {/* Supply-chain detail for chokepoint events */}
        {event.type === 'chokepoint' && event.supplyChain && (
          <div className="mt-4 pt-3 border-t border-[#30363d]">
            <div className="text-[9px] text-[#ff9f0a] uppercase tracking-wider mb-2">Supply-Chain Profile</div>
            <div className="bg-[#0d1117] border border-[#ff9f0a]/20 rounded p-2.5">
              <div className="text-[10px] text-[#8b949e] mb-1">Criticality: <span className="text-[#ff9f0a] font-bold">{'★'.repeat(event.supplyChain.criticality)}</span> ({event.supplyChain.criticality}/5)</div>
              <div className="text-[10px] text-[#8b949e] mb-1">Trade Share: ~{event.supplyChain.tradePct}% of global maritime</div>
              <div className="text-[10px] text-[#e6edf3] mt-2">{event.supplyChain.notes}</div>
              <div className="flex flex-wrap gap-1 mt-2">
                {event.supplyChain.commodities.map((c) => (
                  <span key={c} className="text-[8px] px-1.5 py-0.5 border border-[#ff9f0a]/30 text-[#ff9f0a] bg-[#ff9f0a]/5 clip-corner">{c}</span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Merlin Interpreter */}
        {event.type !== 'chokepoint' && (
          <MerlinInterpreterButton event={event} />
        )}
      </div>
    </>
  );
}