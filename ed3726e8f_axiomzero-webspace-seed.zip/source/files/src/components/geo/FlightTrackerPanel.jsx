/**
 * FlightTrackerPanel — Full rebuild with comprehensive search, filters,
 * sorting, pagination, follow-aircraft mode, and bidirectional map sync.
 *
 * Uses useFlightSearch hook for all state management.
 * Shares selected aircraft state with EarthMapConsole via props.
 *
 * Search: free-text across callsign, ICAO24, registration, type, origin/dest.
 * Filters: altitude range, speed range, aircraft type, military, on-ground.
 * Sort: callsign, altitude, speed, last-seen.
 * Pagination: 50 per page with prev/next + page numbers.
 * Follow: auto-refresh every 15s for a specific aircraft.
 * Map sync: onSelectAircraft callback flies the globe to the aircraft.
 */
import { useState, useMemo } from 'react';
import { Plane, Search, Loader2, RefreshCw, Radio, History, Filter, X, ChevronLeft, ChevronRight, Crosshair, Eye, EyeOff } from 'lucide-react';
import UnavailableCard from '@/components/shared/UnavailableCard';
import AircraftDetailDrawer from '@/components/geo/AircraftDetailDrawer';
import useFlightSearch from '@/lib/geo/useFlightSearch';

export default function FlightTrackerPanel({ selectedAircraft, onSelectAircraft }) {
  const fs = useFlightSearch();
  const [showFilters, setShowFilters] = useState(false);

  // Sync external selection (from map) with internal state
  const selected = selectedAircraft || fs.selected;
  const setSelected = (ac) => {
    fs.setSelected(ac);
    if (onSelectAircraft) onSelectAircraft(ac);
  };

  const handleResultClick = (ac) => {
    setSelected(ac);
  };

  const handleFollow = (ac) => {
    if (fs.followId === ac.icao24) {
      fs.setFollowId(null);
    } else {
      fs.setFollowId(ac.icao24);
      setSelected(ac);
    }
  };

  const fmtAlt = (a) => {
    if (a.altitudeBaro != null) return typeof a.altitudeBaro === 'number' ? `${a.altitudeBaro.toFixed(0)}m` : a.altitudeBaro;
    if (a.baroAltitude != null) return `${a.baroAltitude.toFixed(0)}m`;
    return 'ground';
  };

  const fmtSpd = (a) => {
    if (a.groundSpeed != null) return `${a.groundSpeed.toFixed(0)}`;
    if (a.velocity != null) return `${a.velocity.toFixed(0)}`;
    return '—';
  };

  const highlightMatch = (text, q) => {
    if (!text || !q) return text;
    const idx = text.toLowerCase().indexOf(q.toLowerCase());
    if (idx < 0) return text;
    return (
      <>
        {text.slice(0, idx)}
        <mark className="bg-[#4dd0e1]/30 text-[#4dd0e1] rounded-sm">{text.slice(idx, idx + q.length)}</mark>
        {text.slice(idx + q.length)}
      </>
    );
  };

  const q = fs.query.trim();

  return (
    <div className="glass-panel clip-corner p-3">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Plane size={14} className="text-[#4dd0e1]" />
          <span className="text-xs font-bold text-[#4dd0e1]">Flight Tracker</span>
          <span className="text-[8px] text-[#484f58] border border-[#30363d] rounded px-1.5 py-0.5">Open Science</span>
        </div>
        <div className="flex gap-1">
          <button
            onClick={() => { fs.setSource('adsb'); fs.setResults(null); }}
            className={`flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold transition-colors ${fs.source === 'adsb' ? 'bg-[#4dd0e1] text-black' : 'bg-[#161b22] border border-[#30363d] text-[#8b949e]'}`}
          >
            <Radio size={9} /> ADSB
          </button>
          <button
            onClick={() => { fs.setSource('opensky'); fs.setResults(null); }}
            className={`flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold transition-colors ${fs.source === 'opensky' ? 'bg-[#FF9F00] text-black' : 'bg-[#161b22] border border-[#30363d] text-[#8b949e]'}`}
          >
            <History size={9} /> OpenSky
          </button>
        </div>
      </div>

      {/* Search bar */}
      <div className="space-y-2">
        <div className="flex gap-1.5">
          <input
            type="text"
            value={fs.query}
            onChange={(e) => fs.setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && fs.search()}
            placeholder={fs.source === 'adsb' ? 'Search callsign, ICAO24, registration, type, origin…' : 'ICAO24 hex for track (e.g. a1b2c3)…'}
            className="flex-1 bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] focus:border-[#4dd0e1]/40 focus:outline-none"
          />
          <button onClick={fs.search} disabled={fs.loading} className="px-2 py-1.5 bg-[#4dd0e1]/20 border border-[#4dd0e1]/40 text-[#4dd0e1] rounded text-[10px] font-bold disabled:opacity-50 flex items-center gap-1">
            {fs.loading ? <Loader2 size={10} className="animate-spin" /> : <Search size={10} />} Search
          </button>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-1 px-2 py-1.5 rounded text-[10px] font-bold border transition-colors ${showFilters ? 'border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00]' : 'border-[#30363d] text-[#8b949e]'}`}
          >
            <Filter size={10} /> Filters
            {fs.activeFilterCount > 0 && (
              <span className="bg-[#FF9F00] text-black rounded-full px-1 text-[7px] font-bold">{fs.activeFilterCount}</span>
            )}
          </button>
        </div>

        {/* Area search (only when no text query) */}
        {!q && (
          <>
            <div className="grid grid-cols-3 gap-1.5">
              <div>
                <label className="text-[8px] text-[#484f58] block">Lat</label>
                <input type="text" value={fs.area.lat} onChange={(e) => fs.area.setLat(e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1 text-[10px] text-[#e6edf3]" />
              </div>
              <div>
                <label className="text-[8px] text-[#484f58] block">Lon</label>
                <input type="text" value={fs.area.lon} onChange={(e) => fs.area.setLon(e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1 text-[10px] text-[#e6edf3]" />
              </div>
              <div>
                <label className="text-[8px] text-[#484f58] block">Radius km</label>
                <input type="text" value={fs.area.dist} onChange={(e) => fs.area.setDist(e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1 text-[10px] text-[#e6edf3]" />
              </div>
            </div>
            {/* Quick location presets */}
            <div className="flex flex-wrap gap-1">
              {fs.presets.map((p) => (
                <button
                  key={p.label}
                  onClick={() => { fs.area.setLat(String(p.lat)); fs.area.setLon(String(p.lon)); fs.area.setDist(String(p.dist)); }}
                  className="text-[8px] px-1.5 py-0.5 border border-[#30363d] text-[#8b949e] rounded hover:border-[#4dd0e1]/40 hover:text-[#4dd0e1] transition-colors"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </>
        )}

        {/* Collapsible filters */}
        {showFilters && (
          <div className="bg-[#0d1117] border border-[#30363d] rounded p-2 space-y-2 fade-in">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-[#FF9F00] uppercase tracking-wider">Filters</span>
              <button onClick={fs.clearFilters} className="text-[8px] text-[#484f58] hover:text-[#ff6b6b] flex items-center gap-0.5">
                <X size={8} /> Clear all
              </button>
            </div>
            {/* Altitude range */}
            <div>
              <div className="flex items-center justify-between text-[8px] text-[#484f58]">
                <span>Altitude (m)</span>
                <span className="font-mono text-[#4dd0e1]">{fs.filters.altMin} – {fs.filters.altMax}</span>
              </div>
              <div className="flex gap-1 mt-0.5">
                <input type="range" min="0" max="15000" step="500" value={fs.filters.altMin} onChange={(e) => fs.setFilter('altMin', +e.target.value)} className="flex-1 accent-[#4dd0e1]" />
                <input type="range" min="0" max="15000" step="500" value={fs.filters.altMax} onChange={(e) => fs.setFilter('altMax', +e.target.value)} className="flex-1 accent-[#4dd0e1]" />
              </div>
            </div>
            {/* Speed range */}
            <div>
              <div className="flex items-center justify-between text-[8px] text-[#484f58]">
                <span>Speed (m/s)</span>
                <span className="font-mono text-[#4dd0e1]">{fs.filters.speedMin} – {fs.filters.speedMax}</span>
              </div>
              <div className="flex gap-1 mt-0.5">
                <input type="range" min="0" max="1000" step="50" value={fs.filters.speedMin} onChange={(e) => fs.setFilter('speedMin', +e.target.value)} className="flex-1 accent-[#4dd0e1]" />
                <input type="range" min="0" max="1000" step="50" value={fs.filters.speedMax} onChange={(e) => fs.setFilter('speedMax', +e.target.value)} className="flex-1 accent-[#4dd0e1]" />
              </div>
            </div>
            {/* Aircraft type + toggles */}
            <div className="grid grid-cols-2 gap-1.5">
              <input
                type="text"
                value={fs.filters.aircraftType}
                onChange={(e) => fs.setFilter('aircraftType', e.target.value)}
                placeholder="Aircraft type…"
                className="bg-[#0a0d11] border border-[#30363d] rounded px-1.5 py-1 text-[9px] text-[#e6edf3] placeholder:text-[#484f58]"
              />
              <select
                value={fs.filters.onGround}
                onChange={(e) => fs.setFilter('onGround', e.target.value)}
                className="bg-[#0a0d11] border border-[#30363d] rounded px-1.5 py-1 text-[9px] text-[#e6edf3]"
              >
                <option value="all">All aircraft</option>
                <option value="airborne">Airborne only</option>
                <option value="ground">On ground only</option>
              </select>
            </div>
            <label className="flex items-center gap-1.5 text-[9px] text-[#8b949e] cursor-pointer">
              <input type="checkbox" checked={fs.filters.militaryOnly} onChange={(e) => fs.setFilter('militaryOnly', e.target.checked)} className="accent-[#FF9F00]" />
              Military aircraft only
            </label>
          </div>
        )}

        {/* Sort dropdown */}
        {fs.allAircraft.length > 0 && !fs.isTrack && (
          <div className="flex items-center gap-2">
            <span className="text-[8px] text-[#484f58]">Sort:</span>
            <select
              value={fs.sortBy}
              onChange={(e) => fs.setSortBy(e.target.value)}
              className="bg-[#0d1117] border border-[#30363d] rounded px-1.5 py-1 text-[9px] text-[#e6edf3]"
            >
              {fs.sortOptions.map((s) => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </select>
          </div>
        )}

        {/* Error */}
        {fs.error && <UnavailableCard message={fs.error} onRetry={fs.search} compact />}

        {/* Loading */}
        {fs.loading && (
          <div className="flex items-center justify-center py-4 gap-2 text-[10px] text-[#8b949e]">
            <Loader2 size={12} className="animate-spin text-[#4dd0e1]" /> Querying {fs.source === 'adsb' ? 'ADSB.lol' : 'OpenSky Network'}...
          </div>
        )}

        {/* Results */}
        {fs.results && !fs.loading && (
          <div className="space-y-1.5 fade-in">
            {/* Status bar */}
            {fs.updated && (
              <div className="text-[8px] text-[#484f58] flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <span className={`w-1.5 h-1.5 rounded-full glow-pulse ${fs.source === 'adsb' ? 'bg-[#4dd0e1]' : 'bg-[#FF9F00]'}`} />
                  Last sync: {fs.updated.toLocaleTimeString()}
                  {fs.followId && <span className="text-[#FF9F00] ml-1">· Following {fs.followId}</span>}
                </span>
                <button onClick={fs.search} className="flex items-center gap-1 hover:text-[#4dd0e1]">
                  <RefreshCw size={8} /> Refresh
                </button>
              </div>
            )}

            {/* Historical track */}
            {fs.isTrack ? (
              <div className="bg-[#0d1117] border border-[#FF9F00]/30 rounded p-2">
                <div className="text-[10px] font-bold text-[#FF9F00] mb-1">Historical Track — {fs.results.icao24}</div>
                <div className="text-[9px] text-[#8b949e] mb-1">{fs.results.track?.length || 0} path points</div>
                <div className="max-h-[200px] overflow-y-auto space-y-0.5">
                  {fs.results.track?.slice(0, 50).map((p, i) => (
                    <div key={i} className="text-[9px] text-[#8b949e] font-mono">
                      {new Date(p.time * 1000).toISOString().substring(11, 19)} · {p.latitude?.toFixed(3)}, {p.longitude?.toFixed(3)} · {p.altitude != null ? (p.altitude / 0.3048).toFixed(0) + 'ft' : 'ground'}
                    </div>
                  ))}
                </div>
              </div>
            ) : fs.totalResults === 0 ? (
              <div className="text-[10px] text-[#484f58] py-3 text-center">
                No aircraft found{fs.activeFilterCount > 0 ? ' matching filters.' : '.'} Try a broader search or different area.
              </div>
            ) : (
              <>
                {/* Result count + pagination info */}
                <div className="text-[9px] text-[#484f58] flex items-center justify-between">
                  <span>{fs.totalResults} aircraft · Source: {fs.results.source}</span>
                  <span>Page {fs.page + 1}/{fs.totalPages}</span>
                </div>

                {/* Aircraft list (current page) */}
                <div className="max-h-[280px] overflow-y-auto space-y-1">
                  {fs.pagedResults.map((a, i) => {
                    const isSelected = selected?.icao24 === a.icao24;
                    const isFollowing = fs.followId === a.icao24;
                    return (
                      <div
                        key={a.icao24 || i}
                        className={`flex items-center gap-1.5 p-1.5 border rounded transition-colors cursor-pointer ${isSelected ? 'border-[#4dd0e1]/60 bg-[#4dd0e1]/5' : 'border-[#30363d] bg-[#0d1117] hover:border-[#4dd0e1]/40'}`}
                        onClick={() => handleResultClick(a)}
                      >
                        <button
                          onClick={(e) => { e.stopPropagation(); handleResultClick(a); }}
                          className="flex items-center justify-center w-6 h-6 bg-[#4dd0e1]/10 border border-[#4dd0e1]/30 text-[#4dd0e1] rounded shrink-0"
                        >
                          <Crosshair size={10} />
                        </button>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold text-[#e6edf3] truncate">
                              {highlightMatch(a.callsign || a.icao24 || 'Unknown', q)}
                            </span>
                            <span className="text-[8px] text-[#484f58] shrink-0 ml-1">
                              {highlightMatch(a.aircraftType || a.registration || '', q)}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-[8px] text-[#8b949e] mt-0.5 font-mono">
                            <span>📍 {a.latitude?.toFixed(2)}, {a.longitude?.toFixed(2)}</span>
                            <span>✈ {fmtAlt(a)}</span>
                            <span>🔄 {fmtSpd(a)}m/s</span>
                            {a.fromOrigin && <span className="truncate">{highlightMatch(a.fromOrigin, q)}</span>}
                          </div>
                        </div>
                        <button
                          onClick={(e) => { e.stopPropagation(); handleFollow(a); }}
                          className={`flex items-center justify-center w-6 h-6 rounded shrink-0 transition-colors ${isFollowing ? 'text-[#FF9F00] bg-[#FF9F00]/10' : 'text-[#484f58] hover:text-[#FF9F00]'}`}
                          title={isFollowing ? 'Stop following' : 'Follow aircraft'}
                        >
                          {isFollowing ? <EyeOff size={10} /> : <Eye size={10} />}
                        </button>
                      </div>
                    );
                  })}
                </div>

                {/* Pagination controls */}
                {fs.totalPages > 1 && (
                  <div className="flex items-center justify-center gap-1.5 pt-1">
                    <button
                      onClick={() => fs.setPage(Math.max(0, fs.page - 1))}
                      disabled={fs.page === 0}
                      className="p-1 text-[#8b949e] hover:text-[#4dd0e1] disabled:opacity-30"
                    >
                      <ChevronLeft size={14} />
                    </button>
                    {Array.from({ length: Math.min(7, fs.totalPages) }, (_, i) => {
                      const pageNum = Math.max(0, Math.min(fs.totalPages - 7, fs.page - 3)) + i;
                      return (
                        <button
                          key={pageNum}
                          onClick={() => fs.setPage(pageNum)}
                          className={`w-6 h-6 rounded text-[9px] font-bold ${pageNum === fs.page ? 'bg-[#4dd0e1] text-black' : 'text-[#8b949e] hover:text-[#4dd0e1]'}`}
                        >
                          {pageNum + 1}
                        </button>
                      );
                    })}
                    <button
                      onClick={() => fs.setPage(Math.min(fs.totalPages - 1, fs.page + 1))}
                      disabled={fs.page === fs.totalPages - 1}
                      className="p-1 text-[#8b949e] hover:text-[#4dd0e1] disabled:opacity-30"
                    >
                      <ChevronRight size={14} />
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* Empty state */}
        {!fs.results && !fs.loading && !fs.error && (
          <div className="text-[10px] text-[#484f58] py-3 text-center">
            {fs.source === 'adsb'
              ? 'Search by callsign, ICAO24, registration, type, or origin/destination. Or enter lat/lon to find aircraft within a radius. ADSB.lol provides unfiltered community data — includes military, private, and government aircraft.'
              : 'Enter an ICAO24 hex code to query OpenSky Network for historical flight trajectories. OpenSky is the academic gold standard with 23+ trillion archived messages.'}
          </div>
        )}
      </div>

      {/* Aircraft detail drawer — only when standalone (no map sync) */}
      {!onSelectAircraft && (
        <AircraftDetailDrawer aircraft={selected} onClose={() => setSelected(null)} />
      )}
    </div>
  );
}