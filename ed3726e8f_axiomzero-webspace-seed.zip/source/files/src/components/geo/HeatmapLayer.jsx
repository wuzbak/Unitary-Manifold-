/**
 * HeatmapLayer — react-leaflet wrapper for leaflet.heat.
 * Renders a heat layer from [lat, lng, intensity] points.
 * Falls back to nothing (markers render separately) if the plugin is unavailable.
 */
import { useEffect, useRef } from 'react';
import { useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet.heat';

export default function HeatmapLayer({ points, radius = 25, blur = 18, maxZoom = 10 }) {
  const map = useMap();
  const layerRef = useRef(null);

  useEffect(() => {
    if (!map || typeof L.heatLayer !== 'function') return;

    if (layerRef.current) {
      map.removeLayer(layerRef.current);
      layerRef.current = null;
    }
    if (points.length > 0) {
      layerRef.current = L.heatLayer(points, { radius, blur, maxZoom });
      layerRef.current.addTo(map);
    }
    return () => {
      if (layerRef.current) {
        map.removeLayer(layerRef.current);
        layerRef.current = null;
      }
    };
  }, [map, points, radius, blur, maxZoom]);

  return null;
}