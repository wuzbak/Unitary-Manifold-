/**
 * EarthMapConsole — reusable live hazard-map console (v5).
 * Shared by GeoMonitor (Product 21) and the Topology page's Earth tab.
 *
 * v5 changes:
 *   - Tactical Pin Grid (teardrop symbol pins) via GlobeMap
 *   - Full airspace overlay: live ADSB aircraft on the globe + OpenSky tracks
 *   - Global situational KPI strip
 *   - Saved views + watchlist (GeoMonitorView entity) with import/export
 *   - Map legend key bar
 *
 * Hybrid fetch: client-side for CORS-friendly feeds, base44.functions.invoke
 * for backend proxies. Uses keyless Esri raster tiles via MapLibre.
 */
import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Activity, Loader, Filter, AlertTriangle, Flame, Ship, Search, RotateCcw, Plane, Radio } from 'lucide-react';
import {
  FEEDS, PILLAR_OVERLAYS, TYPE_TO_FEED,
  normalizeEarthquakes, normalizeEonet, normalizeNwsAlerts, normalizeTsunami, normalizeUsgsWater, regionBucket,
} from '@/lib/geoFeeds';
import { computeOverlay } from '@/lib/geo/umOverlay';
import { CHOKEPOINTS, COUNTRY_BRIEFS } from '@/lib/geo/chokepoints';
import GlobeMap from '@/components/geo/GlobeMap';
import EventSidebar from '@/components/geo/EventSidebar';
import EventDetailDrawer from '@/components/geo/EventDetailDrawer';
import BasemapSwitcher from '@/components/geo/BasemapSwitcher';
import ExportControl from '@/components/geo/ExportControl';
import SavedViewsControl from '@/components/geo/SavedViewsControl';
import GeoKpiStrip from '@/components/geo/GeoKpiStrip';
import AircraftDetailDrawer from '@/components/geo/AircraftDetailDrawer';
import SpaceDomainConsole from '@/components/geo/space/SpaceDomainConsole';
import GridStressPanel from '@/components/geo/GridStressPanel';
import { useSpaceWeather } from '@/hooks/useSpaceWeather';

const POINT_FEEDS = ['earthquakes', 'wildfires', 'volcanoes', 'storms', 'nwsAlerts', 'tsunami', 'gdacs', 'nhcCyclones', 'nasaFirms', 'nasaCneos', 'airNow', 'usgsWater', 'ndbcBuoys', 'coopsStations', 'gdelt', 'acled'];

const DEFAULT_FEEDS = () => ({
  earthquakes: false, wildfires: false, volcanoes: false, storms: false,
  nwsAlerts: true, tsunami: false, seaIce: false, drought: false,
  gdacs: false, nhcCyclones: false, usgsWater: false,
  nasaFirms: false, nasaCneos: false, airNow: false,
  ndbcBuoys: false, coopsStations: false,
  supplyChain: false, aircraft: false,
  milAircraft: false, maritime: false, density: false,
  gdelt: false, acled: false,
});

export default function EarthMapConsole({ defaultBasemap = 'dark', showConsolePanels = true, mapClass = 'h-[600px]', sharedSelectedAircraft, onSharedSelectedAircraftChange }) {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeFeeds, setActiveFeeds] = useState(DEFAULT_FEEDS);
  const resetFeeds = () => setActiveFeeds(DEFAULT_FEEDS());
  const [selected, setSelected] = useState(null);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [basemap, setBasemap] = useState(defaultBasemap);
  const [heatmapMode, setHeatmapMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [search, setSearch] = useState('');
  const [minMag, setMinMag] = useState(0);
  const [regions, setRegions] = useState([]);
  const [sortBy, setSortBy] = useState('time');
  const [sortDir, setSortDir] = useState('desc');

  const [chokepoints, setChokepoints] = useState(CHOKEPOINTS);
  const [countryQuery, setCountryQuery] = useState('');
  const [countryBrief, setCountryBrief] = useState(null);

  // Airspace overlay state
  const [aircraft, setAircraft] = useState([]);
  const [aircraftLoading, setAircraftLoading] = useState(false);
  const [internalSelectedAircraft, setInternalSelectedAircraft] = useState(null);
  const selectedAircraft = sharedSelectedAircraft !== undefined ? sharedSelectedAircraft : internalSelectedAircraft;
  const setSelectedAircraft = (ac) => {
    setInternalSelectedAircraft(ac);
    if (onSharedSelectedAircraftChange) onSharedSelectedAircraftChange(ac);
  };
  const [aircraftTrack, setAircraftTrack] = useState([]);
  const [aircraftRadius, setAircraftRadius] = useState(500);
  const [milAircraft, setMilAircraft] = useState([]);
  const [vessels, setVessels] = useState([]);
  const [densityPoints, setDensityPoints] = useState([]);
  const viewportRef = useRef({ center: [20, 0], zoom: 1.2 });
  const [viewport, setViewport] = useState({ center: [20, 0], zoom: 1.2 });

  // Space Domain console (shared fetch + per-card toggles)
  const sw = useSpaceWeather();
  const [spaceCards, setSpaceCards] = useState({
    solarFlux: true, euv: true, f107: true, sdo: true,
    kp: true, alerts: true, cme: true,
    aurora: true, solarWind: true, radiation: true,
    scienceNews: true,
  });

  // Saved views + watchlist
  const [savedViews, setSavedViews] = useState([]);

  const toggleFeed = (key) => setActiveFeeds((f) => ({ ...f, [key]: !f[key] }));
  const toggleRegion = (r) => setRegions((prev) => (prev.includes(r) ? prev.filter((x) => x !== r) : [...prev, r]));

  const handleViewportChange = useCallback((vp) => { viewportRef.current = vp; setViewport(vp); }, []);

  // Fetch chokepoints from backend (with static fallback)
  useEffect(() => {
    base44.functions.invoke('worldMonitorFeeds', {})
      .then((res) => {
        const d = res.data || res;
        if (d.chokepoints?.length) setChokepoints(d.chokepoints);
      })
      .catch(() => { /* static fallback already loaded */ });
  }, []);

  // Country brief lookup
  useEffect(() => {
    if (!countryQuery.trim()) { setCountryBrief(null); return; }
    const q = countryQuery.trim().toUpperCase();
    const brief = COUNTRY_BRIEFS[q];
    if (brief) {
      const nearby = brief.chokepoints.map((id) => CHOKEPOINTS.find((c) => c.id === id)).filter(Boolean);
      setCountryBrief({ ...brief, nearbyChokepoints: nearby });
    } else {
      const nameMatch = Object.values(COUNTRY_BRIEFS).find((c) =>
        c.name.toLowerCase().includes(countryQuery.trim().toLowerCase()));
      if (nameMatch) {
        const nearby = nameMatch.chokepoints.map((id) => CHOKEPOINTS.find((c) => c.id === id)).filter(Boolean);
        setCountryBrief({ ...nameMatch, nearbyChokepoints: nearby });
      } else {
        setCountryBrief({ notFound: true, query: countryQuery });
      }
    }
  }, [countryQuery]);

  // Fetch all hazard feeds (hybrid: client-side fetch + backend proxy invoke)
  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      setError(null);
      const all = [];
      const tasks = POINT_FEEDS.map((key) => {
        const feed = FEEDS[key];
        if (!feed) return null;
        if (feed.backend) {
          return { key, run: () => base44.functions.invoke(feed.backend, {}).then((r) => (feed.normalize || (() => []))(r.data || r)) };
        }
        if (key === 'earthquakes') return { key, run: () => fetch(feed.url).then((r) => r.json()).then(normalizeEarthquakes) };
        if (key === 'wildfires') return { key, run: () => fetch(feed.url).then((r) => r.json()).then((d) => normalizeEonet(d, 'wildfire')) };
        if (key === 'volcanoes') return { key, run: () => fetch(feed.url).then((r) => r.json()).then((d) => normalizeEonet(d, 'volcano')) };
        if (key === 'storms') return { key, run: () => fetch(feed.url).then((r) => r.json()).then((d) => normalizeEonet(d, 'storm')) };
        if (key === 'nwsAlerts') return { key, run: () => fetch(feed.url, { headers: { Accept: 'application/geo+json' } }).then((r) => r.json()).then(normalizeNwsAlerts) };
        if (key === 'tsunami') return { key, run: () => fetch(feed.url, { headers: { Accept: 'application/geo+json' } }).then((r) => r.json()).then(normalizeTsunami) };
        if (key === 'usgsWater') return { key, run: () => fetch(feed.url).then((r) => r.json()).then(normalizeUsgsWater) };
        return null;
      }).filter(Boolean);

      const results = await Promise.allSettled(tasks.map((t) => t.run()));
      if (cancelled) return;
      let failCount = 0;
      results.forEach((res, i) => {
        if (res.status === 'fulfilled') {
          const enriched = (res.value || []).map((e) => ({
            ...e,
            overlay: computeOverlay(e),
            region: e.coords ? regionBucket(e.coords[0], e.coords[1]) : 'Unknown',
          }));
          all.push(...enriched);
        } else {
          failCount++;
          console.warn(`Feed ${tasks[i].key} failed:`, res.reason);
        }
      });
      if (all.length === 0 && failCount === tasks.length) {
        setError('All live feeds unavailable (CORS or network). Showing fallback mode.');
      }
      setEvents(all);
      setLastUpdated(new Date());
      setLoading(false);
    };
    load();
    const interval = setInterval(load, 60000);
    return () => { cancelled = true; clearInterval(interval); };
  }, []);

  // Airspace overlay — poll ADSB.lol while active (auto-retargets away from
  // no-ADS-B-coverage zones and falls back to OpenSky global states if empty)
  useEffect(() => {
    if (!activeFeeds.aircraft) {
      setAircraft([]);
      setAircraftLoading(false);
      return;
    }
    let cancelled = false;
    const poll = async () => {
      setAircraftLoading(true);
      try {
        let [lat, lon] = viewportRef.current.center;
        // Auto-retarget away from no-ADS-B-coverage zones (Sahara / Atlantic / Africa)
        if (lat > -10 && lat < 35 && lon > -25 && lon < 60) { lat = 40; lon = -90; }
        const res = await base44.functions.invoke('adsbFlightTracker', { lat, lon, dist: aircraftRadius });
        const d = res.data || res;
        let ac = (!d.status || d.status === 'ok') ? (d.aircraft || []) : [];
        // Fallback to OpenSky bbox states if ADSB returns nothing
        if (ac.length === 0) {
          try {
            const osRes = await base44.functions.invoke('openskyFlights', { mode: 'live', bbox: { lamin: lat - 5, lomin: lon - 5, lamax: lat + 5, lomax: lon + 5 } });
            const osd = osRes.data || osRes;
            if (!cancelled && (!osd.status || osd.status === 'ok')) {
              ac = (osd.states || []).map((s) => ({
                icao24: s.icao24, callsign: s.callsign, latitude: s.latitude, longitude: s.longitude,
                altitudeBaro: s.baroAltitude, track: s.trueTrack, groundSpeed: s.velocity,
                onGround: s.onGround, squawk: s.squawk, fromOrigin: s.originCountry,
              }));
            }
          } catch { /* OpenSky fallback unavailable */ }
        }
        if (!cancelled) setAircraft(ac);
      } catch (e) {
        if (!cancelled) console.warn('Aircraft feed failed:', e.message);
      }
      if (!cancelled) setAircraftLoading(false);
    };
    poll();
    const id = setInterval(poll, 30000);
    return () => { cancelled = true; clearInterval(id); };
  }, [activeFeeds.aircraft, aircraftRadius]);

  // Military aircraft overlay — ADSB.lol /mil feed
  useEffect(() => {
    if (!activeFeeds.milAircraft) { setMilAircraft([]); return; }
    let cancelled = false;
    const poll = async () => {
      try {
        const res = await base44.functions.invoke('adsbFlightTracker', { mode: 'mil' });
        const d = res.data || res;
        if (!cancelled && (!d.status || d.status === 'ok')) setMilAircraft(d.aircraft || []);
      } catch { /* */ }
    };
    poll();
    const id = setInterval(poll, 30000);
    return () => { cancelled = true; clearInterval(id); };
  }, [activeFeeds.milAircraft]);

  // Maritime (AIS) vessel overlay
  useEffect(() => {
    if (!activeFeeds.maritime) { setVessels([]); return; }
    let cancelled = false;
    const poll = async () => {
      try {
        const res = await base44.functions.invoke('aisMaritime', {});
        const d = res.data || res;
        if (!cancelled && (!d.status || d.status === 'ok')) setVessels(d.vessels || []);
      } catch { /* */ }
    };
    poll();
    const id = setInterval(poll, 60000);
    return () => { cancelled = true; clearInterval(id); };
  }, [activeFeeds.maritime]);

  // Air-traffic density heatmap — OpenSky states/all aggregated to 5° cells
  useEffect(() => {
    if (!activeFeeds.density) { setDensityPoints([]); return; }
    let cancelled = false;
    const poll = async () => {
      try {
        const res = await base44.functions.invoke('openskyFlights', { mode: 'density' });
        const d = res.data || res;
        if (!cancelled && (!d.status || d.status === 'ok')) setDensityPoints(d.cells || []);
      } catch { /* */ }
    };
    poll();
    const id = setInterval(poll, 120000);
    return () => { cancelled = true; clearInterval(id); };
  }, [activeFeeds.density]);

  // Fetch OpenSky track for selected aircraft
  useEffect(() => {
    if (!selectedAircraft?.icao24) { setAircraftTrack([]); return; }
    let cancelled = false;
    (async () => {
      try {
        const res = await base44.functions.invoke('openskyFlights', { mode: 'track', icao24: selectedAircraft.icao24.toLowerCase() });
        const d = res.data || res;
        if (!cancelled && (!d.status || d.status === 'ok')) setAircraftTrack(d.track || []);
      } catch (e) {
        if (!cancelled) console.warn('Aircraft track failed:', e.message);
      }
    })();
    return () => { cancelled = true; };
  }, [selectedAircraft]);

  const feedVisible = useMemo(
    () => events.filter((e) => activeFeeds[TYPE_TO_FEED[e.type] || e.type]),
    [events, activeFeeds],
  );

  const filteredEvents = useMemo(() => {
    let result = feedVisible.filter((e) => {
      if (search.trim()) {
        const q = search.toLowerCase();
        if (!e.title?.toLowerCase().includes(q) && !e.place?.toLowerCase().includes(q)) return false;
      }
      if (minMag > 0 && typeof e.magnitude === 'number' && e.magnitude < minMag) return false;
      if (regions.length > 0 && !regions.includes(e.region)) return false;
      return true;
    });
    result.sort((a, b) => {
      let cmp = 0;
      if (sortBy === 'time') {
        cmp = new Date(a.time || 0).getTime() - new Date(b.time || 0).getTime();
      } else {
        cmp = (typeof a.magnitude === 'number' ? a.magnitude : 0) - (typeof b.magnitude === 'number' ? b.magnitude : 0);
      }
      return sortDir === 'desc' ? -cmp : cmp;
    });
    return result;
  }, [feedVisible, search, minMag, regions, sortBy, sortDir]);

  const counts = useMemo(() => {
    const c = {};
    POINT_FEEDS.forEach((key) => {
      const typeKey = Object.entries(TYPE_TO_FEED).find(([, v]) => v === key)?.[0] || key;
      c[key] = events.filter((e) => e.type === typeKey).length;
    });
    return c;
  }, [events]);

  const severeWeatherCount = useMemo(
    () => events.filter((e) => e.type === 'nwsAlert' && e.severity === 'severe').length,
    [events],
  );

  // Watchlist hits from saved views
  const watchlistHits = useMemo(() => {
    const hits = [];
    savedViews.forEach((v) => {
      let cfg;
      try { cfg = JSON.parse(v.config_json || '{}'); } catch { return; }
      const wl = cfg.watchlist;
      if (!wl) return;
      const match = events.find((e) => {
        const sevOk = e.severity === 'severe' || (typeof e.magnitude === 'number' && e.magnitude >= (wl.minMag || 0));
        const regOk = !wl.regions?.length || wl.regions.includes(e.region);
        return sevOk && regOk;
      });
      if (match) hits.push({ viewName: v.name, event: match });
    });
    return hits.slice(0, 5);
  }, [savedViews, events]);

  const handleSelect = useCallback((e) => {
    setSelected(e);
    setSidebarOpen(false);
  }, []);

  // Config bundle for save / export
  const currentConfig = useMemo(() => ({
    activeFeeds,
    filters: { search, minMag, regions, sortBy, sortDir },
    basemap,
    viewport,
    watchlist: { minMag, severityFloor: 'severe', regions },
    spaceCards,
  }), [activeFeeds, search, minMag, regions, sortBy, sortDir, basemap, viewport, spaceCards]);

  const applyConfig = useCallback((cfg) => {
    if (cfg.activeFeeds) setActiveFeeds({ ...DEFAULT_FEEDS(), ...cfg.activeFeeds });
    if (cfg.filters) {
      if (typeof cfg.filters.search === 'string') setSearch(cfg.filters.search);
      if (typeof cfg.filters.minMag === 'number') setMinMag(cfg.filters.minMag);
      if (Array.isArray(cfg.filters.regions)) setRegions(cfg.filters.regions);
      if (cfg.filters.sortBy) setSortBy(cfg.filters.sortBy);
      if (cfg.filters.sortDir) setSortDir(cfg.filters.sortDir);
    }
    if (cfg.basemap) setBasemap(cfg.basemap);
    if (cfg.spaceCards) setSpaceCards((prev) => ({ ...prev, ...cfg.spaceCards }));
  }, []);

  return (
    <>
      <GeoKpiStrip
        events={events}
        lastUpdated={lastUpdated}
        watchlistHits={watchlistHits}
        aircraftCount={aircraft.length}
        milAircraftCount={milAircraft.length}
        civilUnrestCount={events.filter((e) => e.type === 'civilUnrest').length}
        conflictCount={events.filter((e) => e.type === 'conflict').length}
        vesselCount={vessels.length}
        spaceWeatherStorm={sw.stormLevel}
        chokepointCount={activeFeeds.supplyChain ? chokepoints.length : 0}
      />

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Feed controls + stats */}
        <div className="space-y-3 order-2 lg:order-1">
          <div className="glass-panel clip-corner p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-bold text-[#ff6b6b] uppercase tracking-wider flex items-center gap-1.5"><Filter size={12} /> Overlay Layers</div>
              <button onClick={resetFeeds} className="flex items-center gap-1 px-2 py-1 bg-[#161b22] border border-[#30363d] rounded text-[9px] font-bold text-[#8b949e] hover:text-[#ff6b6b] hover:border-[#ff6b6b]/40 transition-colors">
                <RotateCcw size={9} /> Reset
              </button>
            </div>
            <div className="space-y-1.5 max-h-[420px] overflow-y-auto">
              {Object.entries(FEEDS).map(([key, feed]) => (
                <button key={key} onClick={() => toggleFeed(key)}
                  className={`w-full flex items-center justify-between px-2 py-1.5 rounded text-xs transition-colors min-h-[36px] border ${activeFeeds[key] ? '' : 'border-[#30363d] opacity-50'}`}
                  style={activeFeeds[key] ? { background: `${feed.color}15`, borderColor: `${feed.color}50` } : {}}>
                  <span className="flex items-center gap-2"><span>{feed.icon}</span><span className="text-[#e6edf3]">{feed.label}</span></span>
                  <span className="text-[9px] text-[#8b949e]">{feed.kind === 'overlay' ? (activeFeeds[key] ? 'ON' : 'OFF') : (counts[key] || 0)}</span>
                </button>
              ))}
              {/* Aircraft airspace overlay */}
              <button onClick={() => toggleFeed('aircraft')}
                className={`w-full flex items-center justify-between px-2 py-1.5 rounded text-xs transition-colors min-h-[36px] border ${activeFeeds.aircraft ? 'border-[#4dd0e1]/50 bg-[#4dd0e1]/15' : 'border-[#30363d] opacity-50'}`}>
                <span className="flex items-center gap-2"><Plane size={12} className="text-[#4dd0e1]" /><span className="text-[#e6edf3]">Live Aircraft (ADSB)</span></span>
                <span className="text-[9px] text-[#4dd0e1]">{activeFeeds.aircraft ? `${aircraft.length} ✈` : 'OFF'}</span>
              </button>
              {activeFeeds.aircraft && (
                <div className="flex items-center gap-2 px-2 py-1.5 bg-[#0d1117] border border-[#4dd0e1]/20 rounded">
                  <Radio size={10} className="text-[#4dd0e1] shrink-0" />
                  <span className="text-[9px] text-[#8b949e] shrink-0">Radius</span>
                  <input type="range" min="100" max="2000" step="50" value={aircraftRadius}
                    onChange={(e) => setAircraftRadius(+e.target.value)} className="flex-1 accent-[#4dd0e1]" />
                  <span className="text-[9px] text-[#4dd0e1] font-bold w-12 text-right">{aircraftRadius}km</span>
                </div>
              )}
              {/* Supply Chain layer */}
              <button onClick={() => toggleFeed('supplyChain')}
                className={`w-full flex items-center justify-between px-2 py-1.5 rounded text-xs transition-colors min-h-[36px] border ${activeFeeds.supplyChain ? 'border-[#ff9f0a]/50 bg-[#ff9f0a]/15' : 'border-[#30363d] opacity-50'}`}>
                <span className="flex items-center gap-2"><Ship size={12} className="text-[#ff9f0a]" /><span className="text-[#e6edf3]">Supply Chain (WorldMonitor)</span></span>
                <span className="text-[9px] text-[#ff9f0a]">{chokepoints.length}</span>
              </button>
              {/* Military aircraft layer */}
              <button onClick={() => toggleFeed('milAircraft')}
                className={`w-full flex items-center justify-between px-2 py-1.5 rounded text-xs transition-colors min-h-[36px] border ${activeFeeds.milAircraft ? 'border-[#ff9f0a]/50 bg-[#ff9f0a]/15' : 'border-[#30363d] opacity-50'}`}>
                <span className="flex items-center gap-2"><Plane size={12} className="text-[#ff9f0a]" /><span className="text-[#e6edf3]">Military Aircraft (ADSB)</span></span>
                <span className="text-[9px] text-[#ff9f0a]">{activeFeeds.milAircraft ? `${milAircraft.length} ✈` : 'OFF'}</span>
              </button>
              {/* Maritime AIS layer */}
              <button onClick={() => toggleFeed('maritime')}
                className={`w-full flex items-center justify-between px-2 py-1.5 rounded text-xs transition-colors min-h-[36px] border ${activeFeeds.maritime ? 'border-[#4dd0e1]/50 bg-[#4dd0e1]/15' : 'border-[#30363d] opacity-50'}`}>
                <span className="flex items-center gap-2"><Ship size={12} className="text-[#4dd0e1]" /><span className="text-[#e6edf3]">Maritime (AIS)</span></span>
                <span className="text-[9px] text-[#4dd0e1]">{activeFeeds.maritime ? `${vessels.length} ⚓` : 'OFF'}</span>
              </button>
              {/* Air-traffic density layer */}
              <button onClick={() => toggleFeed('density')}
                className={`w-full flex items-center justify-between px-2 py-1.5 rounded text-xs transition-colors min-h-[36px] border ${activeFeeds.density ? 'border-[#ff6b6b]/50 bg-[#ff6b6b]/15' : 'border-[#30363d] opacity-50'}`}>
                <span className="flex items-center gap-2"><Activity size={12} className="text-[#ff6b6b]" /><span className="text-[#e6edf3]">Air-Traffic Density</span></span>
                <span className="text-[9px] text-[#ff6b6b]">{activeFeeds.density ? `${densityPoints.length} cells` : 'OFF'}</span>
              </button>
            </div>
          </div>

          {/* Country brief lookup */}
          <div className="glass-panel clip-corner p-3">
            <div className="text-xs font-bold text-[#ff9f0a] uppercase tracking-wider mb-2 flex items-center gap-1.5"><Ship size={12} /> Country Brief</div>
            <div className="relative mb-2">
              <Search size={11} className="absolute left-2 top-2.5 text-[#484f58]" />
              <input
                value={countryQuery}
                onChange={(e) => setCountryQuery(e.target.value)}
                placeholder="Country name or code (e.g. Japan, JP)..."
                className="w-full bg-[#0d1117] border border-[#30363d] rounded pl-7 pr-2 py-1.5 text-xs text-[#e6edf3] focus:border-[#ff9f0a]/40 focus:outline-none"
              />
            </div>
            {countryBrief && !countryBrief.notFound && (
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-[#e6edf3]">{countryBrief.name}</div>
                <div className="text-[9px] text-[#8b949e] leading-relaxed">{countryBrief.exposure}</div>
                <div className="flex flex-wrap gap-1 mt-1">
                  {countryBrief.nearbyChokepoints?.map((cp) => (
                    <span key={cp.id} className="text-[8px] px-1.5 py-0.5 border border-[#ff9f0a]/30 text-[#ff9f0a] bg-[#ff9f0a]/5 clip-corner">
                      {cp.name}
                    </span>
                  ))}
                </div>
                <div className="flex flex-wrap gap-1 mt-1">
                  {countryBrief.commodities?.map((c) => (
                    <span key={c} className="text-[8px] px-1.5 py-0.5 border border-[#30363d] text-[#8b949e] clip-corner">{c}</span>
                  ))}
                </div>
              </div>
            )}
            {countryBrief?.notFound && (
              <div className="text-[9px] text-[#484f58] italic">No brief for "{countryBrief.query}". Try: US, CN, JP, DE, GB, IN, KR, TW, EG, SA, RU, AU, BR, ZA, TR.</div>
            )}
          </div>

          <div className="glass-panel clip-corner p-3">
            <div className="text-xs font-bold text-[#00f5ff] uppercase tracking-wider mb-2">UM φ-Overlay Pillars</div>
            <div className="space-y-2">
              {PILLAR_OVERLAYS.map((p) => (
                <div key={p.id} className="bg-[#0d1117] border border-[#30363d] rounded p-2">
                  <div className="text-[10px] font-bold" style={{ color: p.color }}>{p.id}</div>
                  <div className="text-[9px] text-[#8b949e]">{p.desc}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="glass-panel clip-corner p-3">
            <div className="flex items-center gap-2 text-[10px] text-[#8b949e]">
              <Activity size={12} className="text-[#30d158] glow-pulse" />
              <span>{loading ? 'Loading feeds...' : `${filteredEvents.length} active events`}</span>
              {activeFeeds.aircraft && <span className="text-[#4dd0e1]">· {aircraftLoading ? '…' : aircraft.length} aircraft</span>}
            </div>
            {lastUpdated && !loading && (
              <div className="text-[9px] text-[#484f58] mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#30d158] glow-pulse" />
                Last sync: {lastUpdated.toLocaleTimeString()} · auto-refresh 60s
              </div>
            )}
            {error && <div className="text-[9px] text-[#ff9f0a] mt-1 flex items-center gap-1"><AlertTriangle size={9} /> {error}</div>}
          </div>
        </div>

        {/* Map + overlay controls */}
        <div className="lg:col-span-3 relative order-1 lg:order-2">
          <div className={`glass-strong clip-corner p-2 relative ${mapClass}`}>
            <GlobeMap
              events={filteredEvents}
              selected={selected}
              onSelect={handleSelect}
              basemap={basemap}
              activeFeeds={activeFeeds}
              heatmapMode={heatmapMode}
              chokepoints={chokepoints}
              showSupplyChain={activeFeeds.supplyChain}
              aircraft={aircraft}
              selectedAircraft={selectedAircraft}
              onAircraftSelect={setSelectedAircraft}
              aircraftTrack={aircraftTrack}
              milAircraft={milAircraft}
              vessels={vessels}
              densityPoints={densityPoints}
              onViewportChange={handleViewportChange}
              mapClass="h-full"
            />

            {/* Right control cluster — vertical stack */}
            <div className="absolute top-4 right-4 z-[400] flex flex-col gap-2 items-end">
              <BasemapSwitcher active={basemap} onChange={setBasemap} />
              <div className="flex flex-col gap-2 items-end">
                <SavedViewsControl currentConfig={currentConfig} onApply={applyConfig} onViewsChange={setSavedViews} />
                <ExportControl
                  events={filteredEvents}
                  supplyChainRecords={activeFeeds.supplyChain ? chokepoints.map((c) => ({ ...c, type: 'chokepoint', title: c.name, coords: c.coords, overlay: null })) : []}
                  configBundle={currentConfig}
                  onImportConfig={applyConfig}
                />
                <button
                  onClick={() => setHeatmapMode((h) => !h)}
                  className={`glass-strong clip-corner px-3 py-2 text-[10px] font-bold tracking-wide flex items-center gap-1.5 transition-all min-h-[36px] ${
                    heatmapMode ? 'text-[#ff6b6b] border border-[#ff6b6b]/40' : 'text-[#8b949e] border border-[#30363d]'
                  }`}>
                  <Flame size={12} /> {heatmapMode ? 'Heat ON' : 'Heat'}
                </button>
              </div>
            </div>

            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden absolute top-4 left-4 z-[400] glass-strong clip-corner px-3 py-2 text-[10px] font-bold text-[#00f5ff] flex items-center gap-1.5 min-h-[36px]">
              <Filter size={12} /> Events
            </button>
          </div>
          {loading && <div className="text-center mt-4 flex items-center justify-center gap-2 text-xs text-[#8b949e]"><Loader size={14} className="animate-spin text-[#00f5ff]" /> Fetching live hazard feeds + computing UM overlay...</div>}
        </div>

        {/* Event sidebar — desktop */}
        <div className={`hidden lg:block lg:col-span-1 ${mapClass}`}>
          <EventSidebar
            events={filteredEvents}
            selected={selected}
            onSelect={handleSelect}
            search={search} setSearch={setSearch}
            minMag={minMag} setMinMag={setMinMag}
            regions={regions} toggleRegion={toggleRegion}
            sortBy={sortBy} setSortBy={setSortBy}
            sortDir={sortDir} setSortDir={setSortDir}
          />
        </div>
      </div>

      {showConsolePanels && (
        <>
          <SpaceDomainConsole
            data={sw.data}
            loading={sw.loading}
            lastUpdated={sw.lastUpdated}
            cards={spaceCards}
            setCards={setSpaceCards}
            onRefresh={sw.refresh}
          />
          <div className="mt-4">
            <GridStressPanel severeWeatherCount={severeWeatherCount} />
          </div>
        </>
      )}

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <>
          <div className="fixed inset-0 z-[900] bg-black/50 backdrop-blur-sm lg:hidden" onClick={() => setSidebarOpen(false)} />
          <div className="fixed left-0 top-0 bottom-0 z-[901] w-80 max-w-[85vw] p-3 lg:hidden">
            <EventSidebar
              events={filteredEvents}
              selected={selected}
              onSelect={handleSelect}
              onClose={() => setSidebarOpen(false)}
              search={search} setSearch={setSearch}
              minMag={minMag} setMinMag={setMinMag}
              regions={regions} toggleRegion={toggleRegion}
              sortBy={sortBy} setSortBy={setSortBy}
              sortDir={sortDir} setSortDir={setSortDir}
            />
          </div>
        </>
      )}

      <EventDetailDrawer event={selected} onClose={() => setSelected(null)} />
      <AircraftDetailDrawer aircraft={selectedAircraft} onClose={() => setSelectedAircraft(null)} />
    </>
  );
}