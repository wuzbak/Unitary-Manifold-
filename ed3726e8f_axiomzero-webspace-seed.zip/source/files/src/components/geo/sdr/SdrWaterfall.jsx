import { useRef, useEffect } from 'react';

/**
 * Canvas waterfall display — animated spectrum with signal peaks at known
 * broadcast frequencies. In data mode, renders synthetic noise floor + peaks.
 * Cyan-to-amber gradient for signal strength. Frequency markers + tuned-freq line.
 *
 * Enhanced:
 *  - Station marker triangles at known station/channel frequencies (cyan).
 *  - Thicker, glowing tuned-frequency line during scanning.
 *  - "● SCANNING" overlay text during sweep.
 */
export default function SdrWaterfall({ band, frequency, stations, mode, scanning }) {
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const linesRef = useRef([]);
  const lastTimeRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const resize = () => {
      const parent = canvas.parentElement;
      const w = parent ? parent.clientWidth : 600;
      canvas.width = w;
      canvas.height = 180;
      linesRef.current = [];
    };
    resize();
    window.addEventListener('resize', resize);

    const bandMin = band.range[0];
    const bandMax = band.range[1];
    const isKHz = band.unit === 'kHz';
    const tunedFreqKHz = isKHz ? frequency : frequency * 1000;

    // Build peak list — station frequencies + band channels
    const peaks = [
      ...stations
        .filter((s) => {
          const sf = isKHz ? s.freq : s.freq / 1000;
          return sf >= bandMin && sf <= bandMax;
        })
        .map((s) => ({ freq: isKHz ? s.freq : s.freq * 1000, power: s.power, label: s.station })),
      ...(band.channels || []).map((c) => ({
        freq: isKHz ? c.freq : c.freq * 1000,
        power: 100,
        label: c.label,
      })),
    ];

    const powerToColor = (power) => {
      const t = Math.min(1, Math.max(0, power / 255));
      if (t < 0.25) {
        const f = t / 0.25;
        return [Math.round(f * 20), Math.round(f * 100), Math.round(f * 150)];
      } else if (t < 0.5) {
        const f = (t - 0.25) / 0.25;
        return [Math.round(f * 50), Math.round(100 + f * 145), Math.round(150 + f * 105)];
      } else if (t < 0.75) {
        const f = (t - 0.5) / 0.25;
        return [Math.round(50 + f * 205), Math.round(245 - f * 86), Math.round(255 - f * 255)];
      }
      const f = (t - 0.75) / 0.25;
      return [255, Math.round(159 + f * 96), Math.round(f * 200)];
    };

    const generateLine = () => {
      const width = canvas.width;
      const line = new Uint8ClampedArray(width * 4);
      const peakWidth = isKHz ? 3 : 0.5;

      for (let x = 0; x < width; x++) {
        const freq = bandMin + (x / width) * (bandMax - bandMin);
        let power = 15 + Math.random() * 20;

        for (const peak of peaks) {
          const dist = Math.abs(freq - peak.freq);
          if (dist < peakWidth * 3) {
            const strength = Math.exp(-(dist * dist) / (2 * peakWidth * peakWidth));
            power += strength * (peak.power / 3 + 60);
          }
        }

        const tunedDist = Math.abs(freq - tunedFreqKHz);
        const tunedWidth = isKHz ? 2 : 0.3;
        if (tunedDist < tunedWidth * 5) {
          const strength = Math.exp(-(tunedDist * tunedDist) / (2 * tunedWidth * tunedWidth));
          power += strength * (100 + Math.random() * 60);
        }

        power = Math.min(255, Math.max(0, power));
        const [r, g, b] = powerToColor(power);
        const idx = x * 4;
        line[idx] = r;
        line[idx + 1] = g;
        line[idx + 2] = b;
        line[idx + 3] = 255;
      }
      return line;
    };

    const draw = (time) => {
      if (time - lastTimeRef.current > 60) {
        lastTimeRef.current = time;
        const width = canvas.width;
        const height = canvas.height;

        linesRef.current.unshift(generateLine());
        if (linesRef.current.length > height) linesRef.current.pop();

        const imageData = ctx.createImageData(width, height);
        for (let y = 0; y < linesRef.current.length && y < height; y++) {
          const line = linesRef.current[y];
          for (let x = 0; x < width; x++) {
            const src = x * 4;
            const dst = (y * width + x) * 4;
            imageData.data[dst] = line[src];
            imageData.data[dst + 1] = line[src + 1];
            imageData.data[dst + 2] = line[src + 2];
            imageData.data[dst + 3] = 255;
          }
        }
        ctx.putImageData(imageData, 0, 0);

        // Station marker triangles at known frequencies
        for (const peak of peaks) {
          const x = ((peak.freq - bandMin) / (bandMax - bandMin)) * width;
          if (x < 0 || x > width) continue;
          const tunedDist = Math.abs(peak.freq - tunedFreqKHz);
          const isNear = tunedDist < (isKHz ? 10 : 0.1);
          ctx.fillStyle = isNear ? 'rgba(255, 159, 0, 0.9)' : 'rgba(0, 245, 255, 0.55)';
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x - 4, 7);
          ctx.lineTo(x + 4, 7);
          ctx.closePath();
          ctx.fill();
        }

        // Frequency markers
        ctx.fillStyle = 'rgba(0, 245, 255, 0.5)';
        ctx.font = '9px JetBrains Mono, monospace';
        for (let i = 0; i <= 5; i++) {
          const x = (i / 5) * width;
          ctx.fillRect(x, 0, 1, height);
          if (i > 0 && i < 5) {
            const f = bandMin + (i / 5) * (bandMax - bandMin);
            const label = isKHz ? `${(f / 1000).toFixed(1)}M` : `${f.toFixed(0)}M`;
            ctx.fillText(label, x + 3, height - 4);
          }
        }

        // Tuned frequency marker — thicker + glowing during scan
        const tx = ((tunedFreqKHz - bandMin) / (bandMax - bandMin)) * width;
        if (scanning) {
          ctx.fillStyle = 'rgba(255, 159, 0, 0.3)';
          ctx.fillRect(tx - 8, 0, 16, height);
          ctx.fillStyle = '#FF9F00';
          ctx.fillRect(tx - 2, 0, 4, height);
        } else {
          ctx.fillStyle = 'rgba(255, 159, 0, 0.2)';
          ctx.fillRect(tx - 5, 0, 10, height);
          ctx.fillStyle = '#FF9F00';
          ctx.fillRect(tx - 1, 0, 2, height);
        }

        // Mode / scan label
        ctx.fillStyle = scanning ? '#00f5ff' : mode === 'live' ? '#3fb950' : '#FF9F00';
        ctx.font = 'bold 9px JetBrains Mono, monospace';
        ctx.fillText(scanning ? '● SCANNING' : mode === 'live' ? '● LIVE' : '● DATA', 6, 12);
      }
      animRef.current = requestAnimationFrame(draw);
    };

    draw(0);
    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', resize);
    };
  }, [band, frequency, stations, mode, scanning]);

  return (
    <div className="glass-panel clip-corner overflow-hidden">
      <div className="flex items-center justify-between px-2 py-1 border-b border-[#00f5ff]/20">
        <span className="text-[9px] text-[#484f58] font-bold tracking-wider">WATERFALL · SPECTRUM</span>
        <span className="text-[9px] text-[#FF9F00] font-mono">
          {frequency.toFixed(band.unit === 'kHz' ? 0 : 3)} {band.unit}
        </span>
      </div>
      <canvas ref={canvasRef} className="w-full block bg-[#0a0d11]" />
    </div>
  );
}