/**
 * WebSDR embed panel — loads public receiver iframe for HF bands.
 * Shows actionable external links for VHF/UHF (no public receivers exist),
 * and a TAP-TO-START prompt on the iframe (browsers block iframe audio
 * until user interaction).
 */
import { Radio, ExternalLink, Headphones, Volume2 } from 'lucide-react';

export default function SdrWebSdrEmbed({ band, receiver, mode }) {
  // ── VHF/UHF: no public WebSDR coverage — route to external services ──
  if (band.type !== 'hf') {
    const isAir = band.id === 'vhf-air';
    const isScanner = ['vhf-hi', 'uhf', 'uhf-hi'].includes(band.id);
    const links = [];
    if (isAir) {
      links.push({ label: 'LiveATC.net', url: 'https://www.liveatc.net/', desc: 'Live air traffic control audio' });
    }
    if (isScanner) {
      links.push({ label: 'Broadcastify', url: 'https://www.broadcastify.com/', desc: 'Live police & fire scanners' });
    }
    links.push({ label: 'RadioReference', url: 'https://www.radioreference.com/db/browse/', desc: 'Frequency database & live feeds' });

    return (
      <div className="glass-panel clip-corner p-4 min-h-[140px] flex flex-col items-center justify-center text-center">
        <div className="text-[9px] text-[#FF9F00] font-bold mb-2 tracking-wider">⚠ NO LIVE RECEIVER</div>
        <div className="text-[10px] text-[#8b949e] leading-relaxed mb-3 max-w-[280px]">
          {band.label} has no public browser-streamable receiver. These bands require physical SDR hardware — listen via external services:
        </div>
        <div className="flex flex-wrap gap-2 justify-center">
          {links.map((l) => (
            <a
              key={l.label}
              href={l.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-2.5 py-1.5 border border-[#00f5ff]/30 bg-[#00f5ff]/5 text-[#00f5ff] text-[9px] font-bold tracking-wider clip-corner hover:bg-[#00f5ff]/15 hover:border-[#00f5ff]/50 transition-colors touch-manipulation"
            >
              <ExternalLink size={10} /> {l.label}
            </a>
          ))}
        </div>
      </div>
    );
  }

  // ── HF band but no receiver selected ──
  if (!receiver) {
    return (
      <div className="glass-panel clip-corner p-4 text-center min-h-[120px] flex flex-col items-center justify-center">
        <div className="text-[9px] text-[#484f58] mb-1 tracking-wider">WEBSDR EMBED</div>
        <div className="text-[10px] text-[#8b949e]">
          Select a receiver from the directory to stream live audio.
        </div>
      </div>
    );
  }

  // ── HF band with receiver — show iframe + tap-to-start prompt ──
  return (
    <div className="glass-panel clip-corner overflow-hidden">
      <div className="flex items-center justify-between px-2 py-1.5 border-b border-[#00f5ff]/20">
        <span className="text-[9px] text-[#3fb950] font-bold flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] glow-pulse" /> LIVE: {receiver.name}
        </span>
        <a href={receiver.url} target="_blank" rel="noopener noreferrer" className="text-[9px] text-[#00f5ff] hover:text-[#00f5ff]/80 flex items-center gap-1">
          Open <ExternalLink size={10} />
        </a>
      </div>
      {/* Tap-to-start prompt — browsers block iframe audio until user interaction */}
      <div className="px-2 py-1.5 text-[9px] text-[#FF9F00] bg-[#FF9F00]/10 border-b border-[#FF9F00]/20 flex items-center gap-1.5">
        <Headphones size={11} className="shrink-0" />
        <span className="font-bold tracking-wider">TAP "START" INSIDE THE RECEIVER TO HEAR AUDIO</span>
      </div>
      <iframe
        src={receiver.url}
        className="w-full h-[250px] bg-[#0a0d11] border-0"
        sandbox="allow-scripts allow-same-origin allow-forms"
        title={receiver.name}
      />
      {!receiver.https && (
        <div className="px-2 py-1 text-[8px] text-[#fbbf24] bg-[#fbbf24]/10 border-t border-[#fbbf24]/20">
          ⚠ HTTP receiver — may be blocked on HTTPS sites. Use "Open →" if embed is blank.
        </div>
      )}
      <div className="px-2 py-1 text-[8px] text-[#484f58] bg-[#0a0d11] border-t border-[#30363d] flex items-center gap-1">
        <Volume2 size={9} /> Audio volume controlled within the WebSDR embed above — use its internal slider.
      </div>
    </div>
  );
}