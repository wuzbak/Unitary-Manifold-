import { useState, useEffect, useRef } from 'react';
import { Radio, Volume2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { SDR_BANDS, SW_STATIONS, findStationAt } from '@/lib/geo/sdrBands';
import { SDR_RECEIVERS } from '@/lib/geo/sdrReceivers';
import SdrBandSelector from './SdrBandSelector';
import SdrTuningDial from './SdrTuningDial';
import SdrVuMeters from './SdrVuMeters';
import SdrWaterfall from './SdrWaterfall';
import SdrSchedulePanel from './SdrSchedulePanel';
import SdrWebSdrEmbed from './SdrWebSdrEmbed';
import SdrFeedPanel from './SdrFeedPanel';
import SdrAutoScanner from './SdrAutoScanner';
import SdrUnifiedPlayer from './SdrUnifiedPlayer';
import SdrStationDirectory from './SdrStationDirectory';
import SdrNewsStrip from './SdrNewsStrip';

/**
 * All-Band SDR Radio Console — Next Gen unified UI/UX.
 *
 * Single audio player (SdrUnifiedPlayer) + single tabbed station directory
 * (SdrStationDirectory) replace the former 3 players + 4 scattered lists.
 *
 * Two mutually-exclusive listening modes:
 *   1. HF Receiver — WebSDR iframe embed (remote receiver, controlled by dial)
 *   2. Direct Stream — unified audio player (BBC, VOA, NASA, NPR, scanners…)
 *
 * Tactical-HUD aesthetic: glass-strong, clip-corner, scanline, corner brackets.
 */
export default function SdrRadioConsole({ onAnalyze }) {
  const [band, setBand] = useState(SDR_BANDS[2]); // Shortwave
  const [frequency, setFrequency] = useState(14200); // kHz
  const [receiver, setReceiver] = useState(null);
  const [activeStation, setActiveStation] = useState(null);
  const [volume, setVolume] = useState(0.7);
  const [scanning, setScanning] = useState(false);
  const [detected, setDetected] = useState([]);
  const [feedData, setFeedData] = useState(null);
  const [feedLoading, setFeedLoading] = useState(true);
  const scanRef = useRef(null);

  useEffect(() => {
    base44.functions
      .invoke('sdrRadioFeed', {})
      .then((res) => {
        setFeedData(res.data);
        setFeedLoading(false);
      })
      .catch(() => setFeedLoading(false));
  }, []);

  useEffect(() => {
    return () => {
      if (scanRef.current) clearInterval(scanRef.current);
    };
  }, []);

  useEffect(() => {
    if (scanRef.current) clearInterval(scanRef.current);
    setScanning(false);
    setDetected([]);
  }, [band.id]);

  const defaultHttpsReceiver = SDR_RECEIVERS.find((r) => r.https) || null;

  const handleBandChange = (newBand) => {
    setBand(newBand);
    const mid = Math.round((newBand.range[0] + newBand.range[1]) / 2);
    setFrequency(mid);
    setActiveStation(null);
    if (newBand.type === 'hf') {
      // Auto-connect default HTTPS receiver for HF bands — instant audio path
      setReceiver((prev) => prev || defaultHttpsReceiver);
    } else {
      setReceiver(null);
    }
  };

  // Tune to a shortwave station — also auto-connects a receiver if on HF band
  const handleTuneStation = (freq) => {
    setFrequency(freq);
    if (band.type === 'hf') {
      setReceiver((prev) => prev || defaultHttpsReceiver);
    }
  };

  // Direct-stream selection — clears receiver (mutually exclusive)
  const handleSelectStation = (station) => {
    setReceiver(null);
    setActiveStation((prev) => (prev?.id === station.id ? null : station));
  };

  // Receiver selection — clears direct stream (mutually exclusive)
  const handleConnectReceiver = (r) => {
    setActiveStation(null);
    setReceiver((prev) => (prev?.id === r.id ? null : r));
  };

  // ── Auto-scan: sweep band, detect stations ──
  const startScan = () => {
    setDetected([]);
    setScanning(true);
    const [min, max] = band.range;
    const steps = 250;
    const stepSize = (max - min) / steps;
    let current = min;

    scanRef.current = setInterval(() => {
      current += stepSize;
      if (current >= max) {
        clearInterval(scanRef.current);
        setScanning(false);
        return;
      }
      const rounded =
        band.unit === 'kHz'
          ? Math.round(current)
          : Math.round(current * 100) / 100;
      setFrequency(rounded);

      const found = findStationAt(band, rounded);
      if (found) {
        setDetected((prev) => {
          if (prev.find((d) => d.freq === found.freq && d.station === found.station))
            return prev;
          return [...prev, found];
        });
      }
    }, 35);
  };

  const stopScan = () => {
    if (scanRef.current) clearInterval(scanRef.current);
    setScanning(false);
  };

  const clearDetected = () => setDetected([]);

  // Signal boost for VU meters — based on proximity to known stations
  const currentStation = findStationAt(band, frequency);
  const signalBoost = currentStation
    ? Math.min(80, (currentStation.power || 100) / 4)
    : 0;
  const mode = receiver ? 'live' : 'data';

  const nasaNews =
    feedData?.headlines?.filter((h) => h.feedCategory === 'nasa') || [];
  const nprNews =
    feedData?.headlines?.filter((h) => h.feedCategory === 'npr') || [];
  const nprAudioUrl = feedData?.headlines?.find(
    (h) => h.feedCategory === 'npr-audio' && h.audioUrl,
  )?.audioUrl;

  return (
    <div className="glass-strong clip-corner p-3 lg:p-4 mt-4 tactical-hud hud-scanline">
      {/* Header */}
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Radio size={16} className="text-[#00f5ff] shrink-0" />
          <span className="text-xs font-bold text-[#e6edf3] tracking-wider whitespace-nowrap">
            ALL-BAND SDR CONSOLE
          </span>
          <span className="text-[8px] text-[#484f58] hidden sm:inline">|</span>
          <span className="text-[9px] text-[#8b949e] truncate hidden sm:inline">
            {band.label} · {band.description}
          </span>
        </div>
        <span
          className={`text-[9px] px-2 py-0.5 border clip-corner font-bold shrink-0 ${
            scanning
              ? 'text-[#00f5ff] border-[#00f5ff]/40 bg-[#00f5ff]/10 animate-pulse'
              : receiver
                ? 'text-[#3fb950] border-[#3fb950]/40 bg-[#3fb950]/10'
                : activeStation
                  ? 'text-[#FF9F00] border-[#FF9F00]/40 bg-[#FF9F00]/10'
                  : 'text-[#484f58] border-[#30363d]'
          }`}
        >
          {scanning
            ? '◉ SCANNING'
            : receiver
              ? '● LIVE RX'
              : activeStation
                ? '● STREAMING'
                : '○ STANDBY'}
        </span>
      </div>

      {/* Master volume control */}
      <div className="flex items-center gap-2 mb-1">
        <Volume2 size={13} className="text-[#00f5ff] shrink-0" />
        <span className="text-[9px] text-[#484f58] font-bold tracking-wider shrink-0">
          VOL
        </span>
        <input
          type="range"
          min="0"
          max="1"
          step="0.01"
          value={volume}
          onChange={(e) => setVolume(parseFloat(e.target.value))}
          className="flex-1 h-1.5 accent-[#00f5ff] max-w-[200px]"
          aria-label="Radio volume"
        />
        <span className="text-[9px] text-[#00f5ff] font-bold font-mono shrink-0 w-8">
          {Math.round(volume * 100)}%
        </span>
      </div>

      {/* Band selector */}
      <SdrBandSelector band={band} onBandChange={handleBandChange} />

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 mt-3">
        {/* Left: Tuning dial + VU meters + Auto-scanner */}
        <div className="lg:col-span-3 space-y-3">
          <SdrTuningDial
            band={band}
            frequency={frequency}
            onFrequencyChange={setFrequency}
            scanning={scanning}
          />
          <SdrVuMeters mode={mode} signalBoost={signalBoost} />
          <SdrAutoScanner
            band={band}
            frequency={frequency}
            onFrequencyChange={setFrequency}
            scanning={scanning}
            onScanStart={startScan}
            onScanStop={stopScan}
            detected={detected}
            onClearDetected={clearDetected}
          />
        </div>

        {/* Center: Waterfall + Schedule + WebSDR embed */}
        <div className="lg:col-span-6 space-y-3">
          <SdrWaterfall
            band={band}
            frequency={frequency}
            stations={SW_STATIONS}
            mode={mode}
            scanning={scanning}
          />
          <SdrSchedulePanel band={band} frequency={frequency} stations={SW_STATIONS} />
          <SdrWebSdrEmbed band={band} receiver={receiver} mode={mode} />
        </div>

        {/* Right: Unified station directory (all stations in one tabbed panel) */}
        <div className="lg:col-span-3">
          <SdrStationDirectory
            band={band}
            frequency={frequency}
            onTuneStation={handleTuneStation}
            activeStationId={activeStation?.id}
            onPlayStation={handleSelectStation}
            receiver={receiver}
            onConnectReceiver={handleConnectReceiver}
            nprAudioUrl={nprAudioUrl}
          />
        </div>
      </div>

      {/* Unified audio player — shows when a direct stream is selected */}
      <SdrUnifiedPlayer
        station={activeStation}
        volume={volume}
        onStop={() => setActiveStation(null)}
      />

      {/* NASA + NPR news strip */}
      <SdrNewsStrip news={nasaNews} nprNews={nprNews} onAnalyze={onAnalyze} />

      {/* SDR software & community feeds */}
      <SdrFeedPanel feedData={feedData} loading={feedLoading} onAnalyze={onAnalyze} />
    </div>
  );
}