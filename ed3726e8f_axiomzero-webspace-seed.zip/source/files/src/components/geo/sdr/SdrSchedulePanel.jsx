import { SW_STATIONS } from '@/lib/geo/sdrBands';

/** Station identification card — matches tuned frequency against SW_STATIONS or band channels. */
export default function SdrSchedulePanel({ band, frequency, stations }) {
  const freqKHz = band.unit === 'kHz' ? frequency : frequency * 1000;

  // VHF/UHF — show channel assignments
  if (band.type !== 'hf' && band.channels) {
    const matched = band.channels.find((c) => Math.abs(c.freq - frequency) < 0.5);
    return (
      <div className="glass-panel clip-corner p-2.5">
        <div className="text-[9px] text-[#484f58] mb-1 font-bold tracking-wider">CHANNEL ASSIGNMENT</div>
        {matched ? (
          <div>
            <div className="text-xs font-bold text-[#FF9F00]">{matched.label}</div>
            <div className="text-[10px] text-[#8b949e] mt-0.5">{matched.freq} {band.unit}</div>
          </div>
        ) : (
          <div className="text-[10px] text-[#8b949e]">
            No channel at this frequency. Nearby channels:
            <div className="flex flex-wrap gap-1 mt-1">
              {band.channels.slice(0, 3).map((c, i) => (
                <span key={i} className="text-[8px] text-[#484f58] px-1.5 py-0.5 border border-[#30363d] clip-corner">{c.label}</span>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // HF — match shortwave stations
  const matched = stations.find((s) => Math.abs(s.freq - freqKHz) < 5);

  return (
    <div className="glass-panel clip-corner p-2.5">
      <div className="text-[9px] text-[#484f58] mb-1 font-bold tracking-wider">STATION IDENTIFICATION</div>
      {matched ? (
        <div>
          <div className="text-xs font-bold text-[#FF9F00]">{matched.station}</div>
          <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1 text-[9px] text-[#8b949e]">
            <span>📍 {matched.country}</span>
            <span>🗣 {matched.language}</span>
            <span>⚡ {matched.power} kW</span>
            <span>📡 {matched.band}</span>
          </div>
        </div>
      ) : (
        <div className="text-[10px] text-[#8b949e]">No active broadcast — possible static or utility signal.</div>
      )}
    </div>
  );
}