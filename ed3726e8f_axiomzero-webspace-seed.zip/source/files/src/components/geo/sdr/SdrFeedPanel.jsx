import { useState } from 'react';
import { ExternalLink, Sparkles } from 'lucide-react';

/** Tabbed card grid for SDR software releases, community blogs, audio archive, and NASA feeds. */
const TABS = [
  { id: 'software', label: 'Software Releases' },
  { id: 'community', label: 'Community Blogs' },
  { id: 'archive', label: 'Audio Archive' },
  { id: 'nasa', label: 'NASA Feeds' },
  { id: 'npr', label: 'NPR News' },
];

export default function SdrFeedPanel({ feedData, loading, onAnalyze }) {
  const [activeTab, setActiveTab] = useState('software');
  const headlines = feedData?.headlines?.filter((h) => h.feedCategory === activeTab) || [];

  return (
    <div className="mt-3">
      <div className="flex gap-1 overflow-x-auto pb-1 -mx-1 px-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`px-3 py-1.5 text-[10px] font-bold tracking-wider whitespace-nowrap clip-corner transition-colors shrink-0 min-h-[36px] ${
              activeTab === t.id
                ? 'bg-[#FF9F00]/20 text-[#FF9F00] border border-[#FF9F00]/40'
                : 'glass-panel text-[#8b949e] border border-[#00f5ff]/20 hover:text-[#00f5ff]'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 mt-2">
        {loading ? (
          <div className="col-span-full text-center py-8 text-[#484f58] text-xs">Loading SDR feeds…</div>
        ) : headlines.length === 0 ? (
          <div className="col-span-full text-center py-8 text-[#484f58] text-xs">No items in this category.</div>
        ) : (
          headlines.slice(0, 12).map((item, i) => (
            <div key={i} className="glass-panel clip-corner p-2.5 hover:border-[#00f5ff]/30 transition-colors">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[9px] text-[#00f5ff] font-bold">{item.outlet}</span>
                <span className="text-[8px] text-[#484f58]">{item.published?.slice(0, 10)}</span>
              </div>
              <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-[11px] text-[#e6edf3] font-bold hover:text-[#00f5ff] block mb-1 line-clamp-2">
                {item.title}
              </a>
              {item.description && <p className="text-[9px] text-[#8b949e] leading-relaxed mb-2 line-clamp-2">{item.description}</p>}
              <div className="flex items-center gap-2">
                <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-[8px] text-[#00f5ff] hover:text-[#00f5ff]/80 font-bold flex items-center gap-0.5">
                  <ExternalLink size={9} /> Open
                </a>
                {onAnalyze && (
                  <button
                    onClick={() => onAnalyze(`Analyze this SDR feed item: "${item.title}" from ${item.outlet}. ${item.description || ''}`)}
                    className="text-[8px] text-[#FF9F00] hover:text-[#FF9F00]/80 font-bold flex items-center gap-0.5"
                  >
                    <Sparkles size={9} /> Merlin
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}