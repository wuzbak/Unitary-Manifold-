/**
 * SdrUnifiedPlayer — single audio player bar for all direct-stream stations.
 *
 * Replaces the 3 separate players (SdrNasaStream, SdrLiveStations, WebSDR audio).
 * Uses one useAudioStream hook + one <audio> element — no audio conflicts.
 * Shows play/pause, station info, loading/error state, volume, external link, stop.
 * Hidden when no station is selected.
 */
import { Play, Pause, ExternalLink, Volume2, AlertTriangle, Loader2, X } from 'lucide-react';
import { useAudioStream } from '@/hooks/useAudioStream';

export default function SdrUnifiedPlayer({ station, volume, onStop }) {
  const { audioRef, playing, error, loading, togglePlay } = useAudioStream(
    station?.streamUrl,
    volume,
    true,
  );

  if (!station) return null;

  return (
    <div className="glass-panel clip-corner p-3 mt-3 tactical-hud border-[#FF9F00]/30">
      <div className="flex items-center gap-3">
        <button
          onClick={togglePlay}
          className="flex items-center justify-center w-10 h-10 bg-[#FF9F00]/10 border border-[#FF9F00]/30 text-[#FF9F00] clip-corner hover:bg-[#FF9F00]/20 transition-colors shrink-0 touch-manipulation"
          aria-label={playing ? 'Pause' : 'Play'}
        >
          {loading ? (
            <Loader2 size={16} className="animate-spin" />
          ) : playing ? (
            <Pause size={16} />
          ) : (
            <Play size={16} />
          )}
        </button>

        <div className="flex-1 min-w-0">
          <div className="text-[11px] font-bold text-[#e6edf3] truncate">
            {station.flag} {station.name}
          </div>
          <div className="text-[9px] text-[#8b949e] truncate">
            {loading ? 'Buffering…' : station.description}
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {playing && (
            <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] glow-pulse" />
          )}
          <span className="text-[8px] text-[#484f58] flex items-center gap-1">
            <Volume2 size={10} /> {Math.round(volume * 100)}%
          </span>
          {station.streamUrl && (
            <a
              href={station.streamUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#484f58] hover:text-[#00f5ff] transition-colors"
              title="Open stream externally"
            >
              <ExternalLink size={13} />
            </a>
          )}
          <button
            onClick={onStop}
            className="text-[#484f58] hover:text-[#ff3b30] transition-colors"
            aria-label="Stop and close player"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-1.5 mt-2 text-[8px] text-[#fbbf24]">
          <AlertTriangle size={11} className="shrink-0" />
          Stream blocked (mixed-content or offline). Use the external link → to open
          directly.
        </div>
      )}

      <audio ref={audioRef} preload="none" />
    </div>
  );
}