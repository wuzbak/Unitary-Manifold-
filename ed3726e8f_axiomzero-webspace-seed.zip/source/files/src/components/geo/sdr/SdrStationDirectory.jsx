/**
 * SdrStationDirectory — unified tabbed station directory.
 *
 * Consolidates 4 separate lists into one panel:
 *   Shortwave   — band-specific stations (click to tune frequency)
 *   Live Global — BBC, VOA, DW, RFI, NATO, police scanners (click to play)
 *   Space Radio — NASA Third Rock, SomaFM Mission Control, NPR News Now (click to play)
 *   Receivers   — public WebSDR receivers (click to connect iframe)
 *
 * Direct-stream stations are mutually exclusive with receiver mode — selecting
 * a stream clears the receiver and vice versa (handled by parent callbacks).
 */
import { useState, useMemo, useEffect } from 'react';
import {
  Radio,
  Globe,
  Satellite,
  RadioTower,
  Search,
  Play,
  Pause,
  ExternalLink,
} from 'lucide-react';
import { getBandStations } from '@/lib/geo/sdrBands';
import {
  LIVE_STATIONS,
  STATION_CATEGORIES,
  getStationsByCategory,
} from '@/lib/geo/liveStations';
import { SDR_RECEIVERS } from '@/lib/geo/sdrReceivers';

const SPACE_STATIONS = [
  {
    id: 'nasa',
    name: 'NASA Third Rock Radio',
    streamUrl: 'https://rfcm.streamguys1.com/thirdrock-icy',
    format: 'mp3',
    description: 'Rock, alt-indie, space updates',
    flag: '🚀',
    country: 'USA',
  },
  {
    id: 'soma',
    name: 'SomaFM Mission Control',
    streamUrl: 'https://ice1.somafm.com/missioncontrol-128-mp3',
    format: 'mp3',
    description: 'Ambient spaceflight comms',
    flag: '🛰️',
    country: 'USA',
  },
  {
    id: 'npr',
    name: 'NPR News Now',
    streamUrl: null,
    format: 'mp3',
    description: 'Hourly 5-min global briefing',
    flag: '📻',
    country: 'USA',
    isPodcast: true,
  },
];

const TABS = [
  { id: 'shortwave', label: 'Shortwave', icon: Radio },
  { id: 'live', label: 'Live Global', icon: Globe },
  { id: 'space', label: 'Space Radio', icon: Satellite },
  { id: 'receivers', label: 'Receivers', icon: RadioTower },
];

function signalBars(power) {
  return Math.max(1, Math.min(5, Math.ceil((power || 100) / 60)));
}

export default function SdrStationDirectory({
  band,
  frequency,
  onTuneStation,
  activeStationId,
  onPlayStation,
  receiver,
  onConnectReceiver,
  nprAudioUrl,
}) {
  const [tab, setTab] = useState('shortwave');
  const [search, setSearch] = useState('');
  const [receiverStatuses, setReceiverStatuses] = useState({});

  const bandStations = useMemo(() => getBandStations(band), [band]);
  const freqKHz = band.unit === 'kHz' ? frequency : frequency * 1000;

  const filteredShortwave = useMemo(() => {
    if (!search.trim()) return bandStations;
    const q = search.toLowerCase();
    return bandStations.filter(
      (s) =>
        s.station?.toLowerCase().includes(q) ||
        s.country?.toLowerCase().includes(q) ||
        String(s.freq).includes(q),
    );
  }, [bandStations, search]);

  const spaceStations = SPACE_STATIONS.map((s) =>
    s.id === 'npr' ? { ...s, streamUrl: nprAudioUrl } : s,
  );

  useEffect(() => {
    const checks = {};
    SDR_RECEIVERS.forEach((r) => {
      checks[r.id] = r.https ? 'online' : 'unknown';
    });
    setReceiverStatuses(checks);
  }, []);

  const handleLiveClick = (station) => {
    if (station.isRss || station.isExternal) {
      if (station.feedUrl)
        window.open(station.feedUrl, '_blank', 'noopener,noreferrer');
      return;
    }
    onPlayStation(station);
  };

  return (
    <div className="glass-panel clip-corner p-2.5 tactical-hud">
      {/* Tabs */}
      <div className="flex gap-1 mb-2">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-1 px-2 py-1.5 text-[9px] font-bold tracking-wider clip-corner transition-colors shrink-0 touch-manipulation ${
              tab === t.id
                ? 'bg-[#00f5ff]/15 text-[#00f5ff] border border-[#00f5ff]/40'
                : 'text-[#484f58] border border-[#30363d] hover:text-[#8b949e] hover:border-[#00f5ff]/20'
            }`}
          >
            <t.icon size={10} /> {t.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="max-h-[350px] overflow-y-auto">
        {/* ── Shortwave ── */}
        {tab === 'shortwave' && (
          <div>
            <div className="relative mb-2">
              <Search
                size={11}
                className="absolute left-2 top-1/2 -translate-y-1/2 text-[#484f58]"
              />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search name, country, freq…"
                className="w-full bg-[#0a0d11] border border-[#00f5ff]/20 text-[10px] text-[#e6edf3] pl-7 pr-2 py-1.5 clip-corner focus:outline-none focus:border-[#00f5ff]/40 font-mono placeholder:text-[#484f58]"
              />
            </div>
            <div className="text-[8px] text-[#484f58] mb-1.5">
              {filteredShortwave.length}/{bandStations.length} stations · click to tune
            </div>
            <div className="space-y-1">
              {filteredShortwave.length === 0 ? (
                <div className="text-[9px] text-[#484f58] text-center py-3">
                  {bandStations.length === 0
                    ? 'No known stations in this band.'
                    : 'No matches — try a different search.'}
                </div>
              ) : (
                filteredShortwave.map((s, i) => {
                  const sFreqKHz = s.unit === 'MHz' ? s.freq * 1000 : s.freq;
                  const isTuned =
                    Math.abs(sFreqKHz - freqKHz) < (band.unit === 'kHz' ? 5 : 0.05);
                  const bars = signalBars(s.power);
                  return (
                    <button
                      key={`${s.freq}-${i}`}
                      onClick={() => onTuneStation(s.freq)}
                      className={`w-full text-left p-1.5 clip-corner border transition-all touch-manipulation ${
                        isTuned
                          ? 'border-[#FF9F00]/50 bg-[#FF9F00]/10'
                          : 'border-[#30363d] bg-[#0d1117] hover:border-[#00f5ff]/40 hover:bg-[#00f5ff]/5'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span
                          className={`text-[10px] font-bold truncate ${
                            isTuned ? 'text-[#FF9F00]' : 'text-[#e6edf3]'
                          }`}
                        >
                          {s.station}
                        </span>
                        <span className="text-[9px] text-[#00f5ff] font-mono shrink-0">
                          {s.freq} {s.unit || band.unit}
                        </span>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-[8px] text-[#484f58] truncate">
                          {s.country ? s.country : 'Channel'}
                          {s.band ? ` · ${s.band}` : ''}
                          {s.language ? ` · ${s.language}` : ''}
                        </span>
                        <div className="flex items-center gap-0.5 shrink-0">
                          {Array.from({ length: 5 }).map((_, j) => (
                            <span
                              key={j}
                              className="w-1 h-2"
                              style={{
                                background:
                                  j < bars
                                    ? j < 3
                                      ? '#4dd0e1'
                                      : '#FF9F00'
                                    : '#30363d',
                              }}
                            />
                          ))}
                        </div>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* ── Live Global ── */}
        {tab === 'live' && (
          <div className="space-y-3">
            {Object.values(STATION_CATEGORIES).map((cat) => {
              const stations = getStationsByCategory(cat.id);
              if (!stations.length) return null;
              return (
                <div key={cat.id}>
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <span
                      className="w-1.5 h-1.5 rounded-full shrink-0"
                      style={{ background: cat.color }}
                    />
                    <span
                      className="text-[9px] font-bold tracking-wider"
                      style={{ color: cat.color }}
                    >
                      {cat.label}
                    </span>
                  </div>
                  <div className="space-y-1">
                    {stations.map((station) => {
                      const isActive = activeStationId === station.id;
                      const isPlayable =
                        !station.isRss && !station.isExternal && station.streamUrl;
                      return (
                        <button
                          key={station.id}
                          onClick={() => handleLiveClick(station)}
                          className={`w-full flex items-start gap-2 p-1.5 border clip-corner text-left transition-all touch-manipulation ${
                            isActive
                              ? 'border-[#FF9F00]/50 bg-[#FF9F00]/10'
                              : 'border-[#30363d] bg-[#0d1117] hover:border-[#00f5ff]/30'
                          }`}
                          style={
                            isActive ? {} : { borderLeft: `2px solid ${cat.color}40` }
                          }
                        >
                          <span className="text-base shrink-0 leading-none mt-0.5">
                            {station.flag}
                          </span>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1 mb-0.5">
                              <span
                                className={`text-[9px] font-bold truncate ${
                                  isActive ? 'text-[#FF9F00]' : 'text-[#e6edf3]'
                                }`}
                              >
                                {station.name}
                              </span>
                              {isActive && (
                                <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] glow-pulse shrink-0" />
                              )}
                            </div>
                            <div className="text-[8px] text-[#8b949e] line-clamp-1 leading-tight">
                              {station.description}
                            </div>
                          </div>
                          {isPlayable && (
                            <span className="shrink-0 mt-0.5">
                              {isActive ? (
                                <Pause size={11} className="text-[#FF9F00]" />
                              ) : (
                                <Play size={11} className="text-[#484f58]" />
                              )}
                            </span>
                          )}
                          {(station.isRss || station.isExternal) && (
                            <ExternalLink
                              size={10}
                              className="text-[#484f58] shrink-0 mt-0.5"
                            />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ── Space Radio ── */}
        {tab === 'space' && (
          <div className="space-y-1">
            <div className="text-[8px] text-[#484f58] mb-1.5">
              Space &amp; public radio — click to play
            </div>
            {spaceStations.map((station) => {
              const isActive = activeStationId === station.id;
              const isDisabled = station.isPodcast && !station.streamUrl;
              return (
                <button
                  key={station.id}
                  onClick={() => !isDisabled && onPlayStation(station)}
                  disabled={isDisabled}
                  className={`w-full flex items-start gap-2 p-1.5 border clip-corner text-left transition-all touch-manipulation disabled:opacity-40 disabled:cursor-not-allowed ${
                    isActive
                      ? 'border-[#FF9F00]/50 bg-[#FF9F00]/10'
                      : 'border-[#30363d] bg-[#0d1117] hover:border-[#00f5ff]/30'
                  }`}
                >
                  <span className="text-base shrink-0 leading-none mt-0.5">
                    {station.flag}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1 mb-0.5">
                      <span
                        className={`text-[9px] font-bold truncate ${
                          isActive ? 'text-[#FF9F00]' : 'text-[#e6edf3]'
                        }`}
                      >
                        {station.name}
                      </span>
                      {isActive && (
                        <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] glow-pulse shrink-0" />
                      )}
                    </div>
                    <div className="text-[8px] text-[#8b949e] line-clamp-1 leading-tight">
                      {station.isPodcast && !station.streamUrl
                        ? 'Loading podcast…'
                        : station.description}
                    </div>
                  </div>
                  <span className="shrink-0 mt-0.5">
                    {isActive ? (
                      <Pause size={11} className="text-[#FF9F00]" />
                    ) : (
                      <Play size={11} className="text-[#484f58]" />
                    )}
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {/* ── Receivers ── */}
        {tab === 'receivers' && (
          <div className="space-y-1">
            <div className="text-[8px] text-[#484f58] mb-1.5">
              WebSDR receivers — click to connect
            </div>
            {SDR_RECEIVERS.map((r) => {
              const isSelected = receiver?.id === r.id;
              const status = receiverStatuses[r.id];
              return (
                <button
                  key={r.id}
                  onClick={() => onConnectReceiver(r)}
                  className={`w-full text-left p-1.5 clip-corner border transition-colors touch-manipulation ${
                    isSelected
                      ? 'border-[#FF9F00]/40 bg-[#FF9F00]/10'
                      : 'border-[#00f5ff]/20 hover:border-[#00f5ff]/40 hover:bg-[#00f5ff]/5'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span
                        className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                          status === 'online'
                            ? 'bg-[#3fb950] glow-pulse'
                            : status === 'unknown'
                              ? 'bg-[#fbbf24]'
                              : 'bg-[#ff3b30]'
                        }`}
                      />
                      <span className="text-[10px] font-bold text-[#e6edf3] truncate">
                        {r.name}
                      </span>
                    </div>
                    {r.https && (
                      <span className="text-[7px] text-[#3fb950] shrink-0">HTTPS</span>
                    )}
                  </div>
                  <div className="text-[8px] text-[#484f58] mt-0.5">
                    📍 {r.location} · 📡 {r.range}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}