/**
 * SdrNewsStrip — compact NASA + NPR news headline strip.
 *
 * Replaces the news ticker section from the old SdrNasaStream panel.
 * Shows the latest 5 headlines with source labels and an "Analyze with Merlin" button.
 */
import { Newspaper, Sparkles } from 'lucide-react';

export default function SdrNewsStrip({ news, nprNews, onAnalyze }) {
  const allNews = [...(nprNews || []), ...(news || [])];
  if (!allNews.length) return null;

  return (
    <div className="glass-panel clip-corner p-2.5 mt-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <Newspaper size={12} className="text-[#00f5ff]" />
          <span className="text-[9px] font-bold text-[#484f58] tracking-wider">
            NASA + NPR NEWS
          </span>
        </div>
        {onAnalyze && (
          <button
            onClick={() =>
              onAnalyze(
                `Analyze the latest news: "${allNews[0].title}" from ${allNews[0].outlet}. ${allNews[0].description || ''}`,
              )
            }
            className="text-[8px] text-[#FF9F00] hover:text-[#FF9F00]/80 font-bold flex items-center gap-1"
          >
            <Sparkles size={9} /> Analyze
          </button>
        )}
      </div>
      <div className="space-y-1 max-h-[80px] overflow-y-auto">
        {allNews.slice(0, 5).map((item, i) => (
          <div key={i} className="flex items-start gap-1.5">
            <span
              className={`text-[8px] font-bold shrink-0 mt-0.5 ${
                item.feedCategory === 'npr' ? 'text-[#FF9F00]' : 'text-[#00f5ff]'
              }`}
            >
              {item.outlet}
            </span>
            <a
              href={item.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[9px] text-[#8b949e] hover:text-[#00f5ff] line-clamp-1"
            >
              {item.title}
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}