/**
 * SdrAutoScanner — Next Gen auto-tuning & station-finding console.
 *
 * Features:
 *  - SCAN: sweeps the entire band, detecting known stations/channels in real-time.
 *    The waterfall + tuning dial follow the scan; detected stations appear in a
 *    live results list with signal-strength bars and click-to-tune.
 *  - AUTO-TUNE: one-tap jump to the strongest station in the band.
 *  - PREV / NEXT: step to the previous or next known station from the current
 *    frequency — precision station-hopping without a full sweep.
 *  - CLEAR: reset the detected-stations list.
 *
 * Tactical-HUD aesthetic: glass-panel, clip-corner, corner brackets, monospace.
 */
import { Radar, Square, Zap, ChevronLeft, ChevronRight, Signal, Trash2, RadioTower } from 'lucide-react';
import { getBandStations } from '@/lib/geo/sdrBands';

/** Signal strength 0–100 → 1–5 bars. */
function signalBars(power) {
  return Math.max(1, Math.min(5, Math.ceil((power || 100) / 60)));
}

export default function SdrAutoScanner({
  band,
  frequency,
  onFrequencyChange,
  scanning,
  onScanStart,
  onScanStop,
  detected,
  onClearDetected,
}) {
  const bandStations = getBandStations(band);

  const autoTune = () => {
    if (!bandStations.length) return;
    const strongest = [...bandStations].sort((a, b) => (b.power || 100) - (a.power || 100))[0];
    onScanStop();
    onFrequencyChange(strongest.freq);
  };

  const tuneNext = (direction) => {
    const freqKHz = band.unit === 'kHz' ? frequency : frequency * 1000;
    const candidates = bandStations
      .map((s) => ({ ...s, freqKHz: s.unit === 'MHz' ? s.freq * 1000 : s.freq }))
      .filter((s) => (direction > 0 ? s.freqKHz > freqKHz + 1 : s.freqKHz < freqKHz - 1))
      .sort((a, b) => (direction > 0 ? a.freqKHz - b.freqKHz : b.freqKHz - a.freqKHz));
    if (candidates.length) {
      onScanStop();
      onFrequencyChange(candidates[0].freq);
    }
  };

  const handleDetectedClick = (station) => {
    onScanStop();
    onFrequencyChange(station.freq);
  };

  return (
    <div className="glass-panel clip-corner p-3 tactical-hud">
      <div className="text-[9px] text-[#484f58] mb-2 font-bold tracking-wider flex items-center gap-1.5">
        <Radar size={11} className={scanning ? 'text-[#00f5ff] animate-spin' : 'text-[#00f5ff]'} />
        AUTO-SCAN · STATION FINDER
      </div>

      {/* Primary scan controls */}
      <div className="grid grid-cols-2 gap-1.5 mb-1.5">
        {!scanning ? (
          <button
            onClick={onScanStart}
            disabled={!bandStations.length}
            className="flex items-center justify-center gap-1.5 px-2 py-2.5 text-[10px] font-bold tracking-wider clip-corner border border-[#00f5ff]/40 bg-[#00f5ff]/10 text-[#00f5ff] hover:bg-[#00f5ff]/20 glow-hover transition-all touch-manipulation min-h-[44px] disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Radar size={13} /> SCAN
          </button>
        ) : (
          <button
            onClick={onScanStop}
            className="flex items-center justify-center gap-1.5 px-2 py-2.5 text-[10px] font-bold tracking-wider clip-corner border border-[#ff3b30]/40 bg-[#ff3b30]/15 text-[#ff3b30] hover:bg-[#ff3b30]/25 transition-all touch-manipulation min-h-[44px]"
          >
            <Square size={13} /> STOP
          </button>
        )}
        <button
          onClick={autoTune}
          disabled={!bandStations.length || scanning}
          className="flex items-center justify-center gap-1.5 px-2 py-2.5 text-[10px] font-bold tracking-wider clip-corner border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] hover:bg-[#FF9F00]/20 glow-hover-amber transition-all touch-manipulation min-h-[44px] disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Zap size={13} /> AUTO-TUNE
        </button>
      </div>

      {/* Station hopping */}
      <div className="grid grid-cols-2 gap-1.5 mb-2">
        <button
          onClick={() => tuneNext(-1)}
          disabled={!bandStations.length || scanning}
          className="flex items-center justify-center gap-1 px-2 py-1.5 text-[9px] font-bold tracking-wider clip-corner border border-[#30363d] bg-[#0d1117] text-[#8b949e] hover:text-[#00f5ff] hover:border-[#00f5ff]/40 transition-all touch-manipulation min-h-[36px] disabled:opacity-40"
        >
          <ChevronLeft size={12} /> PREV STA
        </button>
        <button
          onClick={() => tuneNext(1)}
          disabled={!bandStations.length || scanning}
          className="flex items-center justify-center gap-1 px-2 py-1.5 text-[9px] font-bold tracking-wider clip-corner border border-[#30363d] bg-[#0d1117] text-[#8b949e] hover:text-[#00f5ff] hover:border-[#00f5ff]/40 transition-all touch-manipulation min-h-[36px] disabled:opacity-40"
        >
          NEXT STA <ChevronRight size={12} />
        </button>
      </div>

      {/* Scan status / progress */}
      <div className="flex items-center justify-between mb-2 text-[8px]">
        <span className="text-[#484f58] font-mono">
          {scanning ? '◉ SWEEPING' : '○ IDLE'} · {bandStations.length} CH
        </span>
        <span className="text-[#484f58] font-mono">
          {detected.length} FOUND
        </span>
      </div>

      {/* Detected stations list */}
      <div className="bg-[#0a0d11] border border-[#30363d] clip-corner max-h-[180px] overflow-y-auto">
        {detected.length === 0 ? (
          <div className="text-[9px] text-[#484f58] text-center py-3 px-2 leading-relaxed">
            {scanning
              ? 'Sweeping band — stations appear here as detected…'
              : bandStations.length
                ? 'Press SCAN to sweep the band, or AUTO-TUNE for the strongest signal.'
                : 'No known stations in this band.'}
          </div>
        ) : (
          <div className="p-1.5 space-y-1">
            {detected.map((s, i) => {
              const bars = signalBars(s.power);
              return (
                <button
                  key={`${s.freq}-${i}`}
                  onClick={() => handleDetectedClick(s)}
                  className="w-full text-left p-1.5 clip-corner border border-[#00f5ff]/20 bg-[#0d1117] hover:border-[#FF9F00]/40 hover:bg-[#FF9F00]/5 transition-all touch-manipulation group"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[9px] font-bold text-[#e6edf3] group-hover:text-[#FF9F00] truncate">
                      {s.station}
                    </span>
                    <span className="text-[8px] text-[#00f5ff] font-mono shrink-0">
                      {s.freq} {s.unit || band.unit}
                    </span>
                  </div>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-[7px] text-[#484f58] truncate">
                      {s.country ? `${s.country}` : 'Channel'} {s.band ? `· ${s.band}` : ''}
                    </span>
                    <div className="flex items-center gap-0.5 shrink-0">
                      {Array.from({ length: 5 }).map((_, j) => (
                        <span
                          key={j}
                          className="w-1 h-2.5"
                          style={{
                            background: j < bars
                              ? (j < 3 ? '#4dd0e1' : '#FF9F00')
                              : '#30363d',
                          }}
                        />
                      ))}
                    </div>
                  </div>
                </button>
              );
            })}
            <button
              onClick={onClearDetected}
              className="w-full flex items-center justify-center gap-1 py-1 text-[8px] text-[#484f58] hover:text-[#ff3b30] transition-colors touch-manipulation"
            >
              <Trash2 size={9} /> CLEAR
            </button>
          </div>
        )}
      </div>
    </div>
  );
}