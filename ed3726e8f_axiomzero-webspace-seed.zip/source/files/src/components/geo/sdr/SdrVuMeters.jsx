import { useState, useEffect } from 'react';

/** Vertical VU meter bars with cyan-to-amber gradient + S-meter readout. */
export default function SdrVuMeters({ mode, signalBoost = 0 }) {
  const [levels, setLevels] = useState([20, 15, 10, 15, 20]);
  const [peakHold, setPeakHold] = useState([0, 0, 0, 0, 0]);

  useEffect(() => {
    const interval = setInterval(() => {
      const base = (mode === 'live' ? 45 : 25) + signalBoost * 0.4;
      const newLevels = Array.from({ length: 5 }, (_, i) => {
        const center = Math.abs(i - 2);
        return Math.max(5, base + (3 - center) * 8 + Math.random() * 30);
      });
      setLevels(newLevels);
      setPeakHold((prev) => prev.map((p, i) => Math.max(p - 3, newLevels[i])));
    }, 120);
    return () => clearInterval(interval);
  }, [mode, signalBoost]);

  const sMeter = Math.round(levels[2] / 10);
  const db = Math.round((levels[2] % 10) * 2);

  return (
    <div className="glass-panel clip-corner p-3 tactical-hud">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[9px] text-[#484f58] font-bold tracking-wider">S-METER · VU</span>
        {signalBoost > 10 && (
          <span className="text-[8px] text-[#3fb950] font-bold tracking-wider animate-pulse">◉ LOCK</span>
        )}
      </div>
      <div className="flex items-end gap-1.5 h-16">
        {levels.map((level, i) => (
          <div key={i} className="flex-1 bg-[#0a0d11] relative overflow-hidden h-full border border-[#30363d]/50">
            <div
              className="absolute bottom-0 left-0 right-0 transition-all duration-100"
              style={{
                height: `${level}%`,
                background: 'linear-gradient(to top, #4dd0e1 0%, #4dd0e1 50%, #FF9F00 100%)',
              }}
            />
            {/* Peak hold marker */}
            {peakHold[i] > level && (
              <div
                className="absolute left-0 right-0 transition-all duration-100"
                style={{
                  bottom: `${peakHold[i]}%`,
                  height: '2px',
                  background: '#FF9F00',
                  opacity: 0.8,
                }}
              />
            )}
          </div>
        ))}
      </div>
      <div className="text-[9px] text-[#8b949e] mt-1.5 text-center font-mono">
        S{sMeter}+{db}dB
      </div>
    </div>
  );
}