import { useRef, useState } from 'react';
import { ChevronUp, ChevronDown, Crosshair } from 'lucide-react';
import { findStationAt } from '@/lib/geo/sdrBands';

/**
 * Semicircular tuning dial with glowing pointer + digital frequency readout.
 * Supports drag on the arc, direct text input, fine-tune up/down, and
 * snap-to-nearest-station. During scanning, the needle sweeps automatically.
 */
export default function SdrTuningDial({ band, frequency, onFrequencyChange, scanning }) {
  const svgRef = useRef(null);
  const [dragging, setDragging] = useState(false);

  const bandMin = band.range[0];
  const bandMax = band.range[1];
  const t = Math.max(0, Math.min(1, (frequency - bandMin) / (bandMax - bandMin)));
  const angle = Math.PI - t * Math.PI;
  const px = 100 + 75 * Math.cos(angle);
  const py = 95 - 75 * Math.sin(angle);

  const step = band.unit === 'kHz' ? 5 : 0.025;

  const handleMove = (e) => {
    if (!dragging || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    const x = ((clientX - rect.left) / rect.width) * 200;
    const y = ((clientY - rect.top) / rect.height) * 95;
    const dx = x - 100;
    const dy = 95 - y;
    if (dx === 0 && dy === 0) return;
    let a = Math.atan2(dy, dx);
    a = Math.max(0, Math.min(Math.PI, a));
    const newT = 1 - a / Math.PI;
    const newFreq = bandMin + newT * (bandMax - bandMin);
    onFrequencyChange(Math.round(newFreq * 100) / 100);
  };

  const fineTune = (dir) => {
    onFrequencyChange(Math.round((frequency + dir * step) * 100) / 100);
  };

  const snapToStation = () => {
    const station = findStationAt(band, frequency);
    if (station) onFrequencyChange(station.freq);
  };

  return (
    <div className="glass-panel clip-corner p-3 tactical-hud">
      <div className="flex items-center justify-between mb-1">
        <span className="text-[9px] text-[#484f58] font-bold tracking-wider">TUNING DIAL</span>
        {scanning && (
          <span className="text-[8px] text-[#00f5ff] font-bold tracking-wider animate-pulse">◉ SCANNING</span>
        )}
      </div>
      <svg
        ref={svgRef}
        viewBox="0 0 200 100"
        className="w-full touch-none select-none"
        onPointerDown={(e) => { e.preventDefault(); setDragging(true); handleMove(e); }}
        onPointerMove={handleMove}
        onPointerUp={() => setDragging(false)}
        onPointerLeave={() => setDragging(false)}
      >
        <path d="M 25 95 A 75 75 0 0 1 175 95" fill="none" stroke="#30363d" strokeWidth="2" />
        <path d={`M 25 95 A 75 75 0 0 1 ${px} ${py}`} fill="none" stroke="#FF9F00" strokeWidth="2" />
        {Array.from({ length: 9 }).map((_, i) => {
          const mt = i / 8;
          const ma = Math.PI - mt * Math.PI;
          return (
            <line key={i} x1={100 + 68 * Math.cos(ma)} y1={95 - 68 * Math.sin(ma)}
              x2={100 + 78 * Math.cos(ma)} y2={95 - 78 * Math.sin(ma)} stroke="#484f58" strokeWidth="1" />
          );
        })}
        <line
          x1="100" y1="95" x2={px} y2={py}
          stroke="#FF9F00"
          strokeWidth={scanning ? 3 : 2}
          className="glow-pulse"
          style={scanning ? { filter: 'drop-shadow(0 0 4px #FF9F00)' } : {}}
        />
        <circle cx="100" cy="95" r="3" fill="#FF9F00" />
      </svg>
      <div className="text-center mt-1">
        <div className={`text-lg font-bold font-mono tracking-wider ${scanning ? 'text-[#00f5ff]' : 'text-[#FF9F00]'}`}>
          {frequency.toFixed(band.unit === 'kHz' ? 0 : 3)} <span className="text-[10px] text-[#8b949e]">{band.unit}</span>
        </div>
        <div className="text-[9px] text-[#484f58]">
          {band.unit === 'kHz' ? `${(frequency / 1000).toFixed(3)} MHz` : `${Math.round(frequency * 1000)} kHz`}
        </div>
      </div>
      <input
        type="number"
        value={frequency}
        onChange={(e) => onFrequencyChange(parseFloat(e.target.value) || 0)}
        className="w-full mt-2 bg-[#0a0d11] border border-[#00f5ff]/20 text-[10px] text-[#e6edf3] px-2 py-1.5 clip-corner focus:outline-none focus:border-[#00f5ff]/40 font-mono"
        step={step}
      />
      {/* Fine-tune + snap controls */}
      <div className="grid grid-cols-3 gap-1 mt-1.5">
        <button
          onClick={() => fineTune(-1)}
          className="flex items-center justify-center gap-0.5 py-1.5 text-[9px] font-bold tracking-wider clip-corner border border-[#30363d] bg-[#0d1117] text-[#8b949e] hover:text-[#00f5ff] hover:border-[#00f5ff]/40 transition-all touch-manipulation min-h-[36px]"
        >
          <ChevronDown size={12} /> FINE
        </button>
        <button
          onClick={snapToStation}
          className="flex items-center justify-center gap-0.5 py-1.5 text-[9px] font-bold tracking-wider clip-corner border border-[#00f5ff]/30 bg-[#00f5ff]/5 text-[#00f5ff] hover:bg-[#00f5ff]/15 transition-all touch-manipulation min-h-[36px]"
        >
          <Crosshair size={12} /> SNAP
        </button>
        <button
          onClick={() => fineTune(1)}
          className="flex items-center justify-center gap-0.5 py-1.5 text-[9px] font-bold tracking-wider clip-corner border border-[#30363d] bg-[#0d1117] text-[#8b949e] hover:text-[#00f5ff] hover:border-[#00f5ff]/40 transition-all touch-manipulation min-h-[36px]"
        >
          FINE <ChevronUp size={12} />
        </button>
      </div>
    </div>
  );
}