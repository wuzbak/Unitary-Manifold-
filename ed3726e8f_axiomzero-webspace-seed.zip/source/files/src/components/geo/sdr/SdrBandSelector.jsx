import { SDR_BANDS } from '@/lib/geo/sdrBands';

/** Horizontal scrollable strip of band chips — active state in amber. */
export default function SdrBandSelector({ band, onBandChange }) {
  return (
    <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1 scroll-area">
      {SDR_BANDS.map((b) => {
        const isActive = band.id === b.id;
        return (
          <button
            key={b.id}
            onClick={() => onBandChange(b)}
            className={`px-3 py-2 text-[10px] font-bold tracking-wider whitespace-nowrap clip-corner transition-all shrink-0 min-h-[44px] flex flex-col items-center justify-center gap-0.5 ${
              isActive
                ? 'bg-[#FF9F00]/20 text-[#FF9F00] border border-[#FF9F00]/40 glow-hover-amber'
                : 'glass-panel text-[#8b949e] border border-[#00f5ff]/20 hover:text-[#00f5ff] hover:border-[#00f5ff]/40'
            }`}
          >
            <span>{b.short}</span>
            <span className="text-[7px] font-normal opacity-60">{b.range[0]}–{b.range[1]} {b.unit}</span>
          </button>
        );
      })}
    </div>
  );
}