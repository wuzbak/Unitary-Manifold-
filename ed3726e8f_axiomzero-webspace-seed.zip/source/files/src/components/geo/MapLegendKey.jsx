/**
 * MapLegendKey — compact horizontal legend bar anchored to the bottom edge of
 * the globe. Tactical-HUD framed (corner brackets + scanline + sectioned 'Key'
 * divider). Shows the icon + color + label for every active point feed, plus
 * aircraft and supply-chain. A live-pulse dot marks each active (polling)
 * feed. Scrollable on narrow screens.
 */
import { FEEDS } from '@/lib/geoFeeds';

export default function MapLegendKey({ activeFeeds }) {
  const entries = [];
  Object.entries(FEEDS).forEach(([key, feed]) => {
    if (feed.kind === 'point' && activeFeeds?.[key]) {
      entries.push({ key, color: feed.color, icon: feed.icon, label: feed.label });
    }
  });
  if (activeFeeds?.aircraft) {
    entries.push({ key: 'aircraft', color: '#4dd0e1', icon: '✈', label: 'Live Aircraft' });
  }
  if (activeFeeds?.supplyChain) {
    entries.push({ key: 'supplyChain', color: '#ff9f0a', icon: '⚓', label: 'Supply Chain' });
  }
  if (activeFeeds?.milAircraft) {
    entries.push({ key: 'milAircraft', color: '#ff9f0a', icon: '✈', label: 'Military Aircraft' });
  }
  if (activeFeeds?.maritime) {
    entries.push({ key: 'maritime', color: '#4dd0e1', icon: '⚓', label: 'Maritime (AIS)' });
  }

  if (!entries.length) return null;

  return (
    <div className="absolute bottom-2 left-2 right-2 z-[350] flex justify-center pointer-events-none">
      <div className="tactical-hud glass-strong clip-corner px-2 py-1.5 pointer-events-auto max-w-full">
        <div className="hud-scanline">
          <div className="flex items-center gap-1.5 overflow-x-auto relative z-[2] max-w-full">
            <span className="text-[8px] text-[#484f58] uppercase tracking-wider shrink-0 pr-1 hud-divider-r">Key</span>
            {entries.map((e) => (
              <div key={e.key} className="flex items-center gap-1 shrink-0">
                <span className="w-1 h-1 rounded-full glow-pulse shrink-0" style={{ background: e.color }} />
                <span className="w-2.5 h-2.5 shrink-0" style={{ background: e.color, clipPath: 'polygon(50% 0,100% 35%,80% 100%,20% 100%,0 35%)' }} />
                <span className="text-[9px] text-[#e6edf3] whitespace-nowrap">{e.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}