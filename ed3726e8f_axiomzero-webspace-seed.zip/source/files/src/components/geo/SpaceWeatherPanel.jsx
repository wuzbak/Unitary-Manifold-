/**
 * SpaceWeatherPanel — dedicated console panel for non-geographic space-weather
 * data. Tier 1: NOAA SWPC (client-side) — solar X-ray flux class, Kp geomagnetic
 * index gauge, recent alerts. Tier 2: NASA DONKI (backend) — CME event list.
 * UM pillar: P16 — Sentinel Capacity.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Sun, AlertTriangle, Loader2, RefreshCw } from 'lucide-react';
import UnavailableCard from '@/components/shared/UnavailableCard';

function flareClass(flux) {
  if (flux == null) return { letter: '—', scale: 0, label: 'No data', color: '#8b949e' };
  const log = Math.log10(flux);
  if (log >= -4) return { letter: 'X', scale: 4, label: 'X-class (severe)', color: '#ff6b6b' };
  if (log >= -5) return { letter: 'M', scale: 3, label: 'M-class (moderate)', color: '#ff9f0a' };
  if (log >= -6) return { letter: 'C', scale: 2, label: 'C-class (minor)', color: '#ffd60a' };
  if (log >= -7) return { letter: 'B', scale: 1, label: 'B-class (background)', color: '#4dd0e1' };
  return { letter: 'A', scale: 0, label: 'A-class (quiet)', color: '#3fb950' };
}

const KP_SCALE = [
  { max: 4, level: 'G0', label: 'Quiet', color: '#3fb950' },
  { max: 5, level: 'G1', label: 'Minor', color: '#4dd0e1' },
  { max: 6, level: 'G2', label: 'Moderate', color: '#ffd60a' },
  { max: 7, level: 'G3', label: 'Strong', color: '#ff9f0a' },
  { max: 8, level: 'G4', label: 'Severe', color: '#ff6b6b' },
  { max: 10, level: 'G5', label: 'Extreme', color: '#bc8cff' },
];

function kpInfo(kp) {
  return KP_SCALE.find((s) => kp <= s.max) || KP_SCALE[KP_SCALE.length - 1];
}

export default function SpaceWeatherPanel() {
  const [data, setData] = useState(null);
  const [donki, setDonki] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const [xrayRes, kpRes, alertsRes] = await Promise.allSettled([
        fetch('https://services.swpc.noaa.gov/json/goes/primary/xrays-6-hour.json').then((r) => r.json()),
        fetch('https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json').then((r) => r.json()),
        fetch('https://services.swpc.noaa.gov/products/alerts.json').then((r) => r.json()),
      ]);
      let xray = null, kp = null, alerts = [];
      if (xrayRes.status === 'fulfilled' && Array.isArray(xrayRes.value) && xrayRes.value.length) {
        const short = xrayRes.value.filter((x) => x.energy === '0.05-0.4nm').slice(-1)[0];
        xray = short || xrayRes.value[xrayRes.value.length - 1];
      }
      if (kpRes.status === 'fulfilled' && Array.isArray(kpRes.value) && kpRes.value.length > 1) {
        const last = kpRes.value[kpRes.value.length - 1];
        kp = { time: last[0], value: parseFloat(last[1]) };
      }
      if (alertsRes.status === 'fulfilled' && Array.isArray(alertsRes.value)) {
        alerts = alertsRes.value.slice(-15).reverse();
      }
      setData({ xray, kp, alerts });
    } catch (e) {
      setError(e.message);
    }
    try {
      const res = await base44.functions.invoke('nasaDonki', {});
      const d = res.data || res;
      if (!d.status || d.status === 'ok') setDonki(d);
    } catch {
      /* Tier 2 (NASA key) not ready yet — panel still shows SWPC data */
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 60000);
    return () => clearInterval(id);
  }, []);

  const flux = data?.xray?.flux;
  const fc = flareClass(flux);
  const kp = data?.kp;
  const ki = kp ? kpInfo(kp.value) : null;

  return (
    <div className="glass-panel clip-corner p-3">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-1.5">
          <Sun size={14} className="text-[#ff9f0a]" />
          <span className="text-xs font-bold text-[#ff9f0a] uppercase tracking-wider">Space Weather</span>
          <span className="text-[9px] text-[#484f58]">P16 · Sentinel</span>
        </div>
        <button onClick={load} className="text-[#484f58] hover:text-[#e6edf3] min-h-[32px] min-w-[32px] flex items-center justify-center"><RefreshCw size={11} /></button>
      </div>

      {loading && !data ? (
        <div className="flex items-center justify-center py-6"><Loader2 size={16} className="animate-spin text-[#ff9f0a]" /></div>
      ) : error ? (
        <UnavailableCard message={error || 'Space weather data unavailable'} onRetry={load} compact />
      ) : (
        <div className="space-y-3">
          <div className="bg-[#0d1117] border border-[#30363d] rounded p-2">
            <div className="text-[9px] text-[#8b949e] uppercase mb-1">Solar X-Ray Flux</div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold" style={{ color: fc.color }}>{fc.letter}</span>
              <span className="text-[10px] text-[#8b949e]">{fc.label}</span>
            </div>
            {flux != null && <div className="text-[9px] text-[#484f58] font-mono">{flux.toExponential(2)} W/m²</div>}
          </div>

          <div className="bg-[#0d1117] border border-[#30363d] rounded p-2">
            <div className="text-[9px] text-[#8b949e] uppercase mb-1">Geomagnetic Kp Index</div>
            {ki ? (
              <>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold" style={{ color: ki.color }}>{ki.level}</span>
                  <span className="text-[10px] text-[#8b949e]">{ki.label} · Kp {kp.value}</span>
                </div>
                <div className="mt-1.5 h-2 bg-[#161b22] rounded overflow-hidden">
                  <div className="h-full transition-all" style={{ width: `${Math.min((kp.value / 9) * 100, 100)}%`, background: ki.color }} />
                </div>
              </>
            ) : <div className="text-[10px] text-[#484f58]">No data</div>}
          </div>

          <div>
            <div className="text-[9px] text-[#8b949e] uppercase mb-1">Recent SWPC Alerts</div>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {data?.alerts?.length ? data.alerts.map((a, i) => (
                <div key={i} className="text-[9px] text-[#8b949e] border-l-2 border-[#ff9f0a]/40 pl-2 py-0.5">
                  <span className="text-[#e6edf3] font-bold">{a.product_id || 'Alert'}</span>
                  <div className="text-[#484f58] truncate">{a.message ? a.message.slice(0, 80) : ''}</div>
                </div>
              )) : <div className="text-[9px] text-[#484f58]">No active alerts</div>}
            </div>
          </div>

          {donki && (
            <div>
              <div className="text-[9px] text-[#8b949e] uppercase mb-1">DONKI · CME Events (7d)</div>
              <div className="space-y-1 max-h-28 overflow-y-auto">
                {donki.cmes?.length ? donki.cmes.slice(0, 8).map((c) => (
                  <div key={c.id} className="text-[9px] text-[#8b949e] border-l-2 border-[#bc8cff]/40 pl-2 py-0.5">
                    <span className="text-[#e6edf3]">{new Date(c.startTime).toUTCString().slice(5, 22)}</span>
                    <div className="text-[#484f58] truncate">{c.note || 'CME analysis'}</div>
                  </div>
                )) : <div className="text-[9px] text-[#484f58]">No CMEs in window</div>}
              </div>
              <div className="text-[8px] text-[#484f58] mt-1">Flares: {donki.flares?.length || 0} · Storms: {donki.storms?.length || 0}</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}