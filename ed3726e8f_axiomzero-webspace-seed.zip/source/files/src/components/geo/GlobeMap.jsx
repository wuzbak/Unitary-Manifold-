/**
 * GlobeMap — MapLibre GL 3D globe component for the GeoMonitor.
 * Renders Tactical Pin Grid symbol markers (teardrop pins with category
 * glyphs), an airspace overlay (aircraft + trajectory tracks), heatmap,
 * WMS overlays, and supply-chain chokepoints.
 *
 * Uses keyless Esri raster tiles (no API key, no tracker). Globe projection
 * with atmosphere fog for the 3D effect. Pin size is fixed; severity is
 * communicated via icon-opacity, not circle-radius scaling.
 */
import { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { STYLES, WMS_SOURCES } from '@/lib/geo/mapStyles';
import { FEEDS, feedForType } from '@/lib/geoFeeds';
import { generatePinImages, generateAircraftImages, generateMilitaryAircraftImages, generateShipImages, altitudeBand } from '@/lib/geo/pinIcons';
import MapLegendKey from '@/components/geo/MapLegendKey';

const SEVERITY_SCORE = { severe: 1, moderate: 0.72, minor: 0.45 };

export default function GlobeMap({
  events, selected, onSelect, basemap = 'dark',
  activeFeeds, heatmapMode = false, chokepoints = [], showSupplyChain = false,
  aircraft = [], selectedAircraft, onAircraftSelect, aircraftTrack = [],
  milAircraft = [], vessels = [], densityPoints = [],
  onViewportChange, mapClass = 'h-[600px]',
}) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const eventsRef = useRef(events);
  const chokepointsRef = useRef(chokepoints);
  const aircraftRef = useRef(aircraft);
  const milAircraftRef = useRef(milAircraft);
  const vesselsRef = useRef(vessels);
  const aircraftTrackRef = useRef(aircraftTrack);
  const onSelectRef = useRef(onSelect);
  const onAircraftSelectRef = useRef(onAircraftSelect);
  const onViewportChangeRef = useRef(onViewportChange);
  const initialBasemap = useRef(basemap);
  useEffect(() => { eventsRef.current = events; }, [events]);
  useEffect(() => { chokepointsRef.current = chokepoints; }, [chokepoints]);
  useEffect(() => { aircraftRef.current = aircraft; }, [aircraft]);
  useEffect(() => { milAircraftRef.current = milAircraft; }, [milAircraft]);
  useEffect(() => { vesselsRef.current = vessels; }, [vessels]);
  useEffect(() => { aircraftTrackRef.current = aircraftTrack; }, [aircraftTrack]);
  useEffect(() => { onSelectRef.current = onSelect; }, [onSelect]);
  useEffect(() => { onAircraftSelectRef.current = onAircraftSelect; }, [onAircraftSelect]);
  useEffect(() => { onViewportChangeRef.current = onViewportChange; }, [onViewportChange]);

  // ── Setup all dynamic layers (called after load + after style change) ──
  function setupDynamicLayers(map) {
    // Pin + aircraft icon images
    const pinImages = generatePinImages(FEEDS);
    Object.entries(pinImages).forEach(([name, img]) => { if (!map.hasImage(name)) map.addImage(name, img); });
    const acImages = generateAircraftImages();
    Object.entries(acImages).forEach(([name, img]) => { if (!map.hasImage(name)) map.addImage(name, img); });
    const milImages = generateMilitaryAircraftImages();
    Object.entries(milImages).forEach(([name, img]) => { if (!map.hasImage(name)) map.addImage(name, img); });
    const shipImages = generateShipImages();
    Object.entries(shipImages).forEach(([name, img]) => { if (!map.hasImage(name)) map.addImage(name, img); });

    if (!map.getSource('events')) {
      map.addSource('events', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
    }
    if (!map.getSource('aircraft')) {
      map.addSource('aircraft', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
    }
    if (!map.getSource('aircraft-track')) {
      map.addSource('aircraft-track', {
        type: 'geojson',
        data: { type: 'Feature', geometry: { type: 'LineString', coordinates: [] }, properties: {} },
      });
    }
    if (!map.getSource('mil-aircraft')) {
      map.addSource('mil-aircraft', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
    }
    if (!map.getSource('vessels')) {
      map.addSource('vessels', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
    }
    if (!map.getSource('density')) {
      map.addSource('density', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
    }
    if (!map.getSource('chokepoints')) {
      map.addSource('chokepoints', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
    }
    if (!map.getSource('wms-seaice')) {
      map.addSource('wms-seaice', { type: 'raster', tiles: WMS_SOURCES.seaIce.tiles, tileSize: 256 });
    }
    if (!map.getSource('wms-drought')) {
      map.addSource('wms-drought', { type: 'raster', tiles: WMS_SOURCES.drought.tiles, tileSize: 256 });
    }

    // Heatmap layer (hidden by default)
    if (!map.getLayer('events-heat')) {
      map.addLayer({
        id: 'events-heat', type: 'heatmap', source: 'events',
        layout: { visibility: 'none' },
        paint: {
          'heatmap-weight': ['interpolate', ['linear'], ['get', 'intensity'], 0, 0, 1, 1],
          'heatmap-intensity': 1.2,
          'heatmap-color': ['interpolate', ['linear'], ['heatmap-density'],
            0, 'rgba(0,0,0,0)', 0.2, '#4dd0e1', 0.4, '#ff9f0a', 0.6, '#ff6b6b', 0.8, '#bc8cff', 1, '#ffffff'],
          'heatmap-radius': ['interpolate', ['linear'], ['zoom'], 0, 15, 8, 40],
          'heatmap-opacity': 0.7,
        },
      });
    }

    // Tactical Pin Grid — symbol layer replacing the old circle layer
    if (!map.getLayer('events-pins')) {
      map.addLayer({
        id: 'events-pins', type: 'symbol', source: 'events',
        layout: {
          'icon-image': ['get', 'icon'],
          'icon-size': 0.5,
          'icon-allow-overlap': true,
          'icon-ignore-placement': true,
          'icon-anchor': 'bottom',
          'icon-rotation-alignment': 'viewport',
        },
        paint: {
          'icon-opacity': ['interpolate', ['linear'], ['get', 'severity'], 0, 0.4, 1, 1],
        },
      });
    }

    // Selected event ring (sits at the pin tip)
    if (!map.getLayer('events-selected')) {
      map.addLayer({
        id: 'events-selected', type: 'circle', source: 'events',
        filter: ['==', ['get', 'id'], '__none__'],
        paint: {
          'circle-radius': 13,
          'circle-color': 'rgba(255,255,255,0)',
          'circle-stroke-color': '#ffffff',
          'circle-stroke-width': 2.5,
          'circle-stroke-opacity': 1,
        },
      });
    }

    // Aircraft airspace overlay
    if (!map.getLayer('aircraft-pins')) {
      map.addLayer({
        id: 'aircraft-pins', type: 'symbol', source: 'aircraft',
        layout: {
          'icon-image': ['get', 'icon'],
          'icon-size': 0.55,
          'icon-allow-overlap': true,
          'icon-ignore-placement': true,
          'icon-rotate': ['get', 'heading'],
          'icon-rotation-alignment': 'map',
          visibility: 'none',
        },
        paint: { 'icon-opacity': 0.95 },
      });
    }
    if (!map.getLayer('aircraft-track-line')) {
      map.addLayer({
        id: 'aircraft-track-line', type: 'line', source: 'aircraft-track',
        layout: { visibility: 'none' },
        paint: { 'line-color': '#4dd0e1', 'line-width': 2, 'line-opacity': 0.85, 'line-dasharray': [2, 2] },
      });
    }

    // Military aircraft overlay (amber)
    if (!map.getLayer('mil-aircraft-pins')) {
      map.addLayer({
        id: 'mil-aircraft-pins', type: 'symbol', source: 'mil-aircraft',
        layout: {
          'icon-image': 'mil-plane', 'icon-size': 0.6,
          'icon-allow-overlap': true, 'icon-ignore-placement': true,
          'icon-rotate': ['get', 'heading'], 'icon-rotation-alignment': 'map',
          visibility: 'none',
        },
        paint: { 'icon-opacity': 0.95 },
      });
    }

    // Vessel overlay (cyan, rotated by course)
    if (!map.getLayer('vessels-pins')) {
      map.addLayer({
        id: 'vessels-pins', type: 'symbol', source: 'vessels',
        layout: {
          'icon-image': 'ship', 'icon-size': 0.55,
          'icon-allow-overlap': true, 'icon-ignore-placement': true,
          'icon-rotate': ['get', 'heading'], 'icon-rotation-alignment': 'map',
          visibility: 'none',
        },
        paint: { 'icon-opacity': 0.9 },
      });
    }

    // Air-traffic density heatmap
    if (!map.getLayer('density-heat')) {
      map.addLayer({
        id: 'density-heat', type: 'heatmap', source: 'density',
        layout: { visibility: 'none' },
        paint: {
          'heatmap-weight': ['interpolate', ['linear'], ['get', 'count'], 0, 0, 50, 1],
          'heatmap-intensity': 1.5,
          'heatmap-color': ['interpolate', ['linear'], ['heatmap-density'],
            0, 'rgba(0,0,0,0)', 0.2, '#4dd0e1', 0.5, '#ff9f0a', 0.8, '#ff6b6b', 1, '#ffffff'],
          'heatmap-radius': ['interpolate', ['linear'], ['zoom'], 0, 8, 8, 30],
          'heatmap-opacity': 0.6,
        },
      });
    }

    // Chokepoint markers
    if (!map.getLayer('chokepoints-circles')) {
      map.addLayer({
        id: 'chokepoints-circles', type: 'circle', source: 'chokepoints',
        layout: { visibility: 'none' },
        paint: {
          'circle-radius': ['interpolate', ['linear'], ['get', 'criticality'], 1, 5, 5, 9],
          'circle-color': '#ff9f0a',
          'circle-opacity': 0.7,
          'circle-stroke-color': '#ff9f0a',
          'circle-stroke-width': 1.5,
          'circle-stroke-opacity': 0.9,
        },
      });
    }
    if (!map.getLayer('chokepoints-labels')) {
      map.addLayer({
        id: 'chokepoints-labels', type: 'symbol', source: 'chokepoints',
        layout: {
          'text-field': ['get', 'name'], 'text-size': 9,
          'text-offset': [0, 1.5], 'text-anchor': 'top', visibility: 'none',
        },
        paint: { 'text-color': '#ff9f0a', 'text-halo-color': '#0B0F13', 'text-halo-width': 2 },
      });
    }
  }

  // ── Initialize map once ──────────────────────────────────────────────
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: STYLES[initialBasemap.current] || STYLES.dark,
      center: [0, 20],
      zoom: 1.2,
      projection: 'globe',
      antialias: true,
      attributionControl: { compact: true },
      maxZoom: 12,
    });
    mapRef.current = map;

    map.addControl(new maplibregl.NavigationControl({ visualizePitch: true, showCompass: true }), 'top-left');
    try { map.addControl(new maplibregl.GlobeControl()); } catch { /* */ }

    map.on('load', () => {
      try {
        map.setFog({
          range: [1, 10], color: '#0B0F13',
          'high-color': '#1a2030', 'space-color': '#000000',
          'horizon-blend': 0.15, 'star-intensity': 0.1,
        });
      } catch { /* */ }
      setupDynamicLayers(map);
      setMapLoaded(true);
      const c = map.getCenter();
      onViewportChangeRef.current?.({ center: [c.lat, c.lng], zoom: map.getZoom() });
    });

    map.on('moveend', () => {
      const c = map.getCenter();
      onViewportChangeRef.current?.({ center: [c.lat, c.lng], zoom: map.getZoom() });
    });

    map.on('click', 'events-pins', (e) => {
      if (e.features?.length) {
        const f = e.features[0];
        const event = eventsRef.current.find((ev) => ev.id === f.properties.id);
        if (event) onSelectRef.current(event);
      }
    });
    map.on('mouseenter', 'events-pins', () => { map.getCanvas().style.cursor = 'pointer'; });
    map.on('mouseleave', 'events-pins', () => { map.getCanvas().style.cursor = ''; });

    map.on('click', 'aircraft-pins', (e) => {
      if (e.features?.length) {
        const f = e.features[0];
        const ac = aircraftRef.current.find((a) => a.icao24 === f.properties.id);
        if (ac) onAircraftSelectRef.current?.(ac);
      }
    });
    map.on('mouseenter', 'aircraft-pins', () => { map.getCanvas().style.cursor = 'pointer'; });
    map.on('mouseleave', 'aircraft-pins', () => { map.getCanvas().style.cursor = ''; });

    map.on('click', 'chokepoints-circles', (e) => {
      if (e.features?.length) {
        const f = e.features[0];
        const cp = chokepointsRef.current.find((c) => c.id === f.properties.id);
        if (cp) onSelectRef.current({
          id: `cp-${cp.id}`, type: 'chokepoint', title: cp.name, coords: cp.coords,
          place: cp.region, source: 'WorldMonitor · Supply Chain',
          severity: cp.criticality >= 5 ? 'severe' : cp.criticality >= 4 ? 'moderate' : 'minor',
          magnitude: cp.criticality, region: 'Supply Chain', supplyChain: cp,
        });
      }
    });
    map.on('mouseenter', 'chokepoints-circles', () => { map.getCanvas().style.cursor = 'pointer'; });
    map.on('mouseleave', 'chokepoints-circles', () => { map.getCanvas().style.cursor = ''; });

    return () => {
      map.remove();
      mapRef.current = null;
      setMapLoaded(false);
    };
  }, []);

  // ── Basemap change ───────────────────────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;
    setMapLoaded(false);
    map.setStyle(STYLES[basemap] || STYLES.dark);
    map.once('style.load', () => {
      try {
        map.setFog({
          range: [1, 10], color: '#0B0F13',
          'high-color': '#1a2030', 'space-color': '#000000',
          'horizon-blend': 0.15, 'star-intensity': 0.1,
        });
      } catch { /* */ }
      setupDynamicLayers(map);
      setMapLoaded(true);
    });
  }, [basemap]);

  // ── Update event data ───────────────────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;

    const features = events
      .filter((e) => e.coords)
      .map((e) => {
        const feed = feedForType(e.type);
        const feedKey = Object.keys(FEEDS).find((k) => FEEDS[k] === feed) || e.type;
        const sev = SEVERITY_SCORE[e.severity] ?? 0.5;
        const intensity = e.overlay ? (1 - e.overlay.windingStab) : 0.5;
        return {
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [e.coords[1], e.coords[0]] },
          properties: {
            id: e.id,
            icon: `pin-${feedKey}`,
            severity: sev,
            intensity,
            type: e.type,
            title: e.title || '',
            color: feed?.color || '#4dd0e1',
          },
        };
      });

    const src = map.getSource('events');
    if (src) src.setData({ type: 'FeatureCollection', features });

    if (map.getLayer('events-heat')) map.setLayoutProperty('events-heat', 'visibility', heatmapMode ? 'visible' : 'none');
    if (map.getLayer('events-pins')) map.setLayoutProperty('events-pins', 'visibility', heatmapMode ? 'none' : 'visible');
  }, [events, heatmapMode, mapLoaded]);

  // ── Update selected highlight ────────────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;
    if (map.getLayer('events-selected')) {
      map.setFilter('events-selected', ['==', ['get', 'id'], selected?.id || '__none__']);
    }
    if (selected?.coords) {
      map.flyTo({
        center: [selected.coords[1], selected.coords[0]],
        zoom: Math.max(map.getZoom(), 4),
        duration: 1200,
        essential: true,
      });
    }
  }, [selected, mapLoaded]);

  // ── Update aircraft overlay ──────────────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;
    const features = aircraft
      .filter((a) => a.latitude != null && a.longitude != null)
      .map((a) => {
        const alt = a.altitudeBaro != null ? a.altitudeBaro : a.baroAltitude;
        const heading = a.track != null ? a.track : (a.trueTrack != null ? a.trueTrack : 0);
        return {
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [a.longitude, a.latitude] },
          properties: { id: a.icao24, icon: altitudeBand(alt), heading, callsign: a.callsign || a.icao24 },
        };
      });
    const src = map.getSource('aircraft');
    if (src) src.setData({ type: 'FeatureCollection', features });

    const vis = activeFeeds?.aircraft ? 'visible' : 'none';
    if (map.getLayer('aircraft-pins')) map.setLayoutProperty('aircraft-pins', 'visibility', vis);
  }, [aircraft, activeFeeds?.aircraft, mapLoaded]);

  // ── Update military aircraft overlay ────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;
    const features = milAircraft
      .filter((a) => a.latitude != null && a.longitude != null)
      .map((a) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: [a.longitude, a.latitude] },
        properties: { id: a.icao24, icon: 'mil-plane', heading: a.track ?? a.trueTrack ?? 0, callsign: a.callsign || a.icao24 },
      }));
    const src = map.getSource('mil-aircraft');
    if (src) src.setData({ type: 'FeatureCollection', features });
    const vis = activeFeeds?.milAircraft ? 'visible' : 'none';
    if (map.getLayer('mil-aircraft-pins')) map.setLayoutProperty('mil-aircraft-pins', 'visibility', vis);
  }, [milAircraft, activeFeeds?.milAircraft, mapLoaded]);

  // ── Update vessel overlay ───────────────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;
    const features = vessels
      .filter((v) => v.latitude != null && v.longitude != null)
      .map((v) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: [v.longitude, v.latitude] },
        properties: { id: v.mmsi, icon: 'ship', heading: v.course ?? v.heading ?? 0, name: v.name || v.mmsi },
      }));
    const src = map.getSource('vessels');
    if (src) src.setData({ type: 'FeatureCollection', features });
    const vis = activeFeeds?.maritime ? 'visible' : 'none';
    if (map.getLayer('vessels-pins')) map.setLayoutProperty('vessels-pins', 'visibility', vis);
  }, [vessels, activeFeeds?.maritime, mapLoaded]);

  // ── Update air-traffic density heatmap ───────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;
    const features = densityPoints
      .filter((c) => c.lat != null && c.lon != null)
      .map((c) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: [c.lon, c.lat] },
        properties: { count: c.count },
      }));
    const src = map.getSource('density');
    if (src) src.setData({ type: 'FeatureCollection', features });
    const vis = activeFeeds?.density ? 'visible' : 'none';
    if (map.getLayer('density-heat')) map.setLayoutProperty('density-heat', 'visibility', vis);
  }, [densityPoints, activeFeeds?.density, mapLoaded]);

  // ── Update selected aircraft track ───────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;
    const coords = aircraftTrack
      .filter((p) => p.latitude != null && p.longitude != null)
      .map((p) => [p.longitude, p.latitude]);
    const src = map.getSource('aircraft-track');
    if (src) src.setData({ type: 'Feature', geometry: { type: 'LineString', coordinates: coords }, properties: {} });
    const vis = selectedAircraft && coords.length > 1 ? 'visible' : 'none';
    if (map.getLayer('aircraft-track-line')) map.setLayoutProperty('aircraft-track-line', 'visibility', vis);
    if (selectedAircraft?.latitude != null && selectedAircraft?.longitude != null) {
      map.flyTo({
        center: [selectedAircraft.longitude, selectedAircraft.latitude],
        zoom: Math.max(map.getZoom(), 5),
        duration: 1000,
        essential: true,
      });
    }
  }, [selectedAircraft, aircraftTrack, mapLoaded]);

  // ── Update WMS overlays ──────────────────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;

    if (activeFeeds?.seaIce) {
      if (!map.getLayer('wms-seaice-layer')) {
        map.addLayer({ id: 'wms-seaice-layer', type: 'raster', source: 'wms-seaice', paint: { 'raster-opacity': 0.7 } }, 'events-heat');
      }
      map.setLayoutProperty('wms-seaice-layer', 'visibility', 'visible');
    } else if (map.getLayer('wms-seaice-layer')) {
      map.setLayoutProperty('wms-seaice-layer', 'visibility', 'none');
    }

    if (activeFeeds?.drought) {
      if (!map.getLayer('wms-drought-layer')) {
        map.addLayer({ id: 'wms-drought-layer', type: 'raster', source: 'wms-drought', paint: { 'raster-opacity': 0.6 } }, 'events-heat');
      }
      map.setLayoutProperty('wms-drought-layer', 'visibility', 'visible');
    } else if (map.getLayer('wms-drought-layer')) {
      map.setLayoutProperty('wms-drought-layer', 'visibility', 'none');
    }
  }, [activeFeeds?.seaIce, activeFeeds?.drought, mapLoaded]);

  // ── Update chokepoints ───────────────────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;

    const features = chokepoints.map((cp) => ({
      type: 'Feature',
      geometry: { type: 'Point', coordinates: [cp.coords[1], cp.coords[0]] },
      properties: { id: cp.id, name: cp.name, criticality: cp.criticality },
    }));
    const src = map.getSource('chokepoints');
    if (src) src.setData({ type: 'FeatureCollection', features });

    const vis = showSupplyChain ? 'visible' : 'none';
    if (map.getLayer('chokepoints-circles')) map.setLayoutProperty('chokepoints-circles', 'visibility', vis);
    if (map.getLayer('chokepoints-labels')) map.setLayoutProperty('chokepoints-labels', 'visibility', vis);
  }, [chokepoints, showSupplyChain, mapLoaded]);

  return (
    <div className="relative w-full h-full">
      <div ref={containerRef} className={`w-full h-full ${mapClass}`} style={{ background: '#0B0F13' }} />
      <MapLegendKey activeFeeds={activeFeeds} />
    </div>
  );
}