/**
 * OverlayCard — UM Physics Overlay breakdown for a single event.
 * Renders φ-debt, radion amplitude, winding stability, w_a local, confidence,
 * energy estimates, and the epistemic label (🔵 ADJACENT TRACK).
 */
import { Atom, Gauge, Waves, Activity, Shield, Zap } from 'lucide-react';

function fmtSci(n) {
  if (n == null || !isFinite(n)) return '—';
  if (n === 0) return '0';
  const abs = Math.abs(n);
  if (abs >= 1e4 || abs < 1e-3) return n.toExponential(3);
  return n.toFixed(4);
}

function MetricRow({ icon, label, value, color, hint }) {
  return (
    <div className="flex items-center gap-2 py-1 border-b border-[#30363d]/50 last:border-b-0">
      <span className="shrink-0" style={{ color }}>{icon}</span>
      <div className="flex-1 min-w-0">
        <div className="text-[10px] text-[#8b949e]">{label}</div>
        {hint && <div className="text-[8px] text-[#484f58]">{hint}</div>}
      </div>
      <span className="text-[11px] font-mono font-bold text-[#e6edf3] text-right">{value}</span>
    </div>
  );
}

export default function OverlayCard({ overlay }) {
  if (!overlay) {
    return (
      <div className="mt-4 pt-3 border-t border-[#30363d]">
        <div className="text-[9px] text-[#484f58] uppercase tracking-wider mb-1">UM Physics Overlay</div>
        <div className="text-[10px] text-[#8b949e] italic">
          No overlay — observational station (gauge, buoy, air quality, or NEO). UM overlay applies to energetic disaster events only.
        </div>
      </div>
    );
  }

  const stabColor = overlay.windingStab > 0.6 ? '#3fb950' : overlay.windingStab > 0.3 ? '#ff9f0a' : '#ff6b6b';
  const confColor = overlay.confidence === 'HIGH' ? '#3fb950' : overlay.confidence === 'MEDIUM' ? '#ff9f0a' : '#8b949e';

  return (
    <div className="mt-4 pt-3 border-t border-[#30363d]">
      <div className="flex items-center gap-2 mb-2">
        <Atom size={14} className="text-[#bc8cff]" />
        <span className="text-[9px] text-[#bc8cff] uppercase tracking-wider font-bold">UM Physics Overlay</span>
        <span className="text-[8px] px-1.5 py-0.5 border border-[#bc8cff]/30 text-[#bc8cff] bg-[#bc8cff]/10 clip-corner ml-auto">
          {overlay.confidence}
        </span>
      </div>

      <div className="bg-[#0d1117] border border-[#30363d] rounded p-2.5">
        {/* Energy */}
        <div className="mb-2 pb-2 border-b border-[#30363d]">
          <div className="text-[9px] text-[#484f58] uppercase mb-1 flex items-center gap-1">
            <Zap size={9} /> Energy Estimate · {overlay.kind}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <div className="text-[8px] text-[#8b949e]">SI (Joules)</div>
              <div className="text-[11px] font-mono font-bold text-[#e6edf3]">{fmtSci(overlay.E_si)}</div>
            </div>
            <div>
              <div className="text-[8px] text-[#8b949e]">Planck units</div>
              <div className="text-[11px] font-mono font-bold text-[#e6edf3]">{fmtSci(overlay.E_planck)}</div>
            </div>
          </div>
        </div>

        {/* Pillar metrics */}
        <MetricRow icon={<Gauge size={11} />} label="φ-debt injection" hint="Pillar 16 — entropy"
          value={fmtSci(overlay.phiDebt)} color="#00f5ff" />
        <MetricRow icon={<Shield size={11} />} label="φ-alignment" hint="[0,1] · 1=pristine"
          value={overlay.phiAlignment.toFixed(4)} color="#4dd0e1" />
        <MetricRow icon={<Activity size={11} />} label="Radion amplitude" hint="Pillar 806 · |Δφ/φ₀|"
          value={fmtSci(overlay.radionAmp)} color="#ff9f0a" />
        <MetricRow icon={<Activity size={11} />} label="QCD suppression" hint="IR back-reaction ceiling"
          value={fmtSci(overlay.suppression)} color="#ff6b6b" />
        <MetricRow icon={<Waves size={11} />} label="Basin perturbation" hint="radion / basin depth"
          value={fmtSci(overlay.basinPert)} color="#bc8cff" />
        <MetricRow icon={<Shield size={11} />} label="Winding stability" hint="Pillar 786 · [0,1]"
          value={overlay.windingStab.toFixed(4)} color={stabColor} />
        <MetricRow icon={<Waves size={11} />} label="w_a local" hint="Pillar 808 · breathing mode"
          value={fmtSci(overlay.wALocal)} color="#79c0ff" />
      </div>

      {/* Pillar sources */}
      <div className="mt-2 flex flex-wrap gap-1">
        {overlay.pillarSources.map((p) => (
          <span key={p} className="text-[8px] px-1.5 py-0.5 border border-[#30363d] text-[#8b949e] clip-corner">
            {p}
          </span>
        ))}
      </div>

      {/* Epistemic label */}
      <div className="mt-2 text-[9px] text-[#bc8cff] italic leading-relaxed">
        {overlay.epistemicLabel}
      </div>
    </div>
  );
}