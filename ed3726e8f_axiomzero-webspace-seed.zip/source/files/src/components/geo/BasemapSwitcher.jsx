/**
 * BasemapSwitcher — compact pill control for switching keyless Esri basemap
 * styles (Dark Gray · Light Gray · Satellite · Streets). No API key anywhere.
 */
import { Map } from 'lucide-react';
import { BASEMAPS } from '@/lib/geoFeeds';

export default function BasemapSwitcher({ active, onChange }) {
  return (
    <div className="glass-strong clip-corner p-1 flex items-center gap-0.5 max-w-[70vw] overflow-x-auto">
      <Map size={12} className="text-[#00f5ff] mx-1 shrink-0" />
      {Object.entries(BASEMAPS).map(([key, bm]) => (
        <button
          key={key}
          onClick={() => onChange(key)}
          className={`text-[10px] px-2.5 py-1.5 font-bold tracking-wide clip-corner transition-all min-h-[36px] whitespace-nowrap ${
            active === key
              ? 'bg-[#00f5ff]/20 text-[#00f5ff] border border-[#00f5ff]/40'
              : 'text-[#8b949e] hover:text-[#e6edf3] border border-transparent'
          }`}
        >
          {bm.label}
        </button>
      ))}
    </div>
  );
}