/**
 * AircraftDetailDrawer — right-side sheet showing full aircraft telemetry.
 * Extracted from FlightTrackerPanel so both the standalone tracker panel and
 * the on-map airspace overlay can open the same drawer.
 */
import { X } from 'lucide-react';

function altDisplay(a) {
  if (a.altitudeBaro != null) return typeof a.altitudeBaro === 'number' ? `${a.altitudeBaro.toFixed(0)} m` : String(a.altitudeBaro);
  if (a.baroAltitude != null) return `${a.baroAltitude.toFixed(0)} m`;
  return 'Ground';
}
function speedDisplay(a) {
  if (a.groundSpeed != null) return `${a.groundSpeed.toFixed(0)} m/s`;
  if (a.velocity != null) return `${a.velocity.toFixed(0)} m/s`;
  return '—';
}
function headingDisplay(a) {
  if (a.track != null) return `${a.track.toFixed(0)}°`;
  if (a.trueTrack != null) return `${a.trueTrack.toFixed(0)}°`;
  return '—';
}

function Row({ label, value, color = '#e6edf3', mono }) {
  return (
    <div className="bg-[#0d1117] border border-[#30363d] rounded p-2">
      <div className="text-[9px] text-[#484f58]">{label}</div>
      <div className={`text-[10px] font-bold ${mono ? 'font-mono' : ''}`} style={{ color }}>{value}</div>
    </div>
  );
}

export default function AircraftDetailDrawer({ aircraft, onClose }) {
  if (!aircraft) return null;
  const a = aircraft;
  return (
    <>
      <div className="fixed inset-0 z-[1000] bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed right-0 top-0 bottom-0 z-[1001] w-80 max-w-[85vw] p-3">
        <div className="glass-strong clip-corner p-4 h-full overflow-y-auto fade-in">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#4dd0e1]">Aircraft Detail</span>
            <button onClick={onClose} className="text-[#8b949e] hover:text-[#e6edf3] min-h-[44px] min-w-[44px] flex items-center justify-center">
              <X size={14} />
            </button>
          </div>
          <div className="space-y-2">
            <div className="bg-[#0d1117] border border-[#30363d] rounded p-2">
              <div className="text-[10px] text-[#484f58]">Callsign</div>
              <div className="text-sm font-bold text-[#e6edf3]">{a.callsign || 'N/A'}</div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Row label="ICAO24" value={a.icao24} color="#4dd0e1" mono />
              <Row label="Registration" value={a.registration || a.originCountry || 'N/A'} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Row label="Altitude" value={altDisplay(a)} color="#ff9f0a" />
              <Row label="Ground Speed" value={speedDisplay(a)} color="#30d158" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Row label="Heading" value={headingDisplay(a)} color="#4dd0e1" />
              <Row label="Vertical Rate" value={a.verticalRate != null ? `${a.verticalRate.toFixed(1)} m/s` : '—'} />
            </div>
            <Row label="Position" value={`${a.latitude?.toFixed(4) ?? '—'}, ${a.longitude?.toFixed(4) ?? '—'}`} mono />
            {a.squawk && <Row label="Squawk" value={a.squawk} color="#ff9f0a" mono />}
            {(a.fromOrigin || a.toDestination) && (
              <Row label="Route" value={`${a.fromOrigin || '?'} → ${a.toDestination || '?'}`} />
            )}
            {a.aircraftType && <Row label="Aircraft Type" value={a.aircraftType} />}
            {a.emergency && a.emergency !== 'none' && (
              <div className="bg-[#7c1d1d]/30 border border-[#ff6b6b]/40 rounded p-2">
                <div className="text-[9px] text-[#ff6b6b] font-bold">⚠ Emergency: {a.emergency}</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}