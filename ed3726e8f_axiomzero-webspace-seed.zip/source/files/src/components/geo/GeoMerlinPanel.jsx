/**
 * GeoMerlinPanel — Embedded Merlin geo-monitoring risk specialist chat
 * for the GeoMonitor page. Uses useMerlinChat hook with geo-specific page
 * context and the geo expert prompt (auto-activated via the expert registry).
 *
 * Feature parity with the global QuantumCat: model selector, fourth-wall
 * mode, thought stream, and assistantFallback — so hiding the global floating
 * button on the Geo Monitor page loses no functionality.
 */
import { useRef, useEffect } from 'react';
import { useMerlinChat } from '@/hooks/useMerlinChat';
import { parseMerlinResponse } from '@/components/quantum-cat/parseMerlinResponse';
import MerlinPanelToolbar from '@/components/quantum-cat/MerlinPanelToolbar';
import { Send, Sparkles, Loader2, X } from 'lucide-react';

const GEO_PAGE_CONTEXT = {
  path: '/geo-monitor',
  title: 'UM Geophysical Monitor — Live Disaster Intelligence',
  description: 'Live globe disaster monitor with USGS, NASA EONET, NOAA NWS, FIRMS, AirNow, OpenSky/ADSB.lol flight tracking, and UM φ-overlay. Unified overlay system with weather as default layer.',
  keyData: 'Earthquakes · Wildfires · Volcanoes · Storms · NWS Alerts · Tsunami · GDACS · NHC Cyclones · FIRMS · CNEOS · AirNow AQI · USGS Water · NDBC Buoys · CO-OPS · Supply Chain · Flight Tracker (ADSB.lol + OpenSky) · Weather Panel (local + emergency alerts) · UM φ-overlay · Space Weather · Grid Stress',
};

const SUGGESTED = [
  'What hazards are active right now and what is the compound risk?',
  'Explain the UM φ-overlay for the largest recent earthquake',
  'Cross-correlate fire + drought + wind conditions in my area',
  'How does the flight tracker work and what data sources does it use?',
  'What do the different NWS alert severity levels mean?',
  'Analyze the supply chain chokepoint risk for the Strait of Hormuz',
];

export default function GeoMerlinPanel({ isOpen, onClose, initialPrompt }) {
  const { messages, input, setInput, loading, model, setModel, fourthWall, setFourthWall, webStatus, send, clearConversation } =
    useMerlinChat({ pageContext: GEO_PAGE_CONTEXT, storageKey: 'merlin-geo' });
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading]);

  // Auto-send a pre-built prompt (e.g. "Analyze this headline") when the panel opens with one.
  const sentPromptRef = useRef('');
  useEffect(() => {
    if (isOpen && initialPrompt && initialPrompt !== sentPromptRef.current) {
      sentPromptRef.current = initialPrompt;
      send(initialPrompt);
    }
    if (!isOpen) sentPromptRef.current = '';
  }, [isOpen, initialPrompt, send]);

  if (!isOpen) return null;

  const phaseLabel = webStatus?.phase === 'searching' ? 'searching web...' :
    webStatus?.phase === 'crawling' ? 'crawling...' :
    webStatus?.phase === 'rag' ? 'analyzing...' : 'Analyzing geo risk...';

  return (
    <>
      <div className="fixed inset-0 z-[900] bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed right-0 top-0 bottom-0 z-[901] w-96 max-w-[90vw] p-3">
        <div className="glass-strong clip-corner p-4 h-full flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles size={14} className="text-[#ff6b6b]" />
              <span className="text-xs font-bold text-[#ff6b6b]">Geo Risk Specialist</span>
              <span className="text-[8px] text-[#484f58] border border-[#30363d] rounded px-1.5 py-0.5">Merlin Expert</span>
            </div>
            <div className="flex items-center gap-2">
              <MerlinPanelToolbar model={model} setModel={setModel} fourthWall={fourthWall} setFourthWall={setFourthWall} onClear={clearConversation} showClear={messages.length > 0} />
              <button onClick={onClose} className="text-[#8b949e] hover:text-[#e6edf3]"><X size={14} /></button>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-2 mb-3">
            {messages.length === 0 && (
              <div className="space-y-2">
                <div className="text-[10px] text-[#8b949e] leading-relaxed">
                  I am your <span className="text-[#ff6b6b] font-bold">Geo-Monitoring Risk Specialist</span>. I have deep knowledge of every system on this page — earthquakes, wildfires, severe weather, volcanoes, air quality, space weather, flight tracking, and supply chain chokepoints.
                  <br /><br />
                  I cross-correlate compound hazards (fire + drought + wind, earthquake + tsunami, geomagnetic storm + grid stress) and explain data provenance. Ask me anything.
                </div>
                <div className="text-[9px] text-[#484f58] uppercase mb-1">Suggested Questions</div>
                {SUGGESTED.map((q, i) => (
                  <button key={i} onClick={() => send(q)} className="w-full text-left bg-[#0d1117] border border-[#30363d] rounded p-2 text-[10px] text-[#8b949e] hover:border-[#ff6b6b]/40 hover:text-[#e6edf3] transition-colors">
                    {q}
                  </button>
                ))}
              </div>
            )}
            {messages.map((m, i) => {
              if (m.role === 'user') {
                return <div key={i} className="bg-[#161b22] border border-[#30363d] rounded p-2 text-[10px] text-[#e6edf3] ml-4">{m.text}</div>;
              }
              const parsed = parseMerlinResponse(m.text);
              return (
                <div key={i} className="space-y-1">
                  <div className="text-[10px] text-[#e6edf3] whitespace-pre-wrap leading-relaxed bg-[#0d1117] border border-[#ff6b6b]/20 rounded p-2">{parsed?.body || m.text}</div>
                  {parsed?.sources?.length > 0 && (
                    <div className="pt-1 border-t border-[#30363d]">
                      <div className="text-[8px] text-[#484f58] uppercase mb-0.5">Sources</div>
                      {parsed.sources.map((s, j) => (
                        <div key={j} className="text-[9px] text-[#8b949e]">
                          {s.type === 'WEB' && s.url ? <a href={s.url} target="_blank" rel="noopener noreferrer" className="text-[#4dd0e1] hover:underline">{s.label}</a> : <span>{s.label}</span>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
            {loading && <div className="flex items-center gap-2 text-[10px] text-[#8b949e]"><Loader2 size={12} className="animate-spin text-[#ff6b6b]" /> {phaseLabel}</div>}
          </div>

          <div className="flex gap-1.5">
            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && send()}
              placeholder="Ask the geo risk specialist... or paste a URL to crawl"
              className="flex-1 bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] focus:border-[#ff6b6b]/40 focus:outline-none"
            />
            <button onClick={() => send()} disabled={loading || !input.trim()} className="px-3 py-1.5 bg-gradient-to-r from-[#ff6b6b] to-[#ff9f0a] text-black rounded text-[10px] font-bold disabled:opacity-50 flex items-center gap-1">
              <Send size={10} />
            </button>
          </div>
          {fourthWall && <div className="text-[8px] text-[#FF9F00] font-bold uppercase tracking-wider mt-1">Fourth-wall ON</div>}
        </div>
      </div>
    </>
  );
}