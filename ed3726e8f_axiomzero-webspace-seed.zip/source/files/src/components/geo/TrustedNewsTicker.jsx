/**
 * TrustedNewsTicker — hybrid empirical news ticker anchored to the bottom of
 * the Geo Monitor page.
 *
 * - Live headlines fetched from trusted outlets via the trustedNewsFeed backend
 *   proxy, interleaved with the curated 12-source trust labels.
 * - Scrolling marquee (pause-on-hover, prefers-reduced-motion → static list).
 * - Live-pulse status indicator (LIVE / PARTIAL / OFFLINE).
 * - Expandable Empirical Strategy panel: 3 rules + clickable outlet-links grid.
 * - Each live headline has a Sparkles "Analyze with Merlin" action that calls
 *   onAnalyze(prompt) — the page wires it into the Geo Risk Specialist panel.
 *
 * Tactical-HUD aesthetic: glass-panel, clip-corner, corner brackets, monospace.
 */
import { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Sparkles, ChevronDown, ChevronUp, ShieldCheck, ExternalLink, Newspaper } from 'lucide-react';
import { TRUSTED_SOURCES, EMPIRICAL_RULES, CATEGORY_META, buildHeadlinePrompt } from '@/lib/geo/trustedNews';
import TopStoriesBySource from '@/components/geo/TopStoriesBySource';

const STATUS_META = {
  live: { label: 'LIVE', color: '#3fb950' },
  partial: { label: 'PARTIAL', color: '#FF9F00' },
  unavailable: { label: 'OFFLINE', color: '#8b949e' },
  loading: { label: 'SYNC', color: '#4dd0e1' },
};

export default function TrustedNewsTicker({ onAnalyze }) {
  const [headlines, setHeadlines] = useState([]);
  const [status, setStatus] = useState('loading');
  const [expanded, setExpanded] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = (e) => setReducedMotion(e.matches);
    mq.addEventListener?.('change', handler);
    return () => mq.removeEventListener?.('change', handler);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const res = await base44.functions.invoke('trustedNewsFeed', {});
        const d = res.data || res;
        if (cancelled) return;
        setHeadlines(d.headlines || []);
        setStatus(d.status || (d.headlines?.length ? 'live' : 'unavailable'));
      } catch {
        if (!cancelled) { setHeadlines([]); setStatus('unavailable'); }
      }
    };
    load();
    const id = setInterval(load, 300000);
    return () => { cancelled = true; clearInterval(id); };
  }, []);

  const tickerItems = useMemo(() => {
    // Interleave live headlines with curated source labels — a mixed stream
    const items = [];
    const hLen = headlines.length;
    const sLen = TRUSTED_SOURCES.length;
    const max = Math.max(hLen, sLen);
    for (let i = 0; i < max; i++) {
      if (i < hLen) items.push({ kind: 'headline', ...headlines[i] });
      if (i < sLen) items.push({ kind: 'source', ...TRUSTED_SOURCES[i] });
    }
    return items;
  }, [headlines]);

  const handleAnalyze = (item) => {
    const prompt = buildHeadlinePrompt(item);
    if (onAnalyze) onAnalyze(prompt);
    else window.dispatchEvent(new CustomEvent('merlin-analyze', { detail: { prompt } }));
  };

  const stat = STATUS_META[status] || STATUS_META.unavailable;
  const pulse = status === 'live' || status === 'partial';

  return (
    <div className="mt-4">
      <div className="tactical-hud glass-panel clip-corner overflow-hidden">
        {/* Ticker bar */}
        <div className="flex items-stretch">
          {/* Label / status */}
          <div className="flex items-center gap-2 px-3 py-2 border-r border-[#30363d] bg-[#0a0d11] shrink-0 min-w-[120px]">
            <ShieldCheck size={14} style={{ color: stat.color }} className="shrink-0" />
            <div className="flex flex-col leading-none">
              <span className="text-[9px] font-bold text-[#e6edf3] uppercase tracking-wider">Trusted News</span>
              <span className="text-[7px] uppercase tracking-wider mt-1 flex items-center gap-1" style={{ color: stat.color }}>
                <span className={`w-1.5 h-1.5 rounded-full ${pulse ? 'glow-pulse' : ''}`} style={{ background: stat.color }} />
                {stat.label}
              </span>
            </div>
          </div>

          {/* Marquee */}
          <div className="flex-1 overflow-hidden relative">
            {reducedMotion ? (
              <div className="flex items-center gap-4 px-3 py-2 overflow-x-auto whitespace-nowrap">
                {tickerItems.map((it, i) => <TickerItem key={i} item={it} onAnalyze={handleAnalyze} />)}
              </div>
            ) : (
              <div className="relative flex items-center h-full">
                <div className="flex items-center gap-4 px-3 py-2 whitespace-nowrap w-max ticker-marquee">
                  {[...tickerItems, ...tickerItems].map((it, i) => <TickerItem key={i} item={it} onAnalyze={handleAnalyze} />)}
                </div>
              </div>
            )}
          </div>

          {/* Expand toggle */}
          <button
            onClick={() => setExpanded((e) => !e)}
            className="flex items-center gap-1 px-3 py-2 border-l border-[#30363d] bg-[#0a0d11] text-[#8b949e] hover:text-[#00f5ff] transition-colors shrink-0 min-h-[44px]"
            aria-label={expanded ? 'Collapse empirical strategy' : 'Expand empirical strategy'}
          >
            {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            <span className="text-[8px] uppercase tracking-wider hidden sm:inline">Strategy</span>
          </button>
        </div>

        {/* Expanded empirical strategy panel */}
        {expanded && (
          <div className="border-t border-[#30363d] p-4 fade-in">
            <div className="grid lg:grid-cols-2 gap-4">
              {/* Rules */}
              <div>
                <div className="text-[10px] font-bold text-[#00f5ff] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <ShieldCheck size={11} /> Empirical Strategy
                </div>
                <div className="space-y-2">
                  {EMPIRICAL_RULES.map((r, i) => (
                    <div key={i} className="bg-[#0d1117] border border-[#30363d] rounded p-2">
                      <div className="text-[10px] font-bold text-[#e6edf3]">{i + 1}. {r.title}</div>
                      <div className="text-[9px] text-[#8b949e] mt-0.5 leading-relaxed">{r.rationale}</div>
                    </div>
                  ))}
                </div>
                <div className="text-[8px] text-[#484f58] mt-2 italic">
                  Ratings per AllSides, Ad Fontes Media, and Media Bias/Fact Check (2026).
                </div>
              </div>

              {/* Outlet links grid */}
              <div>
                <div className="text-[10px] font-bold text-[#00f5ff] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Newspaper size={11} /> 13 Trusted Outlets
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {TRUSTED_SOURCES.map((s) => {
                    const cat = CATEGORY_META[s.category] || FALLBACK_CAT;
                    return (
                      <a key={s.id} href={s.url} target="_blank" rel="noopener noreferrer"
                        className="flex items-start gap-1.5 p-1.5 border border-[#30363d] bg-[#0d1117] rounded hover:border-[#00f5ff]/40 transition-colors group">
                        <span className="w-1.5 h-1.5 rounded-full shrink-0 mt-1" style={{ background: cat.color }} />
                        <div className="min-w-0">
                          <div className="text-[9px] font-bold text-[#e6edf3] group-hover:text-[#00f5ff] truncate flex items-center gap-1">
                            <span className="truncate">{s.name}</span> <ExternalLink size={8} className="shrink-0 opacity-50" />
                          </div>
                          <div className="text-[7px] text-[#484f58] truncate">{cat.label}</div>
                        </div>
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <TopStoriesBySource headlines={headlines} />
    </div>
  );
}

const FALLBACK_CAT = { short: 'NEWS', color: '#8b949e', label: 'Unknown' };

function TickerItem({ item, onAnalyze }) {
  const cat = CATEGORY_META[item.category] || FALLBACK_CAT;
  const chip = (
    <span className="px-1.5 py-0.5 rounded font-bold uppercase tracking-wider text-[7px] shrink-0"
      style={{ background: `${cat.color}20`, color: cat.color, border: `1px solid ${cat.color}40` }}>
      {cat.short}
    </span>
  );

  if (item.kind === 'headline') {
    return (
      <span className="inline-flex items-center gap-2 text-[10px]">
        {chip}
        <span className="text-[#8b949e] font-bold shrink-0">{item.outlet}</span>
        <a href={item.url || '#'} target="_blank" rel="noopener noreferrer"
          className="text-[#e6edf3] hover:text-[#00f5ff] transition-colors truncate max-w-[280px]" title={item.title}>
          {item.title}
        </a>
        <button onClick={() => onAnalyze(item)} title="Analyze with Merlin"
          className="text-[#FF9F00] hover:brightness-125 transition-all flex items-center shrink-0 min-h-[28px] min-w-[28px] justify-center">
          <Sparkles size={11} />
        </button>
        <span className="text-[#30363d] shrink-0">|</span>
      </span>
    );
  }

  // curated source label
  return (
    <span className="inline-flex items-center gap-2 text-[10px]">
      {chip}
      <a href={item.url} target="_blank" rel="noopener noreferrer"
        className="text-[#e6edf3] hover:text-[#00f5ff] transition-colors font-bold shrink-0">{item.name}</a>
      <span className="text-[#484f58] truncate max-w-[220px]">— {item.trustTag}</span>
      <span className="text-[#30363d] shrink-0">|</span>
    </span>
  );
}