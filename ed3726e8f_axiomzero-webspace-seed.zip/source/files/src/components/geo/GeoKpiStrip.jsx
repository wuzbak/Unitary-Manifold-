/**
 * GeoKpiStrip — global situational KPI strip above the map.
 * Tactical-HUD framed: corner brackets, scanline, sectioned dividers, and
 * live-pulse on active/elevated indicators. Cells: Active Events, family
 * counts, Regions, Severe Wx, Live Aircraft, Space-Weather Storm Level,
 * Supply-Chain Chokepoints, Highest Severity spotlight, Watchlist Hits,
 * and Freshness. Pure presentational — derives from props only.
 */
import { Activity, AlertTriangle, Globe2, Zap, Eye, Clock, Plane, Satellite, Anchor, Megaphone, Swords, Ship } from 'lucide-react';
import { FEEDS, TYPE_TO_FEED } from '@/lib/geoFeeds';

const SEVERITY_RANK = { severe: 3, moderate: 2, minor: 1 };

function familyCounts(events) {
  const c = {};
  events.forEach((e) => {
    const fk = TYPE_TO_FEED[e.type] || e.type;
    c[fk] = (c[fk] || 0) + 1;
  });
  return c;
}

function highestSeveritySpotlight(events) {
  let best = null;
  let bestScore = -1;
  events.forEach((e) => {
    const sev = SEVERITY_RANK[e.severity] || 0;
    const mag = typeof e.magnitude === 'number' ? e.magnitude : 0;
    const score = sev * 1000 + mag;
    if (sev >= 2 && score > bestScore) { best = e; bestScore = score; }
  });
  return best;
}

export default function GeoKpiStrip({ events, lastUpdated, watchlistHits = [], aircraftCount = 0, milAircraftCount = 0, civilUnrestCount = 0, conflictCount = 0, vesselCount = 0, spaceWeatherStorm, chokepointCount = 0 }) {
  const total = events.length;
  const counts = familyCounts(events);
  const spotlight = highestSeveritySpotlight(events);
  const regions = new Set(events.map((e) => e.region).filter(Boolean));
  const severeWeather = events.filter((e) => e.type === 'nwsAlert' && e.severity === 'severe').length;

  const topFamilies = Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([key, n]) => ({ key, n, feed: FEEDS[key] }))
    .filter((f) => f.feed);

  const stormActive = spaceWeatherStorm && spaceWeatherStorm.level !== 'Quiet' && spaceWeatherStorm.level !== '—';

  return (
    <div className="tactical-hud glass-panel clip-corner p-2.5 mb-4">
      <div className="hud-scanline">
        <div className="flex items-center gap-2 overflow-x-auto relative z-[2]">
          {/* Total */}
          <div className="flex items-center gap-2 shrink-0 pr-3 hud-divider-r">
            <Activity size={16} className="text-[#00f5ff] glow-pulse" />
            <div>
              <div className="text-lg font-bold text-[#00f5ff] leading-none font-mono">{total}</div>
              <div className="text-[8px] text-[#484f58] uppercase tracking-wider">Active Events</div>
            </div>
          </div>

          {/* Family counts */}
          <div className="flex items-center gap-2 shrink-0 pr-3 hud-divider-r">
            {topFamilies.map((f) => (
              <div key={f.key} className="flex items-center gap-1.5 shrink-0">
                <span className="text-sm">{f.feed.icon}</span>
                <span className="text-xs font-bold text-[#e6edf3] font-mono">{f.n}</span>
                <span className="text-[8px] text-[#484f58] uppercase tracking-wider hidden lg:inline">{f.feed.label.split(' ')[0]}</span>
              </div>
            ))}
          </div>

          {/* Regions */}
          <div className="flex items-center gap-1.5 shrink-0 px-3 hud-divider-r">
            <Globe2 size={13} className="text-[#4dd0e1]" />
            <span className="text-xs font-bold text-[#4dd0e1] font-mono">{regions.size}</span>
            <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Regions</span>
          </div>

          {/* Severe weather */}
          {severeWeather > 0 && (
            <div className="flex items-center gap-1.5 shrink-0 px-3 hud-divider-r">
              <Zap size={13} className="text-[#ffd60a] glow-pulse" />
              <span className="text-xs font-bold text-[#ffd60a] font-mono">{severeWeather}</span>
              <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Severe Wx</span>
            </div>
          )}

          {/* Live Aircraft */}
          <div className="flex items-center gap-1.5 shrink-0 px-3 hud-divider-r">
            <Plane size={13} className="text-[#4dd0e1]" />
            <span className="text-xs font-bold text-[#4dd0e1] font-mono">{aircraftCount}</span>
            <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Aircraft</span>
          </div>

          {/* Military Aircraft */}
          {milAircraftCount > 0 && (
            <div className="flex items-center gap-1.5 shrink-0 px-3 hud-divider-r">
              <Plane size={13} className="text-[#ff9f0a] glow-pulse" />
              <span className="text-xs font-bold text-[#ff9f0a] font-mono">{milAircraftCount}</span>
              <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Mil Aircraft</span>
            </div>
          )}

          {/* Civil Unrest */}
          {civilUnrestCount > 0 && (
            <div className="flex items-center gap-1.5 shrink-0 px-3 hud-divider-r">
              <Megaphone size={13} className="text-[#ff9f0a] glow-pulse" />
              <span className="text-xs font-bold text-[#ff9f0a] font-mono">{civilUnrestCount}</span>
              <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Unrest</span>
            </div>
          )}

          {/* Conflict */}
          {conflictCount > 0 && (
            <div className="flex items-center gap-1.5 shrink-0 px-3 hud-divider-r">
              <Swords size={13} className="text-[#ff6b6b] glow-pulse" />
              <span className="text-xs font-bold text-[#ff6b6b] font-mono">{conflictCount}</span>
              <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Conflict</span>
            </div>
          )}

          {/* Vessels */}
          {vesselCount > 0 && (
            <div className="flex items-center gap-1.5 shrink-0 px-3 hud-divider-r">
              <Ship size={13} className="text-[#4dd0e1]" />
              <span className="text-xs font-bold text-[#4dd0e1] font-mono">{vesselCount}</span>
              <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Vessels</span>
            </div>
          )}

          {/* Space-Weather Storm Level */}
          <div className="flex items-center gap-1.5 shrink-0 px-3 hud-divider-r">
            <Satellite size={13} style={{ color: spaceWeatherStorm?.color || '#8b949e' }} className={stormActive ? 'glow-pulse' : ''} />
            <div>
              <div className="text-xs font-bold font-mono leading-none" style={{ color: spaceWeatherStorm?.color || '#8b949e' }}>{spaceWeatherStorm?.level || '—'}</div>
              <div className="text-[8px] text-[#484f58] uppercase tracking-wider">Space Wx</div>
            </div>
          </div>

          {/* Supply-Chain Chokepoints */}
          <div className="flex items-center gap-1.5 shrink-0 px-3 hud-divider-r">
            <Anchor size={13} className="text-[#ff9f0a]" />
            <span className="text-xs font-bold text-[#ff9f0a] font-mono">{chokepointCount}</span>
            <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Chokepoints</span>
          </div>

          {/* Spotlight */}
          {spotlight && (
            <div className="flex items-center gap-2 shrink-0 px-3 hud-divider-r min-w-0">
              <AlertTriangle size={13} className="text-[#ff6b6b] shrink-0 glow-pulse" />
              <div className="min-w-0">
                <div className="text-[9px] text-[#ff6b6b] font-bold uppercase tracking-wider leading-none mb-0.5">Highest Severity</div>
                <div className="text-[10px] text-[#e6edf3] truncate max-w-[180px]">{spotlight.title}</div>
                <div className="text-[8px] text-[#484f58]">
                  {typeof spotlight.magnitude === 'number' ? `M${spotlight.magnitude} · ` : ''}{spotlight.region || 'Unknown'}
                </div>
              </div>
            </div>
          )}

          {/* Watchlist hits */}
          {watchlistHits.length > 0 && (
            <div className="flex items-center gap-2 shrink-0 px-3 hud-divider-r">
              <Eye size={13} className="text-[#ff9f0a] glow-pulse" />
              <div>
                <div className="text-xs font-bold text-[#ff9f0a] leading-none font-mono">{watchlistHits.length}</div>
                <div className="text-[8px] text-[#484f58] uppercase tracking-wider">Watchlist Hits</div>
              </div>
            </div>
          )}

          {/* Freshness */}
          {lastUpdated && (
            <div className="flex items-center gap-1.5 shrink-0 px-3 ml-auto">
              <span className="w-1.5 h-1.5 rounded-full bg-[#30d158] glow-pulse" />
              <Clock size={11} className="text-[#30d158]" />
              <span className="text-[9px] text-[#484f58] font-mono">{lastUpdated.toLocaleTimeString()}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}