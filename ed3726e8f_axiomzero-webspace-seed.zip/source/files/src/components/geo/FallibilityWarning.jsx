import { ShieldAlert } from 'lucide-react';

export default function FallibilityWarning() {
  return (
    <div className="glass-strong clip-corner p-3 mb-4 border border-[#FF9F00]/40 flex items-start gap-3">
      <ShieldAlert size={16} className="text-[#FF9F00] shrink-0 mt-0.5" />
      <div className="text-[10px] text-[#8b949e] leading-relaxed">
        <span className="text-[#FF9F00] font-bold">OPEN SCIENCE ARTIFACT — FALLIBILITY WARNING.</span>{' '}
        All data on this page is sourced from open, community, and government feeds (USGS, NASA, NOAA, EPA, OpenSky, ADSB.lol).
        These are real-time open-science artifacts — they may contain gaps, delays, or errors inherent to crowdsourced and automated systems.
        <span className="text-[#e6edf3]"> All data should be independently proofed before any critical decision.</span>{' '}
        Treat this console as a situational-awareness tool, not a definitive source.
      </div>
    </div>
  );
}