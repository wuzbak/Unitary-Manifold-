/**
 * WeatherPanel — Live local weather + emergency NWS alerts.
 *
 * Two buttons: Local Weather (agWeatherReport) and Emergency Alerts (nwsAlerts).
 * Auto-refresh with stale-data fallback. Live "last updated" timestamps.
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { CloudRain, AlertTriangle, Loader2, RefreshCw, Thermometer, Droplets, Wind, Calendar, Cloud } from 'lucide-react';
import UnavailableCard from '@/components/shared/UnavailableCard';

const SEVERITY_COLORS = {
  extreme: { bg: '#7c1d1d', text: '#ff6b6b', border: '#ff6b6b' },
  severe: { bg: '#7c3a00', text: '#ff9f0a', border: '#ff9f0a' },
  moderate: { bg: '#7c5a00', text: '#ffd60a', border: '#ffd60a' },
  minor: { bg: '#1a3a1a', text: '#30d158', border: '#30d158' },
  unknown: { bg: '#1a1a2e', text: '#8b949e', border: '#30363d' },
};

export default function WeatherPanel() {
  const [activePanel, setActivePanel] = useState('local');
  const [weather, setWeather] = useState(null);
  const [weatherLoading, setWeatherLoading] = useState(false);
  const [weatherError, setWeatherError] = useState(null);
  const [weatherUpdated, setWeatherUpdated] = useState(null);
  const [alerts, setAlerts] = useState(null);
  const [alertsLoading, setAlertsLoading] = useState(false);
  const [alertsError, setAlertsError] = useState(null);
  const [alertsUpdated, setAlertsUpdated] = useState(null);
  const [location, setLocation] = useState('');

  const fetchWeather = useCallback(async (loc) => {
    if (!loc || !loc.trim()) return;
    setWeatherLoading(true);
    setWeatherError(null);
    try {
      const res = await base44.functions.invoke('agWeatherReport', { location: loc });
      const d = res.data || res;
      if (d.status && d.status !== 'ok') {
        setWeatherError(d.message || 'Weather data unavailable');
      } else {
        setWeather(d);
        setWeatherUpdated(new Date());
      }
    } catch (e) {
      setWeatherError(e.message || 'Failed to fetch weather');
    }
    setWeatherLoading(false);
  }, []);

  const fetchAlerts = useCallback(async () => {
    setAlertsLoading(true);
    setAlertsError(null);
    try {
      const res = await base44.functions.invoke('nwsAlerts', {});
      const d = res.data || res;
      if (d.status && d.status !== 'ok') {
        setAlertsError(d.message || 'Alerts unavailable');
      } else {
        setAlerts(d);
        setAlertsUpdated(new Date());
      }
    } catch (e) {
      setAlertsError(e.message || 'Failed to fetch alerts');
    }
    setAlertsLoading(false);
  }, []);

  // Auto-refresh: weather every 5 min, alerts every 2 min
  useEffect(() => {
    if (activePanel === 'local' && location.trim() && !weather) {
      fetchWeather(location);
    }
    if (activePanel === 'emergency' && !alerts) {
      fetchAlerts();
    }
  }, [activePanel]);

  useEffect(() => {
    if (!location.trim()) return;
    const interval = setInterval(() => fetchWeather(location), 300000);
    return () => clearInterval(interval);
  }, [location, fetchWeather]);

  useEffect(() => {
    if (activePanel !== 'emergency') return;
    const interval = setInterval(fetchAlerts, 120000);
    return () => clearInterval(interval);
  }, [activePanel, fetchAlerts]);

  const useMyLocation = () => {
    if (!navigator.geolocation) {
      setWeatherError('Geolocation not available. Enter a city or ZIP manually.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const loc = `${pos.coords.latitude.toFixed(3)},${pos.coords.longitude.toFixed(3)}`;
        setLocation(loc);
        fetchWeather(loc);
      },
      () => setWeatherError('Geolocation denied. Enter a location manually.')
    );
  };

  return (
    <div className="glass-panel clip-corner p-3">
      <div className="flex items-center gap-2 mb-3">
        <div className="flex gap-1.5">
          <button
            onClick={() => setActivePanel('local')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-bold transition-colors ${activePanel === 'local' ? 'bg-[#4dd0e1] text-black' : 'bg-[#161b22] border border-[#30363d] text-[#8b949e]'}`}
          >
            <CloudRain size={11} /> Local Weather
          </button>
          <button
            onClick={() => { setActivePanel('emergency'); if (!alerts) fetchAlerts(); }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-bold transition-colors ${activePanel === 'emergency' ? 'bg-[#ff6b6b] text-black' : 'bg-[#161b22] border border-[#30363d] text-[#8b949e]'}`}
          >
            <AlertTriangle size={11} /> Emergency Alerts
          </button>
        </div>
      </div>

      {activePanel === 'local' && (
        <div className="space-y-2">
          <div className="flex gap-1.5">
            <input
              type="text"
              value={location}
              onChange={e => setLocation(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && fetchWeather(location)}
              placeholder="City, ZIP, or lat,lon (e.g. 47.74,-121.98)"
              className="flex-1 bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] focus:border-[#4dd0e1]/40 focus:outline-none"
            />
            <button onClick={() => fetchWeather(location)} disabled={weatherLoading || !location.trim()} className="px-2 py-1.5 bg-[#4dd0e1]/20 border border-[#4dd0e1]/40 text-[#4dd0e1] rounded text-[10px] font-bold disabled:opacity-50 flex items-center gap-1">
              {weatherLoading ? <Loader2 size={10} className="animate-spin" /> : <RefreshCw size={10} />} Fetch
            </button>
            <button onClick={useMyLocation} className="px-2 py-1.5 bg-[#161b22] border border-[#30363d] text-[#8b949e] rounded text-[10px] font-bold hover:text-[#4dd0e1]">GPS</button>
          </div>

          {weatherLoading && (
            <div className="flex items-center justify-center py-6 gap-2 text-[10px] text-[#8b949e]">
              <Loader2 size={12} className="animate-spin text-[#4dd0e1]" /> Fetching live weather (Open-Meteo + NOAA NWS)...
            </div>
          )}
          {weatherError && (
            <UnavailableCard message={weatherError} onRetry={() => fetchWeather(location)} compact />
          )}
          {weather && !weatherLoading && !weatherError && (
            <div className="space-y-2 fade-in">
              <div className="flex items-center justify-between">
                <div className="text-[10px] text-[#e6edf3] font-bold">{weather.location?.name || location}</div>
                {weatherUpdated && <div className="text-[8px] text-[#484f58] flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-[#30d158] glow-pulse" /> {weatherUpdated.toLocaleTimeString()}</div>}
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                <div className="bg-[#0d1117] border border-[#30363d] rounded p-1.5 text-center">
                  <Thermometer size={10} className="text-[#ff9f0a] mx-auto mb-0.5" />
                  <div className="text-[9px] text-[#484f58]">Zone</div>
                  <div className="text-[11px] font-bold text-[#4dd0e1]">{weather.zone || '—'}</div>
                </div>
                <div className="bg-[#0d1117] border border-[#30363d] rounded p-1.5 text-center">
                  <Droplets size={10} className="text-[#4dd0e1] mx-auto mb-0.5" />
                  <div className="text-[9px] text-[#484f58]">Drought</div>
                  <div className="text-[11px] font-bold text-[#e6edf3]">{weather.drought?.status || '—'}</div>
                </div>
                <div className="bg-[#0d1117] border border-[#30363d] rounded p-1.5 text-center">
                  <Calendar size={10} className="text-[#30d158] mx-auto mb-0.5" />
                  <div className="text-[9px] text-[#484f58]">Grow Days</div>
                  <div className="text-[11px] font-bold text-[#30d158]">{weather.frostDates?.growingDays || '—'}</div>
                </div>
                <div className="bg-[#0d1117] border border-[#30363d] rounded p-1.5 text-center">
                  <Cloud size={10} className="text-[#8b949e] mx-auto mb-0.5" />
                  <div className="text-[9px] text-[#484f58]">Precip</div>
                  <div className="text-[11px] font-bold text-[#e6edf3]">{weather.drought?.totalPrecip || '—'}mm</div>
                </div>
              </div>
              {weather.forecast7Day?.length > 0 && (
                <div className="bg-[#0d1117] border border-[#30363d] rounded p-2">
                  <div className="text-[9px] text-[#484f58] uppercase mb-1">7-Day Forecast</div>
                  <div className="flex gap-1 overflow-x-auto">
                    {weather.forecast7Day.slice(0, 7).map((f, i) => (
                      <div key={i} className="text-center min-w-[40px] shrink-0">
                        <div className="text-[8px] text-[#484f58]">{f.date?.substring(5)}</div>
                        <div className="text-[10px] font-bold text-[#ff9f0a]">{f.tempMax}°</div>
                        <div className="text-[8px] text-[#4dd0e1]">{f.tempMin}°</div>
                        <div className="text-[7px] text-[#30d158]">{f.precip}mm</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {weather.alerts?.length > 0 && (
                <div className="bg-[#7c3a00]/20 border border-[#ff9f0a]/30 rounded p-2">
                  <div className="text-[9px] text-[#ff9f0a] font-bold mb-1">⚠ {weather.alerts.length} Active Alert(s)</div>
                  {weather.alerts.slice(0, 3).map((a, i) => (
                    <div key={i} className="text-[9px] text-[#e6edf3] mb-0.5">• {a.title || a.event}</div>
                  ))}
                </div>
              )}
              <div className="text-[8px] text-[#484f58] flex items-center gap-1">
                <Wind size={8} /> Sources: {weather.sources?.forecast || 'Open-Meteo'} · {weather.sources?.alerts || 'NOAA NWS'} · auto-refresh 5min
              </div>
            </div>
          )}
          {!weather && !weatherLoading && !weatherError && (
            <div className="text-[10px] text-[#484f58] py-4 text-center">Enter a location above to fetch live weather data.</div>
          )}
        </div>
      )}

      {activePanel === 'emergency' && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-[10px] text-[#8b949e]">Active NWS alerts (all US regions)</div>
            <button onClick={fetchAlerts} disabled={alertsLoading} className="px-2 py-1 bg-[#ff6b6b]/20 border border-[#ff6b6b]/40 text-[#ff6b6b] rounded text-[9px] font-bold disabled:opacity-50 flex items-center gap-1">
              {alertsLoading ? <Loader2 size={9} className="animate-spin" /> : <RefreshCw size={9} />} Refresh
            </button>
          </div>
          {alertsLoading && (
            <div className="flex items-center justify-center py-6 gap-2 text-[10px] text-[#8b949e]">
              <Loader2 size={12} className="animate-spin text-[#ff6b6b]" /> Fetching active NWS alerts...
            </div>
          )}
          {alertsError && (
            <UnavailableCard message={alertsError} onRetry={fetchAlerts} compact />
          )}
          {alerts && !alertsLoading && !alertsError && (
            <div className="space-y-1.5 max-h-[300px] overflow-y-auto fade-in">
              {alertsUpdated && <div className="text-[8px] text-[#484f58] flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-[#ff6b6b] glow-pulse" /> Last sync: {alertsUpdated.toLocaleTimeString()} · auto-refresh 2min</div>}
              {alerts.count === 0 ? (
                <div className="text-[10px] text-[#30d158] py-4 text-center">✓ No active alerts. All clear.</div>
              ) : (
                alerts.alerts.slice(0, 30).map(a => {
                  const sc = SEVERITY_COLORS[a.severity] || SEVERITY_COLORS.unknown;
                  return (
                    <div key={a.id} className="rounded p-2 border" style={{ background: `${sc.bg}30`, borderColor: `${sc.border}40` }}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-bold" style={{ color: sc.text }}>{a.title}</span>
                        <span className="text-[8px] px-1.5 py-0.5 rounded font-bold" style={{ color: sc.text, border: `1px solid ${sc.border}40` }}>{a.severity?.toUpperCase()}</span>
                      </div>
                      <div className="text-[9px] text-[#8b949e] mb-1">📍 {a.area}</div>
                      {a.headline && <div className="text-[9px] text-[#e6edf3] mb-1">{a.headline}</div>}
                      {a.instruction && <div className="text-[9px] text-[#4dd0e1] mt-1">📋 {a.instruction.substring(0, 200)}{a.instruction.length > 200 ? '...' : ''}</div>}
                      <div className="text-[8px] text-[#484f58] mt-1">Expires: {a.expires ? new Date(a.expires).toLocaleString() : 'N/A'}</div>
                    </div>
                  );
                })
              )}
              <div className="text-[8px] text-[#484f58] pt-1">Source: {alerts.source} · {alerts.count} total alerts</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}