/**
 * GridStressPanel — dedicated console panel for EIA near-real-time electricity
 * demand + interchange, rendered as a relative grid-stress indicator.
 * Honest labeling: "grid stress" not "grid collapse" — no public free API
 * exists for live outage status. Severe-weather alert count passed in as
 * grid-threat context. UM pillar: P786 — Climatic Flux.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Zap, AlertTriangle, Loader2, RefreshCw } from 'lucide-react';
import UnavailableCard from '@/components/shared/UnavailableCard';

export default function GridStressPanel({ severeWeatherCount = 0 }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('eiaGrid', {});
      const d = res.data || res;
      if (d.status && d.status !== 'ok') setError(d.message || 'Grid data unavailable');
      else setData(d);
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
    const id = setInterval(load, 300000); // 5 min — EIA data is hourly
    return () => clearInterval(id);
  }, []);

  const totalDemand = data?.totalDemand || 0;
  const stressedRegions = (data?.regions || [])
    .filter((r) => r.loadLevel > 0.7 || r.interchangeStress > 2000)
    .sort((a, b) => b.loadLevel - a.loadLevel);

  return (
    <div className="glass-panel clip-corner p-3">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-1.5">
          <Zap size={14} className="text-[#ffd60a]" />
          <span className="text-xs font-bold text-[#ffd60a] uppercase tracking-wider">Grid Stress</span>
          <span className="text-[9px] text-[#484f58]">EIA · P786</span>
        </div>
        <button onClick={load} className="text-[#484f58] hover:text-[#e6edf3] min-h-[32px] min-w-[32px] flex items-center justify-center"><RefreshCw size={11} /></button>
      </div>

      {loading && !data ? (
        <div className="flex items-center justify-center py-6"><Loader2 size={16} className="animate-spin text-[#ffd60a]" /></div>
      ) : error ? (
        <UnavailableCard message={error} onRetry={load} compact />
      ) : (
        <div className="space-y-3">
          <div className="bg-[#0d1117] border border-[#30363d] rounded p-2">
            <div className="text-[9px] text-[#8b949e] uppercase mb-1">US Electricity Demand (latest hour)</div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-[#ffd60a]">{(totalDemand / 1000).toFixed(1)}</span>
              <span className="text-[10px] text-[#8b949e]">GW · {data?.regions?.length || 0} regions</span>
            </div>
            {data?.period && <div className="text-[9px] text-[#484f58] font-mono">{data.period} UTC</div>}
          </div>

          <div>
            <div className="text-[9px] text-[#8b949e] uppercase mb-1">High-Stress Regions</div>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {stressedRegions.length ? stressedRegions.slice(0, 8).map((r) => (
                <div key={r.region} className="bg-[#0d1117] border border-[#30363d] rounded px-2 py-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-[#e6edf3] font-bold">{r.region}</span>
                    <span className="text-[9px] font-mono" style={{ color: r.loadLevel > 0.85 ? '#ff6b6b' : '#ff9f0a' }}>
                      {((r.demand || 0) / 1000).toFixed(1)} GW
                    </span>
                  </div>
                  <div className="mt-1 h-1.5 bg-[#161b22] rounded overflow-hidden">
                    <div className="h-full" style={{ width: `${r.loadLevel * 100}%`, background: r.loadLevel > 0.85 ? '#ff6b6b' : '#ff9f0a' }} />
                  </div>
                  {r.interchange != null && (
                    <div className="text-[8px] text-[#484f58] mt-0.5">
                      Interchange: {r.interchange > 0 ? '+' : ''}{(r.interchange / 1000).toFixed(2)} GW {r.interchange < 0 ? '(importing)' : '(exporting)'}
                    </div>
                  )}
                </div>
              )) : <div className="text-[9px] text-[#484f58]">No regions at elevated stress</div>}
            </div>
          </div>

          {severeWeatherCount > 0 && (
            <div className="flex items-center gap-1.5 text-[9px] text-[#ff9f0a] bg-[#ff9f0a]/5 border border-[#ff9f0a]/20 rounded px-2 py-1">
              <AlertTriangle size={10} /> {severeWeatherCount} active severe-weather alerts may impact grid infrastructure
            </div>
          )}

          <div className="text-[8px] text-[#484f58] leading-relaxed border-t border-[#30363d] pt-2">
            Relative demand & interchange-imbalance indicator from EIA hourly data. Not a real-time outage map — no public free API exists for live grid-collapse status.
          </div>
        </div>
      )}
    </div>
  );
}