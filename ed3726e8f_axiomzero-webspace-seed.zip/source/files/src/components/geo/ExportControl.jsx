/**
 * ExportControl — client-side JSON/CSV export of the current filtered event set.
 * Includes event coordinates, raw fields, computed overlay quantities, pillar
 * sources, and epistemic labels. Works for both disaster events and supply-chain
 * records. No backend round-trip — pure Blob download.
 */
import { useState, useRef } from 'react';
import { Download, FileJson, FileSpreadsheet, ChevronDown, Upload, Settings } from 'lucide-react';

function toCSV(events) {
  if (!events.length) return '';
  const keys = ['id', 'type', 'title', 'magnitude', 'coords', 'place', 'time', 'region', 'source', 'severity',
    'overlay_kind', 'overlay_E_si', 'overlay_E_planck', 'overlay_phiDebt', 'overlay_phiAlignment',
    'overlay_radionAmp', 'overlay_suppression', 'overlay_basinPert', 'overlay_windingStab',
    'overlay_wALocal', 'overlay_confidence', 'overlay_epistemicLabel'];
  const escape = (v) => {
    if (v == null) return '';
    const s = String(v);
    if (s.includes(',') || s.includes('"') || s.includes('\n')) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  const rows = [keys.join(',')];
  for (const e of events) {
    const o = e.overlay || {};
    const vals = {
      id: e.id, type: e.type, title: e.title, magnitude: e.magnitude,
      coords: e.coords ? `${e.coords[0]},${e.coords[1]}` : '',
      place: e.place, time: e.time, region: e.region, source: e.source, severity: e.severity,
      overlay_kind: o.kind, overlay_E_si: o.E_si, overlay_E_planck: o.E_planck,
      overlay_phiDebt: o.phiDebt, overlay_phiAlignment: o.phiAlignment,
      overlay_radionAmp: o.radionAmp, overlay_suppression: o.suppression,
      overlay_basinPert: o.basinPert, overlay_windingStab: o.windingStab,
      overlay_wALocal: o.wALocal, overlay_confidence: o.confidence,
      overlay_epistemicLabel: o.epistemicLabel,
    };
    rows.push(keys.map((k) => escape(vals[k])).join(','));
  }
  return rows.join('\n');
}

function download(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export default function ExportControl({ events, supplyChainRecords = [], configBundle, onImportConfig }) {
  const [open, setOpen] = useState(false);
  const [importError, setImportError] = useState(null);
  const fileRef = useRef(null);

  const allRecords = [...events, ...supplyChainRecords];
  const ts = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');

  const exportConfig = () => {
    const payload = {
      type: 'geo-monitor-config',
      exportedAt: new Date().toISOString(),
      config: configBundle || {},
    };
    download(JSON.stringify(payload, null, 2), `geo-monitor-config-${ts}.json`, 'application/json');
    setOpen(false);
  };

  const handleImportFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportError(null);
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        const cfg = parsed?.config || parsed;
        if (!cfg || (typeof cfg !== 'object')) throw new Error('No config object found');
        if (!cfg.activeFeeds && !cfg.filters && !cfg.basemap) throw new Error('Not a Geo Monitor config file');
        onImportConfig?.(cfg);
        setOpen(false);
      } catch (err) {
        setImportError(err.message || 'Invalid config file');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const exportJSON = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      source: 'UM Geophysical Monitor v4 — 12-AZ-IP/21-geo-monitor',
      epistemicNote: 'UM overlay metrics are 🔵 ADJACENT TRACK — not hardgate physics claims',
      eventCount: events.length,
      supplyChainCount: supplyChainRecords.length,
      events: allRecords.map((e) => ({ ...e, overlay: e.overlay || null })),
    };
    download(JSON.stringify(payload, null, 2), `geo-monitor-export-${ts}.json`, 'application/json');
    setOpen(false);
  };

  const exportCSV = () => {
    download(toCSV(allRecords), `geo-monitor-export-${ts}.csv`, 'text/csv');
    setOpen(false);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="glass-strong clip-corner px-3 py-2 text-[10px] font-bold tracking-wide flex items-center gap-1.5 text-[#8b949e] hover:text-[#e6edf3] border border-[#30363d] transition-all min-h-[36px]"
      >
        <Download size={12} /> Export
        <span className="text-[8px] text-[#484f58]">({allRecords.length})</span>
        <ChevronDown size={10} className={open ? 'rotate-180 transition-transform' : 'transition-transform'} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-[399]" onClick={() => setOpen(false)} />
          <div className="absolute top-full right-0 mt-1 w-44 glass-strong clip-corner overflow-hidden z-[400] fade-in">
            <button
              onClick={exportJSON}
              className="w-full flex items-center gap-2 px-3 py-2.5 text-xs text-[#e6edf3] hover:bg-[#00f5ff]/10 transition-colors border-b border-[#30363d]"
            >
              <FileJson size={13} className="text-[#4dd0e1]" /> JSON (full + overlay)
            </button>
            <button
              onClick={exportCSV}
              className="w-full flex items-center gap-2 px-3 py-2.5 text-xs text-[#e6edf3] hover:bg-[#00f5ff]/10 transition-colors border-b border-[#30363d]"
            >
              <FileSpreadsheet size={13} className="text-[#3fb950]" /> CSV (spreadsheet)
            </button>
            <button
              onClick={exportConfig}
              disabled={!configBundle}
              className="w-full flex items-center gap-2 px-3 py-2.5 text-xs text-[#e6edf3] hover:bg-[#00f5ff]/10 transition-colors border-b border-[#30363d] disabled:opacity-40"
            >
              <Settings size={13} className="text-[#bc8cff]" /> Config (views + overlays)
            </button>
            <button
              onClick={() => fileRef.current?.click()}
              disabled={!onImportConfig}
              className="w-full flex items-center gap-2 px-3 py-2.5 text-xs text-[#e6edf3] hover:bg-[#00f5ff]/10 transition-colors disabled:opacity-40"
            >
              <Upload size={13} className="text-[#ff9f0a]" /> Import Config…
            </button>
            <input ref={fileRef} type="file" accept="application/json,.json" onChange={handleImportFile} className="hidden" />
            {importError && <div className="px-3 py-1.5 text-[9px] text-[#ff6b6b]">{importError}</div>}
          </div>
        </>
      )}
    </div>
  );
}