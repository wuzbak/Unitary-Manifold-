/**
 * MerlinContextCard — inline Merlin surface for image generators.
 *
 * Renders three states consistent with the established side-dock pattern (not a
 * modal takeover):
 *   - clarify: Merlin asks clarifying questions; user answers → onAnswer(answers)
 *   - proofing/done: shows Merlin's proof verdict (pass/fail) + context note
 *   - error: shows a fallback message
 *
 * Tactical-HUD design: deep charcoal base, amber for active Merlin judgment,
 * ice-blue for structural framework, hard-angled clip-corner containers.
 */
import { useState } from 'react';
import { Sparkles, Loader2, CheckCircle2, AlertTriangle, Send, X } from 'lucide-react';
import { MERLIN_AVATAR } from '@/lib/merlinContextLayer';

export default function MerlinContextCard({ state, accent = '#FF9F00', onAnswer, onRecurate, onDismiss }) {
  const [answers, setAnswers] = useState({});

  if (!state || state.phase === 'idle') return null;

  const setAnswer = (q, val) => setAnswers((prev) => ({ ...prev, [q]: val }));

  const submitAnswers = () => {
    const formatted = Object.entries(answers).map(([question, answer]) => ({ question, answer }));
    onAnswer?.(formatted);
    setAnswers({});
  };

  return (
    <div
      className="glass-strong clip-corner p-3 space-y-2 fade-in"
      style={{ borderColor: `${accent}40` }}
    >
      {/* Header */}
      <div className="flex items-center gap-2">
        <img src={MERLIN_AVATAR} alt="Merlin" className="w-6 h-6 rounded-full shrink-0" />
        <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: accent }}>
          Merlin Intent Layer
        </span>
        {onDismiss && (
          <button onClick={onDismiss} className="ml-auto text-[#8b949e] hover:text-[#e6edf3] shrink-0">
            <X size={12} />
          </button>
        )}
      </div>

      {/* Curating / generating / proofing — loading states */}
      {(state.phase === 'curating' || state.phase === 'generating' || state.phase === 'proofing') && (
        <div className="flex items-center gap-2 text-[10px] text-[#8b949e]">
          <Loader2 size={12} className="animate-spin" style={{ color: accent }} />
          <span>
            {state.phase === 'curating' && 'Reading your intent…'}
            {state.phase === 'generating' && 'Generating with curated prompt…'}
            {state.phase === 'proofing' && 'Proofing the output against your intent…'}
          </span>
        </div>
      )}

      {/* Clarify — Merlin asks questions */}
      {state.phase === 'clarify' && state.clarifyingQuestions?.length > 0 && (
        <div className="space-y-2">
          <p className="text-[10px] text-[#e6edf3] leading-relaxed">
            *tilts head* Before I generate, a quick check so I get it right the first time:
          </p>
          {state.clarifyingQuestions.map((q, i) => (
            <div key={i} className="space-y-1">
              <label className="text-[9px] text-[#8b949e] uppercase font-bold block">{q}</label>
              <input
                type="text"
                value={answers[q] || ''}
                onChange={(e) => setAnswer(q, e.target.value)}
                placeholder="Your answer…"
                className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1.5 text-[11px] text-[#e6edf3] clip-corner focus:outline-none focus:border-[#FF9F00]/40"
              />
            </div>
          ))}
          <button
            onClick={submitAnswers}
            className="flex items-center gap-1.5 px-3 py-1.5 text-black text-[10px] font-bold clip-corner touch-manipulation"
            style={{ background: accent }}
          >
            <Send size={11} /> Generate with answers
          </button>
        </div>
      )}

      {/* Done — proof verdict */}
      {state.phase === 'done' && state.proof && (
        <div className="space-y-2">
          {state.contextNote && (
            <p className="text-[10px] text-[#8b949e] leading-relaxed italic">{state.contextNote}</p>
          )}
          {state.proof.verdict === 'pass' ? (
            <div className="flex items-start gap-1.5">
              <CheckCircle2 size={12} className="text-[#3fb950] shrink-0 mt-0.5" />
              <p className="text-[10px] text-[#3fb950] leading-relaxed">
                {state.proof.reason || 'Proofed — matches your intent and is safe.'}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-start gap-1.5">
                <AlertTriangle size={12} className="text-[#FF9F00] shrink-0 mt-0.5" />
                <p className="text-[10px] text-[#FF9F00] leading-relaxed">
                  {state.proof.reason || 'Output did not match your intent.'}
                </p>
              </div>
              {state.proof.suggested_recurate && (
                <div className="bg-[#0d1117] border border-[#FF9F00]/30 clip-corner p-2">
                  <div className="text-[9px] text-[#8b949e] uppercase font-bold mb-1">Merlin's re-curation</div>
                  <p className="text-[10px] text-[#e6edf3] leading-relaxed">{state.proof.suggested_recurate}</p>
                </div>
              )}
              {onRecurate && (
                <button
                  onClick={() => onRecurate(state.proof.suggested_recurate)}
                  className="flex items-center gap-1.5 px-3 py-1.5 border text-[10px] font-bold clip-corner touch-manipulation"
                  style={{ borderColor: `${accent}60`, color: accent }}
                >
                  <Sparkles size={11} /> Re-generate with fix
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* Error */}
      {state.phase === 'error' && (
        <div className="flex items-start gap-1.5">
          <AlertTriangle size={12} className="text-[#f85149] shrink-0 mt-0.5" />
          <p className="text-[10px] text-[#f85149] leading-relaxed">
            {state.error || 'The intent layer hit an issue. You can still generate directly.'}
          </p>
        </div>
      )}
    </div>
  );
}