import { Satellite, Database, FileText, Globe, ExternalLink, Telescope } from 'lucide-react';
import { FALSIFICATION_LINKS, SUPPLEMENTARY_LINKS, LINK_TYPE_META } from '@/lib/falsificationLinks';

const ICONS = { Satellite, Database, FileText, Globe };

function LinkRow({ link }) {
  const meta = LINK_TYPE_META[link.type] || LINK_TYPE_META.ref;
  const Icon = ICONS[meta.icon] || Globe;
  return (
    <a
      href={link.url}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-2 px-2.5 py-2 border border-[#30363d] bg-[#0d1117] hover:border-[#00f5ff]/40 hover:bg-[#00f5ff]/5 transition-colors group"
    >
      <Icon size={12} style={{ color: meta.color }} className="shrink-0" />
      <span className="text-[8px] font-bold tracking-wider px-1.5 py-0.5 border shrink-0" style={{ color: meta.color, borderColor: `${meta.color}40`, background: `${meta.color}10` }}>
        {meta.label}
      </span>
      <span className="text-[10px] text-[#e6edf3] group-hover:text-[#00f5ff] truncate flex-1">{link.label}</span>
      <ExternalLink size={10} className="text-[#484f58] group-hover:text-[#00f5ff] shrink-0" />
    </a>
  );
}

function MissionBlock({ mission }) {
  return (
    <div className="border border-[#30363d] bg-[#12161A] p-3">
      <div className="flex items-start justify-between mb-1">
        <div className="text-[11px] font-bold text-[#e6edf3] leading-tight">{mission.name}</div>
      </div>
      <div className="text-[9px] text-[#8b949e] mb-0.5">{mission.agency}</div>
      <div className="text-[9px] text-[#FF9F00] mb-2">{mission.target}</div>
      <div className="space-y-1">
        {mission.links.map((link, i) => (
          <LinkRow key={i} link={link} />
        ))}
      </div>
    </div>
  );
}

export default function EmpiricalLinksPanel({ experimentId }) {
  const expLinks = FALSIFICATION_LINKS[experimentId];

  return (
    <div className="mt-4 bg-[#12161A] border border-[#00f5ff]/20 rounded-lg p-4">
      <div className="flex items-center gap-2 mb-3">
        <Telescope size={14} className="text-[#00f5ff]" />
        <div className="text-xs font-bold text-[#00f5ff]">Empirical Data Sources</div>
        <span className="text-[9px] text-[#484f58] ml-auto">verified official portals · {new Date().getFullYear()}</span>
      </div>

      {/* Selected experiment links */}
      {expLinks && (
        <div className="mb-4">
          <div className="text-[9px] text-[#8b949e] uppercase tracking-wider mb-2">▸ Selected Experiment · {experimentId}</div>
          <MissionBlock mission={expLinks} />
        </div>
      )}

      {/* Supplementary cross-check missions */}
      <div>
        <div className="text-[9px] text-[#8b949e] uppercase tracking-wider mb-2">▸ Supplementary Cross-Checks</div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {SUPPLEMENTARY_LINKS.map((m) => (
            <MissionBlock key={m.name} mission={m} />
          ))}
        </div>
        <div className="text-[9px] text-[#484f58] mt-2 leading-relaxed">
          LISA is the gravitational-wave falsifier for <span className="text-[#00f5ff]">Pillar 788</span> (GW propagation speed & birefringence, ~2035).
          Euclid is the independent dark-energy cross-check for the DESI <span className="text-[#00f5ff]">w_a</span> tension (first cosmology data Oct 2026).
        </div>
      </div>
    </div>
  );
}