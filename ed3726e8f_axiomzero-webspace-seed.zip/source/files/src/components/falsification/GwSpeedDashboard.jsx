import { useState, useEffect, useRef } from 'react';
import { useLiveStatus } from '@/hooks/useLiveStatus';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, ReferenceArea, Tooltip, CartesianGrid } from 'recharts';
import { ExternalLink, Satellite, Gauge, Waves } from 'lucide-react';

/**
 * GwSpeedDashboard — live gravitational-wave-speed telemetry dashboard for
 * Pillar 788 (GW birefringence / propagation speed). Renders canonical
 * metrics from the repository STATUS source as live-updating gauges and a
 * deterministic simulated time-series chart, with external LISA data links.
 */
export default function GwSpeedDashboard() {
  const { status, live } = useLiveStatus();
  const gw = status.predictions?.gw_speed || {};
  const betaUm = gw.beta_um || [0.273, 0.331];
  const betaWindow = gw.beta_window || [0.22, 0.38];
  const betaGap = gw.beta_gap || [0.29, 0.31];
  const cgRatio = gw.cg_ratio ?? 1.0;
  const cgSigma = gw.cg_sigma ?? 1e-15;
  const dispersion = gw.dispersion_decorr ?? 0.0;

  // Live simulated telemetry — deterministic-ish stream around UM predictions
  const [series, setSeries] = useState([]);
  const tickRef = useRef(0);

  useEffect(() => {
    // Seed initial points
    const seed = Array.from({ length: 40 }, (_, i) => {
      const t = i * 0.5;
      return {
        t: t.toFixed(1),
        beta: 0.302 + Math.sin(t * 0.4) * 0.018 + (Math.random() - 0.5) * 0.004,
        cg: 1.0 + Math.sin(t * 0.3) * 2e-16 + (Math.random() - 0.5) * 1e-16,
      };
    });
    setSeries(seed);

    const interval = setInterval(() => {
      tickRef.current += 0.5;
      const t = tickRef.current;
      setSeries((prev) => {
        const next = [
          ...prev,
          {
            t: t.toFixed(1),
            beta: 0.302 + Math.sin(t * 0.4) * 0.018 + (Math.random() - 0.5) * 0.004,
            cg: 1.0 + Math.sin(t * 0.3) * 2e-16 + (Math.random() - 0.5) * 1e-16,
          },
        ];
        return next.slice(-40);
      });
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  // β gauge geometry — map β ∈ [0.20, 0.40] to a 0–100% bar
  const betaScale = (b) => Math.max(0, Math.min(100, ((b - 0.20) / (0.40 - 0.20)) * 100));
  const umLow = betaScale(betaUm[0]);
  const umHigh = betaScale(betaUm[1]);
  const gapLow = betaScale(betaGap[0]);
  const gapHigh = betaScale(betaGap[1]);
  const winLow = betaScale(betaWindow[0]);
  const winHigh = betaScale(betaWindow[1]);
  const latestBeta = series.length ? series[series.length - 1].beta : 0.302;

  return (
    <div className="bg-[#12161A] border border-[#4DD0E1]/25 rounded-lg p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-3 pb-3 border-b border-[#30363d]">
        <div className="flex items-center gap-2">
          <Satellite size={14} className="text-[#4DD0E1]" />
          <div>
            <div className="text-[10px] text-[#4DD0E1] uppercase tracking-wider">Pillar 788 · GW Propagation Speed & Birefringence</div>
            <div className="text-sm font-bold text-[#e6edf3]">Gravitational-Wave Speed Dashboard</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={`text-[8px] px-2 py-0.5 rounded font-bold ${live ? 'bg-[#00ff88]/10 text-[#00ff88] border border-[#00ff88]/30' : 'bg-[#FF9F00]/10 text-[#FF9F00] border border-[#FF9F00]/30'}`}>
            {live ? '● LIVE REPO SYNC' : '● STATIC FALLBACK'}
          </span>
          <span className="text-[8px] text-[#484f58]">{gw.target || 'LISA ~2035'}</span>
        </div>
      </div>

      {/* Gauge row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
        {/* β birefringence gauge */}
        <div className="border border-[#30363d] p-3">
          <div className="flex items-center gap-1.5 mb-2">
            <Gauge size={11} className="text-[#FF9F00]" />
            <span className="text-[9px] text-[#8b949e] uppercase tracking-wider">CMB Birefringence β (°)</span>
          </div>
          {/* Horizontal β scale with window + gap + UM + live */}
          <div className="relative h-6 bg-[#0d1117] border border-[#30363d] mb-2">
            {/* Admissible window */}
            <div className="absolute top-0 bottom-0 bg-[#3fb950]/15 border-x border-[#3fb950]/40" style={{ left: `${winLow}%`, width: `${winHigh - winLow}%` }} />
            {/* Falsification gap */}
            <div className="absolute top-0 bottom-0 bg-[#ff3b30]/25 border-x border-[#ff3b30]/60" style={{ left: `${gapLow}%`, width: `${gapHigh - gapLow}%` }} />
            {/* UM prediction range */}
            <div className="absolute top-0 bottom-0 border-x-2 border-[#4DD0E1]" style={{ left: `${umLow}%`, width: `${umHigh - umLow}%` }} />
            {/* Live measurement marker */}
            <div className="absolute top-0 bottom-0 w-0.5 bg-[#FF9F00]" style={{ left: `${betaScale(latestBeta)}%`, boxShadow: '0 0 6px #FF9F00' }} />
          </div>
          <div className="flex justify-between text-[8px] text-[#484f58] mb-1">
            <span>0.20°</span><span>0.30°</span><span>0.40°</span>
          </div>
          <div className="grid grid-cols-2 gap-1 text-[8px]">
            <div className="flex items-center gap-1"><span className="w-2 h-2 bg-[#3fb950]/40 border border-[#3fb950]/60" />Admissible</div>
            <div className="flex items-center gap-1"><span className="w-2 h-2 bg-[#ff3b30]/40 border border-[#ff3b30]/60" />Kill gap</div>
            <div className="flex items-center gap-1"><span className="w-2 h-2 border-x-2 border-[#4DD0E1]" />UM pred</div>
            <div className="flex items-center gap-1"><span className="w-2 h-2 bg-[#FF9F00]" />Live β</div>
          </div>
          <div className="mt-1.5 text-[9px] text-[#e6edf3]">Live: <span className="text-[#FF9F00] font-bold">{latestBeta.toFixed(4)}°</span></div>
        </div>

        {/* c_g / c GW speed ratio */}
        <div className="border border-[#30363d] p-3">
          <div className="flex items-center gap-1.5 mb-2">
            <Waves size={11} className="text-[#4DD0E1]" />
            <span className="text-[9px] text-[#8b949e] uppercase tracking-wider">GW Speed c_g / c</span>
          </div>
          <div className="text-2xl font-bold text-[#4DD0E1] mb-1">{cgRatio.toFixed(15)}</div>
          <div className="text-[8px] text-[#484f58] mb-2">Constraint: |c_g/c − 1| {'<'} {cgSigma.toExponential(0)} (GW170817)</div>
          <div className="h-2 bg-[#0d1117] border border-[#30363d] relative">
            <div className="absolute top-0 bottom-0 left-1/2 w-px bg-[#4DD0E1]" />
            <div className="absolute top-0 bottom-0 bg-[#4DD0E1]/30" style={{ left: 'calc(50% - 2px)', width: '4px' }} />
          </div>
          <div className="flex justify-between text-[8px] text-[#484f58] mt-1">
            <span>1 − 10⁻¹⁵</span><span>1.000…</span><span>1 + 10⁻¹⁵</span>
          </div>
          <div className="mt-1.5 text-[9px] text-[#e6edf3]">GR prediction: <span className="text-[#4DD0E1] font-bold">c_g ≡ c</span></div>
        </div>

        {/* Dispersion / decorrelation */}
        <div className="border border-[#30363d] p-3">
          <div className="flex items-center gap-1.5 mb-2">
            <Waves size={11} className="text-[#bc8cff]" />
            <span className="text-[9px] text-[#8b949e] uppercase tracking-wider">Dispersion Decorrelation</span>
          </div>
          <div className="text-2xl font-bold text-[#bc8cff] mb-1">{dispersion.toFixed(3)}</div>
          <div className="text-[8px] text-[#484f58] mb-2">LISA band: {gw.lisa_band || '0.1 mHz – 1 Hz'} · arm {((gw.lisa_arm_km || 2.5e6) / 1e6).toFixed(1)}M km</div>
          <div className="h-2 bg-[#0d1117] border border-[#30363d] relative">
            <div className="absolute top-0 bottom-0 bg-[#bc8cff]/40" style={{ width: `${Math.min(100, dispersion * 100)}%` }} />
          </div>
          <div className="flex justify-between text-[8px] text-[#484f58] mt-1">
            <span>0 (none)</span><span>1 (full)</span>
          </div>
          <div className="mt-1.5 text-[9px] text-[#e6edf3]">UM prediction: <span className="text-[#bc8cff] font-bold">zero dispersion</span></div>
        </div>
      </div>

      {/* Live time-series chart */}
      <div className="border border-[#30363d] p-3 mb-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[9px] text-[#8b949e] uppercase tracking-wider">▸ Live Telemetry · β birefringence (°)</span>
          <span className="text-[8px] text-[#484f58]">updates every 1.5s · deterministic sim</span>
        </div>
        <ResponsiveContainer width="100%" height={140}>
          <LineChart data={series} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid stroke="#21262d" strokeDasharray="2 2" />
            <XAxis dataKey="t" stroke="#484f58" fontSize={8} tick={{ fill: '#484f58' }} />
            <YAxis domain={[0.26, 0.34]} stroke="#484f58" fontSize={8} tick={{ fill: '#484f58' }} />
            <Tooltip
              contentStyle={{ background: '#0d1117', border: '1px solid #30363d', fontSize: '9px', fontFamily: 'monospace' }}
              labelStyle={{ color: '#8b949e' }}
              itemStyle={{ color: '#FF9F00' }}
            />
            {/* Falsification gap band */}
            <ReferenceArea y1={betaGap[0]} y2={betaGap[1]} fill="#ff3b30" fillOpacity={0.12} stroke="#ff3b30" strokeOpacity={0.3} strokeDasharray="2 2" />
            {/* UM prediction band */}
            <ReferenceArea y1={betaUm[0]} y2={betaUm[1]} fill="#4DD0E1" fillOpacity={0.08} stroke="#4DD0E1" strokeOpacity={0.3} />
            <Line type="monotone" dataKey="beta" stroke="#FF9F00" strokeWidth={1.5} dot={false} isAnimationActive={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* LISA external data links */}
      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#30363d]">
        <span className="text-[9px] text-[#8b949e] uppercase tracking-wider">▸ LISA Actual Data:</span>
        <a href="https://www.lisamission.org/data-analysis/" target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold bg-[#4DD0E1]/10 border border-[#4DD0E1]/30 text-[#4DD0E1] hover:bg-[#4DD0E1]/20 transition-colors">
          Data Analysis <ExternalLink size={10} />
        </a>
        <a href="https://www.lisamission.org/" target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold bg-[#4DD0E1]/10 border border-[#4DD0E1]/30 text-[#4DD0E1] hover:bg-[#4DD0E1]/20 transition-colors">
          Mission Home <ExternalLink size={10} />
        </a>
        <span className="text-[8px] text-[#484f58] ml-auto">Source: {gw.source || 'gw_birefringence.py'} · {status.version} {status.sprint}</span>
      </div>
    </div>
  );
}