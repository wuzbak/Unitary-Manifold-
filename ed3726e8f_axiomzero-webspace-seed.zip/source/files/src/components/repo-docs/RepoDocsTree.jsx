import { useState, useMemo } from 'react';
import { ChevronDown, ChevronRight, FileText, Search, Folder } from 'lucide-react';

/**
 * RepoDocsTree — sidebar file tree for repo documentation.
 * Groups markdown docs by top-level directory, with search filtering.
 */
export default function RepoDocsTree({ entries, selectedPath, onSelect }) {
  const [search, setSearch] = useState('');
  const [collapsed, setCollapsed] = useState({});

  const filtered = useMemo(() => {
    if (!search.trim()) return entries;
    const q = search.toLowerCase();
    return entries.filter((e) => e.path.toLowerCase().includes(q));
  }, [entries, search]);

  // Group by top-level directory
  const groups = useMemo(() => {
    const map = {};
    filtered.forEach((e) => {
      const dir = e.path.includes('/') ? e.path.split('/')[0] : 'Root';
      if (!map[dir]) map[dir] = [];
      map[dir].push(e);
    });
    return Object.keys(map).sort().map((dir) => ({ dir, items: map[dir] }));
  }, [filtered]);

  const toggle = (dir) => setCollapsed((c) => ({ ...c, [dir]: !c[dir] }));

  return (
    <div className="flex flex-col h-full">
      <div className="p-2 border-b border-[#30363d]">
        <div className="flex items-center gap-1.5 bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5">
          <Search size={11} className="text-[#484f58]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search docs..."
            className="bg-transparent text-[11px] text-[#e6edf3] flex-1 focus:outline-none placeholder:text-[#484f58]"
          />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto py-1">
        {groups.length === 0 ? (
          <div className="text-[#484f58] text-[10px] px-3 py-4 text-center">No docs match "{search}"</div>
        ) : (
          groups.map((g) => (
            <div key={g.dir}>
              <button
                onClick={() => toggle(g.dir)}
                className="w-full flex items-center gap-1 px-2 py-1.5 text-[10px] font-bold text-[#8b949e] hover:text-[#e6edf3] hover:bg-[#161b22] transition-colors"
              >
                {collapsed[g.dir] ? <ChevronRight size={10} /> : <ChevronDown size={10} />}
                <Folder size={11} className="text-[#58a6ff]" />
                <span className="truncate">{g.dir}</span>
                <span className="text-[#484f58] ml-auto text-[9px]">{g.items.length}</span>
              </button>
              {!collapsed[g.dir] && (
                <div className="ml-3 border-l border-[#21262d]">
                  {g.items.map((e) => {
                    const name = e.path.includes('/') ? e.path.split('/').slice(1).join('/') : e.path;
                    const isActive = selectedPath === e.path;
                    return (
                      <button
                        key={e.path}
                        onClick={() => onSelect(e.path)}
                        className={`w-full flex items-center gap-1.5 px-2 py-1.5 text-[10px] transition-colors text-left ${isActive ? 'bg-[#00f5ff]/10 text-[#00f5ff] border-l-2 border-[#00f5ff]' : 'text-[#8b949e] hover:text-[#e6edf3] hover:bg-[#161b22] border-l-2 border-transparent'}`}
                      >
                        <FileText size={10} className="shrink-0 opacity-60" />
                        <span className="truncate">{name}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}