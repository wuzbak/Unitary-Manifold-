import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { FileText, Loader2, ExternalLink } from 'lucide-react';

/**
 * RepoDocSources — fetches repo docs matching a query and displays them as
 * clickable deep-links to the Live Docs page (?file=path).
 * Uses the authenticated githubRepoContent backend function (read-only).
 */
export default function RepoDocSources({ query, max = 5 }) {
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!query || query.trim().length < 2) { setDocs([]); return; }
    setLoading(true);
    base44.functions.invoke('githubRepoContent', { action: 'tree' })
      .then((res) => {
        const data = res.data || res;
        const entries = data.entries || [];
        const q = query.toLowerCase();
        const normalized = q.replace(/[-_]/g, ' ');
        const matches = entries
          .filter((e) => {
            const p = e.path.toLowerCase();
            const pn = p.replace(/[-_]/g, ' ');
            return p.includes(q) || pn.includes(normalized);
          })
          .slice(0, max);
        setDocs(matches);
      })
      .catch(() => setDocs([]))
      .finally(() => setLoading(false));
  }, [query, max]);

  if (loading) {
    return <div className="flex items-center gap-1.5 text-[9px] text-[#484f58]"><Loader2 size={10} className="animate-spin" /> Searching documents...</div>;
  }
  if (docs.length === 0) return null;

  return (
    <div className="space-y-1">
      <div className="text-[9px] text-[#8b949e] uppercase tracking-wider flex items-center gap-1"><FileText size={9} /> Source Documents</div>
      {docs.map((d) => (
        <Link key={d.path} to={`/repo-docs?file=${encodeURIComponent(d.path)}`} className="flex items-center gap-1.5 text-[10px] text-[#58a6ff] hover:text-[#00f5ff] transition-colors group">
          <ExternalLink size={9} className="opacity-50 group-hover:opacity-100 shrink-0" />
          <span className="truncate">{d.path}</span>
        </Link>
      ))}
    </div>
  );
}