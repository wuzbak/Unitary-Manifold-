import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import RepoDocsTree from './RepoDocsTree';
import RepoDocsViewer from './RepoDocsViewer';
import { Loader2, AlertCircle, RefreshCw, Github, ShieldCheck } from 'lucide-react';

const REPO_URL = 'https://github.com/wuzbak/Unitary-Manifold-';

/**
 * RepoDocsPanel — reusable live repo documentation browser.
 * Pulls docs & research notes via the authenticated GitHub connector (read-only).
 * Drop onto any page: <RepoDocsPanel />
 */
export default function RepoDocsPanel() {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchParams] = useSearchParams();
  const fileParam = searchParams.get('file');
  const [selectedPath, setSelectedPath] = useState(fileParam || 'README.md');
  const [meta, setMeta] = useState(null);

  // Deep-link: when ?file= changes (e.g. from RepoDocSources links), update selection
  useEffect(() => {
    if (fileParam) setSelectedPath(fileParam);
  }, [fileParam]);

  const fetchTree = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('githubRepoContent', { action: 'tree' });
      const data = res.data || res;
      setEntries(data.entries || []);
      setMeta({ repo: data.repo, branch: data.branch, docsCount: data.docsCount, totalFiles: data.totalFiles, fetchedAt: data.fetchedAt });
    } catch (e) {
      setError(e.message || e?.error || 'Failed to load repository');
    }
    setLoading(false);
  };

  useEffect(() => { fetchTree(); }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <Loader2 size={20} className="animate-spin text-[#00f5ff] mx-auto mb-2" />
          <div className="text-[#8b949e] text-[10px] tracking-wider">CONNECTING TO GITHUB...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center max-w-sm">
          <AlertCircle size={20} className="text-[#f85149] mx-auto mb-2" />
          <div className="text-[#f85149] text-[11px] mb-3">{error}</div>
          <button onClick={fetchTree} className="px-3 py-1.5 rounded border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] text-[10px] flex items-center gap-1.5 mx-auto">
            <RefreshCw size={10} /> Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-[#30363d] bg-[#0d1117] overflow-hidden">
      {/* Status bar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#30363d] bg-[#161b22]">
        <div className="flex items-center gap-2">
          <Github size={12} className="text-[#e6edf3]" />
          <span className="text-[#e6edf3] text-[11px] font-bold">{meta?.repo || 'wuzbak/Unitary-Manifold-'}</span>
          <span className="text-[#484f58] text-[9px]">· {meta?.branch || 'main'}</span>
          <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#238636]/10 border border-[#238636]/30 text-[#3fb950] text-[8px] font-bold">
            <ShieldCheck size={9} /> READ-ONLY
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[#484f58] text-[9px]">{meta?.docsCount || 0} docs · {meta?.totalFiles?.toLocaleString() || 0} files</span>
          <button onClick={fetchTree} className="text-[#8b949e] hover:text-[#00f5ff] transition-colors" title="Refresh from GitHub">
            <RefreshCw size={11} />
          </button>
        </div>
      </div>

      {/* Tree + Viewer */}
      <div className="grid grid-cols-1 md:grid-cols-[260px_1fr] h-[70vh]">
        <div className="border-r border-[#30363d] bg-[#0d1117] overflow-hidden">
          <RepoDocsTree entries={entries} selectedPath={selectedPath} onSelect={setSelectedPath} />
        </div>
        <div className="overflow-hidden bg-[#0d1117]">
          <RepoDocsViewer path={selectedPath} />
        </div>
      </div>
    </div>
  );
}