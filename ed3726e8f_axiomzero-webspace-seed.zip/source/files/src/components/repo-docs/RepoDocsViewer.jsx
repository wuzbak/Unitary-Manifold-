import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import ReactMarkdown from 'react-markdown';
import { Loader2, AlertCircle, ExternalLink, RefreshCw } from 'lucide-react';

const REPO_URL = 'https://github.com/wuzbak/Unitary-Manifold-/blob/main/';

/**
 * RepoDocsViewer — renders a single repo doc as markdown.
 * Fetches authenticated content via the githubRepoContent backend function.
 */
export default function RepoDocsViewer({ path }) {
  const [content, setContent] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [fetchedAt, setFetchedAt] = useState(null);

  const fetchFile = async () => {
    if (!path) return;
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('githubRepoContent', { action: 'file', path });
      const data = res.data || res;
      setContent(data.content);
      setFetchedAt(data.fetchedAt);
    } catch (e) {
      setError(e.message || e?.error || 'Failed to fetch document');
    }
    setLoading(false);
  };

  useEffect(() => { fetchFile(); }, [path]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full py-20">
        <div className="text-center">
          <Loader2 size={20} className="animate-spin text-[#00f5ff] mx-auto mb-2" />
          <div className="text-[#8b949e] text-[10px] tracking-wider">PULLING FROM GITHUB...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-full py-20">
        <div className="text-center max-w-sm">
          <AlertCircle size={20} className="text-[#f85149] mx-auto mb-2" />
          <div className="text-[#f85149] text-[11px] mb-3">{error}</div>
          <button onClick={fetchFile} className="px-3 py-1.5 rounded border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] text-[10px] flex items-center gap-1.5 mx-auto">
            <RefreshCw size={10} /> Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#30363d] bg-[#0d1117]">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-[#00f5ff] text-[10px] font-mono truncate">{path}</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {fetchedAt && <span className="text-[#484f58] text-[9px]">live · {new Date(fetchedAt).toLocaleTimeString()}</span>}
          <a href={`${REPO_URL}${path}`} target="_blank" rel="noopener noreferrer" className="text-[#8b949e] hover:text-[#00f5ff] transition-colors" title="View on GitHub">
            <ExternalLink size={12} />
          </a>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-5 py-4">
        <article className="prose prose-invert prose-sm max-w-none text-[#e6edf3]">
          <ReactMarkdown>{content || '*Select a document to view*'}</ReactMarkdown>
        </article>
      </div>
    </div>
  );
}