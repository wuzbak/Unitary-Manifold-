import { useMemo } from 'react';
import StatCard from '@/components/shared/StatCard';
import { CheckCircle2, AlertTriangle, XCircle, ShieldCheck } from 'lucide-react';

export default function CrawlValidatorTab({ manifest, loading, error }) {
  const checks = useMemo(() => {
    if (!manifest) return [];
    const { routes, robotsTxt, sitemapXml, llmsTxt, jsonLdBlocks, aiAgents, authRoutes, repoSha } = manifest;
    const list = [];

    // 1. All routes in sitemap
    const sitemapRouteCount = (sitemapXml.match(/<loc>/g) || []).length;
    list.push({
      name: 'Sitemap covers all public routes',
      status: sitemapRouteCount === routes.length ? 'pass' : 'fail',
      detail: `${sitemapRouteCount} <loc> entries vs ${routes.length} routes`,
    });

    // 2. Auth routes disallowed
    const allAuthBlocked = authRoutes.every((r) => robotsTxt.includes('Disallow: ' + r));
    list.push({
      name: 'Auth routes disallowed in robots.txt',
      status: allAuthBlocked ? 'pass' : 'fail',
      detail: `${authRoutes.join(', ')}`,
    });

    // 3. AI agents whitelisted
    list.push({
      name: 'AI agents explicitly whitelisted',
      status: aiAgents.length >= 10 ? 'pass' : 'warn',
      detail: `${aiAgents.length} agents (GPTBot, ClaudeBot, PerplexityBot, …)`,
    });

    // 4. Sitemap pointer present
    list.push({
      name: 'robots.txt references sitemap.xml',
      status: robotsTxt.includes('Sitemap: ') ? 'pass' : 'fail',
      detail: robotsTxt.includes('Sitemap: ') ? 'Sitemap line present' : 'Missing Sitemap directive',
    });

    // 5. llms.txt has repo link
    list.push({
      name: 'llms.txt links to source repository',
      status: llmsTxt.includes('github.com') ? 'pass' : 'warn',
      detail: llmsTxt.includes('github.com') ? 'Repo URL present' : 'Repo URL missing',
    });

    // 6. JSON-LD blocks present
    list.push({
      name: 'JSON-LD structured data generated',
      status: jsonLdBlocks && jsonLdBlocks.length >= 3 ? 'pass' : 'warn',
      detail: `${jsonLdBlocks ? jsonLdBlocks.length : 0} schema blocks`,
    });

    // 7. Sitemap XML well-formed
    const wellFormed = sitemapXml.startsWith('<?xml') && sitemapXml.includes('<urlset') && sitemapXml.includes('</urlset>');
    list.push({
      name: 'Sitemap XML is well-formed',
      status: wellFormed ? 'pass' : 'fail',
      detail: wellFormed ? 'Valid urlset structure' : 'Malformed XML',
    });

    // 8. Repo SHA fetched (live pipeline active)
    list.push({
      name: 'Live repo pipeline active',
      status: repoSha && repoSha !== 'unknown' ? 'pass' : 'warn',
      detail: repoSha && repoSha !== 'unknown' ? `SHA ${repoSha}` : 'GitHub API unreachable (using fallback date)',
    });

    // 9. Every route has a description
    const missingDesc = routes.filter((r) => !r.desc);
    list.push({
      name: 'All routes have descriptions',
      status: missingDesc.length === 0 ? 'pass' : 'warn',
      detail: missingDesc.length === 0 ? 'All 40 routes described' : `${missingDesc.length} routes missing description`,
    });

    // 10. No scraping barriers (Allow: / for *)
    list.push({
      name: 'No scraping barriers (public index)',
      status: robotsTxt.includes('User-agent: *\nAllow: /') ? 'pass' : 'fail',
      detail: robotsTxt.includes('User-agent: *\nAllow: /') ? 'Wildcard allow' : 'Wildcard not allowed',
    });

    return list;
  }, [manifest]);

  if (loading) return <div className="text-[#8b949e] text-xs py-8 text-center">Running crawl validation…</div>;
  if (error) return <div className="text-red-400 text-xs py-8 text-center">Error: {error}</div>;
  if (!manifest) return null;

  const passCount = checks.filter((c) => c.status === 'pass').length;
  const warnCount = checks.filter((c) => c.status === 'warn').length;
  const failCount = checks.filter((c) => c.status === 'fail').length;
  const healthScore = Math.round((passCount / checks.length) * 100);

  const statusStyle = {
    pass: { color: '#3fb950', Icon: CheckCircle2, label: 'PASS' },
    warn: { color: '#FF9F00', Icon: AlertTriangle, label: 'WARN' },
    fail: { color: '#f85149', Icon: XCircle, label: 'FAIL' },
  };

  return (
    <div className="space-y-4 fade-in">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Health Score" value={`${healthScore}%`} color={healthScore >= 90 ? '#3fb950' : healthScore >= 70 ? '#FF9F00' : '#f85149'} icon={ShieldCheck} />
        <StatCard label="Passed" value={passCount} color="#3fb950" />
        <StatCard label="Warnings" value={warnCount} color="#FF9F00" />
        <StatCard label="Failed" value={failCount} color="#f85149" />
      </div>

      <div className="border border-[#30363d] rounded-lg overflow-hidden">
        {checks.map((c, i) => {
          const s = statusStyle[c.status];
          return (
            <div key={i} className={`flex items-start gap-3 px-4 py-3 ${i > 0 ? 'border-t border-[#30363d]' : ''} hover:bg-[#161b22] transition-colors`}>
              <s.Icon size={16} className="shrink-0 mt-0.5" style={{ color: s.color }} />
              <div className="flex-1 min-w-0">
                <div className="text-xs font-bold text-[#e6edf3]">{c.name}</div>
                <div className="text-[10px] text-[#8b949e] mt-0.5">{c.detail}</div>
              </div>
              <span className="text-[9px] font-bold px-2 py-0.5 border shrink-0" style={{ color: s.color, borderColor: s.color + '40', background: s.color + '10' }}>{s.label}</span>
            </div>
          );
        })}
      </div>

      <div className="text-[10px] text-[#484f58] leading-relaxed">
        Validation runs against the live manifest generated from <span className="text-[#00f5ff]">wuzbak/Unitary-Manifold-</span> (read-only). Bots receive platform-prerendered HTML on the custom domain, so SPA routes are never blank. Disable platform auto-generation of robots.txt / sitemap.xml in SEO &amp; GEO settings to serve the custom repo-driven versions.
      </div>
    </div>
  );
}