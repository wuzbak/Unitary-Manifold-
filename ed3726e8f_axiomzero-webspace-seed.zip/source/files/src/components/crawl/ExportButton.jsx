import { Download } from 'lucide-react';

/**
 * ExportButton — downloads the given text content as a file (client-side Blob).
 */
export default function ExportButton({ content, filename, label = 'Export' }) {
  const handleExport = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <button
      onClick={handleExport}
      disabled={!content}
      className="px-3 py-1.5 bg-[#FF9F00]/10 border border-[#FF9F00]/40 text-[#FF9F00] text-xs font-bold flex items-center gap-1.5 hover:bg-[#FF9F00]/20 transition-colors clip-corner disabled:opacity-40 disabled:cursor-not-allowed"
    >
      <Download size={12} /> {label}
    </button>
  );
}