import ExportButton from './ExportButton';
import StatCard from '@/components/shared/StatCard';
import { FileText, ExternalLink } from 'lucide-react';

export default function LlmsTab({ manifest, loading, error }) {
  if (loading) return <div className="text-[#8b949e] text-xs py-8 text-center">Generating llms.txt…</div>;
  if (error) return <div className="text-red-400 text-xs py-8 text-center">Error: {error}</div>;
  if (!manifest) return null;

  const { llmsTxt, routes, repoUrl } = manifest;

  return (
    <div className="space-y-4 fade-in">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <StatCard label="Pages Listed" value={routes.length} color="#00f5ff" icon={FileText} />
        <StatCard label="Format" value="llms.txt" color="#58a6ff" />
        <StatCard label="Source" value="Repo README" color="#3fb950" />
      </div>

      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h3 className="text-sm font-bold text-[#e6edf3]">AI Discovery Manifest</h3>
        <div className="flex items-center gap-2">
          <a href={repoUrl} target="_blank" rel="noopener noreferrer" className="px-3 py-1.5 border border-[#30363d] text-[#8b949e] text-xs font-bold flex items-center gap-1.5 hover:text-[#00f5ff] hover:border-[#00f5ff]/40 transition-colors">
            <ExternalLink size={12} /> View Repo
          </a>
          <ExportButton content={llmsTxt} filename="llms.txt" label="Export llms.txt" />
        </div>
      </div>

      <pre className="bg-[#0a0a12] border border-[#30363d] rounded-lg p-3 text-[10px] text-[#8b949e] font-mono overflow-x-auto max-h-[60vh] overflow-y-auto whitespace-pre">{llmsTxt}</pre>
    </div>
  );
}