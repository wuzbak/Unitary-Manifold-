import { Link } from 'react-router-dom';
import ExportButton from './ExportButton';
import StatCard from '@/components/shared/StatCard';
import { Map, GitCommit } from 'lucide-react';

export default function SitemapTab({ manifest, loading, error }) {
  if (loading) return <div className="text-[#8b949e] text-xs py-8 text-center">Generating sitemap from repository…</div>;
  if (error) return <div className="text-red-400 text-xs py-8 text-center">Error: {error}</div>;
  if (!manifest) return null;

  const { routes, sitemapXml, lastmod, repoSha } = manifest;

  return (
    <div className="space-y-4 fade-in">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Routes Indexed" value={routes.length} color="#00f5ff" icon={Map} />
        <StatCard label="Last Modified" value={lastmod} color="#3fb950" />
        <StatCard label="Repo SHA" value={repoSha} color="#FF9F00" />
        <StatCard label="Base URL" value="axiomzerospc.org" color="#58a6ff" />
      </div>

      <div className="bg-[#0a0a12] border border-[#FF9F00]/30 rounded-lg p-3 flex items-start gap-2">
        <span className="text-[#FF9F00] text-xs font-bold whitespace-nowrap">⚠ Manual Step:</span>
        <span className="text-[10px] text-[#8b949e] leading-relaxed">
          Submit <code className="text-[#00f5ff] font-mono">https://axiomzerospc.org/sitemap.xml</code> in Google Search Console → <strong className="text-[#e6edf3]">Sitemaps</strong> tab. The static file is now served live at <code className="text-[#00f5ff] font-mono">/sitemap.xml</code> and referenced from <code className="text-[#00f5ff] font-mono">/robots.txt</code> — Google needs the GSC submission to start discovery.
        </span>
      </div>

      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h3 className="text-sm font-bold text-[#e6edf3] flex items-center gap-1.5">
          <GitCommit size={14} className="text-[#00f5ff]" /> Route Registry
        </h3>
        <ExportButton content={sitemapXml} filename="sitemap.xml" label="Export sitemap.xml" />
      </div>

      <div className="overflow-x-auto border border-[#30363d] rounded-lg">
        <table className="w-full text-xs">
          <thead className="bg-[#161b22] text-[#8b949e]">
            <tr>
              <th className="text-left px-3 py-2 font-bold">Path</th>
              <th className="text-left px-3 py-2 font-bold">Label</th>
              <th className="text-left px-3 py-2 font-bold">Category</th>
              <th className="text-left px-3 py-2 font-bold">Priority</th>
              <th className="text-left px-3 py-2 font-bold">Lastmod</th>
            </tr>
          </thead>
          <tbody>
            {routes.map((r) => (
              <tr key={r.path} className="border-t border-[#30363d] hover:bg-[#161b22]">
                <td className="px-3 py-2"><Link to={r.path} className="text-[#00f5ff] hover:underline font-mono">{r.path}</Link></td>
                <td className="px-3 py-2 text-[#e6edf3]">{r.label}</td>
                <td className="px-3 py-2 text-[#8b949e]">{r.category}</td>
                <td className="px-3 py-2 text-[#FF9F00] font-mono">{r.priority}</td>
                <td className="px-3 py-2 text-[#484f58] font-mono">{r.lastmod}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div>
        <div className="text-[10px] text-[#484f58] uppercase tracking-wider mb-1.5">Raw sitemap.xml</div>
        <pre className="bg-[#0a0a12] border border-[#30363d] rounded-lg p-3 text-[10px] text-[#8b949e] font-mono overflow-x-auto max-h-80 overflow-y-auto whitespace-pre">{sitemapXml}</pre>
      </div>
    </div>
  );
}