import ExportButton from './ExportButton';
import StatCard from '@/components/shared/StatCard';
import { Bot, ShieldCheck } from 'lucide-react';

export default function RobotsTab({ manifest, loading, error }) {
  if (loading) return <div className="text-[#8b949e] text-xs py-8 text-center">Generating robots.txt…</div>;
  if (error) return <div className="text-red-400 text-xs py-8 text-center">Error: {error}</div>;
  if (!manifest) return null;

  const { robotsTxt, aiAgents, authRoutes } = manifest;

  return (
    <div className="space-y-4 fade-in">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <StatCard label="AI Agents Whitelisted" value={aiAgents.length} color="#3fb950" icon={Bot} />
        <StatCard label="Auth Routes Blocked" value={authRoutes.length} color="#FF9F00" icon={ShieldCheck} />
        <StatCard label="Default Policy" value="Allow: /" color="#00f5ff" />
      </div>

      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h3 className="text-sm font-bold text-[#e6edf3]">Explicit AI-Agent Whitelist</h3>
        <ExportButton content={robotsTxt} filename="robots.txt" label="Export robots.txt" />
      </div>

      <div className="flex flex-wrap gap-1.5">
        {aiAgents.map((agent) => (
          <span key={agent} className="px-2 py-1 bg-[#3fb950]/10 border border-[#3fb950]/30 text-[#3fb950] text-[10px] font-mono">
            {agent}
          </span>
        ))}
      </div>

      <div>
        <div className="text-[10px] text-[#484f58] uppercase tracking-wider mb-1.5">Disallowed (auth) routes</div>
        <div className="flex flex-wrap gap-1.5">
          {authRoutes.map((r) => (
            <span key={r} className="px-2 py-1 bg-[#FF9F00]/10 border border-[#FF9F00]/30 text-[#FF9F00] text-[10px] font-mono">{r}</span>
          ))}
        </div>
      </div>

      <div>
        <div className="text-[10px] text-[#484f58] uppercase tracking-wider mb-1.5">Raw robots.txt</div>
        <pre className="bg-[#0a0a12] border border-[#30363d] rounded-lg p-3 text-[10px] text-[#8b949e] font-mono overflow-x-auto max-h-80 overflow-y-auto whitespace-pre">{robotsTxt}</pre>
      </div>
    </div>
  );
}