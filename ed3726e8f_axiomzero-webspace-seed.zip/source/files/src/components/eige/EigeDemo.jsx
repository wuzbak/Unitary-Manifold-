/**
 * EigeDemo — 24-hour election-day simulation shell.
 * Accessed via the "Demo" tab on the EIGE page. Provides a time controller
 * (play/pause/speed/scrub), five stakeholder dashboard views (Public, State,
 * Federal, Regulators, Machine), and a Back button + Site Map button.
 *
 * Anchored to the real EIGE architecture (12-AZ-IP/03-eige): 3-tier sovereign
 * mesh, CS rolling hash (k_CS=74), φ₀=π/4 invariant, 8-shard holographic
 * persistence, Holon Zero ZK certificates, HILS Pentad governance.
 */
import { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, ChevronLeft, Map, Clock, Sparkles, ShieldCheck } from 'lucide-react';
import { buildDemoState } from '@/lib/eige/eigeDemoEngine';
import PublicView from './views/PublicView';
import StateView from './views/StateView';
import FederalView from './views/FederalView';
import RegulatorView from './views/RegulatorView';
import MachineView from './views/MachineView';


const VIEWS = [
  { key: 'public', label: 'Public' },
  { key: 'state', label: 'State' },
  { key: 'federal', label: 'Federal' },
  { key: 'regulators', label: 'Regulators' },
  { key: 'machine', label: 'Machine' },
];

const SPEEDS = [1, 2, 4];

export default function EigeDemo({ onExit }) {
  const [hour, setHour] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [view, setView] = useState('public');

  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setHour((h) => {
        if (h >= 24) { setPlaying(false); return 24; }
        return Math.min(24, +(h + 0.25 * speed).toFixed(2));
      });
    }, 250);
    return () => clearInterval(id);
  }, [playing, speed]);

  const state = buildDemoState(hour);
  const openSiteMap = () => window.dispatchEvent(new Event('site-map-toggle'));
  const reset = () => { setPlaying(false); setHour(0); };
  const phase = hour < 6 ? 'PRE-POLL' : hour <= 20 ? 'POLLS OPEN' : 'COUNTING';

  // Live snapshot for Merlin so he can interpret what's on screen.
  const merlinLiveState = {
    currentView: view,
    hour: state.hour,
    phase,
    totalVotes: state.totalVotes,
    turnoutPct: state.totalVoters > 0 ? ((state.totalVotes / state.totalVoters) * 100).toFixed(1) : '0.0',
    winner: state.winner,
    totals: state.totals,
    integrity: state.integrity,
    regulator: state.regulator,
    federal: state.federal,
    machine: state.machine,
  };

  const suggestedQuestions = [
    `Interpret the current ${view} dashboard — what do the live metrics mean right now?`,
    'Is the election integrity holding? Explain φ_eff drift and k_CS for this hour.',
    'What happens if an admin tries to override a county tally in EIGE?',
    'Why does the federal tier never see raw ballots? Explain the blind audit gate.',
    'Walk through the 3-tier sovereign mesh and what each tier is responsible for.',
    'What is the Freedom Floor and when would it trigger?',
  ];

  return (
    <div className="space-y-4">
      {/* Header bar — back + site map + title */}
      <div className="flex items-center gap-2 flex-wrap">
        <button onClick={onExit} className="flex items-center gap-1.5 px-3 py-2 border border-[#3b8bff]/40 bg-[#3b8bff]/10 text-[#3b8bff] text-xs font-bold clip-corner hover:bg-[#3b8bff]/20 transition-colors touch-manipulation">
          <ChevronLeft size={14} /> Back to EIGE
        </button>
        <button onClick={openSiteMap} className="flex items-center gap-1.5 px-3 py-2 border-2 border-[#00f5ff]/50 bg-[#00f5ff]/10 text-[#00f5ff] text-xs font-bold clip-corner hover:bg-[#00f5ff]/20 transition-colors touch-manipulation">
          <Map size={14} /> Site Map
        </button>
        <div className="ml-auto text-right">
          <div className="text-xs font-bold text-[#3b8bff]">EIGE Live Demo — 24hr Election Day</div>
          <div className="text-[9px] text-[#484f58]">Candidates A · B · C · Parties BLUE · RED · PURPLE · GREEN · RAINBOW</div>
        </div>
      </div>

      {/* Time controller */}
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-3">
        <div className="flex items-center gap-3 flex-wrap">
          <button onClick={() => setPlaying((p) => !p)} disabled={hour >= 24}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#3b8bff] text-white rounded text-xs font-bold disabled:opacity-40 hover:opacity-90 touch-manipulation">
            {playing ? <><Pause size={12} /> Pause</> : <><Play size={12} /> Play</>}
          </button>
          <button onClick={reset} className="flex items-center gap-1.5 px-3 py-2 bg-[#0d1117] border border-[#30363d] text-[#8b949e] rounded text-xs hover:text-[#e6edf3] touch-manipulation">
            <RotateCcw size={12} /> Reset
          </button>
          <div className="flex items-center gap-1">
            <span className="text-[9px] text-[#8b949e]">Speed</span>
            {SPEEDS.map((s) => (
              <button key={s} onClick={() => setSpeed(s)}
                className={`px-2 py-1 rounded text-[10px] font-bold touch-manipulation ${speed === s ? 'bg-[#3b8bff] text-white' : 'bg-[#0d1117] border border-[#30363d] text-[#8b949e]'}`}>
                {s}x
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2 flex-1 min-w-[200px]">
            <Clock size={12} className="text-[#484f58] shrink-0" />
            <input type="range" min="0" max="24" step="0.25" value={hour}
              onChange={(e) => { setPlaying(false); setHour(+e.target.value); }}
              className="flex-1 accent-[#3b8bff]" />
            <span className="text-[10px] text-[#e6edf3] font-mono w-20 text-right">{hour.toFixed(2).padStart(5, '0')}h</span>
          </div>
          <span className="text-[9px] px-2 py-1 rounded border border-[#3b8bff]/30 text-[#3b8bff] bg-[#3b8bff]/5 font-bold">{phase}</span>
        </div>
      </div>

      {/* View tabs */}
      <div className="flex flex-wrap gap-2">
        {VIEWS.map((v) => (
          <button key={v.key} onClick={() => setView(v.key)}
            className={`px-3 py-1.5 rounded text-xs font-bold transition-colors touch-manipulation ${view === v.key ? 'bg-[#3b8bff] text-white' : 'bg-[#0d1117] border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}>
            {v.label}
          </button>
        ))}
      </div>

      {/* Active view */}
      <div className="fade-in">
        {view === 'public' && <PublicView state={state} />}
        {view === 'state' && <StateView state={state} />}
        {view === 'federal' && <FederalView state={state} />}
        {view === 'regulators' && <RegulatorView state={state} />}
        {view === 'machine' && <MachineView state={state} />}
      </div>

      {/* Audit log */}
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-3">
        <div className="text-[10px] font-bold text-[#8b949e] uppercase tracking-wider mb-2">Sovereign Mesh Audit Log</div>
        <div className="space-y-1 max-h-40 overflow-y-auto">
          {state.auditLog.length === 0 && <div className="text-[10px] text-[#484f58] italic">Awaiting polls open (06:00)…</div>}
          {state.auditLog.map((e, i) => (
            <div key={i} className="text-[10px] border-l-2 border-[#3b8bff]/30 pl-2">
              <span className="text-[#3b8bff] font-bold">[{e.tier}] {e.action}</span> <span className="text-[#484f58]">h{e.h}</span>
              <div className="text-[#8b949e]">{e.detail}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-[#3b8bff]/5 border border-[#3b8bff]/20 rounded-lg p-3">
        <div className="text-[10px] text-[#3b8bff]"><strong>🔵 Adjacent Track — Simulation Only</strong> — This is a deterministic showcase toy anchored to the EIGE architecture (k_CS=74, φ₀=π/4, 8-shard persistence, Holon Zero ZK certificates). It does not interact with real election systems. All data is simulated.</div>
      </div>

    </div>
  );
}