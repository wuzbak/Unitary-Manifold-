/**
 * RegulatorView — OSCAL / NIST compliance + Sentinel override interception.
 * The view seen by election regulators (EAC, state PDC, CISA): OSCAL dossier
 * stream, override interception with sub-500ms public-record latency, and the
 * HILS 5-Body Pentad governance matrix.
 */
import { Shield, Zap, FileText, Clock } from 'lucide-react';

const NIST_CONTROLS = [
  { control: 'SI-7', desc: 'Software Integrity (CS rolling hash)', status: 'active' },
  { control: 'AC-1', desc: 'Access Control Policy (5D metric closure)', status: 'active' },
  { control: 'AU-12', desc: 'Audit Generation (override dossier)', status: 'active' },
  { control: 'AC-3', desc: 'Access Enforcement (federal blind gate)', status: 'active' },
  { control: 'CP-9', desc: 'System Backup (8-shard holographic)', status: 'active' },
  { control: 'CA-7', desc: 'Continuous Monitoring (512-bit audit)', status: 'active' },
];

const PENTAD = [
  'Physical spacetime geometry — hardware signature match',
  'Biological / human-in-the-loop intent — multi-signature Handover of Agency',
  'Intentional / relational data flows — cross-shard verification',
  'Computational AI precision — zero-parameter pipelines',
  'Holographic trust saturation — divergence to absolute zero',
];

export default function RegulatorView({ state }) {
  const { regulator, hour } = state;
  const intercepted = regulator.sentinelStatus === 'INTERCEPTED';

  return (
    <div className="space-y-4">
      <div className="bg-[#12161A] border border-[#ff9f0a]/30 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Shield size={14} className="text-[#ff9f0a]" />
          <span className="text-xs font-bold text-[#ff9f0a]">Sentinel Load Balancer — Override Interception</span>
          <span className="text-[9px] text-[#484f58] ml-auto">Hour {hour.toFixed(2)}</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Metric label="OSCAL Dossiers" value={regulator.oscalDossiers} color="#ff9f0a" />
          <Metric label="Override Attempts" value={regulator.overrideAttempts} color={intercepted ? '#ff3b30' : '#10b981'} />
          <Metric label="Dossier Latency" value={`${regulator.dossierLatencyMs}ms`} color="#10b981" />
          <Metric label="Sentinel" value={regulator.sentinelStatus} color={intercepted ? '#ff3b30' : '#10b981'} />
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-[9px] text-[#8b949e]">
          <Clock size={10} className="text-[#10b981]" /> Public-record latency guarantee: under 500ms (POSIX atomic rename)
        </div>
      </div>

      {/* Override log */}
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2"><Zap size={12} className="text-[#ff3b30]" /><span className="text-xs font-bold text-[#e6edf3]">Override Interception Log</span></div>
        <div className="space-y-1">
          {Array.from({ length: Math.min(regulator.overrideAttempts, 3) }).map((_, i) => (
            <div key={i} className="text-[9px] font-mono bg-[#0d1117] border border-[#ff3b30]/20 rounded px-2 py-1 text-[#ff3b30]">
              ⛔ Admin override #{i + 1} intercepted → tally frozen → telemetry snapshot → OSCAL dossier written → public transparency dashboard
            </div>
          ))}
          {regulator.overrideAttempts === 0 && <div className="text-[9px] text-[#484f58] italic">No override attempts — Sentinel nominal.</div>}
        </div>
      </div>

      {/* NIST controls */}
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2"><FileText size={12} className="text-[#3b8bff]" /><span className="text-xs font-bold text-[#e6edf3]">NIST SP-800-53 Rev 5 Control Mapping</span></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {NIST_CONTROLS.map((n) => (
            <div key={n.control} className="flex items-center gap-2 bg-[#0d1117] border border-[#30363d] rounded p-2">
              <span className="text-[9px] font-bold text-[#3b8bff] w-12 shrink-0">{n.control}</span>
              <span className="text-[9px] text-[#8b949e] flex-1">{n.desc}</span>
              <span className="text-[8px] px-1.5 py-0.5 rounded bg-[#10b981]/10 text-[#10b981] border border-[#10b981]/20">{n.status}</span>
            </div>
          ))}
        </div>
      </div>

      {/* HILS Pentad */}
      <div className="bg-[#12161A] border border-[#bc8cff]/20 rounded-lg p-4">
        <div className="text-xs font-bold text-[#bc8cff] mb-2">HILS 5-Body Governance Matrix (Unitary Pentad)</div>
        <div className="space-y-1">
          {PENTAD.map((p, i) => (
            <div key={i} className="flex items-center gap-2 text-[10px] text-[#8b949e]">
              <span className="w-5 h-5 rounded-full bg-[#bc8cff]/10 border border-[#bc8cff]/30 text-[#bc8cff] font-bold flex items-center justify-center text-[9px]">{i + 1}</span>
              <span>{p}</span>
              <span className="ml-auto text-[#10b981] text-[9px]">✓</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Metric({ label, value, color }) {
  return (
    <div className="bg-[#0d1117] border border-[#30363d] rounded p-2 text-center">
      <div className="text-[8px] text-[#8b949e] uppercase tracking-wider">{label}</div>
      <div className="text-xs font-bold" style={{ color }}>{value}</div>
    </div>
  );
}