/**
 * FederalView — federal blind audit gate dashboard.
 * The federal tier receives ONLY OSCAL 1.5.0 Holon Zero ZK certificates.
 * Any raw-ballot data query raises a RawDataAccessAttempt and is blocked.
 * This is the compliance window view seen by EAC / CISA / NIST observers.
 */
import { Flag, Lock, Ban, FileCheck2 } from 'lucide-react';

export default function FederalView({ state }) {
  const { federal, integrity, hour } = state;
  const compliance = federal.complianceWindow === 'OPEN';

  return (
    <div className="space-y-4">
      <div className="bg-[#12161A] border border-[#bc8cff]/30 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Flag size={14} className="text-[#bc8cff]" />
          <span className="text-xs font-bold text-[#bc8cff]">Federal Blind Audit Gate</span>
          <span className="text-[9px] text-[#484f58] ml-auto">Hour {hour.toFixed(2)}</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Metric label="ZK Certs Validated" value={federal.zkCertsEmitted} color="#bc8cff" />
          <Metric label="Raw Access Blocked" value={federal.rawAccessBlocked} color="#ff3b30" />
          <Metric label="Compliance Window" value={federal.complianceWindow} color={compliance ? '#10b981' : '#ff9f0a'} />
          <Metric label="Audit Mode" value="BLIND" color="#3b8bff" />
        </div>
      </div>

      {/* ZK certificate */}
      <div className="bg-[#12161A] border border-[#bc8cff]/20 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2"><Lock size={12} className="text-[#bc8cff]" /><span className="text-xs font-bold text-[#bc8cff]">Zero-Knowledge Certificate</span></div>
        <div className="text-[10px] text-[#8b949e] mb-2">Federal tier validates only the proof status — it cannot see ballot counts, candidate tallies, or county-level raw data.</div>
        <div className="bg-[#0d1117] border border-[#30363d] rounded p-2 font-mono text-[10px] text-[#bc8cff] break-all">
          {integrity.zkCertValid ? `phi_verified=true · k_cs_verified=true · proof_status=VALID · state_hash=${integrity.hashChainHead}` : 'phi_verified=pending · proof_status=AWAITING_CLOSURE'}
        </div>
      </div>

      {/* Raw data access attempts log */}
      <div className="bg-[#12161A] border border-[#ff3b30]/30 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2"><Ban size={12} className="text-[#ff3b30]" /><span className="text-xs font-bold text-[#ff3b30]">RawDataAccessAttempt — Blocked Queries</span></div>
        <div className="text-[10px] text-[#8b949e] mb-2">Any attempt to query raw ballot integers at the federal tier is intercepted and logged. {federal.rawAccessBlocked} attempt(s) blocked this cycle.</div>
        <div className="space-y-1">
          {Array.from({ length: Math.min(federal.rawAccessBlocked, 4) }).map((_, i) => (
            <div key={i} className="text-[9px] text-[#ff3b30] font-mono bg-[#0d1117] border border-[#ff3b30]/20 rounded px-2 py-1">
              ⛔ BLOCKED — federal_query(raw_ballots) from observer_node_{i + 1} · RawDataAccessAttempt raised · OSCAL dossier emitted
            </div>
          ))}
          {federal.rawAccessBlocked === 0 && <div className="text-[9px] text-[#484f58] italic">No raw-data queries attempted — blind audit gate holding.</div>}
        </div>
      </div>

      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-3 flex items-center gap-2">
        <FileCheck2 size={12} className="text-[#10b981]" />
        <span className="text-[10px] text-[#8b949e]">NIST SP-800-53 Rev 5 · AC-3 (Access Enforcement) · OSCAL 1.5.0 component definition attached.</span>
      </div>
    </div>
  );
}

function Metric({ label, value, color }) {
  return (
    <div className="bg-[#0d1117] border border-[#30363d] rounded p-2 text-center">
      <div className="text-[8px] text-[#8b949e] uppercase tracking-wider">{label}</div>
      <div className="text-xs font-bold" style={{ color }}>{value}</div>
    </div>
  );
}