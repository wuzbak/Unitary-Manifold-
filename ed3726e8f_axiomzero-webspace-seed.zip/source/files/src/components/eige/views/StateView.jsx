/**
 * StateView — state-wide topological aggregation dashboard.
 * Cross-county braid synchronization, Holon Zero Certificate emission, and the
 * aggregate metric closure (φ_eff ≈ π/4, k_CS = 74). The state tier receives
 * encrypted shard telemetry only — never raw ballots.
 */
import { DEMO_CANDIDATES } from '@/lib/eige/eigeDemoEngine';
import { Landmark, GitBranch, ShieldCheck } from 'lucide-react';

export default function StateView({ state }) {
  const { counties, integrity, hour, totals, totalVotes } = state;
  const verified = counties.filter((c) => c.verified).length;
  const reporting = counties.filter((c) => c.votes > 0).length;
  const phiOk = Math.abs(integrity.phiDrift) < 1e-12;
  const maxCounty = Math.max(1, ...counties.map((c) => c.votes));

  return (
    <div className="space-y-4">
      <div className="bg-[#12161A] border border-[#10b981]/30 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Landmark size={14} className="text-[#10b981]" />
          <span className="text-xs font-bold text-[#10b981]">State Aggregation Core — Washington</span>
          <span className="text-[9px] text-[#484f58] ml-auto">Hour {hour.toFixed(2)}</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Metric label="Counties Reporting" value={`${reporting}/39`} color="#e6edf3" />
          <Metric label="Braid Sync" value={verified === 39 ? 'SYNCED' : 'IN PROGRESS'} color={verified === 39 ? '#10b981' : '#ff9f0a'} />
          <Metric label="φ_eff" value={integrity.phiEff.toFixed(15)} color={phiOk ? '#10b981' : '#ff3b30'} />
          <Metric label="k_CS" value={integrity.kCs} color="#10b981" />
        </div>
      </div>

      {/* Holon Zero Certificate */}
      <div className="bg-[#12161A] border border-[#bc8cff]/20 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2"><ShieldCheck size={12} className="text-[#bc8cff]" /><span className="text-xs font-bold text-[#bc8cff]">Holon Zero Certificate</span></div>
        <div className="text-[10px] text-[#8b949e] mb-2">State-wide topological closure emits a single zero-knowledge certificate for the federal tier. Status: <span className="text-[#10b981] font-bold">{integrity.zkCertValid ? 'EMITTED' : 'PENDING'}</span></div>
        <div className="text-[10px] text-[#bc8cff] font-mono break-all bg-[#0d1117] border border-[#30363d] rounded p-2">{integrity.hashChainHead}</div>
      </div>

      {/* Per-county tally */}
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3"><GitBranch size={12} className="text-[#3b8bff]" /><span className="text-xs font-bold text-[#e6edf3]">Cross-County Braid — Per-County Tally</span></div>
        <div className="max-h-64 overflow-y-auto space-y-1">
          {counties.map((c) => {
            const leader = ['A', 'B', 'C'].reduce((best, id) => (c[id] > c[best] ? id : best), 'A');
            const cand = DEMO_CANDIDATES.find((x) => x.id === leader);
            return (
              <div key={c.name} className="flex items-center gap-2 text-[10px] py-1 border-b border-[#30363d]/40">
                <span className="w-24 truncate text-[#e6edf3]">{c.name}</span>
                <div className="flex-1 h-2 bg-[#0d1117] rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${(c.votes / maxCounty) * 100}%`, background: cand.color }} />
                </div>
                <span className="w-16 text-right text-[#8b949e]">{c.votes.toLocaleString()}</span>
                <span className="w-6 text-center font-bold" style={{ color: c.verified ? '#10b981' : '#ff3b30' }}>{c.anomalies > 0 ? '⚠' : '✓'}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Metric({ label, value, color }) {
  return (
    <div className="bg-[#0d1117] border border-[#30363d] rounded p-2 text-center">
      <div className="text-[8px] text-[#8b949e] uppercase tracking-wider">{label}</div>
      <div className="text-xs font-bold" style={{ color }}>{value}</div>
    </div>
  );
}