/**
 * PublicView — citizen-facing live results dashboard.
 * Shows the verified public record: live tally, turnout, leader, Holon Zero
 * certificate status, public trust index, and freedom floor — the data a voter
 * sees on election night. No raw ballot data; only the verified aggregate.
 */
import { DEMO_CANDIDATES } from '@/lib/eige/eigeDemoEngine';
import { CheckCircle2, AlertTriangle, Users, ShieldCheck, Lock } from 'lucide-react';

export default function PublicView({ state }) {
  const { totals, totalVotes, totalVoters, winner, integrity, hour } = state;
  const turnoutPct = totalVoters > 0 ? ((totalVotes / totalVoters) * 100).toFixed(1) : '0.0';
  const sorted = [...DEMO_CANDIDATES].sort((a, b) => totals[b.id] - totals[a.id]);
  const maxVotes = Math.max(1, ...DEMO_CANDIDATES.map((c) => totals[c.id]));
  const otherVotes = totals.other;
  const trustIndex = integrity.zkCertValid ? 99.99 : Math.max(0, 99.99 - integrity.totalAnomalies * 0.3);

  return (
    <div className="space-y-4">
      {/* Headline */}
      <div className="bg-[#12161A] border border-[#3b8bff]/30 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-1">
          <Users size={14} className="text-[#3b8bff]" />
          <span className="text-xs font-bold text-[#3b8bff]">Live Public Record</span>
          <span className="text-[9px] text-[#484f58] ml-auto">Hour {hour.toFixed(2)} / 24</span>
        </div>
        <div className="grid grid-cols-3 gap-3 mt-2">
          <div className="text-center">
            <div className="text-[8px] text-[#8b949e] uppercase tracking-wider">Ballots Counted</div>
            <div className="text-xl text-[#e6edf3] font-bold">{totalVotes.toLocaleString()}</div>
          </div>
          <div className="text-center">
            <div className="text-[8px] text-[#8b949e] uppercase tracking-wider">Turnout</div>
            <div className="text-xl text-[#3b8bff] font-bold">{turnoutPct}%</div>
          </div>
          <div className="text-center">
            <div className="text-[8px] text-[#8b949e] uppercase tracking-wider">Current Leader</div>
            <div className="text-xl font-bold" style={{ color: DEMO_CANDIDATES.find((c) => c.id === winner).color }}>
              {winner}
            </div>
          </div>
        </div>
      </div>

      {/* Live results bars */}
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="text-xs font-bold text-[#e6edf3] mb-3">Live Results — Federal Race</div>
        <div className="space-y-3">
          {sorted.map((c) => {
            const pct = totalVotes > 0 ? ((totals[c.id] / totalVotes) * 100).toFixed(1) : '0.0';
            return (
              <div key={c.id}>
                <div className="flex justify-between text-[10px] mb-1">
                  <span className="font-bold" style={{ color: c.color }}>{c.name} · <span className="text-[#8b949e]">{c.party}</span></span>
                  <span className="text-[#e6edf3]">{totals[c.id].toLocaleString()} ({pct}%)</span>
                </div>
                <div className="w-full bg-[#0d1117] rounded-full h-3">
                  <div className="h-3 rounded-full transition-all" style={{ width: `${(totals[c.id] / maxVotes) * 100}%`, background: c.color }} />
                </div>
              </div>
            );
          })}
          <div>
            <div className="flex justify-between text-[10px] mb-1">
              <span className="font-bold text-[#8b949e]">GREEN + RAINBOW (other)</span>
              <span className="text-[#e6edf3]">{otherVotes.toLocaleString()}</span>
            </div>
            <div className="w-full bg-[#0d1117] rounded-full h-2">
              <div className="h-2 rounded-full transition-all" style={{ width: `${(otherVotes / maxVotes) * 100}%`, background: 'linear-gradient(90deg,#3fb950,#f7b955)' }} />
            </div>
          </div>
        </div>
      </div>

      {/* Trust + freedom floor */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="bg-[#12161A] border border-[#10b981]/30 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-1"><ShieldCheck size={12} className="text-[#10b981]" /><span className="text-[10px] font-bold text-[#10b981]">Public Trust Index</span></div>
          <div className="text-lg font-bold text-[#10b981]">{trustIndex.toFixed(2)}%</div>
          <div className="text-[9px] text-[#8b949e]">Holon Zero Certificate {integrity.zkCertValid ? 'verified' : 'pending'} · risk-limit under 1%</div>
        </div>
        <div className="bg-[#12161A] border rounded-lg p-3" style={{ borderColor: integrity.freedomFloor ? '#10b98140' : '#ff3b3040' }}>
          <div className="flex items-center gap-2 mb-1"><Lock size={12} style={{ color: integrity.freedomFloor ? '#10b981' : '#ff3b30' }} /><span className="text-[10px] font-bold" style={{ color: integrity.freedomFloor ? '#10b981' : '#ff3b30' }}>Freedom Floor</span></div>
          <div className="text-lg font-bold" style={{ color: integrity.freedomFloor ? '#10b981' : '#ff3b30' }}>{integrity.freedomFloor ? 'SATISFIED' : 'VIOLATED'}</div>
          <div className="text-[9px] text-[#8b949e]">{integrity.verifiedCount}/39 counties participating</div>
        </div>
      </div>

      <div className="bg-[#3b8bff]/5 border border-[#3b8bff]/20 rounded-lg p-3">
        <div className="flex items-start gap-2 text-[10px] text-[#8b949e]">
          {integrity.zkCertValid ? <CheckCircle2 size={12} className="text-[#10b981] mt-0.5 shrink-0" /> : <AlertTriangle size={12} className="text-[#ff9f0a] mt-0.5 shrink-0" />}
          <span>This public dashboard receives only a zero-knowledge certificate proving the election's integrity. No raw ballot data ever leaves the county tier. Individual votes remain private.</span>
        </div>
      </div>
    </div>
  );
}