const STATUS_STYLES = {
  completed: { badge: 'bg-[#1a3a25] text-[#3fb950]', dot: 'bg-[#3fb950]', label: 'Completed' },
  active: { badge: 'bg-[#0d2040] text-[#58a6ff]', dot: 'bg-[#58a6ff]', label: 'Active' },
  upcoming: { badge: 'bg-[#3a2d0a] text-[#d29922]', dot: 'bg-[#d29922]', label: 'Upcoming' },
  external: { badge: 'bg-[#2a1a3a] text-[#bc8cff]', dot: 'bg-[#bc8cff]', label: 'External Decision' }
};

export default function RoadmapPhase({ phase, isLast }) {
  const style = STATUS_STYLES[phase.status] || STATUS_STYLES.upcoming;
  return (
    <div className="flex gap-4">
      <div className="flex flex-col items-center">
        <div className={`w-3 h-3 rounded-full ${style.dot} ring-4 ring-[#0d1117] shrink-0 mt-1`} />
        {!isLast && <div className="w-px flex-1 bg-[#30363d] mt-1" />}
      </div>
      <div className="flex-1 pb-6">
        <div className="flex items-center gap-2 mb-1 flex-wrap">
          <span className={`px-2 py-0.5 rounded text-xs font-bold ${style.badge}`}>{style.label}</span>
          <span className="text-[#8b949e] text-xs">{phase.period}</span>
        </div>
        <h3 className="text-[#e6edf3] font-bold text-sm mb-1">{phase.version}</h3>
        <p className="text-[#8b949e] text-xs leading-relaxed mb-2">{phase.description}</p>
        {phase.deliverables && (
          <ul className="text-[#8b949e] text-xs space-y-1 list-disc pl-4">
            {phase.deliverables.map((d, i) => <li key={i}>{d}</li>)}
          </ul>
        )}
      </div>
    </div>
  );
}