import { Link } from 'react-router-dom';
import { useLiveStatus } from '@/hooks/useLiveStatus';
import { Activity, FlaskConical, Database, Award, GitBranch, FileText, Loader2 } from 'lucide-react';

/**
 * LiveRepoBadge — compact live tracker for the Repository page.
 * Pulls real-time repo metrics (version, tests, pillars, lean4) via useLiveStatus.
 * Read-only — never writes to the repository.
 */
export default function LiveRepoBadge() {
  const { status, live, loading } = useLiveStatus();

  const metrics = [
    { label: 'Version', value: status.version || '—', icon: GitBranch, color: '#00f5ff' },
    { label: 'Tests Passed', value: status.tests_passed?.toLocaleString() || '—', icon: FlaskConical, color: '#3fb950' },
    { label: 'Pillars', value: status.pillars_total ?? '—', icon: Database, color: '#FF9F00' },
    { label: 'Lean4 Theorems', value: status.lean4_theorems?.toLocaleString() || '—', icon: Award, color: '#bc8cff' },
  ];

  return (
    <div className="rounded-lg border border-[#00f5ff]/20 bg-gradient-to-br from-[#0a0a12] via-[#0d1117] to-[#0a0a12] p-4 mb-6 clip-corner">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Activity size={14} className="text-[#00f5ff]" />
          <span className="text-[#e6edf3] text-xs font-bold uppercase tracking-wider">Live Repository Status</span>
          <span className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold border ${loading ? 'bg-[#8b949e]/10 text-[#8b949e] border-[#8b949e]/30' : live ? 'bg-[#3fb950]/10 text-[#3fb950] border-[#3fb950]/30' : 'bg-[#FF9F00]/10 text-[#FF9F00] border-[#FF9F00]/30'}`}>
            {loading ? <Loader2 size={8} className="animate-spin" /> : <span className={`w-1.5 h-1.5 rounded-full ${live ? 'bg-[#3fb950] glow-pulse' : 'bg-[#FF9F00]'}`} />}
            {loading ? 'SYNCING' : live ? 'LIVE' : 'OFFLINE'}
          </span>
        </div>
        <Link to="/manifold-explorer" className="flex items-center gap-1 text-[#00f5ff] text-[10px] hover:text-[#00f5ff]/80 transition-colors">
          <FileText size={11} /> Live Docs →
        </Link>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {metrics.map((m) => (
          <div key={m.label} className="bg-[#0a0a12]/60 border border-[#30363d] rounded p-2.5">
            <div className="flex items-center gap-1.5 text-[#8b949e] text-[9px] uppercase tracking-wider mb-1">
              <m.icon size={10} style={{ color: m.color }} /> {m.label}
            </div>
            <div className="text-[#e6edf3] text-base sm:text-lg font-bold font-mono">{m.value}</div>
          </div>
        ))}
      </div>
      <div className="text-[#484f58] text-[9px] mt-2 flex items-center gap-1.5">
        <span className={`w-1 h-1 rounded-full ${live ? 'bg-[#3fb950]' : 'bg-[#FF9F00]'}`} />
        source: {status._source || (live ? 'live' : 'static fallback')} · pulled from github.com/wuzbak/Unitary-Manifold- · read-only
      </div>
    </div>
  );
}