import { useState } from 'react';
import ArticleLibrary from './ArticleLibrary';
import ArticleReader from './ArticleReader';

/**
 * ArticlesTab — dedicated Articles & Books reader tab for the Repository page.
 * Left sidebar: searchable library of all .md files in 7-OUTREACH/ and manuscript folders.
 * Right pane: full article reader with TTS and in-article search.
 */
export default function ArticlesTab({ entries }) {
  const [selectedPath, setSelectedPath] = useState('');

  return (
    <div className="flex" style={{ height: '70vh' }}>
      <div className="w-72 shrink-0 border-r border-[#30363d] overflow-hidden">
        <ArticleLibrary
          entries={entries}
          selectedPath={selectedPath}
          onSelect={setSelectedPath}
        />
      </div>
      <div className="flex-1 min-w-0 bg-[#0d1117]">
        <ArticleReader path={selectedPath} />
      </div>
    </div>
  );
}