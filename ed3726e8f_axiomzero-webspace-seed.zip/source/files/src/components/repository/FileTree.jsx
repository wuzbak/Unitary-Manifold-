import { useState, useEffect } from 'react';
import { Folder, FolderOpen, FileText, ChevronRight, ChevronDown } from 'lucide-react';

function buildTree(entries) {
  const root = { name: '', path: '', type: 'tree', children: {} };
  for (const entry of entries) {
    const parts = entry.path.split('/');
    let current = root;
    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      const isLast = i === parts.length - 1;
      if (!current.children[part]) {
        current.children[part] = {
          name: part,
          path: parts.slice(0, i + 1).join('/'),
          type: isLast ? 'blob' : 'tree',
          size: isLast ? entry.size : undefined,
          children: {}
        };
      }
      current = current.children[part];
    }
  }
  return root;
}

function getSortedChildren(node) {
  return Object.values(node.children).sort((a, b) => {
    if (a.type !== b.type) return a.type === 'tree' ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
}

function TreeNode({ node, depth, selectedPath, onSelect, expanded, toggleExpand }) {
  const isFolder = node.type === 'tree';
  const isOpen = expanded[node.path];
  const children = getSortedChildren(node);
  const Icon = isFolder ? (isOpen ? FolderOpen : Folder) : FileText;

  return (
    <div>
      <div
        className={`flex items-center gap-1 py-1 pr-2 cursor-pointer hover:bg-[#21262d] text-xs ${selectedPath === node.path ? 'bg-[#0d2040] text-[#58a6ff]' : 'text-[#e6edf3]'}`}
        style={{ paddingLeft: `${depth * 12 + 8}px` }}
        onClick={() => isFolder ? toggleExpand(node.path) : onSelect(node.path)}
      >
        {isFolder ? (
          isOpen ? <ChevronDown size={12} className="shrink-0" /> : <ChevronRight size={12} className="shrink-0" />
        ) : (
          <span className="w-3 shrink-0" />
        )}
        <Icon size={14} className={`shrink-0 ${isFolder ? 'text-[#d29922]' : 'text-[#8b949e]'}`} />
        <span className="truncate">{node.name}</span>
      </div>
      {isFolder && isOpen && children.map((child) => (
        <TreeNode
          key={child.path}
          node={child}
          depth={depth + 1}
          selectedPath={selectedPath}
          onSelect={onSelect}
          expanded={expanded}
          toggleExpand={toggleExpand}
        />
      ))}
    </div>
  );
}

export default function FileTree({ entries, selectedPath, onSelect }) {
  const [expanded, setExpanded] = useState({});
  const tree = buildTree(entries);

  const toggleExpand = (path) => {
    setExpanded((prev) => ({ ...prev, [path]: !prev[path] }));
  };

  // Auto-expand all ancestor folders of the selected file so it is visible
  // in the tree — essential for deep-linking from cosmic element clicks.
  useEffect(() => {
    if (!selectedPath || !selectedPath.includes('/')) return;
    const parts = selectedPath.split('/');
    const ancestors = {};
    for (let i = 1; i < parts.length; i++) {
      ancestors[parts.slice(0, i).join('/')] = true;
    }
    setExpanded((prev) => ({ ...prev, ...ancestors }));
  }, [selectedPath]);

  const rootChildren = getSortedChildren(tree);

  return (
    <div className="py-2">
      {rootChildren.map((child) => (
        <TreeNode
          key={child.path}
          node={child}
          depth={0}
          selectedPath={selectedPath}
          onSelect={onSelect}
          expanded={expanded}
          toggleExpand={toggleExpand}
        />
      ))}
    </div>
  );
}