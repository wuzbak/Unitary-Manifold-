import { useState, useMemo } from 'react';
import { Search, BookOpen, FileText, ChevronDown, ChevronUp } from 'lucide-react';

/**
 * ArticleLibrary — searchable, sortable list of articles & books discovered in the repo.
 * Filters the fetchRepoTree entries for .md files in 7-OUTREACH/ and manuscript/book folders.
 */
function extractTitle(path) {
  const fileName = path.split('/').pop().replace(/\.md$/i, '');
  // Convert post-013-black-hole-information → Black Hole Information
  return fileName
    .replace(/^\d+-/, '')
    .replace(/^[a-z]/, (c) => c.toUpperCase())
    .replace(/-/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();
}

function extractDate(path) {
  // Try to find a date pattern in the path (e.g. 2024-01-15 or post-013)
  const dateMatch = path.match(/(\d{4})[-/](\d{2})[-/](\d{2})/);
  if (dateMatch) return `${dateMatch[1]}-${dateMatch[2]}-${dateMatch[3]}`;
  return '';
}

function getCategory(path) {
  if (path.includes('substack/posts/')) return 'Substack Post';
  if (path.includes('substack/')) return 'Substack';
  if (path.includes('manuscript/') || path.includes('book/')) return 'Book / Manuscript';
  if (path.includes('7-OUTREACH/')) return 'Outreach';
  return 'Article';
}

export default function ArticleLibrary({ entries, selectedPath, onSelect }) {
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState('path'); // 'path' | 'title'
  const [sortAsc, setSortAsc] = useState(true);

  const articles = useMemo(() => {
    if (!entries?.length) return [];
    return entries
      .filter((e) => {
        if (!e.path.toLowerCase().endsWith('.md')) return false;
        const p = e.path;
        return p.startsWith('7-OUTREACH/') ||
               p.includes('/manuscript/') ||
               p.includes('/book/') ||
               p.includes('/books/') ||
               p.includes('/substack/');
      })
      .map((e) => ({
        path: e.path,
        title: extractTitle(e.path),
        date: extractDate(e.path),
        category: getCategory(e.path),
        size: e.size || 0,
      }));
  }, [entries]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    const list = q
      ? articles.filter((a) => a.title.toLowerCase().includes(q) || a.path.toLowerCase().includes(q))
      : articles;
    const sorted = [...list].sort((a, b) => {
      let cmp;
      if (sortBy === 'title') cmp = a.title.localeCompare(b.title);
      else cmp = a.path.localeCompare(b.path);
      return sortAsc ? cmp : -cmp;
    });
    return sorted;
  }, [articles, search, sortBy, sortAsc]);

  return (
    <div className="h-full flex flex-col bg-[#0d1117]">
      {/* Search bar */}
      <div className="p-3 border-b border-[#30363d] shrink-0">
        <div className="flex items-center gap-1.5 bg-[#161b22] border border-[#30363d] rounded px-2.5 py-1.5 focus-within:border-[#58a6ff]/50 transition-colors">
          <Search size={13} className="text-[#484f58] shrink-0" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search articles..."
            className="bg-transparent text-xs text-[#e6edf3] flex-1 focus:outline-none placeholder:text-[#484f58]"
          />
          {search && (
            <span className="text-[10px] text-[#484f58] shrink-0">{filtered.length} match{filtered.length !== 1 ? 'es' : ''}</span>
          )}
        </div>
        {/* Sort controls */}
        <div className="flex items-center gap-1 mt-2">
          <span className="text-[9px] text-[#484f58] uppercase tracking-wider">Sort:</span>
          <button
            onClick={() => { setSortBy('path'); setSortAsc(true); }}
            className={`text-[10px] px-2 py-0.5 rounded ${sortBy === 'path' ? 'bg-[#58a6ff]/10 text-[#58a6ff]' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
          >Path</button>
          <button
            onClick={() => { setSortBy('title'); setSortAsc(true); }}
            className={`text-[10px] px-2 py-0.5 rounded ${sortBy === 'title' ? 'bg-[#58a6ff]/10 text-[#58a6ff]' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
          >Title</button>
          <button
            onClick={() => setSortAsc(!sortAsc)}
            className="text-[#8b949e] hover:text-[#e6edf3] ml-1"
          >
            {sortAsc ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          </button>
          <span className="ml-auto text-[10px] text-[#484f58]">{articles.length} articles</span>
        </div>
      </div>

      {/* Article list */}
      <div className="flex-1 overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="p-4 text-center">
            <BookOpen size={24} className="mx-auto mb-2 text-[#30363d]" />
            <p className="text-xs text-[#484f58]">{articles.length === 0 ? 'No articles found in repository' : 'No matches'}</p>
          </div>
        ) : (
          filtered.map((article) => {
            const isActive = selectedPath === article.path;
            return (
              <button
                key={article.path}
                onClick={() => onSelect(article.path)}
                className={`w-full text-left px-3 py-2.5 border-b border-[#21262d] transition-colors ${
                  isActive ? 'bg-[#0d2040] border-l-2 border-l-[#58a6ff]' : 'hover:bg-[#161b22] border-l-2 border-l-transparent'
                }`}
              >
                <div className="flex items-start gap-2">
                  <FileText size={12} className={`mt-0.5 shrink-0 ${isActive ? 'text-[#58a6ff]' : 'text-[#484f58]'}`} />
                  <div className="min-w-0 flex-1">
                    <div className={`text-xs font-bold truncate ${isActive ? 'text-[#58a6ff]' : 'text-[#e6edf3]'}`}>
                      {article.title}
                    </div>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#21262d] text-[#8b949e] shrink-0">{article.category}</span>
                      {article.date && <span className="text-[9px] text-[#484f58]">{article.date}</span>}
                      {article.size > 0 && <span className="text-[9px] text-[#484f58]">· {Math.round(article.size / 1024)}KB</span>}
                    </div>
                    <div className="text-[9px] text-[#484f58] truncate mt-0.5 font-mono">{article.path}</div>
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}