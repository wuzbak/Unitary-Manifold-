import { useState, useEffect, useRef, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import { Loader2, ExternalLink, Play, Pause, Square, Search, X, Volume2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import StudioNarration from '@/components/shared/StudioNarration';

const REPO_URL = 'https://github.com/wuzbak/Unitary-Manifold-';
const RAW_BASE = 'https://raw.githubusercontent.com/wuzbak/Unitary-Manifold-/main/';

export default function ArticleReader({ path }) {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [wordCount, setWordCount] = useState(0);

  // TTS state
  const [voices, setVoices] = useState([]);
  const [selectedVoice, setSelectedVoice] = useState('');
  const [rate, setRate] = useState(1.0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const utteranceRef = useRef(null);

  // In-article search state
  const [articleSearch, setArticleSearch] = useState('');
  const [searchMatches, setSearchMatches] = useState([]);
  const [currentMatch, setCurrentMatch] = useState(-1);

  // Fetch article content
  useEffect(() => {
    if (!path) return;
    setLoading(true);
    setError(null);
    setContent('');
    setArticleSearch('');
    setSearchMatches([]);

    // Cancel any ongoing TTS when switching articles
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    setIsSpeaking(false);
    setIsPaused(false);

    base44.functions.invoke('fetchRepoFile', { path })
      .then((res) => {
        const data = res.data || res;
        setContent(data.content || '');
        setWordCount((data.content || '').split(/\s+/).filter(Boolean).length);
      })
      .catch(() => {
        // Fallback to direct fetch if backend function fails
        return fetch(`${RAW_BASE}${path}`)
          .then((r) => { if (!r.ok) throw new Error(`Failed (${r.status})`); return r.text(); })
          .then((text) => {
            setContent(text);
            setWordCount(text.split(/\s+/).filter(Boolean).length);
          })
          .catch((e2) => setError(e2.message || 'Failed to load article'));
      })
      .finally(() => setLoading(false));
  }, [path]);

  // Load TTS voices
  useEffect(() => {
    if (!window.speechSynthesis) return;
    const loadVoices = () => {
      const v = window.speechSynthesis.getVoices();
      setVoices(v);
      if (v.length && !selectedVoice) {
        const enVoice = v.find((voice) => voice.lang.startsWith('en')) || v[0];
        setSelectedVoice(enVoice.name);
      }
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
    return () => { if (window.speechSynthesis) window.speechSynthesis.onvoiceschanged = null; };
  }, []);

  // TTS play
  const handlePlay = useCallback(() => {
    if (!window.speechSynthesis || !content) return;
    window.speechSynthesis.cancel();

    // Strip markdown for speech
    const plainText = content
      .replace(/```[\s\S]*?```/g, ' code block. ')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/!\[.*?\]\(.*?\)/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/^#{1,6}\s+/gm, '')
      .replace(/[*_~]/g, '')
      .replace(/\n{3,}/g, '\n\n');

    const utterance = new SpeechSynthesisUtterance(plainText);
    utterance.rate = rate;
    if (selectedVoice) {
      const voice = voices.find((v) => v.name === selectedVoice);
      if (voice) utterance.voice = voice;
    }
    utterance.onend = () => { setIsSpeaking(false); setIsPaused(false); };
    utterance.onerror = () => { setIsSpeaking(false); setIsPaused(false); };
    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
    setIsPaused(false);
  }, [content, rate, selectedVoice, voices]);

  const handlePause = () => {
    if (!window.speechSynthesis) return;
    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    } else {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  const handleStop = () => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
    setIsPaused(false);
  };

  // Cleanup TTS on unmount
  useEffect(() => {
    return () => { if (window.speechSynthesis) window.speechSynthesis.cancel(); };
  }, []);

  // In-article search
  useEffect(() => {
    if (!articleSearch.trim() || !content) {
      setSearchMatches([]);
      setCurrentMatch(-1);
      return;
    }
    const q = articleSearch.toLowerCase();
    const matches = [];
    let idx = content.toLowerCase().indexOf(q);
    while (idx !== -1) {
      matches.push(idx);
      idx = content.toLowerCase().indexOf(q, idx + 1);
    }
    setSearchMatches(matches);
    setCurrentMatch(matches.length > 0 ? 0 : -1);
  }, [articleSearch, content]);

  const fileName = path ? path.split('/').pop() : '';

  // Highlight search matches in content for markdown rendering
  const renderContent = (() => {
    if (!articleSearch.trim() || !content || searchMatches.length === 0) return content;
    const q = articleSearch;
    const regex = new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    return content.replace(regex, '==$1==');
  })();

  if (!path) {
    return (
      <div className="flex items-center justify-center h-full text-[#8b949e]">
        <div className="text-center">
          <Volume2 size={32} className="mx-auto mb-2 opacity-30" />
          <p className="text-sm">Select an article from the library to read</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Toolbar */}
      <div className="px-4 py-2.5 border-b border-[#30363d] bg-[#161b22] shrink-0">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-[#e6edf3] text-sm font-bold truncate">{fileName}</span>
            {wordCount > 0 && <span className="text-[10px] text-[#484f58] shrink-0">{wordCount.toLocaleString()} words</span>}
          </div>
          <div className="flex items-center gap-2">
            {/* In-article search */}
            <div className="flex items-center gap-1 bg-[#0d1117] border border-[#30363d] rounded px-2 py-1">
              <Search size={11} className="text-[#484f58]" />
              <input
                type="text"
                value={articleSearch}
                onChange={(e) => setArticleSearch(e.target.value)}
                placeholder="Find in article..."
                className="bg-transparent text-[10px] text-[#e6edf3] w-28 focus:outline-none placeholder:text-[#484f58]"
              />
              {searchMatches.length > 0 && (
                <span className="text-[9px] text-[#484f58]">{currentMatch + 1}/{searchMatches.length}</span>
              )}
              {articleSearch && (
                <button onClick={() => setArticleSearch('')} className="text-[#484f58] hover:text-[#e6edf3]">
                  <X size={10} />
                </button>
              )}
            </div>
            <a href={`${REPO_URL}/blob/main/${path}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-[#58a6ff] text-xs hover:underline shrink-0">
              <ExternalLink size={12} /> GitHub
            </a>
          </div>
        </div>

        {/* TTS controls */}
        <div className="flex items-center gap-2 mt-2 flex-wrap">
          {!isSpeaking ? (
            <button onClick={handlePlay} disabled={!content} className="flex items-center gap-1.5 bg-[#58a6ff]/10 text-[#58a6ff] border border-[#58a6ff]/30 px-3 py-1 rounded text-[11px] font-bold hover:bg-[#58a6ff]/20 transition-colors disabled:opacity-40">
              <Play size={12} /> Read Aloud
            </button>
          ) : (
            <>
              <button onClick={handlePause} className="flex items-center gap-1.5 bg-[#FF9F00]/10 text-[#FF9F00] border border-[#FF9F00]/30 px-3 py-1 rounded text-[11px] font-bold hover:bg-[#FF9F00]/20 transition-colors">
                {isPaused ? <Play size={12} /> : <Pause size={12} />} {isPaused ? 'Resume' : 'Pause'}
              </button>
              <button onClick={handleStop} className="flex items-center gap-1.5 bg-[#f85149]/10 text-[#f85149] border border-[#f85149]/30 px-3 py-1 rounded text-[11px] font-bold hover:bg-[#f85149]/20 transition-colors">
                <Square size={12} /> Stop
              </button>
            </>
          )}
          {voices.length > 0 && (
            <select
              value={selectedVoice}
              onChange={(e) => setSelectedVoice(e.target.value)}
              className="bg-[#0d1117] border border-[#30363d] text-[#e6edf3] text-[10px] rounded px-2 py-1 focus:outline-none focus:border-[#58a6ff]/50 max-w-[160px]"
            >
              {voices.filter((v) => v.lang.startsWith('en')).map((v) => (
                <option key={v.name} value={v.name}>{v.name} ({v.lang})</option>
              ))}
            </select>
          )}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-[#484f58]">Speed:</span>
            <input
              type="range"
              min="0.5"
              max="2"
              step="0.1"
              value={rate}
              onChange={(e) => setRate(parseFloat(e.target.value))}
              className="w-16 accent-[#58a6ff]"
            />
            <span className="text-[10px] text-[#8b949e] w-7">{rate.toFixed(1)}x</span>
          </div>
        </div>

        {/* Studio Narration — premium AI narration tier (consumes credits) */}
        {content && <StudioNarration text={content} />}
      </div>

      {/* Reading pane */}
      <div className="flex-1 overflow-auto">
        {loading && (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="animate-spin text-[#58a6ff]" size={24} />
          </div>
        )}
        {error && (
          <div className="p-4">
            <p className="text-[#f85149] text-sm">{error}</p>
          </div>
        )}
        {!loading && !error && (
          <div className="max-w-3xl mx-auto px-6 py-8
            [&_h1]:text-[#58a6ff] [&_h1]:text-2xl [&_h1]:font-bold [&_h1]:mb-4 [&_h1]:mt-2
            [&_h2]:text-[#bc8cff] [&_h2]:text-xl [&_h2]:font-bold [&_h2]:mb-3 [&_h2]:mt-6
            [&_h3]:text-[#58a6ff] [&_h3]:text-lg [&_h3]:font-bold [&_h3]:mb-2 [&_h3]:mt-5
            [&_h4]:text-[#e6edf3] [&_h4]:text-base [&_h4]:font-bold [&_h4]:mb-2 [&_h4]:mt-4
            [&_p]:text-[#c9d1d9] [&_p]:text-sm [&_p]:leading-relaxed [&_p]:mb-4
            [&_a]:text-[#58a6ff] [&_a]:underline [&_a]:hover:text-[#79c0ff]
            [&_code]:bg-[#0a0d11] [&_code]:text-[#79c0ff] [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:rounded [&_code]:text-xs [&_code]:font-mono
            [&_pre]:bg-[#0a0d11] [&_pre]:p-4 [&_pre]:rounded-lg [&_pre]:overflow-x-auto [&_pre]:text-xs [&_pre]:my-4 [&_pre]:border [&_pre]:border-[#30363d]
            [&_blockquote]:border-l-2 [&_blockquote]:border-[#58a6ff]/40 [&_blockquote]:pl-4 [&_blockquote]:text-[#8b949e] [&_blockquote]:italic [&_blockquote]:my-4
            [&_img]:rounded-lg [&_img]:my-4 [&_img]:max-w-full
            [&_ul]:list-disc [&_ul]:pl-6 [&_ul]:text-[#c9d1d9] [&_ul]:text-sm [&_ul]:mb-4 [&_ul]:space-y-1
            [&_ol]:list-decimal [&_ol]:pl-6 [&_ol]:text-[#c9d1d9] [&_ol]:text-sm [&_ol]:mb-4 [&_ol]:space-y-1
            [&_li]:text-[#c9d1d9] [&_li]:text-sm
            [&_hr]:border-[#30363d] [&_hr]:my-6
            [&_strong]:text-[#e6edf3] [&_strong]:font-bold
            [&_em]:text-[#c9d1d9] [&_em]:italic
            [&_table]:w-full [&_table]:my-4 [&_table]:border-collapse
            [&_th]:border [&_th]:border-[#30363d] [&_th]:bg-[#161b22] [&_th]:px-3 [&_th]:py-1.5 [&_th]:text-left [&_th]:text-xs [&_th]:font-bold [&_th]:text-[#e6edf3]
            [&_td]:border [&_td]:border-[#30363d] [&_td]:px-3 [&_td]:py-1.5 [&_td]:text-xs [&_td]:text-[#c9d1d9]
          ">
            <ReactMarkdown
              components={{
                p: ({ children }) => {
                  if (typeof children === 'string') {
                    const parts = children.split(/(==[^=]+==)/g);
                    if (parts.length > 1) {
                      return <p>{parts.map((part, i) => part.startsWith('==') && part.endsWith('==') ? <mark key={i} className="bg-[#FF9F00]/30 text-[#e6edf3] rounded px-0.5">{part.slice(2, -2)}</mark> : part)}</p>;
                    }
                  }
                  return <p>{children}</p>;
                },
              }}
            >
              {renderContent || content}
            </ReactMarkdown>
          </div>
        )}
      </div>
    </div>
  );
}