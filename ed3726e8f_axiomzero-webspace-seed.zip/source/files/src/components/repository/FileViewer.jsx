import { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import { ExternalLink, Loader2, FileText } from 'lucide-react';

const REPO_URL = 'https://github.com/wuzbak/Unitary-Manifold-';
const RAW_BASE = 'https://raw.githubusercontent.com/wuzbak/Unitary-Manifold-/main/';

function getFileType(path) {
  const ext = path.split('.').pop()?.toLowerCase();
  if (['md', 'markdown'].includes(ext)) return 'markdown';
  if (['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'ico', 'bmp'].includes(ext)) return 'image';
  if (['pdf'].includes(ext)) return 'pdf';
  return 'code';
}

export default function FileViewer({ path }) {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isTruncated, setIsTruncated] = useState(false);
  const [fullLength, setFullLength] = useState(0);

  useEffect(() => {
    if (!path) return;
    setLoading(true);
    setError(null);
    fetch(`${RAW_BASE}${path}`)
      .then((res) => {
        if (!res.ok) throw new Error(`Failed to fetch file (${res.status})`);
        return res.text();
      })
      .then((text) => {
        const maxLen = 50000;
        if (text.length > maxLen) {
          setContent(text.slice(0, maxLen));
          setIsTruncated(true);
          setFullLength(text.length);
        } else {
          setContent(text);
          setIsTruncated(false);
          setFullLength(text.length);
        }
      })
      .catch((e) => setError(e.message || 'Failed to load file'))
      .finally(() => setLoading(false));
  }, [path]);

  if (!path) {
    return (
      <div className="flex items-center justify-center h-full text-[#8b949e] text-sm">
        <div className="text-center">
          <FileText size={32} className="mx-auto mb-2 opacity-50" />
          <p>Select a file from the tree to view its contents</p>
        </div>
      </div>
    );
  }

  const fileType = getFileType(path);
  const fileName = path.split('/').pop();

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#30363d] bg-[#161b22] shrink-0">
        <span className="text-[#e6edf3] text-sm font-mono truncate">{path}</span>
        <a href={`${REPO_URL}/blob/main/${path}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-[#58a6ff] text-xs hover:underline shrink-0 ml-2">
          <ExternalLink size={12} /> GitHub
        </a>
      </div>

      <div className="flex-1 overflow-auto p-4">
        {loading && (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="animate-spin text-[#58a6ff]" size={24} />
          </div>
        )}
        {error && <p className="text-[#f85149] text-sm">{error}</p>}
        {!loading && !error && fileType === 'markdown' && (
          <div className="text-sm text-[#e6edf3] space-y-3
            [&_h1]:text-[#58a6ff] [&_h1]:text-lg [&_h1]:font-bold [&_h1]:mt-4
            [&_h2]:text-[#bc8cff] [&_h2]:text-base [&_h2]:font-bold [&_h2]:mt-4
            [&_h3]:text-[#58a6ff] [&_h3]:text-sm [&_h3]:font-bold [&_h3]:mt-3
            [&_a]:text-[#58a6ff] [&_a]:underline
            [&_code]:bg-[#0a0d11] [&_code]:px-1 [&_code]:py-0.5 [&_code]:rounded [&_code]:text-xs
            [&_pre]:bg-[#0a0d11] [&_pre]:p-3 [&_pre]:rounded [&_pre]:overflow-x-auto [&_pre]:text-xs [&_pre]:my-2
            [&_blockquote]:border-l-2 [&_blockquote]:border-[#30363d] [&_blockquote]:pl-3 [&_blockquote]:text-[#8b949e] [&_blockquote]:my-2
            [&_img]:inline [&_img]:my-1 [&_img]:max-w-full
            [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:list-decimal [&_ol]:pl-5
            [&_hr]:border-[#30363d] [&_hr]:my-3
            [&_strong]:text-[#e6edf3] [&_strong]:font-bold">
            <ReactMarkdown>{content}</ReactMarkdown>
          </div>
        )}
        {!loading && !error && fileType === 'image' && (
          <img src={`${RAW_BASE}${path}`} alt={fileName} className="max-w-full rounded" />
        )}
        {!loading && !error && fileType === 'pdf' && (
          <embed src={`${RAW_BASE}${path}`} type="application/pdf" className="w-full min-h-[600px]" />
        )}
        {!loading && !error && fileType === 'code' && (
          <pre className="text-xs text-[#e6edf3] overflow-x-auto font-mono bg-[#0a0d11] p-3 rounded">{content}</pre>
        )}
        {isTruncated && !loading && !error && (
          <a href={`${REPO_URL}/blob/main/${path}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 mt-4 text-[#58a6ff] text-sm hover:underline">
            <ExternalLink size={14} /> Read full file on GitHub ({content.length.toLocaleString()} of {fullLength.toLocaleString()} chars shown)
          </a>
        )}
      </div>
    </div>
  );
}