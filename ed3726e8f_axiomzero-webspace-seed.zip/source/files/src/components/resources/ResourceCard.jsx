import { Download, ExternalLink, FileText } from 'lucide-react';

const TYPE_STYLES = {
  PDF: 'bg-[#3a1015] text-[#f85149]',
  Markdown: 'bg-[#0d2040] text-[#58a6ff]',
  Notebook: 'bg-[#1a3a25] text-[#3fb950]',
  Dataset: 'bg-[#3a2d0a] text-[#d29922]',
  YAML: 'bg-[#2a1a3a] text-[#bc8cff]'
};

export default function ResourceCard({ resource }) {
  return (
    <div className="bg-[#161b22] border border-[#30363d] rounded-lg p-4 hover:border-[#58a6ff] transition-colors flex flex-col">
      <div className="flex items-start gap-3 mb-2">
        <FileText size={20} className="text-[#58a6ff] shrink-0 mt-0.5" />
        <div className="flex-1 min-w-0">
          <h3 className="text-[#e6edf3] font-bold text-sm">{resource.title}</h3>
          <p className="text-[#8b949e] text-xs mt-0.5 leading-relaxed">{resource.description}</p>
        </div>
      </div>
      <div className="flex items-center gap-2 mt-auto pt-2">
        <span className={`px-2 py-0.5 rounded text-xs font-bold ${TYPE_STYLES[resource.type] || 'bg-[#21262d] text-[#8b949e]'}`}>{resource.type}</span>
        {resource.size && <span className="text-[#8b949e] text-xs">{resource.size}</span>}
        <a href={resource.url} target="_blank" rel="noopener noreferrer" className="ml-auto flex items-center gap-1 text-[#58a6ff] text-xs hover:underline">
          {resource.download ? <Download size={14} /> : <ExternalLink size={14} />} {resource.download ? 'Download' : 'View'}
        </a>
      </div>
    </div>
  );
}