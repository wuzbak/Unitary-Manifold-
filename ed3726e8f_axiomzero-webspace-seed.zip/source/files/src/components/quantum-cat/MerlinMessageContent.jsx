/**
 * MerlinMessageContent — parses a Merlin response and renders the body (with
 * clickable links + inline gate-badge pills), follow-up chips, and citation
 * cards. Shared between all Merlin surfaces — MerlinHub, GeoMonitor
 * interpreter, Falsification Lab, Cognitive Layer.
 */
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Volume2, Square } from 'lucide-react';
import { renderWithLinks } from '@/lib/merlinEngine';
import { parseMerlinResponse } from './parseMerlinResponse';
import { speak, stopSpeaking } from '@/lib/psicatTts/router';
import FollowUpChips from './FollowUpChips';
import CitationCards from './CitationCards';
import GateBadge from './GateBadge';

const GATE_REGEX = /\[(HARDGATE|ADJACENT_TRACK|OPEN_GAP|ARCHITECTURE_LIMIT|DERIVED)\]/g;

/**
 * Parse body text into parts: text segments (with links) and gate-badge pills.
 * Gate badges like [HARDGATE] are rendered inline as colored pills.
 */
function parseBodyParts(body) {
  const parts = [];
  let lastIndex = 0;
  let match;
  let key = 0;
  GATE_REGEX.lastIndex = 0;
  while ((match = GATE_REGEX.exec(body)) !== null) {
    if (match.index > lastIndex) {
      const textSegment = body.slice(lastIndex, match.index);
      renderWithLinks(textSegment).forEach(p => {
        parts.push({ ...p, key: key++ });
      });
    }
    parts.push({ type: 'badge', gate: match[1], key: key++ });
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < body.length) {
    renderWithLinks(body.slice(lastIndex)).forEach(p => {
      parts.push({ ...p, key: key++ });
    });
  }
  return parts;
}

export default function MerlinMessageContent({ text, onFollowup }) {
  const { body, followups, sources } = parseMerlinResponse(text);
  const parts = parseBodyParts(body);
  const [speaking, setSpeaking] = useState(false);

  const handleSpeak = () => {
    if (speaking) {
      stopSpeaking();
      setSpeaking(false);
    } else {
      // Strip gate badges and links for clean speech text
      const cleanText = body.replace(/\[(HARDGATE|ADJACENT_TRACK|OPEN_GAP|ARCHITECTURE_LIMIT|DERIVED)\]/g, '').trim();
      speak(cleanText, { onEnd: () => setSpeaking(false) });
      setSpeaking(true);
    }
  };

  return (
    <div className="space-y-1">
      <div className="flex items-start gap-1.5">
        <div className="whitespace-pre-wrap break-words leading-relaxed flex-1">
          {parts.map(part => {
            if (part.type === 'link')
              return <Link key={part.key} to={part.path} className="text-[#00f5ff] underline hover:text-[#00f5ff]/80">{part.label}</Link>;
            if (part.type === 'badge')
              return <GateBadge key={part.key} gate={part.gate} size="xs" />;
            return <span key={part.key}>{part.content}</span>;
          })}
        </div>
        <button
          onClick={handleSpeak}
          className={`shrink-0 p-1 rounded transition-colors ${speaking ? 'text-[#FF9F00] bg-[#FF9F00]/10' : 'text-[#484f58] hover:text-[#4dd0e1]'}`}
          title={speaking ? 'Stop speaking' : 'Speak response (PsiCat TTS Lane B)'}
        >
          {speaking ? <Square size={11} /> : <Volume2 size={11} />}
        </button>
      </div>
      {followups.length > 0 && <FollowUpChips followups={followups} onSelect={onFollowup} />}
      {sources.length > 0 && <CitationCards sources={sources} />}
    </div>
  );
}