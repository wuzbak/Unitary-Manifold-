/**
 * CitationCards — renders Merlin's sources as rich clickable cards.
 * Each card shows: type badge (colored), label, gate status (if Pillar),
 * and a link icon (external for web/crawled, internal route for page paths).
 */
import { Link } from 'react-router-dom';
import { ExternalLink, FileCode, Hash, Globe, BookOpen, AlertCircle } from 'lucide-react';

const TYPE_META = {
  PILLAR: { color: '#4dd0e1', bg: 'rgba(77, 208, 225, 0.08)', icon: Hash, label: 'PILLAR' },
  FILE: { color: '#58a6ff', bg: 'rgba(88, 166, 255, 0.08)', icon: FileCode, label: 'FILE' },
  WEB: { color: '#FF9F00', bg: 'rgba(255, 159, 0, 0.08)', icon: Globe, label: 'WEB' },
  CRAWLED: { color: '#bc8cff', bg: 'rgba(188, 140, 255, 0.08)', icon: BookOpen, label: 'CRAWLED' },
  OPEN_GAP: { color: '#f85149', bg: 'rgba(248, 81, 73, 0.08)', icon: AlertCircle, label: 'OPEN GAP' },
  TEXT: { color: '#8b949e', bg: 'rgba(139, 148, 158, 0.08)', icon: BookOpen, label: 'SOURCE' },
};

const GATE_COLORS = {
  HARDGATE: '#3fb950',
  ADJACENT_TRACK: '#58a6ff',
  ARCHITECTURE_LIMIT: '#FF9F00',
  OPEN_GAP: '#f85149',
};

export default function CitationCards({ sources }) {
  if (!sources || sources.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-1.5 mt-2">
      {sources.map((src, i) => (
        <CitationCard key={i} source={src} />
      ))}
    </div>
  );
}

function CitationCard({ source }) {
  const meta = TYPE_META[source.type] || TYPE_META.TEXT;
  const Icon = meta.icon;
  const gateColor = source.gate ? GATE_COLORS[source.gate] : null;

  const isInternalPath = source.path && source.path.startsWith('/');
  const isExternal = source.url && source.url.startsWith('http');

  const content = (
    <div
      className="flex items-center gap-1.5 px-2 py-1.5 text-[9px] transition-colors group"
      style={{
        background: meta.bg,
        borderLeft: `2px solid ${meta.color}`,
        border: `1px solid ${meta.color}30`,
      }}
    >
      <Icon size={10} className="shrink-0" style={{ color: meta.color }} />
      <span
        className="font-bold uppercase tracking-wider px-1 py-0.5 rounded shrink-0"
        style={{ color: meta.color, background: `${meta.color}15` }}
      >
        {meta.label}
      </span>
      {source.gate && (
        <span
          className="font-bold uppercase tracking-wider px-1 py-0.5 rounded shrink-0"
          style={{ color: gateColor, background: `${gateColor}15` }}
        >
          {source.gate}
        </span>
      )}
      <span className="text-[#c9d1d9] truncate max-w-[160px]" title={source.label}>
        {source.id ? `Pillar ${source.id}` : source.label}
      </span>
      {isExternal && <ExternalLink size={9} className="text-[#484f58] group-hover:text-[#00f5ff] shrink-0" />}
    </div>
  );

  if (isExternal) {
    return (
      <a href={source.url} target="_blank" rel="noopener noreferrer" className="block">
        {content}
      </a>
    );
  }
  if (isInternalPath) {
    return <Link to={source.path} className="block">{content}</Link>;
  }
  return content;
}