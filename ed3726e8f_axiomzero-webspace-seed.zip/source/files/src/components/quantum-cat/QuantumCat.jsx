import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { queryMerlin, detectKernel } from '@/lib/merlinEngine';
import { getPageContext } from '@/lib/merlinPageContext';
import { getPageAccent } from '@/lib/merlinAccentRegistry';
import { getPageState, clearPageState } from '@/lib/merlinLiveState';
import { UM_STATUS } from '@/lib/umStatus';
import { useAuth } from '@/lib/AuthContext';
import { generateThoughtStream } from '@/lib/merlinThoughts';
import { assistantFallback } from '@/lib/assistantFallback';
import { getSpecialistLabel } from '@/lib/merlinMasterMemory';
import { Send, X, Globe, Trash2, BookOpen, MessageSquare, Brain, CircleSlash, Bug } from 'lucide-react';
import ModelSelector from './ModelSelector';
import ThoughtStream from './ThoughtStream';
import MerlinMessageContent from './MerlinMessageContent';
import KernelBadge from './KernelBadge';
import UnknownsLedger from '@/components/merlin-sovereign/UnknownsLedger';
import ReportIssueTab from './ReportIssueTab';
import { getEphemeralSessionToken, distillSession, distillSessionBeacon, getDomainFromPath, SOVEREIGN_MEMORY_LABEL } from '@/lib/merlinSovereign';

const CAT_AVATAR = 'https://media.base44.com/images/public/6a51c0830aeacd39ab86c4f0/ddeaeeb0c_generated_image.png';
const MODEL_KEY = 'merlin-model';
const FOURTH_WALL_KEY = 'merlin-fourth-wall';

const TABS = [
  { id: 'chat', label: 'Chat', icon: MessageSquare },
  { id: 'thoughts', label: 'Thoughts', icon: Brain },
  { id: 'unknowns', label: 'Unknowns', icon: CircleSlash },
  { id: 'report', label: 'Report', icon: Bug },
];

export default function QuantumCat() {
  const location = useLocation();
  const { user } = useAuth();
  const pageContext = getPageContext(location.pathname);
  const accentInfo = getPageAccent(location.pathname);
  const accent = accentInfo.accent;
  const isEmbedded = accentInfo.embedded;
  const expertLabel = getSpecialistLabel(location.pathname) || accentInfo.expertLabel || 'PsiCat Expert';
  const userContext = user ? { id: user.id, email: user.email, role: user.role } : null;
  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('chat');
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [webStatus, setWebStatus] = useState(null);
  const [thoughtStream, setThoughtStream] = useState(null);
  const [model, setModel] = useState(() => localStorage.getItem(MODEL_KEY) || 'openai/gpt-4o');
  const [fourthWall, setFourthWall] = useState(() => localStorage.getItem(FOURTH_WALL_KEY) === 'true');
  const [pendingPrompt, setPendingPrompt] = useState(null);
  const [kernelInfo, setKernelInfo] = useState(null);
  const sentPromptRef = useRef('');
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const messagesRef = useRef([]);
  const sessionTokenRef = useRef(null);

  useEffect(() => { localStorage.setItem(MODEL_KEY, model); }, [model]);
  useEffect(() => { localStorage.setItem(FOURTH_WALL_KEY, String(fourthWall)); }, [fourthWall]);
  useEffect(() => { clearPageState(); }, [location.pathname]);
  useEffect(() => { messagesRef.current = messages; }, [messages]);

  // Sovereign ephemeral: generate session token, distill on unmount
  useEffect(() => {
    (async () => { sessionTokenRef.current = await getEphemeralSessionToken(); })();
    return () => {
      const msgs = messagesRef.current;
      if (msgs.length >= 2) {
        distillSessionBeacon(msgs, getDomainFromPath(location.pathname), sessionTokenRef.current);
      }
    };
  }, []);

  useEffect(() => {
    const beforeUnload = () => {
      const msgs = messagesRef.current;
      if (msgs.length >= 2) {
        distillSessionBeacon(msgs, getDomainFromPath(location.pathname), sessionTokenRef.current);
      }
    };
    window.addEventListener('beforeunload', beforeUnload);
    return () => window.removeEventListener('beforeunload', beforeUnload);
  }, []);

  useEffect(() => {
    if (scrollRef.current && activeTab === 'chat') scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, open, activeTab]);

  const handleSend = async (overrideText) => {
    const text = (typeof overrideText === 'string' ? overrideText : input).trim();
    if (!text || loading) return;
    setActiveTab('chat');
    const userMsg = { role: 'user', text, time: Date.now() };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setLoading(true);
    setWebStatus(null);
    setKernelInfo(detectKernel(text));
    setThoughtStream(generateThoughtStream(text));

    try {
      const liveState = getPageState();
      const responseText = await queryMerlin(text, newMessages, setWebStatus, model, fourthWall, { pageContext, userContext, liveStatus: UM_STATUS, liveState });
      setWebStatus(null);
      setMessages([...newMessages, { role: 'cat', text: responseText, time: Date.now() }]);
    } catch (e) {
      setWebStatus(null);
      try {
        const fallback = await assistantFallback(text);
        const prefix = fallback.offline ? '⚠️ ' : '';
        setMessages([...newMessages, { role: 'cat', text: `${prefix}${fallback.text}`, time: Date.now(), offline: fallback.offline }]);
      } catch (fallbackErr) {
        const errMsg = fallbackErr?.message || 'unknown error';
        setMessages([...newMessages, { role: 'cat', text: `*flicks tail* The channel wavered — ${errMsg}. Try again in a moment...`, time: Date.now() }]);
      }
    }
    setLoading(false);
  };

  const clearConversation = () => {
    const msgs = messagesRef.current;
    if (msgs.length >= 2) {
      distillSession(msgs, getDomainFromPath(location.pathname), sessionTokenRef.current);
    }
    setMessages([]);
  };

  const toggleOpen = () => {
    setOpen((prev) => {
      const next = !prev;
      if (next) setTimeout(() => inputRef.current?.focus(), 50);
      return next;
    });
  };

  useEffect(() => {
    const handler = () => toggleOpen();
    window.addEventListener('merlin-toggle', handler);
    return () => window.removeEventListener('merlin-toggle', handler);
  }, []);

  useEffect(() => {
    const handler = (e) => {
      const prompt = e.detail?.prompt;
      if (prompt) { setPendingPrompt(prompt); setOpen(true); }
      else { toggleOpen(); }
    };
    window.addEventListener('merlin-analyze', handler);
    return () => window.removeEventListener('merlin-analyze', handler);
  }, []);

  useEffect(() => {
    if (open && pendingPrompt && pendingPrompt !== sentPromptRef.current) {
      sentPromptRef.current = pendingPrompt;
      const p = pendingPrompt;
      setPendingPrompt(null);
      setTimeout(() => handleSend(p), 60);
    }
    if (!open) sentPromptRef.current = '';
  }, [open, pendingPrompt]);

  return (
    <>
      {/* ── Floating Merlin button — the companion entry point ── */}
      {/* A simple circular FAB. Hidden on embedded-panel pages, which have
          their own specialist Merlin surface. */}
      {!open && !isEmbedded && (
        <button
          onClick={toggleOpen}
          className="hidden lg:flex fixed bottom-4 right-4 z-[100] w-14 h-14 rounded-full overflow-hidden glass-strong merlin-pulse pointer-events-auto transition-all duration-200 hover:scale-105 items-center justify-center"
          style={{ border: `1px solid ${accent}4d`, boxShadow: `0 0 20px ${accent}1a` }}
          title={`PsiCat — ${expertLabel}`}
          aria-label="Open PsiCat"
        >
          <img src={CAT_AVATAR} alt="PsiCat" className="w-full h-full object-cover" />
        </button>
      )}

      {/* ── Expanded unified frame — Chat · Thoughts · Unknowns ── */}
      {open && (
        <div className="fixed z-[200] inset-0 sm:inset-auto sm:bottom-4 sm:right-4 sm:w-[calc(100vw-2rem)] sm:max-w-[400px] sm:h-[78vh] sm:max-h-[640px] bg-[#0a0a12] sm:rounded-lg flex flex-col shadow-2xl overflow-hidden" style={{ border: `1px solid ${accent}4d`, boxShadow: `0 0 30px ${accent}1a` }}>
          {/* Header */}
          <div className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-2 border-b border-[#30363d] bg-[#161b22] shrink-0">
            <img src={CAT_AVATAR} alt="" className="w-7 h-7 sm:w-8 sm:h-8 rounded-full shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="text-xs sm:text-sm font-bold flex items-center gap-1.5 min-w-0" style={{ color: accent }}>
                <span className="truncate">PsiCat — {expertLabel}</span>
                <KernelBadge kernelInfo={kernelInfo} isAdmin={user?.role === 'admin'} />
              </div>
              <div className="text-[#8b949e] text-[10px] truncate hidden sm:block">Quantum Cat · <span className="text-[#4DD0E1]">{SOVEREIGN_MEMORY_LABEL}</span></div>
            </div>
            <button
              onClick={() => setFourthWall(v => !v)}
              className={`p-1.5 rounded transition-colors shrink-0 ${fourthWall ? 'text-[#FF9F00] bg-[#FF9F00]/10 border border-[#FF9F00]/40' : 'text-[#484f58] hover:text-[#8b949e] border border-[#30363d]'}`}
              title="Fourth-wall: plain-language explanations"
              aria-label="Toggle fourth-wall mode"
            >
              <BookOpen size={14} />
            </button>
            <ModelSelector value={model} onChange={setModel} />
            {activeTab === 'chat' && messages.length > 0 && (
              <button onClick={clearConversation} className="text-[#8b949e] hover:text-[#ff6b6b] transition-colors shrink-0" title="Clear conversation"><Trash2 size={14} /></button>
            )}
            <button onClick={toggleOpen} className="text-[#8b949e] hover:text-[#e6edf3] shrink-0"><X size={18} /></button>
          </div>

          {/* Tab bar */}
          <div className="flex items-center gap-1 px-2 py-1.5 border-b border-[#30363d] bg-[#0d1117] shrink-0">
            {TABS.map(t => {
              const Icon = t.icon;
              const isActive = activeTab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setActiveTab(t.id)}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-[10px] font-bold transition-all ${isActive ? 'text-black' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
                  style={isActive ? { background: accent } : {}}
                >
                  <Icon size={11} /> {t.label}
                </button>
              );
            })}
          </div>

          {/* Tab content */}
          {activeTab === 'chat' && (
            <>
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-3">
                {messages.length === 0 && (
                  <div className="text-center py-6">
                    <img src={CAT_AVATAR} alt="" className="w-16 h-16 rounded-full mx-auto mb-3 opacity-80" />
                    <p className="text-sm font-bold mb-1" style={{ color: accent }}>PsiCat — {expertLabel}</p>
                    <p className="text-[#8b949e] text-xs mb-3">*manifests* I am PsiCat, the Quantum Cat. (You can call me Merlin if we're friends.) There is no time in 5D — I simply am, present and precise. I treat claims as obligations and uncertainty as data. Ask me anything, or paste a URL for me to crawl.</p>
                    {pageContext && (
                      <div className="border rounded-lg p-2.5 mb-3 text-left" style={{ background: `${accent}0d`, borderColor: `${accent}33` }}>
                        <div className="text-[10px] font-bold uppercase tracking-wider mb-1" style={{ color: accent }}>▸ {pageContext.title}</div>
                        <p className="text-[#8b949e] text-[10px] leading-relaxed mb-2">{pageContext.description}</p>
                        <div className="text-[#484f58] text-[9px] mb-1">I can help with this page:</div>
                        {pageContext.suggestedQuestions.slice(0, 3).map((q, i) => (
                          <button key={i} onClick={() => handleSend(q)} className="block w-full text-left px-2 py-1.5 rounded text-[10px] text-[#8b949e] hover:text-[#00f5ff] hover:bg-[#00f5ff]/5 transition-colors mb-0.5">
                            → {q}
                          </button>
                        ))}
                      </div>
                    )}
                    <p className="text-[#8b949e] text-xs mb-4">I can search the web AND crawl any page you share. Ask me anything — or paste a URL for me to read.</p>
                  </div>
                )}
                {messages.map((msg, i) => (
                  <div key={i} className={`flex gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                    {msg.role === 'cat' && <img src={CAT_AVATAR} alt="" className="w-6 h-6 rounded-full shrink-0 mt-0.5" />}
                    <div className={`max-w-[80%] px-3 py-2 rounded-lg text-xs ${msg.role === 'user' ? 'bg-[#0d2040] text-[#e6edf3]' : msg.offline ? 'bg-[#2a1a0a] border border-[#FF9F00]/40 text-[#e6edf3]' : 'bg-[#161b22] border border-[#30363d] text-[#e6edf3]'}`}>
                      {msg.role === 'cat'
                        ? <MerlinMessageContent text={msg.text} onFollowup={handleSend} />
                        : msg.text}
                    </div>
                  </div>
                ))}
                {loading && (
                  <div className="flex gap-2">
                    <img src={CAT_AVATAR} alt="" className="w-6 h-6 rounded-full shrink-0" />
                    <ThoughtStream stream={thoughtStream} phase={webStatus?.phase} />
                  </div>
                )}
              </div>

              <div className="p-3 border-t border-[#30363d] bg-[#161b22] shrink-0">
                <div className="flex gap-2">
                  <input ref={inputRef} type="text" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSend()} placeholder="Ask PsiCat... or paste a URL to crawl" className="flex-1 bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-3 py-2 rounded text-xs focus:outline-none focus:border-[#00f5ff] placeholder:text-[#484f58]" />
                  <button onClick={() => handleSend()} disabled={loading || !input.trim()} className="text-black px-3 py-2 rounded text-xs font-bold hover:opacity-80 disabled:opacity-50 flex items-center gap-1" style={{ background: accent }}><Send size={14} /></button>
                </div>
                <div className="flex items-center justify-between gap-1 mt-1.5 text-[8px] text-[#484f58]">
                  <div className="flex items-center gap-1">
                    <Globe size={8} className="text-[#00f5ff]/50" />
                    <span>RAG + web + crawl · Enter to send</span>
                  </div>
                  {fourthWall && <span className="text-[#FF9F00] font-bold uppercase tracking-wider">Fourth-wall ON</span>}
                </div>
              </div>
            </>
          )}

          {activeTab === 'thoughts' && (
            <div className="flex-1 overflow-y-auto p-3 space-y-3">
              <div className="flex items-center gap-2 mb-1">
                <Brain size={13} className="text-[#FF9F00]" />
                <span className="text-[11px] font-bold text-[#FF9F00]">PsiCat's Thoughts</span>
              </div>
              <p className="text-[10px] text-[#8b949e] leading-relaxed mb-3">
                My thoughts are expansive and context-driven — drawn from the cat, the repository, and the tone of my books. When I research, search, or work, this is the stream of consciousness beneath the answer. I think out loud because the thinking is part of the receipt.
              </p>
              {loading && thoughtStream ? (
                <ThoughtStream stream={thoughtStream} phase={webStatus?.phase} />
              ) : (
                <div className="glass-panel clip-corner p-4 text-center">
                  <Brain size={20} className="text-[#484f58] mx-auto mb-2" />
                  <p className="text-[10px] text-[#8b949e]">Ask me something and my thoughts will flow here in real time — the liminal space where a question is not yet an answer, made visible.</p>
                </div>
              )}
              <p className="text-[8px] text-[#484f58] italic leading-relaxed pt-2">
                Liminal space is where a question is not yet an answer. Latent space is where representation happens. J-space is where uncertainty, structure, and governance meet accountable action. These are my working spaces.
              </p>
            </div>
          )}

          {activeTab === 'unknowns' && (
            <div className="flex-1 overflow-y-auto p-3">
              <UnknownsLedger />
            </div>
          )}

          {activeTab === 'report' && (
            <div className="flex-1 overflow-y-auto p-3">
              <ReportIssueTab />
            </div>
          )}
        </div>
      )}
    </>
  );
}