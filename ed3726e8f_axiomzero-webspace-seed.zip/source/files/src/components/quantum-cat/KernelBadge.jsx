/**
 * KernelBadge — admin-only Pentad kernel routing telemetry.
 * Shows which kernel (P/R/A/G/S) is handling the current query.
 * Regular users do not see this — it isolates sensitive operational data.
 */
export default function KernelBadge({ kernelInfo, isAdmin }) {
  if (!isAdmin || !kernelInfo) return null;

  const { kernel, label, color } = kernelInfo;

  return (
    <span
      className="inline-flex items-center gap-1 text-[8px] px-1.5 py-0.5 clip-corner font-bold uppercase tracking-wider shrink-0"
      style={{
        background: `${color}1a`,
        color,
        border: `1px solid ${color}40`,
      }}
      title={`Pentad kernel routing: ${kernel} (${label}) — admin-only telemetry`}
    >
      <span
        className="w-1.5 h-1.5 rounded-full glow-pulse"
        style={{ background: color, color }}
      />
      {kernel.replace('KERNEL_', 'K')}
    </span>
  );
}