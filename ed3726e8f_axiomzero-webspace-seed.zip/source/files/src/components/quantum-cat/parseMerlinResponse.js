/**
 * Parse a Merlin response into structured parts: body, followups, sources.
 * The system prompt instructs Merlin to end every response with:
 *
 *   [body]
 *   ---
 *   FOLLOWUPS:
 *   1. question
 *   2. question
 *   3. question
 *   Sources:
 *   - Pillar 786 | HARDGATE | description
 *   - src/core/file.py | FILE | description
 *   - https://example.com | WEB | title
 *
 * This parser is robust — if the format isn't found, it returns the full text
 * as body with empty arrays.
 */

/**
 * @param {string} text - raw Merlin response
 * @returns {{ body: string, followups: string[], sources: SourceCard[] }}
 */
export function parseMerlinResponse(text) {
  if (!text) return { body: '', followups: [], sources: [] };

  // Find the separator: a line containing only "---"
  const lines = text.split('\n');
  let sepIdx = -1;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (lines[i].trim() === '---') { sepIdx = i; break; }
  }

  if (sepIdx === -1) {
    return { body: text.trim(), followups: [], sources: [] };
  }

  const body = lines.slice(0, sepIdx).join('\n').trim();
  const metadata = lines.slice(sepIdx + 1).join('\n').trim();

  // Parse FOLLOWUPS section
  const followups = [];
  const followupsMatch = metadata.match(/FOLLOWUPS:\s*\n([\s\S]*?)(?=\n\s*Sources:|$)/i);
  if (followupsMatch) {
    const fLines = followupsMatch[1].split('\n');
    for (const line of fLines) {
      const match = line.match(/^\s*\d+\.\s*(.+)/);
      if (match && match[1].trim()) followups.push(match[1].trim());
    }
  }

  // Parse Sources section
  const sources = [];
  const sourcesMatch = metadata.match(/Sources:\s*\n([\s\S]*?)$/i);
  if (sourcesMatch) {
    const sLines = sourcesMatch[1].split('\n');
    for (const line of sLines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith('-')) continue;
      const source = parseSourceLine(trimmed.slice(1).trim());
      if (source) sources.push(source);
    }
  }

  return { body, followups, sources };
}

/**
 * Parse a single source line into a citation card object.
 * Handles pipe-delimited format and free-form fallback.
 * @returns {SourceCard|null}
 */
function parseSourceLine(line) {
  if (!line) return null;

  // Pipe-delimited: "identifier | TYPE | description"
  const parts = line.split('|').map(p => p.trim());
  if (parts.length >= 2) {
    const first = parts[0];
    const typeField = parts[1].toUpperCase();

    // Pillar: "Pillar 786 | HARDGATE | description"
    if (first.toLowerCase().startsWith('pillar')) {
      const numMatch = first.match(/\d+/);
      return {
        type: 'PILLAR',
        id: numMatch ? numMatch[0] : '',
        gate: typeField || '',
        label: parts[2] || first,
      };
    }

    // Crawled: "[CRAWLED] url | CRAWLED | title"
    if (first.startsWith('[CRAWLED]') || typeField === 'CRAWLED') {
      const url = first.replace('[CRAWLED]', '').trim();
      return { type: 'CRAWLED', url, label: parts[2] || parts[1] || url };
    }

    // File: "src/path | FILE | description"
    if (typeField === 'FILE' || first.startsWith('src/') || first.startsWith('docs/') || first.startsWith('lean4/') || first.startsWith('COMPACTIFICATION/')) {
      return { type: 'FILE', path: first, label: parts[2] || parts[1] || first };
    }

    // Web: "url | WEB | title"
    if (typeField === 'WEB' || first.startsWith('http')) {
      return { type: 'WEB', url: first, label: parts[2] || parts[1] || first };
    }

    // Gate-status types (HARDGATE, ADJACENT_TRACK, etc.) without "Pillar" prefix
    if (['HARDGATE', 'ADJACENT_TRACK', 'ARCHITECTURE_LIMIT', 'OPEN_GAP'].includes(typeField)) {
      const numMatch = first.match(/\d+/);
      return {
        type: 'PILLAR',
        id: numMatch ? numMatch[0] : '',
        gate: typeField,
        label: parts[2] || first,
      };
    }
  }

  // Free-form fallback
  if (line.toLowerCase().startsWith('pillar')) {
    const numMatch = line.match(/\d+/);
    return { type: 'PILLAR', id: numMatch ? numMatch[0] : '', gate: '', label: line };
  }
  if (line.startsWith('src/') || line.startsWith('docs/') || line.startsWith('lean4/')) {
    return { type: 'FILE', path: line, label: line };
  }
  if (line.startsWith('http')) {
    return { type: 'WEB', url: line, label: line };
  }
  if (line.toLowerCase().startsWith('no source')) {
    return { type: 'OPEN_GAP', label: line };
  }

  return { type: 'TEXT', label: line };
}