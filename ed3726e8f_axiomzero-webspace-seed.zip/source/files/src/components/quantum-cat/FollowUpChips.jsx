/**
 * FollowUpChips — renders Merlin's suggested follow-up questions as clickable
 * pills. Clicking a chip auto-sends it as a new message.
 */
import { MessageSquarePlus } from 'lucide-react';

export default function FollowUpChips({ followups, onSelect }) {
  if (!followups || followups.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-1.5 mt-2">
      {followups.map((q, i) => (
        <button
          key={i}
          onClick={() => onSelect?.(q)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-[10px] text-[#4dd0e1] border border-[#4dd0e1]/30 bg-[#4dd0e1]/5 hover:bg-[#4dd0e1]/10 hover:border-[#4dd0e1]/50 transition-colors text-left max-w-full group"
          title={q}
        >
          <MessageSquarePlus size={10} className="shrink-0 text-[#4dd0e1]/60 group-hover:text-[#4dd0e1]" />
          <span className="truncate">{q}</span>
        </button>
      ))}
    </div>
  );
}