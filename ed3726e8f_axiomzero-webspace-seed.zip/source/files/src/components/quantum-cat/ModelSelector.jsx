import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Cpu } from 'lucide-react';
import { MODELS } from '@/lib/openrouter/models';

/**
 * ModelSelector — compact dropdown for choosing OpenRouter models.
 * Persists selection via parent component (localStorage).
 */
export default function ModelSelector({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const current = MODELS.find(m => m.id === value) || MODELS[0];

  // Group by provider for the dropdown
  const grouped = {};
  MODELS.forEach(m => { (grouped[m.provider] = grouped[m.provider] || []).push(m); });

  return (
    <div ref={ref} className="relative shrink-0">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1 px-1.5 py-1 rounded text-[9px] bg-[#0d1117] border border-[#30363d] text-[#8b949e] hover:border-[#00f5ff]/40 transition-colors"
        title="Select AI model"
      >
        <Cpu size={9} className="text-[#00f5ff]/60 shrink-0" />
        <span className="truncate max-w-[70px]">{current.label}</span>
        <ChevronDown size={8} className={`transition-transform shrink-0 ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="absolute bottom-full mb-1 right-0 w-60 max-h-72 overflow-y-auto bg-[#0a0a12] border border-[#00f5ff]/20 rounded-lg shadow-2xl z-50">
          {Object.entries(grouped).map(([provider, models]) => (
            <div key={provider}>
              <div className="px-3 py-1 bg-[#00f5ff]/5 border-b border-[#00f5ff]/10 sticky top-0">
                <span className="text-[8px] font-bold text-[#00f5ff] uppercase tracking-wider">{provider}</span>
              </div>
              {models.map(m => (
                <button
                  key={m.id}
                  onClick={() => { onChange(m.id); setOpen(false); }}
                  className={`w-full text-left px-3 py-1.5 hover:bg-[#00f5ff]/5 transition-colors ${m.id === value ? 'bg-[#00f5ff]/10' : ''}`}
                >
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[10px] font-bold truncate ${m.id === value ? 'text-[#00f5ff]' : 'text-[#e6edf3]'}`}>{m.label}</span>
                    <span className="text-[7px] text-[#484f58] ml-auto shrink-0">{(m.contextWindow / 1000).toFixed(0)}K ctx</span>
                  </div>
                  <div className="text-[8px] text-[#484f58] truncate">{m.strengths.join(' · ')}</div>
                </button>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}