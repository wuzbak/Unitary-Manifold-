/**
 * ReportIssueTab — the report-issue form rendered inside the QuantumCat
 * panel's "Report" tab. Creates a FallibilityEntry with discovered_by='user_report'
 * and auto-fills the current page path.
 */
import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Bug, Send, Loader2, CheckCircle } from 'lucide-react';

const CATEGORIES = [
  { value: 'ui', label: 'UI Glitch' },
  { value: 'ux', label: 'UX Issue' },
  { value: 'function', label: 'Broken Function' },
  { value: 'broken_link', label: 'Broken Link' },
  { value: 'error', label: 'Runtime Error' },
  { value: 'gap', label: 'Missing Feature' },
  { value: 'performance', label: 'Performance' },
  { value: 'content', label: 'Wrong Content' },
  { value: 'other', label: 'Other' },
];
const SEVERITIES = [
  { value: 'critical', label: 'Critical — breaks core flow' },
  { value: 'warning', label: 'Warning — degrades experience' },
  { value: 'info', label: 'Info — minor issue' },
];

export default function ReportIssueTab() {
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ title: '', description: '', category: 'other', severity: 'warning' });
  const location = useLocation();

  useEffect(() => {
    if (submitted) {
      const t = setTimeout(() => setSubmitted(false), 2500);
      return () => clearTimeout(t);
    }
  }, [submitted]);

  const handleSubmit = async () => {
    if (!form.title.trim()) return;
    setSubmitting(true);
    try {
      await base44.entities.FallibilityEntry.create({
        title: form.title,
        description: form.description,
        category: form.category,
        severity: form.severity,
        page_path: location.pathname,
        status: 'open',
        discovered_by: 'user_report',
      });
      setForm({ title: '', description: '', category: 'other', severity: 'warning' });
      setSubmitted(true);
    } catch (e) {
      alert('Failed to submit: ' + e.message);
    }
    setSubmitting(false);
  };

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <CheckCircle size={28} className="text-[#3fb950] mb-2" />
        <div className="text-[#3fb950] text-xs font-bold mb-1">✓ Issue Reported</div>
        <p className="text-[10px] text-[#8b949e]">PsiCat will review and suggest a fix.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Bug size={13} className="text-[#FF9F00]" />
        <span className="text-[11px] font-bold text-[#e6edf3]">Report an Issue</span>
        <span className="text-[9px] text-[#484f58] ml-auto font-mono truncate">{location.pathname}</span>
      </div>
      <p className="text-[10px] text-[#8b949e] leading-relaxed">
        Spotted something broken, misaligned, or missing? Let PsiCat know — he'll review it, suggest a fix, and route it to the Fallibility Ledger.
      </p>
      <input
        value={form.title}
        onChange={(e) => setForm({ ...form, title: e.target.value })}
        placeholder="What's not working?"
        className="w-full bg-[#0B0F13] border border-[#30363d] px-2.5 py-2 text-[11px] text-[#e6edf3] clip-corner focus:border-[#FF9F00]/40 focus:outline-none"
      />
      <textarea
        value={form.description}
        onChange={(e) => setForm({ ...form, description: e.target.value })}
        placeholder="What happened? What did you expect?"
        className="w-full bg-[#0B0F13] border border-[#30363d] px-2.5 py-2 text-[11px] text-[#e6edf3] clip-corner focus:border-[#FF9F00]/40 focus:outline-none resize-y"
        rows={3}
      />
      <div className="flex items-center gap-1.5">
        <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] text-[9px] text-[#e6edf3] px-1.5 py-1.5 clip-corner flex-1 min-w-0">
          {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
        </select>
        <select value={form.severity} onChange={(e) => setForm({ ...form, severity: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] text-[9px] text-[#e6edf3] px-1.5 py-1.5 clip-corner flex-1 min-w-0">
          {SEVERITIES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
      </div>
      <button onClick={handleSubmit} disabled={!form.title.trim() || submitting} className="flex items-center gap-1.5 px-3 py-2 text-[10px] font-bold bg-[#FF9F00] text-black clip-corner disabled:opacity-40 w-full justify-center">
        {submitting ? <Loader2 size={11} className="animate-spin" /> : <Send size={11} />} Submit Report
      </button>
    </div>
  );
}