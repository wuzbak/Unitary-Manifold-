import { BookOpen, Trash2 } from 'lucide-react';
import ModelSelector from './ModelSelector';

/**
 * MerlinPanelToolbar — compact toolbar for embedded Merlin panels.
 * Provides model selector, fourth-wall toggle, and optional clear button.
 * Dropped into any panel header to give it feature parity with the global
 * floating QuantumCat button.
 */
export default function MerlinPanelToolbar({ model, setModel, fourthWall, setFourthWall, onClear, showClear = false }) {
  return (
    <div className="flex items-center gap-1 shrink-0">
      <button
        onClick={() => setFourthWall(v => !v)}
        className={`p-1 rounded transition-colors ${fourthWall ? 'text-[#FF9F00] bg-[#FF9F00]/10 border border-[#FF9F00]/40' : 'text-[#484f58] hover:text-[#8b949e] border border-[#30363d]'}`}
        title="Fourth-wall: plain-language explanations"
        aria-label="Toggle fourth-wall mode"
      >
        <BookOpen size={12} />
      </button>
      <ModelSelector value={model} onChange={setModel} />
      {showClear && (
        <button onClick={onClear} className="text-[#8b949e] hover:text-[#ff6b6b] transition-colors p-1" title="Clear conversation">
          <Trash2 size={12} />
        </button>
      )}
    </div>
  );
}