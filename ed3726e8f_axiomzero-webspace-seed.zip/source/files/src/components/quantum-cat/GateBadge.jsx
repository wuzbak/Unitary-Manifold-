/**
 * GateBadge — reusable epistemic gate-badge pill.
 * Renders a single gate label with the PRD-specified styling:
 *   HARDGATE       = solid cyan
 *   ADJACENT_TRACK  = teal outline
 *   DERIVED         = soft green outline
 *   OPEN_GAP        = amber outline
 *   ARCHITECTURE_LIMIT = muted gray with warning icon
 *
 * Used across all Merlin surfaces for consistent epistemic honesty.
 */
import { AlertTriangle } from 'lucide-react';
import { GATE_BADGES } from '@/lib/merlinPersona';

export default function GateBadge({ gate, size = 'sm' }) {
  const config = GATE_BADGES[gate];
  if (!config) return null;

  const sizeClasses = size === 'xs'
    ? 'text-[8px] px-1.5 py-0.5'
    : 'text-[9px] px-2 py-0.5';

  if (config.solid) {
    return (
      <span
        className={`inline-flex items-center gap-1 font-bold uppercase tracking-wider clip-corner ${sizeClasses}`}
        style={{ color: '#0B0F13', background: config.color }}
      >
        {config.warning && <AlertTriangle size={9} />}
        {config.label}
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center gap-1 font-bold uppercase tracking-wider clip-corner ${sizeClasses}`}
      style={{
        color: config.color,
        background: `${config.color}10`,
        border: `1px solid ${config.color}40`,
      }}
    >
      {config.warning && <AlertTriangle size={9} />}
      {config.label}
    </span>
  );
}

// ── Badge row: render multiple unique gates ───────────────────────
export function GateBadgeRow({ gates, size = 'sm' }) {
  const unique = [...new Set(gates || [])];
  if (unique.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-1.5">
      {unique.map(g => <GateBadge key={g} gate={g} size={size} />)}
    </div>
  );
}