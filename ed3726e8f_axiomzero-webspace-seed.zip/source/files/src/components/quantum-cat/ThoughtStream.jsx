/**
 * ThoughtStream — flowing stream-of-consciousness panel that shows Merlin's
 * actual pipeline steps (crawl → search → RAG → synthesize) with thoughts
 * that linger and accumulate rather than cycling away.
 *
 * Each phase appears as a labeled header. Thoughts append below and persist,
 * producing a visible "thinking" trail. The stream breathes at ~5.5 seconds
 * per thought. Auto-scrolls so the latest thought is always visible while the
 * history of his thinking stays on screen.
 */
import { useState, useEffect, useRef } from 'react';
import { Globe, Search, Database, Sparkles, Loader2 } from 'lucide-react';

const PHASE_META = {
  crawling: { label: 'CRAWL', icon: Globe, color: '#bc8cff' },
  searching: { label: 'SEARCH', icon: Search, color: '#00f5ff' },
  rag: { label: 'RETRIEVE', icon: Database, color: '#4dd0e1' },
  synthesizing: { label: 'SYNTHESIZE', icon: Sparkles, color: '#FF9F00' },
};

const BREATH_MS = 5500;

export default function ThoughtStream({ stream, phase }) {
  const [displayed, setDisplayed] = useState([]); // [{ type: 'header'|'thought', phase, text?, id }]
  const scrollRef = useRef(null);
  const seenPhases = useRef(new Set());
  const poolIdx = useRef({});
  const phaseRef = useRef(phase);
  const streamRef = useRef(stream);

  useEffect(() => { phaseRef.current = phase; }, [phase]);
  useEffect(() => { streamRef.current = stream; }, [stream]);

  // Reset when stream changes (new query)
  useEffect(() => {
    setDisplayed([]);
    seenPhases.current = new Set();
    poolIdx.current = {};
  }, [stream]);

  // Add phase header when phase changes
  useEffect(() => {
    if (!phase || seenPhases.current.has(phase)) return;
    seenPhases.current.add(phase);
    setDisplayed((d) => [...d, { type: 'header', phase, id: `header-${phase}-${Date.now()}` }]);
  }, [phase]);

  // Thought ticker — every BREATH_MS, pull next thought from current phase pool
  useEffect(() => {
    const interval = setInterval(() => {
      const currentPhase = phaseRef.current;
      const currentStream = streamRef.current;
      if (!currentPhase || !currentStream) return;

      const phasePool = currentStream[currentPhase] || [];
      const generalPool = currentStream.general || [];
      const pool = [...phasePool, ...generalPool];

      const idx = poolIdx.current[currentPhase] || 0;
      if (idx >= pool.length) return;

      setDisplayed((d) => [...d, {
        type: 'thought',
        phase: currentPhase,
        text: pool[idx],
        id: `thought-${currentPhase}-${idx}-${Date.now()}`,
      }]);
      poolIdx.current[currentPhase] = idx + 1;
    }, BREATH_MS);

    return () => clearInterval(interval);
  }, []);

  // Auto-scroll to latest
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [displayed]);

  // Group displayed items by phase for rendering with headers
  const grouped = [];
  let currentGroup = null;
  for (const item of displayed) {
    if (item.type === 'header') {
      currentGroup = { phase: item.phase, thoughts: [] };
      grouped.push(currentGroup);
    } else {
      if (!currentGroup || currentGroup.phase !== item.phase) {
        currentGroup = { phase: item.phase, thoughts: [] };
        grouped.push(currentGroup);
      }
      currentGroup.thoughts.push(item.text);
    }
  }

  return (
    <div className="bg-[#161b22] border border-[#30363d] px-3 py-2 rounded-lg space-y-2 max-w-[85%]">
      {/* Active phase indicator */}
      <div className="flex items-center gap-2">
        <Loader2 size={14} className="text-[#00f5ff] animate-spin shrink-0" />
        {phase && PHASE_META[phase] && (
          <span className="text-[10px] font-bold tracking-wider" style={{ color: PHASE_META[phase].color }}>
            {PHASE_META[phase].label}…
          </span>
        )}
        {!phase && <span className="text-[10px] text-[#00f5ff]">Consulting the manifold…</span>}
      </div>

      {/* Flowing thought trail */}
      {grouped.length > 0 && (
        <div ref={scrollRef} className="space-y-1.5 max-h-32 overflow-y-auto pr-1">
          {grouped.map((group, gi) => {
            const meta = PHASE_META[group.phase] || PHASE_META.rag;
            const Icon = meta.icon;
            return (
              <div key={gi} className="space-y-1">
                {/* Phase header */}
                <div className="flex items-center gap-1.5 pt-1" style={{ color: meta.color }}>
                  <Icon size={9} />
                  <span className="text-[8px] font-bold uppercase tracking-wider">{meta.label}</span>
                  <div className="flex-1 h-px" style={{ background: `${meta.color}30` }} />
                </div>
                {/* Thoughts under this phase */}
                {group.thoughts.map((thought, ti) => (
                  <div key={ti} className="text-[10px] italic leading-relaxed fade-in pl-3" style={{ color: '#FF9F00', fontFamily: 'var(--font-mono)' }}>
                    <span className="not-italic" style={{ color: '#FF9F0050' }}>▸ </span>
                    {thought}
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}