import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Sprout, Download, CheckCircle2, Loader2, AlertTriangle, FileArchive, Database, Shield, Globe, FileText, Package } from 'lucide-react';

const MANIFEST_ITEMS = [
  { icon: Package, label: 'Full source code (1,012 files)', detail: 'All React pages, components, backend functions, config — as individual files + machine-readable JSON bundle' },
  { icon: Database, label: 'All entity schemas (71 entities)', detail: 'Full JSON schema definitions — every field, type, default, and RLS rule' },
  { icon: FileArchive, label: 'All entity data records (3,450+)', detail: 'Exported database records as JSON arrays, one file per entity' },
  { icon: Package, label: 'Backend function registry (98 functions)', detail: 'Complete list of all serverless function names' },
  { icon: Shield, label: 'Secrets manifest (15 secrets)', detail: 'All secret names with descriptions (values must be re-provisioned)' },
  { icon: Globe, label: 'DNS & domain guide', detail: 'Nameserver, CNAME/A record, and SSL configuration instructions' },
  { icon: FileText, label: 'Migration docs + scripts', detail: 'MIGRATION.md, DEPLOYMENT_MANIFEST.json, SECRETS_MANIFEST.md, migrate.sh' },
];

const STAGES = [
  { key: 'schemas', label: 'Exporting entity schemas' },
  { key: 'data', label: 'Exporting entity data records' },
  { key: 'source', label: 'Fetching source code bundle' },
  { key: 'manifests', label: 'Generating migration manifests' },
  { key: 'zip', label: 'Building ZIP bundle' },
  { key: 'upload', label: 'Uploading to storage' },
];

export default function SeedExportPanel({ embedded = false }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [stageIndex, setStageIndex] = useState(-1);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const handleGenerate = async () => {
    setGenerating(true);
    setError(null);
    setResult(null);
    setStageIndex(0);

    const stageTimer = setInterval(() => {
      setStageIndex(prev => (prev < STAGES.length - 1 ? prev + 1 : prev));
    }, 2500);

    try {
      const res = await base44.functions.invoke('webspaceSeedExport', {});
      clearInterval(stageTimer);
      setStageIndex(STAGES.length);

      if (res?.data?.error) {
        setError(res.data.error);
      } else if (res?.data?.download_url) {
        setResult(res.data);
      } else {
        setError('Unexpected response from export function');
      }
    } catch (e) {
      clearInterval(stageTimer);
      setError(e.message || 'Export failed');
    } finally {
      setGenerating(false);
    }
  };

  if (loading) {
    return (
      <div className="glass-panel clip-corner p-6 tactical-hud flex items-center gap-3">
        <Loader2 size={16} className="text-[#4dd0e1] animate-spin" />
        <span className="text-[11px] text-[#8b949e]">Checking admin access…</span>
      </div>
    );
  }

  if (!user || user.role !== 'admin') {
    return (
      <div className="glass-panel clip-corner p-6 tactical-hud">
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle size={16} className="text-[#FF9F00]" />
          <span className="text-xs font-bold text-[#FF9F00] uppercase tracking-wider">Admin Access Required</span>
        </div>
        <p className="text-[11px] text-[#8b949e] leading-relaxed">
          The SEED export tool is restricted to administrators. This feature bundles the entire webspace —
          all entity schemas, data records, and configuration — for full site migration and audit.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="glass-strong clip-corner p-4 tactical-hud">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 flex items-center justify-center border border-[#3fb950]/40 bg-[#3fb950]/10 clip-corner shrink-0">
            <Sprout size={20} className="text-[#3fb950]" />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-sm font-bold text-[#e6edf3] tracking-tight">SEED — Full Webspace Export</h2>
            <p className="text-[11px] text-[#8b949e] leading-relaxed mt-0.5">
              Generates a comprehensive ZIP bundle of the entire AxiomZero webspace — all entity schemas,
              data records, backend function registry, secrets manifest, DNS/domain guide, and migration
              documentation. Designed for full site migration to WordPress, CMS2CMS, Automattic RSS, or
              any other platform.
            </p>
          </div>
        </div>
      </div>

      {/* Source code note */}
      <div className="glass-panel clip-corner p-3 tactical-hud border border-[#3fb950]/20">
        <div className="flex items-start gap-2">
          <Package size={13} className="text-[#3fb950] shrink-0 mt-0.5" />
          <div>
            <div className="text-[10px] font-bold text-[#3fb950] uppercase tracking-wider mb-1">Source Code Included</div>
            <p className="text-[10px] text-[#8b949e] leading-relaxed">
              The full app source code (React pages, components, backend functions, config files) is bundled
              inside the ZIP in two formats: individual files under <span className="text-[#3fb950] font-mono">source/files/</span> and a
              machine-readable JSON bundle at <span className="text-[#3fb950] font-mono">source/source_bundle.json</span>.
            </p>
          </div>
        </div>
      </div>

      {/* Manifest checklist */}
      <div className="glass-panel clip-corner p-3 tactical-hud">
        <div className="text-[10px] font-bold text-[#4dd0e1] uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
          <FileArchive size={11} /> Bundle Contents
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {MANIFEST_ITEMS.map((item, i) => {
            const Icon = item.icon;
            return (
              <div key={i} className="flex items-start gap-2 p-2 border border-[#30363d]/60 clip-corner bg-[#0a0d11]/40">
                <Icon size={13} className="text-[#4dd0e1] shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <div className="text-[10px] font-bold text-[#e6edf3] leading-snug">{item.label}</div>
                  <div className="text-[9px] text-[#484f58] leading-snug mt-0.5">{item.detail}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Generate button */}
      {!generating && !result && !error && (
        <div className="glass-panel clip-corner p-4 tactical-hud text-center">
          <button
            onClick={handleGenerate}
            className="px-6 py-3 bg-[#3fb950] text-black text-xs font-bold clip-corner hover:brightness-110 transition-all touch-manipulation min-h-[44px] inline-flex items-center gap-2"
            style={{ boxShadow: '0 0 0 1px rgba(63,185,80,0.4), 0 0 14px rgba(63,185,80,0.2)' }}
          >
            <Sprout size={14} /> Generate Seed Bundle
          </button>
          <p className="text-[9px] text-[#484f58] mt-2">
            This takes 10-15 seconds while all entity schemas and data records are bundled.
          </p>
        </div>
      )}

      {/* Progress stages */}
      {generating && (
        <div className="glass-panel clip-corner p-4 tactical-hud">
          <div className="flex items-center gap-2 mb-3">
            <Loader2 size={14} className="text-[#FF9F00] animate-spin" />
            <span className="text-[10px] font-bold text-[#FF9F00] uppercase tracking-wider">Bundling Webspace…</span>
          </div>
          <div className="space-y-1.5">
            {STAGES.map((stage, i) => {
              const done = i < stageIndex;
              const active = i === stageIndex;
              return (
                <div key={stage.key} className="flex items-center gap-2">
                  {done ? (
                    <CheckCircle2 size={12} className="text-[#3fb950] shrink-0" />
                  ) : active ? (
                    <Loader2 size={12} className="text-[#FF9F00] animate-spin shrink-0" />
                  ) : (
                    <div className="w-3 h-3 border border-[#30363d] shrink-0" />
                  )}
                  <span className={`text-[10px] ${done ? 'text-[#3fb950]' : active ? 'text-[#FF9F00]' : 'text-[#484f58]'}`}>
                    {stage.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="glass-panel clip-corner p-4 tactical-hud border border-[#f85149]/30">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle size={14} className="text-[#f85149]" />
            <span className="text-[10px] font-bold text-[#f85149] uppercase tracking-wider">Export Failed</span>
          </div>
          <p className="text-[10px] text-[#8b949e] leading-relaxed mb-3">{error}</p>
          <button
            onClick={handleGenerate}
            className="px-4 py-2 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner hover:bg-[#FF9F00]/20 transition-colors touch-manipulation min-h-[44px]"
          >
            Retry
          </button>
        </div>
      )}

      {/* Result */}
      {result && (
        <div className="space-y-3">
          <div className="glass-panel clip-corner p-4 tactical-hud border border-[#3fb950]/30">
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle2 size={14} className="text-[#3fb950]" />
              <span className="text-[10px] font-bold text-[#3fb950] uppercase tracking-wider">Bundle Ready</span>
            </div>

            {/* Stats grid */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mb-4">
              <div className="border border-[#30363d] clip-corner p-2">
                <div className="text-[8px] text-[#484f58] uppercase">Files in ZIP</div>
                <div className="text-[#4dd0e1] font-mono text-lg">{result.file_count || '—'}</div>
              </div>
              <div className="border border-[#3fb950]/30 clip-corner p-2 bg-[#3fb950]/5">
                <div className="text-[8px] text-[#3fb950] uppercase">Source Files</div>
                <div className="text-[#3fb950] font-mono text-lg">{result.source_file_count || '—'}</div>
              </div>
              <div className="border border-[#30363d] clip-corner p-2">
                <div className="text-[8px] text-[#484f58] uppercase">Entities</div>
                <div className="text-[#4dd0e1] font-mono text-lg">{result.total_entities || '—'}</div>
              </div>
              <div className="border border-[#30363d] clip-corner p-2">
                <div className="text-[8px] text-[#484f58] uppercase">Entity Records</div>
                <div className="text-[#4dd0e1] font-mono text-lg">{result.total_entity_records || '—'}</div>
              </div>
              <div className="border border-[#30363d] clip-corner p-2">
                <div className="text-[8px] text-[#484f58] uppercase">ZIP Size</div>
                <div className="text-[#4dd0e1] font-mono text-lg">{result.zip_size_mb || '—'} MB</div>
              </div>
            </div>

            {/* Entity record counts */}
            {result.entity_counts && Object.keys(result.entity_counts).length > 0 && (
              <div className="mb-4">
                <div className="text-[8px] text-[#484f58] uppercase mb-1.5">Entity Record Counts</div>
                <div className="flex flex-wrap gap-1 max-h-32 overflow-y-auto">
                  {Object.entries(result.entity_counts)
                    .sort((a, b) => b[1] - a[1])
                    .map(([name, count]) => (
                      <span
                        key={name}
                        className={`text-[8px] font-mono px-1.5 py-0.5 border clip-corner ${
                          count < 0
                            ? 'border-[#f85149]/20 text-[#f85149] bg-[#f85149]/5'
                            : count === 0
                            ? 'border-[#30363d] text-[#484f58]'
                            : 'border-[#4dd0e1]/20 text-[#4dd0e1] bg-[#4dd0e1]/5'
                        }`}
                        title={count < 0 ? 'Export error' : `${name}: ${count} records`}
                      >
                        {name}: {count < 0 ? 'ERR' : count}
                      </span>
                    ))}
                </div>
              </div>
            )}

            {/* Download button */}
            <a
              href={result.download_url}
              download="axiomzero-webspace-seed.zip"
              className="flex items-center justify-center gap-2 px-6 py-3 bg-[#3fb950] text-black text-xs font-bold clip-corner hover:brightness-110 transition-all touch-manipulation min-h-[44px] w-full"
              style={{ boxShadow: '0 0 0 1px rgba(63,185,80,0.4), 0 0 14px rgba(63,185,80,0.2)' }}
            >
              <Download size={14} /> Download Seed Bundle (ZIP)
            </a>
            <p className="text-[9px] text-[#484f58] text-center mt-2">
              Generated: {new Date(result.generated_at).toLocaleString()}
            </p>
          </div>

          {/* Source code details */}
          {result.source_code_included && (
            <div className="glass-panel clip-corner p-3 tactical-hud border border-[#3fb950]/20">
              <div className="flex items-start gap-2">
                <Package size={13} className="text-[#3fb950] shrink-0 mt-0.5" />
                <div>
                  <div className="text-[10px] font-bold text-[#3fb950] mb-1">Source Code Included</div>
                  <p className="text-[10px] text-[#8b949e] leading-relaxed mb-2">
                    {result.source_file_count} source files bundled in the ZIP under <span className="text-[#3fb950] font-mono">source/files/</span> (individual files preserving directory structure) and <span className="text-[#3fb950] font-mono">source/source_bundle.json</span> (machine-readable JSON).
                  </p>
                  <div className="text-[9px] text-[#484f58]">
                    Source snapshot: {result.source_generated_at ? new Date(result.source_generated_at).toLocaleString() : 'N/A'}
                  </div>
                </div>
              </div>
            </div>
          )}

          <button
            onClick={() => { setResult(null); setStageIndex(-1); }}
            className="text-[10px] text-[#484f58] hover:text-[#4dd0e1] transition-colors touch-manipulation min-h-[44px] w-full"
          >
            ← Generate another bundle
          </button>
        </div>
      )}
    </div>
  );
}