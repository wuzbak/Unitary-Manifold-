import { Link } from 'react-router-dom';
import { FlaskConical, AlertTriangle, ArrowRight } from 'lucide-react';

/**
 * OpenScienceDisclaimer — bottom-of-Corporate transparent notice.
 * Declares the entire AxiomZero webspace an Open Science Artifact and honestly
 * lists intended functions versus known limitations. Every limitation cited is
 * verified against the repository's FALLIBILITY.md / STATUS.md — no confabulation.
 */
export default function OpenScienceDisclaimer() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-10 mt-2">
      <div className="border border-[#d29922]/40 bg-[#0a0a12]/80 backdrop-blur-md clip-corner p-5 sm:p-7">
        {/* Title */}
        <div className="flex items-center gap-2.5 mb-4">
          <AlertTriangle size={18} className="text-[#d29922] shrink-0" />
          <h2 className="text-[#e6edf3] text-base sm:text-lg font-bold tracking-wide">
            Open Science Artifact — Limitations &amp; Intended Functions
          </h2>
        </div>

        <p className="text-[#8b949e] text-sm leading-relaxed mb-4 max-w-4xl">
          The entirety of this webspace — every page, visualization, engine, ledger,
          and document — is published as an <span className="text-[#d29922] font-bold">Open Science Artifact</span>.
          It is a transparent, honest research instrument, not a commercial product.
          The statements below are grounded in the Unitary Manifold repository's own
          fallibility register and status tracking.
        </p>

        {/* Zero-liability callout — per Section 4 of the Integrated Licensing Policy */}
        <div className="border-2 border-[#f85149]/40 bg-[#f85149]/8 clip-corner p-3.5 mb-5">
          <div className="flex items-start gap-2.5">
            <AlertTriangle size={16} className="text-[#f85149] shrink-0 mt-0.5" />
            <div>
              <p className="text-[#f85149] text-xs font-bold uppercase tracking-wider mb-1">
                Use at Your Own Risk — Zero Liability
              </p>
              <p className="text-[#e6edf3] text-xs sm:text-[13px] leading-relaxed">
                ALL open science artifacts, products, and software are use at &ldquo;your own risk.&rdquo;
                <span className="text-[#e6edf3] font-bold"> AxiomZero Technologies &amp; Consulting, SPC</span>{' '}
                assumes <span className="text-[#f85149] font-bold">ZERO risk or liability</span> for use or
                integration. These artifacts are works in development and may have ERRORS (modules/pages
                are in various states of functionality). The{' '}
                <a href="https://github.com/wuzbak/Unitary-Manifold" target="_blank" rel="noopener noreferrer" className="text-[#4dd0e1] hover:underline font-bold">
                  GitHub Unitary Manifold repository
                </a>{' '}
                is the <span className="text-[#d29922] font-bold">Truth Anchor</span> for the DEMO
                simulations currently hosted on Base44.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Intended Functions */}
          <div className="border border-[#00f5ff]/25 bg-[#00f5ff]/5 clip-corner p-4">
            <div className="flex items-center gap-2 mb-3">
              <FlaskConical size={15} className="text-[#00f5ff]" />
              <h3 className="text-[#00f5ff] text-xs font-bold uppercase tracking-wider">Intended Functions</h3>
            </div>
            <ul className="space-y-2 text-[#8b949e] text-xs sm:text-[13px] leading-relaxed">
              <li><span className="text-[#e6edf3] font-bold">Deterministic scientific engines</span> — falsification testing, statistical verification, and physics compute against the Unitary Manifold framework.</li>
              <li><span className="text-[#e6edf3] font-bold">Governance ledgers</span> — auditable state records, ECLIPSA integrity monitoring, and Pentad framework tracking.</li>
              <li><span className="text-[#e6edf3] font-bold">Diagnostic &amp; falsification tools</span> — the Falsification Observatory and Interrogator for claim-challenge operations.</li>
              <li><span className="text-[#e6edf3] font-bold">Multi-model AI capability</span> — assistant, research, and analysis surfaces via multiple LLM providers.</li>
              <li><span className="text-[#e6edf3] font-bold">Local-first compute</span> — in-browser scientific calculation with zero-tracker policy and transparent provenance.</li>
            </ul>
          </div>

          {/* Known Limitations */}
          <div className="border border-[#d29922]/30 bg-[#d29922]/5 clip-corner p-4">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle size={15} className="text-[#d29922]" />
              <h3 className="text-[#d29922] text-xs font-bold uppercase tracking-wider">Known Limitations</h3>
            </div>
            <ul className="space-y-2 text-[#8b949e] text-xs sm:text-[13px] leading-relaxed">
              <li><span className="text-[#e6edf3] font-mono">MAS Wave Engine</span> — Λ_QCD exhibits a ~10⁷ order mismatch, classified as <span className="text-[#d29922] font-mono">ARCHITECTURE_LIMIT</span>.</li>
              <li><span className="text-[#e6edf3] font-mono">Δm²₂₁</span> residual tension ~1.07σ — certified <span className="text-[#d29922] font-mono">NNLO_ARCHITECTURE_LIMIT_CERTIFIED</span>.</li>
              <li><span className="text-[#e6edf3] font-mono">Yukawa sector</span> is fitted, not top-down derived — <span className="text-[#d29922] font-mono">ARCHITECTURE_LIMIT</span>.</li>
              <li><span className="text-[#e6edf3] font-mono">S³×S² Kawamura import</span> reproduces K_CS=74, but the Z₂ parity matrix is not internally derived — honest negative.</li>
              <li><span className="text-[#e6edf3] font-mono">Higgs 1-loop CW</span> gives m_H ≈ 34 GeV, below the PDG value — the architecture limit survives.</li>
              <li><span className="text-[#e6edf3]">Third-party data APIs</span> (e.g. CourtListener, OpenCorporates, Aleph) may return 401 until their access tokens are refreshed in settings.</li>
              <li><span className="text-[#e6edf3] font-bold">This is a research artifact</span>, not a certified, warranted, or production-grade product. Use at your own risk.</li>
            </ul>
          </div>
        </div>

        {/* Footer — full fallibility register lives in the repo */}
        <div className="mt-5 pt-4 border-t border-[#30363d] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <p className="text-[#484f58] text-[11px] font-mono">
            The complete, continuously-updated fallibility register lives in the repository (FALLIBILITY.md / STATUS.md).
          </p>
          <Link
            to="/corporate"
            className="inline-flex items-center gap-1.5 text-[#00f5ff] text-xs font-bold tracking-wider hover:underline shrink-0"
          >
            Open Licensing &amp; Legal <ArrowRight size={13} />
          </Link>
        </div>
      </div>
    </section>
  );
}