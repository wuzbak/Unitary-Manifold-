/**
 * LegalDocModal — reusable verbatim viewer for a repository legal document.
 * Fetches the raw file from the Unitary Manifold repo and displays it verbatim
 * (no paraphrasing). Used by the Licensing tab's legal-document index cards.
 */
import { useState, useEffect } from 'react';
import { Loader2, ExternalLink, AlertTriangle, X } from 'lucide-react';

const RAW_BASE = 'https://raw.githubusercontent.com/wuzbak/Unitary-Manifold-/main/';
const REPO_URL = 'https://github.com/wuzbak/Unitary-Manifold-';

export default function LegalDocModal({ doc, onClose }) {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!doc?.path) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    setContent('');
    fetch(`${RAW_BASE}${doc.path}`)
      .then((r) => {
        if (!r.ok) throw new Error(`Failed (${r.status})`);
        return r.text();
      })
      .then((t) => {
        if (!cancelled) {
          setContent(t);
          setLoading(false);
        }
      })
      .catch((e) => {
        if (!cancelled) {
          setError(e.message || 'Failed to load document');
          setLoading(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [doc?.path]);

  if (!doc) return null;
  const Icon = doc.icon;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="glass-strong clip-corner w-full max-w-3xl max-h-[80vh] flex flex-col fade-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#30363d]">
          <div className="flex items-center gap-2 min-w-0">
            {Icon && <Icon size={14} style={{ color: doc.accent }} className="shrink-0" />}
            <span className="text-sm font-bold text-[#e6edf3] truncate">{doc.title}</span>
            <span className="text-[10px] text-[#484f58] font-mono truncate hidden sm:inline">
              {doc.path}
            </span>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <a
              href={`${REPO_URL}/blob/main/${doc.path}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#58a6ff] hover:underline text-xs flex items-center gap-1"
            >
              <ExternalLink size={11} /> GitHub
            </a>
            <button onClick={onClose} className="text-[#8b949e] hover:text-[#e6edf3] transition-colors">
              <X size={16} />
            </button>
          </div>
        </div>
        <div className="flex-1 overflow-auto p-4">
          {loading && (
            <div className="flex items-center justify-center py-10 gap-2">
              <Loader2 className="animate-spin text-[#00f5ff]" size={18} />
              <span className="text-[#8b949e] text-sm">Fetching canonical text…</span>
            </div>
          )}
          {error && (
            <div className="flex items-start gap-2 text-[#f85149] text-sm">
              <AlertTriangle size={16} className="shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Could not load this document.</p>
                <p className="text-[#8b949e] text-xs mt-1">{error}</p>
                <a
                  href={`${REPO_URL}/blob/main/${doc.path}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 mt-2 text-[#58a6ff] text-xs hover:underline"
                >
                  <ExternalLink size={11} /> Read it directly on GitHub
                </a>
              </div>
            </div>
          )}
          {!loading && !error && (
            <pre className="text-[11px] sm:text-xs text-[#e6edf3] font-mono whitespace-pre-wrap break-words leading-relaxed">
              {content}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
}