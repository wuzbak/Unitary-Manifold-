import { Link } from 'react-router-dom';
import {
  ShieldCheck,
  Lock,
  GitBranch,
  FileText,
  AlertTriangle,
  ExternalLink,
  Scale,
  Gavel,
  Eye,
  Building2,
} from 'lucide-react';

const REPO_URL = 'https://github.com/wuzbak/Unitary-Manifold';
const SITE_URL = 'https://axiomzerospc.org/';
const ZENODO_DOI = '10.5281/zenodo.19584531';
const ZENODO_URL = 'https://doi.org/10.5281/zenodo.19584531';

/**
 * IntegratedLicensingPolicy — the full, official 4-section
 * Integrated Licensing, User Agreement, and Waiver Policy (Aug 28, 2026).
 * Rendered verbatim from the corporate document — no paraphrasing.
 */
export default function IntegratedLicensingPolicy() {
  return (
    <div className="space-y-4">
      {/* Document header */}
      <div className="border border-[#00f5ff]/25 bg-[#0a0a12]/80 backdrop-blur-md clip-corner p-4">
        <div className="flex items-center gap-2 mb-2">
          <ShieldCheck size={16} className="text-[#00f5ff]" />
          <h3 className="text-[#00f5ff] text-sm font-bold uppercase tracking-wider">
            Integrated Licensing, User Agreement &amp; Waiver Policy
          </h3>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[10px] text-[#484f58] font-mono mb-2">
          <span className="text-[#e6edf3] font-bold">AxiomZero Technologies &amp; Consulting, SPC</span>
          <span>UBI: 606 239 876</span>
          <span>·</span>
          <span>August 28, 2026</span>
        </div>
        <p className="text-[#8b949e] text-xs leading-relaxed">
          This is the truth layer. The Corporation does not provide these artifacts for entrapment.
          The policy below is the official, binding Integrated Licensing, User Agreement, and Waiver
          Policy of the Corporation. It is reproduced in full — no summary, no abbreviation.
        </p>
      </div>

      {/* SECTION 1 — Statutory Social Purpose & Fiduciary Alignment */}
      <PolicySection
        icon={ShieldCheck}
        accent="#3fb950"
        number="1"
        title="Statutory Social Purpose & Fiduciary Alignment"
      >
        <p className="text-[#c9d1d9] text-xs sm:text-[13px] leading-relaxed mb-3">
          AxiomZero Technologies &amp; Consulting, SPC (the &ldquo;Corporation&rdquo;) is organized as a
          state-chartered Washington Social Purpose Corporation pursuant to{' '}
          <Cite>Chapter 23B.25 RCW</Cite>. In strict compliance with its Articles of Incorporation and
          the mandate set forth under <Cite>RCW 23B.25.040(1)(e)</Cite>, the fiduciary architecture
          of the Corporation is legally decoupled from standard shareholder wealth maximization.
          Pursuant to <Cite>RCW 23B.25.050</Cite>, the Director and officers are granted robust safe
          harbor protections to prioritize the Corporation&rsquo;s stated social purposes over
          short-term capital extraction. These social purposes are codified as:
        </p>
        <ul className="space-y-2 text-[#8b949e] text-xs sm:text-[13px] leading-relaxed mb-3">
          <li className="flex gap-2">
            <span className="text-[#3fb950] font-bold shrink-0">(a)</span>
            <span><span className="text-[#e6edf3] font-bold">Ethical AI Governance</span> via the deployment of the 5-body/7-body Human-in-the-Loop Systems (HILS) Unitary Pentad framework;</span>
          </li>
          <li className="flex gap-2">
            <span className="text-[#3fb950] font-bold shrink-0">(b)</span>
            <span><span className="text-[#e6edf3] font-bold">Technical Risk Reduction</span> via GibberLink and SDAM acoustic transport integrations; and</span>
          </li>
          <li className="flex gap-2">
            <span className="text-[#3fb950] font-bold shrink-0">(c)</span>
            <span><span className="text-[#e6edf3] font-bold">Environmental Stewardship</span> via energy minimization.</span>
          </li>
        </ul>
      </PolicySection>

      {/* SECTION 2 — Dual-Layer IP Moat */}
      <PolicySection
        icon={Lock}
        accent="#00f5ff"
        number="2"
        title="Dual-Layer Intellectual Property Moat"
      >
        <p className="text-[#c9d1d9] text-xs sm:text-[13px] leading-relaxed mb-3">
          To protect the scientific commons of theoretical physics while building a high-margin,
          scalable commercial consulting and licensing business, the Corporation maintains a strict
          dual-layer IP strategy:
        </p>
        <div className="space-y-3">
          <div className="border border-[#3fb950]/30 bg-[#3fb950]/5 clip-corner p-3">
            <div className="flex items-center gap-2 mb-1.5">
              <GitBranch size={13} className="text-[#3fb950]" />
            <span className="text-[#3fb950] text-xs font-bold">Defensive Public Commons License v1.0 (DPC v1.0)</span>
            </div>
            <p className="text-[#8b949e] text-xs leading-relaxed">
              Covers the entire theoretical physics framework, Walker-Pearson field equations, 5D
              Kaluza-Klein theoretical derivations, and the scientific monograph. The theory is
              irrevocably dedicated to the public domain to establish permanent prior art{' '}
              (<span className="text-[#e6edf3] font-mono">Zenodo DOI:{ZENODO_DOI}</span>), permanently
              blocking downstream patent enclosure. <span className="text-[#f85149] font-bold">Charging fees for the theoretical physics or raw derivations is strictly prohibited under Section 2.</span>
            </p>
          </div>
          <div className="border border-[#00f5ff]/30 bg-[#00f5ff]/5 clip-corner p-3">
            <div className="flex items-center gap-2 mb-1.5">
              <Lock size={13} className="text-[#00f5ff]" />
            <span className="text-[#00f5ff] text-xs font-bold">GNU Affero General Public License v3.0 (AGPL-3.0)</span>
            </div>
            <p className="text-[#8b949e] text-xs leading-relaxed">
              Selectively covers the Corporation&rsquo;s programmatic software implementation
              (including <span className="text-[#e6edf3] font-mono">src/, tests/, Unitary Pentad/, omega/, bot/, and embryology-manifold/</span>).
              Under <Cite>AGPL-3.0 Section 13</Cite>, any entity running modified versions of this
              software over a network (e.g., Cloud APIs or SaaS platforms) to interact with remote
              users must make their complete corresponding source code available publicly under
              copyleft terms.
            </p>
          </div>
        </div>
      </PolicySection>

      {/* SECTION 3 — Commercial License Exceptions & Waiver Policies */}
      <PolicySection
        icon={FileText}
        accent="#bc8cff"
        number="3"
        title="Commercial License Exceptions & Waiver Policies"
      >
        <p className="text-[#c9d1d9] text-xs sm:text-[13px] leading-relaxed mb-3">
          For enterprise clients, government bodies, and defense contractors who require integration
          of the Corporation&rsquo;s software implementation into closed, proprietary, or classified
          networks, the Corporation grants <span className="text-[#e6edf3] font-bold">Commercial License Exceptions (CLEs)</span>.
          These CLEs act as explicit, targeted contractual waivers of the source-disclosure mandates
          of AGPL-3.0 Section 13 in exchange for negotiated commercial consideration.
        </p>

        <SubSection icon={Scale} accent="#bc8cff" label="3.1" title="Case-by-Case, Product-by-Product Evaluation">
          <p className="text-[#8b949e] text-xs leading-relaxed">
            Commercial License Exceptions, copyleft waivers, and operational exemptions are{' '}
            <span className="text-[#e6edf3] font-bold">never granted automatically, universally, or in perpetuity</span>.
            Waivers and CLEs shall be negotiated and granted strictly on a case-by-case and
            product-by-product basis. An exception granted for one specific software module (e.g.,
            AxiomOS) does not extend, by implication or structure, to any other product or system in
            the Corporation&rsquo;s portfolio (e.g., the Unitary Pentad HILS Engine).
          </p>
        </SubSection>

        <SubSection icon={ShieldCheck} accent="#d29922" label="3.2" title="Mandatory Due Diligence & Ethical Alignment Audit">
          <p className="text-[#8b949e] text-xs leading-relaxed mb-2">
            Prior to the commencement of any formal negotiation or the execution of any licensing
            waiver, the Corporation&rsquo;s Board of Directors and Chief Purpose Officer reserve the{' '}
            <span className="text-[#e6edf3] font-bold">absolute, unconditioned right</span> to perform a
            comprehensive due diligence and ethical alignment check on the prospective client, its
            parent entities, its primary funding sources, and its intended deployment targets. Any
            proposed application that intersects with prohibited high-risk fields shall result in the
            potential (immediate and permanent) denial of waiver eligibility. Prohibited fields:
          </p>
          <ul className="space-y-1 text-[#8b949e] text-xs leading-relaxed">
            <li className="flex gap-2"><span className="text-[#f85149]">▸</span><span>Kinetic weapons tracking</span></li>
            <li className="flex gap-2"><span className="text-[#f85149]">▸</span><span>Non-consensual biological surveillance</span></li>
            <li className="flex gap-2"><span className="text-[#f85149]">▸</span><span>Automated systems designed to bypass human oversight</span></li>
          </ul>
        </SubSection>

        <SubSection icon={Eye} accent="#58a6ff" label="3.3" title="Mandatory Public Disclosure Authorization">
          <p className="text-[#8b949e] text-xs leading-relaxed">
            To promote public accountability and satisfy the statutory reporting requirements of
            Washington SPC law, the Corporation rejects absolute commercial secrecy. AxiomZero
            Technologies &amp; Consulting, SPC reserves the explicit right, at its sole discretion, to{' '}
            <span className="text-[#e6edf3] font-bold">publicly disclose the existence, licensing scope, and core transaction terms</span>{' '}
            of any contract or waiver executed with external clients. While client-proprietary
            datasets and trade secrets will remain protected under mutual non-disclosure agreements,
            the legal and operational fact of a waiver being granted to an enterprise&mdash;and the
            ethical constraints governing that waiver&mdash;shall remain eligible for public
            registration and inclusion in the Corporation&rsquo;s annual Social Purpose Report.
          </p>
        </SubSection>
      </PolicySection>

      {/* SECTION 4 — Risk Transmutation & Zero-Liability Posture */}
      <PolicySection
        icon={AlertTriangle}
        accent="#f85149"
        number="4"
        title="Risk Transmutation & Zero-Liability Posture"
      >
        <p className="text-[#c9d1d9] text-xs sm:text-[13px] leading-relaxed mb-3">
          Because the Corporation operates as a highly specialized pure-research and strategic
          advisory firm, it enforces an unyielding risk-transmutation contracting paradigm. All
          commercial consulting agreements, Master Services Agreements (MSAs), Statements of Work
          (SOWs), and any and all work must integrate a{' '}
          <span className="text-[#e6edf3] font-bold">Super-Priority Limitation of Liability</span>{' '}
          capping the Corporation&rsquo;s aggregate liability at exactly{' '}
          <span className="text-[#f85149] font-bold font-mono">$0.00 (Zero US Dollars)</span>. This cap
          is absolute and takes precedence over any conflicting, mutual, or indemnification terms in
          any client-provided agreement. Furthermore, clients must contractually execute a{' '}
          <span className="text-[#e6edf3] font-bold">Unilateral Indemnification and Hold Harmless</span>{' '}
          clause, absorbing 100% of the operational, technical, and regulatory risks associated with
          the physical deployment or real-world execution of the Corporation&rsquo;s recommendations,
          simulations, and software.
        </p>

        {/* Zero-liability callout */}
        <div className="border-2 border-[#f85149]/50 bg-[#f85149]/8 clip-corner p-4 my-3">
          <div className="flex items-start gap-2.5">
            <AlertTriangle size={18} className="text-[#f85149] shrink-0 mt-0.5" />
            <div>
              <p className="text-[#f85149] text-xs font-bold uppercase tracking-wider mb-1">
                Zero-Liability Declaration
              </p>
              <p className="text-[#e6edf3] text-xs sm:text-[13px] leading-relaxed font-bold">
                ALL open science artifacts, products, and software are use at &ldquo;your own risk.&rdquo;
                AxiomZero Technologies &amp; Consulting, SPC assumes{' '}
                <span className="text-[#f85149]">ZERO risk or liability</span> for use or integration.
              </p>
            </div>
          </div>
        </div>

        <p className="text-[#8b949e] text-xs leading-relaxed mb-3">
          <span className="text-[#e6edf3] font-bold">AxiomZero Technologies &amp; Consulting, SPC</span>
        </p>

        {/* Open Science Artifact links */}
        <div className="border border-[#30363d] bg-[#0d1117] clip-corner p-3">
          <div className="flex items-center gap-2 mb-2">
            <ExternalLink size={13} className="text-[#4dd0e1]" />
            <span className="text-[#4dd0e1] text-[11px] font-bold uppercase tracking-wider">
              Links to Open Science Artifacts
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            <a href={SITE_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 border border-[#00f5ff]/30 bg-[#00f5ff]/5 px-2.5 py-1.5 text-[11px] text-[#00f5ff] hover:bg-[#00f5ff]/15 transition-colors clip-corner">
              <Building2 size={11} /> axiomzerospc.org
            </a>
            <a href={REPO_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 border border-[#bc8cff]/30 bg-[#bc8cff]/5 px-2.5 py-1.5 text-[11px] text-[#bc8cff] hover:bg-[#bc8cff]/15 transition-colors clip-corner">
              <GitBranch size={11} /> github.com/wuzbak/Unitary-Manifold
            </a>
            <a href={ZENODO_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 border border-[#3fb950]/30 bg-[#3fb950]/5 px-2.5 py-1.5 text-[11px] text-[#3fb950] hover:bg-[#3fb950]/15 transition-colors clip-corner">
              <FileText size={11} /> Zenodo DOI:{ZENODO_DOI}
            </a>
          </div>
        </div>

        {/* Closing note */}
        <div className="mt-3 border-l-2 border-[#d29922] pl-3 py-1">
          <p className="text-[#d29922] text-[11px] leading-relaxed">
            <span className="font-bold">NOTE:</span> These artifacts are works in development and may
            have ERRORS (modules/pages are in various states of functionality). The GitHub Unitary
            Manifold&rsquo;s work is the <span className="font-bold">Truth Anchor</span> for DEMO
            simulations currently hosted on Base44.
          </p>
        </div>
      </PolicySection>

      {/* Waiver request CTA */}
      <div className="border border-[#ff9f00]/30 bg-[#ff9f00]/5 clip-corner p-3 flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <Gavel size={14} className="text-[#ff9f00]" />
          <span className="text-[#e6edf3] text-xs">
            Request a Commercial License Exception or waiver
          </span>
        </div>
        <Link
          to="/client-inquiry"
          className="inline-flex items-center gap-1.5 text-[#ff9f00] text-xs font-bold tracking-wider hover:underline"
        >
          Client Inquiry <ExternalLink size={11} />
        </Link>
      </div>
    </div>
  );
}

function PolicySection({ icon: Icon, accent, number, title, children }) {
  return (
    <div className="border bg-[#0a0a12]/80 backdrop-blur-md clip-corner p-4" style={{ borderColor: `${accent}33` }}>
      <div className="flex items-center gap-2.5 mb-3">
        <div className="w-8 h-8 flex items-center justify-center border clip-corner shrink-0" style={{ borderColor: `${accent}50`, background: `${accent}10` }}>
          <Icon size={16} style={{ color: accent }} />
        </div>
        <div className="min-w-0">
          <div className="text-[10px] font-mono uppercase tracking-wider" style={{ color: accent }}>
            Section {number}
          </div>
          <h4 className="text-[#e6edf3] text-sm font-bold leading-tight">{title}</h4>
        </div>
      </div>
      <div className="pl-0 sm:pl-[42px]">{children}</div>
    </div>
  );
}

function SubSection({ icon: Icon, accent, label, title, children }) {
  return (
    <div className="mt-3 border-l-2 pl-3 py-1" style={{ borderColor: `${accent}50` }}>
      <div className="flex items-center gap-2 mb-1.5">
        <Icon size={12} style={{ color: accent }} />
        <span className="font-mono text-[10px] font-bold" style={{ color: accent }}>{label}</span>
        <span className="text-[#e6edf3] text-xs font-bold">{title}</span>
      </div>
      {children}
    </div>
  );
}

function Cite({ children }) {
  return <span className="text-[#4dd0e1] font-mono text-[11px]">{children}</span>;
}