import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Loader2,
  ExternalLink,
  AlertTriangle,
  ScrollText,
  FileText,
  ShieldAlert,
  Gavel,
  FileWarning,
  Scale,
  ArrowRight,
} from 'lucide-react';
import LegalDocModal from './LegalDocModal';
import IntegratedLicensingPolicy from './IntegratedLicensingPolicy';

const REPO_URL = 'https://github.com/wuzbak/Unitary-Manifold-';
const RAW_BASE = 'https://raw.githubusercontent.com/wuzbak/Unitary-Manifold-/main/';

// The two canonical licenses — both fetched live and shown verbatim.
const LICENSES = [
  {
    key: 'dpcl',
    label: 'DPCL v1.0',
    path: 'LICENSE',
    desc: 'Defensive Public Commons License v1.0 (2026) — covers theoretical content.',
  },
  {
    key: 'agpl',
    label: 'AGPL-3.0',
    path: 'LICENSE-AGPL',
    desc: 'GNU AGPL v3.0-or-later — covers software implementation only.',
  },
];

// Legal-document index — every path verified against the live repository.
// No waiver file exists; waiver access is a /client-inquiry link (not a fabricated doc).
const LEGAL_DOCS = [
  {
    key: 'user-agreement',
    title: 'User Agreement',
    desc: 'Commercial terms & user obligations.',
    path: 'docs/policy/COMMERCIAL_TERMS.md',
    icon: FileText,
    accent: '#4dd0e1',
  },
  {
    key: 'waiver',
    title: 'Waiver Access',
    desc: 'Request a waiver to either license.',
    link: '/client-inquiry',
    icon: Gavel,
    accent: '#ff9f00',
  },
  {
    key: 'dual-use',
    title: 'Dual-Use Notice',
    desc: 'Ethical-use restrictions on outputs.',
    path: 'DUAL_USE_NOTICE.md',
    icon: ShieldAlert,
    accent: '#d29922',
  },
  {
    key: 'notice',
    title: 'NOTICE',
    desc: 'Attribution & third-party notices.',
    path: 'NOTICE',
    icon: FileText,
    accent: '#8b949e',
  },
  {
    key: 'fallibility',
    title: 'Fallibility Register',
    desc: 'Known limitations & architecture limits.',
    path: 'FALLIBILITY.md',
    icon: FileWarning,
    accent: '#d29922',
  },
  {
    key: 'pentad-notice',
    title: 'Pentad Product Notice',
    desc: 'Pentad product governance & scope.',
    path: 'PENTAD_PRODUCT_NOTICE.md',
    icon: Scale,
    accent: '#bc8cff',
  },
];

/**
 * LicensingTab — the Dual License tab on the Corporate page.
 * Shows both canonical licenses (DPCL v1.0 + AGPL-3.0) fetched live and verbatim,
 * plus a linked legal-document index: User Agreement, Waiver Access (Client
 * Inquiry), and Legal Disclaimers (Dual-Use Notice, NOTICE, Fallibility Register,
 * Pentad Product Notice). All text is fetched live from the repo — no paraphrasing.
 */
export default function LicensingTab({ embedded }) {
  const [activeLicense, setActiveLicense] = useState('dpcl');
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalDoc, setModalDoc] = useState(null);

  const currentLicense = LICENSES.find((l) => l.key === activeLicense);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    fetch(`${RAW_BASE}${currentLicense.path}`)
      .then((res) => {
        if (!res.ok) throw new Error(`Failed to fetch ${currentLicense.path} (${res.status})`);
        return res.text();
      })
      .then((text) => {
        if (!cancelled) {
          setContent(text);
          setLoading(false);
        }
      })
      .catch((e) => {
        if (!cancelled) {
          setError(e.message || 'Failed to load license');
          setLoading(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [activeLicense]);

  return (
    <div className="space-y-4">
      {/* Full Integrated Licensing Policy — 4 statutory sections */}
      <IntegratedLicensingPolicy />

      {/* Verbatim canonical license viewer */}
      <div className="border border-[#00f5ff]/25 bg-[#0a0a12]/80 backdrop-blur-md clip-corner p-4">
        <div className="flex items-center gap-2 mb-2">
          <ScrollText size={16} className="text-[#00f5ff]" />
          <h3 className="text-[#00f5ff] text-sm font-bold uppercase tracking-wider">
            Canonical License Text — Verbatim
          </h3>
        </div>
        <p className="text-[#8b949e] text-xs leading-relaxed mb-2">
          The work is dual-licensed under the{' '}
          <span className="text-[#e6edf3] font-bold">Defensive Public Commons License v1.0</span>{' '}
          (theoretical content, public domain) and{' '}
          <span className="text-[#e6edf3] font-bold">AGPL-3.0-or-later</span> (software implementation).
          Both are reproduced verbatim from the repository — no paraphrasing. Commercial License
          Exceptions to AGPL-3.0 Section 13 are available via{' '}
          <Link to="/client-inquiry" className="text-[#ff9f00] hover:underline font-bold">
            Client Inquiry
          </Link>
          .
        </p>
        <a
          href={`${REPO_URL}/blob/main/${currentLicense.path}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 text-[#58a6ff] text-xs hover:underline"
        >
          <ExternalLink size={12} /> View on GitHub · {REPO_URL}
        </a>
      </div>

      {/* Verbatim license viewer with DPCL / AGPL toggle */}
      <div className="border border-[#30363d] bg-[#0d1117] clip-corner">
        <div className="flex items-center justify-between px-4 py-2 border-b border-[#30363d] bg-[#161b22] flex-wrap gap-2">
          <div className="flex gap-1">
            {LICENSES.map((l) => (
              <button
                key={l.key}
                onClick={() => setActiveLicense(l.key)}
                title={l.desc}
                className={`px-3 py-1 text-xs font-bold clip-corner transition-all ${
                  activeLicense === l.key
                    ? 'bg-[#00f5ff]/15 text-[#00f5ff] border border-[#00f5ff]/40'
                    : 'text-[#8b949e] border border-transparent hover:text-[#e6edf3]'
                }`}
              >
                {l.label}
              </button>
            ))}
          </div>
          <span className="text-[#484f58] text-[10px] font-mono">
            {currentLicense.path} · {content.length.toLocaleString()} chars · verbatim
          </span>
        </div>
        <div className="px-4 py-2 border-b border-[#30363d] bg-[#0d1117]">
          <p className="text-[10px] text-[#8b949e] leading-relaxed">{currentLicense.desc}</p>
        </div>
        <div className="p-4 max-h-[50vh] overflow-auto">
          {loading && (
            <div className="flex items-center justify-center py-12 gap-2">
              <Loader2 className="animate-spin text-[#00f5ff]" size={20} />
              <span className="text-[#8b949e] text-sm">Fetching canonical license text…</span>
            </div>
          )}
          {error && (
            <div className="flex items-start gap-2 py-6 text-[#f85149] text-sm">
              <AlertTriangle size={16} className="shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Could not load the license file.</p>
                <p className="text-[#8b949e] text-xs mt-1">{error}</p>
                <a
                  href={`${REPO_URL}/blob/main/${currentLicense.path}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 mt-2 text-[#58a6ff] text-xs hover:underline"
                >
                  <ExternalLink size={12} /> Read it directly on GitHub
                </a>
              </div>
            </div>
          )}
          {!loading && !error && (
            <pre className="text-[11px] sm:text-xs text-[#e6edf3] font-mono whitespace-pre-wrap break-words leading-relaxed">
              {content}
            </pre>
          )}
        </div>
      </div>

      {/* Legal document index — glass cards */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <FileText size={14} className="text-[#4dd0e1]" />
          <h4 className="text-[#4dd0e1] text-xs font-bold uppercase tracking-wider">
            Legal Documents &amp; Disclaimers
          </h4>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {LEGAL_DOCS.map((doc) => {
            const Icon = doc.icon;
            const isLink = !!doc.link;
            const cardClass =
              'group border bg-[#0a0a12]/80 backdrop-blur-md clip-corner p-3 transition-all flex flex-col gap-1.5';
            const cardStyle = { borderColor: `${doc.accent}33` };
            const hoverStyle = isLink
              ? 'hover:border-[#ff9f00]/50'
              : 'hover:border-[#4dd0e1]/50';
            return isLink ? (
              <Link
                key={doc.key}
                to={doc.link}
                className={`${cardClass} ${hoverStyle}`}
                style={cardStyle}
              >
                <div className="flex items-center gap-2">
                  <Icon size={14} style={{ color: doc.accent }} />
                  <span className="text-[#e6edf3] text-xs font-bold">{doc.title}</span>
                  <ArrowRight
                    size={11}
                    className="text-[#484f58] group-hover:text-[#ff9f00] ml-auto transition-colors"
                  />
                </div>
                <p className="text-[10px] text-[#8b949e] leading-relaxed">{doc.desc}</p>
              </Link>
            ) : (
              <button
                key={doc.key}
                onClick={() => setModalDoc(doc)}
                className={`${cardClass} ${hoverStyle} text-left`}
                style={cardStyle}
              >
                <div className="flex items-center gap-2">
                  <Icon size={14} style={{ color: doc.accent }} />
                  <span className="text-[#e6edf3] text-xs font-bold">{doc.title}</span>
                  <ExternalLink
                    size={11}
                    className="text-[#484f58] group-hover:text-[#4dd0e1] ml-auto transition-colors"
                  />
                </div>
                <p className="text-[10px] text-[#8b949e] leading-relaxed">{doc.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Verbatim document viewer modal */}
      {modalDoc && <LegalDocModal doc={modalDoc} onClose={() => setModalDoc(null)} />}
    </div>
  );
}