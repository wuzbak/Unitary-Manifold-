import { Building2, GraduationCap, Landmark, FlaskConical } from 'lucide-react';

const TYPE_ICONS = {
  Academic: GraduationCap,
  Government: Landmark,
  Industry: Building2,
  Research: FlaskConical
};

const TYPE_COLORS = {
  Academic: 'bg-[#0d2040] text-[#58a6ff]',
  Government: 'bg-[#3a2d0a] text-[#d29922]',
  Industry: 'bg-[#1a3a25] text-[#3fb950]',
  Research: 'bg-[#2a1a3a] text-[#bc8cff]'
};

export default function PartnerCard({ partner }) {
  const Icon = TYPE_ICONS[partner.type] || Building2;
  return (
    <div className="bg-[#161b22] border border-[#30363d] rounded-lg p-4 hover:border-[#58a6ff] transition-colors">
      <div className="flex items-center gap-2 mb-2">
        <Icon size={18} className="text-[#58a6ff]" />
        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${TYPE_COLORS[partner.type] || 'bg-[#21262d] text-[#8b949e]'}`}>{partner.type}</span>
      </div>
      <h3 className="text-[#e6edf3] font-bold text-sm mb-1">{partner.name}</h3>
      <p className="text-[#8b949e] text-xs leading-relaxed mb-2">{partner.description}</p>
      {partner.contribution && <p className="text-[#58a6ff] text-xs">Contribution: {partner.contribution}</p>}
    </div>
  );
}