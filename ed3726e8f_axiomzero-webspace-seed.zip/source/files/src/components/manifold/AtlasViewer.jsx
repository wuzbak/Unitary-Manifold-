/**
 * AtlasViewer — Ultra HD Manifold Atlas Visualization Engine
 *
 * Supports 5 visualization modes:
 *   - geometric:     Wireframe manifold structures (torus, knot, sphere, icosa, cone, calabi-yau)
 *   - plasma:        Plasma current streams with hot-to-cool particle flow
 *   - electromagnetic: Toroidal EM field lines with flowing energy
 *   - gravity:       Spacetime curvature grid (gravitational well)
 *   - thermodynamics: Heat flow with entropy gradient
 *
 * Dimension selector: 3D, 5D, 7D, 11D, 13D — modulates structural complexity.
 *
 * AxiomZero Technologies & Consulting, SPC / ThomasCory Walker-Pearson
 */
import { useEffect, useRef } from 'react';
import * as THREE from 'three';

// ── Structure definitions ──
const STRUCTURES = {
  torus: { name: 'Torus T²', geo: (dim) => new THREE.TorusGeometry(2, 0.7, 32, dim >= 11 ? 200 : 128) },
  knot: { name: 'Torus Knot K', geo: (dim) => new THREE.TorusKnotGeometry(2, 0.5, dim >= 11 ? 256 : 128, 32) },
  sphere: { name: 'Sphere S²', geo: (dim) => new THREE.SphereGeometry(2, dim >= 11 ? 64 : 48, dim >= 11 ? 64 : 48) },
  icosa: { name: 'Icosahedron', geo: (dim) => new THREE.IcosahedronGeometry(2, dim >= 11 ? 2 : 1) },
  cone: { name: 'Orbifold Z₂', geo: () => new THREE.ConeGeometry(1.5, 3, 6) },
  calabi: { name: 'Calabi-Yau 13D', geo: null }, // special — built manually
};

// ── Dimension modulation factor ──
function dimFactor(dim) {
  const map = { 3: 1.0, 5: 1.3, 7: 1.6, 11: 2.0, 13: 2.5 };
  return map[dim] || 1.0;
}

// ── Color palettes per mode ──
const MODE_COLORS = {
  geometric: { primary: 0x00f5ff, secondary: 0xff9f00, particle: 0x4dd0e1 },
  plasma: { primary: 0xff6b00, secondary: 0xffd700, particle: 0xff4500 },
  electromagnetic: { primary: 0x00f5ff, secondary: 0xbc8cff, particle: 0x00ddff },
  gravity: { primary: 0x4dd0e1, secondary: 0x1a73e8, particle: 0x80e0e0 },
  thermodynamics: { primary: 0xff3b30, secondary: 0x3b8bff, particle: 0xff9f00 },
};

// ── Build Calabi-Yau-like 13D projection ──
function buildCalabiYau() {
  const group = new THREE.Group();
  const segments = 64;
  // Create intersecting toroidal surfaces
  for (let s = 0; s < 5; s++) {
    const angle = (s / 5) * Math.PI * 2;
    const points = [];
    for (let i = 0; i <= segments; i++) {
      const u = (i / segments) * Math.PI * 2;
      for (let j = 0; j <= segments / 2; j++) {
        const v = (j / (segments / 2)) * Math.PI;
        const r1 = 1.8 + 0.3 * Math.cos(u * 3);
        const r2 = 1.8 + 0.3 * Math.sin(u * 2);
        const x = r1 * Math.sin(v) * Math.cos(angle);
        const y = r2 * Math.cos(v);
        const z = r1 * Math.sin(v) * Math.sin(angle);
        points.push(new THREE.Vector3(x, y, z));
      }
    }
    const geo = new THREE.BufferGeometry().setFromPoints(points);
    const mat = new THREE.PointsMaterial({ color: s % 2 === 0 ? 0x00f5ff : 0xbc8cff, size: 0.03, transparent: true, opacity: 0.6 });
    group.add(new THREE.Points(geo, mat));
  }
  // Add wireframe tori at different orientations
  for (let s = 0; s < 3; s++) {
    const torusGeo = new THREE.TorusGeometry(1.5, 0.3, 16, 64);
    const mat = new THREE.MeshBasicMaterial({ color: 0xff9f00, wireframe: true, transparent: true, opacity: 0.2 });
    const mesh = new THREE.Mesh(torusGeo, mat);
    mesh.rotation.x = (s / 3) * Math.PI;
    mesh.rotation.y = (s / 3) * Math.PI * 0.7;
    group.add(mesh);
  }
  return group;
}

// ── Build plasma current streams ──
function buildPlasmaStreams(dim) {
  const group = new THREE.Group();
  const numStreams = Math.floor(8 * dimFactor(dim));
  const colors = [0xff4500, 0xff6b00, 0xff9f00, 0xffd700, 0xffeb3b];

  for (let s = 0; s < numStreams; s++) {
    const points = [];
    const segments = 200;
    const phase = (s / numStreams) * Math.PI * 2;
    const radius = 2 + Math.sin(s * 0.7) * 0.5;
    for (let i = 0; i <= segments; i++) {
      const t = (i / segments) * Math.PI * 4;
      const x = (radius + 0.3 * Math.sin(t * 3 + phase)) * Math.cos(t + phase);
      const y = 0.5 * Math.sin(t * 5 + phase);
      const z = (radius + 0.3 * Math.cos(t * 3 + phase)) * Math.sin(t + phase);
      points.push(new THREE.Vector3(x, y, z));
    }
    const curve = new THREE.CatmullRomCurve3(points);
    const tubeGeo = new THREE.TubeGeometry(curve, 200, 0.02, 8, false);
    const color = colors[s % colors.length];
    const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.7 });
    group.add(new THREE.Mesh(tubeGeo, mat));

    // Flowing particles along the stream
    const particleCount = 50;
    const pPositions = new Float32Array(particleCount * 3);
    for (let p = 0; p < particleCount; p++) {
      const t = p / particleCount;
      const point = curve.getPoint(t);
      pPositions[p * 3] = point.x;
      pPositions[p * 3 + 1] = point.y;
      pPositions[p * 3 + 2] = point.z;
    }
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute('position', new THREE.BufferAttribute(pPositions, 3));
    const pMat = new THREE.PointsMaterial({ color, size: 0.06, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending });
    const particles = new THREE.Points(pGeo, pMat);
    particles.userData = { curve, count: particleCount, speed: 0.003 + Math.random() * 0.002 };
    group.add(particles);
  }
  return group;
}

// ── Build electromagnetic field lines ──
function buildEMField(dim) {
  const group = new THREE.Group();
  const numRings = Math.floor(6 * dimFactor(dim));
  const colors = [0x00f5ff, 0x00ddff, 0xbc8cff, 0x80c0ff];

  for (let r = 0; r < numRings; r++) {
    const ringRadius = 2 + (r - numRings / 2) * 0.15;
    const tubeRadius = 0.015;
    const torusGeo = new THREE.TorusGeometry(ringRadius, tubeRadius, 8, 128);
    const color = colors[r % colors.length];
    const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.5 });
    const mesh = new THREE.Mesh(torusGeo, mat);
    mesh.rotation.x = (r / numRings) * Math.PI;
    mesh.rotation.z = (r / numRings) * Math.PI * 0.5;
    group.add(mesh);

    // Flowing energy particles along field lines
    const particleCount = 80;
    const pPositions = new Float32Array(particleCount * 3);
    for (let p = 0; p < particleCount; p++) {
      const angle = (p / particleCount) * Math.PI * 2;
      pPositions[p * 3] = ringRadius * Math.cos(angle);
      pPositions[p * 3 + 1] = ringRadius * Math.sin(angle);
      pPositions[p * 3 + 2] = 0;
    }
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute('position', new THREE.BufferAttribute(pPositions, 3));
    const pMat = new THREE.PointsMaterial({ color, size: 0.05, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending });
    const particles = new THREE.Points(pGeo, pMat);
    particles.userData = { ringRadius, rotation: mesh.rotation, speed: 0.005 + r * 0.001 };
    group.add(particles);
  }

  // Central energy core
  const coreGeo = new THREE.SphereGeometry(0.3, 32, 32);
  const coreMat = new THREE.MeshBasicMaterial({ color: 0x00f5ff, transparent: true, opacity: 0.3 });
  group.add(new THREE.Mesh(coreGeo, coreMat));

  return group;
}

// ── Build gravity spacetime grid ──
function buildGravityGrid(dim) {
  const group = new THREE.Group();
  const gridSize = dim >= 11 ? 12 : 8;
  const divisions = dim >= 11 ? 40 : 28;
  const spacing = (gridSize * 2) / divisions;

  // Build a deformed grid (gravitational well)
  const points = [];
  const colors = [];
  const color1 = new THREE.Color(0x4dd0e1);
  const color2 = new THREE.Color(0x1a73e8);

  for (let i = 0; i <= divisions; i++) {
    for (let j = 0; j <= divisions; j++) {
      const x = -gridSize + i * spacing;
      const z = -gridSize + j * spacing;
      const dist = Math.sqrt(x * x + z * z);
      const y = -2.5 / (1 + dist * 0.3); // gravitational well curve
      points.push(new THREE.Vector3(x, y, z));
      const t = Math.min(1, dist / gridSize);
      colors.push(color1.r * (1 - t) + color2.r * t, color1.g * (1 - t) + color2.g * t, color1.b * (1 - t) + color2.b * t);
    }
  }

  // Build grid lines (X direction)
  for (let i = 0; i <= divisions; i++) {
    const linePoints = [];
    for (let j = 0; j <= divisions; j++) {
      const idx = i * (divisions + 1) + j;
      linePoints.push(points[idx]);
    }
    const geo = new THREE.BufferGeometry().setFromPoints(linePoints);
    const mat = new THREE.LineBasicMaterial({ color: 0x4dd0e1, transparent: true, opacity: 0.4 });
    group.add(new THREE.Line(geo, mat));
  }
  // Build grid lines (Z direction)
  for (let j = 0; j <= divisions; j++) {
    const linePoints = [];
    for (let i = 0; i <= divisions; i++) {
      const idx = i * (divisions + 1) + j;
      linePoints.push(points[idx]);
    }
    const geo = new THREE.BufferGeometry().setFromPoints(linePoints);
    const mat = new THREE.LineBasicMaterial({ color: 0x4dd0e1, transparent: true, opacity: 0.4 });
    group.add(new THREE.Line(geo, mat));
  }

  // Central mass
  const massGeo = new THREE.SphereGeometry(0.5, 32, 32);
  const massMat = new THREE.MeshBasicMaterial({ color: 0xff9f00, transparent: true, opacity: 0.8 });
  group.add(new THREE.Mesh(massGeo, massMat));

  // Gravitational field particles spiraling inward
  const particleCount = 300;
  const pPositions = new Float32Array(particleCount * 3);
  for (let p = 0; p < particleCount; p++) {
    const angle = Math.random() * Math.PI * 2;
    const r = 1 + Math.random() * 4;
    const x = r * Math.cos(angle);
    const z = r * Math.sin(angle);
    const y = -2.5 / (1 + r * 0.3) + 0.2;
    pPositions[p * 3] = x;
    pPositions[p * 3 + 1] = y;
    pPositions[p * 3 + 2] = z;
  }
  const pGeo = new THREE.BufferGeometry();
  pGeo.setAttribute('position', new THREE.BufferAttribute(pPositions, 3));
  const pMat = new THREE.PointsMaterial({ color: 0x80e0e0, size: 0.04, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending });
  group.add(new THREE.Points(pGeo, pMat));

  return group;
}

// ── Build thermodynamic heat flow ──
function buildThermoFlow(dim) {
  const group = new THREE.Group();
  const numFlows = Math.floor(6 * dimFactor(dim));

  for (let f = 0; f < numFlows; f++) {
    const points = [];
    const segments = 150;
    const phase = (f / numFlows) * Math.PI * 2;
    for (let i = 0; i <= segments; i++) {
      const t = (i / segments) * Math.PI * 2;
      const x = 2 * Math.cos(t + phase) * (1 + 0.3 * Math.sin(t * 4));
      const y = 1.5 * Math.sin(t * 3 + phase);
      const z = 2 * Math.sin(t + phase) * (1 + 0.3 * Math.cos(t * 4));
      points.push(new THREE.Vector3(x, y, z));
    }
    const curve = new THREE.CatmullRomCurve3(points);
    const tubeGeo = new THREE.TubeGeometry(curve, 150, 0.015, 8, true);
    // Gradient color: hot (red) to cool (blue)
    const color = new THREE.Color().setHSL(0.02 + (f / numFlows) * 0.6, 1, 0.5);
    const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.6 });
    group.add(new THREE.Mesh(tubeGeo, mat));

    // Heat particles
    const particleCount = 60;
    const pPositions = new Float32Array(particleCount * 3);
    const pColors = new Float32Array(particleCount * 3);
    for (let p = 0; p < particleCount; p++) {
      const t = p / particleCount;
      const point = curve.getPoint(t);
      pPositions[p * 3] = point.x;
      pPositions[p * 3 + 1] = point.y;
      pPositions[p * 3 + 2] = point.z;
      const heat = 1 - t; // hot at start, cool at end
      const c = new THREE.Color().setHSL(0.02 * heat, 1, 0.3 + heat * 0.4);
      pColors[p * 3] = c.r;
      pColors[p * 3 + 1] = c.g;
      pColors[p * 3 + 2] = c.b;
    }
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute('position', new THREE.BufferAttribute(pPositions, 3));
    pGeo.setAttribute('color', new THREE.BufferAttribute(pColors, 3));
    const pMat = new THREE.PointsMaterial({ size: 0.06, vertexColors: true, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending });
    const particles = new THREE.Points(pGeo, pMat);
    particles.userData = { curve, count: particleCount, speed: 0.004 + Math.random() * 0.002 };
    group.add(particles);
  }

  return group;
}

export default function AtlasViewer({ structure = 'torus', dimensions = 5, mode = 'geometric' }) {
  const mountRef = useRef(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, mount.clientWidth / mount.clientHeight, 0.1, 1000);
    camera.position.z = 7;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    mount.appendChild(renderer.domElement);

    const colors = MODE_COLORS[mode] || MODE_COLORS.geometric;
    let mainGroup = new THREE.Group();
    scene.add(mainGroup);

    // ── Build scene based on mode ──
    if (mode === 'plasma') {
      mainGroup.add(buildPlasmaStreams(dimensions));
    } else if (mode === 'electromagnetic') {
      mainGroup.add(buildEMField(dimensions));
    } else if (mode === 'gravity') {
      mainGroup.add(buildGravityGrid(dimensions));
    } else if (mode === 'thermodynamics') {
      mainGroup.add(buildThermoFlow(dimensions));
    } else {
      // geometric mode
      if (structure === 'calabi') {
        mainGroup.add(buildCalabiYau());
      } else {
        const config = STRUCTURES[structure] || STRUCTURES.torus;
        const geometry = config.geo(dimensions);
        const material = new THREE.MeshBasicMaterial({ color: colors.primary, wireframe: true, transparent: true, opacity: 0.6 });
        mainGroup.add(new THREE.Mesh(geometry, material));

        // Inner mesh for depth
        const innerMat = new THREE.MeshBasicMaterial({ color: colors.secondary, wireframe: true, transparent: true, opacity: 0.15 });
        const innerMesh = new THREE.Mesh(geometry.clone().scale(0.5, 0.5, 0.5), innerMat);
        mainGroup.add(innerMesh);

        // Dimensional rings for 5D+
        if (dimensions >= 5) {
          const numRings = Math.floor(dimensions / 2);
          for (let r = 0; r < numRings; r++) {
            const ringGeo = new THREE.TorusGeometry(2.5 + r * 0.2, 0.01, 8, 64);
            const ringMat = new THREE.MeshBasicMaterial({ color: colors.secondary, transparent: true, opacity: 0.3 });
            const ring = new THREE.Mesh(ringGeo, ringMat);
            ring.rotation.x = (r / numRings) * Math.PI;
            ring.rotation.y = (r / numRings) * Math.PI * 0.5;
            mainGroup.add(ring);
          }
        }
      }
    }

    // Ambient particles (all modes)
    const particleGeo = new THREE.BufferGeometry();
    const particleCount = 300;
    const positions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      const r = 3.5 + Math.random() * 2.5;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleMat = new THREE.PointsMaterial({ color: colors.particle, size: 0.03, transparent: true, opacity: 0.4 });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Mouse rotation
    let isDragging = false;
    let prevX = 0, prevY = 0;
    let rotX = 0.3, rotY = 0;
    let autoRot = true;

    const onMouseDown = (e) => { isDragging = true; autoRot = false; prevX = e.clientX; prevY = e.clientY; };
    const onMouseMove = (e) => {
      if (!isDragging) return;
      rotY += (e.clientX - prevX) * 0.008;
      rotX += (e.clientY - prevY) * 0.008;
      prevX = e.clientX; prevY = e.clientY;
    };
    const onMouseUp = () => { isDragging = false; };
    const onWheel = (e) => { e.preventDefault(); camera.position.z = Math.max(3, Math.min(15, camera.position.z + e.deltaY * 0.005)); };

    renderer.domElement.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    renderer.domElement.addEventListener('wheel', onWheel, { passive: false });

    let frame;
    const animate = () => {
      frame = requestAnimationFrame(animate);
      if (autoRot) rotY += 0.003;
      mainGroup.rotation.x = rotX;
      mainGroup.rotation.y = rotY;
      particles.rotation.y = rotY * 0.2;

      // Animate flowing particles in plasma/EM/thermo modes
      mainGroup.traverse((obj) => {
        if (obj.userData && obj.userData.curve && obj.userData.count) {
          const positions = obj.geometry.attributes.position.array;
          for (let p = 0; p < obj.userData.count; p++) {
            const t = ((p / obj.userData.count) + performance.now() * obj.userData.speed * 0.001) % 1;
            const point = obj.userData.curve.getPoint(t);
            positions[p * 3] = point.x;
            positions[p * 3 + 1] = point.y;
            positions[p * 3 + 2] = point.z;
          }
          obj.geometry.attributes.position.needsUpdate = true;
        }
        if (obj.userData && obj.userData.ringRadius && obj.userData.speed) {
          obj.rotation.z += obj.userData.speed;
        }
      });

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(frame);
      renderer.domElement.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      renderer.domElement.removeEventListener('wheel', onWheel);
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
      scene.traverse((obj) => {
        if (obj.geometry) obj.geometry.dispose();
        if (obj.material) { if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose()); else obj.material.dispose(); }
      });
      renderer.dispose();
    };
  }, [structure, dimensions, mode]);

  return <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />;
}