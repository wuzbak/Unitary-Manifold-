/**
 * PsicatResearchSidebar — dedicated in-page PsiCat research sidebar for Product 24.
 *
 * Mirrors the repo's browser sidebar design: active-page awareness, notebook entries,
 * remembered context, and integrity labeling that distinguishes live PsiCat responses
 * from local heuristics. Routes queries through InvokeLLM with the psicatBrowserExpert
 * system prompt — no new backend function needed.
 *
 * Distinct from the global QuantumCat overlay — this is a purpose-built product sidebar.
 */
import { useState, useRef, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { buildPsicatBrowserExpertPrompt } from '@/lib/merlinExperts/psicatBrowserExpert';
import { Sparkles, Send, Loader2, NotebookPen, MessageSquarePlus, FileText, Trash2, ShieldCheck, Zap, X, ChevronRight } from 'lucide-react';

const SECTIONS = [
  { id: 'hero', label: 'Hero · Product 24' },
  { id: 'surfaces', label: 'Three Surfaces' },
  { id: 'architecture', label: 'Architecture' },
  { id: 'integrity', label: 'Integrity Boundary' },
  { id: 'repo', label: 'Repository Links' },
];

export default function PsicatResearchSidebar({ activeSection = 'hero', onSectionChange, mobileOpen, onMobileClose }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [notebook, setNotebook] = useState([]);
  const [integrityMode, setIntegrityMode] = useState('live'); // 'live' | 'local'
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading]);

  const sendQuery = useCallback(async (query) => {
    if (!query.trim() || loading) return;
    const userMsg = { role: 'user', content: query, ts: Date.now() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);
    try {
      const systemPrompt = buildPsicatBrowserExpertPrompt();
      const contextLine = `\n\nCURRENT PAGE CONTEXT: The visitor is viewing the PsiCat Web Browser product page (Product 24), section: "${SECTIONS.find(s => s.id === activeSection)?.label || activeSection}".`;
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `${systemPrompt}${contextLine}\n\nVisitor question: ${query}\n\nRespond as PsiCat, the embedded browser research assistant. Be concise, grounded in the repository facts, and clearly label whether your answer is from live PsiCat knowledge or a local heuristic.`,
        response_json_schema: {
          type: 'object',
          properties: {
            answer: { type: 'string' },
            source_label: { type: 'string', enum: ['live-psicat', 'local-heuristic', 'remembered-context'] },
            confidence: { type: 'number' },
          },
        },
      });
      const assistantMsg = {
        role: 'assistant',
        content: res.answer || '(no response)',
        sourceLabel: res.source_label || 'live-psicat',
        confidence: res.confidence ?? null,
        ts: Date.now(),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (e) {
      setMessages((prev) => [...prev, { role: 'assistant', content: `Error: ${e.message}`, sourceLabel: 'local-heuristic', confidence: 0, ts: Date.now(), error: true }]);
    }
    setLoading(false);
  }, [activeSection, loading]);

  const handleSummarize = () => sendQuery('Summarize this product page and what PsiCat Web Browser does.');
  const handleInterrogate = () => sendQuery(`Interrogate the "${SECTIONS.find(s => s.id === activeSection)?.label}" section. What are the key claims and are they supported by the repository?`);
  const handleAddNotebook = () => {
    const lastAssistant = [...messages].reverse().find((m) => m.role === 'assistant');
    if (!lastAssistant) return;
    setNotebook((prev) => [...prev, {
      id: Date.now(),
      section: activeSection,
      content: lastAssistant.content.slice(0, 300),
      sourceLabel: lastAssistant.sourceLabel,
      ts: Date.now(),
    }]);
  };

  const sidebar = (
    <div className="flex flex-col h-full glass-strong clip-corner overflow-hidden">
      {/* Header — active page awareness + integrity label */}
      <div className="px-3 py-2.5 border-b border-[#4dd0e1]/20 bg-[#4dd0e1]/5">
        <div className="flex items-center justify-between gap-2 mb-1.5">
          <div className="flex items-center gap-1.5">
            <Sparkles size={12} className="text-[#4dd0e1]" />
            <span className="text-[10px] font-bold text-[#e6edf3] uppercase tracking-wider">PsiCat Sidebar</span>
          </div>
          {onMobileClose && (
            <button onClick={onMobileClose} className="lg:hidden text-[#484f58] hover:text-[#e6edf3]">
              <X size={14} />
            </button>
          )}
        </div>
        {/* Active page context indicator */}
        <div className="flex items-center gap-1.5 text-[9px]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] glow-pulse" />
          <span className="text-[#484f58]">Active page:</span>
          <span className="text-[#4dd0e1] font-mono">/psicat-browser</span>
        </div>
        {/* Section selector */}
        <div className="flex items-center gap-1 mt-1.5 flex-wrap">
          <span className="text-[8px] text-[#484f58]">Section:</span>
          {SECTIONS.map((s) => (
            <button
              key={s.id}
              onClick={() => onSectionChange?.(s.id)}
              className={`text-[8px] px-1.5 py-0.5 clip-corner transition-all ${activeSection === s.id ? 'bg-[#4dd0e1] text-black font-bold' : 'border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}
            >
              {s.label.split(' · ')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Integrity mode toggle */}
      <div className="px-3 py-1.5 border-b border-[#30363d] flex items-center gap-2">
        <ShieldCheck size={10} className="text-[#3fb950]" />
        <span className="text-[8px] text-[#484f58]">Integrity:</span>
        <button
          onClick={() => setIntegrityMode('live')}
          className={`text-[8px] px-1.5 py-0.5 clip-corner ${integrityMode === 'live' ? 'bg-[#FF9F00] text-black font-bold' : 'border border-[#30363d] text-[#8b949e]'}`}
        >
          Live PsiCat
        </button>
        <button
          onClick={() => setIntegrityMode('local')}
          className={`text-[8px] px-1.5 py-0.5 clip-corner ${integrityMode === 'local' ? 'bg-[#484f58] text-[#e6edf3] font-bold' : 'border border-[#30363d] text-[#8b949e]'}`}
        >
          Local heuristic
        </button>
      </div>

      {/* Quick actions */}
      <div className="px-3 py-2 border-b border-[#30363d] grid grid-cols-3 gap-1.5">
        <button onClick={handleSummarize} disabled={loading} className="flex flex-col items-center gap-0.5 py-1.5 border border-[#4dd0e1]/30 text-[#4dd0e1] hover:bg-[#4dd0e1]/10 clip-corner disabled:opacity-40 transition-all">
          <FileText size={11} />
          <span className="text-[7px] font-bold">Summarize</span>
        </button>
        <button onClick={handleInterrogate} disabled={loading} className="flex flex-col items-center gap-0.5 py-1.5 border border-[#FF9F00]/30 text-[#FF9F00] hover:bg-[#FF9F00]/10 clip-corner disabled:opacity-40 transition-all">
          <Zap size={11} />
          <span className="text-[7px] font-bold">Interrogate</span>
        </button>
        <button onClick={handleAddNotebook} disabled={loading || messages.length === 0} className="flex flex-col items-center gap-0.5 py-1.5 border border-[#3fb950]/30 text-[#3fb950] hover:bg-[#3fb950]/10 clip-corner disabled:opacity-40 transition-all">
          <NotebookPen size={11} />
          <span className="text-[7px] font-bold">Notebook</span>
        </button>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-3 py-2 space-y-2 min-h-0">
        {messages.length === 0 && (
          <div className="text-center py-6">
            <Sparkles size={18} className="text-[#4dd0e1]/40 mx-auto mb-2" />
            <p className="text-[9px] text-[#484f58] leading-relaxed">
              Ask about PsiCat Web Browser, or use the quick actions above.
              <br /><br />
              <span className="text-[#4dd0e1]/60">Integrity-first: live responses are labeled; local heuristics are clearly separated.</span>
            </p>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[88%] px-2 py-1.5 clip-corner text-[9px] leading-relaxed ${
              m.role === 'user'
                ? 'bg-[#4dd0e1]/15 border border-[#4dd0e1]/30 text-[#e6edf3]'
                : m.error
                  ? 'bg-[#f85149]/10 border border-[#f85149]/30 text-[#f85149]'
                  : 'bg-[#0d1117] border border-[#30363d] text-[#c9d1d9]'
            }`}>
              {m.role === 'assistant' && (
                <div className="flex items-center gap-1 mb-1">
                  <span className={`text-[7px] px-1 py-0.5 clip-corner font-bold ${
                    m.sourceLabel === 'live-psicat' ? 'bg-[#FF9F00]/20 text-[#FF9F00]' :
                    m.sourceLabel === 'local-heuristic' ? 'bg-[#484f58]/30 text-[#8b949e]' :
                    'bg-[#4dd0e1]/20 text-[#4dd0e1]'
                  }`}>
                    {m.sourceLabel === 'live-psicat' ? '● LIVE' : m.sourceLabel === 'local-heuristic' ? '○ LOCAL' : '◆ CONTEXT'}
                  </span>
                  {m.confidence != null && (
                    <span className="text-[7px] text-[#484f58]">conf {Math.round(m.confidence * 100)}%</span>
                  )}
                </div>
              )}
              <p className="whitespace-pre-wrap">{m.content}</p>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="px-2 py-1.5 bg-[#0d1117] border border-[#30363d] clip-corner">
              <Loader2 size={11} className="animate-spin text-[#4dd0e1]" />
            </div>
          </div>
        )}
      </div>

      {/* Notebook entries */}
      {notebook.length > 0 && (
        <div className="px-3 py-1.5 border-t border-[#30363d] max-h-24 overflow-y-auto">
          <div className="flex items-center gap-1 mb-1">
            <NotebookPen size={9} className="text-[#3fb950]" />
            <span className="text-[8px] font-bold text-[#3fb950]">NOTEBOOK ({notebook.length})</span>
            <button onClick={() => setNotebook([])} className="ml-auto text-[#484f58] hover:text-[#f85149]"><Trash2 size={9} /></button>
          </div>
          {notebook.slice(-2).map((n) => (
            <div key={n.id} className="text-[8px] text-[#8b949e] mb-0.5 truncate">
              <ChevronRight size={7} className="inline text-[#484f58]" /> {n.content}
            </div>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="px-3 py-2 border-t border-[#30363d]">
        <div className="flex items-center gap-1.5">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendQuery(input); } }}
            placeholder="Ask PsiCat…"
            className="flex-1 min-w-0 bg-[#0B0F13] border border-[#30363d] px-2 py-1.5 text-[9px] text-[#e6edf3] placeholder:text-[#484f58] focus:border-[#4dd0e1]/40 focus:outline-none clip-corner"
          />
          <button onClick={() => sendQuery(input)} disabled={loading || !input.trim()} className="p-1.5 bg-[#4dd0e1] text-black clip-corner disabled:opacity-40">
            <Send size={11} />
          </button>
        </div>
      </div>
    </div>
  );

  return sidebar;
}