import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Send, Loader2, CheckCircle } from 'lucide-react';

const STAGES = ['Conceptual', 'In Development', 'Scaling', 'Operational'];
const DOMAINS = ['Energy', 'Water Systems', 'Transit', 'Digital', 'Materials', 'Urban'];
const SCALES = ['Advisory', 'Partnership', 'Full Delivery'];

const INQUIRY_EMAIL = 'cpo@axiomzerospc.org';

export default function InquiryForm() {
  const [form, setForm] = useState({ name: '', email: '', organization: '', stage: '', domain: '', scale: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await base44.entities.Inquiry.create(form);
      try {
        await base44.integrations.Core.SendEmail({
          to: INQUIRY_EMAIL,
          subject: `New Inquiry from ${form.name} - ${form.organization || 'No Organization'}`,
          body: `New client inquiry received:\n\nName: ${form.name}\nEmail: ${form.email}\nOrganization: ${form.organization || 'N/A'}\nStage: ${form.stage}\nDomain: ${form.domain}\nScale: ${form.scale}\n\nMessage:\n${form.message || 'N/A'}`
        });
      } catch (emailErr) {
        console.warn('Email notification failed:', emailErr);
      }
      setSuccess(true);
      setForm({ name: '', email: '', organization: '', stage: '', domain: '', scale: '', message: '' });
    } catch (err) {
      setError(err.response?.data?.error || err.message || 'Failed to submit inquiry');
    }
    setLoading(false);
  };

  if (success) {
    return (
      <div className="bg-[#161b22] border border-[#30363d] rounded-lg p-6 text-center">
        <CheckCircle size={32} className="text-[#3fb950] mx-auto mb-3" />
        <h3 className="text-[#e6edf3] font-bold text-sm mb-1">Inquiry Submitted</h3>
        <p className="text-[#8b949e] text-xs mb-4">Thank you for your interest. We'll be in touch within 2 business days.</p>
        <button onClick={() => setSuccess(false)} className="text-[#58a6ff] text-xs hover:underline">Submit another inquiry</button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-[#161b22] border border-[#30363d] rounded-lg p-4 lg:p-6 space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-[#8b949e] text-xs mb-1">Name *</label>
          <input type="text" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-3 py-2.5 rounded text-sm focus:outline-none focus:border-[#58a6ff] min-h-[44px]" />
        </div>
        <div>
          <label className="block text-[#8b949e] text-xs mb-1">Email *</label>
          <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-3 py-2.5 rounded text-sm focus:outline-none focus:border-[#58a6ff] min-h-[44px]" />
        </div>
      </div>
      <div>
        <label className="block text-[#8b949e] text-xs mb-1">Organization</label>
        <input type="text" value={form.organization} onChange={(e) => setForm({ ...form, organization: e.target.value })} className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-3 py-2.5 rounded text-sm focus:outline-none focus:border-[#58a6ff] min-h-[44px]" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-[#8b949e] text-xs mb-1">Project Stage *</label>
          <select required value={form.stage} onChange={(e) => setForm({ ...form, stage: e.target.value })} className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-3 py-2.5 rounded text-sm min-h-[44px]">
            <option value="">Select…</option>
            {STAGES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-[#8b949e] text-xs mb-1">Domain *</label>
          <select required value={form.domain} onChange={(e) => setForm({ ...form, domain: e.target.value })} className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-3 py-2.5 rounded text-sm min-h-[44px]">
            <option value="">Select…</option>
            {DOMAINS.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-[#8b949e] text-xs mb-1">Engagement Scale *</label>
          <select required value={form.scale} onChange={(e) => setForm({ ...form, scale: e.target.value })} className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-3 py-2.5 rounded text-sm min-h-[44px]">
            <option value="">Select…</option>
            {SCALES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>
      <div>
        <label className="block text-[#8b949e] text-xs mb-1">Message</label>
        <textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} rows={4} className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-3 py-2.5 rounded text-sm focus:outline-none focus:border-[#58a6ff] min-h-[44px]" />
      </div>
      {error && <p className="text-[#f85149] text-xs">{error}</p>}
      <button type="submit" disabled={loading} className="flex items-center gap-2 bg-[#58a6ff] text-black px-4 py-2.5 rounded text-sm font-bold hover:opacity-80 disabled:opacity-50 min-h-[44px] w-full lg:w-auto justify-center lg:justify-start">
        {loading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />} Submit Inquiry
      </button>
    </form>
  );
}