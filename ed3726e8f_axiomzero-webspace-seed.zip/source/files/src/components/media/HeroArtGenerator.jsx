/**
 * HeroArtGenerator — AI hero art generator for Media Archive cards.
 * Builds a prompt from the media item's title + description → GenerateImage.
 * Session-scoped (no entity persistence). Consumes integration credits.
 */
import { useState } from 'react';
import { Sparkles, Download, Loader2, RotateCw, X, Image as ImageIcon } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { runMerlinImageFlow } from '@/lib/merlinContextLayer';
import MerlinContextCard from '@/components/merlin-context/MerlinContextCard';

export default function HeroArtGenerator({ media, onClose }) {
  const [prompt, setPrompt] = useState(`${media.title}. ${media.description}`);
  const [art, setArt] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState(null);
  const [merlinState, setMerlinState] = useState({ phase: 'idle' });
  const [pendingAnswers, setPendingAnswers] = useState(null);

  const handleGenerate = async (answers) => {
    if (generating) return;
    setGenerating(true);
    setError(null);
    setMerlinState({ phase: 'curating' });
    try {
      const result = await runMerlinImageFlow({
        rawPrompt: prompt.trim() || media.title,
        generatorType: 'media-heroart',
        answers: answers || pendingAnswers || undefined,
        pageContext: `Media Archive — Hero Art for "${media.title}"`,
        onStatus: (s) => setMerlinState((prev) => ({ ...prev, phase: s.phase })),
      });
      if (result.phase === 'clarify') {
        setMerlinState({ phase: 'clarify', clarifyingQuestions: result.clarifyingQuestions });
      } else if (result.phase === 'done') {
        setArt(result.imageUrl);
        setMerlinState({ phase: 'done', proof: result.proof, contextNote: result.contextNote });
      } else if (result.phase === 'error') {
        setError(result.error);
        setMerlinState({ phase: 'error', error: result.error });
      }
      setPendingAnswers(null);
    } catch (e) {
      setError(String(e?.message || e));
      setMerlinState({ phase: 'error', error: String(e?.message || e) });
    }
    setGenerating(false);
  };

  const handleAnswer = (answers) => {
    setPendingAnswers(answers);
    setMerlinState({ phase: 'idle' });
    setTimeout(() => handleGenerate(answers), 30);
  };

  const handleRecurate = (suggested) => {
    setMerlinState({ phase: 'idle' });
    setArt(null);
    setPrompt(suggested);
    setTimeout(() => handleGenerate(), 30);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-[#0d1117] border border-[#58a6ff]/30 clip-corner max-w-2xl w-full p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 mb-3">
          <Sparkles size={14} className="text-[#58a6ff]" />
          <span className="text-xs font-bold text-[#58a6ff]">Generate Hero Art</span>
          <span className="text-[8px] text-[#484f58]">· {media.title}</span>
          <button onClick={onClose} className="ml-auto text-[#8b949e] hover:text-[#e6edf3]"><X size={16} /></button>
        </div>

        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={2}
          className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2 resize-none focus:border-[#58a6ff]/40 focus:outline-none"
        />
        <button
          onClick={handleGenerate}
          disabled={generating}
          className="flex items-center gap-1.5 bg-[#58a6ff] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"
        >
          {generating ? <Loader2 size={12} className="animate-spin" /> : <ImageIcon size={12} />}
          {generating ? 'Generating hero art…' : art ? 'Regenerate' : 'Generate'}
        </button>

        {error && <div className="mt-2 text-[10px] text-[#f85149] border border-[#f85149]/30 rounded p-2">{error}</div>}

        <MerlinContextCard
          state={merlinState}
          accent="#58a6ff"
          onAnswer={handleAnswer}
          onRecurate={handleRecurate}
          onDismiss={() => setMerlinState({ phase: 'idle' })}
        />

        {art && (
          <div className="mt-3 border border-[#30363d] rounded overflow-hidden">
            <div className="aspect-video relative group">
              <img src={art} alt={media.title} className="w-full h-full object-cover" />
              <div className="absolute top-2 right-2 flex gap-1">
                <a href={art} download={`hero_${media.title.replace(/\s+/g, '_')}.png`} className="bg-[#0B0F13]/80 p-1.5 rounded hover:bg-[#3fb950]/20">
                  <Download size={12} className="text-[#3fb950]" />
                </a>
                <button onClick={handleGenerate} className="bg-[#0B0F13]/80 p-1.5 rounded hover:bg-[#58a6ff]/20">
                  <RotateCw size={12} className="text-[#58a6ff]" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}