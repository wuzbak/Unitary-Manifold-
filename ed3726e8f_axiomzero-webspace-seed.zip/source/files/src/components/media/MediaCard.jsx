import { Video, FileText, Image as ImageIcon, ExternalLink, Sparkles } from 'lucide-react';

const TYPE_ICONS = {
  video: Video,
  presentation: FileText,
  visualization: ImageIcon,
  demo: Video,
  document: FileText,
  notebook: FileText
};

const TYPE_COLORS = {
  video: 'bg-[#3a1015] text-[#f85149]',
  presentation: 'bg-[#0d2040] text-[#58a6ff]',
  visualization: 'bg-[#1a3a25] text-[#3fb950]',
  demo: 'bg-[#2a1a3a] text-[#bc8cff]',
  document: 'bg-[#3a2d0a] text-[#d29922]',
  notebook: 'bg-[#0a2a30] text-[#00f5ff]'
};

export default function MediaCard({ media, onGenerateHero }) {
  const Icon = TYPE_ICONS[media.type] || FileText;
  return (
    <div className="bg-[#161b22] border border-[#30363d] rounded-lg overflow-hidden hover:border-[#58a6ff] transition-colors group">
      <div className="aspect-video bg-[#0a0d11] flex items-center justify-center relative">
        {media.thumbnail ? (
          <img src={media.thumbnail} alt={media.title} className="w-full h-full object-cover" />
        ) : (
          <Icon size={32} className="text-[#30363d]" />
        )}
        <span className={`absolute top-2 left-2 px-2 py-0.5 rounded text-xs font-bold ${TYPE_COLORS[media.type] || 'bg-[#21262d] text-[#8b949e]'}`}>{media.type}</span>
      </div>
      <div className="p-4">
        <h3 className="text-[#e6edf3] font-bold text-sm mb-1">{media.title}</h3>
        <p className="text-[#8b949e] text-xs mb-3 leading-relaxed">{media.description}</p>
        <div className="flex items-center gap-3">
          <a href={media.url} target={media.internal ? undefined : '_blank'} rel={media.internal ? undefined : 'noopener noreferrer'} className="flex items-center gap-1 text-[#58a6ff] text-xs hover:underline">
            <ExternalLink size={12} /> {media.action || 'View'}
          </a>
          {onGenerateHero && (
            <button onClick={() => onGenerateHero(media)} className="flex items-center gap-1 text-[#bc8cff] text-xs hover:underline ml-auto">
              <Sparkles size={12} /> Hero Art
            </button>
          )}
        </div>
      </div>
    </div>
  );
}