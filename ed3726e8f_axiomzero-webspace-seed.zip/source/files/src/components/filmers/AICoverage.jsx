import { useState } from 'react';
import { Sparkles, Loader2, Camera } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { SCENE_TYPES } from '@/lib/filmers/filmEngine';
import { merlinCuratePrompt, MERLIN_AVATAR } from '@/lib/merlinContextLayer';

/**
 * AICoverage — AI coverage suggestions for a scene synopsis + type.
 * Routes through Merlin's intent layer to curate the coverage prompt before
 * InvokeLLM, so the shot suggestions match the scene's actual intent.
 */
export default function AICoverage({ synopsis, sceneType }) {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [merlinNote, setMerlinNote] = useState('');
  const [merlinPhase, setMerlinPhase] = useState('idle');

  const suggest = async () => {
    if (!synopsis.trim()) return;
    setLoading(true); setError(null);
    setMerlinPhase('curating');
    setMerlinNote('');
    try {
      // Merlin intent layer: curate the coverage request
      const curation = await merlinCuratePrompt({
        rawPrompt: `Suggest shot coverage for a ${sceneType} scene. Synopsis: "${synopsis}"`,
        generatorType: 'filmers-coverage',
        pageContext: `Filmer's Companion — AI Coverage (${sceneType})`,
      });
      const curated = curation.status === 'curated' && curation.curated_prompt
        ? curation.curated_prompt
        : `You are an expert cinematographer. Suggest shot coverage for this ${sceneType} scene. Synopsis: "${synopsis}"`;
      if (curation.context_note) setMerlinNote(curation.context_note);
      setMerlinPhase('generating');
      const fullPrompt = `You are an expert cinematographer. ${curated} Return a JSON array of 4-6 shots, each with coverage_type (master, MS, CU, BCU, OTS, POV, insert, cutaway, aerial, or dolly), lens (e.g. "35mm"), movement (e.g. "static", "handheld", "slow dolly"), and notes (one sentence rationale).`;
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: fullPrompt, response_json_schema: { type: 'object', properties: { shots: { type: 'array', items: { type: 'object', properties: { coverage_type: { type: 'string' }, lens: { type: 'string' }, movement: { type: 'string' }, notes: { type: 'string' } } } } } },
      });
      setResult(res?.shots || []);
      setMerlinPhase('idle');
    } catch (e) { setError(String(e?.message || e)); setMerlinPhase('idle'); }
    setLoading(false);
  };

  return (
    <div className="glass-panel clip-corner p-3">
      <div className="flex items-center gap-2 mb-2">
        <Sparkles size={13} className="text-[#fbbf24]" />
        <span className="text-[11px] font-bold text-[#fbbf24]">AI Coverage Suggestions</span>
        <span className="text-[8px] text-[#484f58] ml-auto">InvokeLLM</span>
      </div>
      <button onClick={suggest} disabled={!synopsis.trim() || loading} className="flex items-center gap-1.5 bg-[#fbbf24]/20 border border-[#fbbf24]/40 text-[#fbbf24] px-3 py-1.5 rounded text-[11px] font-bold hover:bg-[#fbbf24]/30 disabled:opacity-40">
        {loading ? <Loader2 size={12} className="animate-spin" /> : <Camera size={12} />} {loading ? 'Suggesting…' : 'Suggest Coverage'}
      </button>
      {error && <div className="mt-2 text-[10px] text-[#f85149] border border-[#f85149]/30 rounded p-2">{error}</div>}

      {(merlinPhase === 'curating' || merlinNote) && (
        <div className="mt-2 flex items-start gap-2 glass-panel clip-corner p-2" style={{ borderColor: '#fbbf2440' }}>
          <img src={MERLIN_AVATAR} alt="Merlin" className="w-5 h-5 rounded-full shrink-0" />
          <div className="min-w-0">
            <span className="text-[9px] font-bold uppercase tracking-wider text-[#fbbf24]">Merlin Intent Layer</span>
            {merlinPhase === 'curating' ? (
              <p className="text-[10px] text-[#8b949e] flex items-center gap-1.5">
                <Loader2 size={10} className="animate-spin" /> Reading scene intent…
              </p>
            ) : merlinNote ? (
              <p className="text-[10px] text-[#8b949e] italic leading-relaxed">{merlinNote}</p>
            ) : null}
          </div>
        </div>
      )}

      {result && (
        <div className="mt-2 space-y-1.5">
          {result.map((s, i) => (
            <div key={i} className="border border-[#30363d] rounded p-2">
              <div className="flex items-center gap-2">
                <span className="text-[9px] bg-[#fbbf24]/20 text-[#fbbf24] px-1.5 py-0.5 rounded font-bold">{s.coverage_type}</span>
                <span className="text-[9px] text-[#8b949e]">{s.lens} · {s.movement}</span>
              </div>
              <p className="text-[10px] text-[#e6edf3] mt-1">{s.notes}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}