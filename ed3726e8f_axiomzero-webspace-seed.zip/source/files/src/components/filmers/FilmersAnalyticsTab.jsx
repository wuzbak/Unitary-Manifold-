/**
 * FilmersAnalyticsTab — In-browser SQL analytics for the Filmer's Companion.
 *
 * Wraps DuckDBAnalyticsPanel with an entity selector for film production data.
 * Lets the user run SQL across projects, scenes, cast, crew, time cards, and
 * department items — all client-side via DuckDB-WASM. Includes Parquet
 * export/import for cross-suite columnar data sharing.
 */
import { useState } from 'react';
import DuckDBAnalyticsPanel from '@/components/compute-stack/DuckDBAnalyticsPanel';
import ParquetExportImport from '@/components/compute-stack/ParquetExportImport';
import { Database } from 'lucide-react';

const ENTITIES = [
  {
    name: 'FilmProject',
    label: 'Projects',
    defaultSql: 'SELECT status, COUNT(*) as count, SUM(total_budget) as total_budget FROM records GROUP BY status ORDER BY total_budget DESC',
  },
  {
    name: 'Scene',
    label: 'Scenes',
    defaultSql: 'SELECT int_ext, day_night, COUNT(*) as count, SUM(CASE WHEN pages != \'\' THEN CAST(pages AS DOUBLE) ELSE 0 END) as total_pages FROM records GROUP BY int_ext, day_night',
  },
  {
    name: 'CastMember',
    label: 'Cast',
    defaultSql: 'SELECT sag_status, COUNT(*) as count, AVG(day_rate) as avg_rate FROM records GROUP BY sag_status',
  },
  {
    name: 'CrewMember',
    label: 'Crew',
    defaultSql: 'SELECT department, COUNT(*) as count, AVG(day_rate) as avg_rate FROM records GROUP BY department ORDER BY count DESC',
  },
  {
    name: 'TimeCard',
    label: 'Time Cards',
    defaultSql: 'SELECT department, SUM(regular_hours) as reg_hours, SUM(ot_hours) as ot_hours, SUM(total_pay) as total_pay FROM records GROUP BY department ORDER BY total_pay DESC',
  },
  {
    name: 'DepartmentItem',
    label: 'Dept Items',
    defaultSql: 'SELECT department, status, COUNT(*) as count, SUM(quantity * unit_cost) as total_value FROM records GROUP BY department, status',
  },
];

export default function FilmersAnalyticsTab({ project }) {
  const [entity, setEntity] = useState(ENTITIES[0]);

  return (
    <div className="space-y-4">
      <div className="glass-panel clip-corner p-3">
        <div className="flex items-center gap-2 mb-2">
          <Database size={14} className="text-[#4dd0e1]" />
          <span className="text-xs font-bold text-[#e6edf3]">In-Browser Analytics — DuckDB-WASM + Arrow + Parquet</span>
        </div>
        <p className="text-[10px] text-[#8b949e] mb-3 leading-relaxed">
          Run SQL analytics across your production data client-side — no server round-trips. Powered by DuckDB-WASM (embedded OLAP), Apache Arrow (zero-copy columnar), and Parquet (compressed export/import).
          {project ? ` Project: ${project.title}` : ' Studio-wide (all projects).'}
        </p>
        <div className="flex flex-wrap gap-1.5">
          {ENTITIES.map(e => (
            <button
              key={e.name}
              onClick={() => setEntity(e)}
              className={`px-3 py-1.5 text-[10px] font-bold clip-corner transition-all ${
                entity.name === e.name
                  ? 'text-black'
                  : 'bg-[#0d1117] text-[#8b949e] border border-[#30363d] hover:text-[#e6edf3]'
              }`}
              style={entity.name === e.name ? { background: '#4dd0e1' } : {}}
            >
              {e.label}
            </button>
          ))}
        </div>
      </div>

      <DuckDBAnalyticsPanel
        key={entity.name}
        entityName={entity.name}
        accent="#4dd0e1"
        defaultSql={entity.defaultSql}
      />
      <ParquetExportImport entityName={entity.name} accent="#4dd0e1" />
    </div>
  );
}