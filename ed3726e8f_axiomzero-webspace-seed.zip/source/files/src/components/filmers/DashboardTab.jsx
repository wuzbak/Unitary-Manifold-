/**
 * DashboardTab — Enhanced Producer Dashboard with live recharts visualizations.
 * Pulls from all project entities: scenes, locations, shots, cast, crew, department items.
 * NEW: Budget-by-department bar chart, live activity feed, cast/crew status pipeline.
 */
import { useState, useEffect } from 'react';
import { FileText, MapPin, Camera, Sparkles, DollarSign, Calendar, ArrowRight, Loader2, Users, Package, TrendingUp, AlertTriangle } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, RadarChart, Radar, PolarGrid, PolarAngleAxis, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { base44 } from '@/api/base44Client';
import { DEPARTMENTS, STATUS_COLORS, STATUS_ORDER, DEPARTMENT_BUDGET_WEIGHTS, PROCUREMENT_STATUS_COLORS, PROCUREMENT_STATUS_ORDER } from '@/lib/filmers/departments';
import { buildBudget, BUDGET_ALLOCATION_DEFAULTS } from '@/lib/filmers/filmEngine';
import ActivityFeed from './ActivityFeed';
import StatusPipeline from './StatusPipeline';

const CHART_STYLE = { fontSize: '9px', fill: '#8b949e' };

export default function DashboardTab({ project, onNavigate }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    (async () => {
      setLoading(true);
      if (!project) { setLoading(false); return; }
      try {
        const [scenes, locations, shots, panels, cast, crew, items] = await Promise.all([
          base44.entities.Scene.filter({ project_id: project.id }),
          base44.entities.Location.filter({ project_id: project.id }),
          base44.entities.Shot.filter({ project_id: project.id }),
          base44.entities.StoryboardPanel.filter({ project_id: project.id }),
          base44.entities.CastMember.filter({ project_id: project.id }),
          base44.entities.CrewMember.filter({ project_id: project.id }),
          base44.entities.DepartmentItem.filter({ project_id: project.id }),
        ]);
        setData({ scenes, locations, shots, panels, cast, crew, items });
      } finally { setLoading(false); }
    })();
  }, [project?.id, refreshKey]);

  if (loading) return <div className="flex items-center justify-center py-12 text-[#484f58]"><Loader2 className="animate-spin" size={18} /></div>;
  if (!project) return (
    <div className="glass-panel clip-corner p-8 text-center">
      <Package size={28} className="text-[#484f58] mx-auto mb-3" />
      <p className="text-xs text-[#8b949e] mb-4">Select or create a project from the dropdown above to view the producer dashboard.</p>
      <button onClick={() => onNavigate('projects')} className="px-4 py-2 bg-[#fbbf24] text-black rounded text-xs font-bold hover:opacity-80 transition-opacity">
        Go to Projects →
      </button>
    </div>
  );
  if (!data) return null;

  const { scenes, locations, shots, panels, cast, crew, items } = data;

  // Budget chart (by category)
  let budgetData = [];
  try {
    const overrides = JSON.parse(project.budget_overrides_json || '{}');
    budgetData = buildBudget(project.total_budget || 1000000, overrides).map(b => ({ name: b.category.replace(/_/g, ' ').slice(0, 12), amount: b.amount, pct: b.pct }));
  } catch { budgetData = Object.entries(BUDGET_ALLOCATION_DEFAULTS).map(([k, v]) => ({ name: k.replace(/_/g, ' ').slice(0, 12), amount: Math.round((project.total_budget || 1000000) * v.pct / 100), pct: v.pct })); }

  // Budget by department (allocated vs actual spent)
  const totalBudget = project.total_budget || 0;
  const deptBudgetData = DEPARTMENTS.map(d => {
    const allocated = Math.round(totalBudget * (DEPARTMENT_BUDGET_WEIGHTS[d.key] || 0) / 100);
    const deptItems = items.filter(i => i.department === d.key);
    const actualSpent = deptItems.reduce((sum, i) => sum + (i.unit_cost || 0) * (i.quantity || 1), 0);
    return { name: d.key.split(' ')[0], allocated, spent: actualSpent, color: d.color };
  }).filter(d => d.allocated > 0 || d.spent > 0);

  // Scene coverage pie
  const coverageTypes = ['master', 'MS', 'CU', 'BCU', 'OTS', 'POV', 'insert', 'cutaway', 'aerial', 'dolly'];
  const coverageData = coverageTypes.map(t => ({ name: t, value: shots.filter(s => s.coverage_type === t).length })).filter(d => d.value > 0);

  // Department readiness radar
  const radarData = DEPARTMENTS.map(d => {
    const deptItems = items.filter(i => i.department === d.key);
    const ready = deptItems.filter(i => {
      const ps = i.procurement_status || i.status;
      return ps === 'received' || ps === 'ready' || ps === 'on-set';
    }).length;
    const total = deptItems.length || 1;
    return { department: d.key.split(' ')[0], readiness: Math.round((ready / total) * 100), items: deptItems.length };
  }).filter(d => d.items > 0);

  // Cast summary
  const sagBreakdown = ['SAG-AFTRA', 'Non-Union', 'Fi-Core', 'Pending'].map(s => ({ name: s, value: cast.filter(c => c.sag_status === s).length })).filter(d => d.value > 0);
  const COVERAGE_COLORS = ['#fbbf24', '#a78bfa', '#34d399', '#f472b6', '#22d3ee', '#facc15', '#fb923c', '#f87171', '#58a6ff', '#2dd4bf'];
  const SAG_COLORS = { 'SAG-AFTRA': '#fbbf24', 'Non-Union': '#8b949e', 'Fi-Core': '#f472b6', 'Pending': '#f85149' };

  const cards = [
    { label: 'Scenes', value: scenes.length, icon: FileText, color: '#a78bfa', tab: 'script' },
    { label: 'Locations', value: locations.length, icon: MapPin, color: '#34d399', tab: 'locations' },
    { label: 'Shots', value: shots.length, icon: Camera, color: '#fbbf24', tab: 'cinematography' },
    { label: 'Cast', value: cast.length, icon: Users, color: '#fbbf24', tab: 'cast' },
    { label: 'Crew', value: crew.length, icon: Users, color: '#58a6ff', tab: 'crew' },
    { label: 'Dept Items', value: items.length, icon: Package, color: '#34d399', tab: 'props' },
    { label: 'Panels', value: panels.length, icon: Sparkles, color: '#fbbf24', tab: 'storyboard' },
    { label: 'Budget', value: `$${(project.total_budget || 0).toLocaleString()}`, icon: DollarSign, color: '#60a5fa', tab: 'finance' },
  ];

  const quick = [
    { label: 'Import a script', icon: FileText, tab: 'script', color: '#a78bfa' },
    { label: 'Build a budget', icon: DollarSign, tab: 'finance', color: '#60a5fa' },
    { label: 'Generate storyboard', icon: Sparkles, tab: 'storyboard', color: '#fbbf24' },
    { label: 'Plan the day', icon: Calendar, tab: 'ad_suite', color: '#f472b6' },
    { label: 'Add cast member', icon: Users, tab: 'cast', color: '#fbbf24' },
    { label: 'Track props', icon: Package, tab: 'props', color: '#fbbf24' },
  ];

  const hasMaster = shots.some(s => s.coverage_type === 'master');
  const missingCoverage = !hasMaster && scenes.length > 0;

  // Budget alerts for departments
  const budgetAlerts = deptBudgetData.filter(d => d.allocated > 0 && d.spent > d.allocated * 0.8).map(d => ({
    dept: d.name, spent: d.spent, allocated: d.allocated, pct: Math.round((d.spent / d.allocated) * 100),
  }));

  return (
    <div className="space-y-4">
      {/* Synopsis + stat cards */}
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center justify-between mb-1">
          <h2 className="text-sm font-bold text-[#e6edf3]">Producer Dashboard</h2>
          <button onClick={() => setRefreshKey(k => k + 1)} className="text-[9px] text-[#8b949e] hover:text-[#fbbf24] transition-colors flex items-center gap-1">
            <TrendingUp size={10} /> Refresh
          </button>
        </div>
        <p className="text-[10px] text-[#8b949e] mb-4">{project.synopsis || 'No synopsis — add one from the project library.'}</p>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {cards.map((c) => (
            <div key={c.label} className="glass-panel clip-corner p-3 glow-hover cursor-pointer" onClick={() => onNavigate(c.tab)}>
              <div className="flex items-center justify-between mb-2">
                <c.icon size={14} style={{ color: c.color }} />
                <ArrowRight size={11} className="text-[#484f58]" />
              </div>
              <div className="text-xl font-bold" style={{ color: c.color }}>{c.value}</div>
              <div className="text-[9px] text-[#8b949e] uppercase tracking-wider">{c.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Alerts */}
      {(missingCoverage || budgetAlerts.length > 0) && (
        <div className="space-y-2">
          {missingCoverage && (
            <div className="glass-panel clip-corner p-3 border-l-2 border-[#f85149] flex items-center gap-2">
              <AlertTriangle size={14} className="text-[#f85149]" />
              <span className="text-[10px] text-[#f85149] font-bold">No master shots detected — editorial risk. Add master coverage in Cinematography.</span>
            </div>
          )}
          {budgetAlerts.map((a, i) => (
            <div key={i} className="glass-panel clip-corner p-3 border-l-2 border-[#fbbf24] flex items-center gap-2">
              <AlertTriangle size={14} className="text-[#fbbf24]" />
              <span className="text-[10px] text-[#fbbf24] font-bold">{a.dept} department at {a.pct}% of allocated budget (${a.spent.toLocaleString()} / ${a.allocated.toLocaleString()})</span>
            </div>
          ))}
        </div>
      )}

      {/* Budget by department — NEW */}
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><Package size={12} className="text-[#34d399]" /><span className="text-[10px] font-bold text-[#34d399] uppercase tracking-wider">Budget by Department — Allocated vs Spent</span></div>
        {deptBudgetData.length > 0 ? (
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={deptBudgetData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
              <XAxis dataKey="name" tick={CHART_STYLE} angle={-35} textAnchor="end" height={60} />
              <YAxis tick={CHART_STYLE} tickFormatter={v => `$${(v / 1000).toFixed(0)}K`} />
              <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #30363d', borderRadius: 4, fontSize: 10 }} formatter={(v, name) => [`${name}: $${v.toLocaleString()}`, name === 'allocated' ? 'Allocated' : 'Spent']} />
              <Bar dataKey="allocated" fill="#30363d" radius={[2, 2, 0, 0]} name="allocated" />
              <Bar dataKey="spent" fill="#34d399" radius={[2, 2, 0, 0]} name="spent" />
            </BarChart>
          </ResponsiveContainer>
        ) : <div className="text-center py-12 text-[10px] text-[#484f58] italic">Set a total budget in Finance to see department allocations.</div>}
      </div>

      {/* Activity feed + Status pipeline — NEW side-by-side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <ActivityFeed projectId={project.id} refreshKey={refreshKey} />
        <StatusPipeline cast={cast} crew={crew} />
      </div>

      {/* Charts grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Budget allocation by category */}
        <div className="glass-strong clip-corner p-4">
          <div className="flex items-center gap-2 mb-3"><DollarSign size={12} className="text-[#60a5fa]" /><span className="text-[10px] font-bold text-[#60a5fa] uppercase tracking-wider">Budget Allocation (Category)</span></div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={budgetData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
              <XAxis dataKey="name" tick={CHART_STYLE} angle={-35} textAnchor="end" height={60} />
              <YAxis tick={CHART_STYLE} tickFormatter={v => `$${(v / 1000).toFixed(0)}K`} />
              <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #30363d', borderRadius: 4, fontSize: 10 }} />
              <Bar dataKey="amount" fill="#60a5fa" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Scene coverage */}
        <div className="glass-strong clip-corner p-4">
          <div className="flex items-center gap-2 mb-3"><Camera size={12} className="text-[#fbbf24]" /><span className="text-[10px] font-bold text-[#fbbf24] uppercase tracking-wider">Scene Coverage</span></div>
          {coverageData.length ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={coverageData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label={({ name, value }) => `${name}: ${value}`} labelLine={false} tick={CHART_STYLE}>
                  {coverageData.map((_, i) => <Cell key={i} fill={COVERAGE_COLORS[i % COVERAGE_COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #30363d', borderRadius: 4, fontSize: 10 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <div className="text-center py-12 text-[10px] text-[#484f58] italic">No shots yet. Add coverage in Cinematography.</div>}
        </div>

        {/* Department readiness */}
        <div className="glass-strong clip-corner p-4">
          <div className="flex items-center gap-2 mb-3"><Package size={12} className="text-[#34d399]" /><span className="text-[10px] font-bold text-[#34d399] uppercase tracking-wider">Department Readiness</span></div>
          {radarData.length ? (
            <ResponsiveContainer width="100%" height={200}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="#30363d" />
                <PolarAngleAxis dataKey="department" tick={CHART_STYLE} />
                <Radar dataKey="readiness" stroke="#34d399" fill="#34d399" fillOpacity={0.3} />
                <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #30363d', borderRadius: 4, fontSize: 10 }} />
              </RadarChart>
            </ResponsiveContainer>
          ) : <div className="text-center py-12 text-[10px] text-[#484f58] italic">No department items yet. Add items in department tabs.</div>}
        </div>

        {/* Cast SAG breakdown */}
        <div className="glass-strong clip-corner p-4">
          <div className="flex items-center gap-2 mb-3"><Users size={12} className="text-[#fbbf24]" /><span className="text-[10px] font-bold text-[#fbbf24] uppercase tracking-wider">Cast Union Status</span></div>
          {sagBreakdown.length ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={sagBreakdown} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label={({ name, value }) => `${name}: ${value}`} labelLine={false}>
                  {sagBreakdown.map(d => <Cell key={d.name} fill={SAG_COLORS[d.name]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #30363d', borderRadius: 4, fontSize: 10 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <div className="text-center py-12 text-[10px] text-[#484f58] italic">No cast members yet. Add cast in the Cast tab.</div>}
        </div>
      </div>

      {/* Quick actions */}
      <div className="glass-panel clip-corner p-4">
        <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-3">Quick Actions</div>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
          {quick.map((q) => (
            <button key={q.label} onClick={() => onNavigate(q.tab)} className="flex items-center gap-2 p-3 border border-[#30363d] rounded hover:border-[#fbbf24]/40 transition-colors text-left">
              <q.icon size={14} style={{ color: q.color }} />
              <span className="text-[11px] text-[#e6edf3] font-bold">{q.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}