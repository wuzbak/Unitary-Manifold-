/**
 * LocationsTab — Location management with full CRUD, CSV import/export, scout reports, and detail drawer.
 */
import { useState, useEffect } from 'react';
import { MapPin, Plus, Trash2, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { PERMIT_STATUSES, generateScoutReport } from '@/lib/filmers/filmEngine';
import { exportPDF, exportTXT, exportCSV } from '@/lib/filmers/filmExport';
import { readCSVFile, coerceValue } from '@/lib/filmers/csvImport';
import { logActivity } from '@/lib/filmers/activityLog';
import ImportExportBar from './ImportExportBar';
import EntityDetailDrawer from './EntityDetailDrawer';
import PermitTrackerPanel from './PermitTrackerPanel';
import DualEntryToggle, { resolveProjectId } from './DualEntryToggle';

const PERMIT_COLOR = { confirmed: '#3fb950', pending: '#d29922', rejected: '#f85149', expired: '#8b949e' };

const FIELDS = [
  { key: 'name', label: 'Location Name', type: 'text', required: true },
  { key: 'address', label: 'Address', type: 'text' },
  { key: 'permit_status', label: 'Permit Status', type: 'select', options: PERMIT_STATUSES },
  { key: 'permit_fee', label: 'Permit Fee', type: 'text' },
  { key: 'electrical', label: 'Electrical', type: 'text' },
  { key: 'sound', label: 'Sound', type: 'text' },
  { key: 'parking', label: 'Parking', type: 'text' },
  { key: 'owner', label: 'Owner', type: 'text' },
  { key: 'access_notes', label: 'Access Notes', type: 'textarea' },
];

export default function LocationsTab({ project }) {
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: '', address: '', permit_status: 'pending', permit_fee: '', electrical: '', sound: '', parking: '', owner: '', access_notes: '' });
  const [report, setReport] = useState(null);
  const [drawer, setDrawer] = useState({ open: false, entity: null });
  const [entryMode, setEntryMode] = useState(project ? 'project' : 'studio');

  const load = async () => { setLoading(true); try { setLocations(project ? await base44.entities.Location.filter({ project_id: project.id }) : await base44.entities.Location.list('-created_date', 500).then((all) => all.filter((l) => !l.project_id))); } finally { setLoading(false); } };
  useEffect(() => { load(); }, [project?.id]);

  const add = async () => {
    if (!form.name.trim()) return;
    const pid = resolveProjectId(entryMode, project);
    const loc = await base44.entities.Location.create({ ...form, project_id: pid });
    setLocations([...locations, loc]);
    logActivity(project?.id || '', 'location', form.name, 'created');
    setForm({ name: '', address: '', permit_status: 'pending', permit_fee: '', electrical: '', sound: '', parking: '', owner: '', access_notes: '' });
  };
  const del = async (id) => {
    const loc = locations.find((l) => l.id === id);
    await base44.entities.Location.delete(id);
    setLocations(locations.filter((l) => l.id !== id));
    if (loc) logActivity(project?.id || '', 'location', loc.name, 'deleted');
    setDrawer({ open: false, entity: null });
  };
  const save = async (id, formData) => {
    await base44.entities.Location.update(id, formData);
    setLocations(locations.map((l) => l.id === id ? { ...l, ...formData } : l));
    logActivity(project?.id || '', 'location', formData.name || '', 'updated');
  };

  const doExport = () => {
    exportCSV(locations.map((l) => ({ name: l.name, address: l.address, permit_status: l.permit_status, permit_fee: l.permit_fee, electrical: l.electrical, sound: l.sound, parking: l.parking, owner: l.owner, access_notes: l.access_notes })), 'locations.csv');
  };

  const doImportCSV = async (file) => {
    const rows = await readCSVFile(file);
    const pid = resolveProjectId(entryMode, project);
    const records = rows.map((row) => {
      const obj = { project_id: pid };
      FIELDS.forEach((f) => {
        const val = coerceValue(row[f.key], f.type);
        if (val !== undefined) obj[f.key] = val;
      });
      return obj;
    }).filter((r) => r.name);
    if (records.length) await base44.entities.Location.bulkCreate(records);
    await load();
    logActivity(project?.id || '', 'location', `${records.length} locations`, 'created', 'CSV import');
  };

  return (
    <div className="space-y-4">
      {/* Add form */}
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><MapPin size={14} className="text-[#34d399]" /><span className="text-xs font-bold text-[#34d399]">Add Location</span></div>
        <DualEntryToggle mode={entryMode} onChange={setEntryMode} projectName={project?.title} />
        <div className="space-y-2">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Location name *" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Address" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <div className="grid grid-cols-2 gap-2">
            <select value={form.permit_status} onChange={(e) => setForm({ ...form, permit_status: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]">
              {PERMIT_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
            <input type="number" value={form.permit_fee} onChange={(e) => setForm({ ...form, permit_fee: e.target.value })} placeholder="Permit fee $" className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          </div>
          <input value={form.electrical} onChange={(e) => setForm({ ...form, electrical: e.target.value })} placeholder="Electrical capacity" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <input value={form.sound} onChange={(e) => setForm({ ...form, sound: e.target.value })} placeholder="Sound environment" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <input value={form.parking} onChange={(e) => setForm({ ...form, parking: e.target.value })} placeholder="Parking / base camp" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <input value={form.owner} onChange={(e) => setForm({ ...form, owner: e.target.value })} placeholder="Owner contact" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <textarea value={form.access_notes} onChange={(e) => setForm({ ...form, access_notes: e.target.value })} placeholder="Access notes" rows={2} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] resize-none" />
          <button onClick={add} disabled={!form.name.trim()} className="flex items-center gap-1.5 bg-[#34d399] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"><Plus size={12} /> Add Location</button>
        </div>
      </div>

      {/* Locations list */}
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
          <div className="text-[10px] text-[#8b949e] uppercase tracking-wider">Locations ({locations.length})</div>
          <ImportExportBar onImportCSV={doImportCSV} onExportCSV={doExport} accent="#34d399" disabled={!locations.length} />
        </div>
        {loading ? <div className="flex justify-center py-6"><Loader2 className="animate-spin text-[#484f58]" size={16} /></div> : !locations.length ? (
          <p className="text-[11px] text-[#8b949e] italic text-center py-4">No locations added yet. Add one above or import a CSV.</p>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {locations.map((loc) => (
              <div key={loc.id} className="border border-[#30363d] rounded p-2 cursor-pointer hover:border-[#34d399]/40 transition-colors" onClick={() => setDrawer({ open: true, entity: loc })}>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-[#e6edf3]">{loc.name}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded font-bold" style={{ color: PERMIT_COLOR[loc.permit_status], border: `1px solid ${PERMIT_COLOR[loc.permit_status]}40` }}>{loc.permit_status}</span>
                  <div className="ml-auto flex gap-1">
                    <button onClick={(e) => { e.stopPropagation(); setReport(generateScoutReport(loc)); }} className="text-[10px] bg-[#34d399]/10 border border-[#34d399]/30 text-[#34d399] px-2 py-1 rounded hover:bg-[#34d399]/20">Scout</button>
                  </div>
                </div>
                {loc.address && <p className="text-[10px] text-[#8b949e] mt-1">{loc.address}</p>}
              </div>
            ))}
          </div>
        )}
        {report && (
          <div className="mt-3">
            <div className="flex gap-2 mb-2">
              <button onClick={() => exportPDF('Location Scout Report', report, 'scout_report.pdf')} className="flex items-center gap-1 text-[10px] text-[#3fb950] hover:underline">PDF</button>
              <button onClick={() => exportTXT(report, 'scout_report.txt')} className="flex items-center gap-1 text-[10px] text-[#3fb950] hover:underline">TXT</button>
            </div>
            <pre className="text-[10px] text-[#e6edf3] whitespace-pre-wrap bg-[#0B0F13] border border-[#30363d] rounded p-2 max-h-48 overflow-y-auto">{report}</pre>
          </div>
        )}
      </div>

      <EntityDetailDrawer
        open={drawer.open}
        entity={drawer.entity}
        entityName="Location"
        fields={FIELDS}
        accent="#34d399"
        onClose={() => setDrawer({ open: false, entity: null })}
        onSave={save}
        onDelete={del}
        exportRows={(entity) => [{ name: entity.name, address: entity.address, permit_status: entity.permit_status, permit_fee: entity.permit_fee, electrical: entity.electrical, sound: entity.sound, parking: entity.parking, owner: entity.owner, access_notes: entity.access_notes }]}
        exportFilename={`location_${drawer.entity?.name || 'item'}.csv`}
      />

      {/* Permit Tracker */}
      <PermitTrackerPanel project={project} />
    </div>
  );
}