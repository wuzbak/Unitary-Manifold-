/**
 * BookReader — Founding Fathers-style book reproduction with TOC navigation.
 * Fetches markdown from URL, parses into chapters by headers, progressive loading.
 */
import { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import { BookOpen, Loader2, ChevronRight } from 'lucide-react';

const VISIBLE_CHUNK = 3;

function parseChapters(markdown) {
  const lines = markdown.split('\n');
  const chapters = [];
  let current = null;
  let partTitle = '';

  for (const line of lines) {
    if (line.startsWith('# ')) {
      // Book title — skip, it's the header
      continue;
    }
    if (line.startsWith('## PART')) {
      partTitle = line.replace(/^##\s+/, '');
      if (current) { chapters.push(current); current = null; }
      chapters.push({ type: 'part', title: partTitle, body: '' });
      continue;
    }
    if (line.startsWith('## ')) {
      if (current) chapters.push(current);
      current = { type: 'chapter', title: line.replace(/^##\s+/, ''), body: '', part: partTitle };
      continue;
    }
    if (current) {
      current.body += line + '\n';
    }
  }
  if (current) chapters.push(current);
  return chapters;
}

export default function BookReader({ bookUrl, bookTitle, bookSubtitle, accent = '#fbbf24' }) {
  const [chapters, setChapters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [visibleCount, setVisibleCount] = useState(VISIBLE_CHUNK);
  const [activeChapter, setActiveChapter] = useState(0);
  const contentRef = useRef(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(bookUrl);
        const text = await res.text();
        setChapters(parseChapters(text));
      } catch (e) {
        setChapters([{ type: 'chapter', title: 'Error', body: `Failed to load: ${e.message}` }]);
      } finally { setLoading(false); }
    })();
  }, [bookUrl]);

  const loadMore = () => setVisibleCount(c => Math.min(c + VISIBLE_CHUNK, chapters.length));

  const scrollToChapter = (idx) => {
    const chapterElements = contentRef.current?.querySelectorAll('[data-chapter-idx]');
    chapterElements?.[idx]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setActiveChapter(idx);
  };

  if (loading) return <div className="flex justify-center py-16"><Loader2 className="animate-spin text-[#fbbf24]" size={24} /></div>;

  const chapterList = chapters.filter(c => c.type === 'chapter');
  const visible = chapters.slice(0, visibleCount);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[200px_1fr] gap-4">
      {/* Sticky TOC */}
      <div className="lg:sticky lg:top-14 h-fit">
        <div className="glass-strong clip-corner p-3 max-h-[70vh] overflow-y-auto">
          <div className="flex items-center gap-2 mb-3">
            <BookOpen size={12} style={{ color: accent }} />
            <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: accent }}>Contents</span>
          </div>
          <nav className="space-y-0.5">
            {chapterList.map((ch, idx) => {
              const chapterIdx = chapters.indexOf(ch);
              return (
                <button
                  key={idx}
                  onClick={() => scrollToChapter(chapterIdx)}
                  className={`flex items-start gap-1.5 w-full text-left text-[10px] py-1 px-1.5 rounded transition-colors ${activeChapter === chapterIdx ? 'text-[#e6edf3] bg-[#161b22]' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
                >
                  <ChevronRight size={9} className="mt-0.5 shrink-0 opacity-50" />
                  <span className="line-clamp-2">{ch.title}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Book content */}
      <div ref={contentRef} className="min-w-0">
        <div className="max-w-3xl">
          {/* Title block */}
          <header className="mb-8 border-l-2 pl-4" style={{ borderColor: accent }}>
            <div className="text-[10px] tracking-[0.3em] font-bold mb-2 uppercase" style={{ color: accent }}>AxiomZero Production Library</div>
            <h1 className="text-2xl font-bold text-[#e6edf3] leading-tight tracking-tight">{bookTitle}</h1>
            {bookSubtitle && <div className="text-[#8b949e] text-sm mt-2 font-mono">{bookSubtitle}</div>}
          </header>

          {/* Chapters */}
          {visible.map((ch, idx) => {
            if (ch.type === 'part') {
              return (
                <div key={idx} className="my-8 py-4 border-y border-[#30363d] text-center">
                  <span className="text-sm font-bold text-[#e6edf3] tracking-wider uppercase">{ch.title}</span>
                </div>
              );
            }
            const chNum = chapterList.indexOf(ch) + 1;
            return (
              <section key={idx} data-chapter-idx={idx} className="mb-12 scroll-mt-20">
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-[10px] font-mono px-2 py-1 border" style={{ color: accent, borderColor: `${accent}40`, background: `${accent}10` }}>{String(chNum).padStart(2, '0')}</span>
                  <h2 className="text-lg font-bold text-[#e6edf3] leading-tight">{ch.title}</h2>
                </div>
                <div className="text-sm text-[#c9d1d9] leading-relaxed space-y-4 prose-invert">
                  <ReactMarkdown
                    components={{
                      h1: ({ children }) => <h3 className="text-base font-bold text-[#e6edf3] mt-4 mb-2">{children}</h3>,
                      h2: ({ children }) => <h3 className="text-sm font-bold text-[#e6edf3] mt-4 mb-2">{children}</h3>,
                      h3: ({ children }) => <h4 className="text-sm font-bold text-[#e6edf3] mt-3 mb-1">{children}</h4>,
                      blockquote: ({ children }) => <blockquote className="my-4 border-l-2 pl-4 py-2 italic text-[#e6edf3]" style={{ borderColor: accent, background: `${accent}05` }}>{children}</blockquote>,
                      code: ({ children }) => <code className="bg-[#0d1117] text-[#fbbf24] px-1.5 py-0.5 rounded text-xs font-mono">{children}</code>,
                      pre: ({ children }) => <pre className="bg-[#0d1117] border border-[#30363d] p-3 rounded text-xs overflow-x-auto my-3">{children}</pre>,
                      ul: ({ children }) => <ul className="list-disc pl-5 space-y-1">{children}</ul>,
                      ol: ({ children }) => <ol className="list-decimal pl-5 space-y-1">{children}</ol>,
                      a: ({ href, children }) => <a href={href} target="_blank" rel="noopener noreferrer" className="text-[#58a6ff] underline hover:text-[#fbbf24]">{children}</a>,
                      table: ({ children }) => <div className="overflow-x-auto my-3"><table className="w-full border border-[#30363d] text-xs">{children}</table></div>,
                      th: ({ children }) => <th className="border border-[#30363d] bg-[#161b22] p-2 text-left text-[#e6edf3]">{children}</th>,
                      td: ({ children }) => <td className="border border-[#30363d] p-2 text-[#c9d1d9]">{children}</td>,
                      strong: ({ children }) => <strong className="font-bold text-[#e6edf3]">{children}</strong>,
                      em: ({ children }) => <em className="text-[#e6edf3]">{children}</em>,
                    }}
                  >
                    {ch.body}
                  </ReactMarkdown>
                </div>
              </section>
            );
          })}

          {visibleCount < chapters.length && (
            <div className="text-center py-6">
              <button onClick={loadMore} className="px-4 py-2 bg-[#161b22] border border-[#30363d] rounded text-xs font-bold text-[#e6edf3] hover:border-[#fbbf24]/40 transition-colors">Load More Chapters ({chapters.length - visibleCount} remaining)</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}