/**
 * InventoryOverviewTab — Cross-department inventory dashboard.
 * Shows ALL departments' gear, rentals, and purchases in one view with
 * budget allocation, status breakdown, asset type filtering, and master export.
 */
import { useState, useEffect, useMemo } from 'react';
import { Package, Loader2, Download, Search, AlertTriangle, Repeat, ShoppingCart, Boxes, DollarSign, TrendingUp } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { DEPARTMENTS, DEPARTMENT_MAP, DEPARTMENT_BUDGET_WEIGHTS, ASSET_TYPES, ASSET_TYPE_MAP, PROCUREMENT_STATUS_COLORS, PROCUREMENT_STATUS_ORDER } from '@/lib/filmers/departments';
import { exportCSV } from '@/lib/filmers/filmExport';

const ASSET_TYPE_ICONS = { studio_gear: Package, rental: Repeat, purchase: ShoppingCart };

export default function InventoryOverviewTab({ project }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterDept, setFilterDept] = useState('all');
  const [filterAssetType, setFilterAssetType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      if (!project) { setLoading(false); return; }
      setLoading(true);
      try {
        const all = await base44.entities.DepartmentItem.filter({ project_id: project.id });
        setItems(all);
      } finally { setLoading(false); }
    })();
  }, [project?.id]);

  const filtered = useMemo(() => {
    return items.filter(i => {
      const ps = i.procurement_status || i.status || 'needed';
      return (filterDept === 'all' || i.department === filterDept) &&
             (filterAssetType === 'all' || (i.rental_type || 'purchase') === filterAssetType) &&
             (filterStatus === 'all' || ps === filterStatus) &&
             (search === '' || (i.item_name || '').toLowerCase().includes(search.toLowerCase()) ||
              (i.source_vendor || '').toLowerCase().includes(search.toLowerCase()) ||
              (i.category || '').toLowerCase().includes(search.toLowerCase()));
    });
  }, [items, filterDept, filterAssetType, filterStatus, search]);

  // Summary stats
  const stats = useMemo(() => {
    const totalValue = items.reduce((s, i) => s + (i.unit_cost || 0) * (i.quantity || 1), 0);
    const byAssetType = {};
    ASSET_TYPES.forEach(at => {
      const atItems = items.filter(i => (i.rental_type || 'purchase') === at.key);
      byAssetType[at.key] = {
        count: atItems.length,
        value: atItems.reduce((s, i) => s + (i.unit_cost || 0) * (i.quantity || 1), 0),
      };
    });
    const byStatus = {};
    PROCUREMENT_STATUS_ORDER.forEach(s => { byStatus[s] = items.filter(i => (i.procurement_status || i.status || 'needed') === s).length; });
    return { totalItems: items.length, totalValue, byAssetType, byStatus };
  }, [items]);

  // Per-department budget allocation
  const deptBudgets = useMemo(() => {
    return DEPARTMENTS.map(d => {
      const deptItems = items.filter(i => i.department === d.key);
      const spent = deptItems.reduce((s, i) => s + (i.unit_cost || 0) * (i.quantity || 1), 0);
      const allocated = project ? Math.round((project.total_budget || 0) * (DEPARTMENT_BUDGET_WEIGHTS[d.key] || 0) / 100) : 0;
      const pct = allocated > 0 ? Math.round((spent / allocated) * 100) : 0;
      return { dept: d, itemCount: deptItems.length, spent, allocated, pct, over: pct >= 100, alert: pct >= 80 };
    }).filter(db => db.itemCount > 0 || db.allocated > 0);
  }, [items, project]);

  const exportAll = () => {
    exportCSV(filtered.map(i => ({
      department: i.department, item: i.item_name, category: i.category, qty: i.quantity,
      asset_type: i.rental_type || 'purchase',
      procurement_status: i.procurement_status || i.status || 'needed',
      condition: i.condition_status || '',
      asset_tag: i.asset_tag || '',
      vendor: i.source_vendor, unit_cost: i.unit_cost,
      total_cost: (i.unit_cost || 0) * (i.quantity || 1),
      storage_location: i.storage_location || '',
      po_number: i.po_number || '',
      rental_vendor: i.rental_vendor || '',
      rental_return_date: i.rental_return_date || '',
      rental_daily_rate: i.rental_daily_rate || 0,
      notes: i.notes,
    })), 'all_departments_inventory.csv');
  };

  if (!project) return (
    <div className="glass-panel clip-corner p-8 text-center">
      <Boxes size={28} className="text-[#484f58] mx-auto mb-3" />
      <p className="text-xs text-[#8b949e]">Select a project to view cross-department inventory.</p>
    </div>
  );

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#484f58]" size={18} /></div>;

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Boxes size={14} className="text-[#4dd0e1]" />
          <span className="text-xs font-bold text-[#4dd0e1]">Inventory Overview — All Departments</span>
          <span className="text-[9px] text-[#484f58]">{items.length} total items</span>
        </div>
        <button onClick={exportAll} disabled={!filtered.length} className="flex items-center gap-1 px-2 py-1 bg-[#3fb950] text-black rounded text-[9px] font-bold disabled:opacity-40">
          <Download size={10} /> Export All
        </button>
      </div>

      {/* Summary stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
        <div className="glass-panel clip-corner p-3 border-l-2 border-[#4dd0e1]">
          <div className="flex items-center gap-1.5 mb-1"><Package size={10} className="text-[#4dd0e1]" /><span className="text-[8px] text-[#8b949e] uppercase">Total Items</span></div>
          <div className="text-lg font-bold text-[#4dd0e1]">{stats.totalItems}</div>
        </div>
        <div className="glass-panel clip-corner p-3 border-l-2 border-[#3fb950]">
          <div className="flex items-center gap-1.5 mb-1"><DollarSign size={10} className="text-[#3fb950]" /><span className="text-[8px] text-[#8b949e] uppercase">Total Value</span></div>
          <div className="text-lg font-bold text-[#3fb950]">${stats.totalValue.toLocaleString()}</div>
        </div>
        {ASSET_TYPES.map(at => {
          const Icon = ASSET_TYPE_ICONS[at.key] || Package;
          const data = stats.byAssetType[at.key];
          return (
            <div key={at.key} className="glass-panel clip-corner p-3 border-l-2" style={{ borderColor: at.color }}>
              <div className="flex items-center gap-1.5 mb-1"><Icon size={10} style={{ color: at.color }} /><span className="text-[8px] text-[#8b949e] uppercase">{at.label}</span></div>
              <div className="text-lg font-bold" style={{ color: at.color }}>{data.count}</div>
              <div className="text-[8px] text-[#484f58]">${data.value.toLocaleString()}</div>
            </div>
          );
        })}
      </div>

      {/* Budget allocation across departments */}
      <div className="glass-panel clip-corner p-3">
        <div className="flex items-center gap-2 mb-2"><TrendingUp size={12} className="text-[#4dd0e1]" /><span className="text-[10px] font-bold text-[#4dd0e1]">Budget Allocation by Department</span></div>
        {!deptBudgets.length ? (
          <div className="text-[10px] text-[#484f58] italic py-2">No inventory items or budget allocated yet.</div>
        ) : (
          <div className="space-y-1.5">
            {deptBudgets.map(db => (
              <div key={db.dept.key} className="flex items-center gap-2">
                <span className="text-[9px] font-bold w-28 shrink-0 truncate" style={{ color: db.dept.color }}>{db.dept.key}</span>
                <div className="flex-1 h-5 bg-[#161b22] rounded-sm overflow-hidden relative">
                  <div className="h-full transition-all" style={{ width: `${Math.min(db.pct, 100)}%`, background: db.over ? '#f85149' : db.alert ? '#fbbf24' : db.dept.color }} />
                  <span className="absolute inset-0 flex items-center px-2 text-[8px] font-bold text-white/90">
                    ${db.spent.toLocaleString()} / ${db.allocated.toLocaleString()}
                  </span>
                </div>
                <span className={`text-[9px] font-bold w-10 text-right ${db.over ? 'text-[#f85149]' : db.alert ? 'text-[#fbbf24]' : 'text-[#8b949e]'}`}>
                  {db.pct}%{db.over && <AlertTriangle size={8} className="inline ml-0.5" />}
                </span>
                <span className="text-[8px] text-[#484f58] w-8 text-right">{db.itemCount} items</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Status breakdown bar */}
      <div className="glass-panel clip-corner p-3">
        <div className="flex items-center gap-2 mb-2"><Package size={12} className="text-[#8b949e]" /><span className="text-[10px] font-bold text-[#8b949e]">Procurement Status Breakdown</span></div>
        <div className="flex items-center gap-1 h-6 rounded-sm overflow-hidden">
          {PROCUREMENT_STATUS_ORDER.map(s => {
            const count = stats.byStatus[s] || 0;
            const pct = stats.totalItems > 0 ? (count / stats.totalItems) * 100 : 0;
            if (pct === 0) return null;
            return (
              <div key={s} className="h-full flex items-center justify-center text-[8px] font-bold text-black/80" style={{ width: `${pct}%`, background: PROCUREMENT_STATUS_COLORS[s] }} title={`${s}: ${count}`}>
                {pct > 8 ? count : ''}
              </div>
            );
          })}
        </div>
        <div className="flex items-center gap-3 mt-1.5 flex-wrap">
          {PROCUREMENT_STATUS_ORDER.map(s => (
            <div key={s} className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-sm" style={{ background: PROCUREMENT_STATUS_COLORS[s] }} />
              <span className="text-[8px] text-[#8b949e]">{s} ({stats.byStatus[s] || 0})</span>
            </div>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="glass-panel clip-corner p-2 flex items-center gap-2 flex-wrap">
        <div className="flex items-center gap-1 flex-1 min-w-[150px]">
          <Search size={12} className="text-[#484f58]" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search items, vendors, categories..." className="flex-1 bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[10px] text-[#e6edf3]" />
        </div>
        <select value={filterDept} onChange={e => setFilterDept(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[10px] text-[#e6edf3]">
          <option value="all">All Departments</option>
          {DEPARTMENTS.map(d => <option key={d.key} value={d.key}>{d.key}</option>)}
        </select>
        <select value={filterAssetType} onChange={e => setFilterAssetType(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[10px] text-[#e6edf3]">
          <option value="all">All Asset Types</option>
          {ASSET_TYPES.map(a => <option key={a.key} value={a.key}>{a.label}</option>)}
        </select>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[10px] text-[#e6edf3]">
          <option value="all">All Status</option>
          {PROCUREMENT_STATUS_ORDER.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {/* Master list */}
      {!filtered.length ? (
        <div className="text-center py-8 text-[10px] text-[#484f58] italic">No items match the current filters.</div>
      ) : (
        <div className="glass-panel clip-corner overflow-x-auto">
          <table className="w-full text-[10px]">
            <thead className="bg-[#161b22] text-[#8b949e] uppercase">
              <tr>
                <th className="p-2 text-left">Item</th>
                <th className="p-2 text-left">Dept</th>
                <th className="p-2 text-left">Asset Type</th>
                <th className="p-2 text-right">Qty</th>
                <th className="p-2 text-right">Unit Cost</th>
                <th className="p-2 text-right">Total</th>
                <th className="p-2 text-left">Status</th>
                <th className="p-2 text-left">Vendor</th>
                <th className="p-2 text-left">Storage</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(item => {
                const dept = DEPARTMENT_MAP[item.department];
                const at = ASSET_TYPE_MAP[item.rental_type || 'purchase'] || ASSET_TYPE_MAP.purchase;
                const ps = item.procurement_status || item.status || 'needed';
                const total = (item.unit_cost || 0) * (item.quantity || 1);
                const AssetIcon = ASSET_TYPE_ICONS[at.key] || Package;
                return (
                  <tr key={item.id} className="border-t border-[#30363d] hover:bg-[#161b22]">
                    <td className="p-2 font-bold text-[#e6edf3]">{item.item_name}</td>
                    <td className="p-2"><span className="text-[8px] px-1.5 py-0.5 rounded border" style={{ color: dept?.color || '#8b949e', borderColor: `${dept?.color || '#8b949e'}40` }}>{item.department}</span></td>
                    <td className="p-2"><span className="flex items-center gap-1 text-[9px]" style={{ color: at.color }}><AssetIcon size={9} /> {at.label}</span></td>
                    <td className="p-2 text-right text-[#e6edf3]">{item.quantity}</td>
                    <td className="p-2 text-right text-[#8b949e]">${(item.unit_cost || 0).toLocaleString()}</td>
                    <td className="p-2 text-right text-[#3fb950] font-bold">${total.toLocaleString()}</td>
                    <td className="p-2"><span className="text-[8px] px-1.5 py-0.5 rounded font-bold" style={{ background: `${PROCUREMENT_STATUS_COLORS[ps]}20`, color: PROCUREMENT_STATUS_COLORS[ps] }}>{ps}</span></td>
                    <td className="p-2 text-[9px] text-[#8b949e]">{item.source_vendor || '—'}</td>
                    <td className="p-2 text-[9px] text-[#58a6ff]">{item.storage_location || '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}