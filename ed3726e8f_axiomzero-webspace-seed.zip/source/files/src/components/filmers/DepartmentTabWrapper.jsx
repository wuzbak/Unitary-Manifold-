/**
 * DepartmentTabWrapper — Renders a department inventory tab with a toggle
 * between the generic DepartmentItem grid and the specialized entity grid
 * (WardrobeItem / CameraItem) for departments that have one.
 */
import { useState } from 'react';
import { Layers, Package } from 'lucide-react';
import DepartmentInventoryGrid from './DepartmentInventoryGrid';
import SpecializedEntityGrid, { SPECIALIZED_CONFIG } from './SpecializedEntityGrid';

const HAS_SPECIALIZED = Object.keys(SPECIALIZED_CONFIG);

export default function DepartmentTabWrapper({ project, deptKey }) {
  const hasSpecialized = HAS_SPECIALIZED.includes(deptKey);
  const [mode, setMode] = useState('generic'); // 'generic' | 'specialized'

  if (!hasSpecialized) {
    return <DepartmentInventoryGrid project={project} deptKey={deptKey} />;
  }

  const config = SPECIALIZED_CONFIG[deptKey];

  return (
    <div className="space-y-3">
      {/* Mode toggle */}
      <div className="flex items-center gap-1 glass-panel clip-corner p-1 w-fit">
        <button
          onClick={() => setMode('generic')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-bold transition-all ${mode === 'generic' ? 'text-black bg-[#34d399]' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
        >
          <Package size={11} /> Generic Inventory
        </button>
        <button
          onClick={() => setMode('specialized')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-bold transition-all ${mode === 'specialized' ? 'text-black' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
          style={mode === 'specialized' ? { background: config.accent } : {}}
        >
          <Layers size={11} /> {config.label} Specialized
        </button>
      </div>

      {mode === 'generic' ? (
        <DepartmentInventoryGrid project={project} deptKey={deptKey} />
      ) : (
        <SpecializedEntityGrid project={project} deptKey={deptKey} />
      )}
    </div>
  );
}