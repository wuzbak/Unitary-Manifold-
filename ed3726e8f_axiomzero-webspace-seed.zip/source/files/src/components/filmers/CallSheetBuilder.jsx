/**
 * CallSheetBuilder — Professional call sheet builder.
 * Selects a shoot day, auto-generates cast/crew calls, scenes, weather,
 * nearest hospital, and exports as formatted PDF/text.
 */
import { useState, useEffect, useCallback } from 'react';
import { FileText, Download, Loader2, Plus, Trash2, Clock, MapPin, Sun, Cloud } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { generateCallSheetData, formatCallSheetText } from '@/lib/filmers/schedulingEngine';
import { exportPDF, exportTXT } from '@/lib/filmers/filmExport';
import { logActivity } from '@/lib/filmers/activityLog';

export default function CallSheetBuilder({ project }) {
  const [shootDays, setShootDays] = useState([]);
  const [scenes, setScenes] = useState([]);
  const [cast, setCast] = useState([]);
  const [crew, setCrew] = useState([]);
  const [locations, setLocations] = useState([]);
  const [callSheets, setCallSheets] = useState([]);
  const [selectedDayId, setSelectedDayId] = useState('');
  const [loading, setLoading] = useState(true);
  const [preview, setPreview] = useState(null);
  const [generating, setGenerating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [d, s, c, cr, l, cs] = await Promise.all([
        base44.entities.ShootDay.filter({ project_id: project.id }, 'day_number', 200),
        base44.entities.Scene.filter({ project_id: project.id }, 'sort_order', 500),
        base44.entities.CastMember.filter({ project_id: project.id }),
        base44.entities.CrewMember.filter({ project_id: project.id }),
        base44.entities.Location.filter({ project_id: project.id }),
        base44.entities.CallSheet.filter({ project_id: project.id }, '-shoot_date', 50),
      ]);
      setShootDays(d); setScenes(s); setCast(c); setCrew(cr); setLocations(l); setCallSheets(cs);
      if (d.length > 0 && !selectedDayId) setSelectedDayId(d[0].id);
    } catch { /* best-effort */ }
    finally { setLoading(false); }
  }, [project.id]);

  useEffect(() => { load(); }, [load]);

  const selectedDay = shootDays.find(d => d.id === selectedDayId);
  const selectedLocation = locations.find(l => l.id === selectedDay?.location_id) || locations.find(l => l.name === selectedDay?.location_name);

  const generate = async () => {
    if (!selectedDay) return;
    setGenerating(true);
    try {
      const data = generateCallSheetData(selectedDay, scenes, cast, crew, selectedLocation);
      data.production = project.title;
      const text = formatCallSheetText(data);

      // Save call sheet entity
      const saved = await base44.entities.CallSheet.create({
        project_id: project.id,
        shoot_day_id: selectedDay.id,
        shoot_date: selectedDay.date,
        day_number: selectedDay.day_number,
        location_name: data.location,
        location_address: data.location_address,
        nearest_hospital: data.nearest_hospital,
        sunrise: data.sunrise,
        sunset: data.sunset,
        weather: data.weather,
        crew_call: data.crew_call,
        shooting_call: data.shooting_call,
        lunch_call: data.lunch,
        estimated_wrap: data.estimated_wrap,
        scenes_json: JSON.stringify(data.scenes),
        cast_calls_json: JSON.stringify(data.cast_calls),
        crew_calls_json: JSON.stringify(data.crew_calls),
        notes: data.notes,
      });

      // Update shoot day with call sheet reference
      await base44.entities.ShootDay.update(selectedDay.id, { call_sheet_id: saved.id, status: 'shooting' });

      setCallSheets([saved, ...callSheets]);
      setPreview({ data, text, id: saved.id });
      logActivity(project.id, 'call_sheet', `Day ${selectedDay.day_number}`, 'generated', selectedDay.date);
    } catch { /* best-effort */ }
    setGenerating(false);
  };

  const exportSheet = (format) => {
    if (!preview) return;
    const title = `Call_Sheet_Day_${preview.data.day_number}_${preview.data.shoot_date}`;
    if (format === 'pdf') exportPDF(`Call Sheet — Day ${preview.data.day_number}`, preview.text, `${title}.pdf`);
    else exportTXT(preview.text, `${title}.txt`);
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#f472b6]" size={18} /></div>;

  return (
    <div className="space-y-3">
      {/* Day selector + generate */}
      <div className="glass-strong clip-corner p-3 flex items-center gap-2 flex-wrap">
        <FileText size={14} className="text-[#f472b6]" />
        <span className="text-xs font-bold text-[#f472b6]">Call Sheet Builder</span>
        <select value={selectedDayId} onChange={e => setSelectedDayId(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] flex-1 min-w-[150px]">
          <option value="">Select shoot day...</option>
          {shootDays.map(d => <option key={d.id} value={d.id}>Day {d.day_number} — {d.date} — {d.location_name || 'TBD'}</option>)}
        </select>
        <button onClick={generate} disabled={!selectedDay || generating} className="flex items-center gap-1 px-3 py-1.5 bg-[#f472b6] text-black rounded text-[10px] font-bold hover:opacity-80 disabled:opacity-40">
          {generating ? <Loader2 size={10} className="animate-spin" /> : <Plus size={10} />} Generate
        </button>
      </div>

      {shootDays.length === 0 && (
        <div className="glass-panel clip-corner p-8 text-center">
          <FileText size={28} className="text-[#484f58] mx-auto mb-3" />
          <p className="text-xs text-[#8b949e]">No shoot days yet. Create days in the Scheduling tab first.</p>
        </div>
      )}

      {/* Preview */}
      {preview && (
        <div className="glass-strong clip-corner p-4">
          <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
            <span className="text-xs font-bold text-[#f472b6]">Call Sheet — Day {preview.data.day_number} — {preview.data.shoot_date}</span>
            <div className="flex items-center gap-2">
              <button onClick={() => exportSheet('pdf')} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#3fb950]/20 border border-[#3fb950]/40 text-[#3fb950] hover:bg-[#3fb950]/30">
                <Download size={10} /> PDF
              </button>
              <button onClick={() => exportSheet('txt')} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]">
                <Download size={10} /> TXT
              </button>
            </div>
          </div>
          {/* Quick stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
            <div className="glass-panel clip-corner p-2">
              <div className="flex items-center gap-1 text-[8px] text-[#484f58] uppercase"><Clock size={8} /> Crew Call</div>
              <div className="text-sm font-bold text-[#e6edf3]">{preview.data.crew_call}</div>
            </div>
            <div className="glass-panel clip-corner p-2">
              <div className="flex items-center gap-1 text-[8px] text-[#484f58] uppercase"><MapPin size={8} /> Location</div>
              <div className="text-[10px] font-bold text-[#34d399] truncate">{preview.data.location}</div>
            </div>
            <div className="glass-panel clip-corner p-2">
              <div className="flex items-center gap-1 text-[8px] text-[#484f58] uppercase"><Sun size={8} /> Sunrise/Sunset</div>
              <div className="text-[10px] font-bold text-[#fbbf24]">{preview.data.sunrise || '—'} / {preview.data.sunset || '—'}</div>
            </div>
            <div className="glass-panel clip-corner p-2">
              <div className="flex items-center gap-1 text-[8px] text-[#484f58] uppercase"><Cloud size={8} /> Weather</div>
              <div className="text-[10px] font-bold text-[#58a6ff]">{preview.data.weather || 'TBD'}</div>
            </div>
          </div>
          <pre className="text-[10px] text-[#e6edf3] whitespace-pre-wrap bg-[#0B0F13] border border-[#30363d] rounded p-3 max-h-[60vh] overflow-y-auto font-mono">{preview.text}</pre>
        </div>
      )}

      {/* Saved call sheets */}
      {callSheets.length > 0 && (
        <div className="glass-panel clip-corner p-3">
          <div className="text-[10px] font-bold text-[#8b949e] uppercase tracking-wider mb-2">Saved Call Sheets ({callSheets.length})</div>
          <div className="space-y-1">
            {callSheets.map(cs => (
              <div key={cs.id} className="flex items-center gap-2 p-2 border border-[#30363d] rounded hover:border-[#f472b6]/30">
                <span className="text-[10px] font-bold text-[#f472b6]">Day {cs.day_number}</span>
                <span className="text-[10px] text-[#e6edf3]">{cs.shoot_date}</span>
                <span className="text-[9px] text-[#8b949e]">{cs.location_name}</span>
                <button onClick={async () => {
                  let castCalls = [], crewCalls = [], sheetScenes = [];
                  try { castCalls = JSON.parse(cs.cast_calls_json || '[]'); } catch {}
                  try { crewCalls = JSON.parse(cs.crew_calls_json || '[]'); } catch {}
                  try { sheetScenes = JSON.parse(cs.scenes_json || '[]'); } catch {}
                  const data = {
                    day_number: cs.day_number, shoot_date: cs.shoot_date, production: project.title,
                    location: cs.location_name, location_address: cs.location_address,
                    nearest_hospital: cs.nearest_hospital, sunrise: cs.sunrise, sunset: cs.sunset,
                    weather: cs.weather, crew_call: cs.crew_call, shooting_call: cs.shooting_call,
                    lunch: cs.lunch_call, estimated_wrap: cs.estimated_wrap,
                    scenes: sheetScenes, cast_calls: castCalls, crew_calls: crewCalls, notes: cs.notes,
                  };
                  setPreview({ data, text: formatCallSheetText(data), id: cs.id });
                }} className="ml-auto text-[9px] text-[#f472b6] hover:underline">View</button>
                <button onClick={async () => { await base44.entities.CallSheet.delete(cs.id); setCallSheets(callSheets.filter(x => x.id !== cs.id)); }} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={10} /></button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}