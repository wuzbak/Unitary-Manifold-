/**
 * BooksTab — Container for two book reproductions with sub-tab switching.
 */
import { useState } from 'react';
import { BookOpen, Clapperboard } from 'lucide-react';
import BookReader from './BookReader';

const BOOKS = [
  {
    key: 'production',
    label: 'Axiom Omega Production Guide',
    icon: BookOpen,
    url: 'https://media.base44.com/files/public/6a51c0830aeacd39ab86c4f0/498851358_book-film-production-omega1.md',
    title: 'Axiom Omega Production Guide',
    subtitle: 'Film and Television: Fast, Humane, and Built to Last',
    accent: '#fbbf24',
  },
  {
    key: 'acting',
    label: 'The Living Instrument',
    icon: Clapperboard,
    url: 'https://media.base44.com/files/public/6a51c0830aeacd39ab86c4f0/6868b98c9_book-living-instrument-actors-craft.md',
    title: 'The Living Instrument',
    subtitle: 'A Complete Manual of the Actor\'s Craft — From Ancient Ritual to the Modern Stage and Screen',
    accent: '#a78bfa',
  },
];

export default function BooksTab() {
  const [active, setActive] = useState('production');
  const book = BOOKS.find(b => b.key === active);

  return (
    <div className="space-y-4">
      <div className="flex gap-2 flex-wrap">
        {BOOKS.map(b => (
          <button key={b.key} onClick={() => setActive(b.key)} className={`flex items-center gap-2 px-4 py-2 rounded text-xs font-bold border transition-colors ${active === b.key ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`} style={active === b.key ? { background: b.accent } : {}}>
            <b.icon size={12} /> {b.label}
          </button>
        ))}
      </div>
      <div className="text-[10px] text-[#484f58] px-1">Full reproduction · Founding Fathers exhibit format · Progressive chapter loading · Licensed under Defensive Public Commons License v1.0 (2026)</div>
      <BookReader key={book.key} bookUrl={book.url} bookTitle={book.title} bookSubtitle={book.subtitle} accent={book.accent} />
    </div>
  );
}