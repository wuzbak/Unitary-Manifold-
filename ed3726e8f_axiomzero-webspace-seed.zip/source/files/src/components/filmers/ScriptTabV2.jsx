/**
 * ScriptTabV2 — Trelby-inspired screenwriting suite with three sub-panels:
 * Editor | Reports | Compare
 *
 * Replaces the old import-only ScriptTab with a full WYSIWYG editor,
 * intelligent breakdown, comprehensive reporting, and revision comparison.
 */
import { useState, useEffect, useCallback, useRef } from 'react';
import { FileText, Edit3, BarChart3, GitCompare, Upload, Plus, Loader2, Scissors, RefreshCw, LayoutDashboard } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { fountainToElements, elementsToFountain, genId } from '@/lib/filmers/fountainSerializer';
import { generateBreakdown } from '@/lib/filmers/breakdownEngine';
import { logActivity } from '@/lib/filmers/activityLog';
import ScreenplayEditor from './ScreenplayEditor';
import ScriptReports from './ScriptReports';
import ScriptCompare from './ScriptCompare';
import BreakdownReviewPanel from './BreakdownReviewPanel';
import ScriptDashboard from './ScriptDashboard';

const REVISION_COLORS = ['White', 'Blue', 'Pink', 'Yellow', 'Green', 'Goldenrod', 'Buff', 'Salmon', 'Cherry'];
const SUB_TABS = [
  { id: 'dashboard', label: 'Breakdown', icon: LayoutDashboard, color: '#4dd0e1' },
  { id: 'editor', label: 'Editor', icon: Edit3, color: '#a78bfa' },
  { id: 'reports', label: 'Reports', icon: BarChart3, color: '#4dd0e1' },
  { id: 'compare', label: 'Compare', icon: GitCompare, color: '#fbbf24' },
];

export default function ScriptTabV2({ project, embeddedDashboard }) {
  const [scripts, setScripts] = useState([]);
  const [activeScript, setActiveScript] = useState(null);
  const [elements, setElements] = useState([]);
  const [castNames, setCastNames] = useState([]);
  const [locationNames, setLocationNames] = useState([]);
  const [cast, setCast] = useState([]);
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [subTab, setSubTab] = useState(embeddedDashboard ? 'dashboard' : 'editor');
  const [showImport, setShowImport] = useState(false);
  const [importText, setImportText] = useState('');
  const [importTitle, setImportTitle] = useState('');
  const [importing, setImporting] = useState(false);
  const [breakdown, setBreakdown] = useState(null);
  const [showBreakdown, setShowBreakdown] = useState(false);
  const [error, setError] = useState(null);
  const saveTimer = useRef(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [s, c, l] = await Promise.all([
        base44.entities.Script.filter({ project_id: project.id }, '-imported_date', 50),
        base44.entities.CastMember.filter({ project_id: project.id }),
        base44.entities.Location.filter({ project_id: project.id }),
      ]);
      setScripts(s);
      setCast(c);
      setLocations(l);
      setCastNames(c.map(m => m.name));
      setLocationNames(l.map(loc => loc.name));
      // Auto-select most recent script
      if (s.length > 0) {
        const latest = s[0];
        setActiveScript(latest);
        try {
          const els = latest.elements_json ? JSON.parse(latest.elements_json) : [];
          setElements(els.length > 0 ? els : (latest.content ? fountainToElements(latest.content) : []));
        } catch {
          setElements(latest.content ? fountainToElements(latest.content) : []);
        }
      } else {
        setActiveScript(null);
        setElements([]);
      }
    } catch (e) { setError(String(e?.message || e)); }
    finally { setLoading(false); }
  }, [project.id]);

  useEffect(() => { load(); }, [load]);

  // Debounced auto-save
  const scheduleSave = useCallback((newElements) => {
    if (!activeScript) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      setSaving(true);
      try {
        const content = elementsToFountain(newElements);
        await base44.entities.Script.update(activeScript.id, {
          elements_json: JSON.stringify(newElements),
          content,
          last_edited: new Date().toISOString(),
        });
        logActivity(project.id, 'script', activeScript.title, 'auto-saved');
      } catch (e) { /* best-effort */ }
      setSaving(false);
    }, 2000);
  }, [activeScript, project.id]);

  const handleElementsChange = useCallback((newElements) => {
    setElements(newElements);
    scheduleSave(newElements);
  }, [scheduleSave]);

  const handleManualSave = async () => {
    if (!activeScript) return;
    setSaving(true);
    try {
      const content = elementsToFountain(elements);
      await base44.entities.Script.update(activeScript.id, {
        elements_json: JSON.stringify(elements),
        content,
        last_edited: new Date().toISOString(),
      });
      setActiveScript({ ...activeScript, elements_json: JSON.stringify(elements), content });
      logActivity(project.id, 'script', activeScript.title, 'saved');
    } catch (e) { setError(String(e?.message || e)); }
    setSaving(false);
  };

  const createNewScript = async () => {
    const title = `New Screenplay ${scripts.length + 1}`;
    const initialElements = [
      { id: genId(), type: 'scene', text: 'INT. LOCATION - DAY', scene_index: 0 },
      { id: genId(), type: 'action', text: '', scene_index: 0 },
    ];
    const content = elementsToFountain(initialElements);
    const script = await base44.entities.Script.create({
      project_id: project.id,
      title,
      content,
      elements_json: JSON.stringify(initialElements),
      source_format: 'editor',
      revision_name: 'White Draft',
      revision_color: 'White',
      imported_date: new Date().toISOString(),
      last_edited: new Date().toISOString(),
    });
    setScripts([script, ...scripts]);
    setActiveScript(script);
    setElements(initialElements);
    setSubTab('editor');
    logActivity(project.id, 'script', title, 'created');
  };

  const selectScript = (s) => {
    setActiveScript(s);
    try {
      const els = s.elements_json ? JSON.parse(s.elements_json) : [];
      setElements(els.length > 0 ? els : (s.content ? fountainToElements(s.content) : []));
    } catch {
      setElements(s.content ? fountainToElements(s.content) : []);
    }
  };

  const handleImport = async () => {
    if (!importText.trim()) return;
    setImporting(true); setError(null);
    try {
      const parsed = fountainToElements(importText);
      const title = importTitle.trim() || 'Imported Script';
      const content = elementsToFountain(parsed);
      const script = await base44.entities.Script.create({
        project_id: project.id,
        title,
        content,
        elements_json: JSON.stringify(parsed),
        source_format: 'fountain',
        revision_name: 'White Draft',
        revision_color: 'White',
        imported_date: new Date().toISOString(),
        last_edited: new Date().toISOString(),
      });
      setScripts([script, ...scripts]);
      setActiveScript(script);
      setElements(parsed);
      setImportText(''); setImportTitle('');
      setShowImport(false);
      setSubTab('editor');
      logActivity(project.id, 'script', title, 'imported');
    } catch (e) { setError(String(e?.message || e)); }
    setImporting(false);
  };

  const handleFileImport = async (file) => {
    if (!file) return;
    setImporting(true); setError(null);
    try {
      const text = await file.text();
      const parsed = fountainToElements(text);
      const title = file.name.replace(/\.[^.]+$/, '');
      const content = elementsToFountain(parsed);
      const script = await base44.entities.Script.create({
        project_id: project.id,
        title,
        content,
        elements_json: JSON.stringify(parsed),
        source_format: file.name.endsWith('.fountain') ? 'fountain' : 'text',
        revision_name: 'White Draft',
        revision_color: 'White',
        imported_date: new Date().toISOString(),
        last_edited: new Date().toISOString(),
      });
      setScripts([script, ...scripts]);
      setActiveScript(script);
      setElements(parsed);
      setShowImport(false);
      setSubTab('editor');
      logActivity(project.id, 'script', title, 'imported from file');
    } catch (e) { setError(String(e?.message || e)); }
    setImporting(false);
  };

  const runBreakdown = () => {
    const result = generateBreakdown(elements, cast, locations);
    setBreakdown(result);
    setShowBreakdown(true);
  };

  if (loading) {
    return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#a78bfa]" size={20} /></div>;
  }

  return (
    <div className="space-y-3">
      {/* Script selector + actions */}
      <div className="glass-strong clip-corner p-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <FileText size={14} className="text-[#a78bfa] shrink-0" />
            <select
              value={activeScript?.id || ''}
              onChange={e => { const s = scripts.find(x => x.id === e.target.value); if (s) selectScript(s); }}
              className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[11px] text-[#e6edf3] flex-1 min-w-[150px]"
            >
              {scripts.length === 0 && <option value="">No scripts yet</option>}
              {scripts.map(s => <option key={s.id} value={s.id}>{s.title} · {s.revision_color}</option>)}
            </select>
          </div>
          <div className="flex items-center gap-1.5">
            <button onClick={() => setShowImport(!showImport)} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] hover:border-[#a78bfa]/40">
              <Upload size={10} /> Import
            </button>
            <button onClick={createNewScript} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#a78bfa] text-black hover:opacity-80">
              <Plus size={10} /> New
            </button>
            {activeScript && elements.length > 0 && (
              <button onClick={runBreakdown} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#34d399] text-black hover:opacity-80">
                <Scissors size={10} /> Break Down
              </button>
            )}
            <button onClick={load} className="text-[#484f58] hover:text-[#e6edf3] p-1.5"><RefreshCw size={11} /></button>
          </div>
        </div>
      </div>

      {/* Import panel */}
      {showImport && (
        <div className="glass-panel clip-corner p-4">
          <div className="flex items-center gap-2 mb-2">
            <Upload size={12} className="text-[#a78bfa]" />
            <h3 className="text-[10px] font-bold text-[#a78bfa] uppercase tracking-wider">Import Script</h3>
          </div>
          <input value={importTitle} onChange={e => setImportTitle(e.target.value)} placeholder="Script title (optional)" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-[11px] text-[#e6edf3] mb-2" />
          <textarea value={importText} onChange={e => setImportText(e.target.value)} placeholder="Paste Fountain or plain-text screenplay here…" rows={5} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-[11px] text-[#e6edf3] mb-2 resize-y font-mono" />
          <div className="flex items-center gap-2 flex-wrap">
            <button onClick={handleImport} disabled={!importText.trim() || importing} className="flex items-center gap-1 bg-[#a78bfa] text-black px-3 py-1.5 rounded text-[10px] font-bold hover:opacity-80 disabled:opacity-40">
              {importing ? <Loader2 size={10} className="animate-spin" /> : <Plus size={10} />} Import Text
            </button>
            <label className="flex items-center gap-1 px-3 py-1.5 rounded text-[10px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] cursor-pointer">
              <Upload size={10} /> Upload .fountain / .txt
              <input type="file" accept=".fountain,.txt,.text" className="hidden" onChange={e => handleFileImport(e.target.files?.[0])} />
            </label>
          </div>
          {error && <div className="mt-2 text-[10px] text-[#f85149] border border-[#f85149]/30 rounded p-2">{error}</div>}
        </div>
      )}

      {/* Breakdown review */}
      {showBreakdown && breakdown && (
        <BreakdownReviewPanel
          breakdown={breakdown}
          project={project}
          onApplied={() => { setShowBreakdown(false); setBreakdown(null); }}
          onClose={() => { setShowBreakdown(false); setBreakdown(null); }}
        />
      )}

      {/* Sub-tabs */}
      {activeScript && (
        <div className="flex items-center gap-1 flex-wrap">
          {SUB_TABS.map(t => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setSubTab(t.id)}
                className={`flex items-center gap-1 px-3 py-1.5 rounded text-[10px] font-bold border transition-colors ${subTab === t.id ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}
                style={subTab === t.id ? { background: t.color } : {}}
              >
                <Icon size={10} /> {t.label}
              </button>
            );
          })}
        </div>
      )}

      {/* Content */}
      {activeScript ? (
        <>
          {subTab === 'dashboard' && (
            <ScriptDashboard elements={elements} scripts={scripts} project={project} cast={cast} locations={locations} scenes={[]} />
          )}
          {subTab === 'editor' && (
            <ScreenplayEditor
              script={activeScript}
              elements={elements}
              onChange={handleElementsChange}
              castNames={castNames}
              locationNames={locationNames}
              onSave={handleManualSave}
              saving={saving}
            />
          )}
          {subTab === 'reports' && (
            <ScriptReports elements={elements} project={project} />
          )}
          {subTab === 'compare' && (
            <ScriptCompare scripts={scripts} />
          )}
        </>
      ) : (
        <div className="glass-strong clip-corner p-8 text-center">
          <FileText size={28} className="text-[#484f58] mx-auto mb-3" />
          <p className="text-xs text-[#8b949e] mb-4">No script selected. Create a new screenplay or import one to get started.</p>
          <button onClick={createNewScript} className="px-4 py-2 bg-[#a78bfa] text-black rounded text-xs font-bold hover:opacity-80 flex items-center gap-1.5 mx-auto">
            <Plus size={12} /> New Screenplay
          </button>
        </div>
      )}

      {error && !showImport && <div className="text-[10px] text-[#f85149] border border-[#f85149]/30 rounded p-2">{error}</div>}
    </div>
  );
}