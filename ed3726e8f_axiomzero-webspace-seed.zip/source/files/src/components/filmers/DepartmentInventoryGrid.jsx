/**
 * DepartmentInventoryGrid — Full procurement & inventory management.
 * Storage location, PO tracking (po_number, order_date, expected_delivery_date),
 * procurement lifecycle, budget alerts, and expanded CSV export.
 */
import { useState, useEffect } from 'react';
import { Plus, Trash2, Download, Loader2, Package, AlertTriangle, MapPin, ShoppingCart, ChevronDown, ChevronRight, Repeat } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { DEPARTMENTS, PROCUREMENT_STATUS_COLORS, PROCUREMENT_STATUS_ORDER, DEPARTMENT_BUDGET_WEIGHTS, METADATA_FIELDS, ASSET_TYPES, CONDITION_STATUSES, CONDITION_COLORS } from '@/lib/filmers/departments';
import { exportCSV } from '@/lib/filmers/filmExport';
import { readCSVFile, coerceValue } from '@/lib/filmers/csvImport';
import { logActivity } from '@/lib/filmers/activityLog';
import ImportExportBar from './ImportExportBar';
import EntityDetailDrawer from './EntityDetailDrawer';

const ITEM_FIELDS = [
  { key: 'item_name', label: 'Item Name', type: 'text', required: true },
  { key: 'category', label: 'Category', type: 'text' },
  { key: 'quantity', label: 'Quantity', type: 'number' },
  { key: 'rental_type', label: 'Asset Type', type: 'select', options: ['purchase', 'rental', 'studio_gear'] },
  { key: 'procurement_status', label: 'Procurement Status', type: 'select', options: PROCUREMENT_STATUS_ORDER },
  { key: 'source_vendor', label: 'Vendor', type: 'text' },
  { key: 'unit_cost', label: 'Unit Cost', type: 'number' },
  { key: 'storage_location', label: 'Storage Location', type: 'text' },
  { key: 'asset_tag', label: 'Asset Tag / Serial', type: 'text' },
  { key: 'condition_status', label: 'Condition', type: 'select', options: CONDITION_STATUSES },
  { key: 'po_number', label: 'PO Number', type: 'text' },
  { key: 'order_date', label: 'Order Date', type: 'date' },
  { key: 'expected_delivery_date', label: 'Expected Delivery', type: 'date' },
  { key: 'rental_vendor', label: 'Rental Vendor', type: 'text' },
  { key: 'rental_return_date', label: 'Rental Return Date', type: 'date' },
  { key: 'rental_daily_rate', label: 'Rental Daily Rate', type: 'number' },
  { key: 'notes', label: 'Notes', type: 'textarea' },
];

const ASSET_TYPE_COLORS = { purchase: '#58a6ff', rental: '#fbbf24', studio_gear: '#4dd0e1' };
const ASSET_TYPE_LABELS = { purchase: 'Purchase', rental: 'Rental', studio_gear: 'Studio Gear' };

export default function DepartmentInventoryGrid({ project, deptKey }) {
  const dept = DEPARTMENTS.find(d => d.key === deptKey);
  const metadataFields = (METADATA_FIELDS[deptKey] || []).map(f => ({ key: f.key, label: f.label, type: 'text' }));
  const [items, setItems] = useState([]);
  const [scenes, setScenes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterScene, setFilterScene] = useState('all');
  const [showAdd, setShowAdd] = useState(false);
  const [expandedItem, setExpandedItem] = useState(null);
  const [drawer, setDrawer] = useState({ open: false, entity: null });
  const [form, setForm] = useState({
    item_name: '', category: dept.categories[0], quantity: 1, assigned_scene_id: '',
    procurement_status: 'needed', source_vendor: '', unit_cost: 0,
    storage_location: '', asset_tag: '', condition_status: 'new',
    po_number: '', order_date: '', expected_delivery_date: '',
    rental_type: 'purchase', rental_vendor: '', rental_return_date: '', rental_daily_rate: 0,
    notes: '',
  });

  useEffect(() => {
    (async () => {
      if (!project) { setLoading(false); return; }
      setLoading(true);
      try {
        const [deptItems, sceneList] = await Promise.all([
          project
            ? base44.entities.DepartmentItem.filter({ project_id: project.id, department: deptKey })
            : base44.entities.DepartmentItem.filter({ department: deptKey }, '-created_date', 500).then((all) => all.filter((i) => !i.project_id)),
          project
            ? base44.entities.Scene.filter({ project_id: project.id }, 'sort_order', 500)
            : Promise.resolve([]),
        ]);
        setItems(deptItems);
        setScenes(sceneList);
      } finally { setLoading(false); }
    })();
  }, [project?.id, deptKey]);

  const filtered = items.filter(i => {
    const ps = i.procurement_status || i.status || 'needed';
    return (filterStatus === 'all' || ps === filterStatus) &&
           (filterScene === 'all' || i.assigned_scene_id === filterScene);
  });

  const sceneLabel = (id) => scenes.find(s => s.id === id)?.scene_number || (id ? `Scene ${id.slice(-4)}` : '—');

  const addItem = async () => {
    if (!form.item_name.trim()) return;
    // Pack department-specific metadata fields into metadata_json
    const meta = {};
    metadataFields.forEach(f => { if (form[f.key]) meta[f.key] = form[f.key]; });
    const payload = { ...form, project_id: project?.id || '', department: deptKey, status: form.procurement_status, metadata_json: JSON.stringify(meta) };
    metadataFields.forEach(f => { delete payload[f.key]; });
    const created = await base44.entities.DepartmentItem.create(payload);
    setItems([...items, created]);
    logActivity(project?.id || '', 'department_item', form.item_name, 'created', `${deptKey}: ${form.procurement_status}`);
    setForm({
      item_name: '', category: dept.categories[0], quantity: 1, assigned_scene_id: '',
      procurement_status: 'needed', source_vendor: '', unit_cost: 0,
      storage_location: '', asset_tag: '', condition_status: 'new',
      po_number: '', order_date: '', expected_delivery_date: '',
      rental_type: 'purchase', rental_vendor: '', rental_return_date: '', rental_daily_rate: 0,
      notes: '',
    });
    setShowAdd(false);
  };

  const updateProcurementStatus = async (id, procurement_status) => {
    const updated = await base44.entities.DepartmentItem.update(id, { procurement_status, status: procurement_status });
    setItems(items.map(i => i.id === id ? { ...i, ...updated } : i));
    const item = items.find(i => i.id === id);
    if (item) logActivity(project?.id, 'department_item', item.item_name, 'status_changed', `${deptKey}: ${procurement_status}`);
  };

  const updateItemField = async (id, field, value) => {
    const updated = await base44.entities.DepartmentItem.update(id, { [field]: value });
    setItems(items.map(i => i.id === id ? { ...i, ...updated } : i));
  };

  const deleteItem = async (id) => {
    const item = items.find(i => i.id === id);
    await base44.entities.DepartmentItem.delete(id);
    setItems(items.filter(i => i.id !== id));
    if (item) logActivity(project?.id, 'department_item', item.item_name, 'deleted', deptKey);
  };

  const doExport = () => {
    exportCSV(filtered.map(i => {
      let meta = {};
      try { meta = JSON.parse(i.metadata_json || '{}'); } catch { /* ignore */ }
      const row = {
        item: i.item_name, category: i.category, qty: i.quantity,
        scene: sceneLabel(i.assigned_scene_id),
        procurement_status: i.procurement_status || i.status || 'needed',
        asset_type: i.rental_type || 'purchase',
        asset_tag: i.asset_tag || '',
        condition_status: i.condition_status || '',
        vendor: i.source_vendor, unit_cost: i.unit_cost,
        total_cost: (i.unit_cost || 0) * (i.quantity || 1),
        storage_location: i.storage_location || '',
        po_number: i.po_number || '',
        order_date: i.order_date || '',
        expected_delivery: i.expected_delivery_date || '',
        rental_vendor: i.rental_vendor || '',
        rental_return_date: i.rental_return_date || '',
        rental_daily_rate: i.rental_daily_rate || 0,
        notes: i.notes,
      };
      metadataFields.forEach(f => { row[f.key] = meta[f.key] || ''; });
      return row;
    }), `${deptKey.toLowerCase().replace(/\s/g, '_')}_inventory.csv`);
  };

  const doImportCSV = async (file) => {
    const rows = await readCSVFile(file);
    const records = rows.map((row) => {
      const obj = { project_id: project.id, department: deptKey, status: 'needed', rental_type: 'purchase' };
      ITEM_FIELDS.forEach((f) => {
        const val = coerceValue(row[f.key] ?? row[f.label?.toLowerCase().replace(/ /g, '_')], f.type);
        if (val !== undefined) obj[f.key] = val;
      });
      // Pack department-specific metadata fields into metadata_json
      const meta = {};
      metadataFields.forEach(f => {
        const val = coerceValue(row[f.key], 'text');
        if (val !== undefined && val !== '') meta[f.key] = val;
      });
      obj.metadata_json = JSON.stringify(meta);
      if (obj.procurement_status) obj.status = obj.procurement_status;
      return obj;
    }).filter((r) => r.item_name);
    if (records.length) await base44.entities.DepartmentItem.bulkCreate(records);
    const refreshed = project ? await base44.entities.DepartmentItem.filter({ project_id: project.id, department: deptKey }) : await base44.entities.DepartmentItem.filter({ department: deptKey }, '-created_date', 500).then((all) => all.filter((i) => !i.project_id));
    setItems(refreshed);
    logActivity(project?.id || '', 'department_item', `${records.length} items`, 'created', `${deptKey}: CSV import`);
  };

  const saveItem = async (id, formData) => {
    const updateData = { ...formData };
    // Extract department-specific metadata fields into metadata_json
    const meta = {};
    metadataFields.forEach(f => {
      if (updateData[f.key] !== undefined) {
        meta[f.key] = updateData[f.key];
        delete updateData[f.key];
      }
    });
    updateData.metadata_json = JSON.stringify(meta);
    if (updateData.procurement_status) updateData.status = updateData.procurement_status;
    await base44.entities.DepartmentItem.update(id, updateData);
    setItems(items.map(i => i.id === id ? { ...i, ...updateData } : i));
    logActivity(project?.id || '', 'department_item', formData.item_name || '', 'updated', deptKey);
  };

  const openDrawer = (item) => {
    const expanded = { ...item };
    try {
      const meta = JSON.parse(item.metadata_json || '{}');
      metadataFields.forEach(f => { expanded[f.key] = meta[f.key] || ''; });
    } catch { /* ignore malformed metadata */ }
    setDrawer({ open: true, entity: expanded });
  };

  const deleteItemDrawer = async (id) => {
    const item = items.find(i => i.id === id);
    await base44.entities.DepartmentItem.delete(id);
    setItems(items.filter(i => i.id !== id));
    if (item) logActivity(project?.id || '', 'department_item', item.item_name, 'deleted', deptKey);
    setDrawer({ open: false, entity: null });
  };

  // Budget tracking
  const totalSpent = items.reduce((sum, i) => sum + (i.unit_cost || 0) * (i.quantity || 1), 0);
  const allocatedBudget = project ? Math.round((project.total_budget || 0) * (DEPARTMENT_BUDGET_WEIGHTS[deptKey] || 0) / 100) : 0;
  const budgetPct = allocatedBudget > 0 ? Math.round((totalSpent / allocatedBudget) * 100) : 0;
  const budgetAlert = allocatedBudget > 0 && budgetPct >= 80;

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#484f58]" size={18} /></div>;

  return (
    <div className="space-y-3">
      {/* Header with budget tracking */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Package size={14} style={{ color: dept.color }} />
          <span className="text-xs font-bold" style={{ color: dept.color }}>{deptKey} Inventory</span>
          <span className="text-[9px] text-[#484f58]">{items.length} items</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[10px] text-[#e6edf3]">
            <option value="all">All Status</option>
            {PROCUREMENT_STATUS_ORDER.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
          <select value={filterScene} onChange={e => setFilterScene(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[10px] text-[#e6edf3]">
            <option value="all">All Scenes</option>
            {scenes.map(s => <option key={s.id} value={s.id}>Scene {s.scene_number}</option>)}
          </select>
          <ImportExportBar onImportCSV={doImportCSV} onExportCSV={doExport} accent={dept.color} disabled={!items.length} />
          <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold text-black" style={{ background: dept.color }}><Plus size={10} /> Add</button>
        </div>
      </div>

      {/* Budget alert bar */}
      {allocatedBudget > 0 && (
        <div className={`glass-panel clip-corner p-2.5 flex items-center gap-2 ${budgetAlert ? 'border-l-2 border-[#fbbf24]' : 'border-l-2'}`} style={{ borderLeftColor: budgetAlert ? '#fbbf24' : `${dept.color}40` }}>
          {budgetAlert ? <AlertTriangle size={12} className="text-[#fbbf24]" /> : <ShoppingCart size={12} style={{ color: dept.color }} />}
          <span className="text-[9px] text-[#8b949e]">
            Spent <span className="text-[#e6edf3] font-bold">${totalSpent.toLocaleString()}</span> of <span style={{ color: dept.color }} className="font-bold">${allocatedBudget.toLocaleString()}</span> allocated
          </span>
          <div className="flex-1 h-1.5 bg-[#0d1117] rounded-sm overflow-hidden max-w-[200px]">
            <div className="h-full transition-all" style={{ width: `${Math.min(budgetPct, 100)}%`, background: budgetAlert ? '#fbbf24' : dept.color }} />
          </div>
          <span className={`text-[9px] font-bold ${budgetAlert ? 'text-[#fbbf24]' : 'text-[#8b949e]'}`}>{budgetPct}%</span>
        </div>
      )}

      {/* Add form */}
      {showAdd && (
        <div className="glass-panel clip-corner p-3 space-y-2 border-l-2" style={{ borderLeftColor: dept.color }}>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <input value={form.item_name} onChange={e => setForm({ ...form, item_name: e.target.value })} placeholder="Item name *" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] md:col-span-2" />
            <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              {dept.categories.map(c => <option key={c}>{c}</option>)}
            </select>
            <input type="number" value={form.quantity} onChange={e => setForm({ ...form, quantity: +e.target.value })} placeholder="Qty" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <select value={form.assigned_scene_id} onChange={e => setForm({ ...form, assigned_scene_id: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              <option value="">No scene assigned</option>
              {scenes.map(s => <option key={s.id} value={s.id}>Scene {s.scene_number}</option>)}
            </select>
            <select value={form.procurement_status} onChange={e => setForm({ ...form, procurement_status: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              {PROCUREMENT_STATUS_ORDER.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <input value={form.source_vendor} onChange={e => setForm({ ...form, source_vendor: e.target.value })} placeholder="Vendor/source" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="number" value={form.unit_cost} onChange={e => setForm({ ...form, unit_cost: +e.target.value })} placeholder="Unit cost $" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          </div>
          {/* PO tracking fields */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 border-t border-[#30363d] pt-2">
            <input value={form.storage_location} onChange={e => setForm({ ...form, storage_location: e.target.value })} placeholder="Storage location" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.po_number} onChange={e => setForm({ ...form, po_number: e.target.value })} placeholder="PO number" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="date" value={form.order_date} onChange={e => setForm({ ...form, order_date: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="date" value={form.expected_delivery_date} onChange={e => setForm({ ...form, expected_delivery_date: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          </div>
          {/* Asset type + gear tracking fields */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 border-t border-[#30363d] pt-2">
            <select value={form.rental_type} onChange={e => setForm({ ...form, rental_type: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              <option value="purchase">Purchase (consumable)</option>
              <option value="rental">Rental</option>
              <option value="studio_gear">Studio Gear (owned)</option>
            </select>
            <input value={form.asset_tag} onChange={e => setForm({ ...form, asset_tag: e.target.value })} placeholder="Asset tag / serial #" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <select value={form.condition_status} onChange={e => setForm({ ...form, condition_status: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              {CONDITION_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <input value={form.rental_vendor} onChange={e => setForm({ ...form, rental_vendor: e.target.value })} placeholder="Rental vendor" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <input type="date" value={form.rental_return_date} onChange={e => setForm({ ...form, rental_return_date: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="number" value={form.rental_daily_rate} onChange={e => setForm({ ...form, rental_daily_rate: +e.target.value })} placeholder="Daily rate $" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          </div>
          {/* Department-specific metadata fields */}
          {metadataFields.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 border-t border-[#30363d] pt-2">
              {metadataFields.map(f => (
                <input key={f.key} value={form[f.key] ?? ''} onChange={e => setForm({ ...form, [f.key]: e.target.value })} placeholder={f.label} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
              ))}
            </div>
          )}
          <input value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Notes" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          <div className="flex gap-2">
            <button onClick={addItem} className="px-3 py-1.5 rounded text-[10px] font-bold text-black" style={{ background: dept.color }}>Save Item</button>
            <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
          </div>
        </div>
      )}

      {/* Items list */}
      {!filtered.length ? (
        <div className="text-center py-8 text-[10px] text-[#484f58] italic">No items in inventory. Click "Add" to create one.</div>
      ) : (
        <div className="space-y-1.5">
          {filtered.map(item => {
            const ps = item.procurement_status || item.status || 'needed';
            const isExpanded = expandedItem === item.id;
            const totalCost = (item.unit_cost || 0) * (item.quantity || 1);
            return (
              <div key={item.id} className="glass-panel clip-corner overflow-hidden">
                <div className="p-2.5 flex items-center gap-3 group">
                  <button onClick={() => setExpandedItem(isExpanded ? null : item.id)} className="text-[#484f58] hover:text-[#e6edf3] shrink-0">
                    {isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                  </button>
                  <div className="flex-1 min-w-0 cursor-pointer" onClick={() => openDrawer(item)}>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-[#e6edf3] truncate hover:text-[#00f5ff] transition-colors">{item.item_name}</span>
                      <span className="text-[8px] px-1.5 py-0.5 rounded border" style={{ color: dept.color, borderColor: `${dept.color}40` }}>{item.category}</span>
                      {item.storage_location && <span className="text-[8px] flex items-center gap-0.5 text-[#58a6ff]"><MapPin size={8} /> {item.storage_location}</span>}
                      {item.po_number && <span className="text-[8px] px-1.5 py-0.5 rounded bg-[#fbbf24]/10 text-[#fbbf24]">PO: {item.po_number}</span>}
                      {item.rental_type === 'rental' && (
                        <span className="text-[8px] px-1.5 py-0.5 rounded bg-[#fbbf24]/15 text-[#fbbf24] flex items-center gap-0.5">
                          <Repeat size={8} /> Rental{item.rental_return_date ? ` · ret ${item.rental_return_date}` : ''}
                        </span>
                      )}
                      {item.rental_type === 'studio_gear' && (
                        <span className="text-[8px] px-1.5 py-0.5 rounded bg-[#4dd0e1]/15 text-[#4dd0e1] flex items-center gap-0.5">
                          <Package size={8} /> Gear{item.asset_tag ? ` · ${item.asset_tag}` : ''}
                        </span>
                      )}
                      {item.rental_type === 'studio_gear' && item.condition_status && item.condition_status !== 'new' && (
                        <span className="text-[8px] px-1 py-0.5 rounded border" style={{ color: CONDITION_COLORS[item.condition_status] || '#8b949e', borderColor: `${CONDITION_COLORS[item.condition_status] || '#8b949e'}40` }}>{item.condition_status}</span>
                      )}
                    </div>
                    <div className="text-[9px] text-[#8b949e] mt-0.5">
                      Qty: {item.quantity} · Scene: {sceneLabel(item.assigned_scene_id)} {item.source_vendor ? `· ${item.source_vendor}` : ''}
                      {item.unit_cost ? `· $${item.unit_cost}/ea ($${totalCost.toLocaleString()} total)` : ''}
                      {item.expected_delivery_date ? `· Delivery: ${item.expected_delivery_date}` : ''}
                    </div>
                  </div>
                  <select value={ps} onChange={e => updateProcurementStatus(item.id, e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-1.5 py-1 text-[9px] font-bold cursor-pointer" style={{ color: PROCUREMENT_STATUS_COLORS[ps] || '#8b949e' }}>
                    {PROCUREMENT_STATUS_ORDER.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                  <button onClick={() => deleteItem(item.id)} className="text-[#484f58] hover:text-[#f85149] transition-colors"><Trash2 size={12} /></button>
                </div>
                {/* Expanded PO detail */}
                {isExpanded && (
                  <div className="border-t border-[#30363d] p-3 bg-[#0d1117] grid grid-cols-2 md:grid-cols-4 gap-2">
                    <div>
                      <label className="text-[8px] text-[#484f58] uppercase block mb-0.5">Asset Tag / Serial</label>
                      <input value={item.asset_tag || ''} onChange={e => updateItemField(item.id, 'asset_tag', e.target.value)} placeholder="AZ-001" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[9px] text-[#e6edf3]" />
                    </div>
                    <div>
                      <label className="text-[8px] text-[#484f58] uppercase block mb-0.5">Condition</label>
                      <select value={item.condition_status || 'new'} onChange={e => updateItemField(item.id, 'condition_status', e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[9px] text-[#e6edf3]">
                        {CONDITION_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-[8px] text-[#484f58] uppercase block mb-0.5">Storage Location</label>
                      <input value={item.storage_location || ''} onChange={e => updateItemField(item.id, 'storage_location', e.target.value)} placeholder="Warehouse / Truck / Stage" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[9px] text-[#e6edf3]" />
                    </div>
                    <div>
                      <label className="text-[8px] text-[#484f58] uppercase block mb-0.5">PO Number</label>
                      <input value={item.po_number || ''} onChange={e => updateItemField(item.id, 'po_number', e.target.value)} placeholder="PO-001" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[9px] text-[#e6edf3]" />
                    </div>
                    <div>
                      <label className="text-[8px] text-[#484f58] uppercase block mb-0.5">Order Date</label>
                      <input type="date" value={item.order_date || ''} onChange={e => updateItemField(item.id, 'order_date', e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[9px] text-[#e6edf3]" />
                    </div>
                    <div>
                      <label className="text-[8px] text-[#484f58] uppercase block mb-0.5">Expected Delivery</label>
                      <input type="date" value={item.expected_delivery_date || ''} onChange={e => updateItemField(item.id, 'expected_delivery_date', e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[9px] text-[#e6edf3]" />
                    </div>
                    {item.notes && <div className="md:col-span-4 text-[9px] text-[#8b949e] italic">Notes: {item.notes}</div>}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <EntityDetailDrawer
        open={drawer.open}
        entity={drawer.entity}
        entityName="DepartmentItem"
        fields={ITEM_FIELDS}
        titleKey="item_name"
        accent={dept.color}
        extraSections={metadataFields.length > 0 ? [{ title: `${deptKey} Details`, accent: dept.color, fields: metadataFields }] : []}
        onClose={() => setDrawer({ open: false, entity: null })}
        onSave={saveItem}
        onDelete={deleteItemDrawer}
        exportRows={(entity) => {
          let meta = {};
          try { meta = JSON.parse(entity.metadata_json || '{}'); } catch { /* ignore */ }
          const row = {
            item: entity.item_name, category: entity.category, qty: entity.quantity,
            procurement_status: entity.procurement_status || entity.status || 'needed',
            asset_type: entity.rental_type || 'purchase',
            asset_tag: entity.asset_tag || '',
            condition_status: entity.condition_status || '',
            vendor: entity.source_vendor, unit_cost: entity.unit_cost,
            total_cost: (entity.unit_cost || 0) * (entity.quantity || 1),
            storage_location: entity.storage_location || '',
            po_number: entity.po_number || '',
            order_date: entity.order_date || '',
            expected_delivery: entity.expected_delivery_date || '',
            rental_vendor: entity.rental_vendor || '',
            rental_return_date: entity.rental_return_date || '',
            rental_daily_rate: entity.rental_daily_rate || 0,
            notes: entity.notes,
          };
          metadataFields.forEach(f => { row[f.key] = meta[f.key] || ''; });
          return [row];
        }}
        exportFilename={`${deptKey.toLowerCase().replace(/\s/g, '_')}_${drawer.entity?.item_name || 'item'}.csv`}
      />
    </div>
  );
}