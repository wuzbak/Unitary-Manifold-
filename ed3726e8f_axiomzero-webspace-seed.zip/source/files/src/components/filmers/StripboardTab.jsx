/**
 * StripboardTab — Shooting schedule stripboard + Day-Out-Of-Days matrix.
 * Scenes assigned to shoot days, auto-sort, DOOD grid.
 */
import { useState, useEffect, useCallback } from 'react';
import { Calendar, Plus, Trash2, Loader2, Clock, MapPin, Film, Grid3x3, Download, RefreshCw } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { autoSortScenes, generateStripboard, generateDOOD, DOOD_LABELS } from '@/lib/filmers/schedulingEngine';
import { exportCSV } from '@/lib/filmers/filmExport';
import { logActivity } from '@/lib/filmers/activityLog';

export default function StripboardTab({ project }) {
  const [scenes, setScenes] = useState([]);
  const [shootDays, setShootDays] = useState([]);
  const [cast, setCast] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState('stripboard'); // 'stripboard' | 'dood'
  const [showAddDay, setShowAddDay] = useState(false);
  const [newDay, setNewDay] = useState({ date: '', crew_call: '07:00', shooting_call: '08:00', lunch: '12:00', location_name: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [s, d, c] = await Promise.all([
        base44.entities.Scene.filter({ project_id: project.id }, 'sort_order', 500),
        base44.entities.ShootDay.filter({ project_id: project.id }, 'day_number', 200),
        base44.entities.CastMember.filter({ project_id: project.id }),
      ]);
      setScenes(s); setShootDays(d); setCast(c);
    } catch { /* best-effort */ }
    finally { setLoading(false); }
  }, [project.id]);

  useEffect(() => { load(); }, [load]);

  const addDay = async () => {
    if (!newDay.date) return;
    const dayNumber = shootDays.length + 1;
    const created = await base44.entities.ShootDay.create({
      ...newDay,
      project_id: project.id,
      day_number: dayNumber,
      status: 'scheduled',
      scenes_json: '[]',
    });
    setShootDays([...shootDays, created]);
    logActivity(project.id, 'schedule', `Day ${dayNumber}`, 'created', newDay.date);
    setNewDay({ date: '', crew_call: '07:00', shooting_call: '08:00', lunch: '12:00', location_name: '' });
    setShowAddDay(false);
  };

  const deleteDay = async (id) => {
    await base44.entities.ShootDay.delete(id);
    setShootDays(shootDays.filter(d => d.id !== id));
    logActivity(project.id, 'schedule', '', 'deleted');
  };

  const assignSceneToDay = async (dayId, sceneId) => {
    const day = shootDays.find(d => d.id === dayId);
    if (!day) return;
    let sceneIds = [];
    try { sceneIds = JSON.parse(day.scenes_json || '[]'); } catch {}
    if (sceneIds.includes(sceneId)) return; // already assigned
    sceneIds.push(sceneId);
    await base44.entities.ShootDay.update(dayId, { scenes_json: JSON.stringify(sceneIds) });
    setShootDays(shootDays.map(d => d.id === dayId ? { ...d, scenes_json: JSON.stringify(sceneIds) } : d));
  };

  const removeSceneFromDay = async (dayId, sceneId) => {
    const day = shootDays.find(d => d.id === dayId);
    if (!day) return;
    let sceneIds = [];
    try { sceneIds = JSON.parse(day.scenes_json || '[]'); } catch {}
    sceneIds = sceneIds.filter(id => id !== sceneId);
    await base44.entities.ShootDay.update(dayId, { scenes_json: JSON.stringify(sceneIds) });
    setShootDays(shootDays.map(d => d.id === dayId ? { ...d, scenes_json: JSON.stringify(sceneIds) } : d));
  };

  const autoSchedule = () => {
    // Auto-assign scenes to days using stripboard algorithm
    const stripboard = generateStripboard(scenes);
    // For each stripboard day, create or update a ShootDay
    // This is a suggestion — user can adjust
    stripboard.forEach(async (sbDay, idx) => {
      const existing = shootDays[idx];
      const sceneIds = sbDay.scenes.map(s => s.id);
      if (existing) {
        await base44.entities.ShootDay.update(existing.id, {
          scenes_json: JSON.stringify(sceneIds),
          location_name: sbDay.location,
          int_ext: sbDay.int_ext,
          day_night: sbDay.day_night,
          estimated_pages: sbDay.pages,
        });
      }
    });
    load();
    logActivity(project.id, 'schedule', 'Auto-schedule', 'generated', `${stripboard.length} days`);
  };

  const exportStripboard = () => {
    const rows = shootDays.map(d => {
      let sceneIds = [];
      try { sceneIds = JSON.parse(d.scenes_json || '[]'); } catch {}
      const dayScenes = sceneIds.map(id => scenes.find(s => s.id === id)).filter(Boolean);
      return {
        day: d.day_number,
        date: d.date,
        location: d.location_name,
        int_ext: d.int_ext,
        day_night: d.day_night,
        crew_call: d.crew_call,
        shooting_call: d.shooting_call,
        lunch: d.lunch,
        scenes: dayScenes.map(s => `${s.scene_number}`).join(','),
        pages: d.estimated_pages,
        status: d.status,
      };
    });
    exportCSV(rows, 'stripboard.csv');
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#f472b6]" size={18} /></div>;

  const unassignedScenes = scenes.filter(s => !shootDays.some(d => {
    let ids = [];
    try { ids = JSON.parse(d.scenes_json || '[]'); } catch {}
    return ids.includes(s.id);
  }));

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Calendar size={14} className="text-[#f472b6]" />
          <span className="text-xs font-bold text-[#f472b6]">Scheduling</span>
          <span className="text-[9px] text-[#484f58]">{shootDays.length} days · {scenes.length} scenes · {unassignedScenes.length} unassigned</span>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <button onClick={() => setView('stripboard')} className={`flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border ${view === 'stripboard' ? 'bg-[#f472b6] text-black border-transparent' : 'border-[#30363d] text-[#8b949e]'}`}>
            <Calendar size={10} /> Stripboard
          </button>
          <button onClick={() => setView('dood')} className={`flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border ${view === 'dood' ? 'bg-[#f472b6] text-black border-transparent' : 'border-[#30363d] text-[#8b949e]'}`}>
            <Grid3x3 size={10} /> Day-Out-Of-Days
          </button>
          <button onClick={autoSchedule} disabled={!scenes.length} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#3fb950]/20 border border-[#3fb950]/40 text-[#3fb950] hover:bg-[#3fb950]/30 disabled:opacity-40">
            <RefreshCw size={10} /> Auto-Schedule
          </button>
          <button onClick={exportStripboard} disabled={!shootDays.length} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] disabled:opacity-40">
            <Download size={10} /> CSV
          </button>
          <button onClick={() => setShowAddDay(!showAddDay)} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#f472b6] text-black">
            <Plus size={10} /> Add Day
          </button>
        </div>
      </div>

      {/* Add day form */}
      {showAddDay && (
        <div className="glass-panel clip-corner p-3 border-l-2 border-[#f472b6]">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
            <input type="date" value={newDay.date} onChange={e => setNewDay({ ...newDay, date: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="time" value={newDay.crew_call} onChange={e => setNewDay({ ...newDay, crew_call: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="time" value={newDay.shooting_call} onChange={e => setNewDay({ ...newDay, shooting_call: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="time" value={newDay.lunch} onChange={e => setNewDay({ ...newDay, lunch: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={newDay.location_name} onChange={e => setNewDay({ ...newDay, location_name: e.target.value })} placeholder="Location" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          </div>
          <div className="flex gap-2 mt-2">
            <button onClick={addDay} className="px-3 py-1.5 bg-[#f472b6] text-black rounded text-[10px] font-bold">Save Day</button>
            <button onClick={() => setShowAddDay(false)} className="px-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
          </div>
        </div>
      )}

      {/* Stripboard view */}
      {view === 'stripboard' && (
        <div className="space-y-3">
          {/* Unassigned scenes pool */}
          {unassignedScenes.length > 0 && (
            <div className="glass-panel clip-corner p-3">
              <div className="flex items-center gap-2 mb-2">
                <Film size={12} className="text-[#fbbf24]" />
                <span className="text-[10px] font-bold text-[#fbbf24]">Unassigned Scenes ({unassignedScenes.length})</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {unassignedScenes.map(s => (
                  <div key={s.id} className="px-2 py-1 bg-[#161b22] border border-[#30363d] rounded text-[9px] text-[#e6edf3]">
                    <span className="text-[#fbbf24] font-bold">{s.scene_number}</span> {s.int_ext}/{s.day_night} {s.location_text} ({s.pages}p)
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Day strips */}
          {shootDays.length === 0 ? (
            <div className="glass-panel clip-corner p-8 text-center">
              <Calendar size={28} className="text-[#484f58] mx-auto mb-3" />
              <p className="text-xs text-[#8b949e] mb-2">No shoot days scheduled yet.</p>
              <p className="text-[10px] text-[#484f58]">Click "Add Day" to create one, or "Auto-Schedule" to auto-assign scenes.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {shootDays.map(day => {
                let daySceneIds = [];
                try { daySceneIds = JSON.parse(day.scenes_json || '[]'); } catch {}
                const dayScenes = daySceneIds.map(id => scenes.find(s => s.id === id)).filter(Boolean);
                return (
                  <div key={day.id} className="glass-panel clip-corner overflow-hidden">
                    {/* Day header */}
                    <div className="flex items-center gap-3 p-2.5 bg-[#161b22] border-b border-[#30363d]">
                      <span className="text-xs font-bold text-[#f472b6]">Day {day.day_number}</span>
                      <span className="text-[10px] text-[#e6edf3]">{day.date}</span>
                      {day.location_name && <span className="text-[9px] text-[#34d399] flex items-center gap-0.5"><MapPin size={8} /> {day.location_name}</span>}
                      <span className="text-[8px] text-[#484f58]">{day.int_ext}/{day.day_night}</span>
                      <span className="text-[8px] text-[#484f58] flex items-center gap-0.5"><Clock size={8} /> {day.crew_call}</span>
                      <span className="text-[8px] text-[#484f58]">{day.estimated_pages}p</span>
                      <select value={day.status} onChange={async e => { await base44.entities.ShootDay.update(day.id, { status: e.target.value }); setShootDays(shootDays.map(d => d.id === day.id ? { ...d, status: e.target.value } : d)); }}
                        className="ml-auto bg-[#0B0F13] border border-[#30363d] rounded px-1.5 py-0.5 text-[8px] font-bold text-[#8b949e]">
                        <option value="scheduled">scheduled</option>
                        <option value="shooting">shooting</option>
                        <option value="wrapped">wrapped</option>
                        <option value="cancelled">cancelled</option>
                        <option value="rained_out">rained_out</option>
                      </select>
                      <button onClick={() => deleteDay(day.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={11} /></button>
                    </div>
                    {/* Scene strips */}
                    <div className="p-2 space-y-1">
                      {dayScenes.length === 0 ? (
                        <p className="text-[9px] text-[#484f58] italic py-1">No scenes assigned. Select from unassigned pool below.</p>
                      ) : (
                        dayScenes.map(s => (
                          <div key={s.id} className="flex items-center gap-2 px-2 py-1.5 bg-[#0d1117] border-l-2 border-[#f472b6] rounded-sm">
                            <span className="text-[9px] font-bold text-[#f472b6] w-8">{s.scene_number}</span>
                            <span className="text-[8px] text-[#8b949e]">{s.int_ext}/{s.day_night}</span>
                            <span className="text-[10px] text-[#e6edf3] flex-1 truncate">{s.location_text || s.synopsis}</span>
                            <span className="text-[8px] text-[#484f58]">{s.pages}p</span>
                            <button onClick={() => removeSceneFromDay(day.id, s.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={9} /></button>
                          </div>
                        ))
                      )}
                      {/* Quick assign dropdown */}
                      {unassignedScenes.length > 0 && (
                        <select value="" onChange={e => { if (e.target.value) assignSceneToDay(day.id, e.target.value); }}
                          className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[9px] text-[#8b949e]">
                          <option value="">+ Assign scene...</option>
                          {unassignedScenes.map(s => <option key={s.id} value={s.id}>Scene {s.scene_number} — {s.location_text} ({s.pages}p)</option>)}
                        </select>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* DOOD view */}
      {view === 'dood' && (
        <div className="glass-panel clip-corner p-3 overflow-x-auto">
          {shootDays.length === 0 || cast.length === 0 ? (
            <p className="text-[10px] text-[#484f58] italic text-center py-8">Need shoot days and cast members to generate Day-Out-Of-Days.</p>
          ) : (
            <table className="text-[9px]">
              <thead>
                <tr className="border-b border-[#30363d]">
                  <th className="text-left p-1.5 sticky left-0 bg-[#0d1117] z-10">Cast Member</th>
                  <th className="text-left p-1.5">Role</th>
                  {shootDays.map(d => <th key={d.id} className="text-center p-1.5 text-[#f472b6]">D{d.day_number}</th>)}
                  <th className="text-right p-1.5">Days</th>
                </tr>
              </thead>
              <tbody>
                {cast.map(member => {
                  const workDays = shootDays.map((day, idx) => {
                    let sceneIds = [];
                    try { sceneIds = JSON.parse(day.scenes_json || '[]'); } catch {}
                    const dayScenes = sceneIds.map(id => scenes.find(s => s.id === id)).filter(Boolean);
                    const charName = (member.role || member.name || '').toUpperCase();
                    return dayScenes.some(s => (s.synopsis || '').toUpperCase().includes(charName)) ? 'W' : '-';
                  });
                  const dayCount = workDays.filter(d => d === 'W').length;
                  return (
                    <tr key={member.id} className="border-b border-[#30363d]/50 hover:bg-[#161b22]">
                      <td className="p-1.5 text-[#e6edf3] font-bold sticky left-0 bg-[#0d1117] z-10">{member.name}</td>
                      <td className="p-1.5 text-[#fbbf24]">{member.role}</td>
                      {workDays.map((status, idx) => (
                        <td key={idx} className="text-center p-1.5">
                          <span className="inline-block w-5 h-5 leading-5 rounded font-bold text-[8px]"
                            style={{ background: status === 'W' ? DOOD_LABELS.W.color + '30' : 'transparent', color: status === 'W' ? DOOD_LABELS.W.color : '#484f58' }}>
                            {status}
                          </span>
                        </td>
                      ))}
                      <td className="text-right p-1.5 text-[#3fb950] font-bold">{dayCount}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  );
}