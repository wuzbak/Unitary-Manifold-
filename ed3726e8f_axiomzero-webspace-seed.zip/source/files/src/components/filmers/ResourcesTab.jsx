/**
 * ResourcesTab — Open-source and public domain resource library.
 * Categorized links to software, archives, music, images, and educational resources.
 */
import { Code2, ClipboardList, Film, Music, Archive, Volume2, Image as ImageIcon, GraduationCap, ExternalLink } from 'lucide-react';
import { RESOURCE_CATEGORIES } from '@/lib/filmers/resources';

const ICON_MAP = { Code2, ClipboardList, Film, Music, Archive, Volume2, Image: ImageIcon, GraduationCap };

export default function ResourcesTab() {
  return (
    <div className="space-y-4">
      <div className="glass-strong clip-corner p-4">
        <h2 className="text-sm font-bold text-[#e6edf3] mb-1">Production Resource Library</h2>
        <p className="text-[10px] text-[#8b949e]">Open-source tools, public domain archives, Creative Commons music, and educational resources for film and television production. All entries verified and linked.</p>
      </div>
      {RESOURCE_CATEGORIES.map(cat => {
        const Icon = ICON_MAP[cat.icon] || Film;
        return (
          <div key={cat.title} className="glass-strong clip-corner p-4">
            <div className="flex items-center gap-2 mb-3">
              <Icon size={14} style={{ color: cat.color }} />
              <span className="text-xs font-bold" style={{ color: cat.color }}>{cat.title}</span>
              <span className="text-[8px] text-[#484f58]">({cat.resources.length})</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {cat.resources.map(r => (
                <a key={r.name} href={r.url} target="_blank" rel="noopener noreferrer" className="glass-panel clip-corner p-2.5 glow-hover block group">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-[#e6edf3] group-hover:text-[#58a6ff] transition-colors">{r.name}</span>
                    <ExternalLink size={10} className="text-[#484f58] group-hover:text-[#58a6ff] transition-colors" />
                  </div>
                  <p className="text-[9px] text-[#8b949e] leading-relaxed">{r.desc}</p>
                </a>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}