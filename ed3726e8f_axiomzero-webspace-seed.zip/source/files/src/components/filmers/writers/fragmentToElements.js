/**
 * fragmentToElements — Converts a StoryFragment into screenplay elements
 * using the fountainSerializer element model.
 */
import { genId } from '@/lib/filmers/fountainSerializer';

export const FRAGMENT_TYPES = [
  { id: 'character', label: 'Character', color: '#fbbf24' },
  { id: 'scene', label: 'Scene', color: '#a78bfa' },
  { id: 'outline', label: 'Outline Beat', color: '#4dd0e1' },
  { id: 'theme', label: 'Theme', color: '#bc8cff' },
  { id: 'location', label: 'Location', color: '#34d399' },
  { id: 'prop', label: 'Prop', color: '#58a6ff' },
  { id: 'dialogue', label: 'Dialogue', color: '#f472b6' },
];

export const FRAGMENT_TYPE_MAP = Object.fromEntries(FRAGMENT_TYPES.map((t) => [t.id, t]));

/**
 * Convert a single fragment into one or more screenplay elements.
 */
export function fragmentToElements(fragment) {
  const { type, title, content } = fragment;
  const t = (title || '').trim();
  const c = (content || '').trim();
  switch (type) {
    case 'character':
      return [{ id: genId(), type: 'character', text: (t || 'CHARACTER').toUpperCase(), scene_index: -1 }];
    case 'scene':
      return [{ id: genId(), type: 'scene', text: c || t || 'INT. LOCATION - DAY', scene_index: -1 }];
    case 'dialogue':
      return [
        { id: genId(), type: 'character', text: (t || 'CHARACTER').toUpperCase(), scene_index: -1 },
        { id: genId(), type: 'dialogue', text: c, scene_index: -1 },
      ];
    case 'outline':
      return [{ id: genId(), type: 'action', text: c || t, scene_index: -1 }];
    case 'theme':
      return [{ id: genId(), type: 'note', text: `[THEME] ${t}: ${c}`.replace(': ', '').trim(), scene_index: -1 }];
    case 'location':
      return [{ id: genId(), type: 'scene', text: `EXT. ${(t || 'LOCATION').toUpperCase()} - DAY`, scene_index: -1 }];
    case 'prop':
      return [{ id: genId(), type: 'action', text: `${t}: ${c}`.replace(': ', '').trim(), scene_index: -1 }];
    default:
      return [{ id: genId(), type: 'action', text: c || t, scene_index: -1 }];
  }
}

/**
 * Convert an ordered array of fragments into a flat elements array.
 */
export function fragmentsToElements(fragments) {
  const all = [];
  for (const f of fragments) {
    const els = fragmentToElements(f);
    all.push(...els);
  }
  // Assign scene_index sequentially
  let sceneIdx = -1;
  for (const el of all) {
    if (el.type === 'scene') sceneIdx++;
    el.scene_index = sceneIdx < 0 ? 0 : sceneIdx;
  }
  return all;
}