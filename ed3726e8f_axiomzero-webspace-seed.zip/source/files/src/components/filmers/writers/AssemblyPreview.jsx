/**
 * AssemblyPreview — Right panel of the Writers Room showing the assembled
 * script elements in screenplay format, with spawn/link actions.
 */
import { useState } from 'react';
import { X, FileText, Link2, Loader2, ArrowUp, ArrowDown } from 'lucide-react';
import { TYPE_COLORS } from '@/lib/filmers/fountainSerializer';
import { FRAGMENT_TYPE_MAP, fragmentsToElements } from './fragmentToElements';

export default function AssemblyPreview({ assemblyFragments, scripts, onRemove, onReorder, onSpawn, onLink, saving }) {
  const elements = fragmentsToElements(assemblyFragments);

  return (
    <div className="glass-strong clip-corner flex flex-col h-full">
      <div className="flex items-center justify-between p-3 border-b border-[#30363d] shrink-0">
        <div className="flex items-center gap-2">
          <FileText size={13} className="text-[#a78bfa]" />
          <span className="text-[11px] font-bold text-[#a78bfa]">Script Assembly</span>
          <span className="text-[9px] text-[#484f58]">{assemblyFragments.length} fragments · {elements.length} elements</span>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={onSpawn}
            disabled={!assemblyFragments.length || saving}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[9px] font-bold bg-[#a78bfa] text-black hover:opacity-80 disabled:opacity-40 transition-opacity"
          >
            {saving ? <Loader2 size={10} className="animate-spin" /> : <FileText size={10} />} Spawn Script
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-1 min-h-0">
        {!assemblyFragments.length ? (
          <div className="text-center py-12">
            <FileText size={24} className="text-[#484f58] mx-auto mb-2" />
            <p className="text-[10px] text-[#484f58]">Add fragments from the board to assemble a script.</p>
          </div>
        ) : (
          assemblyFragments.map((frag, idx) => {
            const typeInfo = FRAGMENT_TYPE_MAP[frag.type] || FRAGMENT_TYPE_MAP.outline;
            const els = fragmentsToElements([frag]);
            return (
              <div key={idx} className="glass-panel clip-corner p-2 border-l-2" style={{ borderLeftColor: typeInfo.color }}>
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="text-[8px] px-1 py-0.5 rounded font-bold uppercase" style={{ color: typeInfo.color, background: `${typeInfo.color}15` }}>
                    {typeInfo.label}
                  </span>
                  <span className="text-[9px] text-[#e6edf3] truncate flex-1">{frag.title || frag.content?.slice(0, 40) || 'Untitled'}</span>
                  <button onClick={() => onReorder(idx, -1)} disabled={idx === 0} className="text-[#484f58] hover:text-[#e6edf3] disabled:opacity-20"><ArrowUp size={9} /></button>
                  <button onClick={() => onReorder(idx, 1)} disabled={idx === assemblyFragments.length - 1} className="text-[#484f58] hover:text-[#e6edf3] disabled:opacity-20"><ArrowDown size={9} /></button>
                  <button onClick={() => onRemove(idx)} className="text-[#484f58] hover:text-[#f85149]"><X size={10} /></button>
                </div>
                <div className="pl-2 space-y-0.5">
                  {els.map((el, i) => (
                    <div key={i} className="text-[9px] leading-snug" style={{ color: TYPE_COLORS[el.type] || '#e6edf3' }}>
                      {el.type === 'character' && <span className="font-bold uppercase">{el.text}</span>}
                      {el.type === 'scene' && <span className="font-bold uppercase">{el.text}</span>}
                      {el.type === 'dialogue' && <span>{el.text}</span>}
                      {el.type === 'action' && <span>{el.text}</span>}
                      {el.type === 'note' && <span className="italic text-[#8b949e]">[[{el.text}]]</span>}
                      {el.type === 'parenthetical' && <span>({el.text})</span>}
                    </div>
                  ))}
                </div>
              </div>
            );
          })
        )}
      </div>

      {scripts?.length > 0 && (
        <div className="p-3 border-t border-[#30363d] shrink-0">
          <LinkToScriptControl scripts={scripts} onLink={onLink} disabled={!assemblyFragments.length || saving} />
        </div>
      )}
    </div>
  );
}

function LinkToScriptControl({ scripts, onLink, disabled }) {
  const [scriptId, setScriptId] = useState('');
  return (
    <div className="flex items-center gap-1.5">
      <Link2 size={11} className="text-[#4dd0e1] shrink-0" />
      <select value={scriptId} onChange={(e) => setScriptId(e.target.value)} className="flex-1 min-w-0 bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[9px] text-[#e6edf3]">
        <option value="">Link to existing script…</option>
        {scripts.map((s) => <option key={s.id} value={s.id}>{s.title}</option>)}
      </select>
      <button
        onClick={() => { if (scriptId) onLink(scriptId); setScriptId(''); }}
        disabled={!scriptId || disabled}
        className="px-2.5 py-1.5 rounded text-[9px] font-bold border border-[#4dd0e1]/30 text-[#4dd0e1] bg-[#4dd0e1]/10 hover:bg-[#4dd0e1]/20 disabled:opacity-40 transition-colors"
      >
        Merge
      </button>
    </div>
  );
}