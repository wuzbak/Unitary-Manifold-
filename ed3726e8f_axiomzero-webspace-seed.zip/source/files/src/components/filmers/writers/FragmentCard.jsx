/**
 * FragmentCard — A single story fragment card on the Writers Room board.
 * Supports selection (multi-select) and drag handle.
 */
import { GripVertical, Trash2, ArrowRight } from 'lucide-react';
import { FRAGMENT_TYPE_MAP } from './fragmentToElements';

export default function FragmentCard({ fragment, selected, onSelect, onAddToAssembly, onDelete, isDragging }) {
  const typeInfo = FRAGMENT_TYPE_MAP[fragment.type] || FRAGMENT_TYPE_MAP.outline;
  const tags = (() => { try { return JSON.parse(fragment.tags_json || '[]'); } catch { return []; } })();

  return (
    <div
      className={`glass-panel clip-corner p-2.5 border-l-2 transition-all ${selected ? 'ring-1 ring-[#a78bfa]/50' : ''} ${isDragging ? 'opacity-50' : ''}`}
      style={{ borderLeftColor: typeInfo.color }}
    >
      <div className="flex items-start gap-1.5">
        <span className="text-[#484f58] cursor-grab active:cursor-grabbing pt-0.5 shrink-0">
          <GripVertical size={11} />
        </span>
        <button onClick={() => onSelect(fragment.id)} className="flex-1 min-w-0 text-left">
          <div className="flex items-center gap-1.5 mb-0.5">
            <span className="text-[8px] px-1 py-0.5 rounded font-bold uppercase" style={{ color: typeInfo.color, background: `${typeInfo.color}15` }}>
              {typeInfo.label}
            </span>
            {tags.slice(0, 2).map((t, i) => (
              <span key={i} className="text-[7px] px-1 py-0.5 rounded bg-[#30363d] text-[#8b949e]">{t}</span>
            ))}
          </div>
          {fragment.title && <div className="text-[11px] font-bold text-[#e6edf3] truncate">{fragment.title}</div>}
          {fragment.content && <div className="text-[9px] text-[#8b949e] line-clamp-2 leading-snug">{fragment.content}</div>}
        </button>
        <div className="flex flex-col gap-1 shrink-0">
          <button onClick={() => onAddToAssembly(fragment.id)} className="text-[#a78bfa] hover:text-[#c4b5fd] transition-colors" title="Add to assembly">
            <ArrowRight size={11} />
          </button>
          <button onClick={() => onDelete(fragment.id)} className="text-[#484f58] hover:text-[#f85149] transition-colors" title="Delete">
            <Trash2 size={10} />
          </button>
        </div>
      </div>
    </div>
  );
}