/**
 * SpecializedEntityGrid — Dedicated CRUD grid for specialized per-department
 * entities (WardrobeItem, CameraItem). Provides the same import/export/tracking
 * as DepartmentInventoryGrid but with hard-coded, department-specific schemas
 * (character/period/size for wardrobe, body/lens/serial for camera).
 */
import { useState, useEffect, useCallback } from 'react';
import { Plus, Trash2, Loader2, Package, Repeat, MapPin, ChevronDown, ChevronRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { PROCUREMENT_STATUS_COLORS, PROCUREMENT_STATUS_ORDER } from '@/lib/filmers/departments';
import { exportCSV } from '@/lib/filmers/filmExport';
import { readCSVFile, coerceValue } from '@/lib/filmers/csvImport';
import { logActivity } from '@/lib/filmers/activityLog';
import ImportExportBar from './ImportExportBar';
import EntityDetailDrawer from './EntityDetailDrawer';

const WARDROBE_CATEGORIES = ['Principal Wardrobe', 'Background Wardrobe', 'Costume Builds', 'Footwear', 'Accessories', 'Jewelry', 'Weather Gear'];
const CAMERA_CATEGORIES = ['Camera Bodies', 'Lenses', 'Filters', 'Matte Box', 'Follow Focus', 'Monitor', 'Media/Storage', 'Support Rig'];
const BUILD_STATUSES = ['concept', 'in-progress', 'fitted', 'complete', 'continuity-locked'];

export const SPECIALIZED_CONFIG = {
  Wardrobe: {
    entityName: 'WardrobeItem',
    titleKey: 'item_name',
    accent: '#a78bfa',
    label: 'Wardrobe',
    categories: WARDROBE_CATEGORIES,
    fields: [
      { key: 'item_name', label: 'Item Name', type: 'text', required: true },
      { key: 'character', label: 'Character', type: 'text' },
      { key: 'period', label: 'Period / Era', type: 'text' },
      { key: 'size', label: 'Size', type: 'text' },
      { key: 'category', label: 'Category', type: 'select', options: WARDROBE_CATEGORIES },
      { key: 'build_status', label: 'Build Status', type: 'select', options: BUILD_STATUSES },
      { key: 'continuity_photo_url', label: 'Continuity Photo URL', type: 'text' },
      { key: 'quantity', label: 'Quantity', type: 'number' },
      { key: 'procurement_status', label: 'Procurement Status', type: 'select', options: PROCUREMENT_STATUS_ORDER },
      { key: 'assigned_scene_id', label: 'Assigned Scene', type: 'text' },
      { key: 'unit_cost', label: 'Unit Cost', type: 'number' },
      { key: 'source_vendor', label: 'Vendor', type: 'text' },
      { key: 'rental_type', label: 'Rental Type', type: 'select', options: ['purchase', 'rental'] },
      { key: 'rental_vendor', label: 'Rental Vendor', type: 'text' },
      { key: 'rental_return_date', label: 'Rental Return Date', type: 'date' },
      { key: 'rental_daily_rate', label: 'Rental Daily Rate', type: 'number' },
      { key: 'storage_location', label: 'Storage Location', type: 'text' },
      { key: 'po_number', label: 'PO Number', type: 'text' },
      { key: 'order_date', label: 'Order Date', type: 'date' },
      { key: 'expected_delivery_date', label: 'Expected Delivery', type: 'date' },
      { key: 'notes', label: 'Notes', type: 'textarea' },
    ],
    // Fields shown in the compact add form (quick-add for makeup/wardrobe artists)
    quickFields: ['item_name', 'character', 'period', 'size', 'category', 'quantity', 'assigned_scene_id'],
    subtitleFields: ['character', 'period', 'size'],
  },
  Camera: {
    entityName: 'CameraItem',
    titleKey: 'item_name',
    accent: '#fbbf24',
    label: 'Camera',
    categories: CAMERA_CATEGORIES,
    fields: [
      { key: 'item_name', label: 'Item Name', type: 'text', required: true },
      { key: 'body', label: 'Camera Body', type: 'text' },
      { key: 'lens', label: 'Lens', type: 'text' },
      { key: 'serial', label: 'Serial', type: 'text' },
      { key: 'media_type', label: 'Media Type', type: 'text' },
      { key: 'kit_assignment', label: 'Kit Assignment', type: 'text' },
      { key: 'category', label: 'Category', type: 'select', options: CAMERA_CATEGORIES },
      { key: 'quantity', label: 'Quantity', type: 'number' },
      { key: 'procurement_status', label: 'Procurement Status', type: 'select', options: PROCUREMENT_STATUS_ORDER },
      { key: 'assigned_scene_id', label: 'Assigned Scene', type: 'text' },
      { key: 'unit_cost', label: 'Unit Cost', type: 'number' },
      { key: 'source_vendor', label: 'Vendor', type: 'text' },
      { key: 'rental_type', label: 'Rental Type', type: 'select', options: ['purchase', 'rental'] },
      { key: 'rental_vendor', label: 'Rental Vendor', type: 'text' },
      { key: 'rental_return_date', label: 'Rental Return Date', type: 'date' },
      { key: 'rental_daily_rate', label: 'Rental Daily Rate', type: 'number' },
      { key: 'storage_location', label: 'Storage Location', type: 'text' },
      { key: 'po_number', label: 'PO Number', type: 'text' },
      { key: 'order_date', label: 'Order Date', type: 'date' },
      { key: 'expected_delivery_date', label: 'Expected Delivery', type: 'date' },
      { key: 'notes', label: 'Notes', type: 'textarea' },
    ],
    quickFields: ['item_name', 'body', 'lens', 'serial', 'kit_assignment', 'category', 'quantity'],
    subtitleFields: ['body', 'lens', 'serial'],
  },
};

export default function SpecializedEntityGrid({ project, deptKey }) {
  const config = SPECIALIZED_CONFIG[deptKey];
  const [items, setItems] = useState([]);
  const [scenes, setScenes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('all');
  const [showAdd, setShowAdd] = useState(false);
  const [expandedItem, setExpandedItem] = useState(null);
  const [drawer, setDrawer] = useState({ open: false, entity: null });
  const [form, setForm] = useState({});

  const initForm = useCallback(() => {
    const f = {};
    config.fields.forEach((field) => {
      f[field.key] = field.type === 'number' ? 0 : field.key === 'rental_type' ? (deptKey === 'Camera' ? 'rental' : 'purchase') : '';
    });
    f.quantity = 1;
    f.procurement_status = 'needed';
    f.category = config.categories[0];
    return f;
  }, [config, deptKey]);

  useEffect(() => {
    setForm(initForm());
  }, [initForm]);

  const load = useCallback(async () => {
    if (!project) { setLoading(false); return; }
    setLoading(true);
    try {
      const [entityItems, sceneList] = await Promise.all([
        base44.entities[config.entityName].filter({ project_id: project.id }),
        base44.entities.Scene.filter({ project_id: project.id }, 'sort_order', 500),
      ]);
      setItems(entityItems);
      setScenes(sceneList);
    } catch (e) { console.error(`${config.entityName} load failed:`, e); }
    setLoading(false);
  }, [project?.id, config.entityName]);

  useEffect(() => { load(); }, [load]);

  const filtered = items.filter(i => filterStatus === 'all' || (i.procurement_status || 'needed') === filterStatus);
  const sceneLabel = (id) => scenes.find(s => s.id === id)?.scene_number || (id ? `Scene ${id.slice(-4)}` : '—');

  const addItem = async () => {
    if (!form.item_name?.trim() || !project) return;
    const payload = { ...form, project_id: project.id };
    if (payload.procurement_status) payload.status = payload.procurement_status;
    const created = await base44.entities[config.entityName].create(payload);
    setItems([...items, created]);
    logActivity(project.id, config.entityName.toLowerCase(), form.item_name, 'created', deptKey);
    setForm(initForm());
    setShowAdd(false);
  };

  const updateProcurementStatus = async (id, procurement_status) => {
    const updated = await base44.entities[config.entityName].update(id, { procurement_status, status: procurement_status });
    setItems(items.map(i => i.id === id ? { ...i, ...updated } : i));
  };

  const deleteItem = async (id) => {
    const item = items.find(i => i.id === id);
    await base44.entities[config.entityName].delete(id);
    setItems(items.filter(i => i.id !== id));
    if (item) logActivity(project?.id, config.entityName.toLowerCase(), item.item_name, 'deleted', deptKey);
  };

  const saveItem = async (id, formData) => {
    const updateData = { ...formData };
    if (updateData.procurement_status) updateData.status = updateData.procurement_status;
    await base44.entities[config.entityName].update(id, updateData);
    setItems(items.map(i => i.id === id ? { ...i, ...updateData } : i));
    logActivity(project.id, config.entityName.toLowerCase(), formData.item_name || '', 'updated', deptKey);
  };

  const deleteItemDrawer = async (id) => {
    await deleteItem(id);
    setDrawer({ open: false, entity: null });
  };

  const doExport = () => {
    exportCSV(filtered.map(i => {
      const row = { item: i.item_name };
      config.fields.forEach(f => { if (f.key !== 'item_name') row[f.key] = i[f.key] ?? ''; });
      row.scene = sceneLabel(i.assigned_scene_id);
      row.total_cost = (i.unit_cost || 0) * (i.quantity || 1);
      return row;
    }), `${deptKey.toLowerCase().replace(/\s/g, '_')}_specialized.csv`);
  };

  const doImportCSV = async (file) => {
    const rows = await readCSVFile(file);
    const records = rows.map((row) => {
      const obj = { project_id: project.id, status: 'needed', rental_type: deptKey === 'Camera' ? 'rental' : 'purchase' };
      config.fields.forEach((f) => {
        const val = coerceValue(row[f.key] ?? row[f.label?.toLowerCase().replace(/ /g, '_')], f.type);
        if (val !== undefined) obj[f.key] = val;
      });
      if (obj.procurement_status) obj.status = obj.procurement_status;
      return obj;
    }).filter((r) => r.item_name);
    if (records.length) await base44.entities[config.entityName].bulkCreate(records);
    await load();
    logActivity(project.id, config.entityName.toLowerCase(), `${records.length} items`, 'created', `${deptKey}: CSV import`);
  };

  if (!project) return (
    <div className="glass-panel clip-corner p-8 text-center">
      <Package size={28} className="text-[#484f58] mx-auto mb-3" />
      <p className="text-xs text-[#8b949e]">Select a project to manage {config.label} items.</p>
    </div>
  );

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#484f58]" size={18} /></div>;

  const totalSpent = items.reduce((sum, i) => sum + (i.unit_cost || 0) * (i.quantity || 1), 0);
  const rentalCount = items.filter(i => i.rental_type === 'rental').length;

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Package size={14} style={{ color: config.accent }} />
          <span className="text-xs font-bold" style={{ color: config.accent }}>{config.label} — Specialized Tracking</span>
          <span className="text-[9px] text-[#484f58]">{items.length} items · ${totalSpent.toLocaleString()} · {rentalCount} rentals</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[10px] text-[#e6edf3]">
            <option value="all">All Status</option>
            {PROCUREMENT_STATUS_ORDER.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
          <ImportExportBar onImportCSV={doImportCSV} onExportCSV={doExport} accent={config.accent} disabled={!items.length} />
          <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold text-black" style={{ background: config.accent }}><Plus size={10} /> Add</button>
        </div>
      </div>

      {/* Quick-add form (simple for artists) */}
      {showAdd && (
        <div className="glass-panel clip-corner p-3 space-y-2 border-l-2" style={{ borderLeftColor: config.accent }}>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {config.quickFields.map(fk => {
              const field = config.fields.find(f => f.key === fk);
              if (!field) return null;
              if (field.type === 'select') {
                return (
                  <select key={fk} value={form[fk] ?? ''} onChange={e => setForm({ ...form, [fk]: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
                    <option value="">{field.label}</option>
                    {field.options.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                );
              }
              if (fk === 'assigned_scene_id') {
                return (
                  <select key={fk} value={form[fk] ?? ''} onChange={e => setForm({ ...form, [fk]: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
                    <option value="">No scene</option>
                    {scenes.map(s => <option key={s.id} value={s.id}>Scene {s.scene_number}</option>)}
                  </select>
                );
              }
              return (
                <input
                  key={fk}
                  type={field.type === 'number' ? 'number' : 'text'}
                  value={form[fk] ?? ''}
                  onChange={e => setForm({ ...form, [fk]: field.type === 'number' ? (+e.target.value || 0) : e.target.value })}
                  placeholder={field.label + (field.required ? ' *' : '')}
                  className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]"
                />
              );
            })}
          </div>
          {/* Advanced fields collapsible */}
          <details className="text-[10px]">
            <summary className="text-[#484f58] cursor-pointer hover:text-[#e6edf3]">Advanced (cost, rental, PO, storage)</summary>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
              <input type="number" value={form.unit_cost ?? 0} onChange={e => setForm({ ...form, unit_cost: +e.target.value })} placeholder="Unit cost $" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
              <input value={form.source_vendor ?? ''} onChange={e => setForm({ ...form, source_vendor: e.target.value })} placeholder="Vendor" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
              <select value={form.rental_type ?? 'purchase'} onChange={e => setForm({ ...form, rental_type: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
                <option value="purchase">Purchase</option>
                <option value="rental">Rental</option>
              </select>
              <input value={form.rental_vendor ?? ''} onChange={e => setForm({ ...form, rental_vendor: e.target.value })} placeholder="Rental vendor" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
              <input type="date" value={form.rental_return_date ?? ''} onChange={e => setForm({ ...form, rental_return_date: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
              <input type="number" value={form.rental_daily_rate ?? 0} onChange={e => setForm({ ...form, rental_daily_rate: +e.target.value })} placeholder="Daily rate $" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
              <input value={form.storage_location ?? ''} onChange={e => setForm({ ...form, storage_location: e.target.value })} placeholder="Storage" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
              <input value={form.po_number ?? ''} onChange={e => setForm({ ...form, po_number: e.target.value })} placeholder="PO number" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            </div>
          </details>
          <input value={form.notes ?? ''} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Notes" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          <div className="flex gap-2">
            <button onClick={addItem} className="px-3 py-1.5 rounded text-[10px] font-bold text-black" style={{ background: config.accent }}>Save Item</button>
            <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
          </div>
        </div>
      )}

      {/* Items list */}
      {!filtered.length ? (
        <div className="text-center py-8 text-[10px] text-[#484f58] italic">No {config.label} items yet. Click "Add" to create one.</div>
      ) : (
        <div className="space-y-1.5">
          {filtered.map(item => {
            const ps = item.procurement_status || 'needed';
            const isExpanded = expandedItem === item.id;
            const totalCost = (item.unit_cost || 0) * (item.quantity || 1);
            const subtitle = config.subtitleFields.map(fk => item[fk]).filter(Boolean).join(' · ');
            return (
              <div key={item.id} className="glass-panel clip-corner overflow-hidden">
                <div className="p-2.5 flex items-center gap-3 group">
                  <button onClick={() => setExpandedItem(isExpanded ? null : item.id)} className="text-[#484f58] hover:text-[#e6edf3] shrink-0">
                    {isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                  </button>
                  <div className="flex-1 min-w-0 cursor-pointer" onClick={() => setDrawer({ open: true, entity: item })}>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-[#e6edf3] truncate hover:text-[#00f5ff] transition-colors">{item.item_name}</span>
                      <span className="text-[8px] px-1.5 py-0.5 rounded border" style={{ color: config.accent, borderColor: `${config.accent}40` }}>{item.category}</span>
                      {item.storage_location && <span className="text-[8px] flex items-center gap-0.5 text-[#58a6ff]"><MapPin size={8} /> {item.storage_location}</span>}
                      {item.rental_type === 'rental' && (
                        <span className="text-[8px] px-1.5 py-0.5 rounded bg-[#fbbf24]/15 text-[#fbbf24] flex items-center gap-0.5">
                          <Repeat size={8} /> Rental{item.rental_return_date ? ` · ret ${item.rental_return_date}` : ''}
                        </span>
                      )}
                    </div>
                    <div className="text-[9px] text-[#8b949e] mt-0.5">
                      {subtitle && <span>{subtitle} · </span>}
                      Qty: {item.quantity} · Scene: {sceneLabel(item.assigned_scene_id)}
                      {item.unit_cost ? ` · $${item.unit_cost}/ea ($${totalCost.toLocaleString()})` : ''}
                    </div>
                  </div>
                  <select value={ps} onChange={e => updateProcurementStatus(item.id, e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-1.5 py-1 text-[9px] font-bold cursor-pointer" style={{ color: PROCUREMENT_STATUS_COLORS[ps] || '#8b949e' }}>
                    {PROCUREMENT_STATUS_ORDER.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                  <button onClick={() => deleteItem(item.id)} className="text-[#484f58] hover:text-[#f85149] transition-colors"><Trash2 size={12} /></button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <EntityDetailDrawer
        open={drawer.open}
        entity={drawer.entity}
        entityName={config.entityName}
        fields={config.fields}
        titleKey={config.titleKey}
        accent={config.accent}
        onClose={() => setDrawer({ open: false, entity: null })}
        onSave={saveItem}
        onDelete={deleteItemDrawer}
        exportRows={(entity) => {
          const row = { item: entity.item_name };
          config.fields.forEach(f => { if (f.key !== 'item_name') row[f.key] = entity[f.key] ?? ''; });
          row.total_cost = (entity.unit_cost || 0) * (entity.quantity || 1);
          return [row];
        }}
        exportFilename={`${deptKey.toLowerCase().replace(/\s/g, '_')}_${drawer.entity?.item_name || 'item'}.csv`}
      />
    </div>
  );
}