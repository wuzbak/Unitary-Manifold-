/**
 * MerlinActionMenu — Context-action button that offers tab-specific
 * first-pass Merlin actions. Floating on desktop, bottom-sheet on mobile.
 */
import { useState } from 'react';
import { Sparkles, ChevronUp, Loader2, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { buildFilmExpertPrompt } from '@/lib/merlinFilmExpert';
import { parseMerlinResponse } from '@/components/quantum-cat/parseMerlinResponse';
import { TAB_ACTIONS } from '@/lib/filmers/merlinAlerts';

export default function MerlinActionMenu({ tab, project, onResult, contextData }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const actions = TAB_ACTIONS[tab] || TAB_ACTIONS.dashboard;

  const runAction = async (action) => {
    setLoading(true);
    setOpen(false);
    try {
      const ctx = contextData || {};
      const prompt = buildFilmExpertPrompt() + `\n\nACTION REQUEST: ${action.label} — ${action.desc}\n\nPROJECT: ${project?.title || 'None'}\nDATA SUMMARY: ${JSON.stringify(ctx).slice(0, 2000)}\n\nPerform this action and provide actionable, specific results.`;
      const res = await base44.integrations.Core.InvokeLLM({
        prompt,
        model: 'claude_sonnet_4_6',
      });
      const parsed = parseMerlinResponse(res);
      setResult({ action: action.label, body: parsed.body || res });
      if (onResult) onResult(parsed.body || res);
    } catch (e) {
      setResult({ action: action.label, body: `Error: ${e.message}` });
    }
    setLoading(false);
  };

  return (
    <>
      {/* Floating action button */}
      <div className="fixed bottom-4 right-4 z-40 flex flex-col items-end gap-2">
        {result && (
          <div className="glass-strong clip-corner p-3 max-w-sm max-h-[40vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-[#fbbf24]">{result.action}</span>
              <button onClick={() => setResult(null)} className="text-[#484f58] hover:text-[#e6edf3]"><X size={12} /></button>
            </div>
            <div className="text-[10px] text-[#e6edf3] whitespace-pre-wrap leading-relaxed">{result.body}</div>
          </div>
        )}
        {loading && (
          <div className="glass-strong clip-corner p-3 flex items-center gap-2">
            <Loader2 size={12} className="animate-spin text-[#fbbf24]" />
            <span className="text-[10px] text-[#8b949e]">Merlin working…</span>
          </div>
        )}
        {open && (
          <div className="glass-strong clip-corner p-2 space-y-1 min-w-[200px]">
            <div className="flex items-center justify-between px-1 pb-1 border-b border-[#30363d]">
              <span className="text-[9px] font-bold text-[#fbbf24] uppercase tracking-wider">Merlin Actions</span>
              <button onClick={() => setOpen(false)} className="text-[#484f58] hover:text-[#e6edf3]"><X size={11} /></button>
            </div>
            {actions.map(a => (
              <button
                key={a.id}
                onClick={() => runAction(a)}
                className="w-full text-left p-2 rounded hover:bg-[#161b22] transition-colors group"
              >
                <div className="text-[10px] font-bold text-[#e6edf3] group-hover:text-[#fbbf24]">{a.label}</div>
                <div className="text-[8px] text-[#484f58]">{a.desc}</div>
              </button>
            ))}
          </div>
        )}
        <button
          onClick={() => setOpen(!open)}
          className="w-12 h-12 rounded-full bg-[#fbbf24] text-black flex items-center justify-center shadow-lg hover:scale-105 transition-transform merlin-pulse"
          title="Merlin Actions"
        >
          {loading ? <Loader2 size={18} className="animate-spin" /> : open ? <X size={18} /> : <Sparkles size={18} />}
        </button>
      </div>
    </>
  );
}