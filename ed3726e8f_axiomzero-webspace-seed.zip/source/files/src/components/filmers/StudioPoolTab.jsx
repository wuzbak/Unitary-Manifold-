/**
 * StudioPoolTab — Studio-wide shared resource pool.
 * Four sub-sections: Contacts, Inventory, Locations, Templates.
 * Each resource has a "Push to Project" action that clones it into a selected project.
 * Studio records persist for reuse across all projects.
 */
import { useState, useEffect, useCallback } from 'react';
import { Users, Package, MapPin, Film, Plus, Trash2, ArrowRightToLine, Loader2, Building2, Link2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { DEPARTMENTS } from '@/lib/filmers/departments';
import { cloneContactToProject, cloneInventoryToProject, cloneLocationToProject, cloneTemplateToProject } from '@/lib/filmers/studioClone';
import { exportCSV } from '@/lib/filmers/filmExport';
import EntityDetailDrawer from './EntityDetailDrawer';
import AlignmentView from './AlignmentView';
import ImportExportBar from './ImportExportBar';
import BudgetVsDaysSummary from './BudgetVsDaysSummary';
import { readCSVFile, coerceValue } from '@/lib/filmers/csvImport';

const SECTIONS = [
  { id: 'contacts', label: 'Contacts', icon: Users, color: '#fbbf24' },
  { id: 'inventory', label: 'Inventory', icon: Package, color: '#34d399' },
  { id: 'locations', label: 'Locations', icon: MapPin, color: '#58a6ff' },
  { id: 'templates', label: 'Templates', icon: Film, color: '#a78bfa' },
  { id: 'alignment', label: 'Alignment', icon: Link2, color: '#4dd0e1' },
];

const CONTACT_FIELDS = [
  { key: 'name', label: 'Name', type: 'text', required: true },
  { key: 'contact_type', label: 'Type', type: 'select', options: ['cast', 'crew'] },
  { key: 'role', label: 'Role / Position', type: 'text' },
  { key: 'department', label: 'Department', type: 'select', options: ['', ...DEPARTMENTS.map((d) => d.key), 'Production', 'Post-Production'] },
  { key: 'agent', label: 'Agent', type: 'text' },
  { key: 'contact', label: 'Contact (email/phone)', type: 'text' },
  { key: 'sag_status', label: 'SAG Status', type: 'select', options: ['SAG-AFTRA', 'Non-Union', 'Fi-Core', 'Pending'] },
  { key: 'union_status', label: 'Union Status', type: 'select', options: ['IATSE', 'DGA', 'Non-Union', 'Fi-Core', 'Pending'] },
  { key: 'day_rate', label: 'Day Rate', type: 'number' },
  { key: 'notes', label: 'Notes', type: 'textarea' },
];

const INVENTORY_FIELDS = [
  { key: 'item_name', label: 'Item Name', type: 'text', required: true },
  { key: 'department', label: 'Department', type: 'select', options: DEPARTMENTS.map((d) => d.key) },
  { key: 'category', label: 'Category', type: 'text' },
  { key: 'quantity', label: 'Quantity', type: 'number' },
  { key: 'unit_cost', label: 'Unit Cost', type: 'number' },
  { key: 'source_vendor', label: 'Vendor', type: 'text' },
  { key: 'storage_location', label: 'Storage Location', type: 'text' },
  { key: 'notes', label: 'Notes', type: 'textarea' },
];

const LOCATION_FIELDS = [
  { key: 'name', label: 'Location Name', type: 'text', required: true },
  { key: 'address', label: 'Address', type: 'text' },
  { key: 'permit_status', label: 'Permit Status', type: 'select', options: ['confirmed', 'pending', 'rejected', 'expired'] },
  { key: 'permit_fee', label: 'Permit Fee', type: 'text' },
  { key: 'electrical', label: 'Electrical', type: 'text' },
  { key: 'sound', label: 'Sound', type: 'text' },
  { key: 'parking', label: 'Parking', type: 'text' },
  { key: 'owner', label: 'Owner', type: 'text' },
  { key: 'access_notes', label: 'Access Notes', type: 'textarea' },
];

const TEMPLATE_FIELDS = [
  { key: 'title', label: 'Template Name', type: 'text', required: true },
  { key: 'description', label: 'Description', type: 'textarea' },
  { key: 'status', label: 'Default Status', type: 'select', options: ['Development', 'Pre-production', 'Production', 'Post-production', 'Wrapped'] },
  { key: 'total_budget', label: 'Default Budget', type: 'number' },
  { key: 'shoot_days', label: 'Shoot Days', type: 'number' },
];

export default function StudioPoolTab({ projects, onSelectProject }) {
  const [section, setSection] = useState('contacts');
  const [contacts, setContacts] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [locations, setLocations] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [pushTarget, setPushTarget] = useState({}); // resourceId -> selected projectId
  const [drawer, setDrawer] = useState({ open: false, entity: null });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [c, i, l, t] = await Promise.all([
        base44.entities.StudioContact.list('-created_date', 500),
        base44.entities.StudioInventory.list('-created_date', 500),
        base44.entities.StudioLocation.list('-created_date', 500),
        base44.entities.ProjectTemplate.list('-created_date', 500),
      ]);
      setContacts(c); setInventory(i); setLocations(l); setTemplates(t);
    } catch (e) { console.error('Studio pool load failed:', e); }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  // --- CRUD helpers ---
  const createEntity = async (entityName, formData) => {
    const created = await base44.entities[entityName].create(formData);
    await load();
    return created;
  };

  const updateEntity = async (entityName, id, formData) => {
    await base44.entities[entityName].update(id, formData);
    await load();
  };

  const deleteEntity = async (entityName, id) => {
    await base44.entities[entityName].delete(id);
    await load();
  };

  // --- Push to project ---
  const handlePush = async (resource, type) => {
    const projectId = pushTarget[resource.id];
    if (!projectId) { alert('Select a target project first.'); return; }
    const project = projects.find((p) => p.id === projectId);
    if (!project) return;
    try {
      if (type === 'contacts') await cloneContactToProject(resource, project, projectId);
      else if (type === 'inventory') await cloneInventoryToProject(resource, project, projectId);
      else if (type === 'locations') await cloneLocationToProject(resource, project, projectId);
      else if (type === 'templates') {
        const newProj = await cloneTemplateToProject(resource);
        onSelectProject?.(newProj);
      }
      alert(`Cloned "${resource.name || resource.item_name || resource.title}" into ${project.title}.`);
    } catch (e) { alert('Clone failed: ' + String(e?.message || e)); }
  };

  // --- CSV Import ---
  const handleImportCSV = async (file) => {
    const rows = await readCSVFile(file);
    if (!rows.length) return;
    const entityMap = {
      contacts: { entity: 'StudioContact', fields: CONTACT_FIELDS },
      inventory: { entity: 'StudioInventory', fields: INVENTORY_FIELDS },
      locations: { entity: 'StudioLocation', fields: LOCATION_FIELDS },
      templates: { entity: 'ProjectTemplate', fields: TEMPLATE_FIELDS },
    };
    const { entity: entityName, fields } = entityMap[section];
    const records = rows.map((row) => {
      const obj = {};
      fields.forEach((f) => {
        if (f.type === 'select' && f.options && !f.options.includes(row[f.key])) return;
        const val = coerceValue(row[f.key], f.type);
        if (val !== undefined) obj[f.key] = val;
      });
      return obj;
    }).filter((r) => Object.keys(r).length > 0);
    if (records.length) await base44.entities[entityName].bulkCreate(records);
    await load();
    alert(`Imported ${records.length} record(s).`);
  };

  // --- Export ---
  const handleExportCSV = () => {
    const data = { contacts, inventory, locations, templates }[section];
    if (!data.length) return;
    const rows = data.map((r) => {
      const obj = {};
      Object.keys(r).forEach((k) => { if (!['id', 'created_date', 'updated_date', 'created_by_id'].includes(k)) obj[k] = r[k]; });
      return obj;
    });
    exportCSV(rows, `studio_${section}.csv`);
  };

  const activeSection = SECTIONS.find((s) => s.id === section);
  const sectionData = { contacts, inventory, locations, templates }[section];
  const sectionFields = { contacts: CONTACT_FIELDS, inventory: INVENTORY_FIELDS, locations: LOCATION_FIELDS, templates: TEMPLATE_FIELDS }[section];
  const entityName = { contacts: 'StudioContact', inventory: 'StudioInventory', locations: 'StudioLocation', templates: 'ProjectTemplate' }[section];
  const titleKey = { contacts: 'name', inventory: 'item_name', locations: 'name', templates: 'title' }[section];

  const renderCard = (item) => {
    const isContact = section === 'contacts';
    const isInventory = section === 'inventory';
    const isLocation = section === 'locations';
    const isTemplate = section === 'templates';
    const title = item[titleKey];
    const subtitle = isContact ? `${item.contact_type === 'crew' ? item.department || 'Crew' : 'Cast'}${item.role ? ' · ' + item.role : ''}`
      : isInventory ? `${item.department} · ${item.category || '—'}`
      : isLocation ? item.address || ''
      : item.description || '';

    return (
      <div key={item.id} className="glass-panel clip-corner p-3 group">
        <div className="flex items-start justify-between gap-2 mb-1">
          <button onClick={() => setDrawer({ open: true, entity: item })} className="flex-1 min-w-0 text-left">
            <div className="text-xs font-bold text-[#e6edf3] truncate group-hover:text-[#4dd0e1] transition-colors">{title}</div>
            {subtitle && <div className="text-[9px] text-[#8b949e] truncate">{subtitle}</div>}
          </button>
          <button onClick={() => deleteEntity(entityName, item.id)} className="text-[#484f58] hover:text-[#f85149] transition-colors shrink-0">
            <Trash2 size={11} />
          </button>
        </div>
        {/* Push to project */}
        <div className="flex items-center gap-1.5 mt-2">
          <select
            value={pushTarget[item.id] || ''}
            onChange={(e) => setPushTarget({ ...pushTarget, [item.id]: e.target.value })}
            className="flex-1 min-w-0 bg-[#0B0F13] border border-[#30363d] rounded px-1.5 py-1 text-[9px] text-[#e6edf3]"
          >
            <option value="">Push to…</option>
            {projects.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
          </select>
          <button
            onClick={() => handlePush(item, section)}
            disabled={!pushTarget[item.id]}
            className="flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold border border-[#4dd0e1]/30 text-[#4dd0e1] bg-[#4dd0e1]/10 hover:bg-[#4dd0e1]/20 disabled:opacity-40 transition-colors shrink-0"
          >
            <ArrowRightToLine size={10} /> Push
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Budget vs Days analytics summary */}
      <BudgetVsDaysSummary projects={projects} onSelectProject={onSelectProject} />

      {/* Header */}
      <div className="glass-strong clip-corner p-4 flex items-center gap-2 border-l-2 border-[#4dd0e1]">
        <Building2 size={16} className="text-[#4dd0e1]" />
        <div>
          <span className="text-sm font-bold text-[#4dd0e1]">Studio Resource Pool</span>
          <span className="text-[10px] text-[#484f58] ml-2">Shared contacts, inventory, locations & templates — push to any project</span>
        </div>
      </div>

      {/* Section tabs */}
      <div className="glass-panel clip-corner p-1.5 overflow-x-auto">
        <div className="flex items-center gap-1 min-w-max">
          {SECTIONS.map((s) => (
            <button
              key={s.id}
              onClick={() => { setSection(s.id); setShowAdd(false); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-bold border transition-all whitespace-nowrap ${section === s.id ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}
              style={section === s.id ? { background: s.color } : {}}
            >
              <s.icon size={11} /> {s.label} ({s.id === 'alignment' ? '↗' : (({ contacts, inventory, locations, templates }[s.id])?.length ?? 0)})
            </button>
          ))}
        </div>
      </div>

      {/* Alignment view (replaces card grid for alignment section) */}
      {section === 'alignment' && <AlignmentView projects={projects} />}

      {section !== 'alignment' && (
      <>
      {/* Action bar */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <button
          onClick={() => setShowAdd(!showAdd)}
          className="flex items-center gap-1 px-3 py-1.5 rounded text-[10px] font-bold text-black"
          style={{ background: activeSection.color }}
        >
          <Plus size={11} /> Add {activeSection.label.replace(/s$/, '')}
        </button>
        <ImportExportBar onImportCSV={handleImportCSV} onExportCSV={handleExportCSV} accent={activeSection.color} exportDisabled={!sectionData.length} />
      </div>

      {/* Add form */}
      {showAdd && (
        <AddForm fields={sectionFields} accent={activeSection.color} onSubmit={(formData) => createEntity(entityName, formData).then(() => setShowAdd(false))} onCancel={() => setShowAdd(false)} />
      )}

      {/* Results */}
      {loading ? (
        <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#4dd0e1]" size={18} /></div>
      ) : !sectionData.length ? (
        <div className="text-center py-8 text-[10px] text-[#484f58] italic">No {activeSection.label.toLowerCase()} in the studio pool yet. Add one or import a CSV.</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          {sectionData.map(renderCard)}
        </div>
      )}
      </>
      )}

      {/* Detail drawer */}
      <EntityDetailDrawer
        open={drawer.open}
        entity={drawer.entity}
        entityName={entityName}
        fields={sectionFields}
        titleKey={titleKey}
        accent={activeSection.color}
        onClose={() => setDrawer({ open: false, entity: null })}
        onSave={(id, formData) => updateEntity(entityName, id, formData)}
        onDelete={(id) => deleteEntity(entityName, id)}
        exportRows={(entity) => { const obj = {}; sectionFields.forEach((f) => obj[f.key] = entity[f.key]); return [obj]; }}
        exportFilename={`studio_${section}_${drawer.entity?.[titleKey] || 'item'}.csv`}
      />
    </div>
  );
}

// --- Inline add form ---
function AddForm({ fields, accent, onSubmit, onCancel }) {
  const [form, setForm] = useState({});
  const submit = () => {
    const clean = {};
    fields.forEach((f) => { if (form[f.key] !== undefined && form[f.key] !== '') clean[f.key] = form[f.key]; });
    onSubmit(clean);
  };
  return (
    <div className="glass-panel clip-corner p-3 space-y-2 border-l-2" style={{ borderLeftColor: accent }}>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        {fields.map((f) => (
          f.type === 'textarea' ? null : f.type === 'select' ? (
            <select key={f.key} value={form[f.key] ?? ''} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              <option value="">{f.label}</option>
              {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          ) : (
            <input
              key={f.key}
              type={f.type === 'number' ? 'number' : 'text'}
              value={form[f.key] ?? ''}
              onChange={(e) => setForm({ ...form, [f.key]: f.type === 'number' ? (+e.target.value || 0) : e.target.value })}
              placeholder={f.label + (f.required ? ' *' : '')}
              className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]"
            />
          )
        ))}
      </div>
      {fields.filter((f) => f.type === 'textarea').map((f) => (
        <textarea key={f.key} value={form[f.key] ?? ''} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} placeholder={f.label} rows={2} className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] resize-none" />
      ))}
      <div className="flex gap-2">
        <button onClick={submit} className="px-3 py-1.5 rounded text-[10px] font-bold text-black" style={{ background: accent }}>Save</button>
        <button onClick={onCancel} className="px-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
      </div>
    </div>
  );
}