/**
 * StoryboardGenerator — AI storyboard frame generator for Filmer's Companion.
 * Filmmaker describes a shot → GenerateImage renders a cinematic visual reference.
 * Session-scoped gallery (no entity persistence). Consumes integration credits.
 */
import { useState } from 'react';
import { Image as ImageIcon, Sparkles, Download, Loader2, RotateCw, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { runMerlinImageFlow } from '@/lib/merlinContextLayer';
import MerlinContextCard from '@/components/merlin-context/MerlinContextCard';

export default function StoryboardGenerator({ synopsis = '', sceneType = 'drama' }) {
  const [prompt, setPrompt] = useState(synopsis ? `${synopsis} — ${sceneType} scene` : '');
  const [frames, setFrames] = useState([]);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState(null);
  const [merlinState, setMerlinState] = useState({ phase: 'idle' });
  const [pendingAnswers, setPendingAnswers] = useState(null);

  const handleGenerate = async (answers) => {
    if (generating) return;
    setGenerating(true);
    setError(null);
    setMerlinState({ phase: 'curating' });
    try {
      const result = await runMerlinImageFlow({
        rawPrompt: prompt.trim() || 'cinematic film still, dramatic lighting',
        generatorType: 'filmers-storyboard',
        answers: answers || pendingAnswers || undefined,
        pageContext: `Filmer's Companion — Storyboard (${sceneType})`,
        onStatus: (s) => setMerlinState((prev) => ({ ...prev, phase: s.phase })),
      });
      if (result.phase === 'clarify') {
        setMerlinState({ phase: 'clarify', clarifyingQuestions: result.clarifyingQuestions });
      } else if (result.phase === 'done') {
        setFrames(prev => [{ url: result.imageUrl, prompt: prompt.trim() || 'Untitled frame', id: Date.now() }, ...prev].slice(0, 12));
        setMerlinState({ phase: 'done', proof: result.proof, contextNote: result.contextNote });
      } else if (result.phase === 'error') {
        setError(result.error);
        setMerlinState({ phase: 'error', error: result.error });
      }
      setPendingAnswers(null);
    } catch (e) {
      setError(String(e?.message || e));
      setMerlinState({ phase: 'error', error: String(e?.message || e) });
    }
    setGenerating(false);
  };

  const handleAnswer = (answers) => {
    setPendingAnswers(answers);
    setMerlinState({ phase: 'idle' });
    setTimeout(() => handleGenerate(answers), 30);
  };

  const handleRecurate = (suggested) => {
    setMerlinState({ phase: 'idle' });
    setPrompt(suggested);
    setTimeout(() => handleGenerate(), 30);
  };

  const handleRegenerate = async (frame) => {
    setGenerating(true);
    setError(null);
    setMerlinState({ phase: 'curating' });
    try {
      const result = await runMerlinImageFlow({
        rawPrompt: frame.prompt,
        generatorType: 'filmers-storyboard',
        pageContext: `Filmer's Companion — Storyboard regenerate`,
        onStatus: (s) => setMerlinState((prev) => ({ ...prev, phase: s.phase })),
      });
      if (result.phase === 'done') {
        setFrames(prev => [{ url: result.imageUrl, prompt: frame.prompt, id: Date.now() }, ...prev.filter(f => f.id !== frame.id)]);
        setMerlinState({ phase: 'done', proof: result.proof, contextNote: result.contextNote });
      } else if (result.phase === 'error') {
        setError(result.error);
        setMerlinState({ phase: 'error', error: result.error });
      }
    } catch (e) {
      setError(String(e?.message || e));
      setMerlinState({ phase: 'error', error: String(e?.message || e) });
    }
    setGenerating(false);
  };

  return (
    <div className="bg-[#12161A] border border-[#fbbf24]/30 rounded-lg p-4 clip-corner">
      <div className="flex items-center gap-2 mb-3">
        <Sparkles size={14} className="text-[#fbbf24]" />
        <span className="text-xs font-bold text-[#fbbf24]">AI Storyboard Generator</span>
        <span className="text-[8px] text-[#484f58] ml-auto">consumes image credits</span>
      </div>

      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="Describe the shot… e.g. 'Wide aerial of a lone figure walking a rain-slicked pier at dusk, amber backlight, fog rolling in'"
        rows={2}
        className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2 resize-none focus:border-[#fbbf24]/40 focus:outline-none"
      />
      <button
        onClick={handleGenerate}
        disabled={generating}
        className="flex items-center gap-1.5 bg-[#fbbf24] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"
      >
        {generating ? <Loader2 size={12} className="animate-spin" /> : <ImageIcon size={12} />}
        {generating ? 'Generating frame…' : 'Generate Frame'}
      </button>

      {error && <div className="mt-2 text-[10px] text-[#f85149] border border-[#f85149]/30 rounded p-2">{error}</div>}

      <MerlinContextCard
        state={merlinState}
        accent="#fbbf24"
        onAnswer={handleAnswer}
        onRecurate={handleRecurate}
        onDismiss={() => setMerlinState({ phase: 'idle' })}
      />

      {frames.length > 0 && (
        <div className="grid grid-cols-2 gap-2 mt-4">
          {frames.map((f) => (
            <div key={f.id} className="border border-[#30363d] rounded overflow-hidden bg-[#0B0F13] group">
              <div className="aspect-video relative">
                <img src={f.url} alt={f.prompt} className="w-full h-full object-cover" />
                <div className="absolute top-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <a href={f.url} download={`storyboard_${f.id}.png`} className="bg-[#0B0F13]/80 p-1 rounded hover:bg-[#3fb950]/20">
                    <Download size={10} className="text-[#3fb950]" />
                  </a>
                  <button onClick={() => handleRegenerate(f)} className="bg-[#0B0F13]/80 p-1 rounded hover:bg-[#fbbf24]/20">
                    <RotateCw size={10} className="text-[#fbbf24]" />
                  </button>
                  <button onClick={() => setFrames(prev => prev.filter(x => x.id !== f.id))} className="bg-[#0B0F13]/80 p-1 rounded hover:bg-[#f85149]/20">
                    <Trash2 size={10} className="text-[#f85149]" />
                  </button>
                </div>
              </div>
              <p className="text-[9px] text-[#8b949e] p-1.5 leading-snug line-clamp-2">{f.prompt}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}