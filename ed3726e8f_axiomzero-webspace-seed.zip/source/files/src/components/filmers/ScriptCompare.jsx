/**
 * ScriptCompare — Side-by-side revision comparison with element-level diff.
 * Uses LCS-based diff algorithm. Highlights added/removed/changed elements.
 */
import { useState, useMemo } from 'react';
import { GitCompare, ArrowRight } from 'lucide-react';
import { diffScripts, diffStats } from '@/lib/filmers/scriptDiff';
import { TYPE_LABELS, TYPE_COLORS } from '@/lib/filmers/fountainSerializer';

export default function ScriptCompare({ scripts }) {
  const [revA, setRevA] = useState('');
  const [revB, setRevB] = useState('');

  const scriptA = scripts.find(s => s.id === revA);
  const scriptB = scripts.find(s => s.id === revB);

  const elementsA = useMemo(() => {
    if (!scriptA?.elements_json) return [];
    try { return JSON.parse(scriptA.elements_json); } catch { return []; }
  }, [scriptA]);

  const elementsB = useMemo(() => {
    if (!scriptB?.elements_json) return [];
    try { return JSON.parse(scriptB.elements_json); } catch { return []; }
  }, [scriptB]);

  const diff = useMemo(() => diffScripts(elementsA, elementsB), [elementsA, elementsB]);
  const stats = useMemo(() => diffStats(diff), [diff]);

  const statusColor = { added: '#34d399', removed: '#f87171', changed: '#fbbf24', unchanged: '#484f58' };
  const statusBg = { added: 'rgba(52,211,153,0.08)', removed: 'rgba(248,113,113,0.08)', changed: 'rgba(251,191,36,0.08)', unchanged: 'transparent' };

  return (
    <div className="space-y-3">
      {/* Revision selectors */}
      <div className="glass-panel clip-corner p-3">
        <div className="flex items-center gap-2 mb-2">
          <GitCompare size={12} className="text-[#a78bfa]" />
          <span className="text-[10px] font-bold text-[#a78bfa] uppercase tracking-wider">Compare Revisions</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <select value={revA} onChange={e => setRevA(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] flex-1 min-w-[150px]">
            <option value="">Old revision...</option>
            {scripts.map(s => <option key={s.id} value={s.id}>{s.title} · {s.revision_color}</option>)}
          </select>
          <ArrowRight size={14} className="text-[#484f58] shrink-0" />
          <select value={revB} onChange={e => setRevB(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] flex-1 min-w-[150px]">
            <option value="">New revision...</option>
            {scripts.map(s => <option key={s.id} value={s.id}>{s.title} · {s.revision_color}</option>)}
          </select>
        </div>
      </div>

      {/* Stats */}
      {diff.length > 0 && (
        <div className="glass-panel clip-corner p-3 flex items-center gap-4 flex-wrap">
          <span className="text-[10px] text-[#34d399]">+{stats.added} added</span>
          <span className="text-[10px] text-[#f87171]">-{stats.removed} removed</span>
          <span className="text-[10px] text-[#fbbf24]">~{stats.changed} changed</span>
          <span className="text-[10px] text-[#484f58]">{stats.unchanged} unchanged</span>
        </div>
      )}

      {/* Diff view */}
      {diff.length > 0 ? (
        <div className="glass-panel clip-corner p-3 max-h-[60vh] overflow-y-auto">
          <div className="space-y-0.5">
            {diff.map((entry, i) => {
              const color = statusColor[entry.status];
              const bg = statusBg[entry.status];
              const type = entry.a?.type || entry.b?.type || 'action';
              const typeColor = TYPE_COLORS[type] || '#e6edf3';
              const text = entry.status === 'added' ? entry.b.text : entry.status === 'removed' ? entry.a.text : entry.b?.text || entry.a?.text || '';

              return (
                <div key={i} className="flex items-start gap-1.5 p-1.5 rounded" style={{ background: bg }}>
                  <span className="text-[7px] font-bold uppercase shrink-0 mt-0.5" style={{ color: typeColor, minWidth: '48px' }}>
                    {TYPE_LABELS[type]}
                  </span>
                  <span className="text-[8px] shrink-0 mt-0.5" style={{ color }}>
                    {entry.status === 'added' ? '+' : entry.status === 'removed' ? '-' : entry.status === 'changed' ? '~' : '='}
                  </span>
                  <div className="flex-1 min-w-0">
                    {entry.status === 'changed' ? (
                      <div className="text-[10px] font-mono">
                        <div className="text-[#f87149] line-through opacity-60">{entry.a.text}</div>
                        <div className="text-[#34d399]">{entry.b.text}</div>
                      </div>
                    ) : (
                      <div className="text-[10px] font-mono" style={{ color: entry.status === 'unchanged' ? '#8b949e' : '#e6edf3' }}>
                        {text}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : revA && revB ? (
        <div className="glass-panel clip-corner p-6 text-center">
          <p className="text-[10px] text-[#484f58] italic">No differences found — revisions are identical.</p>
        </div>
      ) : (
        <div className="glass-panel clip-corner p-6 text-center">
          <GitCompare size={24} className="text-[#484f58] mx-auto mb-2" />
          <p className="text-[10px] text-[#8b949e]">Select two revisions to compare.</p>
        </div>
      )}
    </div>
  );
}