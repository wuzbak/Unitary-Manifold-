/**
 * DualEntryToggle — Toggle between Studio (standalone) and Project-scoped entry.
 * Used in all entity forms to support the dual-entry model.
 */
import { Building2, FolderOpen } from 'lucide-react';

export default function DualEntryToggle({ mode, onChange, projectName }) {
  return (
    <div className="flex items-center gap-1 p-1 rounded bg-[#0B0F13] border border-[#30363d]">
      <button
        onClick={() => onChange('studio')}
        className={`flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold transition-colors ${mode === 'studio' ? 'bg-[#4dd0e1] text-black' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
      >
        <Building2 size={10} /> Studio
      </button>
      <button
        onClick={() => onChange('project')}
        className={`flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold transition-colors ${mode === 'project' ? 'bg-[#fbbf24] text-black' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
      >
        <FolderOpen size={10} /> {projectName ? `Project` : 'Project'}
      </button>
    </div>
  );
}

/**
 * Helper: resolve project_id based on dual-entry mode.
 * Returns null for studio mode, project.id for project mode.
 */
export function resolveProjectId(mode, project) {
  return mode === 'project' && project ? project.id : null;
}