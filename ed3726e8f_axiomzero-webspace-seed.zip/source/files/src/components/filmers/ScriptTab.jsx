import { useState, useEffect } from 'react';
import { FileText, Upload, Loader2, Plus, Trash2, RefreshCw } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { parseScript } from '@/lib/filmers/sceneParser';
import { exportCSV } from '@/lib/filmers/filmExport';
import { logActivity } from '@/lib/filmers/activityLog';
import ImportExportBar from './ImportExportBar';
import EntityDetailDrawer from './EntityDetailDrawer';

const SCENE_FIELDS = [
  { key: 'scene_number', label: 'Scene Number', type: 'text' },
  { key: 'int_ext', label: 'INT/EXT', type: 'select', options: ['INT', 'EXT', 'I/E'] },
  { key: 'day_night', label: 'Day/Night', type: 'select', options: ['DAY', 'NIGHT', 'DUSK', 'DAWN'] },
  { key: 'location_text', label: 'Location', type: 'text' },
  { key: 'synopsis', label: 'Synopsis', type: 'textarea' },
  { key: 'pages', label: 'Pages', type: 'text' },
  { key: 'call_time', label: 'Call Time', type: 'text' },
];

const REVISION_COLORS = ['White', 'Blue', 'Pink', 'Yellow', 'Green', 'Goldenrod', 'Buff', 'Salmon', 'Cherry'];

export default function ScriptTab({ project }) {
  const [scripts, setScripts] = useState([]);
  const [scenes, setScenes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState('text');
  const [text, setText] = useState('');
  const [title, setTitle] = useState('');
  const [revName, setRevName] = useState('White Draft');
  const [revColor, setRevColor] = useState('White');
  const [replace, setReplace] = useState(true);
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState(null);
  const [drawer, setDrawer] = useState({ open: false, entity: null });

  const load = async () => {
    setLoading(true);
    try {
      const [s, sc] = await Promise.all([
        base44.entities.Script.filter({ project_id: project.id }),
        base44.entities.Scene.filter({ project_id: project.id }, 'sort_order', 500),
      ]);
      setScripts(s); setScenes(sc);
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [project.id]);

  const importText = async () => {
    if (!text.trim()) return;
    setImporting(true); setError(null);
    try {
      const { scenes: parsed, title: parsedTitle } = parseScript(text, mode);
      const scriptTitle = title.trim() || parsedTitle || 'Imported Script';
      if (replace) {
        await base44.entities.Scene.deleteMany({ project_id: project.id });
        setScenes([]);
      }
      const sceneRecords = parsed.map((s, i) => ({ ...s, project_id: project.id, sort_order: i }));
      if (sceneRecords.length) await base44.entities.Scene.bulkCreate(sceneRecords);
      await base44.entities.Script.create({
        project_id: project.id, title: scriptTitle, content: text, source_format: mode,
        revision_name: revName, revision_color: revColor, imported_date: new Date().toISOString(),
      });
      setText(''); setTitle('');
      await load();
    } catch (e) { setError(String(e?.message || e)); }
    setImporting(false);
  };

  const importFile = async (file) => {
    if (!file) return;
    setImporting(true); setError(null);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const isPdf = file.name.toLowerCase().endsWith('.pdf');
      const schema = { type: 'object', properties: { title: { type: 'string' }, text: { type: 'string' } } };
      const res = await base44.integrations.Core.ExtractDataFromUploadedFile({ file_url, json_schema: schema });
      const extracted = res?.output || {};
      const content = extracted.text || '';
      const scriptTitle = title.trim() || extracted.title || file.name.replace(/\.[^.]+$/, '');
      const { scenes: parsed } = parseScript(content, isPdf ? 'pdf_extract' : 'docx_extract');
      if (replace) { await base44.entities.Scene.deleteMany({ project_id: project.id }); setScenes([]); }
      if (parsed.length) await base44.entities.Scene.bulkCreate(parsed.map((s, i) => ({ ...s, project_id: project.id, sort_order: i })));
      await base44.entities.Script.create({
        project_id: project.id, title: scriptTitle, content, source_format: isPdf ? 'pdf_extract' : 'docx_extract',
        revision_name: revName, revision_color: revColor, imported_date: new Date().toISOString(),
      });
      await load();
    } catch (e) { setError(String(e?.message || e)); }
    setImporting(false);
  };

  const delScene = async (id) => { await base44.entities.Scene.delete(id); setScenes(scenes.filter((s) => s.id !== id)); setDrawer({ open: false, entity: null }); };
  const saveScene = async (id, formData) => { await base44.entities.Scene.update(id, formData); setScenes(scenes.map(s => s.id === id ? { ...s, ...formData } : s)); logActivity(project.id, 'scene', formData.scene_number || '', 'updated'); };
  const delSceneDrawer = async (id) => { await base44.entities.Scene.delete(id); setScenes(scenes.filter((s) => s.id !== id)); setDrawer({ open: false, entity: null }); };
  const doExportScenes = () => { exportCSV(scenes.map((s, i) => ({ scene: s.scene_number || i + 1, int_ext: s.int_ext, day_night: s.day_night, location: s.location_text, synopsis: s.synopsis, pages: s.pages, call_time: s.call_time })), 'scenes.csv'); };

  return (
    <div className="space-y-4">
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><FileText size={14} className="text-[#a78bfa]" /><h3 className="text-xs font-bold text-[#a78bfa]">Import Script</h3></div>
        <div className="flex gap-2 mb-3">
          <button onClick={() => setMode('text')} className={`px-3 py-1.5 rounded text-[11px] font-bold border ${mode === 'text' ? 'bg-[#a78bfa] text-black border-transparent' : 'border-[#30363d] text-[#8b949e]'}`}>Paste Text / Fountain</button>
          <button onClick={() => setMode('pdf')} className={`px-3 py-1.5 rounded text-[11px] font-bold border ${mode !== 'text' ? 'bg-[#a78bfa] text-black border-transparent' : 'border-[#30363d] text-[#8b949e]'}`}>Upload PDF / DOCX</button>
        </div>
        {mode === 'text' ? (
          <>
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Script title (optional)" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
            <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Paste Fountain or plain-text screenplay here…&#10;INT. WAREHOUSE - NIGHT&#10;A figure moves through the dark…" rows={6} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2 resize-y font-mono" />
          </>
        ) : (
          <label className="flex flex-col items-center justify-center border-2 border-dashed border-[#30363d] rounded p-6 cursor-pointer hover:border-[#a78bfa]/40 transition-colors">
            <Upload size={20} className="text-[#484f58] mb-2" />
            <span className="text-[11px] text-[#8b949e]">Click to upload a PDF or DOCX script</span>
            <span className="text-[9px] text-[#484f58] mt-1">Extracted via AI, then parsed into scenes</span>
            <input type="file" accept=".pdf,.docx" className="hidden" onChange={(e) => importFile(e.target.files?.[0])} />
          </label>
        )}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
          <input value={revName} onChange={(e) => setRevName(e.target.value)} placeholder="Revision name" className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <select value={revColor} onChange={(e) => setRevColor(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]">
            {REVISION_COLORS.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <label className="flex items-center gap-2 text-[10px] text-[#8b949e] px-2">
            <input type="checkbox" checked={replace} onChange={(e) => setReplace(e.target.checked)} /> Replace existing
          </label>
          <button onClick={importText} disabled={!text.trim() || importing} className="flex items-center justify-center gap-1.5 bg-[#a78bfa] text-black px-3 py-2 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40">
            {importing ? <Loader2 size={12} className="animate-spin" /> : <Plus size={12} />} Import
          </button>
        </div>
        {error && <div className="mt-2 text-[10px] text-[#f85149] border border-[#f85149]/30 rounded p-2">{error}</div>}
      </div>

      {/* Revision history */}
      {scripts.length > 0 && (
        <div className="glass-panel clip-corner p-3">
          <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-2">Revisions ({scripts.length})</div>
          <div className="flex flex-wrap gap-2">
            {scripts.map((s) => (
              <span key={s.id} className="text-[10px] border border-[#30363d] rounded px-2 py-1 text-[#e6edf3]">{s.title} · {s.revision_color} · {s.source_format}</span>
            ))}
          </div>
        </div>
      )}

      {/* Scene list */}
      <div className="glass-panel clip-corner p-4">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
          <div className="flex items-center gap-2">
            <div className="text-[10px] text-[#8b949e] uppercase tracking-wider">Scenes ({scenes.length})</div>
            <button onClick={load} className="text-[#484f58] hover:text-[#e6edf3]"><RefreshCw size={11} /></button>
          </div>
          <ImportExportBar onExportCSV={doExportScenes} accent="#a78bfa" disabled={!scenes.length} />
        </div>
        {loading ? (
          <div className="flex justify-center py-6"><Loader2 className="animate-spin text-[#484f58]" size={16} /></div>
        ) : scenes.length === 0 ? (
          <p className="text-[11px] text-[#8b949e] italic text-center py-4">No scenes yet. Import a script above to populate the breakdown.</p>
        ) : (
          <div className="space-y-1.5 max-h-96 overflow-y-auto">
            {scenes.map((s, i) => (
              <div key={s.id} className="flex items-center gap-2 border border-[#30363d] rounded p-2 text-[10px] cursor-pointer hover:border-[#a78bfa]/40 transition-colors" onClick={() => setDrawer({ open: true, entity: s })}>
                <span className="text-[#a78bfa] font-bold w-6 shrink-0">{s.scene_number || i + 1}</span>
                <span className="text-[#8b949e] shrink-0">{s.int_ext}/{s.day_night}</span>
                <span className="text-[#e6edf3] flex-1 truncate">{s.location_text || s.synopsis || 'Untitled'}</span>
                <span className="text-[#484f58] shrink-0">{s.pages}p</span>
                <button onClick={(e) => { e.stopPropagation(); delScene(s.id); }} className="text-[#f85149] hover:bg-[#f85149]/10 p-1 rounded shrink-0"><Trash2 size={10} /></button>
              </div>
            ))}
          </div>
        )}
      </div>

      <EntityDetailDrawer
        open={drawer.open}
        entity={drawer.entity}
        entityName="Scene"
        fields={SCENE_FIELDS}
        titleKey="scene_number"
        titleFallback="Scene"
        accent="#a78bfa"
        onClose={() => setDrawer({ open: false, entity: null })}
        onSave={saveScene}
        onDelete={delSceneDrawer}
        exportRows={(entity) => [{ scene: entity.scene_number, int_ext: entity.int_ext, day_night: entity.day_night, location: entity.location_text, synopsis: entity.synopsis, pages: entity.pages, call_time: entity.call_time }]}
        exportFilename={`scene_${drawer.entity?.scene_number || 'item'}.csv`}
      />
    </div>
  );
}