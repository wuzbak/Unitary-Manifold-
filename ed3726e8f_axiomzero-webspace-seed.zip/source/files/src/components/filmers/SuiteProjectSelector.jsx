/**
 * SuiteProjectSelector — Dropdown for switching between productions.
 * Prominent pill at the top right of the suite header.
 */
import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Film, Plus, Check } from 'lucide-react';

const STATUS_COLOR = { Development: '#8b949e', 'Pre-production': '#fbbf24', Production: '#3fb950', 'Post-production': '#60a5fa', Wrapped: '#a78bfa' };

export default function SuiteProjectSelector({ projects, selectedProject, onSelect, onCreateNew }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-2 glass-panel clip-corner glow-hover min-h-[40px]"
      >
        <Film size={13} className="text-[#fbbf24] shrink-0" />
        <div className="text-left min-w-0">
          {selectedProject ? (
            <>
              <div className="text-xs font-bold text-[#e6edf3] truncate max-w-[160px]">{selectedProject.title}</div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: STATUS_COLOR[selectedProject.status] || '#8b949e' }} />
                <span className="text-[8px] text-[#8b949e]">{selectedProject.status}</span>
              </div>
            </>
          ) : (
            <div className="text-xs font-bold text-[#8b949e]">No project selected</div>
          )}
        </div>
        <ChevronDown size={12} className={`text-[#484f58] transition-transform shrink-0 ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-1 w-72 glass-strong clip-corner overflow-hidden z-50 max-h-[60vh] overflow-y-auto">
          {projects.length === 0 ? (
            <div className="p-3 text-center">
              <p className="text-[10px] text-[#8b949e] mb-2">No productions yet.</p>
              <button onClick={() => { setOpen(false); onCreateNew(); }} className="flex items-center gap-1.5 mx-auto px-3 py-1.5 bg-[#fbbf24] text-black rounded text-[10px] font-bold">
                <Plus size={11} /> Create Project
              </button>
            </div>
          ) : (
            <>
              <div className="p-2 space-y-1">
                {projects.map(p => (
                  <button
                    key={p.id}
                    onClick={() => { onSelect(p); setOpen(false); }}
                    className={`w-full flex items-center gap-2 p-2 rounded text-left transition-colors ${selectedProject?.id === p.id ? 'bg-[#fbbf24]/10' : 'hover:bg-[#161b22]'}`}
                  >
                    <Film size={11} className="text-[#fbbf24] shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-[#e6edf3] truncate">{p.title}</div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full" style={{ background: STATUS_COLOR[p.status] || '#8b949e' }} />
                        <span className="text-[8px] text-[#8b949e]">{p.status} · {p.shoot_days || 0} days</span>
                      </div>
                    </div>
                    {selectedProject?.id === p.id && <Check size={12} className="text-[#fbbf24] shrink-0" />}
                  </button>
                ))}
              </div>
              <div className="border-t border-[#30363d] p-2">
                <button onClick={() => { setOpen(false); onCreateNew(); }} className="w-full flex items-center gap-2 p-2 rounded text-left hover:bg-[#161b22] transition-colors">
                  <Plus size={12} className="text-[#3fb950]" />
                  <span className="text-[10px] font-bold text-[#3fb950]">Create New Project</span>
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}