/**
 * StudioDashboardTab — Cross-project aggregation dashboard.
 * Shows total budget, combined cast/crew, total inventory, open POs,
 * recent activity feed, and per-project status pipeline across ALL projects.
 * All metrics are clickable to drill into the project.
 */
import { useState, useEffect, useCallback } from 'react';
import { Building2, Film, Users, Package, ShoppingCart, Activity, DollarSign, Loader2, ChevronRight } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { base44 } from '@/api/base44Client';

const STATUS_COLORS = {
  Development: '#8b949e',
  'Pre-production': '#fbbf24',
  Production: '#3fb950',
  'Post-production': '#60a5fa',
  Wrapped: '#a78bfa',
};

export default function StudioDashboardTab({ projects, onSelectProject }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!projects.length) { setLoading(false); return; }
    setLoading(true);
    try {
      const [allCast, allCrew, allDept, allActivity] = await Promise.all([
        base44.entities.CastMember.list('-created_date', 500),
        base44.entities.CrewMember.list('-created_date', 500),
        base44.entities.DepartmentItem.list('-created_date', 500),
        base44.entities.ProductionActivity.list('-created_date', 50),
      ]);
      setData({ allCast, allCrew, allDept, allActivity });
    } catch (e) {
      console.error('Studio dashboard load failed:', e);
    }
    setLoading(false);
  }, [projects.length]);

  useEffect(() => { load(); }, [load]);

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#4dd0e1]" size={20} /></div>;
  if (!projects.length) return (
    <div className="glass-panel clip-corner p-8 text-center">
      <Building2 size={28} className="text-[#484f58] mx-auto mb-3" />
      <p className="text-xs text-[#8b949e]">No projects yet. Create a project to see studio-wide metrics.</p>
    </div>
  );

  const d = data || { allCast: [], allCrew: [], allDept: [], allActivity: [] };
  const totalBudget = projects.reduce((s, p) => s + (p.total_budget || 0), 0);
  const totalCast = d.allCast.length;
  const totalCrew = d.allCrew.length;
  const totalItems = d.allDept.length;
  const openPOs = d.allDept.filter((i) => (i.procurement_status || i.status) === 'ordered').length;

  // Per-project budget data for chart
  const budgetData = projects.map((p) => ({ name: p.title.length > 15 ? p.title.slice(0, 13) + '…' : p.title, budget: p.total_budget || 0 }));

  // Status distribution for pie
  const statusCounts = {};
  projects.forEach((p) => { statusCounts[p.status] = (statusCounts[p.status] || 0) + 1; });
  const statusData = Object.entries(statusCounts).map(([name, value]) => ({ name, value, fill: STATUS_COLORS[name] || '#8b949e' }));

  const stats = [
    { label: 'Total Budget', value: `$${totalBudget.toLocaleString()}`, icon: DollarSign, color: '#60a5fa' },
    { label: 'Projects', value: projects.length, icon: Film, color: '#4dd0e1' },
    { label: 'Cast Members', value: totalCast, icon: Users, color: '#fbbf24' },
    { label: 'Crew Members', value: totalCrew, icon: Users, color: '#58a6ff' },
    { label: 'Inventory Items', value: totalItems, icon: Package, color: '#34d399' },
    { label: 'Open POs', value: openPOs, icon: ShoppingCart, color: '#fbbf24' },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="glass-strong clip-corner p-4 flex items-center gap-2 border-l-2 border-[#4dd0e1]">
        <Building2 size={16} className="text-[#4dd0e1]" />
        <div>
          <span className="text-sm font-bold text-[#4dd0e1]">Studio Dashboard</span>
          <span className="text-[10px] text-[#484f58] ml-2">Cross-project aggregation across all productions</span>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
        {stats.map((s) => (
          <div key={s.label} className="glass-panel clip-corner p-3">
            <div className="flex items-center gap-1.5 mb-1">
              <s.icon size={11} style={{ color: s.color }} />
              <span className="text-[8px] text-[#484f58] uppercase tracking-wider">{s.label}</span>
            </div>
            <div className="text-lg font-bold" style={{ color: s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Budget by project */}
        <div className="glass-strong clip-corner p-4">
          <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-3">Budget by Project</div>
          {budgetData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={budgetData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#30363d" />
                <XAxis dataKey="name" tick={{ fill: '#8b949e', fontSize: 9 }} angle={-20} textAnchor="end" height={50} />
                <YAxis tick={{ fill: '#8b949e', fontSize: 9 }} tickFormatter={(v) => `$${v / 1000}k`} />
                <Tooltip contentStyle={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 0, fontSize: 10 }} />
                <Bar dataKey="budget" fill="#4dd0e1" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : <p className="text-[10px] text-[#484f58] italic text-center py-8">No budget data</p>}
        </div>

        {/* Status distribution */}
        <div className="glass-strong clip-corner p-4">
          <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-3">Project Status Pipeline</div>
          {statusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} innerRadius={35}>
                  {statusData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Pie>
                <Tooltip contentStyle={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 0, fontSize: 10 }} />
                <Legend wrapperStyle={{ fontSize: 9, color: '#8b949e' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <p className="text-[10px] text-[#484f58] italic text-center py-8">No projects</p>}
        </div>
      </div>

      {/* Per-project pipeline + activity feed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Project pipeline */}
        <div className="glass-strong clip-corner p-4">
          <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-3">All Projects — Click to Open</div>
          <div className="space-y-1.5 max-h-64 overflow-y-auto">
            {projects.map((p) => {
              const projCast = d.allCast.filter((c) => c.project_id === p.id).length;
              const projCrew = d.allCrew.filter((c) => c.project_id === p.id).length;
              const projItems = d.allDept.filter((i) => i.project_id === p.id).length;
              return (
                <button
                  key={p.id}
                  onClick={() => onSelectProject?.(p)}
                  className="w-full glass-panel clip-corner p-2.5 flex items-center gap-3 hover:border-[#4dd0e1]/40 transition-colors text-left group"
                >
                  <div className="w-1.5 h-8 rounded-full shrink-0" style={{ background: STATUS_COLORS[p.status] || '#8b949e' }} />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-[#e6edf3] truncate group-hover:text-[#4dd0e1] transition-colors">{p.title}</div>
                    <div className="text-[9px] text-[#484f58]">
                      {p.status} · ${(p.total_budget || 0).toLocaleString()} · {projCast} cast · {projCrew} crew · {projItems} items
                    </div>
                  </div>
                  <ChevronRight size={12} className="text-[#484f58] group-hover:text-[#4dd0e1] transition-colors shrink-0" />
                </button>
              );
            })}
          </div>
        </div>

        {/* Activity feed */}
        <div className="glass-strong clip-corner p-4">
          <div className="flex items-center gap-1.5 mb-3">
            <Activity size={11} className="text-[#4dd0e1]" />
            <span className="text-[10px] text-[#8b949e] uppercase tracking-wider">Studio Activity Feed</span>
          </div>
          {d.allActivity.length > 0 ? (
            <div className="space-y-1.5 max-h-64 overflow-y-auto">
              {d.allActivity.map((a) => {
                const proj = projects.find((p) => p.id === a.project_id);
                return (
                  <div key={a.id} className="text-[10px] border-l-2 border-[#30363d] pl-2 py-1">
                    <span className="font-bold text-[#4dd0e1]">{a.action}</span>{' '}
                    <span className="text-[#e6edf3]">{a.entity_name || a.entity_type}</span>
                    {a.details && <span className="text-[#484f58]"> — {a.details}</span>}
                    {proj && <span className="text-[#484f58] block text-[8px]">{proj.title}</span>}
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-[10px] text-[#484f58] italic text-center py-8">No recent activity</p>
          )}
        </div>
      </div>
    </div>
  );
}