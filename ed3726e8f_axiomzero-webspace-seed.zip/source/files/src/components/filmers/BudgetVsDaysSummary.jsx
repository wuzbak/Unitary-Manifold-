/**
 * BudgetVsDaysSummary — Studio-level analytics summary for the Studio Pool tab.
 * Lists each active project with total budget, budget spent so far (summed from
 * DepartmentItem + WardrobeItem + CameraItem), remaining shoot days (auto-computed
 * from shoot_end_date with a manual days_completed override), and a burn-rate
 * indicator. Clicking a project drills into it.
 */
import { useState, useEffect, useCallback } from 'react';
import { Building2, DollarSign, Calendar, TrendingUp, Loader2, Film, AlertTriangle } from 'lucide-react';
import { base44 } from '@/api/base44Client';

function daysBetween(a, b) {
  const ms = 1000 * 60 * 60 * 24;
  return Math.ceil((new Date(b) - new Date(a)) / ms);
}

function computeRemainingDays(p) {
  // Manual override takes precedence
  if ((p.days_completed || 0) > 0) {
    return Math.max(0, (p.shoot_days || 0) - p.days_completed);
  }
  // Auto-compute from end date
  if (p.shoot_end_date) {
    const today = new Date().toISOString().slice(0, 10);
    const diff = daysBetween(today, p.shoot_end_date);
    return Math.max(0, diff);
  }
  // Fallback to total shoot days
  return p.shoot_days || 0;
}

function itemCost(i) {
  return (i.unit_cost || 0) * (i.quantity || 1);
}

export default function BudgetVsDaysSummary({ projects, onSelectProject }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!projects.length) { setLoading(false); return; }
    setLoading(true);
    try {
      const [deptItems, wardrobeItems, cameraItems] = await Promise.all([
        base44.entities.DepartmentItem.list('-created_date', 1000),
        base44.entities.WardrobeItem.list('-created_date', 1000),
        base44.entities.CameraItem.list('-created_date', 1000),
      ]);
      setData({ deptItems, wardrobeItems, cameraItems });
    } catch (e) {
      console.error('Budget summary load failed:', e);
    }
    setLoading(false);
  }, [projects.length]);

  useEffect(() => { load(); }, [load]);

  if (loading) return (
    <div className="glass-strong clip-corner p-4 flex items-center gap-2 border-l-2 border-[#4dd0e1]">
      <Loader2 size={14} className="animate-spin text-[#4dd0e1]" />
      <span className="text-[10px] text-[#8b949e]">Loading studio analytics…</span>
    </div>
  );

  if (!projects.length) return null;

  const d = data || { deptItems: [], wardrobeItems: [], cameraItems: [] };

  const rows = projects.map((p) => {
    const deptSpend = d.deptItems.filter((i) => i.project_id === p.id).reduce((s, i) => s + itemCost(i), 0);
    const wardrobeSpend = d.wardrobeItems.filter((i) => i.project_id === p.id).reduce((s, i) => s + itemCost(i), 0);
    const cameraSpend = d.cameraItems.filter((i) => i.project_id === p.id).reduce((s, i) => s + itemCost(i), 0);
    const spent = deptSpend + wardrobeSpend + cameraSpend;
    const budget = p.total_budget || 0;
    const remainingDays = computeRemainingDays(p);
    const totalDays = p.shoot_days || 0;
    const daysElapsed = Math.max(0, totalDays - remainingDays);
    const burnRate = daysElapsed > 0 ? spent / daysElapsed : 0;
    const budgetPct = budget > 0 ? Math.round((spent / budget) * 100) : 0;
    const overBudget = budget > 0 && spent > budget;
    return { p, spent, budget, remainingDays, totalDays, daysElapsed, burnRate, budgetPct, overBudget };
  });

  return (
    <div className="glass-strong clip-corner p-4 border-l-2 border-[#4dd0e1]">
      <div className="flex items-center gap-2 mb-3">
        <Building2 size={14} className="text-[#4dd0e1]" />
        <span className="text-xs font-bold text-[#4dd0e1]">Studio Analytics — Budget vs Remaining Days</span>
        <span className="text-[9px] text-[#484f58]">· {projects.length} project{projects.length !== 1 ? 's' : ''}</span>
      </div>

      {rows.length === 0 ? (
        <p className="text-[10px] text-[#484f58] italic text-center py-4">No projects to analyze.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2">
          {rows.map(({ p, spent, budget, remainingDays, totalDays, daysElapsed, burnRate, budgetPct, overBudget }) => {
            const isWrapped = p.status === 'Wrapped';
            return (
              <button
                key={p.id}
                onClick={() => onSelectProject?.(p)}
                className="glass-panel clip-corner p-3 text-left hover:border-[#4dd0e1]/40 transition-colors group"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Film size={12} className="text-[#fbbf24] shrink-0" />
                  <span className="text-xs font-bold text-[#e6edf3] truncate group-hover:text-[#4dd0e1] transition-colors flex-1 min-w-0">{p.title}</span>
                  <span className="text-[8px] px-1.5 py-0.5 rounded border shrink-0" style={{ color: '#8b949e', borderColor: '#30363d' }}>{p.status}</span>
                </div>

                {/* Budget row */}
                <div className="flex items-center gap-2 mb-1.5">
                  <DollarSign size={11} className={overBudget ? 'text-[#f85149]' : 'text-[#3fb950]'} />
                  <span className="text-[9px] text-[#8b949e]">
                    <span className="font-bold" style={{ color: overBudget ? '#f85149' : '#e6edf3' }}>${spent.toLocaleString()}</span>
                    {' / '}
                    <span>{budget > 0 ? `$${budget.toLocaleString()}` : '—'}</span>
                    {budget > 0 && <span className={overBudget ? 'text-[#f85149]' : 'text-[#484f58]'}> · {budgetPct}%</span>}
                  </span>
                  {overBudget && <AlertTriangle size={10} className="text-[#f85149] ml-auto" />}
                </div>
                {/* Budget progress bar */}
                <div className="h-1.5 bg-[#0d1117] rounded-sm overflow-hidden mb-2">
                  <div className="h-full transition-all" style={{ width: `${Math.min(budgetPct, 100)}%`, background: overBudget ? '#f85149' : budgetPct >= 80 ? '#fbbf24' : '#3fb950' }} />
                </div>

                {/* Days row */}
                <div className="flex items-center gap-2 mb-1">
                  <Calendar size={11} className="text-[#58a6ff]" />
                  <span className="text-[9px] text-[#8b949e]">
                    <span className="font-bold text-[#e6edf3]">{remainingDays}</span> days remaining
                    <span className="text-[#484f58]"> · {daysElapsed}/{totalDays} elapsed</span>
                  </span>
                </div>
                {/* Days progress bar */}
                <div className="h-1.5 bg-[#0d1117] rounded-sm overflow-hidden mb-2">
                  <div className="h-full transition-all" style={{ width: `${totalDays > 0 ? Math.min((daysElapsed / totalDays) * 100, 100) : 0}%`, background: isWrapped ? '#a78bfa' : '#58a6ff' }} />
                </div>

                {/* Burn rate */}
                <div className="flex items-center gap-2">
                  <TrendingUp size={11} className="text-[#fbbf24]" />
                  <span className="text-[9px] text-[#8b949e]">
                    Burn: <span className="font-bold text-[#fbbf24]">${burnRate > 0 ? `${Math.round(burnRate).toLocaleString()}/day` : '—'}</span>
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}