import { useState, useEffect } from 'react';
import { Film, Plus, Loader2, Trash2, Clapperboard } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const STATUSES = ['Development', 'Pre-production', 'Production', 'Post-production', 'Wrapped'];
const STATUS_COLOR = { Development: '#8b949e', 'Pre-production': '#fbbf24', Production: '#3fb950', 'Post-production': '#60a5fa', Wrapped: '#a78bfa' };

export default function ProjectLibrary({ onOpen, embedded }) {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ title: '', synopsis: '', status: 'Development', total_budget: '', shoot_days: '' });

  const load = async () => {
    setLoading(true);
    try { setProjects(await base44.entities.FilmProject.list('-created_date', 100)); } catch {}
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const create = async () => {
    if (!form.title.trim()) return;
    setCreating(true);
    try {
      const p = await base44.entities.FilmProject.create({
        title: form.title.trim(), synopsis: form.synopsis, status: form.status,
        total_budget: parseFloat(form.total_budget) || 0, shoot_days: parseInt(form.shoot_days) || 0,
      });
      setForm({ title: '', synopsis: '', status: 'Development', total_budget: '', shoot_days: '' });
      onOpen(p);
    } finally { setCreating(false); }
  };

  const del = async (id) => { await base44.entities.FilmProject.delete(id); load(); };

  return (
    <div className="space-y-4">
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3">
          <Clapperboard size={16} className="text-[#fbbf24]" />
          <h2 className="text-sm font-bold text-[#fbbf24]">{embedded ? 'Create New Production' : 'Project Library'}</h2>
          {!embedded && <span className="text-[9px] text-[#484f58] ml-auto">{projects.length} production{projects.length !== 1 ? 's' : ''}</span>}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="New production title *" className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <input value={form.synopsis} onChange={(e) => setForm({ ...form, synopsis: e.target.value })} placeholder="Logline / synopsis" className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <div className="flex gap-2">
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] flex-1">
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
            <button onClick={create} disabled={!form.title.trim() || creating} className="flex items-center gap-1 bg-[#fbbf24] text-black px-3 py-2 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40">
              {creating ? <Loader2 size={12} className="animate-spin" /> : <Plus size={12} />} New
            </button>
          </div>
        </div>
        <div className="flex gap-2 mt-2">
          <input type="number" value={form.total_budget} onChange={(e) => setForm({ ...form, total_budget: e.target.value })} placeholder="Total budget $" className="flex-1 bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <input type="number" value={form.shoot_days} onChange={(e) => setForm({ ...form, shoot_days: e.target.value })} placeholder="Shoot days" className="w-32 bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12 text-[#484f58]"><Loader2 className="animate-spin" size={20} /></div>
      ) : projects.length === 0 ? (
        <div className="glass-panel clip-corner p-8 text-center">
          <Film size={28} className="text-[#484f58] mx-auto mb-2" />
          <p className="text-xs text-[#8b949e]">No productions yet. Create your first project above to open the production workspace.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {projects.map((p) => (
            <div key={p.id} className="glass-panel clip-corner p-3 glow-hover cursor-pointer group relative" onClick={() => onOpen(p)}>
              <div className="flex items-start justify-between mb-2">
                <Film size={14} className="text-[#fbbf24] shrink-0 mt-0.5" />
                <span className="text-[8px] px-1.5 py-0.5 rounded font-bold" style={{ color: STATUS_COLOR[p.status], border: `1px solid ${STATUS_COLOR[p.status]}40` }}>{p.status}</span>
              </div>
              <h3 className="text-sm font-bold text-[#e6edf3] mb-1 group-hover:text-[#fbbf24] transition-colors">{p.title}</h3>
              <p className="text-[10px] text-[#8b949e] line-clamp-2 mb-2">{p.synopsis || 'No synopsis'}</p>
              <div className="flex items-center justify-between text-[9px] text-[#484f58]">
                <span>{p.total_budget ? `$${Number(p.total_budget).toLocaleString()}` : 'No budget'}</span>
                <span>{p.shoot_days || 0} shoot days</span>
              </div>
              <button onClick={(e) => { e.stopPropagation(); del(p.id); }} className="absolute opacity-0 group-hover:opacity-100 text-[#f85149] p-1 hover:bg-[#f85149]/10 rounded transition-all" style={{ top: 8, right: 8 }}>
                <Trash2 size={10} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}