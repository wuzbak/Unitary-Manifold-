/**
 * CastTab — Cast member management with full CRUD, CSV import/export, and clickable detail drawer.
 */
import { useState, useEffect } from 'react';
import { Plus, Loader2, User } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { exportCSV } from '@/lib/filmers/filmExport';
import { readCSVFile, coerceValue } from '@/lib/filmers/csvImport';
import { logActivity } from '@/lib/filmers/activityLog';
import ImportExportBar from './ImportExportBar';
import EntityDetailDrawer from './EntityDetailDrawer';
import DualEntryToggle, { resolveProjectId } from './DualEntryToggle';

const SAG_STATUSES = ['SAG-AFTRA', 'Non-Union', 'Fi-Core', 'Pending'];
const SAG_COLORS = { 'SAG-AFTRA': '#fbbf24', 'Non-Union': '#8b949e', 'Fi-Core': '#f472b6', 'Pending': '#f85149' };

const FIELDS = [
  { key: 'name', label: 'Name', type: 'text', required: true },
  { key: 'role', label: 'Role / Character', type: 'text' },
  { key: 'agent', label: 'Agent', type: 'text' },
  { key: 'contact', label: 'Contact (email/phone)', type: 'text' },
  { key: 'sag_status', label: 'SAG Status', type: 'select', options: SAG_STATUSES },
  { key: 'day_rate', label: 'Day Rate', type: 'number' },
  { key: 'fitting_date', label: 'Wardrobe Fitting Date', type: 'date' },
  { key: 'character_notes', label: 'Character Notes', type: 'textarea' },
  { key: 'notes', label: 'Notes', type: 'textarea' },
];

export default function CastTab({ project }) {
  const [cast, setCast] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: '', role: '', agent: '', contact: '', sag_status: 'Non-Union', day_rate: 0, fitting_date: '', character_notes: '', notes: '' });
  const [drawer, setDrawer] = useState({ open: false, entity: null });
  const [activity, setActivity] = useState([]);
  const [entryMode, setEntryMode] = useState(project ? 'project' : 'studio');

  useEffect(() => {
    (async () => {
      try {
        const [c, act] = await Promise.all([
          project
            ? base44.entities.CastMember.filter({ project_id: project.id })
            : base44.entities.CastMember.list('-created_date', 500).then((all) => all.filter((i) => !i.project_id)),
          project
            ? base44.entities.ProductionActivity.filter({ project_id: project.id, entity_type: 'cast' }, '-created_date', 20)
            : [],
        ]);
        setCast(c); setActivity(act);
      } finally { setLoading(false); }
    })();
  }, [project?.id]);

  const addCast = async () => {
    if (!form.name.trim()) return;
    const pid = resolveProjectId(entryMode, project);
    const created = await base44.entities.CastMember.create({ ...form, project_id: pid });
    setCast([...cast, created]);
    logActivity(project?.id || '', 'cast', form.name, 'created', `${form.role || 'TBD'} · ${form.sag_status}`);
    setForm({ name: '', role: '', agent: '', contact: '', sag_status: 'Non-Union', day_rate: 0, fitting_date: '', character_notes: '', notes: '' });
    setShowAdd(false);
  };

  const deleteCast = async (id) => {
    const member = cast.find(c => c.id === id);
    await base44.entities.CastMember.delete(id);
    setCast(cast.filter(c => c.id !== id));
    if (member) logActivity(project?.id || '', 'cast', member.name, 'deleted');
    setDrawer({ open: false, entity: null });
  };

  const saveCast = async (id, formData) => {
    await base44.entities.CastMember.update(id, formData);
    setCast(cast.map(c => c.id === id ? { ...c, ...formData } : c));
    const member = cast.find(c => c.id === id);
    logActivity(project?.id || '', 'cast', member?.name || '', 'updated');
  };

  const doExport = () => {
    exportCSV(cast.map(c => ({ name: c.name, role: c.role, agent: c.agent, contact: c.contact, sag: c.sag_status, day_rate: c.day_rate, notes: c.notes })), 'cast_list.csv');
  };

  const doImportCSV = async (file) => {
    const rows = await readCSVFile(file);
    const pid = resolveProjectId(entryMode, project);
    const records = rows.map((row) => {
      const obj = { project_id: pid };
      FIELDS.forEach((f) => {
        const val = coerceValue(row[f.key], f.type);
        if (val !== undefined) obj[f.key] = val;
      });
      return obj;
    }).filter((r) => r.name);
    if (records.length) await base44.entities.CastMember.bulkCreate(records);
    setCast(project ? await base44.entities.CastMember.filter({ project_id: project.id }) : await base44.entities.CastMember.list('-created_date', 500).then((all) => all.filter((i) => !i.project_id)));
    logActivity(project?.id || '', 'cast', `${records.length} members`, 'created', 'CSV import');
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#484f58]" size={18} /></div>;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2"><User size={14} className="text-[#fbbf24]" /><span className="text-xs font-bold text-[#fbbf24]">Cast Members ({cast.length})</span></div>
        <div className="flex items-center gap-2 flex-wrap">
          <ImportExportBar onImportCSV={doImportCSV} onExportCSV={doExport} accent="#fbbf24" disabled={!cast.length} />
          <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1 px-2 py-1 bg-[#fbbf24] text-black rounded text-[9px] font-bold"><Plus size={10} /> Add Cast</button>
        </div>
      </div>

      {showAdd && (
        <div className="glass-panel clip-corner p-3 space-y-2 border-l-2 border-[#fbbf24]">
          <DualEntryToggle mode={entryMode} onChange={setEntryMode} projectName={project?.title} />
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Name *" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} placeholder="Role / Character" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.agent} onChange={e => setForm({ ...form, agent: e.target.value })} placeholder="Agent" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.contact} onChange={e => setForm({ ...form, contact: e.target.value })} placeholder="Contact (email/phone)" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <select value={form.sag_status} onChange={e => setForm({ ...form, sag_status: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              {SAG_STATUSES.map(s => <option key={s}>{s}</option>)}
            </select>
            <input type="number" value={form.day_rate} onChange={e => setForm({ ...form, day_rate: +e.target.value })} placeholder="Day rate $" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          </div>
          <input value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Notes (wardrobe sizes, special requirements, etc.)" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          <div className="flex gap-2">
            <button onClick={addCast} className="px-3 py-1.5 bg-[#fbbf24] text-black rounded text-[10px] font-bold">Save</button>
            <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
          </div>
        </div>
      )}

      {!cast.length ? (
        <div className="text-center py-8 text-[10px] text-[#484f58] italic">No cast members yet. Click "Add Cast" or import a CSV.</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {cast.map(c => (
            <div key={c.id} className="glass-panel clip-corner p-3 group cursor-pointer hover:border-[#fbbf24]/40 transition-colors" onClick={() => setDrawer({ open: true, entity: c })}>
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-bold text-[#e6edf3]">{c.name}</span>
                    <span className="text-[8px] px-1.5 py-0.5 rounded border font-bold" style={{ color: SAG_COLORS[c.sag_status], borderColor: `${SAG_COLORS[c.sag_status]}40` }}>{c.sag_status}</span>
                    {c.fitting_date && <span className="text-[7px] px-1 py-0.5 rounded bg-[#bc8cff]/15 text-[#bc8cff]">Fitting {c.fitting_date}</span>}
                  </div>
                  {c.role && <div className="text-[10px] text-[#fbbf24] mt-0.5">as {c.role}</div>}
                  <div className="text-[9px] text-[#8b949e] mt-1 space-y-0.5">
                    {c.agent && <div>Agent: {c.agent}</div>}
                    {c.contact && <div>Contact: {c.contact}</div>}
                    {c.day_rate > 0 && <div className="text-[#3fb950]">Day rate: ${c.day_rate.toLocaleString()}</div>}
                    {c.notes && <div className="text-[#484f58] italic line-clamp-1">{c.notes}</div>}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <EntityDetailDrawer
        open={drawer.open}
        entity={drawer.entity}
        entityName="CastMember"
        fields={FIELDS}
        accent="#fbbf24"
        onClose={() => setDrawer({ open: false, entity: null })}
        onSave={saveCast}
        onDelete={deleteCast}
        activityLog={activity.filter((a) => a.entity_name === drawer.entity?.name)}
        exportRows={(entity) => [{ name: entity.name, role: entity.role, agent: entity.agent, contact: entity.contact, sag_status: entity.sag_status, day_rate: entity.day_rate, notes: entity.notes }]}
        exportFilename={`cast_${drawer.entity?.name || 'member'}.csv`}
      />
    </div>
  );
}