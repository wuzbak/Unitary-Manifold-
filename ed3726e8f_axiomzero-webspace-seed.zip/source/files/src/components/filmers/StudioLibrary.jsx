/**
 * StudioLibrary — Shared library of standalone (project_id=null) records.
 * Browse, search, and assign/clone studio records into the current project.
 * Supports: Cast, Crew, Locations, Department Items, Local Resources, Scripts.
 */
import { useState, useEffect } from 'react';
import { BookOpen, Search, ArrowRight, Loader2, Users, MapPin, Package, Building2, FileText } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/filmers/activityLog';

const ENTITY_TYPES = [
  { key: 'CastMember', label: 'Cast', icon: Users, color: '#fbbf24' },
  { key: 'CrewMember', label: 'Crew', icon: Users, color: '#58a6ff' },
  { key: 'Location', label: 'Locations', icon: MapPin, color: '#34d399' },
  { key: 'DepartmentItem', label: 'Dept Items', icon: Package, color: '#58a6ff' },
  { key: 'LocalResource', label: 'Resources', icon: Building2, color: '#4dd0e1' },
  { key: 'Script', label: 'Scripts', icon: FileText, color: '#a78bfa' },
];

export default function StudioLibrary({ project, onAssign }) {
  const [activeType, setActiveType] = useState('CastMember');
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const load = async () => {
    setLoading(true);
    try {
      // Fetch standalone records (project_id is null/empty)
      const all = await base44.entities[activeType].list('-created_date', 200);
      // Filter to standalone (no project_id)
      const standalone = all.filter(r => !r.project_id);
      setRecords(standalone);
    } catch {
      setRecords([]);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, [activeType]);

  const assignToProject = async (record) => {
    if (!project) return;
    // Clone the record into the current project
    const { id, created_date, updated_date, created_by_id, project_id, ...fields } = record;
    const newRecord = await base44.entities[activeType].create({ ...fields, project_id: project.id });
    logActivity(project.id, activeType.toLowerCase(), fields.name || fields.item_name || 'record', 'assigned from studio library');
    if (onAssign) onAssign(newRecord);
  };

  const filtered = search
    ? records.filter(r => {
        const name = r.name || r.item_name || r.title || '';
        return name.toLowerCase().includes(search.toLowerCase());
      })
    : records;

  const meta = ENTITY_TYPES.find(t => t.key === activeType);
  const Icon = meta.icon;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <BookOpen size={14} className="text-[#4dd0e1]" />
          <span className="text-xs font-bold text-[#4dd0e1]">Studio Library</span>
          <span className="text-[9px] text-[#484f58]">Standalone records — assign to any project</span>
        </div>
        {project && (
          <div className="text-[9px] text-[#8b949e]">
            Assign to: <span className="text-[#fbbf24] font-bold">{project.title}</span>
          </div>
        )}
      </div>

      {/* Entity type selector */}
      <div className="flex items-center gap-1 flex-wrap">
        {ENTITY_TYPES.map(t => {
          const TIcon = t.icon;
          return (
            <button
              key={t.key}
              onClick={() => setActiveType(t.key)}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded text-[9px] font-bold border transition-colors ${activeType === t.key ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}
              style={activeType === t.key ? { background: t.color } : {}}
            >
              <TIcon size={10} /> {t.label}
            </button>
          );
        })}
      </div>

      {/* Search */}
      <div className="flex items-center gap-2">
        <Search size={12} className="text-[#484f58]" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder={`Search ${meta.label.toLowerCase()}…`}
          className="flex-1 bg-[#0B0F13] border border-[#30363d] rounded px-3 py-1.5 text-[10px] text-[#e6edf3]"
        />
      </div>

      {/* Records */}
      {loading ? (
        <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#484f58]" size={18} /></div>
      ) : filtered.length === 0 ? (
        <div className="glass-panel clip-corner p-8 text-center">
          <Icon size={28} className="text-[#484f58] mx-auto mb-3" />
          <p className="text-xs text-[#8b949e] mb-1">No standalone {meta.label.toLowerCase()} yet.</p>
          <p className="text-[10px] text-[#484f58]">Create records with "Studio" mode to populate this library.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          {filtered.map(r => {
            const name = r.name || r.item_name || r.title || 'Unnamed';
            const subtitle = r.role || r.position || r.department || r.address || r.category || '';
            return (
              <div key={r.id} className="glass-panel clip-corner p-3 group">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-[#e6edf3] truncate">{name}</div>
                    {subtitle && <div className="text-[9px] text-[#8b949e] truncate">{subtitle}</div>}
                    {r.sag_status && <span className="text-[8px] text-[#fbbf24]">{r.sag_status}</span>}
                    {r.union_status && <span className="text-[8px] text-[#58a6ff]">{r.union_status}</span>}
                    {r.day_rate > 0 && <div className="text-[9px] text-[#3fb950]">${r.day_rate.toLocaleString()}/day</div>}
                  </div>
                  {project && (
                    <button
                      onClick={() => assignToProject(r)}
                      className="flex items-center gap-1 px-2 py-1 rounded text-[9px] font-bold bg-[#fbbf24]/20 text-[#fbbf24] hover:bg-[#fbbf24]/30 transition-colors shrink-0"
                      title={`Assign to ${project.title}`}
                    >
                      <ArrowRight size={10} /> Assign
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}