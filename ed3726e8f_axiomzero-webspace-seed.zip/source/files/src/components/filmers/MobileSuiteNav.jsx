/**
 * MobileSuiteNav — Mobile bottom-tab navigation for the production suite.
 * 5 primary destinations: Studio, Script, Schedule, Cast/Crew, Finance.
 * Each expands to sub-tabs via a swipeable horizontal scroll above the bar.
 */
import { Building2, FileText, Calendar, Users, DollarSign } from 'lucide-react';
import { DEPARTMENTS } from '@/lib/filmers/departments';

const PRIMARY_TABS = [
  { id: 'studio', label: 'Studio', icon: Building2, color: '#4dd0e1', tabs: ['studio_dashboard', 'studio_pool', 'library', 'projects'] },
  { id: 'script', label: 'Script', icon: FileText, color: '#a78bfa', tabs: ['writers_room', 'script', 'cinematography'] },
  { id: 'schedule', label: 'Schedule', icon: Calendar, color: '#f472b6', tabs: ['scheduling', 'call_sheets', 'locations', 'storyboard'] },
  { id: 'castcrew', label: 'Cast/Crew', icon: Users, color: '#fbbf24', tabs: ['cast', 'crew', 'actor_portal', 'time_cards', 'inventory_overview', ...DEPARTMENTS.map(d => d.key.toLowerCase().replace(/\s/g, '_'))] },
  { id: 'finance', label: 'Finance', icon: DollarSign, color: '#60a5fa', tabs: ['finance', 'ad_suite', 'upm_overview', 'film_credits', 'local_resources', 'export'] },
];

// Map any tab id → primary group
const TAB_TO_PRIMARY = {};
PRIMARY_TABS.forEach(pt => pt.tabs.forEach(t => { TAB_TO_PRIMARY[t] = pt.id; }));
// Dashboard goes to studio
TAB_TO_PRIMARY['dashboard'] = 'studio';

const SUB_TAB_LABELS = {
  studio_dashboard: 'Dashboard', studio_pool: 'Pool', library: 'Library', projects: 'Projects', dashboard: 'Proj Dashboard',
  writers_room: 'Writers Room', script: 'Script', cinematography: 'Cinematography',
  scheduling: 'Stripboard', call_sheets: 'Call Sheets', locations: 'Locations', storyboard: 'Storyboard',
  cast: 'Cast', crew: 'Crew', actor_portal: 'Actor Portal', time_cards: 'Time Cards', inventory_overview: 'Inventory',
  finance: 'Finance', ad_suite: 'AD Suite', upm_overview: 'UPM', film_credits: 'Credits', local_resources: 'Resources', export: 'Export',
};

export default function MobileSuiteNav({ activeTab, onSelectTab }) {
  const primaryId = TAB_TO_PRIMARY[activeTab] || 'studio';
  const primaryTab = PRIMARY_TABS.find(t => t.id === primaryId);
  const subTabs = primaryTab?.tabs.filter(t => t !== activeTab) || [];
  const activePrimary = PRIMARY_TABS.find(t => t.id === primaryId);

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40">
      {/* Sub-tab scroll row */}
      {subTabs.length > 0 && (
        <div className="glass-strong border-t border-[#30363d] px-2 py-1.5 overflow-x-auto">
          <div className="flex items-center gap-1 min-w-max">
            {subTabs.map(st => (
              <button
                key={st}
                onClick={() => onSelectTab(st)}
                className={`px-2.5 py-1 rounded text-[9px] font-bold whitespace-nowrap transition-colors ${activeTab === st ? 'text-black' : 'text-[#8b949e]'}`}
                style={activeTab === st ? { background: activePrimary.color } : {}}
              >
                {SUB_TAB_LABELS[st] || st.replace(/_/g, ' ')}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Primary bottom tab bar */}
      <div className="glass-strong border-t border-[#30363d] flex">
        {PRIMARY_TABS.map(pt => {
          const Icon = pt.icon;
          const isActive = pt.id === primaryId;
          return (
            <button
              key={pt.id}
              onClick={() => onSelectTab(pt.tabs[0])}
              className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2 transition-colors"
              style={{ color: isActive ? pt.color : '#484f58' }}
            >
              <Icon size={16} />
              <span className="text-[8px] font-bold">{pt.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}