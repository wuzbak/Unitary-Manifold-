/**
 * DepartmentReviewTab — Department head review & verification of script breakdown items.
 * Shows each department's extracted requirements (props, wardrobe, VFX, stunts, etc.)
 * grouped by scene, with per-item review status: pending → verified/rejected/needs_revision.
 * Review status persists to the BreakdownReview entity.
 */
import { useState, useEffect, useMemo, useCallback } from 'react';
import { Check, X, AlertCircle, Loader2, ChevronDown, ChevronRight, Camera, Shirt, Brush, Mic, Sparkles, ShieldAlert, Package, Sofa, Palette, Lightbulb, Wrench, ClipboardCheck } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/filmers/activityLog';

const REVIEW_STATUSES = [
  { key: 'pending', label: 'Pending', color: '#8b949e', icon: AlertCircle },
  { key: 'verified', label: 'Verified', color: '#3fb950', icon: Check },
  { key: 'rejected', label: 'Rejected', color: '#f85149', icon: X },
  { key: 'needs_revision', label: 'Needs Revision', color: '#fbbf24', icon: AlertCircle },
];

const STATUS_MAP = Object.fromEntries(REVIEW_STATUSES.map(s => [s.key, s]));

// Map breakdown sheet keys to department display info
const DEPT_SHEET_META = {
  camera: { label: 'Camera', icon: Camera, color: '#fbbf24' },
  wardrobe: { label: 'Wardrobe', icon: Shirt, color: '#f472b6' },
  hmu: { label: 'Hair & Makeup', icon: Brush, color: '#bc8cff' },
  sound: { label: 'Sound', icon: Mic, color: '#4dd0e1' },
  vfx: { label: 'VFX / Special Effects', icon: Sparkles, color: '#a78bfa' },
  stunts: { label: 'Stunts / Safety', icon: ShieldAlert, color: '#f85149' },
  props: { label: 'Props', icon: Package, color: '#fbbf24' },
  set_decoration: { label: 'Set Decoration', icon: Sofa, color: '#2dd4bf' },
  art_department: { label: 'Art Department', icon: Palette, color: '#34d399' },
  lighting_electric: { label: 'Lighting/Electric', icon: Lightbulb, color: '#facc15' },
  grip: { label: 'Grip', icon: Wrench, color: '#fb923c' },
};

export default function DepartmentReviewTab({ breakdown, project, scenes: dbScenes }) {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [expandedDept, setExpandedDept] = useState(null);
  const [filterDept, setFilterDept] = useState('all');

  const { departmentSheets, scenes } = breakdown || {};

  // Load existing review records
  const loadReviews = useCallback(async () => {
    if (!project) { setLoading(false); return; }
    try {
      const existing = await base44.entities.BreakdownReview.filter({ project_id: project.id });
      setReviews(existing);
    } finally { setLoading(false); }
  }, [project]);

  useEffect(() => { loadReviews(); }, [loadReviews]);

  // Build a lookup: `${sceneIndex}_${department}_${keyword}` → review record
  const reviewMap = useMemo(() => {
    const map = {};
    reviews.forEach(r => {
      map[`${r.scene_index}_${r.department}_${r.keyword}`] = r;
    });
    return map;
  }, [reviews]);

  // Flatten all sheet items into a unified list with department grouping
  const allSheetItems = useMemo(() => {
    if (!departmentSheets) return [];
    const items = [];
    for (const [sceneIdxStr, sheet] of Object.entries(departmentSheets)) {
      const sceneIdx = Number(sceneIdxStr);
      const scene = scenes?.find(s => s.sort_order === sceneIdx);
      for (const [deptKey, flags] of Object.entries(sheet)) {
        for (const flag of flags) {
          items.push({
            sceneIdx,
            sceneNumber: scene?.scene_number || `?`,
            department: deptKey,
            keyword: flag.keyword,
            sourceNote: flag.note || '',
            character: flag.character || '',
          });
        }
      }
    }
    return items;
  }, [departmentSheets, scenes]);

  // Group by department
  const byDepartment = useMemo(() => {
    const groups = {};
    allSheetItems.forEach(item => {
      if (!groups[item.department]) groups[item.department] = [];
      groups[item.department].push(item);
    });
    return groups;
  }, [allSheetItems]);

  // Review progress per department
  const deptProgress = useMemo(() => {
    const progress = {};
    for (const [dept, items] of Object.entries(byDepartment)) {
      const reviewed = items.filter(i => reviewMap[`${i.sceneIdx}_${i.department}_${i.keyword}`]?.review_status !== undefined);
      const verified = items.filter(i => reviewMap[`${i.sceneIdx}_${i.department}_${i.keyword}`]?.review_status === 'verified');
      const rejected = items.filter(i => reviewMap[`${i.sceneIdx}_${i.department}_${i.keyword}`]?.review_status === 'rejected');
      const needsRevision = items.filter(i => reviewMap[`${i.sceneIdx}_${i.department}_${i.keyword}`]?.review_status === 'needs_revision');
      progress[dept] = {
        total: items.length,
        reviewed: reviewed.length,
        verified: verified.length,
        rejected: rejected.length,
        needsRevision: needsRevision.length,
        pending: items.length - reviewed.length,
        pct: items.length > 0 ? Math.round((reviewed.length / items.length) * 100) : 0,
      };
    }
    return progress;
  }, [byDepartment, reviewMap]);

  const updateReview = async (item, newStatus, notes = '') => {
    const key = `${item.sceneIdx}_${item.department}_${item.keyword}`;
    const existing = reviewMap[key];
    setSaving(true);
    try {
      if (existing) {
        const updated = await base44.entities.BreakdownReview.update(existing.id, {
          review_status: newStatus,
          reviewer_notes: notes,
          reviewed_date: new Date().toISOString().split('T')[0],
        });
        setReviews(prev => prev.map(r => r.id === existing.id ? updated : r));
      } else {
        const created = await base44.entities.BreakdownReview.create({
          project_id: project.id,
          scene_number: item.sceneNumber,
          scene_index: item.sceneIdx,
          department: item.department,
          keyword: item.keyword,
          source_note: item.sourceNote,
          review_status: newStatus,
          reviewer_notes: notes,
          reviewed_date: new Date().toISOString().split('T')[0],
        });
        setReviews(prev => [...prev, created]);
      }
      if (newStatus !== 'pending') {
        logActivity(project.id, 'breakdown_review', `${DEPT_SHEET_META[item.department]?.label || item.department}: ${item.keyword}`, 'reviewed', newStatus);
      }
    } finally { setSaving(false); }
  };

  const updateNotes = async (item, notes) => {
    const key = `${item.sceneIdx}_${item.department}_${item.keyword}`;
    const existing = reviewMap[key];
    if (!existing) return;
    await base44.entities.BreakdownReview.update(existing.id, { reviewer_notes: notes });
    setReviews(prev => prev.map(r => r.id === existing.id ? { ...r, reviewer_notes: notes } : r));
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#484f58]" size={18} /></div>;

  if (!allSheetItems.length) {
    return (
      <div className="glass-strong clip-corner p-8 text-center">
        <ClipboardCheck size={28} className="text-[#484f58] mx-auto mb-3" />
        <p className="text-xs text-[#8b949e] mb-2">No department breakdown items to review.</p>
        <p className="text-[10px] text-[#484f58]">Import or create a screenplay, then run the breakdown to generate department requirements.</p>
      </div>
    );
  }

  const deptKeys = Object.keys(byDepartment).sort();
  const filteredDepts = filterDept === 'all' ? deptKeys : [filterDept];

  // Overall progress
  const totalItems = allSheetItems.length;
  const totalReviewed = allSheetItems.filter(i => reviewMap[`${i.sceneIdx}_${i.department}_${i.keyword}`]?.review_status !== undefined).length;
  const totalVerified = allSheetItems.filter(i => reviewMap[`${i.sceneIdx}_${i.department}_${i.keyword}`]?.review_status === 'verified').length;
  const overallPct = totalItems > 0 ? Math.round((totalReviewed / totalItems) * 100) : 0;

  return (
    <div className="space-y-3">
      {/* Overall progress header */}
      <div className="glass-strong clip-corner p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <ClipboardCheck size={14} className="text-[#4dd0e1]" />
            <span className="text-xs font-bold text-[#4dd0e1]">Department Head Review</span>
            <span className="text-[9px] text-[#484f58]">{totalReviewed}/{totalItems} reviewed · {totalVerified} verified</span>
          </div>
          <select value={filterDept} onChange={e => setFilterDept(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[10px] text-[#e6edf3]">
            <option value="all">All Departments</option>
            {deptKeys.map(d => <option key={d} value={d}>{DEPT_SHEET_META[d]?.label || d}</option>)}
          </select>
        </div>
        <div className="h-2 bg-[#161b22] rounded-sm overflow-hidden">
          <div className="h-full transition-all" style={{ width: `${overallPct}%`, background: overallPct === 100 ? '#3fb950' : '#4dd0e1' }} />
        </div>
        <div className="flex items-center gap-3 mt-1.5 flex-wrap">
          {REVIEW_STATUSES.map(s => {
            const count = s.key === 'pending' ? totalItems - totalReviewed : allSheetItems.filter(i => reviewMap[`${i.sceneIdx}_${i.department}_${i.keyword}`]?.review_status === s.key).length;
            return (
              <div key={s.key} className="flex items-center gap-1">
                <s.icon size={9} style={{ color: s.color }} />
                <span className="text-[8px] text-[#8b949e]">{s.label}: {count}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Department sections */}
      {filteredDepts.map(deptKey => {
        const meta = DEPT_SHEET_META[deptKey] || { label: deptKey, icon: Package, color: '#8b949e' };
        const Icon = meta.icon;
        const items = byDepartment[deptKey];
        const prog = deptProgress[deptKey];
        const isExpanded = expandedDept === deptKey || filteredDepts.length === 1;

        return (
          <div key={deptKey} className="glass-panel clip-corner overflow-hidden border-l-2" style={{ borderLeftColor: meta.color }}>
            <button
              onClick={() => setExpandedDept(isExpanded ? null : deptKey)}
              className="w-full flex items-center justify-between p-3 hover:bg-[#161b22] transition-colors"
            >
              <div className="flex items-center gap-2">
                {isExpanded ? <ChevronDown size={12} className="text-[#484f58]" /> : <ChevronRight size={12} className="text-[#484f58]" />}
                <Icon size={14} style={{ color: meta.color }} />
                <span className="text-xs font-bold" style={{ color: meta.color }}>{meta.label}</span>
                <span className="text-[9px] text-[#484f58]">{prog.total} items · {prog.verified} verified · {prog.rejected} rejected · {prog.needsRevision} needs revision</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-20 h-1.5 bg-[#161b22] rounded-full overflow-hidden">
                  <div className="h-full transition-all" style={{ width: `${prog.pct}%`, background: prog.pct === 100 ? '#3fb950' : meta.color }} />
                </div>
                <span className="text-[9px] font-bold" style={{ color: prog.pct === 100 ? '#3fb950' : '#8b949e' }}>{prog.pct}%</span>
              </div>
            </button>

            {isExpanded && (
              <div className="border-t border-[#30363d] p-2 space-y-1.5 max-h-[500px] overflow-y-auto">
                {/* Group items by scene */}
                {Object.entries(
                  items.reduce((acc, item) => {
                    const key = `Scene ${item.sceneNumber}`;
                    if (!acc[key]) acc[key] = [];
                    acc[key].push(item);
                    return acc;
                  }, {})
                ).map(([sceneLabel, sceneItems]) => (
                  <div key={sceneLabel}>
                    <div className="text-[9px] font-bold text-[#a78bfa] uppercase mb-1 sticky top-0 bg-[#0d1117] py-0.5">{sceneLabel}</div>
                    {sceneItems.map((item, i) => {
                      const key = `${item.sceneIdx}_${item.department}_${item.keyword}`;
                      const review = reviewMap[key];
                      const status = review?.review_status || 'pending';
                      const statusMeta = STATUS_MAP[status];
                      return (
                        <div key={i} className="flex items-start gap-2 p-2 rounded border border-[#30363d] hover:border-[#4dd0e1]/30 mb-1">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-[10px] font-bold text-[#e6edf3]">{item.keyword}</span>
                              {item.character && <span className="text-[8px] px-1 py-0.5 rounded bg-[#fbbf24]/10 text-[#fbbf24]">{item.character}</span>}
                              <span className="text-[8px] px-1.5 py-0.5 rounded font-bold" style={{ background: `${statusMeta.color}20`, color: statusMeta.color }}>{statusMeta.label}</span>
                            </div>
                            {item.sourceNote && (
                              <div className="text-[8px] text-[#484f58] italic mt-0.5 line-clamp-2">"{item.sourceNote}"</div>
                            )}
                            {review?.reviewer_notes && (
                              <div className="text-[9px] text-[#8b949e] mt-1 p-1 rounded bg-[#161b22]">📝 {review.reviewer_notes}</div>
                            )}
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            {REVIEW_STATUSES.map(s => (
                              <button
                                key={s.key}
                                onClick={() => updateReview(item, s.key, review?.reviewer_notes || '')}
                                disabled={saving}
                                title={s.label}
                                className={`p-1 rounded border transition-all ${status === s.key ? 'border-transparent' : 'border-[#30363d] hover:border-[#4dd0e1]/40'}`}
                                style={status === s.key ? { background: `${s.color}20`, borderColor: `${s.color}60` } : {}}
                              >
                                <s.icon size={10} style={{ color: status === s.key ? s.color : '#484f58' }} />
                              </button>
                            ))}
                          </div>
                          <input
                            defaultValue={review?.reviewer_notes || ''}
                            onBlur={e => { if (review && e.target.value !== (review.reviewer_notes || '')) updateNotes(item, e.target.value); }}
                            placeholder="Add note..."
                            className="w-32 shrink-0 bg-[#0B0F13] border border-[#30363d] rounded px-1.5 py-1 text-[9px] text-[#e6edf3] focus:border-[#4dd0e1]/40"
                          />
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}