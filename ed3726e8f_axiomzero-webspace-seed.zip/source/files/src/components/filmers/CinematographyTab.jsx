/**
 * CinematographyTab — Lighting calculator, AI coverage, shot list with CRUD + CSV import/export + detail drawer.
 */
import { useState, useEffect } from 'react';
import { Lightbulb, Play, Plus, ClipboardList, CheckCircle2, AlertTriangle, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { calcLighting, COVERAGE_TYPES, SCENE_TYPES, validateShotList } from '@/lib/filmers/filmEngine';
import { exportCSV } from '@/lib/filmers/filmExport';
import { readCSVFile, coerceValue } from '@/lib/filmers/csvImport';
import { logActivity } from '@/lib/filmers/activityLog';
import AICoverage from './AICoverage';
import ImportExportBar from './ImportExportBar';
import EntityDetailDrawer from './EntityDetailDrawer';

const SHOT_FIELDS = [
  { key: 'coverage_type', label: 'Coverage Type', type: 'select', options: COVERAGE_TYPES },
  { key: 'lens', label: 'Lens', type: 'text' },
  { key: 'movement', label: 'Movement', type: 'text' },
  { key: 'notes', label: 'Notes', type: 'textarea' },
];

export default function CinematographyTab({ project }) {
  const [lightDist, setLightDist] = useState('10');
  const [lightPower, setLightPower] = useState('1000');
  const [lightResult, setLightResult] = useState(null);
  const [synopsis, setSynopsis] = useState('');
  const [sceneType, setSceneType] = useState('drama');
  const [shots, setShots] = useState([]);
  const [shotType, setShotType] = useState('master');
  const [validate, setValidate] = useState(null);
  const [loading, setLoading] = useState(true);
  const [drawer, setDrawer] = useState({ open: false, entity: null });

  const loadShots = async () => {
    setLoading(true);
    try { setShots(await base44.entities.Shot.filter({ project_id: project.id }, 'sort_order', 500)); } finally { setLoading(false); }
  };
  useEffect(() => { loadShots(); }, [project.id]);

  const addShot = async () => {
    const order = shots.length;
    const s = await base44.entities.Shot.create({ project_id: project.id, coverage_type: shotType, sort_order: order });
    setShots([...shots, s]);
    logActivity(project.id, 'shot', `Shot ${order + 1}`, 'created', shotType);
  };
  const delShot = async (id) => {
    await base44.entities.Shot.delete(id);
    setShots(shots.filter((s) => s.id !== id));
    setDrawer({ open: false, entity: null });
  };
  const saveShot = async (id, formData) => {
    await base44.entities.Shot.update(id, formData);
    setShots(shots.map(s => s.id === id ? { ...s, ...formData } : s));
  };
  const runValidate = () => setValidate(validateShotList(shots));

  const doExport = () => {
    exportCSV(shots.map((s, i) => ({ order: i + 1, coverage: s.coverage_type, lens: s.lens, movement: s.movement, notes: s.notes })), 'shot_list.csv');
  };

  const doImportCSV = async (file) => {
    const rows = await readCSVFile(file);
    const records = rows.map((row, i) => {
      const obj = { project_id: project.id, sort_order: shots.length + i };
      SHOT_FIELDS.forEach((f) => {
        const val = coerceValue(row[f.key], f.type);
        if (val !== undefined) obj[f.key] = val;
      });
      return obj;
    }).filter((r) => r.coverage_type);
    if (records.length) await base44.entities.Shot.bulkCreate(records);
    await loadShots();
    logActivity(project.id, 'shot', `${records.length} shots`, 'created', 'CSV import');
  };

  return (
    <div className="space-y-4">
      {/* Lighting */}
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><Lightbulb size={14} className="text-[#fbbf24]" /><span className="text-xs font-bold text-[#fbbf24]">Lighting Calculator — Inverse Square Law</span></div>
        <div className="grid grid-cols-2 gap-3 mb-3">
          <div><label className="text-[9px] text-[#8b949e] block mb-1">Distance (feet)</label>
            <input type="number" value={lightDist} onChange={(e) => setLightDist(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" /></div>
          <div><label className="text-[9px] text-[#8b949e] block mb-1">Fixture Power (watts)</label>
            <input type="number" value={lightPower} onChange={(e) => setLightPower(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" /></div>
        </div>
        <button onClick={() => setLightResult(calcLighting(parseFloat(lightDist) || 0, parseFloat(lightPower) || 0))} className="flex items-center gap-1.5 bg-[#fbbf24] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80"><Play size={12} /> Calculate</button>
        {lightResult && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-3">
            {[['Lumens', lightResult.lumens.toLocaleString()], ['Lux', lightResult.lux], ['EV', lightResult.ev], ['f-stop', `f/${lightResult.fStop}`], ['Color Temp', `${lightResult.colorTempK}K`]].map(([l, v]) => (
              <div key={l} className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-center"><div className="text-[8px] text-[#8b949e] uppercase tracking-wider">{l}</div><div className="text-sm text-[#fbbf24] font-bold">{v}</div></div>
            ))}
          </div>
        )}
      </div>

      {/* AI Coverage */}
      <div className="glass-strong clip-corner p-4 space-y-3">
        <div className="flex items-center gap-2"><ClipboardList size={14} className="text-[#fbbf24]" /><span className="text-xs font-bold text-[#fbbf24]">Coverage Suggestions</span></div>
        <textarea value={synopsis} onChange={(e) => setSynopsis(e.target.value)} placeholder="Scene synopsis…" rows={2} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] resize-none" />
        <select value={sceneType} onChange={(e) => setSceneType(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]">
          {SCENE_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
        <AICoverage synopsis={synopsis} sceneType={sceneType} />
      </div>

      {/* Shot list */}
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
          <div className="flex items-center gap-2"><ClipboardList size={14} className="text-[#fbbf24]" /><span className="text-xs font-bold text-[#fbbf24]">Shot List ({shots.length})</span></div>
          <ImportExportBar onImportCSV={doImportCSV} onExportCSV={doExport} accent="#fbbf24" disabled={!shots.length} />
        </div>
        <div className="flex flex-wrap gap-2 mb-3">
          <select value={shotType} onChange={(e) => setShotType(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]">
            {COVERAGE_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <button onClick={addShot} className="flex items-center gap-1 bg-[#30363d] text-[#e6edf3] px-3 py-2 rounded text-xs hover:bg-[#484f58]"><Plus size={12} /> Add Shot</button>
          <button onClick={runValidate} disabled={!shots.length} className="flex items-center gap-1.5 bg-[#fbbf24] text-black px-3 py-2 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"><Play size={12} /> Validate</button>
        </div>
        {loading ? <div className="flex justify-center py-4"><Loader2 className="animate-spin text-[#484f58]" size={16} /></div> : (
          <div className="flex flex-wrap gap-1.5 mb-3">
            {shots.map((s, i) => (
              <span key={s.id} className="text-[10px] bg-[#0B0F13] border border-[#30363d] text-[#e6edf3] px-2 py-1 rounded cursor-pointer hover:border-[#fbbf24]/40 transition-colors" onClick={() => setDrawer({ open: true, entity: s })}>
                {i + 1}. {s.coverage_type} {s.lens && `· ${s.lens}`}
              </span>
            ))}
          </div>
        )}
        {validate && (
          <div className="space-y-1">
            <div className={`flex items-center gap-2 text-xs font-bold ${validate.valid ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>
              {validate.valid ? <CheckCircle2 size={14} /> : <AlertTriangle size={14} />}{validate.valid ? 'VALID — master shot present' : 'INVALID — issues found'}
            </div>
            {validate.issues.map((iss, i) => <div key={i} className="text-[10px] text-[#f85149] pl-4">⚠ {iss}</div>)}
            {validate.warnings.map((w, i) => <div key={i} className="text-[10px] text-[#d29922] pl-4">⚠ {w}</div>)}
          </div>
        )}
      </div>

      <EntityDetailDrawer
        open={drawer.open}
        entity={drawer.entity}
        entityName="Shot"
        fields={SHOT_FIELDS}
        titleKey="coverage_type"
        titleFallback="Shot"
        accent="#fbbf24"
        onClose={() => setDrawer({ open: false, entity: null })}
        onSave={saveShot}
        onDelete={delShot}
        exportRows={(entity) => [{ coverage: entity.coverage_type, lens: entity.lens, movement: entity.movement, notes: entity.notes }]}
        exportFilename={`shot_${drawer.entity?.coverage_type || 'item'}.csv`}
      />
    </div>
  );
}