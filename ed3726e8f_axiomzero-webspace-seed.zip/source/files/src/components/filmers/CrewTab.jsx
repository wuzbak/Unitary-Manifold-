/**
 * CrewTab — Crew member management grouped by department, full CRUD + CSV import/export + detail drawer.
 */
import { useState, useEffect } from 'react';
import { Plus, Loader2, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { exportCSV } from '@/lib/filmers/filmExport';
import { readCSVFile, coerceValue } from '@/lib/filmers/csvImport';
import { DEPARTMENTS } from '@/lib/filmers/departments';
import { logActivity } from '@/lib/filmers/activityLog';
import ImportExportBar from './ImportExportBar';
import EntityDetailDrawer from './EntityDetailDrawer';
import DualEntryToggle, { resolveProjectId } from './DualEntryToggle';

const UNION_STATUSES = ['IATSE', 'DGA', 'Non-Union', 'Fi-Core', 'Pending'];
const DEPT_OPTIONS = [...DEPARTMENTS.map(d => d.key), 'Production', 'Post-Production'];

const FIELDS = [
  { key: 'name', label: 'Name', type: 'text', required: true },
  { key: 'department', label: 'Department', type: 'select', options: DEPT_OPTIONS },
  { key: 'position', label: 'Position', type: 'text' },
  { key: 'union_status', label: 'Union Status', type: 'select', options: UNION_STATUSES },
  { key: 'above_below_line', label: 'Above/Below Line', type: 'select', options: ['above_line', 'below_line'] },
  { key: 'day_rate', label: 'Day Rate', type: 'number' },
  { key: 'contact', label: 'Contact', type: 'text' },
  { key: 'availability_status', label: 'Availability', type: 'select', options: ['available', 'booked', 'hold', 'unavailable'] },
  { key: 'emergency_contact', label: 'Emergency Contact', type: 'text' },
  { key: 'notes', label: 'Notes', type: 'textarea' },
];

export default function CrewTab({ project }) {
  const [crew, setCrew] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: '', department: 'Camera', position: '', union_status: 'Non-Union', above_below_line: 'below_line', day_rate: 0, contact: '', availability_status: 'available', emergency_contact: '', notes: '' });
  const [drawer, setDrawer] = useState({ open: false, entity: null });
  const [activity, setActivity] = useState([]);
  const [entryMode, setEntryMode] = useState(project ? 'project' : 'studio');

  useEffect(() => {
    (async () => {
      try {
        const [c, act] = await Promise.all([
          project
            ? base44.entities.CrewMember.filter({ project_id: project.id })
            : base44.entities.CrewMember.list('-created_date', 500).then((all) => all.filter((i) => !i.project_id)),
          project
            ? base44.entities.ProductionActivity.filter({ project_id: project.id, entity_type: 'crew' }, '-created_date', 20)
            : [],
        ]);
        setCrew(c); setActivity(act);
      } finally { setLoading(false); }
    })();
  }, [project?.id]);

  const addCrew = async () => {
    if (!form.name.trim()) return;
    const pid = resolveProjectId(entryMode, project);
    const created = await base44.entities.CrewMember.create({ ...form, project_id: pid });
    setCrew([...crew, created]);
    logActivity(project?.id || '', 'crew', form.name, 'created', `${form.department} · ${form.position || 'TBD'} · ${form.union_status}`);
    setForm({ name: '', department: 'Camera', position: '', union_status: 'Non-Union', above_below_line: 'below_line', day_rate: 0, contact: '', availability_status: 'available', emergency_contact: '', notes: '' });
    setShowAdd(false);
  };

  const deleteCrew = async (id) => {
    const member = crew.find(c => c.id === id);
    await base44.entities.CrewMember.delete(id);
    setCrew(crew.filter(c => c.id !== id));
    if (member) logActivity(project?.id || '', 'crew', member.name, 'deleted');
    setDrawer({ open: false, entity: null });
  };

  const saveCrew = async (id, formData) => {
    await base44.entities.CrewMember.update(id, formData);
    setCrew(crew.map(c => c.id === id ? { ...c, ...formData } : c));
    const member = crew.find(c => c.id === id);
    logActivity(project?.id || '', 'crew', member?.name || '', 'updated');
  };

  const doExport = () => {
    exportCSV(crew.map(c => ({ name: c.name, department: c.department, position: c.position, union: c.union_status, day_rate: c.day_rate, contact: c.contact, notes: c.notes })), 'crew_list.csv');
  };

  const doImportCSV = async (file) => {
    const rows = await readCSVFile(file);
    const pid = resolveProjectId(entryMode, project);
    const records = rows.map((row) => {
      const obj = { project_id: pid };
      FIELDS.forEach((f) => {
        const val = coerceValue(row[f.key], f.type);
        if (val !== undefined) obj[f.key] = val;
      });
      return obj;
    }).filter((r) => r.name);
    if (records.length) await base44.entities.CrewMember.bulkCreate(records);
    setCrew(project ? await base44.entities.CrewMember.filter({ project_id: project.id }) : await base44.entities.CrewMember.list('-created_date', 500).then((all) => all.filter((i) => !i.project_id)));
    logActivity(project?.id || '', 'crew', `${records.length} members`, 'created', 'CSV import');
  };

  const grouped = DEPARTMENTS.map(d => ({ dept: d, members: crew.filter(c => c.department === d.key) })).filter(g => g.members.length > 0);

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#484f58]" size={18} /></div>;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2"><Users size={14} className="text-[#58a6ff]" /><span className="text-xs font-bold text-[#58a6ff]">Crew ({crew.length})</span></div>
        <div className="flex items-center gap-2 flex-wrap">
          <ImportExportBar onImportCSV={doImportCSV} onExportCSV={doExport} accent="#58a6ff" disabled={!crew.length} />
          <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1 px-2 py-1 bg-[#58a6ff] text-black rounded text-[9px] font-bold"><Plus size={10} /> Add Crew</button>
        </div>
      </div>

      {showAdd && (
        <div className="glass-panel clip-corner p-3 space-y-2 border-l-2 border-[#58a6ff]">
          <DualEntryToggle mode={entryMode} onChange={setEntryMode} projectName={project?.title} />
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Name *" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <select value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              {DEPT_OPTIONS.map(d => <option key={d}>{d}</option>)}
            </select>
            <input value={form.position} onChange={e => setForm({ ...form, position: e.target.value })} placeholder="Position (e.g. DP, Gaffer)" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <select value={form.union_status} onChange={e => setForm({ ...form, union_status: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              {UNION_STATUSES.map(s => <option key={s}>{s}</option>)}
            </select>
            <input type="number" value={form.day_rate} onChange={e => setForm({ ...form, day_rate: +e.target.value })} placeholder="Day rate $" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.contact} onChange={e => setForm({ ...form, contact: e.target.value })} placeholder="Contact" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          </div>
          <input value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Notes" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          <div className="flex gap-2">
            <button onClick={addCrew} className="px-3 py-1.5 bg-[#58a6ff] text-black rounded text-[10px] font-bold">Save</button>
            <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
          </div>
        </div>
      )}

      {!crew.length ? (
        <div className="text-center py-8 text-[10px] text-[#484f58] italic">No crew members yet. Click "Add Crew" or import a CSV.</div>
      ) : (
        <div className="space-y-4">
          {grouped.map(({ dept, members }) => (
            <div key={dept.key}>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full" style={{ background: dept.color }} />
                <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: dept.color }}>{dept.key}</span>
                <span className="text-[8px] text-[#484f58]">({members.length})</span>
              </div>
              <div className="space-y-1.5">
                {members.map(c => (
                  <div key={c.id} className="glass-panel clip-corner p-2.5 flex items-center gap-3 group cursor-pointer hover:border-[#58a6ff]/40 transition-colors" onClick={() => setDrawer({ open: true, entity: c })}>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold text-[#e6edf3]">{c.name}</span>
                        {c.position && <span className="text-[9px] text-[#8b949e]">— {c.position}</span>}
                        <span className="text-[7px] px-1 py-0.5 rounded border border-[#30363d] text-[#8b949e]">{c.union_status}</span>
                        {c.above_below_line === 'above_line' && <span className="text-[7px] px-1 py-0.5 rounded bg-[#fbbf24]/15 text-[#fbbf24]">ATL</span>}
                        {c.availability_status && c.availability_status !== 'available' && <span className="text-[7px] px-1 py-0.5 rounded" style={{ color: c.availability_status === 'booked' ? '#f85149' : c.availability_status === 'hold' ? '#d29922' : '#8b949e' }}>{c.availability_status}</span>}
                      </div>
                      <div className="text-[9px] text-[#8b949e] mt-0.5">
                        {c.day_rate > 0 && <span className="text-[#3fb950]">${c.day_rate.toLocaleString()}/day · </span>}
                        {c.contact && <span>{c.contact}</span>}
                        {c.notes && <span className="text-[#484f58]"> · {c.notes}</span>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <EntityDetailDrawer
        open={drawer.open}
        entity={drawer.entity}
        entityName="CrewMember"
        fields={FIELDS}
        accent="#58a6ff"
        onClose={() => setDrawer({ open: false, entity: null })}
        onSave={saveCrew}
        onDelete={deleteCrew}
        activityLog={activity.filter((a) => a.entity_name === drawer.entity?.name)}
        exportRows={(entity) => [{ name: entity.name, department: entity.department, position: entity.position, union_status: entity.union_status, day_rate: entity.day_rate, contact: entity.contact, notes: entity.notes }]}
        exportFilename={`crew_${drawer.entity?.name || 'member'}.csv`}
      />
    </div>
  );
}