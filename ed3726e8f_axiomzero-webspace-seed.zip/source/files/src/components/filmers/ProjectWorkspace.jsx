/**
 * ProjectWorkspace — Enhanced production suite workspace with grouped navigation.
 * Categories: Pre-Production, Departments, Cast & Crew, Production Management, Post, Resources, Books.
 * Includes Merlin Producer expert button.
 */
import { useState } from 'react';
import { ArrowLeft, LayoutDashboard, FileText, Camera, MapPin, DollarSign, ClipboardList, Sparkles, Download, Users, Package, BookOpen, Wrench, Brush, Mic, Palette, Lightbulb, ShieldAlert, Shirt, Sofa, BookMarked, ChevronDown, ChevronRight } from 'lucide-react';
import DashboardTab from './DashboardTab';
import ScriptTab from './ScriptTab';
import CinematographyTab from './CinematographyTab';
import LocationsTab from './LocationsTab';
import FinanceTab from './FinanceTab';
import ADSuiteTab from './ADSuiteTab';
import StoryboardTab from './StoryboardTab';
import ExportTab from './ExportTab';
import CastTab from './CastTab';
import CrewTab from './CrewTab';
import DepartmentInventoryGrid from './DepartmentInventoryGrid';
import ResourcesTab from './ResourcesTab';
import BooksTab from './BooksTab';
import MerlinProducerPanel from './MerlinProducerPanel';
import { DEPARTMENTS } from '@/lib/filmers/departments';

const STATUS_COLOR = { Development: '#8b949e', 'Pre-production': '#fbbf24', Production: '#3fb950', 'Post-production': '#60a5fa', Wrapped: '#a78bfa' };

const DEPT_ICONS = { Props: Package, 'Set Decoration': Sofa, Camera: Camera, Wardrobe: Shirt, 'Hair & Makeup': Brush, Sound: Mic, 'Art Department': Palette, 'Lighting/Electric': Lightbulb, Grip: Wrench, 'Stunts/Safety': ShieldAlert };

const NAV_GROUPS = [
  {
    label: 'Pre-Production',
    color: '#58a6ff',
    tabs: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, color: '#58a6ff' },
      { id: 'script', label: 'Script', icon: FileText, color: '#a78bfa' },
      { id: 'cinematography', label: 'Cinematography', icon: Camera, color: '#fbbf24' },
      { id: 'locations', label: 'Locations', icon: MapPin, color: '#34d399' },
    ],
  },
  {
    label: 'Departments',
    color: '#34d399',
    tabs: DEPARTMENTS.map(d => ({ id: d.key.toLowerCase().replace(/\s/g, '_'), label: d.key, icon: DEPT_ICONS[d.key] || Package, color: d.color, deptKey: d.key })),
  },
  {
    label: 'Cast & Crew',
    color: '#fbbf24',
    tabs: [
      { id: 'cast', label: 'Cast', icon: Users, color: '#fbbf24' },
      { id: 'crew', label: 'Crew', icon: Users, color: '#58a6ff' },
    ],
  },
  {
    label: 'Production',
    color: '#f472b6',
    tabs: [
      { id: 'finance', label: 'Finance', icon: DollarSign, color: '#60a5fa' },
      { id: 'ad_suite', label: 'AD Suite', icon: ClipboardList, color: '#f472b6' },
      { id: 'storyboard', label: 'Storyboard', icon: Sparkles, color: '#fbbf24' },
    ],
  },
  {
    label: 'Post & Resources',
    color: '#3fb950',
    tabs: [
      { id: 'export', label: 'Export', icon: Download, color: '#3fb950' },
      { id: 'resources', label: 'Resources', icon: BookOpen, color: '#a78bfa' },
    ],
  },
  {
    label: 'Books',
    color: '#a78bfa',
    tabs: [
      { id: 'books', label: 'Production Library', icon: BookMarked, color: '#a78bfa' },
    ],
  },
];

export default function ProjectWorkspace({ project, onBack, onUpdate }) {
  const [tab, setTab] = useState('dashboard');
  const [collapsed, setCollapsed] = useState({});
  const [merlinOpen, setMerlinOpen] = useState(false);

  const toggleGroup = (label) => setCollapsed(c => ({ ...c, [label]: !c[label] }));
  const isCollapsed = (label) => collapsed[label];

  const allTabs = NAV_GROUPS.flatMap(g => g.tabs);
  const activeTab = allTabs.find(t => t.id === tab);

  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-4">
        {/* Left rail */}
        <div className="glass-strong clip-corner p-3 h-fit lg:sticky lg:top-14 max-h-[85vh] overflow-y-auto">
          <button onClick={onBack} className="flex items-center gap-1.5 text-[10px] text-[#8b949e] hover:text-[#fbbf24] mb-3 transition-colors">
            <ArrowLeft size={11} /> Library
          </button>
          <h2 className="text-sm font-bold text-[#e6edf3] mb-1 leading-tight">{project.title}</h2>
          <span className="text-[8px] px-1.5 py-0.5 rounded font-bold inline-block mb-3" style={{ color: STATUS_COLOR[project.status], border: `1px solid ${STATUS_COLOR[project.status]}40` }}>{project.status}</span>
          <div className="space-y-1.5 text-[10px] text-[#8b949e] mb-3 border-t border-[#30363d] pt-3">
            <div><span className="text-[#484f58]">Budget:</span> <span className="text-[#3fb950]">{project.total_budget ? `$${Number(project.total_budget).toLocaleString()}` : '—'}</span></div>
            <div><span className="text-[#484f58]">Shoot days:</span> <span className="text-[#e6edf3]">{project.shoot_days || 0}</span></div>
          </div>

          {/* Merlin button */}
          <button onClick={() => setMerlinOpen(true)} className="w-full flex items-center gap-1.5 px-2.5 py-2 mb-3 rounded text-[10px] font-bold border border-[#fbbf24]/30 text-[#fbbf24] bg-[#fbbf24]/10 hover:bg-[#fbbf24]/20 transition-colors">
            <Sparkles size={12} /> Merlin Producer
          </button>

          {/* Grouped navigation */}
          <nav className="space-y-3">
            {NAV_GROUPS.map(group => (
              <div key={group.label}>
                <button onClick={() => toggleGroup(group.label)} className="flex items-center gap-1 w-full text-[9px] font-bold uppercase tracking-wider mb-1.5 hover:text-[#e6edf3] transition-colors" style={{ color: group.color }}>
                  {isCollapsed(group.label) ? <ChevronRight size={10} /> : <ChevronDown size={10} />}
                  {group.label}
                </button>
                {!isCollapsed(group.label) && (
                  <div className="space-y-1">
                    {group.tabs.map(t => (
                      <button key={t.id} onClick={() => setTab(t.id)} className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded text-[10px] font-bold border transition-all ${tab === t.id ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`} style={tab === t.id ? { background: t.color } : {}}>
                        <t.icon size={11} /> {t.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>
        </div>

        {/* Active tab */}
        <div className="min-w-0">
          {/* Mobile active tab indicator */}
          <div className="lg:hidden mb-2 text-[10px] text-[#8b949e]">
            <span className="font-bold" style={{ color: activeTab?.color }}>{activeTab?.label}</span>
          </div>
          {tab === 'dashboard' && <DashboardTab project={project} onNavigate={setTab} />}
          {tab === 'script' && <ScriptTab project={project} />}
          {tab === 'cinematography' && <CinematographyTab project={project} />}
          {tab === 'locations' && <LocationsTab project={project} />}
          {tab === 'finance' && <FinanceTab project={project} onUpdate={onUpdate} />}
          {tab === 'ad_suite' && <ADSuiteTab project={project} />}
          {tab === 'storyboard' && <StoryboardTab project={project} />}
          {tab === 'cast' && <CastTab project={project} />}
          {tab === 'crew' && <CrewTab project={project} />}
          {tab === 'export' && <ExportTab project={project} />}
          {tab === 'resources' && <ResourcesTab />}
          {tab === 'books' && <BooksTab />}
          {/* Department tabs */}
          {DEPARTMENTS.map(d => {
            const tabId = d.key.toLowerCase().replace(/\s/g, '_');
            return tab === tabId ? <DepartmentInventoryGrid key={d.key} project={project} deptKey={d.key} /> : null;
          })}
        </div>
      </div>
      <MerlinProducerPanel project={project} isOpen={merlinOpen} onClose={() => setMerlinOpen(false)} />
    </>
  );
}