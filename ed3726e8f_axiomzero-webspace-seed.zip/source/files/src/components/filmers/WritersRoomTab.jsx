/**
 * WritersRoomTab — Split-view "think space" for capturing story fragments
 * (characters, scenes, ideas, outlines) and assembling them into scripts.
 *
 * Left: freeform fragment board with drag-reorder + multi-select.
 * Right: live script assembly preview with spawn/link actions.
 * Works in both project mode and studio mode (project_id nullable).
 */
import { useState, useEffect, useCallback } from 'react';
import { Plus, Loader2, Sparkles, ArrowRight } from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { base44 } from '@/api/base44Client';
import { elementsToFountain } from '@/lib/filmers/fountainSerializer';
import { logActivity } from '@/lib/filmers/activityLog';
import { FRAGMENT_TYPES, fragmentsToElements } from './writers/fragmentToElements';
import FragmentCard from './writers/FragmentCard';
import AssemblyPreview from './writers/AssemblyPreview';

export default function WritersRoomTab({ project }) {
  const [fragments, setFragments] = useState([]);
  const [scripts, setScripts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [assemblyIds, setAssemblyIds] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ type: 'outline', title: '', content: '', tags: '', color: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const fragPromise = project
        ? base44.entities.StoryFragment.filter({ project_id: project.id }, 'sort_order', 500)
        : base44.entities.StoryFragment.list('-created_date', 500).then((all) => all.filter((f) => !f.project_id));
      const scriptPromise = project
        ? base44.entities.Script.filter({ project_id: project.id }, '-imported_date', 50)
        : Promise.resolve([]);
      const [f, s] = await Promise.all([fragPromise, scriptPromise]);
      setFragments(f);
      setScripts(s);
    } catch (e) { /* ignore */ }
    setLoading(false);
  }, [project?.id]);

  useEffect(() => { load(); }, [load]);

  const createFragment = async () => {
    if (!form.title.trim() && !form.content.trim()) return;
    const tags = form.tags.split(',').map((t) => t.trim()).filter(Boolean);
    const typeInfo = FRAGMENT_TYPES.find((t) => t.id === form.type);
    const created = await base44.entities.StoryFragment.create({
      project_id: project?.id || '',
      type: form.type,
      title: form.title.trim(),
      content: form.content.trim(),
      tags_json: JSON.stringify(tags),
      color: form.color || typeInfo.color,
      sort_order: fragments.length,
    });
    setFragments([...fragments, created]);
    logActivity(project?.id || '', 'fragment', form.title || form.type, 'created', `Writers Room`);
    setForm({ type: form.type, title: '', content: '', tags: '', color: '' });
    setShowAdd(false);
  };

  const deleteFragment = async (id) => {
    await base44.entities.StoryFragment.delete(id);
    setFragments(fragments.filter((f) => f.id !== id));
    setAssemblyIds(assemblyIds.filter((fid) => fid !== id));
    setSelectedIds((prev) => { const n = new Set(prev); n.delete(id); return n; });
  };

  const onDragEnd = async (result) => {
    if (!result.destination) return;
    const reordered = Array.from(fragments);
    const [moved] = reordered.splice(result.source.index, 1);
    reordered.splice(result.destination.index, 0, moved);
    setFragments(reordered);
    // Persist sort order
    const updates = reordered.map((f, i) => ({ id: f.id, sort_order: i }));
    await base44.entities.StoryFragment.bulkUpdate(updates);
  };

  const toggleSelect = (id) => {
    setSelectedIds((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };

  const addToAssembly = (id) => {
    if (!assemblyIds.includes(id)) setAssemblyIds([...assemblyIds, id]);
  };

  const addSelectedToAssembly = () => {
    const newIds = [...selectedIds].filter((id) => !assemblyIds.includes(id));
    setAssemblyIds([...assemblyIds, ...newIds]);
    setSelectedIds(new Set());
  };

  const removeFromAssembly = (idx) => {
    setAssemblyIds(assemblyIds.filter((_, i) => i !== idx));
  };

  const reorderAssembly = (idx, dir) => {
    const newIdx = idx + dir;
    if (newIdx < 0 || newIdx >= assemblyIds.length) return;
    const reordered = [...assemblyIds];
    [reordered[idx], reordered[newIdx]] = [reordered[newIdx], reordered[idx]];
    setAssemblyIds(reordered);
  };

  const assemblyFragments = assemblyIds.map((id) => fragments.find((f) => f.id === id)).filter(Boolean);

  const spawnScript = async () => {
    if (!assemblyFragments.length) return;
    setSaving(true);
    try {
      const elements = fragmentsToElements(assemblyFragments);
      const content = elementsToFountain(elements);
      const title = `Writers Room Draft ${scripts.length + 1}`;
      const script = await base44.entities.Script.create({
        project_id: project?.id || '',
        title,
        content,
        elements_json: JSON.stringify(elements),
        source_format: 'editor',
        revision_name: 'White Draft',
        revision_color: 'White',
        imported_date: new Date().toISOString(),
        last_edited: new Date().toISOString(),
      });
      // Mark fragments as linked
      await base44.entities.StoryFragment.bulkUpdate(
        assemblyFragments.map((f) => ({ id: f.id, linked_script_id: script.id }))
      );
      logActivity(project?.id || '', 'script', title, 'created from Writers Room');
      setScripts([script, ...scripts]);
      setAssemblyIds([]);
    } catch (e) { /* ignore */ }
    setSaving(false);
  };

  const linkToScript = async (scriptId) => {
    if (!assemblyFragments.length) return;
    setSaving(true);
    try {
      const script = scripts.find((s) => s.id === scriptId);
      if (!script) return;
      let existing = [];
      try { existing = script.elements_json ? JSON.parse(script.elements_json) : []; } catch { /* ignore */ }
      const newElements = fragmentsToElements(assemblyFragments);
      const merged = [...existing, ...newElements];
      const content = elementsToFountain(merged);
      await base44.entities.Script.update(scriptId, {
        elements_json: JSON.stringify(merged),
        content,
        last_edited: new Date().toISOString(),
      });
      await base44.entities.StoryFragment.bulkUpdate(
        assemblyFragments.map((f) => ({ id: f.id, linked_script_id: scriptId }))
      );
      logActivity(project?.id || '', 'script', script.title, 'merged from Writers Room');
      setAssemblyIds([]);
    } catch (e) { /* ignore */ }
    setSaving(false);
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#a78bfa]" size={20} /></div>;

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="glass-strong clip-corner p-3 flex items-center justify-between flex-wrap gap-2 border-l-2 border-[#a78bfa]">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-[#a78bfa]" />
          <div>
            <span className="text-xs font-bold text-[#a78bfa]">Writers Room</span>
            <span className="text-[9px] text-[#484f58] ml-2">{project ? `Linked to ${project.title}` : 'Studio Pool — standalone think space'}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {selectedIds.size > 0 && (
            <button onClick={addSelectedToAssembly} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[9px] font-bold bg-[#a78bfa] text-black hover:opacity-80">
              <ArrowRight size={10} /> Add {selectedIds.size} to Assembly
            </button>
          )}
          <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[9px] font-bold bg-[#a78bfa] text-black hover:opacity-80">
            <Plus size={10} /> New Fragment
          </button>
        </div>
      </div>

      {/* Add form */}
      {showAdd && (
        <div className="glass-panel clip-corner p-3 space-y-2 border-l-2 border-[#a78bfa]">
          <div className="flex items-center gap-1 flex-wrap">
            {FRAGMENT_TYPES.map((t) => (
              <button
                key={t.id}
                onClick={() => setForm({ ...form, type: t.id, color: t.color })}
                className={`px-2 py-1 rounded text-[9px] font-bold border transition-all ${form.type === t.id ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}
                style={form.type === t.id ? { background: t.color } : {}}
              >
                {t.label}
              </button>
            ))}
          </div>
          <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Title (character name, scene title, beat label)…" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          <textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} placeholder="Content (scene heading, dialogue, description, notes)…" rows={3} className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] resize-y" />
          <input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="Tags (comma-separated)…" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          <div className="flex gap-2">
            <button onClick={createFragment} className="px-3 py-1.5 bg-[#a78bfa] text-black rounded text-[10px] font-bold">Save Fragment</button>
            <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
          </div>
        </div>
      )}

      {/* Split view */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-3" style={{ minHeight: '60vh' }}>
        {/* Left: Fragment board */}
        <div className="lg:col-span-2 space-y-2">
          <div className="text-[9px] text-[#484f58] uppercase tracking-wider px-1">Fragment Board ({fragments.length})</div>
          {!fragments.length ? (
            <div className="glass-panel clip-corner p-6 text-center">
              <Sparkles size={20} className="text-[#484f58] mx-auto mb-2" />
              <p className="text-[10px] text-[#484f58]">No fragments yet. Capture a character, scene idea, or outline beat to start.</p>
            </div>
          ) : (
            <DragDropContext onDragEnd={onDragEnd}>
              <Droppable droppableId="board">
                {(provided) => (
                  <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-1.5">
                    {fragments.map((f, idx) => (
                      <Draggable key={f.id} draggableId={f.id} index={idx}>
                        {(p, s) => (
                          <div ref={p.innerRef} {...p.draggableProps} {...p.dragHandleProps}>
                            <FragmentCard
                              fragment={f}
                              selected={selectedIds.has(f.id)}
                              onSelect={toggleSelect}
                              onAddToAssembly={addToAssembly}
                              onDelete={deleteFragment}
                              isDragging={s.isDragging}
                            />
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          )}
        </div>

        {/* Right: Assembly preview */}
        <div className="lg:col-span-3" style={{ minHeight: '50vh' }}>
          <AssemblyPreview
            assemblyFragments={assemblyFragments}
            scripts={scripts}
            onRemove={removeFromAssembly}
            onReorder={reorderAssembly}
            onSpawn={spawnScript}
            onLink={linkToScript}
            saving={saving}
          />
        </div>
      </div>
    </div>
  );
}