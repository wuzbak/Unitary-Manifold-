/**
 * SuiteShell — Persistent production suite shell with full tab exposure.
 * Responsive: desktop horizontal tabs + sub-tabs, mobile bottom-tab nav.
 * Merlin co-pilot: alert badge + action menu + producer panel.
 * Dual-entry: all data tabs support studio (standalone) or project-scoped.
 */
import { useState, useEffect } from 'react';
import { LayoutDashboard, FileText, Camera, MapPin, Users, DollarSign, ClipboardList, Sparkles, Download, BookOpen, Package, Film, ChevronRight, Wrench, Brush, Mic, Palette, Lightbulb, ShieldAlert, Shirt, Sofa, Building2, Calendar, Clock, Award, User, Boxes, PenLine, Database } from 'lucide-react';
import { DEPARTMENTS } from '@/lib/filmers/departments';
import SuiteProjectSelector from './SuiteProjectSelector';
import DashboardTab from './DashboardTab';
import ScriptTab from './ScriptTabV2';
import CinematographyTab from './CinematographyTab';
import LocationsTab from './LocationsTab';
import DepartmentTabWrapper from './DepartmentTabWrapper';
import CastTab from './CastTab';
import CrewTab from './CrewTab';
import FinanceTab from './FinanceTab';
import ADSuiteTab from './ADSuiteTab';
import StoryboardTab from './StoryboardTab';
import ExportTab from './ExportTab';
import LibraryTab from './LibraryTab';
import StudioDashboardTab from './StudioDashboardTab';
import StudioPoolTab from './StudioPoolTab';
import StudioLibrary from './StudioLibrary';
import ProjectLibrary from './ProjectLibrary';
import MerlinSuitePanel from './MerlinSuitePanel';
import WritersRoomTab from './WritersRoomTab';
import MobileSuiteNav from './MobileSuiteNav';
import UPOverviewTab from './UPOverviewTab';
import StripboardTab from './StripboardTab';
import CallSheetBuilder from './CallSheetBuilder';
import TimeCardTab from './TimeCardTab';
import ActorPortalPanel from './ActorPortalPanel';
import FilmCreditTab from './FilmCreditTab';
import LocalResourceTab from './LocalResourceTab';
import FilmersAnalyticsTab from './FilmersAnalyticsTab';
import InventoryOverviewTab from './InventoryOverviewTab';

const DEPT_ICONS = { Props: Package, 'Set Decoration': Sofa, Camera: Camera, Wardrobe: Shirt, 'Hair & Makeup': Brush, Sound: Mic, 'Art Department': Palette, 'Lighting/Electric': Lightbulb, Grip: Wrench, 'Stunts/Safety': ShieldAlert };

const MAIN_TABS = [
  { id: 'studio_dashboard', label: 'Studio', icon: Building2, color: '#4dd0e1' },
  { id: 'studio_library', label: 'Library', icon: BookOpen, color: '#4dd0e1' },
  { id: 'studio_pool', label: 'Studio Pool', icon: Package, color: '#4dd0e1' },
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, color: '#58a6ff' },
  {
    id: 'preprod', label: 'Pre-Production', icon: FileText, color: '#a78bfa',
    subTabs: [
      { id: 'script', label: 'Script', icon: FileText, color: '#a78bfa' },
      { id: 'script_dashboard', label: 'Breakdown', icon: LayoutDashboard, color: '#4dd0e1' },
      { id: 'cinematography', label: 'Cinematography', icon: Camera, color: '#fbbf24' },
      { id: 'locations', label: 'Locations', icon: MapPin, color: '#34d399' },
      { id: 'scheduling', label: 'Scheduling', icon: Calendar, color: '#f472b6' },
      { id: 'call_sheets', label: 'Call Sheets', icon: ClipboardList, color: '#f472b6' },
    ],
  },
  { id: 'writers_room', label: 'Writers Room', icon: PenLine, color: '#a78bfa' },
  {
    id: 'departments', label: 'Departments', icon: Package, color: '#34d399',
    subTabs: [
      { id: 'inventory_overview', label: 'Overview', icon: Boxes, color: '#4dd0e1' },
      ...DEPARTMENTS.map(d => ({ id: d.key.toLowerCase().replace(/\s/g, '_'), label: d.key, icon: DEPT_ICONS[d.key] || Package, color: d.color, deptKey: d.key })),
    ],
  },
  {
    id: 'castcrew', label: 'Cast & Crew', icon: Users, color: '#fbbf24',
    subTabs: [
      { id: 'cast', label: 'Cast', icon: Users, color: '#fbbf24' },
      { id: 'crew', label: 'Crew', icon: Users, color: '#58a6ff' },
      { id: 'actor_portal', label: 'Actor Portal', icon: User, color: '#fbbf24' },
      { id: 'time_cards', label: 'Time Cards', icon: Clock, color: '#f472b6' },
    ],
  },
  {
    id: 'production', label: 'Production', icon: ClipboardList, color: '#f472b6',
    subTabs: [
      { id: 'finance', label: 'Finance', icon: DollarSign, color: '#60a5fa' },
      { id: 'ad_suite', label: 'AD Suite', icon: ClipboardList, color: '#f472b6' },
      { id: 'upm_overview', label: 'UPM Overview', icon: ClipboardList, color: '#4dd0e1' },
      { id: 'storyboard', label: 'Storyboard', icon: Sparkles, color: '#fbbf24' },
      { id: 'film_credits', label: 'Film Credits', icon: Award, color: '#fbbf24' },
      { id: 'local_resources', label: 'Local Resources', icon: Building2, color: '#4dd0e1' },
      { id: 'analytics', label: 'Analytics', icon: Database, color: '#4dd0e1' },
      { id: 'export', label: 'Export', icon: Download, color: '#3fb950' },
    ],
  },
  { id: 'projects', label: 'Projects', icon: Film, color: '#fbbf24' },
];

// Map leaf tab id → main tab id
const LEAF_TO_MAIN = {};
MAIN_TABS.forEach(mt => {
  if (mt.subTabs) mt.subTabs.forEach(st => { LEAF_TO_MAIN[st.id] = mt.id; });
  else LEAF_TO_MAIN[mt.id] = mt.id;
});
// script_dashboard lives under preprod
LEAF_TO_MAIN['script_dashboard'] = 'preprod';
LEAF_TO_MAIN['studio_library'] = 'studio_library';
LEAF_TO_MAIN['writers_room'] = 'writers_room';

const PROJECT_REQUIRED_TABS = ['dashboard', 'script', 'script_dashboard', 'cinematography', 'scheduling', 'call_sheets', 'finance', 'ad_suite', 'upm_overview', 'storyboard', 'film_credits', 'local_resources', 'export', 'actor_portal', 'time_cards'];

function NoProjectPrompt({ onNavigate }) {
  return (
    <div className="glass-panel clip-corner p-8 text-center">
      <Film size={28} className="text-[#484f58] mx-auto mb-3" />
      <p className="text-xs text-[#8b949e] mb-4">Select or create a project to start tracking data in this section.</p>
      <button onClick={() => onNavigate('projects')} className="px-4 py-2 bg-[#fbbf24] text-black rounded text-xs font-bold hover:opacity-80 transition-opacity">
        Go to Projects →
      </button>
    </div>
  );
}

export default function SuiteShell({ project, projects, onSelectProject, onUpdateProject }) {
  const [tab, setTab] = useState('dashboard');
  const [merlinOpen, setMerlinOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 1024);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  const mainTabId = LEAF_TO_MAIN[tab] || 'dashboard';
  const mainTab = MAIN_TABS.find(t => t.id === mainTabId);
  const subTabs = mainTab?.subTabs;
  const activeSubTab = subTabs?.find(t => t.id === tab);

  const handleSelectProject = (p) => {
    onSelectProject(p);
    setTab('dashboard');
  };

  const needsProject = !project && PROJECT_REQUIRED_TABS.includes(tab);
  const handleCreateNew = () => setTab('projects');

  return (
    <>
      {/* Suite header with project selector + alerts */}
      <div className="glass-strong clip-corner p-3 mb-3 flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 min-w-0">
          <Film size={16} className="text-[#fbbf24] shrink-0" />
          <div className="min-w-0">
            <span className="text-xs font-bold text-[#e6edf3]">Production Suite</span>
            {!project ? (
              <span className="text-[9px] text-[#4dd0e1] ml-2">· Studio Pool Mode</span>
            ) : (
              <span className="text-[9px] text-[#484f58] ml-2 hidden lg:inline">· {project.synopsis || 'No synopsis'}</span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setMerlinOpen(!merlinOpen)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded text-[10px] font-bold border transition-colors min-h-[40px] ${merlinOpen ? 'bg-[#fbbf24] text-black border-transparent' : 'border-[#fbbf24]/30 text-[#fbbf24] bg-[#fbbf24]/10 hover:bg-[#fbbf24]/20'}`}
          >
            <Sparkles size={12} /> <span className="hidden sm:inline">Merlin</span>
          </button>
          <SuiteProjectSelector
            projects={projects}
            selectedProject={project}
            onSelect={handleSelectProject}
            onCreateNew={handleCreateNew}
          />
        </div>
      </div>

      {/* Desktop: Main horizontal tab bar */}
      <div className="hidden lg:block">
        <div className="glass-panel clip-corner p-1.5 mb-3 overflow-x-auto">
          <div className="flex items-center gap-1 min-w-max">
            {MAIN_TABS.map(mt => (
              <button
                key={mt.id}
                onClick={() => { if (mt.subTabs) setTab(mt.subTabs[0].id); else setTab(mt.id); }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded text-[10px] font-bold border transition-all whitespace-nowrap ${mainTabId === mt.id ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}
                style={mainTabId === mt.id ? { background: mt.color } : {}}
              >
                <mt.icon size={11} /> {mt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Sub-tab bar */}
        {subTabs && (
          <div className="glass-panel clip-corner p-1.5 mb-3 overflow-x-auto">
            <div className="flex items-center gap-1 min-w-max">
              {subTabs.map(st => (
                <button
                  key={st.id}
                  onClick={() => setTab(st.id)}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-[9px] font-bold border transition-all whitespace-nowrap ${tab === st.id ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}
                  style={tab === st.id ? { background: st.color } : {}}
                >
                  <st.icon size={10} /> {st.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Active tab content */}
      <div className={`min-w-0 pb-20 lg:pb-0 transition-all duration-300 ${merlinOpen ? 'lg:mr-[390px]' : ''}`}>
        {needsProject ? (
          <NoProjectPrompt onNavigate={setTab} />
        ) : (
          <>
            {tab === 'studio_dashboard' && <StudioDashboardTab projects={projects} onSelectProject={handleSelectProject} />}
            {tab === 'studio_library' && <StudioLibrary project={project} />}
            {tab === 'studio_pool' && <StudioPoolTab projects={projects} onSelectProject={handleSelectProject} />}
            {tab === 'dashboard' && <DashboardTab project={project} onNavigate={setTab} />}
            {tab === 'script' && <ScriptTab project={project} />}
            {tab === 'script_dashboard' && <ScriptTab project={project} embeddedDashboard />}
            {tab === 'cinematography' && <CinematographyTab project={project} />}
            {tab === 'locations' && <LocationsTab project={project} />}
            {tab === 'scheduling' && <StripboardTab project={project} />}
            {tab === 'call_sheets' && <CallSheetBuilder project={project} />}
            {tab === 'cast' && <CastTab project={project} />}
            {tab === 'crew' && <CrewTab project={project} />}
            {tab === 'actor_portal' && <ActorPortalPanel project={project} />}
            {tab === 'time_cards' && <TimeCardTab project={project} />}
            {tab === 'finance' && <FinanceTab project={project} onUpdate={onUpdateProject} />}
            {tab === 'ad_suite' && <ADSuiteTab project={project} />}
            {tab === 'upm_overview' && <UPOverviewTab project={project} />}
            {tab === 'storyboard' && <StoryboardTab project={project} />}
            {tab === 'film_credits' && <FilmCreditTab project={project} />}
            {tab === 'local_resources' && <LocalResourceTab project={project} />}
            {tab === 'inventory_overview' && <InventoryOverviewTab project={project} />}
            {tab === 'writers_room' && <WritersRoomTab project={project} />}
            {tab === 'export' && <ExportTab project={project} />}
            {tab === 'analytics' && <FilmersAnalyticsTab project={project} />}
            {tab === 'library' && <LibraryTab />}
            {tab === 'projects' && (<ProjectLibrary onOpen={handleSelectProject} embedded />)}
            {/* Department tabs */}
            {DEPARTMENTS.map(d => {
              const tabId = d.key.toLowerCase().replace(/\s/g, '_');
              return tab === tabId ? <DepartmentTabWrapper key={d.key} project={project} deptKey={d.key} /> : null;
            })}
          </>
        )}
      </div>

      {/* Mobile bottom-tab navigation */}
      <MobileSuiteNav activeTab={tab} onSelectTab={setTab} />

      {/* Unified Merlin panel — persistent, context-aware */}
      <MerlinSuitePanel isOpen={merlinOpen} onClose={() => setMerlinOpen(false)} tab={tab} project={project} onNavigate={setTab} projects={projects} />
    </>
  );
}