/**
 * TabEntryHeader — Standardized entry-point header for every Filmer's Companion tab.
 * Shows: tab title, live metrics (entity counts, status badges), and action toolbar
 * (import/export buttons + dual-entry toggle).
 *
 * Each tab feels like a self-contained workspace with its own header, metrics row,
 * and action toolbar — not just a content panel inside a shell.
 */
import ImportExportBar from './ImportExportBar';
import DualEntryToggle from './DualEntryToggle';

export default function TabEntryHeader({
  title,
  subtitle,
  icon: Icon,
  accent = '#fbbf24',
  metrics = [],
  onImportCSV,
  onExportCSV,
  onExportJSON,
  onImportJSON,
  importLabel = 'Import CSV',
  exportLabel = 'Export CSV',
  ioDisabled = false,
  exportDisabled = false,
  dualEntry,
  onDualEntryChange,
  projectName,
  children,
}) {
  return (
    <div className="glass-strong clip-corner p-3 mb-3 fade-in">
      {/* Title row */}
      <div className="flex items-start justify-between gap-3 flex-wrap mb-2">
        <div className="flex items-center gap-2 min-w-0">
          {Icon && (
            <div className="flex items-center justify-center w-8 h-8 shrink-0 clip-corner" style={{ background: `${accent}15`, border: `1px solid ${accent}30` }}>
              <Icon size={14} style={{ color: accent }} />
            </div>
          )}
          <div className="min-w-0">
            <h2 className="text-sm font-bold text-[#e6edf3] tracking-tight">{title}</h2>
            {subtitle && <p className="text-[10px] text-[#8b949e] leading-relaxed mt-0.5">{subtitle}</p>}
          </div>
        </div>

        {/* Action toolbar */}
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          {dualEntry && onDualEntryChange && (
            <DualEntryToggle mode={dualEntry} onChange={onDualEntryChange} projectName={projectName} />
          )}
          {(onImportCSV || onExportCSV || onExportJSON || onImportJSON) && (
            <ImportExportBar
              onImportCSV={onImportCSV}
              onExportCSV={onExportCSV}
              onExportJSON={onExportJSON}
              onImportJSON={onImportJSON}
              accent={accent}
              disabled={ioDisabled}
              exportDisabled={exportDisabled}
              importLabel={importLabel}
              exportLabel={exportLabel}
            />
          )}
          {children}
        </div>
      </div>

      {/* Metrics row */}
      {metrics.length > 0 && (
        <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-[#30363d]">
          {metrics.map((m, i) => (
            <div key={i} className="flex items-center gap-1.5 px-2 py-1 bg-[#0B0F13] border border-[#30363d] rounded">
              {m.icon && <m.icon size={9} style={{ color: m.color || accent }} />}
              <span className="text-[9px] font-bold text-[#e6edf3]">{m.value}</span>
              <span className="text-[8px] text-[#484f58]">{m.label}</span>
              {m.badge && (
                <span className="text-[7px] px-1 rounded font-bold" style={{ background: m.badgeColor || accent, color: '#000' }}>
                  {m.badge}
                </span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}