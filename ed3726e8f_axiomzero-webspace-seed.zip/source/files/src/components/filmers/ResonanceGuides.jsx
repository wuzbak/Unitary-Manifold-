/**
 * ResonanceGuides — Merlin's Resonance Guides section for the Filmer's Companion Library.
 *
 * Four sub-tabs (Music, Film, Television, Animation) sourced from the pillar
 * media data. Arc-grouped collapsible sections (Part I–IX) collapsed by default,
 * Founding-Fathers exhibit style. Search/filter per tab.
 */
import { useState, useMemo } from 'react';
import { Music, Film, Tv, Clapperboard, ChevronRight, Search, Sparkles } from 'lucide-react';
import {
  PILLAR_ARCS,
  CINEMA_ENTRIES, MUSIC_ENTRIES,
  CINEMA_EXACT_MATCHES, MUSIC_EXACT_MATCHES,
} from '@/lib/merlinExperts/pillarMediaData';
import { getCategoryCounts } from '@/lib/merlinExperts/pillarMediaGraph';

// Filter cinema exact matches by the category of the matching pillar entry
const cinemaExactFor = (cat) => CINEMA_EXACT_MATCHES.filter((m) => {
  const e = CINEMA_ENTRIES.find((c) => c.pillar === m.pillar);
  return e && e.category === cat;
});

const TABS = [
  { id: 'music',      label: 'Music',      icon: Music,        accent: '#a78bfa', entries: MUSIC_ENTRIES,                                exact: MUSIC_EXACT_MATCHES },
  { id: 'film',       label: 'Film',       icon: Film,         accent: '#fbbf24', entries: CINEMA_ENTRIES.filter((e) => e.category === 'film'),       exact: cinemaExactFor('film') },
  { id: 'television', label: 'Television', icon: Tv,           accent: '#4dd0e1', entries: CINEMA_ENTRIES.filter((e) => e.category === 'television'), exact: cinemaExactFor('television') },
  { id: 'animation',  label: 'Animation',  icon: Clapperboard, accent: '#3fb950', entries: CINEMA_ENTRIES.filter((e) => e.category === 'animation'),  exact: cinemaExactFor('animation') },
];

export default function ResonanceGuides() {
  const [activeTab, setActiveTab] = useState('music');
  const [expandedArcs, setExpandedArcs] = useState(new Set());
  const [search, setSearch] = useState('');

  const tab = TABS.find((t) => t.id === activeTab);
  const counts = getCategoryCounts();

  // Filter entries by search within the active tab
  const filteredEntries = useMemo(() => {
    if (!search.trim()) return tab.entries;
    const q = search.toLowerCase();
    return tab.entries.filter((e) =>
      e.pillar.toLowerCase().includes(q) ||
      e.description.toLowerCase().includes(q) ||
      e.bestMatch.toLowerCase().includes(q) ||
      e.work.includes(q) ||
      e.specificMoment.toLowerCase().includes(q)
    );
  }, [tab, search]);

  // Group filtered entries by arc
  const grouped = useMemo(() => {
    const g = {};
    for (const arc of PILLAR_ARCS) g[arc.id] = [];
    for (const e of filteredEntries) {
      if (g[e.part]) g[e.part].push(e);
    }
    return g;
  }, [filteredEntries]);

  const toggleArc = (arcId) => {
    setExpandedArcs((prev) => {
      const next = new Set(prev);
      if (next.has(arcId)) next.delete(arcId);
      else next.add(arcId);
      return next;
    });
  };

  // When switching tabs, collapse all arcs and clear search
  const switchTab = (id) => {
    setActiveTab(id);
    setExpandedArcs(new Set());
    setSearch('');
  };

  return (
    <div className="glass-strong clip-corner p-4 border-l-2 border-[#00f5ff]/40">
      {/* Section header */}
      <div className="flex items-center gap-2 mb-3">
        <Sparkles size={14} className="text-[#00f5ff]" />
        <span className="text-xs font-bold text-[#00f5ff]">Merlin's Resonance Guides — Pillar Media Library</span>
        <span className="text-[8px] text-[#484f58] ml-auto">{counts.total} entries · 4 media</span>
      </div>
      <p className="text-[9px] text-[#8b949e] leading-relaxed mb-3">
        Every pillar in the Unitary Manifold mapped to one structurally exact work of cinema, television, animation, or music.
        These are Merlin's preferred works — part of his training and memory. One match per pillar; the most structurally exact, not the most famous.
      </p>

      {/* Sub-tabs */}
      <div className="flex gap-1.5 flex-wrap mb-3">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => switchTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold border clip-corner transition-all touch-manipulation ${
              activeTab === t.id ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'
            }`}
            style={activeTab === t.id ? { background: t.accent } : {}}
          >
            <t.icon size={11} /> {t.label}
            <span className={`text-[8px] ${activeTab === t.id ? 'text-black/60' : 'text-[#484f58]'}`}>({t.entries.length})</span>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative flex items-center gap-1.5 glass-panel clip-corner px-2 py-1.5 mb-3">
        <Search size={11} className="text-[#484f58] shrink-0" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={`Search ${tab.label.toLowerCase()} by pillar, title, or moment…`}
          className="bg-transparent text-[10px] text-[#e6edf3] flex-1 min-w-0 focus:outline-none placeholder:text-[#484f58]"
        />
        {search && (
          <button onClick={() => setSearch('')} className="text-[#484f58] hover:text-[#00f5ff] shrink-0 text-xs">✕</button>
        )}
      </div>

      {/* Exact matches callout (film + music tabs only) */}
      {tab.exact.length > 0 && !search && (
        <div className="glass-panel clip-corner p-2.5 mb-3 border-l-2" style={{ borderColor: `${tab.accent}60` }}>
          <p className="text-[8px] font-bold uppercase mb-1.5" style={{ color: tab.accent }}>Most Structurally Exact Matches</p>
          <div className="space-y-0.5">
            {tab.exact.slice(0, 6).map((m, i) => (
              <div key={i} className="text-[9px] text-[#8b949e] flex gap-1.5">
                <span className="font-bold text-[#e6edf3] shrink-0">P{m.pillar}</span>
                <span className="text-[#c9d1d9]">{m.match}</span>
                <span className="text-[#484f58] italic hidden sm:block">— {m.reason}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Arc-grouped collapsible sections */}
      <div className="space-y-1.5">
        {PILLAR_ARCS.map((arc, idx) => {
          const entries = grouped[arc.id] || [];
          if (entries.length === 0) return null;
          const isExpanded = expandedArcs.has(arc.id);
          return (
            <div key={arc.id} className="border border-[#30363d] clip-corner overflow-hidden">
              {/* Arc header — clickable */}
              <button
                onClick={() => toggleArc(arc.id)}
                className="w-full flex items-center gap-2 px-3 py-2 bg-[#0d1117] hover:bg-[#161b22] transition-colors touch-manipulation"
              >
                <span className="text-[9px] font-mono px-1.5 py-0.5 border border-[#00f5ff]/20 text-[#00f5ff]/70 bg-[#00f5ff]/5 clip-corner shrink-0">
                  {String(idx + 1).padStart(2, '0')}
                </span>
                <span className="text-[10px] font-bold text-[#e6edf3] text-left flex-1 min-w-0">
                  Part {arc.id} — {arc.label}
                </span>
                <span className="text-[8px] text-[#484f58] shrink-0">{arc.range}</span>
                <span className="text-[8px] px-1.5 py-0.5 bg-[#30363d] text-[#8b949e] clip-corner shrink-0">{entries.length}</span>
                <ChevronRight
                  size={12}
                  className={`text-[#484f58] shrink-0 transition-transform ${isExpanded ? 'rotate-90' : ''}`}
                />
              </button>

              {/* Expanded entries */}
              {isExpanded && (
                <div className="p-2 space-y-1.5 fade-in">
                  {entries.map((e, i) => (
                    <PillarEntryCard key={`${e.pillar}-${e.category}-${i}`} entry={e} accent={tab.accent} />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {filteredEntries.length === 0 && (
        <div className="text-center py-6 text-[10px] text-[#484f58]">
          No entries match "{search}" in {tab.label}.
        </div>
      )}
    </div>
  );
}

function PillarEntryCard({ entry, accent }) {
  return (
    <div className="bg-[#0d1117] border border-[#30363d] clip-corner p-2.5 hover:border-[#30363d]/80 transition-colors">
      <div className="flex items-start gap-2 mb-1">
        <span
          className="text-[9px] font-mono font-bold px-1.5 py-0.5 clip-corner shrink-0"
          style={{ background: `${accent}20`, color: accent, border: `1px solid ${accent}40` }}
        >
          P{entry.pillar}
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[10px] font-bold text-[#e6edf3] leading-snug">{entry.bestMatch}</p>
          <p className="text-[8px] text-[#484f58] leading-snug">{entry.description}</p>
        </div>
      </div>
      <p className="text-[9px] text-[#c9d1d9] leading-relaxed mb-1 pl-1 border-l border-[#30363d]">
        <span className="text-[#8b949e] font-bold">Moment:</span> {entry.specificMoment}
      </p>
      <p className="text-[9px] text-[#8b949e] leading-relaxed italic">
        {entry.whyItFits}
      </p>
    </div>
  );
}