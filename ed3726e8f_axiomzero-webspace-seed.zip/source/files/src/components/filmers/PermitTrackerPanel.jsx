/**
 * PermitTrackerPanel — Location permit tracking with status pipeline,
 * issuing authority, cost, expiry, and insurance requirements.
 */
import { useState, useEffect, useCallback } from 'react';
import { Shield, Plus, Trash2, Loader2, Download, AlertTriangle, FileText } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { exportCSV } from '@/lib/filmers/filmExport';
import { logActivity } from '@/lib/filmers/activityLog';

const PERMIT_TYPES = ['film', 'photography', 'drone', 'street_closure', 'park', 'beach', 'federal_land', 'state_land', 'other'];
const PERMIT_STATUSES = ['applied', 'pending', 'approved', 'denied', 'expired'];
const STATUS_COLORS = { applied: '#58a6ff', pending: '#d29922', approved: '#3fb950', denied: '#f85149', expired: '#8b949e' };

export default function PermitTrackerPanel({ project }) {
  const [permits, setPermits] = useState([]);
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ location_id: '', permit_type: 'film', status: 'applied', permit_number: '', issuing_authority: '', cost: 0, issue_date: '', expiry_date: '', insurance_required: true, contact_name: '', contact_phone: '', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [p, l] = await Promise.all([
        base44.entities.Permit.filter({ project_id: project.id }),
        base44.entities.Location.filter({ project_id: project.id }),
      ]);
      setPermits(p); setLocations(l);
    } catch { /* best-effort */ }
    finally { setLoading(false); }
  }, [project.id]);

  useEffect(() => { load(); }, [load]);

  const addPermit = async () => {
    const loc = locations.find(l => l.id === form.location_id);
    const permit = await base44.entities.Permit.create({
      ...form,
      project_id: project.id,
      location_name: loc?.name || '',
      cost: Number(form.cost) || 0,
    });
    setPermits([permit, ...permits]);
    logActivity(project.id, 'permit', loc?.name || 'Permit', 'created', form.status);
    setForm({ location_id: '', permit_type: 'film', status: 'applied', permit_number: '', issuing_authority: '', cost: 0, issue_date: '', expiry_date: '', insurance_required: true, contact_name: '', contact_phone: '', notes: '' });
    setShowAdd(false);
  };

  const updateStatus = async (id, status) => {
    await base44.entities.Permit.update(id, { status });
    setPermits(permits.map(p => p.id === id ? { ...p, status } : p));
    const permit = permits.find(p => p.id === id);
    if (permit) logActivity(project.id, 'permit', permit.location_name || 'Permit', 'status_changed', status);
  };

  const deletePermit = async (id) => {
    await base44.entities.Permit.delete(id);
    setPermits(permits.filter(p => p.id !== id));
  };

  const exportPermits = () => {
    exportCSV(permits.map(p => ({
      location: p.location_name, type: p.permit_type, status: p.status,
      permit_number: p.permit_number, authority: p.issuing_authority,
      cost: p.cost, issue_date: p.issue_date, expiry_date: p.expiry_date,
      insurance: p.insurance_required ? 'yes' : 'no', contact: p.contact_name, phone: p.contact_phone,
    })), 'permits.csv');
  };

  const today = new Date().toISOString().split('T')[0];
  const expiringSoon = permits.filter(p => p.expiry_date && p.expiry_date <= today && p.status === 'approved');
  const totalCost = permits.reduce((s, p) => s + (p.cost || 0), 0);

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#34d399]" size={18} /></div>;

  return (
    <div className="space-y-3">
      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="glass-panel clip-corner p-2.5">
          <div className="text-[8px] text-[#484f58] uppercase">Total Permits</div>
          <div className="text-lg font-bold text-[#e6edf3]">{permits.length}</div>
        </div>
        <div className="glass-panel clip-corner p-2.5">
          <div className="text-[8px] text-[#484f58] uppercase">Approved</div>
          <div className="text-lg font-bold text-[#3fb950]">{permits.filter(p => p.status === 'approved').length}</div>
        </div>
        <div className="glass-panel clip-corner p-2.5">
          <div className="text-[8px] text-[#484f58] uppercase">Pending</div>
          <div className="text-lg font-bold text-[#d29922]">{permits.filter(p => p.status === 'applied' || p.status === 'pending').length}</div>
        </div>
        <div className="glass-panel clip-corner p-2.5">
          <div className="text-[8px] text-[#484f58] uppercase">Total Cost</div>
          <div className="text-lg font-bold text-[#e6edf3]">${totalCost.toLocaleString()}</div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Shield size={14} className="text-[#34d399]" />
          <span className="text-xs font-bold text-[#34d399]">Permits</span>
        </div>
        <div className="flex items-center gap-1.5">
          <button onClick={exportPermits} disabled={!permits.length} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] disabled:opacity-40">
            <Download size={10} /> CSV
          </button>
          <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#34d399] text-black">
            <Plus size={10} /> Add Permit
          </button>
        </div>
      </div>

      {/* Expiry alert */}
      {expiringSoon.length > 0 && (
        <div className="glass-panel clip-corner p-2.5 border-l-2 border-[#fbbf24] flex items-center gap-2">
          <AlertTriangle size={12} className="text-[#fbbf24]" />
          <span className="text-[10px] text-[#fbbf24]">{expiringSoon.length} permit(s) expired or expiring soon — review and renew.</span>
        </div>
      )}

      {/* Add form */}
      {showAdd && (
        <div className="glass-panel clip-corner p-3 border-l-2 border-[#34d399] space-y-2">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            <select value={form.location_id} onChange={e => setForm({ ...form, location_id: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              <option value="">Select location...</option>
              {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
            </select>
            <select value={form.permit_type} onChange={e => setForm({ ...form, permit_type: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              {PERMIT_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
            <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              {PERMIT_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <input value={form.permit_number} onChange={e => setForm({ ...form, permit_number: e.target.value })} placeholder="Permit #" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.issuing_authority} onChange={e => setForm({ ...form, issuing_authority: e.target.value })} placeholder="Issuing authority" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="number" value={form.cost} onChange={e => setForm({ ...form, cost: +e.target.value })} placeholder="Cost $" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="date" value={form.issue_date} onChange={e => setForm({ ...form, issue_date: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="date" value={form.expiry_date} onChange={e => setForm({ ...form, expiry_date: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <label className="flex items-center gap-1.5 text-[10px] text-[#8b949e]">
              <input type="checkbox" checked={form.insurance_required} onChange={e => setForm({ ...form, insurance_required: e.target.checked })} className="accent-[#34d399]" /> Insurance required
            </label>
            <input value={form.contact_name} onChange={e => setForm({ ...form, contact_name: e.target.value })} placeholder="Contact name" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.contact_phone} onChange={e => setForm({ ...form, contact_phone: e.target.value })} placeholder="Contact phone" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          </div>
          <input value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Notes" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          <div className="flex gap-2">
            <button onClick={addPermit} className="px-3 py-1.5 bg-[#34d399] text-black rounded text-[10px] font-bold">Save Permit</button>
            <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
          </div>
        </div>
      )}

      {/* Permit list */}
      {permits.length === 0 ? (
        <div className="glass-panel clip-corner p-8 text-center">
          <Shield size={28} className="text-[#484f58] mx-auto mb-3" />
          <p className="text-xs text-[#8b949e]">No permits tracked yet. Add locations first, then create permits for each.</p>
        </div>
      ) : (
        <div className="space-y-1.5">
          {permits.map(p => (
            <div key={p.id} className="glass-panel clip-corner p-2.5 flex items-center gap-3">
              <FileText size={14} style={{ color: STATUS_COLORS[p.status] }} className="shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold text-[#e6edf3]">{p.location_name || 'Unknown location'}</span>
                  <span className="text-[8px] px-1.5 py-0.5 rounded border border-[#30363d] text-[#8b949e]">{p.permit_type}</span>
                  {p.permit_number && <span className="text-[8px] text-[#58a6ff]">#{p.permit_number}</span>}
                  {p.insurance_required && <span className="text-[8px] text-[#fbbf24]">insurance req.</span>}
                </div>
                <div className="text-[9px] text-[#8b949e] mt-0.5 flex items-center gap-2 flex-wrap">
                  {p.issuing_authority && <span>{p.issuing_authority}</span>}
                  {p.cost > 0 && <span className="text-[#3fb950]">${p.cost.toLocaleString()}</span>}
                  {p.issue_date && <span>issued: {p.issue_date}</span>}
                  {p.expiry_date && <span className={p.expiry_date < today ? 'text-[#f85149]' : ''}>expires: {p.expiry_date}</span>}
                </div>
              </div>
              <select value={p.status} onChange={e => updateStatus(p.id, e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-1.5 py-1 text-[9px] font-bold" style={{ color: STATUS_COLORS[p.status] }}>
                {PERMIT_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <button onClick={() => deletePermit(p.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={11} /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}