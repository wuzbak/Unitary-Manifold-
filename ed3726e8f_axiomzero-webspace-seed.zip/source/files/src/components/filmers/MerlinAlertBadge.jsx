/**
 * MerlinAlertBadge — Proactive alert indicator for the suite shell.
 * Shows a count badge with severity color. Clicking opens the alert list.
 */
import { useState, useEffect } from 'react';
import { Bell, AlertTriangle, AlertCircle, Info, X, ChevronRight } from 'lucide-react';
import { scanProjectAlerts, ALERT_SEVERITY } from '@/lib/filmers/merlinAlerts';
import { base44 } from '@/api/base44Client';

export default function MerlinAlertBadge({ project, onNavigate }) {
  const [alerts, setAlerts] = useState([]);
  const [summary, setSummary] = useState({ critical: 0, warning: 0, info: 0, total: 0 });
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const scan = async () => {
    if (!project) {
      setAlerts([]);
      setSummary({ critical: 0, warning: 0, info: 0, total: 0 });
      return;
    }
    setLoading(true);
    try {
      const [scenes, cast, crew, items, scripts, shootDays, timeCards, permits, locations] = await Promise.all([
        base44.entities.Scene.filter({ project_id: project.id }),
        base44.entities.CastMember.filter({ project_id: project.id }),
        base44.entities.CrewMember.filter({ project_id: project.id }),
        base44.entities.DepartmentItem.filter({ project_id: project.id }),
        base44.entities.Script.filter({ project_id: project.id }, '-imported_date', 5),
        base44.entities.ShootDay.filter({ project_id: project.id }, 'day_number', 50),
        base44.entities.TimeCard.filter({ project_id: project.id }, '-shoot_date', 50),
        base44.entities.Permit.filter({ project_id: project.id }),
        base44.entities.Location.filter({ project_id: project.id }),
      ]);
      const { alerts: a, summary: s } = scanProjectAlerts({ project, scenes, cast, crew, items, scripts, shootDays, timeCards, permits, locations });
      setAlerts(a);
      setSummary(s);
    } catch {
      setAlerts([]);
      setSummary({ critical: 0, warning: 0, info: 0, total: 0 });
    }
    setLoading(false);
  };

  useEffect(() => { scan(); }, [project?.id]);

  const badgeColor = summary.critical > 0 ? ALERT_SEVERITY.critical.color : summary.warning > 0 ? ALERT_SEVERITY.warning.color : summary.info > 0 ? ALERT_SEVERITY.info.color : '#484f58';

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        className="relative flex items-center gap-1.5 px-3 py-2 rounded text-[10px] font-bold border transition-colors min-h-[40px]"
        style={{ borderColor: `${badgeColor}40`, color: badgeColor, background: `${badgeColor}10` }}
        title="Production Alerts"
      >
        <Bell size={12} />
        <span className="hidden sm:inline">Alerts</span>
        {summary.total > 0 && (
          <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full text-[8px] font-bold flex items-center justify-center text-black" style={{ background: badgeColor }}>
            {summary.total > 9 ? '9+' : summary.total}
          </span>
        )}
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-start justify-end pt-16 pr-4 bg-black/40 backdrop-blur-sm" onClick={() => setOpen(false)}>
          <div className="glass-strong clip-corner w-full max-w-md max-h-[70vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-3 border-b border-[#30363d] sticky top-0 bg-[#0d1117] z-10">
              <div className="flex items-center gap-2">
                <Bell size={14} className="text-[#fbbf24]" />
                <span className="text-xs font-bold text-[#fbbf24]">Production Alerts</span>
                {loading && <span className="text-[9px] text-[#484f58]">scanning…</span>}
              </div>
              <button onClick={() => setOpen(false)} className="text-[#484f58] hover:text-[#e6edf3]"><X size={14} /></button>
            </div>

            {/* Summary bar */}
            <div className="flex gap-2 p-3 border-b border-[#30363d]">
              <div className="flex-1 text-center p-2 rounded border border-[#f85149]/30">
                <div className="text-lg font-bold text-[#f85149]">{summary.critical}</div>
                <div className="text-[8px] text-[#8b949e] uppercase">Critical</div>
              </div>
              <div className="flex-1 text-center p-2 rounded border border-[#fbbf24]/30">
                <div className="text-lg font-bold text-[#fbbf24]">{summary.warning}</div>
                <div className="text-[8px] text-[#8b949e] uppercase">Warning</div>
              </div>
              <div className="flex-1 text-center p-2 rounded border border-[#4dd0e1]/30">
                <div className="text-lg font-bold text-[#4dd0e1]">{summary.info}</div>
                <div className="text-[8px] text-[#8b949e] uppercase">Info</div>
              </div>
            </div>

            {/* Alert list */}
            <div className="p-2 space-y-1.5">
              {alerts.length === 0 ? (
                <div className="text-center py-8">
                  <div className="text-[#3fb950] text-xs font-bold mb-1">All Clear</div>
                  <div className="text-[10px] text-[#484f58]">No production alerts detected.</div>
                </div>
              ) : (
                alerts.map(a => {
                  const sev = ALERT_SEVERITY[a.severity];
                  const Icon = a.severity === 'critical' ? AlertCircle : a.severity === 'warning' ? AlertTriangle : Info;
                  return (
                    <div
                      key={a.id}
                      className="p-2 rounded border cursor-pointer hover:bg-[#161b22] transition-colors"
                      style={{ borderColor: `${sev.color}30` }}
                      onClick={() => { if (onNavigate && a.tab) onNavigate(a.tab); setOpen(false); }}
                    >
                      <div className="flex items-start gap-2">
                        <Icon size={12} style={{ color: sev.color }} className="shrink-0 mt-0.5" />
                        <div className="flex-1 min-w-0">
                          <div className="text-[10px] font-bold" style={{ color: sev.color }}>{a.title}</div>
                          <div className="text-[9px] text-[#e6edf3]">{a.message}</div>
                          {a.action && <div className="text-[8px] text-[#8b949e] italic mt-0.5">→ {a.action}</div>}
                        </div>
                        {a.tab && <ChevronRight size={10} className="text-[#484f58] shrink-0" />}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="p-2 border-t border-[#30363d]">
              <button onClick={scan} className="w-full text-[10px] text-[#8b949e] hover:text-[#e6edf3] py-1.5">
                ↻ Rescan
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}