/**
 * MerlinSuitePanel — Unified, persistent, context-aware Merlin presence.
 *
 * Three zones in one right-docked panel (desktop) / bottom sheet (mobile):
 *   1. Alerts — proactive scan results + alignment suggestions
 *   2. Actions — context-aware tab action chips (replaces MerlinActionMenu)
 *   3. Chat — full UPM/Producer conversation with live project context
 *
 * Replaces MerlinActionMenu, MerlinAlertBadge, and MerlinProducerPanel.
 */
import { useState, useRef, useEffect } from 'react';
import { Sparkles, X, Send, Loader2, Bell, Zap, AlertCircle, AlertTriangle, Info, Check } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { buildFilmExpertPrompt } from '@/lib/merlinFilmExpert';
import { parseMerlinResponse } from '@/components/quantum-cat/parseMerlinResponse';
import { scanProjectAlerts, ALERT_SEVERITY, TAB_ACTIONS, scanStudioPoolForProject } from '@/lib/filmers/merlinAlerts';
import MerlinAgentRunner from '@/components/merlin/MerlinAgentRunner';
import { getToolManifest, formatToolManifest } from '@/lib/merlinAgentTools';
import { loadMemoryRecall } from '@/lib/merlinMemoryRecall';

const TAB_LABELS = {
  dashboard: 'Dashboard', script: 'Script', script_dashboard: 'Breakdown', cinematography: 'Cinematography',
  locations: 'Locations', scheduling: 'Scheduling', call_sheets: 'Call Sheets', cast: 'Cast', crew: 'Crew',
  actor_portal: 'Actor Portal', time_cards: 'Time Cards', finance: 'Finance', ad_suite: 'AD Suite',
  upm_overview: 'UPM Overview', storyboard: 'Storyboard', film_credits: 'Film Credits',
  local_resources: 'Local Resources', inventory_overview: 'Inventory Overview', export: 'Export',
  writers_room: 'Writers Room', studio_dashboard: 'Studio', studio_library: 'Library', studio_pool: 'Studio Pool',
};

export default function MerlinSuitePanel({ isOpen, onClose, tab, project, onNavigate, projects }) {
  const [zone, setZone] = useState('alerts');
  const [alerts, setAlerts] = useState([]);
  const [alertSummary, setAlertSummary] = useState({ critical: 0, warning: 0, info: 0, total: 0 });
  const [alignmentSuggestions, setAlignmentSuggestions] = useState([]);
  const [scanning, setScanning] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [actionResult, setActionResult] = useState(null);
  const [dismissedIds, setDismissedIds] = useState(() => {
    try { return JSON.parse(localStorage.getItem('merlin_dismissed_alignments') || '[]'); } catch { return []; }
  });
  const scrollRef = useRef(null);

  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [messages, chatLoading]);

  // Scan alerts + alignment suggestions on project change
  const scan = async () => {
    if (!project) {
      setAlerts([]); setAlertSummary({ critical: 0, warning: 0, info: 0, total: 0 });
      setAlignmentSuggestions([]);
      return;
    }
    setScanning(true);
    try {
      const [scenes, cast, crew, items, scripts, shootDays, timeCards, permits, locations] = await Promise.all([
        base44.entities.Scene.filter({ project_id: project.id }),
        base44.entities.CastMember.filter({ project_id: project.id }),
        base44.entities.CrewMember.filter({ project_id: project.id }),
        base44.entities.DepartmentItem.filter({ project_id: project.id }),
        base44.entities.Script.filter({ project_id: project.id }, '-imported_date', 5),
        base44.entities.ShootDay.filter({ project_id: project.id }, 'day_number', 50),
        base44.entities.TimeCard.filter({ project_id: project.id }, '-shoot_date', 50),
        base44.entities.Permit.filter({ project_id: project.id }),
        base44.entities.Location.filter({ project_id: project.id }),
      ]);
      const { alerts: a, summary: s } = scanProjectAlerts({ project, scenes, cast, crew, items, scripts, shootDays, timeCards, permits, locations });
      setAlerts(a); setAlertSummary(s);

      // Alignment suggestions — load standalone studio pool records
      const [standaloneItems, standaloneCast, standaloneCrew, standaloneLocs] = await Promise.all([
        base44.entities.DepartmentItem.list('-created_date', 500).then((all) => all.filter((r) => !r.project_id).map((r) => ({ ...r, _type: 'DepartmentItem' }))),
        base44.entities.CastMember.list('-created_date', 500).then((all) => all.filter((r) => !r.project_id).map((r) => ({ ...r, _type: 'CastMember' }))),
        base44.entities.CrewMember.list('-created_date', 500).then((all) => all.filter((r) => !r.project_id).map((r) => ({ ...r, _type: 'CrewMember' }))),
        base44.entities.Location.list('-created_date', 500).then((all) => all.filter((r) => !r.project_id).map((r) => ({ ...r, _type: 'Location' }))),
      ]);
      const allStandalone = [...standaloneItems, ...standaloneCast, ...standaloneCrew, ...standaloneLocs];
      const suggestions = scanStudioPoolForProject(project, allStandalone, { scenes, cast, locations })
        .filter((s) => !dismissedIds.includes(s.recordId));
      setAlignmentSuggestions(suggestions);
    } catch { /* ignore */ }
    setScanning(false);
  };

  useEffect(() => { scan(); }, [project?.id]);

  const approveAlignment = async (suggestion) => {
    try {
      await base44.entities[suggestion.recordType].update(suggestion.recordId, { project_id: project.id });
      setAlignmentSuggestions((prev) => prev.filter((s) => s.recordId !== suggestion.recordId));
    } catch { /* ignore */ }
  };

  const dismissAlignment = (suggestion) => {
    const newDismissed = [...dismissedIds, suggestion.recordId];
    setDismissedIds(newDismissed);
    localStorage.setItem('merlin_dismissed_alignments', JSON.stringify(newDismissed));
    setAlignmentSuggestions((prev) => prev.filter((s) => s.recordId !== suggestion.recordId));
  };

  const buildContext = async () => {
    if (!project) return 'NO PROJECT SELECTED — Studio Pool mode. Help with general production, or suggest creating a project.';
    const [scenes, cast, crew, items, scripts, shootDays, timeCards, permits, credits, resources] = await Promise.all([
      base44.entities.Scene.filter({ project_id: project.id }),
      base44.entities.CastMember.filter({ project_id: project.id }),
      base44.entities.CrewMember.filter({ project_id: project.id }),
      base44.entities.DepartmentItem.filter({ project_id: project.id }),
      base44.entities.Script.filter({ project_id: project.id }, '-imported_date', 5),
      base44.entities.ShootDay.filter({ project_id: project.id }, 'day_number', 50),
      base44.entities.TimeCard.filter({ project_id: project.id }, '-shoot_date', 50),
      base44.entities.Permit.filter({ project_id: project.id }),
      base44.entities.FilmCredit.filter({ project_id: project.id }),
      base44.entities.LocalResource.filter({ project_id: project.id }),
    ]);
    const deptSummary = {};
    items.forEach((i) => { deptSummary[i.department] = (deptSummary[i.department] || 0) + 1; });
    let scriptSummary = 'No scripts yet.';
    if (scripts.length > 0) {
      const latest = scripts[0];
      let elCount = 0, sceneCount = 0;
      try { const els = latest.elements_json ? JSON.parse(latest.elements_json) : []; elCount = els.length; sceneCount = els.filter((e) => e.type === 'scene').length; } catch { /* ignore */ }
      scriptSummary = `Latest: "${latest.title}" | ${elCount} elements | ${sceneCount} scenes`;
    }
    const laborCost = timeCards.filter((tc) => tc.status === 'approved').reduce((s, tc) => s + (tc.total_pay || 0), 0);
    const otTotal = timeCards.filter((tc) => tc.status === 'approved').reduce((s, tc) => s + (tc.ot_hours || 0), 0);
    return `LIVE PROJECT DATA:
Title: ${project.title} | Status: ${project.status} | Budget: $${project.total_budget || 0} | Shoot Days: ${project.shoot_days || 0}
Scenes: ${scenes.length} | Cast: ${cast.length} | Crew: ${crew.length} | Department Items: ${items.length}
Departments: ${Object.entries(deptSummary).map(([k, v]) => `${k}(${v})`).join(', ') || 'none'}
SCRIPT: ${scriptSummary}
SCHEDULE: ${shootDays.length} shoot days | LABOR: ${timeCards.length} time cards | $${laborCost.toLocaleString()} | OT: ${otTotal}h
PERMITS: ${permits.length} | CREDITS: ${credits.length} | RESOURCES: ${resources.length}
ACTIVE TAB: ${TAB_LABELS[tab] || tab} — The user is currently viewing this section. Tailor your advice to this context.`;
  };

  const send = async (text) => {
    const msg = text || input;
    if (!msg.trim() || chatLoading) return;
    setInput('');
    setMessages((m) => [...m, { role: 'user', content: msg }]);
    setChatLoading(true);
    try {
      const ctx = await buildContext();
      const memoryRecall = await loadMemoryRecall('film', project?.title || '');
      const toolManifest = formatToolManifest(getToolManifest('/filmers-companion'));
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `${buildFilmExpertPrompt()}\n\n${ctx}\n\n${memoryRecall}\n\nAVAILABLE TOOLS (emit [TOOL_CALL]{"tool":"<name>","args":{...}}[/TOOL_CALL] to call):\n${toolManifest}\n\nUSER QUESTION: ${msg}`,
        model: 'claude_sonnet_4_6',
      });
      const parsed = parseMerlinResponse(res);
      setMessages((m) => [...m, { role: 'assistant', content: parsed.body || res }]);
    } catch (e) { setMessages((m) => [...m, { role: 'assistant', content: `Error: ${e.message}` }]); }
    setChatLoading(false);
  };

  const runAction = async (action) => {
    setActionLoading(true);
    setActionResult(null);
    try {
      const ctx = await buildContext();
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `${buildFilmExpertPrompt()}\n\n${ctx}\n\nACTION REQUEST: ${action.label} — ${action.desc}\nPerform this action and provide actionable, specific results.`,
        model: 'claude_sonnet_4_6',
      });
      const parsed = parseMerlinResponse(res);
      setActionResult({ action: action.label, body: parsed.body || res });
      setZone('actions');
    } catch (e) { setActionResult({ action: action.label, body: `Error: ${e.message}` }); }
    setActionLoading(false);
  };

  const actions = TAB_ACTIONS[tab] || TAB_ACTIONS.dashboard;
  const badgeColor = alertSummary.critical > 0 ? ALERT_SEVERITY.critical.color : alertSummary.warning > 0 ? ALERT_SEVERITY.warning.color : alertSummary.info > 0 ? ALERT_SEVERITY.info.color : '#484f58';

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[55] lg:hidden" onClick={onClose} />
      <div className="fixed right-0 top-0 bottom-0 w-full max-w-[380px] z-[56] glass-strong border-l border-[#fbbf24]/20 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-3 border-b border-[#30363d] shrink-0">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Sparkles size={14} className="text-[#fbbf24]" />
              {alertSummary.total > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-3.5 h-3.5 rounded-full text-[7px] font-bold flex items-center justify-center text-black" style={{ background: badgeColor }}>
                  {alertSummary.total > 9 ? '9+' : alertSummary.total}
                </span>
              )}
            </div>
            <span className="text-xs font-bold text-[#fbbf24]">Merlin</span>
            <span className="text-[8px] text-[#484f58] uppercase tracking-wider">{TAB_LABELS[tab] || tab}</span>
          </div>
          <button onClick={onClose} className="text-[#484f58] hover:text-[#e6edf3]"><X size={16} /></button>
        </div>

        {/* Zone switcher */}
        <div className="flex items-center gap-1 p-2 border-b border-[#30363d] shrink-0">
          {[
            { id: 'alerts', label: 'Alerts', icon: Bell, badge: alertSummary.total + alignmentSuggestions.length },
            { id: 'actions', label: 'Actions', icon: Zap, badge: 0 },
            { id: 'tasks', label: 'Tasks', icon: Sparkles, badge: 0 },
            { id: 'chat', label: 'Chat', icon: Sparkles, badge: 0 },
          ].map((z) => (
            <button
              key={z.id}
              onClick={() => setZone(z.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-bold transition-all relative ${zone === z.id ? 'bg-[#fbbf24] text-black' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
            >
              <z.icon size={11} /> {z.label}
              {z.badge > 0 && zone !== z.id && (
                <span className="ml-0.5 px-1 rounded-full text-[8px] font-bold" style={{ background: badgeColor, color: '#000' }}>{z.badge}</span>
              )}
            </button>
          ))}
        </div>

        {/* Zone content */}
        <div className="flex-1 overflow-y-auto min-h-0">
          {/* Alerts zone */}
          {zone === 'alerts' && (
            <div className="p-3 space-y-3">
              {scanning && <div className="flex items-center gap-2 text-[10px] text-[#8b949e]"><Loader2 size={12} className="animate-spin" /> Scanning…</div>}

              {/* Alignment suggestions */}
              {alignmentSuggestions.length > 0 && (
                <div>
                  <div className="text-[9px] font-bold uppercase tracking-wider text-[#4dd0e1] mb-2">Studio Pool Matches</div>
                  <div className="space-y-1.5">
                    {alignmentSuggestions.map((s) => (
                      <div key={s.recordId} className="glass-panel clip-corner p-2 border-l-2 border-[#4dd0e1]/40">
                        <div className="text-[10px] font-bold text-[#e6edf3]">{s.title}</div>
                        <div className="text-[9px] text-[#8b949e]">{s.message}</div>
                        <div className="flex items-center gap-1.5 mt-1.5">
                          <button onClick={() => approveAlignment(s)} className="flex items-center gap-1 px-2 py-1 rounded text-[8px] font-bold bg-[#3fb950] text-black hover:opacity-80">
                            <Check size={9} /> Link
                          </button>
                          <button onClick={() => dismissAlignment(s)} className="px-2 py-1 rounded text-[8px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]">
                            Dismiss
                          </button>
                          <span className="text-[8px] text-[#484f58] ml-auto">{Math.round(s.score)}% match</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Production alerts */}
              <div>
                <div className="text-[9px] font-bold uppercase tracking-wider text-[#fbbf24] mb-2">Production Alerts</div>
                {alertSummary.total === 0 && !alignmentSuggestions.length ? (
                  <div className="text-center py-6">
                    <div className="text-[#3fb950] text-xs font-bold mb-1">All Clear</div>
                    <div className="text-[10px] text-[#484f58]">No alerts detected.</div>
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    {alerts.map((a) => {
                      const sev = ALERT_SEVERITY[a.severity];
                      const Icon = a.severity === 'critical' ? AlertCircle : a.severity === 'warning' ? AlertTriangle : Info;
                      return (
                        <div key={a.id} className="p-2 rounded border cursor-pointer hover:bg-[#161b22] transition-colors" style={{ borderColor: `${sev.color}30` }} onClick={() => { if (onNavigate && a.tab) onNavigate(a.tab); }}>
                          <div className="flex items-start gap-2">
                            <Icon size={12} style={{ color: sev.color }} className="shrink-0 mt-0.5" />
                            <div className="flex-1 min-w-0">
                              <div className="text-[10px] font-bold" style={{ color: sev.color }}>{a.title}</div>
                              <div className="text-[9px] text-[#e6edf3]">{a.message}</div>
                              {a.action && <div className="text-[8px] text-[#8b949e] italic mt-0.5">→ {a.action}</div>}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
              <button onClick={scan} className="w-full text-[10px] text-[#8b949e] hover:text-[#e6edf3] py-1.5">↻ Rescan</button>
            </div>
          )}

          {/* Actions zone */}
          {zone === 'actions' && (
            <div className="p-3 space-y-2">
              <div className="text-[9px] font-bold uppercase tracking-wider text-[#fbbf24] mb-1">{TAB_LABELS[tab] || tab} Actions</div>
              {actions.map((a) => (
                <button key={a.id} onClick={() => runAction(a)} disabled={actionLoading} className="w-full text-left p-2.5 rounded border border-[#30363d] hover:border-[#fbbf24]/40 hover:bg-[#161b22] transition-colors group disabled:opacity-40">
                  <div className="text-[10px] font-bold text-[#e6edf3] group-hover:text-[#fbbf24]">{a.label}</div>
                  <div className="text-[8px] text-[#484f58]">{a.desc}</div>
                </button>
              ))}
              {actionLoading && <div className="flex items-center gap-2 text-[10px] text-[#8b949e]"><Loader2 size={12} className="animate-spin" /> Merlin working…</div>}
              {actionResult && (
                <div className="glass-panel clip-corner p-3 mt-2">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold text-[#fbbf24]">{actionResult.action}</span>
                    <button onClick={() => setActionResult(null)} className="text-[#484f58] hover:text-[#e6edf3]"><X size={11} /></button>
                  </div>
                  <div className="text-[10px] text-[#e6edf3] whitespace-pre-wrap leading-relaxed max-h-[40vh] overflow-y-auto">{actionResult.body}</div>
                </div>
              )}
            </div>
          )}

          {/* Tasks zone — autonomous agent */}
          {zone === 'tasks' && (
            <MerlinAgentRunner
              context={project ? `Project: ${project.title} | Status: ${project.status} | Budget: $${project.total_budget || 0} | Shoot Days: ${project.shoot_days || 0} | Active Tab: ${TAB_LABELS[tab] || tab}` : 'No project selected — Studio Pool mode'}
              tools={getToolManifest('/filmers-companion')}
              accent="#fbbf24"
            />
          )}

          {/* Chat zone */}
          {zone === 'chat' && (
            <>
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-2.5 min-h-0">
                {messages.length === 0 && (
                  <div className="text-center py-6">
                    <Sparkles size={20} className="text-[#fbbf24] mx-auto mb-2" />
                    <p className="text-[10px] text-[#8b949e] mb-3">{project ? "I can see your project data in real-time. What do you need?" : "Ask me anything about your production."}</p>
                    <div className="flex flex-col gap-1.5">
                      {['Analyze my script structure', 'Check turnaround compliance', 'Optimize my shooting order', 'What should I prioritize?'].map((s) => (
                        <button key={s} onClick={() => send(s)} className="text-left text-[10px] text-[#e6edf3] bg-[#161b22] border border-[#30363d] rounded p-2 hover:border-[#fbbf24]/40 transition-colors">{s}</button>
                      ))}
                    </div>
                  </div>
                )}
                {messages.map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] rounded p-2.5 text-[10px] leading-relaxed ${m.role === 'user' ? 'bg-[#fbbf24] text-black' : 'bg-[#161b22] border border-[#30363d] text-[#e6edf3]'}`}>
                      <div className="whitespace-pre-wrap">{m.content}</div>
                    </div>
                  </div>
                ))}
                {chatLoading && <div className="flex justify-center"><Loader2 className="animate-spin text-[#fbbf24]" size={14} /></div>}
              </div>
              <div className="p-3 border-t border-[#30363d] flex gap-2 shrink-0">
                <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} placeholder="Ask Merlin…" className="flex-1 bg-[#0B0F13] border border-[#30363d] rounded px-2.5 py-2 text-[11px] text-[#e6edf3] focus:border-[#fbbf24]/40 focus:outline-none" />
                <button onClick={() => send()} disabled={chatLoading} className="px-3 py-2 bg-[#fbbf24] text-black rounded text-xs font-bold disabled:opacity-40"><Send size={12} /></button>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}