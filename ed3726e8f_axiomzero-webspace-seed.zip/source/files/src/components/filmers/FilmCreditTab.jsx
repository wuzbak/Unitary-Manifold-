/**
 * FilmCreditTab — Above/below-the-line credit management.
 * Billing position, title cards, credit type (opening/end crawl/single card).
 * Exports formatted credit roll for deliverables and union submissions.
 */
import { useState, useEffect, useCallback } from 'react';
import { Award, Plus, Trash2, Loader2, Download, Star, ArrowUp, ArrowDown } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { exportTXT, exportCSV } from '@/lib/filmers/filmExport';
import { logActivity } from '@/lib/filmers/activityLog';
import DualEntryToggle, { resolveProjectId } from './DualEntryToggle';

const TIER_COLORS = { above_line: '#fbbf24', below_line: '#58a6ff' };
const CREDIT_TYPES = ['opening', 'end_crawl', 'single_card', 'group_card'];

export default function FilmCreditTab({ project }) {
  const [credits, setCredits] = useState([]);
  const [cast, setCast] = useState([]);
  const [crew, setCrew] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [entryMode, setEntryMode] = useState('project');
  const [form, setForm] = useState({ person_name: '', role: '', credit_tier: 'below_line', department: '', billing_position: 0, title_card: false, credit_type: 'end_crawl', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [cr, c, cr2] = await Promise.all([
        base44.entities.FilmCredit.filter({ project_id: project.id }),
        base44.entities.CastMember.filter({ project_id: project.id }),
        base44.entities.CrewMember.filter({ project_id: project.id }),
      ]);
      setCredits(cr); setCast(c); setCrew(cr2);
    } catch { /* best-effort */ }
    finally { setLoading(false); }
  }, [project.id]);

  useEffect(() => { load(); }, [load]);

  const addCredit = async () => {
    if (!form.person_name.trim()) return;
    const pid = resolveProjectId(entryMode, project);
    const credit = await base44.entities.FilmCredit.create({ ...form, project_id: pid, billing_position: Number(form.billing_position) || 0 });
    setCredits([...credits, credit]);
    logActivity(project.id, 'credit', form.person_name, 'created', form.credit_tier);
    setForm({ person_name: '', role: '', credit_tier: 'below_line', department: '', billing_position: 0, title_card: false, credit_type: 'end_crawl', notes: '' });
    setShowAdd(false);
  };

  const deleteCredit = async (id) => {
    await base44.entities.FilmCredit.delete(id);
    setCredits(credits.filter(c => c.id !== id));
  };

  const moveCredit = async (id, direction) => {
    const credit = credits.find(c => c.id === id);
    if (!credit) return;
    const newPos = credit.billing_position + direction;
    await base44.entities.FilmCredit.update(id, { billing_position: newPos });
    setCredits(credits.map(c => c.id === id ? { ...c, billing_position: newPos } : c));
  };

  const importFromCastCrew = async () => {
    // Auto-generate credits from existing cast and crew
    const newCredits = [];
    cast.forEach(c => {
      if (!credits.find(cr => cr.person_name === c.name)) {
        newCredits.push({ project_id: project.id, person_name: c.name, role: c.role || 'Actor', credit_tier: 'above_line', billing_position: 0, title_card: false, credit_type: 'end_crawl', linked_cast_id: c.id });
      }
    });
    crew.forEach(c => {
      if (!credits.find(cr => cr.person_name === c.name)) {
        newCredits.push({ project_id: project.id, person_name: c.name, role: c.position || c.department, credit_tier: c.above_below_line || 'below_line', department: c.department, billing_position: 0, title_card: false, credit_type: 'end_crawl', linked_crew_id: c.id });
      }
    });
    if (newCredits.length > 0) {
      await base44.entities.FilmCredit.bulkCreate(newCredits);
      load();
      logActivity(project.id, 'credit', `${newCredits.length} credits`, 'imported', 'from cast & crew');
    }
  };

  const sorted = [...credits].sort((a, b) => {
    if (a.credit_tier !== b.credit_tier) return a.credit_tier === 'above_line' ? -1 : 1;
    return (a.billing_position || 0) - (b.billing_position || 0);
  });
  const aboveLine = sorted.filter(c => c.credit_tier === 'above_line');
  const belowLine = sorted.filter(c => c.credit_tier === 'below_line');

  const exportCreditRoll = () => {
    const lines = ['=' .repeat(60), `  CREDITS — ${project.title}`, '=' .repeat(60), '', 'ABOVE THE LINE', '-' .repeat(30)];
    aboveLine.forEach(c => {
      if (c.title_card) lines.push(`\n  ${c.person_name}`);
      if (c.role) lines.push(`  ${c.role}`);
    });
    lines.push('', 'BELOW THE LINE', '-' .repeat(30));
    let currentDept = '';
    belowLine.forEach(c => {
      if (c.department && c.department !== currentDept) { lines.push(`\n  ${c.department.toUpperCase()}`); currentDept = c.department; }
      lines.push(`  ${c.person_name}${c.role ? ' — ' + c.role : ''}`);
    });
    lines.push('', '=' .repeat(60));
    exportTXT(lines.join('\n'), 'credit_roll.txt');
  };

  const exportCreditsCSV = () => {
    exportCSV(sorted.map(c => ({ name: c.person_name, role: c.role, tier: c.credit_tier, department: c.department, billing: c.billing_position, title_card: c.title_card, type: c.credit_type })), 'credits.csv');
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#fbbf24]" size={18} /></div>;

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Award size={14} className="text-[#fbbf24]" />
          <span className="text-xs font-bold text-[#fbbf24]">Film Credits</span>
          <span className="text-[9px] text-[#484f58]">{credits.length} credits · {aboveLine.length} ATL · {belowLine.length} BTL</span>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <button onClick={importFromCastCrew} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#3fb950]/20 border border-[#3fb950]/40 text-[#3fb950] hover:bg-[#3fb950]/30">
            <Plus size={10} /> Import from Cast/Crew
          </button>
          <button onClick={exportCreditRoll} disabled={!credits.length} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] disabled:opacity-40">
            <Download size={10} /> Credit Roll
          </button>
          <button onClick={exportCreditsCSV} disabled={!credits.length} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] disabled:opacity-40">
            <Download size={10} /> CSV
          </button>
          <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#fbbf24] text-black">
            <Plus size={10} /> Add Credit
          </button>
        </div>
      </div>

      {/* Add form */}
      {showAdd && (
        <div className="glass-panel clip-corner p-3 border-l-2 border-[#fbbf24] space-y-2">
          <DualEntryToggle mode={entryMode} onChange={setEntryMode} projectName={project?.title} />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <input value={form.person_name} onChange={e => setForm({ ...form, person_name: e.target.value })} placeholder="Name *" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} placeholder="Role / Title" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <select value={form.credit_tier} onChange={e => setForm({ ...form, credit_tier: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              <option value="above_line">Above the Line</option>
              <option value="below_line">Below the Line</option>
            </select>
            <input value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} placeholder="Department" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="number" value={form.billing_position} onChange={e => setForm({ ...form, billing_position: +e.target.value })} placeholder="Billing order" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <select value={form.credit_type} onChange={e => setForm({ ...form, credit_type: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              {CREDIT_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
            <label className="flex items-center gap-1.5 text-[10px] text-[#8b949e] col-span-2">
              <input type="checkbox" checked={form.title_card} onChange={e => setForm({ ...form, title_card: e.target.checked })} className="accent-[#fbbf24]" /> Title card (solo billing)
            </label>
          </div>
          <div className="flex gap-2">
            <button onClick={addCredit} className="px-3 py-1.5 bg-[#fbbf24] text-black rounded text-[10px] font-bold">Save Credit</button>
            <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
          </div>
        </div>
      )}

      {/* Credits list */}
      {credits.length === 0 ? (
        <div className="glass-panel clip-corner p-8 text-center">
          <Award size={28} className="text-[#484f58] mx-auto mb-3" />
          <p className="text-xs text-[#8b949e] mb-2">No credits yet.</p>
          <p className="text-[10px] text-[#484f58]">Click "Import from Cast/Crew" to auto-generate from existing cast and crew, or add manually.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Above the line */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Star size={12} className="text-[#fbbf24]" />
              <span className="text-[10px] font-bold text-[#fbbf24] uppercase tracking-wider">Above the Line</span>
              <span className="text-[8px] text-[#484f58]">({aboveLine.length})</span>
            </div>
            <div className="space-y-1">
              {aboveLine.map(c => (
                <div key={c.id} className="glass-panel clip-corner p-2.5 flex items-center gap-2">
                  {c.title_card && <Star size={12} className="text-[#fbbf24] fill-[#fbbf24]" />}
                  <div className="flex-1">
                    <span className="text-xs font-bold text-[#e6edf3]">{c.person_name}</span>
                    {c.role && <span className="text-[10px] text-[#fbbf24] ml-2">— {c.role}</span>}
                    <span className="text-[8px] text-[#484f58] ml-2">{c.credit_type}</span>
                  </div>
                  <button onClick={() => moveCredit(c.id, -1)} className="text-[#484f58] hover:text-[#e6edf3]"><ArrowUp size={11} /></button>
                  <button onClick={() => moveCredit(c.id, 1)} className="text-[#484f58] hover:text-[#e6edf3]"><ArrowDown size={11} /></button>
                  <button onClick={() => deleteCredit(c.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={11} /></button>
                </div>
              ))}
            </div>
          </div>

          {/* Below the line */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Award size={12} className="text-[#58a6ff]" />
              <span className="text-[10px] font-bold text-[#58a6ff] uppercase tracking-wider">Below the Line</span>
              <span className="text-[8px] text-[#484f58]">({belowLine.length})</span>
            </div>
            <div className="space-y-1">
              {belowLine.map(c => (
                <div key={c.id} className="glass-panel clip-corner p-2.5 flex items-center gap-2">
                  <div className="flex-1">
                    <span className="text-xs font-bold text-[#e6edf3]">{c.person_name}</span>
                    {c.role && <span className="text-[10px] text-[#58a6ff] ml-2">— {c.role}</span>}
                    {c.department && <span className="text-[8px] px-1.5 py-0.5 rounded border border-[#30363d] text-[#8b949e] ml-2">{c.department}</span>}
                  </div>
                  <button onClick={() => deleteCredit(c.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={11} /></button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}