/**
 * BreakdownReviewPanel — Shows suggested entities from script breakdown,
 * grouped by department, with accept/reject/edit per item.
 * Only approved items are created when the user clicks "Apply".
 */
import { useState, useEffect } from 'react';
import { Check, X, Loader2, Package, Users, MapPin, Film, ChevronDown, ChevronRight } from 'lucide-react';
import { DEPARTMENTS, DEPARTMENT_MAP } from '@/lib/filmers/departments';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/filmers/activityLog';

export default function BreakdownReviewPanel({ breakdown, project, onApplied, onClose }) {
  const [suggestions, setSuggestions] = useState(breakdown);
  const [expanded, setExpanded] = useState({});
  const [applying, setApplying] = useState(false);
  const [applied, setApplied] = useState(false);
  const [result, setResult] = useState(null);

  useEffect(() => {
    setSuggestions(breakdown);
    // Expand all by default
    const allExpanded = {};
    Object.keys(breakdown).forEach(k => { allExpanded[k] = true; });
    setExpanded(allExpanded);
  }, [breakdown]);

  const toggleItem = (group, idx) => {
    const next = { ...suggestions };
    next[group][idx] = { ...next[group][idx], approved: !next[group][idx].approved };
    setSuggestions(next);
  };

  const editItem = (group, idx, field, value) => {
    const next = { ...suggestions };
    next[group][idx] = { ...next[group][idx], [field]: value };
    setSuggestions(next);
  };

  const toggleGroup = (group) => {
    setExpanded(prev => ({ ...prev, [group]: !prev[group] }));
  };

  const approvedCount = (group) => (suggestions[group] || []).filter(i => i.approved).length;

  const apply = async () => {
    setApplying(true);
    const created = { scenes: 0, characters: 0, locations: 0, departmentItems: 0 };

    try {
      // Scenes
      const approvedScenes = (suggestions.scenes || []).filter(s => s.approved);
      if (approvedScenes.length > 0) {
        // Delete existing scenes first (replace mode)
        await base44.entities.Scene.deleteMany({ project_id: project.id });
        const records = approvedScenes.map(s => ({
          project_id: project.id,
          scene_number: s.scene_number,
          int_ext: s.int_ext,
          day_night: s.day_night,
          location_text: s.location_text,
          synopsis: s.synopsis,
          pages: s.pages,
          call_time: s.call_time,
          sort_order: s.sort_order,
        }));
        await base44.entities.Scene.bulkCreate(records);
        created.scenes = records.length;
        logActivity(project.id, 'breakdown', `${records.length} scenes`, 'created from script breakdown');
      }

      // Characters (only new ones)
      const newChars = (suggestions.characters || []).filter(c => c.approved && c._isNew);
      if (newChars.length > 0) {
        const records = newChars.map(c => ({
          project_id: project.id,
          name: c.name,
          role: c.role || '',
          sag_status: c.sag_status,
          day_rate: c.day_rate,
        }));
        await base44.entities.CastMember.bulkCreate(records);
        created.characters = records.length;
        logActivity(project.id, 'cast', `${records.length} cast members`, 'created from script breakdown');
      }

      // Locations (only new ones)
      const newLocs = (suggestions.locations || []).filter(l => l.approved && l._isNew);
      if (newLocs.length > 0) {
        const records = newLocs.map(l => ({
          project_id: project.id,
          name: l.name,
          permit_status: l.permit_status,
        }));
        await base44.entities.Location.bulkCreate(records);
        created.locations = records.length;
        logActivity(project.id, 'location', `${records.length} locations`, 'created from script breakdown');
      }

      // Department items
      const approvedItems = (suggestions.departmentItems || []).filter(i => i.approved);
      if (approvedItems.length > 0) {
        const records = approvedItems.map(i => ({
          project_id: project.id,
          department: i.department,
          item_name: i.item_name,
          category: i.category,
          quantity: i.quantity,
          status: 'needed',
          notes: `From script breakdown (scene ${i._scene_number || '?'})`,
        }));
        await base44.entities.DepartmentItem.bulkCreate(records);
        created.departmentItems = records.length;
        logActivity(project.id, 'department', `${records.length} items`, 'created from script breakdown');
      }

      setResult(created);
      setApplied(true);
      if (onApplied) onApplied(created);
    } catch (e) {
      setResult({ error: e.message });
    }
    setApplying(false);
  };

  if (applied && result) {
    return (
      <div className="glass-strong clip-corner p-6">
        <div className="flex items-center gap-2 mb-3">
          <Check size={16} className="text-[#34d399]" />
          <h3 className="text-sm font-bold text-[#34d399]">Breakdown Applied</h3>
        </div>
        {result.error ? (
          <p className="text-[10px] text-[#f85149]">{result.error}</p>
        ) : (
          <div className="space-y-1 text-[10px] text-[#8b949e]">
            {result.scenes > 0 && <p>✓ {result.scenes} scenes created</p>}
            {result.characters > 0 && <p>✓ {result.characters} cast members created</p>}
            {result.locations > 0 && <p>✓ {result.locations} locations created</p>}
            {result.departmentItems > 0 && <p>✓ {result.departmentItems} department items created</p>}
            {(result.scenes + result.characters + result.locations + result.departmentItems) === 0 && <p>No items were approved for creation.</p>}
          </div>
        )}
        <button onClick={onClose} className="mt-4 px-4 py-2 bg-[#a78bfa] text-black rounded text-xs font-bold">Close</button>
      </div>
    );
  }

  const groups = [
    { key: 'scenes', label: 'Scenes', icon: Film, color: '#a78bfa' },
    { key: 'characters', label: 'Cast', icon: Users, color: '#fbbf24' },
    { key: 'locations', label: 'Locations', icon: MapPin, color: '#34d399' },
    { key: 'departmentItems', label: 'Department Items', icon: Package, color: '#58a6ff' },
  ];

  return (
    <div className="glass-strong clip-corner p-4">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Package size={14} className="text-[#a78bfa]" />
          <h3 className="text-xs font-bold text-[#a78bfa]">Breakdown Review</h3>
          <span className="text-[9px] text-[#484f58]">
            {suggestions.stats ? `${suggestions.stats.sceneCount} scenes · ${suggestions.stats.characterCount} chars · ${suggestions.stats.departmentItemCount} items` : ''}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={apply} disabled={applying} className="flex items-center gap-1 px-3 py-1.5 bg-[#34d399] text-black rounded text-[10px] font-bold hover:opacity-80 disabled:opacity-40">
            {applying ? <Loader2 size={10} className="animate-spin" /> : <Check size={10} />} Apply Approved
          </button>
          <button onClick={onClose} className="text-[#484f58] hover:text-[#e6edf3]"><X size={14} /></button>
        </div>
      </div>

      <div className="space-y-2 max-h-[60vh] overflow-y-auto">
        {groups.map(group => {
          const items = suggestions[group.key] || [];
          if (items.length === 0) return null;
          const Icon = group.icon;
          const isExpanded = expanded[group.key];
          const count = approvedCount(group.key);
          return (
            <div key={group.key} className="border border-[#30363d] rounded">
              <button
                onClick={() => toggleGroup(group.key)}
                className="w-full flex items-center justify-between p-2 hover:bg-[#161b22] transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  {isExpanded ? <ChevronDown size={10} className="text-[#484f58]" /> : <ChevronRight size={10} className="text-[#484f58]" />}
                  <Icon size={12} style={{ color: group.color }} />
                  <span className="text-[10px] font-bold" style={{ color: group.color }}>{group.label}</span>
                  <span className="text-[9px] text-[#484f58]">({count}/{items.length} approved)</span>
                </div>
              </button>
              {isExpanded && (
                <div className="p-2 space-y-1 border-t border-[#30363d]">
                  {group.key === 'departmentItems' ? (
                    // Department items grouped by department
                    DEPARTMENTS.map(dept => {
                      const deptItems = items.filter(i => i.department === dept.key);
                      if (deptItems.length === 0) return null;
                      return (
                        <div key={dept.key} className="mb-2">
                          <div className="text-[9px] font-bold uppercase mb-1" style={{ color: dept.color }}>{dept.key} ({deptItems.filter(i => i.approved).length}/{deptItems.length})</div>
                          {deptItems.map((item, idx) => {
                            const globalIdx = items.indexOf(item);
                            return (
                              <div key={idx} className="flex items-center gap-1.5 p-1.5 rounded border border-[#30363d] hover:border-[#a78bfa]/30">
                                <input type="checkbox" checked={item.approved} onChange={() => toggleItem('departmentItems', globalIdx)} className="accent-[#a78bfa] shrink-0" />
                                <input
                                  value={item.item_name}
                                  onChange={e => editItem('departmentItems', globalIdx, 'item_name', e.target.value)}
                                  className="flex-1 bg-transparent text-[10px] text-[#e6edf3] outline-none border-b border-transparent focus:border-[#a78bfa]/40"
                                />
                                <span className="text-[8px] text-[#484f58] shrink-0">#{item._scene_number || '?'}</span>
                                <span className="text-[8px] px-1 rounded shrink-0" style={{ background: `${dept.color}20`, color: dept.color }}>
                                  {Math.round(item.confidence * 100)}%
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })
                  ) : (
                    items.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-1.5 p-1.5 rounded border border-[#30363d] hover:border-[#a78bfa]/30">
                        <input type="checkbox" checked={item.approved} onChange={() => toggleItem(group.key, idx)} className="accent-[#a78bfa] shrink-0" />
                        {group.key === 'scenes' ? (
                          <>
                            <span className="text-[9px] font-bold text-[#a78bfa] shrink-0 w-6">{item.scene_number}</span>
                            <span className="text-[8px] text-[#484f58] shrink-0">{item.int_ext}/{item.day_night}</span>
                            <input
                              value={item.location_text}
                              onChange={e => editItem(group.key, idx, 'location_text', e.target.value)}
                              className="flex-1 bg-transparent text-[10px] text-[#e6edf3] outline-none border-b border-transparent focus:border-[#a78bfa]/40"
                            />
                            <span className="text-[8px] text-[#484f58] shrink-0">{item.pages}p</span>
                          </>
                        ) : group.key === 'characters' ? (
                          <>
                            <input
                              value={item.name}
                              onChange={e => editItem(group.key, idx, 'name', e.target.value)}
                              className="flex-1 bg-transparent text-[10px] text-[#e6edf3] outline-none border-b border-transparent focus:border-[#a78bfa]/40"
                            />
                            {item._isNew ? <span className="text-[8px] text-[#34d399] shrink-0">NEW</span> : <span className="text-[8px] text-[#484f58] shrink-0">exists</span>}
                            <span className="text-[8px] text-[#484f58] shrink-0">{item._scene_count} scenes</span>
                          </>
                        ) : (
                          <>
                            <input
                              value={item.name}
                              onChange={e => editItem(group.key, idx, 'name', e.target.value)}
                              className="flex-1 bg-transparent text-[10px] text-[#e6edf3] outline-none border-b border-transparent focus:border-[#a78bfa]/40"
                            />
                            {item._isNew ? <span className="text-[8px] text-[#34d399] shrink-0">NEW</span> : <span className="text-[8px] text-[#484f58] shrink-0">exists</span>}
                            <span className="text-[8px] text-[#484f58] shrink-0">{item._scene_count} scenes</span>
                          </>
                        )}
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}