import { useState, useEffect } from 'react';
import { Clock, Play, Plus, CheckCircle2, AlertTriangle, Download, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { checkTurnaround, generateOneLiner, generateCallSheet } from '@/lib/filmers/filmEngine';
import { exportPDF, exportTXT, exportCSV } from '@/lib/filmers/filmExport';
import ImportExportBar from './ImportExportBar';

export default function ADSuiteTab({ project }) {
  const [wrapTime, setWrapTime] = useState('22:00');
  const [callTime, setCallTime] = useState('07:00');
  const [turnaround, setTurnaround] = useState(null);
  const [scenes, setScenes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loc, setLoc] = useState({ name: '', address: '', nearest_hospital: '', notes: '' });
  const [date, setDate] = useState('');
  const [oneLiner, setOneLiner] = useState(null);
  const [callSheet, setCallSheet] = useState(null);

  useEffect(() => { (async () => { try { setScenes(await base44.entities.Scene.filter({ project_id: project.id }, 'sort_order', 500)); } finally { setLoading(false); } })(); }, [project.id]);

  const genOneLiner = () => setOneLiner(generateOneLiner(scenes));
  const genCallSheet = () => setCallSheet(generateCallSheet(scenes, loc, date));
  const doExportScenes = () => { exportCSV(scenes.map((s, i) => ({ scene: s.scene_number || i + 1, int_ext: s.int_ext, day_night: s.day_night, location: s.location_text, synopsis: s.synopsis, pages: s.pages, call_time: s.call_time })), 'ad_scenes.csv'); };

  return (
    <div className="space-y-4">
      {/* Turnaround */}
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><Clock size={14} className="text-[#f472b6]" /><span className="text-xs font-bold text-[#f472b6]">Turnaround Compliance (12h minimum)</span></div>
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div><label className="text-[9px] text-[#8b949e] block mb-1">Wrap Time</label><input type="time" value={wrapTime} onChange={(e) => setWrapTime(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" /></div>
          <div><label className="text-[9px] text-[#8b949e] block mb-1">Next Call Time</label><input type="time" value={callTime} onChange={(e) => setCallTime(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" /></div>
        </div>
        <button onClick={() => setTurnaround(checkTurnaround(wrapTime, callTime))} className="flex items-center gap-1.5 bg-[#f472b6] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80"><Play size={12} /> Check</button>
        {turnaround && (
          <div className={`flex items-center gap-2 mt-3 text-xs font-bold ${turnaround.violation ? 'text-[#f85149]' : 'text-[#3fb950]'}`}>
            {turnaround.violation ? <AlertTriangle size={14} /> : <CheckCircle2 size={14} />}Gap: {turnaround.gapHours}h — {turnaround.violation ? `VIOLATION (min ${turnaround.minimumRequired}h)` : 'COMPLIANT'}
          </div>
        )}
      </div>

      {/* Scene list + call sheet */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="glass-strong clip-corner p-4">
          <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
            <div className="flex items-center gap-2"><Clock size={14} className="text-[#f472b6]" /><span className="text-xs font-bold text-[#f472b6]">Scenes ({scenes.length})</span></div>
            <ImportExportBar onExportCSV={doExportScenes} accent="#f472b6" disabled={!scenes.length} />
          </div>
          {loading ? <div className="flex justify-center py-4"><Loader2 className="animate-spin text-[#484f58]" size={16} /></div> : !scenes.length ? (
            <p className="text-[11px] text-[#8b949e] italic">No scenes. Import a script first to populate the one-liner and call sheet.</p>
          ) : (
            <div className="space-y-1 max-h-48 overflow-y-auto mb-3">
              {scenes.map((s, i) => (
                <div key={s.id} className="flex items-center gap-2 text-[10px] border border-[#30363d] rounded p-1.5">
                  <span className="text-[#f472b6] font-bold">{s.scene_number || i + 1}</span>
                  <span className="text-[#8b949e]">{s.int_ext}/{s.day_night}</span>
                  <span className="text-[#e6edf3] flex-1 truncate">{s.location_text || s.synopsis}</span>
                  <span className="text-[#484f58]">{s.pages}p</span>
                </div>
              ))}
            </div>
          )}
          <div className="flex gap-2">
            <button onClick={genOneLiner} disabled={!scenes.length} className="flex items-center gap-1.5 bg-[#f472b6]/20 border border-[#f472b6]/40 text-[#f472b6] px-3 py-1.5 rounded text-xs font-bold hover:bg-[#f472b6]/30 disabled:opacity-40"><Play size={12} /> One-Liner</button>
            <button onClick={genCallSheet} disabled={!scenes.length} className="flex items-center gap-1.5 bg-[#f472b6]/20 border border-[#f472b6]/40 text-[#f472b6] px-3 py-1.5 rounded text-xs font-bold hover:bg-[#f472b6]/30 disabled:opacity-40"><Play size={12} /> Call Sheet</button>
          </div>
        </div>
        <div className="glass-strong clip-corner p-4">
          <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-3">Call Sheet Location</div>
          <input value={loc.name} onChange={(e) => setLoc({ ...loc, name: e.target.value })} placeholder="Location name" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
          <input value={loc.address} onChange={(e) => setLoc({ ...loc, address: e.target.value })} placeholder="Address" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
          <input value={loc.nearest_hospital} onChange={(e) => setLoc({ ...loc, nearest_hospital: e.target.value })} placeholder="Nearest hospital" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
          <textarea value={loc.notes} onChange={(e) => setLoc({ ...loc, notes: e.target.value })} placeholder="General notes" rows={2} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] resize-none" />
        </div>
      </div>

      {(oneLiner || callSheet) && (
        <div className="glass-strong clip-corner p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-bold text-[#f472b6]">Generated Output</span>
            {oneLiner && <button onClick={() => { exportPDF('One-Liner', oneLiner, 'one_liner.pdf'); exportTXT(oneLiner.join('\n'), 'one_liner.txt'); }} className="flex items-center gap-1 text-[10px] text-[#3fb950] hover:underline"><Download size={10} /> Export</button>}
            {callSheet && <button onClick={() => { exportPDF('Call Sheet', callSheet, 'call_sheet.pdf'); exportTXT(callSheet, 'call_sheet.txt'); }} className="flex items-center gap-1 text-[10px] text-[#3fb950] hover:underline"><Download size={10} /> Export</button>}
          </div>
          <pre className="text-[10px] text-[#e6edf3] whitespace-pre-wrap bg-[#0B0F13] border border-[#30363d] rounded p-3 max-h-64 overflow-y-auto">{oneLiner?.join('\n') || callSheet}</pre>
        </div>
      )}
    </div>
  );
}