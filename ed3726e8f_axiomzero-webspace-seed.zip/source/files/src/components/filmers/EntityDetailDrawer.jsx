/**
 * EntityDetailDrawer — Shared right-side slide-over for viewing/editing a single entity.
 * Accepts a field schema and renders appropriate inputs (text, number, select, textarea, date).
 * Shows activity history for the entity and per-item export.
 */
import { useState, useEffect } from 'react';
import { X, Save, Trash2, Download, History, Loader2, Link2 } from 'lucide-react';
import { exportCSV } from '@/lib/filmers/filmExport';
import { base44 } from '@/api/base44Client';

const FIELD_DEFAULTS = {
  text: '',
  number: 0,
  textarea: '',
  select: '',
  date: '',
};

export default function EntityDetailDrawer({
  open,
  onClose,
  entity,
  entityName,
  fields,
  titleKey = 'name',
  titleFallback = 'Item',
  accent = '#fbbf24',
  onSave,
  onDelete,
  activityLog = [],
  exportRows,
  exportFilename = 'entity.csv',
  extraSections = [],
}) {
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [projects, setProjects] = useState([]);
  const [linkProjectId, setLinkProjectId] = useState('');
  const [linking, setLinking] = useState(false);

  useEffect(() => {
    if (entity && open) {
      const initial = {};
      fields.forEach((f) => {
        initial[f.key] = entity[f.key] ?? FIELD_DEFAULTS[f.type] ?? '';
      });
      setForm(initial);
    }
  }, [entity, open, fields]);

  useEffect(() => {
    if (open) {
      base44.entities.FilmProject.list('-created_date', 200).then(setProjects).catch(() => {});
    }
  }, [open]);

  if (!open || !entity) return null;

  const title = entity[titleKey] || titleFallback;

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSave(entity.id, form);
      onClose();
    } catch (e) {
      console.error('Save failed:', e);
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!confirm(`Delete "${title}"? This cannot be undone.`)) return;
    setDeleting(true);
    try {
      await onDelete(entity.id);
      onClose();
    } catch (e) {
      console.error('Delete failed:', e);
    }
    setDeleting(false);
  };

  const handleExport = () => {
    if (exportRows) {
      exportCSV(exportRows(entity), exportFilename);
    }
  };

  const handleLinkToProject = async () => {
    if (!linkProjectId || !entity?.id || !entityName) return;
    setLinking(true);
    try {
      await base44.entities[entityName].update(entity.id, { project_id: linkProjectId });
      if (onSave) await onSave(entity.id, { project_id: linkProjectId });
      onClose();
    } catch (e) { console.error('Link failed:', e); }
    setLinking(false);
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] transition-opacity"
        onClick={onClose}
      />

      {/* Drawer */}
      <div className="fixed right-0 top-0 bottom-0 w-full max-w-md z-[61] glass-strong border-l border-[#00f5ff]/20 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#30363d] shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-1 h-5 rounded-full shrink-0" style={{ background: accent }} />
            <div className="min-w-0">
              <div className="text-sm font-bold text-[#e6edf3] truncate">{title}</div>
              <div className="text-[9px] text-[#484f58] uppercase tracking-wider">{entityName}</div>
            </div>
          </div>
          <button onClick={onClose} className="text-[#484f58] hover:text-[#e6edf3] shrink-0 p-1">
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {fields.map((f) => (
            <div key={f.key}>
              <label className="text-[9px] text-[#8b949e] uppercase tracking-wider block mb-1">
                {f.label || f.key.replace(/_/g, ' ')}
                {f.required && <span className="text-[#fbbf24]"> *</span>}
              </label>
              {f.type === 'textarea' ? (
                <textarea
                  value={form[f.key] ?? ''}
                  onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                  rows={3}
                  className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] resize-none focus:border-[#00f5ff]/40 focus:outline-none"
                  placeholder={f.placeholder || ''}
                />
              ) : f.type === 'select' ? (
                <select
                  value={form[f.key] ?? ''}
                  onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                  className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] focus:border-[#00f5ff]/40 focus:outline-none"
                >
                  {f.options.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              ) : (
                <input
                  type={f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'}
                  value={form[f.key] ?? ''}
                  onChange={(e) => setForm({ ...form, [f.key]: f.type === 'number' ? (+e.target.value || 0) : e.target.value })}
                  className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] focus:border-[#00f5ff]/40 focus:outline-none"
                  placeholder={f.placeholder || ''}
                />
              )}
            </div>
          ))}

          {/* Extra sections (e.g., department-specific metadata) */}
          {extraSections.map((section) => (
            <div key={section.title} className="pt-3 border-t border-[#30363d]">
              <div className="text-[9px] font-bold uppercase tracking-wider mb-2" style={{ color: section.accent || accent }}>{section.title}</div>
              {section.fields.map((f) => (
                <div key={f.key} className="mb-2">
                  <label className="text-[9px] text-[#8b949e] uppercase tracking-wider block mb-1">
                    {f.label || f.key.replace(/_/g, ' ')}
                    {f.required && <span className="text-[#fbbf24]"> *</span>}
                  </label>
                  {f.type === 'textarea' ? (
                    <textarea
                      value={form[f.key] ?? ''}
                      onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                      rows={2}
                      className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] resize-none focus:border-[#00f5ff]/40 focus:outline-none"
                      placeholder={f.placeholder || ''}
                    />
                  ) : f.type === 'select' ? (
                    <select
                      value={form[f.key] ?? ''}
                      onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                      className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] focus:border-[#00f5ff]/40 focus:outline-none"
                    >
                      {(f.options || ['']).map((opt) => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type={f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'}
                      value={form[f.key] ?? ''}
                      onChange={(e) => setForm({ ...form, [f.key]: f.type === 'number' ? (+e.target.value || 0) : e.target.value })}
                      className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] focus:border-[#00f5ff]/40 focus:outline-none"
                      placeholder={f.placeholder || ''}
                    />
                  )}
                </div>
              ))}
            </div>
          ))}

          {/* Link to Project (standalone records only) */}
          {projects.length > 0 && !entity.project_id && (
            <div className="pt-3 border-t border-[#30363d]">
              <div className="flex items-center gap-1.5 mb-2">
                <Link2 size={11} className="text-[#4dd0e1]" />
                <span className="text-[9px] font-bold uppercase tracking-wider text-[#4dd0e1]">Link to Project</span>
              </div>
              <div className="text-[9px] text-[#8b949e] mb-2">This is a standalone studio-pool record. Link it to a project to make it project-scoped.</div>
              <div className="flex items-center gap-2">
                <select value={linkProjectId} onChange={(e) => setLinkProjectId(e.target.value)} className="flex-1 bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] focus:border-[#4dd0e1]/40 focus:outline-none">
                  <option value="">Select project…</option>
                  {projects.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
                </select>
                <button onClick={handleLinkToProject} disabled={!linkProjectId || linking} className="flex items-center gap-1.5 px-3 py-2 rounded text-xs font-bold text-black disabled:opacity-40 transition-opacity" style={{ background: '#4dd0e1' }}>
                  {linking ? <Loader2 size={12} className="animate-spin" /> : <Link2 size={12} />} Link
                </button>
              </div>
            </div>
          )}

          {/* Activity history */}
          {activityLog.length > 0 && (
            <div className="pt-3 border-t border-[#30363d]">
              <div className="flex items-center gap-1.5 mb-2">
                <History size={11} className="text-[#484f58]" />
                <span className="text-[9px] text-[#484f58] uppercase tracking-wider">Activity History</span>
              </div>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {activityLog.slice(0, 20).map((a, i) => (
                  <div key={a.id || i} className="text-[9px] text-[#8b949e] border-l-2 border-[#30363d] pl-2 py-0.5">
                    <span className="font-bold" style={{ color: accent }}>{a.action}</span>
                    {a.details && <span className="text-[#484f58]"> · {a.details}</span>}
                    <span className="text-[#484f58] block text-[8px]">{a.created_date ? new Date(a.created_date).toLocaleString() : ''}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#30363d] flex items-center gap-2 shrink-0">
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-1.5 px-3 py-2 rounded text-xs font-bold text-black disabled:opacity-40 transition-opacity"
            style={{ background: accent }}
          >
            {saving ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />} Save
          </button>
          {exportRows && (
            <button
              onClick={handleExport}
              className="flex items-center gap-1.5 px-3 py-2 rounded text-xs font-bold border border-[#3fb950]/30 text-[#3fb950] bg-[#3fb950]/10 hover:bg-[#3fb950]/20 transition-colors"
            >
              <Download size={12} /> Export
            </button>
          )}
          <button
            onClick={handleDelete}
            disabled={deleting}
            className="flex items-center gap-1.5 px-3 py-2 rounded text-xs font-bold border border-[#f85149]/30 text-[#f85149] bg-[#f85149]/10 hover:bg-[#f85149]/20 transition-colors ml-auto disabled:opacity-40"
          >
            {deleting ? <Loader2 size={12} className="animate-spin" /> : <Trash2 size={12} />} Delete
          </button>
        </div>
      </div>
    </>
  );
}