/**
 * SceneNavigator — Left sidebar showing scene/element navigator.
 * Click a scene to jump to it in the editor.
 */
import { Film, MapPin, MessageSquare } from 'lucide-react';
import { parseSceneHeading } from '@/lib/filmers/fountainSerializer';

export default function SceneNavigator({ elements, onJumpToScene, activeSceneIndex }) {
  const scenes = elements.filter(el => el.type === 'scene');
  const characterCount = new Set(elements.filter(el => el.type === 'character').map(el => el.text.trim().toUpperCase())).size;

  if (scenes.length === 0) {
    return (
      <div className="glass-panel clip-corner p-3">
        <div className="flex items-center gap-1.5 mb-2">
          <Film size={12} className="text-[#a78bfa]" />
          <span className="text-[10px] font-bold text-[#a78bfa] uppercase tracking-wider">Navigator</span>
        </div>
        <p className="text-[10px] text-[#484f58] italic">No scenes yet. Start writing or import a script.</p>
      </div>
    );
  }

  return (
    <div className="glass-panel clip-corner p-3 max-h-[70vh] overflow-y-auto">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <Film size={12} className="text-[#a78bfa]" />
          <span className="text-[10px] font-bold text-[#a78bfa] uppercase tracking-wider">Scenes</span>
        </div>
        <span className="text-[9px] text-[#484f58]">{scenes.length} scenes · {characterCount} chars</span>
      </div>
      <div className="space-y-1">
        {scenes.map((el, i) => {
          const parsed = parseSceneHeading(el.text);
          const sceneIdx = el.scene_index;
          const sceneChars = [...new Set(
            elements.filter(e => e.scene_index === sceneIdx && e.type === 'character').map(e => e.text.trim().toUpperCase())
          )];
          const isActive = activeSceneIndex === sceneIdx;
          return (
            <button
              key={el.id || i}
              onClick={() => onJumpToScene(i)}
              className={`w-full text-left p-1.5 rounded border transition-colors ${isActive ? 'border-[#a78bfa]/50 bg-[#a78bfa]/10' : 'border-[#30363d] hover:border-[#a78bfa]/30'}`}
            >
              <div className="flex items-center gap-1.5">
                <span className="text-[9px] font-bold text-[#a78bfa] shrink-0">{parsed.scene_number || i + 1}</span>
                <span className="text-[8px] text-[#484f58] shrink-0">{parsed.int_ext}/{parsed.day_night}</span>
              </div>
              <div className="text-[10px] text-[#e6edf3] truncate flex items-center gap-1">
                <MapPin size={8} className="text-[#34d399] shrink-0" />
                {parsed.location_text || 'Untitled'}
              </div>
              {sceneChars.length > 0 && (
                <div className="text-[8px] text-[#8b949e] truncate flex items-center gap-1 mt-0.5">
                  <MessageSquare size={7} className="shrink-0" />
                  {sceneChars.slice(0, 4).join(', ')}{sceneChars.length > 4 ? ` +${sceneChars.length - 4}` : ''}
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}