/**
 * ScreenplayEditor — Trelby-inspired WYSIWYG screenplay editor.
 *
 * Element-based editing with Tab/Enter style switching, context-aware
 * defaults, auto-complete for character names and locations, and
 * Draft/Layout view modes.
 */
import { useState, useRef, useEffect, useCallback } from 'react';
import { Eye, Edit3, Plus, Download, FileText, Loader2 } from 'lucide-react';
import ElementLine from './ElementLine';
import SceneNavigator from './SceneNavigator';
import {
  genId, getDefaultType, cycleType, TYPE_LABELS, TYPE_COLORS,
  ELEMENT_TYPES, parseSceneHeading, elementsToFountain, fountainToElements,
} from '@/lib/filmers/fountainSerializer';
import { exportFountain, exportFormattedText, exportScreenplayPDF } from '@/lib/filmers/scriptExport';

export default function ScreenplayEditor({
  script, elements, onChange, castNames, locationNames, onSave, saving,
}) {
  const [viewMode, setViewMode] = useState(script?.view_mode || 'draft');
  const [activeIndex, setActiveIndex] = useState(-1);
  const [activeSceneIndex, setActiveSceneIndex] = useState(-1);
  const [autoFocusIndex, setAutoFocusIndex] = useState(-1);
  const [showExport, setShowExport] = useState(false);
  const containerRef = useRef(null);
  const lineRefs = useRef([]);

  // Update active scene when active element changes
  useEffect(() => {
    if (activeIndex >= 0 && elements[activeIndex]) {
      setActiveSceneIndex(elements[activeIndex].scene_index);
    }
  }, [activeIndex, elements]);

  const updateElement = useCallback((index, text) => {
    const next = elements.map((el, i) => i === index ? { ...el, text } : el);
    onChange(next);
  }, [elements, onChange]);

  const changeType = useCallback((index, newType) => {
    const next = elements.map((el, i) => i === index ? { ...el, type: newType } : el);
    onChange(next);
  }, [elements, onChange]);

  const handleTypeCycle = useCallback((index, backward = false) => {
    const currentType = elements[index]?.type || 'action';
    const newType = cycleType(currentType, backward);
    changeType(index, newType);
  }, [elements, changeType]);

  const insertElement = useCallback((index, newEl) => {
    const next = [...elements];
    next.splice(index + 1, 0, newEl);
    onChange(next);
    setAutoFocusIndex(index + 1);
  }, [elements, onChange]);

  const joinWithPrevious = useCallback((index) => {
    if (index === 0) return;
    const next = [...elements];
    const prev = next[index - 1];
    const curr = next[index];
    next[index - 1] = { ...prev, text: (prev.text + ' ' + curr.text).trim() };
    next.splice(index, 1);
    onChange(next);
    setAutoFocusIndex(index - 1);
  }, [elements, onChange]);

  const deleteElement = useCallback((index) => {
    if (elements.length <= 1) return;
    const next = elements.filter((_, i) => i !== index);
    onChange(next);
  }, [elements, onChange]);

  const handleKeyDown = useCallback((e, index) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      handleTypeCycle(index, e.shiftKey);
    } else if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      const currentType = elements[index]?.type || 'action';
      const defaultType = getDefaultType(currentType, elements[index]?.text || '');
      const currentScene = elements[index]?.scene_index ?? 0;
      const newEl = { id: genId(), type: defaultType, text: '', scene_index: currentScene };
      insertElement(index, newEl);
    } else if (e.key === 'Backspace') {
      const target = e.target;
      if (target.selectionStart === 0 && target.selectionEnd === 0 && index > 0) {
        e.preventDefault();
        joinWithPrevious(index);
      }
    } else if (e.key === 'Delete' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      deleteElement(index);
    }
  }, [elements, handleTypeCycle, insertElement, joinWithPrevious, deleteElement]);

  const addSceneAtEnd = () => {
    const lastScene = elements.filter(e => e.type === 'scene').length;
    const newEl = { id: genId(), type: 'scene', text: 'INT. LOCATION - DAY', scene_index: lastScene };
    onChange([...elements, newEl]);
    setAutoFocusIndex(elements.length);
  };

  const jumpToScene = (sceneNumber) => {
    const sceneElements = elements.filter(e => e.type === 'scene');
    const target = sceneElements[sceneNumber];
    if (!target) return;
    const targetIndex = elements.indexOf(target);
    setActiveIndex(targetIndex);
    setAutoFocusIndex(targetIndex);
    lineRefs.current[targetIndex]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  const handleExport = (format) => {
    const title = script?.title || 'Screenplay';
    const safeTitle = title.replace(/[^a-zA-Z0-9-_]/g, '_');
    if (format === 'fountain') exportFountain(elements, title, `${safeTitle}.fountain`);
    else if (format === 'pdf') exportScreenplayPDF(elements, title, `${safeTitle}.pdf`);
    else if (format === 'txt') exportFormattedText(elements, title, `${safeTitle}.txt`);
    setShowExport(false);
  };

  // Empty state — create first scene
  if (elements.length === 0) {
    return (
      <div className="glass-strong clip-corner p-8 text-center">
        <FileText size={32} className="text-[#a78bfa] mx-auto mb-3" />
        <h3 className="text-sm font-bold text-[#e6edf3] mb-1">Start Writing</h3>
        <p className="text-[10px] text-[#8b949e] mb-4">Create a new screenplay or import an existing one. The WYSIWYG editor uses Trelby-inspired element-based editing — Tab to switch styles, Enter for new elements.</p>
        <button onClick={addSceneAtEnd} className="px-4 py-2 bg-[#a78bfa] text-black rounded text-xs font-bold hover:opacity-80 flex items-center gap-1.5 mx-auto">
          <Plus size={12} /> New Screenplay
        </button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
      {/* Left: Scene Navigator */}
      <div className="lg:col-span-3 order-2 lg:order-1">
        <SceneNavigator
          elements={elements}
          onJumpToScene={jumpToScene}
          activeSceneIndex={activeSceneIndex}
        />
      </div>

      {/* Center: Editor */}
      <div className="lg:col-span-9 order-1 lg:order-2">
        <div className="glass-strong clip-corner p-3">
          {/* Toolbar */}
          <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setViewMode('draft')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border transition-colors ${viewMode === 'draft' ? 'bg-[#a78bfa] text-black border-transparent' : 'border-[#30363d] text-[#8b949e]'}`}
              >
                <Edit3 size={10} /> Draft
              </button>
              <button
                onClick={() => setViewMode('layout')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border transition-colors ${viewMode === 'layout' ? 'bg-[#a78bfa] text-black border-transparent' : 'border-[#30363d] text-[#8b949e]'}`}
              >
                <Eye size={10} /> Layout
              </button>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={onSave}
                disabled={saving}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#34d399] text-black hover:opacity-80 disabled:opacity-40"
              >
                {saving ? <Loader2 size={10} className="animate-spin" /> : <Plus size={10} />} Save
              </button>
              <div className="relative">
                <button
                  onClick={() => setShowExport(!showExport)}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] hover:border-[#a78bfa]/40"
                >
                  <Download size={10} /> Export
                </button>
                {showExport && (
                  <div className="absolute right-0 top-full mt-1 glass-strong clip-corner p-1 z-10 min-w-[120px]">
                    <button onClick={() => handleExport('fountain')} className="block w-full text-left px-2 py-1.5 text-[10px] text-[#e6edf3] hover:bg-[#a78bfa]/10 rounded">Fountain (.fountain)</button>
                    <button onClick={() => handleExport('pdf')} className="block w-full text-left px-2 py-1.5 text-[10px] text-[#e6edf3] hover:bg-[#a78bfa]/10 rounded">PDF (formatted)</button>
                    <button onClick={() => handleExport('txt')} className="block w-full text-left px-2 py-1.5 text-[10px] text-[#e6edf3] hover:bg-[#a78bfa]/10 rounded">Formatted Text (.txt)</button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Editor area */}
          <div ref={containerRef} className="space-y-0.5 max-h-[65vh] overflow-y-auto pr-1">
            {elements.map((el, i) => (
              <div key={el.id || i} ref={r => lineRefs.current[i] = r}>
                <ElementLine
                  element={el}
                  index={i}
                  isActive={activeIndex === i}
                  autoFocus={autoFocusIndex === i}
                  viewMode={viewMode}
                  castNames={castNames}
                  locationNames={locationNames}
                  onChange={updateElement}
                  onTypeChange={(idx) => handleTypeCycle(idx, false)}
                  onKeyDown={handleKeyDown}
                  onFocus={setActiveIndex}
                />
              </div>
            ))}
          </div>

          {/* Bottom bar */}
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#30363d]">
            <div className="text-[9px] text-[#484f58]">
              {elements.length} elements · {elements.filter(e => e.type === 'scene').length} scenes
            </div>
            <button onClick={addSceneAtEnd} className="flex items-center gap-1 px-2 py-1 rounded text-[9px] text-[#a78bfa] hover:bg-[#a78bfa]/10">
              <Plus size={9} /> Add Scene
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}