/**
 * TimeCardTab — Labor tracking with digital/manual entry + department-head approval.
 * Computes hours, OT, DT, meal penalties per union rules.
 * Shows compliance badges and rolls into payroll export.
 */
import { useState, useEffect, useCallback } from 'react';
import { Clock, Plus, Trash2, Loader2, Check, X, Download, AlertTriangle, CheckCircle2, DollarSign } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { computeHours, computePay, checkTurnaroundViolation, computeLaborSummary, generatePayrollRows, UNION_RULES } from '@/lib/filmers/laborEngine';
import { exportCSV } from '@/lib/filmers/filmExport';
import { logActivity } from '@/lib/filmers/activityLog';

const STATUS_COLORS = { pending: '#d29922', approved: '#3fb950', rejected: '#f85149' };

export default function TimeCardTab({ project }) {
  const [crew, setCrew] = useState([]);
  const [timeCards, setTimeCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [filterDept, setFilterDept] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [form, setForm] = useState({ crew_member_id: '', shoot_date: '', call_time: '07:00', wrap_time: '18:00', meal_start: '12:00', meal_end: '13:00', entry_mode: 'manual', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [c, tc] = await Promise.all([
        base44.entities.CrewMember.filter({ project_id: project.id }),
        base44.entities.TimeCard.filter({ project_id: project.id }, '-shoot_date', 500),
      ]);
      setCrew(c); setTimeCards(tc);
    } catch { /* best-effort */ }
    finally { setLoading(false); }
  }, [project.id]);

  useEffect(() => { load(); }, [load]);

  const addTimeCard = async () => {
    if (!form.crew_member_id || !form.shoot_date) return;
    const member = crew.find(c => c.id === form.crew_member_id);
    if (!member) return;
    const hours = computeHours(form.call_time, form.wrap_time, form.meal_start, form.meal_end, member.union_status);
    const pay = computePay(hours, member.day_rate || 0, member.union_status);
    const card = await base44.entities.TimeCard.create({
      project_id: project.id,
      crew_member_id: member.id,
      crew_name: member.name,
      department: member.department,
      shoot_date: form.shoot_date,
      call_time: form.call_time,
      wrap_time: form.wrap_time,
      meal_start: form.meal_start,
      meal_end: form.meal_end,
      regular_hours: hours.regularHours,
      ot_hours: hours.otHours,
      double_time_hours: hours.doubleTimeHours,
      meal_penalty_hours: hours.mealPenaltyHours,
      union_status: member.union_status,
      day_rate: member.day_rate || 0,
      total_pay: pay,
      entry_mode: form.entry_mode,
      status: 'pending',
      turnaround_violation: false,
      notes: form.notes,
    });
    setTimeCards([card, ...timeCards]);
    logActivity(project.id, 'timecard', member.name, 'created', `${form.shoot_date} · ${hours.regularHours + hours.otHours + hours.doubleTimeHours}h`);
    setForm({ crew_member_id: '', shoot_date: '', call_time: '07:00', wrap_time: '18:00', meal_start: '12:00', meal_end: '13:00', entry_mode: 'manual', notes: '' });
    setShowAdd(false);
  };

  const approveCard = async (id) => {
    const card = timeCards.find(tc => tc.id === id);
    if (!card) return;
    await base44.entities.TimeCard.update(id, { status: 'approved', approved_by: 'Production', approved_date: new Date().toISOString().split('T')[0] });
    setTimeCards(timeCards.map(tc => tc.id === id ? { ...tc, status: 'approved', approved_by: 'Production' } : tc));
    logActivity(project.id, 'timecard', card.crew_name, 'approved', card.shoot_date);
  };

  const rejectCard = async (id) => {
    const card = timeCards.find(tc => tc.id === id);
    if (!card) return;
    await base44.entities.TimeCard.update(id, { status: 'rejected' });
    setTimeCards(timeCards.map(tc => tc.id === id ? { ...tc, status: 'rejected' } : tc));
    logActivity(project.id, 'timecard', card.crew_name, 'rejected', card.shoot_date);
  };

  const deleteCard = async (id) => {
    await base44.entities.TimeCard.delete(id);
    setTimeCards(timeCards.filter(tc => tc.id !== id));
  };

  const filtered = timeCards.filter(tc => {
    const deptOk = filterDept === 'all' || tc.department === filterDept;
    const statusOk = filterStatus === 'all' || tc.status === filterStatus;
    return deptOk && statusOk;
  });

  const summary = computeLaborSummary(timeCards);
  const departments = [...new Set(crew.map(c => c.department))];

  const exportPayroll = () => {
    exportCSV(generatePayrollRows(filtered), 'payroll_export.csv');
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#f472b6]" size={18} /></div>;

  return (
    <div className="space-y-3">
      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
        <div className="glass-panel clip-corner p-2.5">
          <div className="text-[8px] text-[#484f58] uppercase">Approved</div>
          <div className="text-lg font-bold text-[#3fb950]">{summary.approvedCount}</div>
        </div>
        <div className="glass-panel clip-corner p-2.5">
          <div className="text-[8px] text-[#484f58] uppercase">Pending</div>
          <div className="text-lg font-bold text-[#d29922]">{summary.pendingCount}</div>
        </div>
        <div className="glass-panel clip-corner p-2.5">
          <div className="text-[8px] text-[#484f58] uppercase flex items-center gap-1"><DollarSign size={8} /> Labor Cost</div>
          <div className="text-lg font-bold text-[#e6edf3]">${summary.totalLaborCost.toLocaleString()}</div>
        </div>
        <div className="glass-panel clip-corner p-2.5">
          <div className="text-[8px] text-[#484f58] uppercase">OT Hours</div>
          <div className="text-lg font-bold text-[#fbbf24]">{summary.totalOTHours}h</div>
        </div>
        <div className="glass-panel clip-corner p-2.5">
          <div className="text-[8px] text-[#484f58] uppercase flex items-center gap-1"><AlertTriangle size={8} /> Turnaround Vio.</div>
          <div className="text-lg font-bold text-[#f85149]">{summary.turnaroundViolations}</div>
        </div>
      </div>

      {/* Header + filters */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Clock size={14} className="text-[#f472b6]" />
          <span className="text-xs font-bold text-[#f472b6]">Time Cards ({timeCards.length})</span>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <select value={filterDept} onChange={e => setFilterDept(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[10px] text-[#e6edf3]">
            <option value="all">All Depts</option>
            {departments.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[10px] text-[#e6edf3]">
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </select>
          <button onClick={exportPayroll} disabled={!filtered.length} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] disabled:opacity-40">
            <Download size={10} /> Payroll CSV
          </button>
          <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#f472b6] text-black">
            <Plus size={10} /> Add Time Card
          </button>
        </div>
      </div>

      {/* Add form */}
      {showAdd && (
        <div className="glass-panel clip-corner p-3 border-l-2 border-[#f472b6] space-y-2">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <select value={form.crew_member_id} onChange={e => setForm({ ...form, crew_member_id: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              <option value="">Select crew member...</option>
              {crew.map(c => <option key={c.id} value={c.id}>{c.name} ({c.department})</option>)}
            </select>
            <input type="date" value={form.shoot_date} onChange={e => setForm({ ...form, shoot_date: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="time" value={form.call_time} onChange={e => setForm({ ...form, call_time: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="time" value={form.wrap_time} onChange={e => setForm({ ...form, wrap_time: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="time" value={form.meal_start} onChange={e => setForm({ ...form, meal_start: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="time" value={form.meal_end} onChange={e => setForm({ ...form, meal_end: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <select value={form.entry_mode} onChange={e => setForm({ ...form, entry_mode: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              <option value="manual">Manual Entry</option>
              <option value="digital">Digital Clock-In</option>
            </select>
          </div>
          <input value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Notes" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          <div className="flex gap-2">
            <button onClick={addTimeCard} className="px-3 py-1.5 bg-[#f472b6] text-black rounded text-[10px] font-bold">Save Time Card</button>
            <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
          </div>
        </div>
      )}

      {/* Time card list */}
      {filtered.length === 0 ? (
        <div className="glass-panel clip-corner p-8 text-center">
          <Clock size={28} className="text-[#484f58] mx-auto mb-3" />
          <p className="text-xs text-[#8b949e]">No time cards yet. Add crew members first, then create time cards for each shoot day.</p>
        </div>
      ) : (
        <div className="space-y-1.5">
          {filtered.map(tc => {
            const totalHours = (tc.regular_hours || 0) + (tc.ot_hours || 0) + (tc.double_time_hours || 0);
            const hasOT = (tc.ot_hours || 0) > 0;
            const hasDT = (tc.double_time_hours || 0) > 0;
            return (
              <div key={tc.id} className="glass-panel clip-corner p-2.5 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold text-[#e6edf3]">{tc.crew_name}</span>
                    <span className="text-[8px] px-1.5 py-0.5 rounded border border-[#30363d] text-[#8b949e]">{tc.department}</span>
                    <span className="text-[8px] px-1.5 py-0.5 rounded" style={{ color: STATUS_COLORS[tc.status], background: STATUS_COLORS[tc.status] + '20' }}>{tc.status}</span>
                    <span className="text-[8px] text-[#484f58]">{tc.union_status}</span>
                    {tc.entry_mode === 'digital' && <span className="text-[8px] text-[#58a6ff]">digital</span>}
                  </div>
                  <div className="text-[9px] text-[#8b949e] mt-0.5 flex items-center gap-2 flex-wrap">
                    <span>{tc.shoot_date}</span>
                    <span>{tc.call_time} → {tc.wrap_time}</span>
                    <span className="text-[#e6edf3] font-bold">{totalHours}h</span>
                    {hasOT && <span className="text-[#fbbf24]">OT: {tc.ot_hours}h</span>}
                    {hasDT && <span className="text-[#f85149]">DT: {tc.double_time_hours}h</span>}
                    {(tc.meal_penalty_hours || 0) > 0 && <span className="text-[#d29922]">Meal penalty: {tc.meal_penalty_hours}h</span>}
                    <span className="text-[#3fb950]">${(tc.total_pay || 0).toLocaleString()}</span>
                  </div>
                </div>
                {tc.status === 'pending' && (
                  <div className="flex items-center gap-1">
                    <button onClick={() => approveCard(tc.id)} className="text-[#3fb950] hover:opacity-70" title="Approve"><CheckCircle2 size={14} /></button>
                    <button onClick={() => rejectCard(tc.id)} className="text-[#f85149] hover:opacity-70" title="Reject"><X size={14} /></button>
                  </div>
                )}
                {tc.status === 'rejected' && (
                  <button onClick={() => approveCard(tc.id)} className="text-[#3fb950] hover:opacity-70" title="Re-approve"><CheckCircle2 size={14} /></button>
                )}
                {tc.status === 'approved' && <Check size={14} className="text-[#3fb950]" />}
                <button onClick={() => deleteCard(tc.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={11} /></button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}