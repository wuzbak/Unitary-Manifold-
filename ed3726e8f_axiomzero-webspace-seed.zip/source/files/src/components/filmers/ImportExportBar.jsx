/**
 * ImportExportBar — Shared import/export button group for consistent per-tab I/O.
 * Props:
 *  - onImportCSV: function(file) — receives the uploaded CSV file
 *  - onExportCSV: function() — triggers CSV export
 *  - onExportJSON: function() (optional) — triggers JSON export
 *  - onImportJSON: function(file) (optional) — receives uploaded JSON file
 *  - exportLabel: string (default 'CSV')
 *  - accent: string (hex color)
 *  - disabled: boolean
 */
import { Upload, Download, FileJson, Loader2 } from 'lucide-react';
import { useRef, useState } from 'react';

export default function ImportExportBar({
  onImportCSV,
  onExportCSV,
  onExportJSON,
  onImportJSON,
  accent = '#fbbf24',
  disabled = false,
  exportDisabled = false,
  importLabel = 'Import CSV',
  exportLabel = 'Export CSV',
}) {
  const csvInputRef = useRef(null);
  const jsonInputRef = useRef(null);
  const [busy, setBusy] = useState(false);

  const handleCSVImport = async (file) => {
    if (!file || !onImportCSV) return;
    setBusy(true);
    try { await onImportCSV(file); } catch (e) { console.error('Import failed:', e); }
    setBusy(false);
    if (csvInputRef.current) csvInputRef.current.value = '';
  };

  const handleJSONImport = async (file) => {
    if (!file || !onImportJSON) return;
    setBusy(true);
    try { await onImportJSON(file); } catch (e) { console.error('Import failed:', e); }
    setBusy(false);
    if (jsonInputRef.current) jsonInputRef.current.value = '';
  };

  return (
    <div className="flex items-center gap-1.5 flex-wrap">
      {onImportCSV && (
        <label className={`flex items-center gap-1 px-2 py-1 bg-[#161b22] border border-[#30363d] rounded text-[9px] cursor-pointer transition-colors hover:border-[${accent}]/40 ${disabled ? 'opacity-40 pointer-events-none' : ''}`}>
          {busy ? <Loader2 size={10} className="animate-spin" /> : <Upload size={10} />}
          <span className="text-[#8b949e]">{importLabel}</span>
          <input ref={csvInputRef} type="file" accept=".csv" className="hidden" onChange={(e) => handleCSVImport(e.target.files?.[0])} />
        </label>
      )}
      {onExportCSV && (
        <button onClick={onExportCSV} disabled={disabled || exportDisabled} className="flex items-center gap-1 px-2 py-1 bg-[#161b22] border border-[#30363d] rounded text-[9px] text-[#3fb950] hover:border-[#3fb950]/40 disabled:opacity-40 transition-colors">
          <Download size={10} /> {exportLabel}
        </button>
      )}
      {onExportJSON && (
        <button onClick={onExportJSON} disabled={disabled || exportDisabled} className="flex items-center gap-1 px-2 py-1 bg-[#161b22] border border-[#30363d] rounded text-[9px] text-[#a78bfa] hover:border-[#a78bfa]/40 disabled:opacity-40 transition-colors">
          <FileJson size={10} /> JSON
        </button>
      )}
      {onImportJSON && (
        <label className={`flex items-center gap-1 px-2 py-1 bg-[#161b22] border border-[#30363d] rounded text-[9px] cursor-pointer transition-colors hover:border-[#a78bfa]/40 ${disabled ? 'opacity-40 pointer-events-none' : ''}`}>
          <Upload size={10} />
          <span className="text-[#a78bfa]">Import JSON</span>
          <input ref={jsonInputRef} type="file" accept=".json" className="hidden" onChange={(e) => handleJSONImport(e.target.files?.[0])} />
        </label>
      )}
    </div>
  );
}