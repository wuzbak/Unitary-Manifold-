/**
 * UPOverviewTab — Combined UPM (Unit Production Manager) overview.
 * Aggregates spend across ALL departments (DepartmentItem + WardrobeItem +
 * CameraItem) and groups it by SET (assigned scene) or by LOCATION, showing
 * per-group totals, budget-vs-actual, rental exposure, and a combined CSV export.
 */
import { useState, useEffect, useCallback } from 'react';
import { ClipboardList, Loader2, MapPin, Film, Download, Repeat, DollarSign } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { exportCSV } from '@/lib/filmers/filmExport';
import ImportExportBar from './ImportExportBar';

const STATUS_COLORS = {
  Development: '#8b949e',
  'Pre-production': '#fbbf24',
  Production: '#3fb950',
  'Post-production': '#60a5fa',
  Wrapped: '#a78bfa',
};

function itemCost(i) {
  return (i.unit_cost || 0) * (i.quantity || 1);
}

function rentalExposure(i) {
  if (i.rental_type !== 'rental') return 0;
  return (i.rental_daily_rate || 0) * (i.quantity || 1);
}

export default function UPOverviewTab({ project }) {
  const [grouping, setGrouping] = useState('set'); // 'set' | 'location'
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!project) { setLoading(false); return; }
    setLoading(true);
    try {
      const [deptItems, wardrobeItems, cameraItems, scenes] = await Promise.all([
        base44.entities.DepartmentItem.filter({ project_id: project.id }),
        base44.entities.WardrobeItem.filter({ project_id: project.id }),
        base44.entities.CameraItem.filter({ project_id: project.id }),
        base44.entities.Scene.filter({ project_id: project.id }, 'sort_order', 500),
      ]);
      setData({ deptItems, wardrobeItems, cameraItems, scenes });
    } catch (e) {
      console.error('UPM overview load failed:', e);
    }
    setLoading(false);
  }, [project?.id]);

  useEffect(() => { load(); }, [load]);

  if (!project) return (
    <div className="glass-panel clip-corner p-8 text-center">
      <ClipboardList size={28} className="text-[#484f58] mx-auto mb-3" />
      <p className="text-xs text-[#8b949e]">Select a project to view the UPM overview.</p>
    </div>
  );

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#4dd0e1]" size={20} /></div>;

  const d = data || { deptItems: [], wardrobeItems: [], cameraItems: [], scenes: [] };
  const sceneMap = {};
  d.scenes.forEach((s) => { sceneMap[s.id] = s; });

  // Combine all items with a source tag
  const allItems = [
    ...d.deptItems.map((i) => ({ ...i, _source: 'DepartmentItem' })),
    ...d.wardrobeItems.map((i) => ({ ...i, _source: 'WardrobeItem' })),
    ...d.cameraItems.map((i) => ({ ...i, _source: 'CameraItem' })),
  ];

  // Group key resolver
  const groupKey = (item) => {
    const scene = item.assigned_scene_id ? sceneMap[item.assigned_scene_id] : null;
    if (grouping === 'location') {
      return scene?.location_text || 'Unassigned';
    }
    // set grouping
    if (!item.assigned_scene_id) return 'Unassigned';
    return scene ? `Scene ${scene.scene_number || item.assigned_scene_id.slice(-4)}` : `Scene ${item.assigned_scene_id.slice(-4)}`;
  };

  // Aggregate by group
  const groups = {};
  allItems.forEach((item) => {
    const key = groupKey(item);
    if (!groups[key]) groups[key] = { key, items: [], spent: 0, rentalExposure: 0, rentalCount: 0, byDept: {} };
    const cost = itemCost(item);
    groups[key].items.push(item);
    groups[key].spent += cost;
    const re = rentalExposure(item);
    if (re > 0) {
      groups[key].rentalExposure += re;
      groups[key].rentalCount += 1;
    }
    const dept = item.department || item._source;
    groups[key].byDept[dept] = (groups[key].byDept[dept] || 0) + cost;
  });

  const groupRows = Object.values(groups).sort((a, b) => b.spent - a.spent);
  const totalSpent = groupRows.reduce((s, g) => s + g.spent, 0);
  const totalRentalExposure = groupRows.reduce((s, g) => s + g.rentalExposure, 0);
  const totalRentalCount = groupRows.reduce((s, g) => s + g.rentalCount, 0);
  const budget = project.total_budget || 0;
  const budgetPct = budget > 0 ? Math.round((totalSpent / budget) * 100) : 0;
  const overBudget = budget > 0 && totalSpent > budget;

  const handleExport = () => {
    const rows = groupRows.map((g) => ({
      group: g.key,
      item_count: g.items.length,
      total_spent: g.spent.toFixed(2),
      rental_items: g.rentalCount,
      rental_daily_exposure: g.rentalExposure.toFixed(2),
      ...Object.fromEntries(Object.entries(g.byDept).map(([k, v]) => [k, v.toFixed(2)])),
    }));
    exportCSV(rows, `upm_overview_by_${grouping}.csv`);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="glass-strong clip-corner p-4 flex items-center justify-between gap-2 flex-wrap border-l-2 border-[#4dd0e1]">
        <div className="flex items-center gap-2">
          <ClipboardList size={16} className="text-[#4dd0e1]" />
          <div>
            <span className="text-sm font-bold text-[#4dd0e1]">UPM Overview</span>
            <span className="text-[10px] text-[#484f58] ml-2">Aggregated spend across all departments · {project.title}</span>
          </div>
        </div>
        {/* Grouping toggle */}
        <div className="flex items-center gap-1 glass-panel clip-corner p-1">
          <button
            onClick={() => setGrouping('set')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded text-[10px] font-bold transition-all ${grouping === 'set' ? 'text-black bg-[#4dd0e1]' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
          >
            <Film size={11} /> By Set
          </button>
          <button
            onClick={() => setGrouping('location')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded text-[10px] font-bold transition-all ${grouping === 'location' ? 'text-black bg-[#58a6ff]' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
          >
            <MapPin size={11} /> By Location
          </button>
        </div>
      </div>

      {/* Totals strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="glass-panel clip-corner p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <DollarSign size={11} className={overBudget ? 'text-[#f85149]' : 'text-[#3fb950]'} />
            <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Total Spent</span>
          </div>
          <div className="text-lg font-bold" style={{ color: overBudget ? '#f85149' : '#3fb950' }}>${totalSpent.toLocaleString()}</div>
          {budget > 0 && <div className="text-[9px] text-[#484f58]">of ${budget.toLocaleString()} · {budgetPct}%</div>}
        </div>
        <div className="glass-panel clip-corner p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <Repeat size={11} className="text-[#fbbf24]" />
            <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Rental Exposure</span>
          </div>
          <div className="text-lg font-bold text-[#fbbf24]">${totalRentalExposure.toLocaleString()}<span className="text-[10px] text-[#484f58]">/day</span></div>
          <div className="text-[9px] text-[#484f58]">{totalRentalCount} rental item{totalRentalCount !== 1 ? 's' : ''}</div>
        </div>
        <div className="glass-panel clip-corner p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <ClipboardList size={11} className="text-[#4dd0e1]" />
            <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Total Items</span>
          </div>
          <div className="text-lg font-bold text-[#4dd0e1]">{allItems.length}</div>
          <div className="text-[9px] text-[#484f58]">{groupRows.length} group{groupRows.length !== 1 ? 's' : ''}</div>
        </div>
        <div className="glass-panel clip-corner p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <Film size={11} className="text-[#a78bfa]" />
            <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Project Status</span>
          </div>
          <div className="text-sm font-bold" style={{ color: STATUS_COLORS[project.status] || '#8b949e' }}>{project.status}</div>
          <div className="text-[9px] text-[#484f58]">{project.shoot_days || 0} shoot days</div>
        </div>
      </div>

      {/* Export bar */}
      <div className="flex items-center justify-end">
        <ImportExportBar onExportCSV={handleExport} accent="#4dd0e1" exportDisabled={!groupRows.length} exportLabel="Export UPM Report" />
      </div>

      {/* Group table */}
      {!groupRows.length ? (
        <div className="text-center py-8 text-[10px] text-[#484f58] italic">No items tracked yet. Add inventory in the department tabs to populate the UPM overview.</div>
      ) : (
        <div className="glass-strong clip-corner overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-[10px]">
              <thead>
                <tr className="border-b border-[#30363d] text-[#8b949e]">
                  <th className="text-left px-3 py-2 font-bold uppercase tracking-wider">{grouping === 'set' ? 'Set' : 'Location'}</th>
                  <th className="text-right px-3 py-2 font-bold uppercase tracking-wider">Items</th>
                  <th className="text-right px-3 py-2 font-bold uppercase tracking-wider">Spent</th>
                  <th className="text-right px-3 py-2 font-bold uppercase tracking-wider">Rentals</th>
                  <th className="text-right px-3 py-2 font-bold uppercase tracking-wider">Rental/Day</th>
                  <th className="text-left px-3 py-2 font-bold uppercase tracking-wider">Department Breakdown</th>
                </tr>
              </thead>
              <tbody>
                {groupRows.map((g) => (
                  <tr key={g.key} className="border-b border-[#30363d]/50 hover:bg-[#00f5ff]/5 transition-colors">
                    <td className="px-3 py-2 font-bold text-[#e6edf3]">{g.key}</td>
                    <td className="px-3 py-2 text-right text-[#8b949e]">{g.items.length}</td>
                    <td className="px-3 py-2 text-right font-bold text-[#3fb950]">${g.spent.toLocaleString()}</td>
                    <td className="px-3 py-2 text-right text-[#fbbf24]">{g.rentalCount || '—'}</td>
                    <td className="px-3 py-2 text-right text-[#fbbf24]">{g.rentalExposure > 0 ? `$${g.rentalExposure.toLocaleString()}` : '—'}</td>
                    <td className="px-3 py-2 text-[9px] text-[#8b949e]">
                      {Object.entries(g.byDept).sort((a, b) => b[1] - a[1]).map(([dept, val]) => (
                        <span key={dept} className="inline-block mr-2">
                          <span className="text-[#484f58]">{dept}:</span> <span className="text-[#e6edf3]">${val.toLocaleString()}</span>
                        </span>
                      ))}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-[#4dd0e1]/30 bg-[#0d1117]">
                  <td className="px-3 py-2 font-bold text-[#4dd0e1]">TOTAL</td>
                  <td className="px-3 py-2 text-right font-bold text-[#e6edf3]">{allItems.length}</td>
                  <td className="px-3 py-2 text-right font-bold text-[#3fb950]">${totalSpent.toLocaleString()}</td>
                  <td className="px-3 py-2 text-right font-bold text-[#fbbf24]">{totalRentalCount}</td>
                  <td className="px-3 py-2 text-right font-bold text-[#fbbf24]">${totalRentalExposure.toLocaleString()}</td>
                  <td className="px-3 py-2"></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}