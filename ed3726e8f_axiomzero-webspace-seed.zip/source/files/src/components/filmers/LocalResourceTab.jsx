/**
 * LocalResourceTab — Directory of local vendors, rental houses, hospitals,
 * catering, and support services. Linkable to DepartmentItem vendors and permits.
 */
import { useState, useEffect, useCallback } from 'react';
import { Building2, Plus, Trash2, Loader2, Download, Phone, Mail, MapPin, Star } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { exportCSV } from '@/lib/filmers/filmExport';
import { logActivity } from '@/lib/filmers/activityLog';
import DualEntryToggle, { resolveProjectId } from './DualEntryToggle';

const CATEGORIES = ['rental_house', 'camera_rental', 'grip_lighting', 'sound', 'wardrobe', 'props', 'catering', 'craft_service', 'transportation', 'hardware_store', 'hospital', 'hotel', 'parking', 'post_production', 'vfx', 'other'];
const CATEGORY_ICONS = { rental_house: Building2, hospital: Building2, hotel: Building2, hardware_store: Building2, catering: Building2, other: Building2 };

export default function LocalResourceTab({ project }) {
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [filterCat, setFilterCat] = useState('all');
  const [entryMode, setEntryMode] = useState('project');
  const [form, setForm] = useState({ name: '', category: 'other', contact_name: '', phone: '', email: '', address: '', distance_miles: 0, rates: '', hours: '', website: '', rating: 0, project_history: '', notes: '' });

  const load = useCallback(async () => {
    setLoading(true);
    try { setResources(await base44.entities.LocalResource.filter({ project_id: project.id })); }
    catch { /* best-effort */ }
    finally { setLoading(false); }
  }, [project.id]);

  useEffect(() => { load(); }, [load]);

  const addResource = async () => {
    if (!form.name.trim()) return;
    const pid = resolveProjectId(entryMode, project);
    const resource = await base44.entities.LocalResource.create({
      ...form, project_id: pid, distance_miles: Number(form.distance_miles) || 0, rating: Number(form.rating) || 0,
    });
    setResources([resource, ...resources]);
    logActivity(project.id, 'resource', form.name, 'created', form.category);
    setForm({ name: '', category: 'other', contact_name: '', phone: '', email: '', address: '', distance_miles: 0, rates: '', hours: '', website: '', rating: 0, project_history: '', notes: '' });
    setShowAdd(false);
  };

  const deleteResource = async (id) => {
    await base44.entities.LocalResource.delete(id);
    setResources(resources.filter(r => r.id !== id));
  };

  const exportResources = () => {
    exportCSV(resources.map(r => ({
      name: r.name, category: r.category, contact: r.contact_name, phone: r.phone, email: r.email,
      address: r.address, distance: r.distance_miles, rates: r.rates, hours: r.hours, website: r.website,
      rating: r.rating, notes: r.notes,
    })), 'local_resources.csv');
  };

  const filtered = filterCat === 'all' ? resources : resources.filter(r => r.category === filterCat);

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#4dd0e1]" size={18} /></div>;

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Building2 size={14} className="text-[#4dd0e1]" />
          <span className="text-xs font-bold text-[#4dd0e1]">Local Resources</span>
          <span className="text-[9px] text-[#484f58]">{resources.length} resources</span>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <select value={filterCat} onChange={e => setFilterCat(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
            <option value="all">All Categories</option>
            {CATEGORIES.map(c => <option key={c} value={c}>{c.replace(/_/g, ' ')}</option>)}
          </select>
          <button onClick={exportResources} disabled={!resources.length} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] disabled:opacity-40">
            <Download size={10} /> CSV
          </button>
          <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#4dd0e1] text-black">
            <Plus size={10} /> Add Resource
          </button>
        </div>
      </div>

      {/* Add form */}
      {showAdd && (
        <div className="glass-panel clip-corner p-3 border-l-2 border-[#4dd0e1] space-y-2">
          <DualEntryToggle mode={entryMode} onChange={setEntryMode} projectName={project?.title} />
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Resource name *" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
              {CATEGORIES.map(c => <option key={c} value={c}>{c.replace(/_/g, ' ')}</option>)}
            </select>
            <input value={form.contact_name} onChange={e => setForm({ ...form, contact_name: e.target.value })} placeholder="Contact name" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="Phone" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="Email" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="Address" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="number" value={form.distance_miles} onChange={e => setForm({ ...form, distance_miles: +e.target.value })} placeholder="Distance (mi)" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.rates} onChange={e => setForm({ ...form, rates: e.target.value })} placeholder="Rates" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.hours} onChange={e => setForm({ ...form, hours: e.target.value })} placeholder="Hours" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input value={form.website} onChange={e => setForm({ ...form, website: e.target.value })} placeholder="Website" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
            <input type="number" value={form.rating} onChange={e => setForm({ ...form, rating: +e.target.value })} placeholder="Rating (1-5)" min="0" max="5" className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          </div>
          <input value={form.project_history} onChange={e => setForm({ ...form, project_history: e.target.value })} placeholder="Project history (past productions, notes)" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          <input value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Notes" className="w-full bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]" />
          <div className="flex gap-2">
            <button onClick={addResource} className="px-3 py-1.5 bg-[#4dd0e1] text-black rounded text-[10px] font-bold">Save Resource</button>
            <button onClick={() => setShowAdd(false)} className="px-3 py-1.5 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
          </div>
        </div>
      )}

      {/* Resource list */}
      {filtered.length === 0 ? (
        <div className="glass-panel clip-corner p-8 text-center">
          <Building2 size={28} className="text-[#484f58] mx-auto mb-3" />
          <p className="text-xs text-[#8b949e]">No local resources yet. Add rental houses, hospitals, catering, hardware stores, and other support services.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {filtered.map(r => (
            <div key={r.id} className="glass-panel clip-corner p-3 group">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold text-[#e6edf3]">{r.name}</span>
                    <span className="text-[8px] px-1.5 py-0.5 rounded border border-[#4dd0e1]/30 text-[#4dd0e1]">{r.category.replace(/_/g, ' ')}</span>
                    {r.rating > 0 && <span className="flex items-center gap-0.5 text-[8px] text-[#fbbf24]"><Star size={8} className="fill-[#fbbf24]" /> {r.rating}</span>}
                  </div>
                  <div className="text-[9px] text-[#8b949e] mt-1 space-y-0.5">
                    {r.contact_name && <div>{r.contact_name}</div>}
                    {r.phone && <div className="flex items-center gap-1"><Phone size={8} /> {r.phone}</div>}
                    {r.email && <div className="flex items-center gap-1"><Mail size={8} /> {r.email}</div>}
                    {r.address && <div className="flex items-center gap-1"><MapPin size={8} /> {r.address}</div>}
                    {r.distance_miles > 0 && <div className="text-[#58a6ff]">{r.distance_miles} mi from base</div>}
                    {r.rates && <div className="text-[#3fb950]">{r.rates}</div>}
                    {r.hours && <div>{r.hours}</div>}
                    {r.website && <a href={r.website} target="_blank" rel="noopener noreferrer" className="text-[#4dd0e1] hover:underline">{r.website}</a>}
                    {r.project_history && <div className="text-[#484f58] italic mt-1">{r.project_history}</div>}
                    {r.notes && <div className="text-[#484f58]">{r.notes}</div>}
                  </div>
                </div>
                <button onClick={() => deleteResource(r.id)} className="text-[#484f58] hover:text-[#f85149] shrink-0"><Trash2 size={11} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}