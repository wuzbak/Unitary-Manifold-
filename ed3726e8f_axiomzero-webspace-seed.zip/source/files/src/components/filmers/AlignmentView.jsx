/**
 * AlignmentView — Studio-pool alignment screen for bulk-assigning standalone
 * records to a project, with smart-match suggestions.
 */
import { useState, useEffect, useCallback } from 'react';
import { Loader2, Link2, Sparkles, Check, X, Zap } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { extractProjectSignals, matchStandaloneToProject } from '@/lib/filmers/alignmentMatcher';

const ENTITY_LABELS = {
  DepartmentItem: 'Inventory', CastMember: 'Cast', CrewMember: 'Crew',
  Location: 'Location', StoryFragment: 'Story Fragment',
};

export default function AlignmentView({ projects }) {
  const [standalone, setStandalone] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(new Set());
  const [targetProject, setTargetProject] = useState('');
  const [assigning, setAssigning] = useState(false);
  const [matches, setMatches] = useState([]);
  const [matching, setMatching] = useState(false);
  const [filterType, setFilterType] = useState('all');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [items, cast, crew, locs, frags] = await Promise.all([
        base44.entities.DepartmentItem.list('-created_date', 500).then((a) => a.filter((r) => !r.project_id).map((r) => ({ ...r, _type: 'DepartmentItem' }))),
        base44.entities.CastMember.list('-created_date', 500).then((a) => a.filter((r) => !r.project_id).map((r) => ({ ...r, _type: 'CastMember' }))),
        base44.entities.CrewMember.list('-created_date', 500).then((a) => a.filter((r) => !r.project_id).map((r) => ({ ...r, _type: 'CrewMember' }))),
        base44.entities.Location.list('-created_date', 500).then((a) => a.filter((r) => !r.project_id).map((r) => ({ ...r, _type: 'Location' }))),
        base44.entities.StoryFragment.list('-created_date', 500).then((a) => a.filter((r) => !r.project_id).map((r) => ({ ...r, _type: 'StoryFragment' }))),
      ]);
      setStandalone([...items, ...cast, ...crew, ...locs, ...frags]);
    } catch { /* ignore */ }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = filterType === 'all' ? standalone : standalone.filter((r) => r._type === filterType);

  const toggleSelect = (id) => {
    setSelected((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };

  const selectAll = () => {
    setSelected(new Set(filtered.map((r) => r.id)));
  };

  const bulkAssign = async () => {
    if (!targetProject || selected.size === 0) return;
    setAssigning(true);
    try {
      const updates = [];
      for (const r of standalone) {
        if (selected.has(r.id)) {
          await base44.entities[r._type].update(r.id, { project_id: targetProject });
          updates.push(r.id);
        }
      }
      setSelected(new Set());
      setTargetProject('');
      await load();
    } catch { /* ignore */ }
    setAssigning(false);
  };

  const runSmartMatch = async () => {
    if (!targetProject) { alert('Select a target project first.'); return; }
    setMatching(true);
    try {
      const project = projects.find((p) => p.id === targetProject);
      if (!project) return;
      const [scenes, cast, locs] = await Promise.all([
        base44.entities.Scene.filter({ project_id: project.id }),
        base44.entities.CastMember.filter({ project_id: project.id }),
        base44.entities.Location.filter({ project_id: project.id }),
      ]);
      const signals = extractProjectSignals(project, scenes, cast, locs);
      const results = matchStandaloneToProject(standalone, signals);
      setMatches(results);
    } catch { /* ignore */ }
    setMatching(false);
  };

  const approveMatch = async (m) => {
    try {
      await base44.entities[m.record._type].update(m.record.id, { project_id: targetProject });
      setMatches((prev) => prev.filter((r) => r.record.id !== m.record.id));
      await load();
    } catch { /* ignore */ }
  };

  const dismissMatch = (m) => {
    setMatches((prev) => prev.filter((r) => r.record.id !== m.record.id));
  };

  const recordTitle = (r) => r.item_name || r.name || r.title || 'Untitled';
  const recordTypeLabel = (r) => ENTITY_LABELS[r._type] || r._type;

  return (
    <div className="space-y-3">
      {/* Controls */}
      <div className="glass-panel clip-corner p-3 space-y-2 border-l-2 border-[#4dd0e1]">
        <div className="flex items-center gap-2 flex-wrap">
          <Link2 size={13} className="text-[#4dd0e1]" />
          <span className="text-[10px] font-bold text-[#4dd0e1]">Align Studio Pool to Project</span>
          <span className="text-[9px] text-[#484f58]">{standalone.length} standalone records</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <select value={targetProject} onChange={(e) => { setTargetProject(e.target.value); setMatches([]); }} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] min-w-[180px]">
            <option value="">Select target project…</option>
            {projects.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
          </select>
          <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]">
            <option value="all">All Types</option>
            {Object.entries(ENTITY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <button onClick={selectAll} disabled={!filtered.length} className="px-2.5 py-1.5 rounded text-[9px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] disabled:opacity-40">Select All</button>
          <button onClick={bulkAssign} disabled={!targetProject || selected.size === 0 || assigning} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[9px] font-bold bg-[#4dd0e1] text-black hover:opacity-80 disabled:opacity-40">
            {assigning ? <Loader2 size={10} className="animate-spin" /> : <Link2 size={10} />} Assign {selected.size > 0 ? `(${selected.size})` : ''}
          </button>
          <button onClick={runSmartMatch} disabled={!targetProject || matching} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[9px] font-bold border border-[#a78bfa]/30 text-[#a78bfa] bg-[#a78bfa]/10 hover:bg-[#a78bfa]/20 disabled:opacity-40">
            {matching ? <Loader2 size={10} className="animate-spin" /> : <Sparkles size={10} />} Smart Match
          </button>
        </div>
      </div>

      {/* Smart match results */}
      {matches.length > 0 && (
        <div className="glass-panel clip-corner p-3 space-y-1.5 border-l-2 border-[#a78bfa]">
          <div className="flex items-center gap-2 mb-1">
            <Sparkles size={12} className="text-[#a78bfa]" />
            <span className="text-[10px] font-bold text-[#a78bfa]">Smart Matches ({matches.length})</span>
          </div>
          {matches.map((m, i) => (
            <div key={i} className="flex items-center gap-2 p-2 rounded border border-[#30363d]">
              <div className="flex-1 min-w-0">
                <span className="text-[10px] font-bold text-[#e6edf3]">{recordTitle(m.record)}</span>
                <span className="text-[8px] text-[#484f58] ml-1.5">{recordTypeLabel(m.record)}</span>
                <span className="text-[9px] text-[#8b949e] block">{m.matchDetail}</span>
              </div>
              <span className="text-[8px] px-1.5 py-0.5 rounded bg-[#a78bfa]/15 text-[#a78bfa] font-bold">{Math.round(m.score)}%</span>
              <button onClick={() => approveMatch(m)} className="flex items-center gap-1 px-2 py-1 rounded text-[8px] font-bold bg-[#3fb950] text-black hover:opacity-80"><Check size={9} /> Link</button>
              <button onClick={() => dismissMatch(m)} className="text-[#484f58] hover:text-[#e6edf3]"><X size={11} /></button>
            </div>
          ))}
        </div>
      )}

      {/* Standalone records list */}
      {loading ? (
        <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#4dd0e1]" size={18} /></div>
      ) : !filtered.length ? (
        <div className="text-center py-8 text-[10px] text-[#484f58] italic">No standalone records in the studio pool. Records without a project link will appear here.</div>
      ) : (
        <div className="space-y-1">
          {filtered.map((r) => (
            <div key={r.id} className={`glass-panel clip-corner p-2 flex items-center gap-2 ${selected.has(r.id) ? 'border-l-2 border-[#4dd0e1]' : ''}`}>
              <input type="checkbox" checked={selected.has(r.id)} onChange={() => toggleSelect(r.id)} className="accent-[#4dd0e1] shrink-0" />
              <span className="text-[8px] px-1.5 py-0.5 rounded bg-[#30363d] text-[#8b949e] shrink-0">{recordTypeLabel(r)}</span>
              <span className="text-[10px] font-bold text-[#e6edf3] truncate flex-1">{recordTitle(r)}</span>
              {r.department && <span className="text-[8px] text-[#484f58]">{r.department}</span>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}