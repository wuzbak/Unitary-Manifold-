/**
 * ActivityFeed — Live chronological feed of production activities.
 * Shows recent creates, updates, deletes, and status changes across all entities.
 */
import { useState, useEffect } from 'react';
import { Activity, User, Users, Package, MapPin, Camera, FileText, Sparkles, Plus, Edit3, Trash2, RefreshCw, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const ENTITY_ICONS = {
  cast: User, crew: Users, department_item: Package, scene: FileText,
  shot: Camera, location: MapPin, storyboard: Sparkles, script: FileText, project: FileText,
};

const ACTION_CONFIG = {
  created: { icon: Plus, color: '#3fb950', label: 'added' },
  updated: { icon: Edit3, color: '#58a6ff', label: 'updated' },
  deleted: { icon: Trash2, color: '#f85149', label: 'removed' },
  status_changed: { icon: RefreshCw, color: '#fbbf24', label: 'status changed' },
};

function timeAgo(dateStr) {
  if (!dateStr) return '';
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export default function ActivityFeed({ projectId, refreshKey }) {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const filter = projectId ? { project_id: projectId } : {};
        const acts = await base44.entities.ProductionActivity.filter(filter, '-created_date', 30);
        setActivities(acts);
      } catch { setActivities([]); }
      finally { setLoading(false); }
    })();
  }, [projectId, refreshKey]);

  return (
    <div className="glass-strong clip-corner p-4 h-full">
      <div className="flex items-center gap-2 mb-3">
        <Activity size={12} className="text-[#fbbf24]" />
        <span className="text-[10px] font-bold text-[#fbbf24] uppercase tracking-wider">Live Activity Feed</span>
        <span className="text-[8px] text-[#484f58] ml-auto">{activities.length} events</span>
      </div>

      {loading ? (
        <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#484f58]" size={16} /></div>
      ) : activities.length === 0 ? (
        <div className="text-center py-8 text-[10px] text-[#484f58] italic">
          No activity yet. Add cast, crew, scenes, or department items to see live updates here.
        </div>
      ) : (
        <div className="space-y-1.5 max-h-[320px] overflow-y-auto pr-1">
          {activities.map(a => {
            const EntityIcon = ENTITY_ICONS[a.entity_type] || FileText;
            const action = ACTION_CONFIG[a.action] || ACTION_CONFIG.created;
            const ActionIcon = action.icon;
            return (
              <div key={a.id} className="flex items-start gap-2.5 p-2 rounded hover:bg-[#161b22] transition-colors">
                <div className="relative shrink-0 mt-0.5">
                  <div className="w-7 h-7 rounded flex items-center justify-center border border-[#30363d] bg-[#0d1117]">
                    <EntityIcon size={11} className="text-[#8b949e]" />
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded flex items-center justify-center" style={{ background: action.color }}>
                    <ActionIcon size={8} className="text-black" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] text-[#e6edf3]">
                    <span className="font-bold">{a.entity_name || 'Untitled'}</span>
                    <span className="text-[#8b949e]"> {action.label}</span>
                  </div>
                  <div className="text-[8px] text-[#484f58] flex items-center gap-1.5">
                    <span className="uppercase tracking-wider">{a.entity_type.replace('_', ' ')}</span>
                    {a.details && <span>· {a.details}</span>}
                    <span className="ml-auto">{timeAgo(a.created_date)}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}