import { useState } from 'react';
import { DollarSign, Clock, Play, Download } from 'lucide-react';
import { buildBudget, calcROI, calcDOOD, BUDGET_ALLOCATION_DEFAULTS } from '@/lib/filmers/filmEngine';
import { exportPDF, exportCSV, exportJSON, importJSON } from '@/lib/filmers/filmExport';
import ImportExportBar from './ImportExportBar';

export default function FinanceTab({ project, onUpdate }) {
  const [total, setTotal] = useState(String(project.total_budget || 1000000));
  const [overrides, setOverrides] = useState(() => { try { return JSON.parse(project.budget_overrides_json || '{}'); } catch { return {}; } });
  const [budget, setBudget] = useState(null);
  const [roiBudget, setRoiBudget] = useState(String(project.total_budget || 1000000));
  const [roiRevenue, setRoiRevenue] = useState('3000000');
  const [roiDist, setRoiDist] = useState('0.55');
  const [roi, setRoi] = useState(null);
  const [days, setDays] = useState(String(project.shoot_days || 24));
  const [dood, setDood] = useState(null);
  const [shootStart, setShootStart] = useState(project.shoot_start_date || '');
  const [shootEnd, setShootEnd] = useState(project.shoot_end_date || '');
  const [daysCompleted, setDaysCompleted] = useState(String(project.days_completed || 0));

  const fmt = (n) => `$${n.toLocaleString()}`;

  const build = () => {
    const b = buildBudget(parseFloat(total) || 0, overrides);
    setBudget(b);
    onUpdate?.({ total_budget: parseFloat(total) || 0, budget_overrides_json: JSON.stringify(overrides) });
  };
  const setOverride = (key, val) => setOverrides({ ...overrides, [key]: val });

  const exportBudgetConfig = () => {
    exportJSON({ total_budget: parseFloat(total) || 0, shoot_days: parseInt(days) || 0, budget_overrides: overrides }, `${project.title.replace(/\s+/g, '_')}_budget_config.json`);
  };

  const importBudgetConfig = async (file) => {
    try {
      const config = await importJSON(file);
      if (config.total_budget !== undefined) setTotal(String(config.total_budget));
      if (config.shoot_days !== undefined) setDays(String(config.shoot_days));
      if (config.budget_overrides) setOverrides(config.budget_overrides);
    } catch (e) { alert('Import failed: ' + String(e?.message || e)); }
  };

  const saveSchedule = () => {
    onUpdate?.({
      shoot_start_date: shootStart,
      shoot_end_date: shootEnd,
      days_completed: parseInt(daysCompleted) || 0,
    });
  };

  return (
    <div className="space-y-4">
      {/* Budget builder */}
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
          <div className="flex items-center gap-2"><DollarSign size={14} className="text-[#60a5fa]" /><span className="text-xs font-bold text-[#60a5fa]">Budget Builder — 11-Category Allocation</span></div>
          <ImportExportBar onExportJSON={exportBudgetConfig} onImportJSON={importBudgetConfig} accent="#60a5fa" importLabel="Import Config" exportLabel="Export Config" />
        </div>
        <div className="flex gap-2 mb-3">
          <input type="number" value={total} onChange={(e) => setTotal(e.target.value)} placeholder="Total budget $" className="flex-1 bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <button onClick={build} className="flex items-center gap-1.5 bg-[#60a5fa] text-black px-3 py-2 rounded text-xs font-bold hover:opacity-80"><Play size={12} /> Build</button>
          {budget && <button onClick={() => { exportCSV(budget.map((b) => ({ category: b.category, pct: b.pct, amount: b.amount, description: b.description })), 'budget.csv'); exportPDF('Production Budget', budget.map((b) => `${b.category}: ${b.pct}% — ${fmt(b.amount)}`), 'budget.pdf'); }} className="flex items-center gap-1 bg-[#3fb950]/10 border border-[#3fb950]/30 text-[#3fb950] px-3 py-2 rounded text-xs font-bold hover:bg-[#3fb950]/20"><Download size={12} /> Export</button>}
        </div>
        <details className="mb-3">
          <summary className="text-[10px] text-[#8b949e] cursor-pointer hover:text-[#e6edf3]">Custom category overrides (%)</summary>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2">
            {Object.entries(BUDGET_ALLOCATION_DEFAULTS).map(([key, v]) => (
              <div key={key}><label className="text-[8px] text-[#484f58] block">{key.replace(/_/g, ' ')} (def {v.pct}%)</label>
                <input type="number" step="0.1" value={overrides[key] ?? ''} onChange={(e) => setOverride(key, e.target.value)} placeholder={String(v.pct)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-1.5 text-[10px] text-[#e6edf3]" /></div>
            ))}
          </div>
        </details>
        {budget && (
          <div className="space-y-1">
            {budget.map((b) => (
              <div key={b.category} className="flex items-center gap-2 border border-[#30363d] rounded p-2">
                <div className="flex-1"><div className="text-xs font-bold text-[#e6edf3]">{b.category.replace(/_/g, ' ')}</div><div className="text-[9px] text-[#8b949e]">{b.description}</div></div>
                <div className="text-[10px] text-[#60a5fa] font-bold">{b.pct}%</div>
                <div className="text-xs text-[#3fb950] font-bold w-24 text-right">{fmt(b.amount)}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ROI */}
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><DollarSign size={14} className="text-[#60a5fa]" /><span className="text-xs font-bold text-[#60a5fa]">ROI Calculator</span></div>
        <div className="grid grid-cols-3 gap-2 mb-3">
          <input type="number" value={roiBudget} onChange={(e) => setRoiBudget(e.target.value)} placeholder="Budget $" className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <input type="number" value={roiRevenue} onChange={(e) => setRoiRevenue(e.target.value)} placeholder="Revenue $" className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <input type="number" step="0.01" value={roiDist} onChange={(e) => setRoiDist(e.target.value)} placeholder="Dist %" className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
        </div>
        <div className="flex gap-2">
          <button onClick={() => setRoi(calcROI(parseFloat(roiBudget) || 0, parseFloat(roiRevenue) || 0, parseFloat(roiDist) || 0))} className="flex items-center gap-1.5 bg-[#60a5fa] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80"><Play size={12} /> Calculate</button>
          {roi && <button onClick={() => exportPDF('ROI Report', [`Budget: ${fmt(parseFloat(roiBudget))}`, `Gross Revenue: ${fmt(roi.grossRevenue)}`, `Net Profit: ${fmt(roi.netProfit)}`, `ROI: ${roi.roiPct}%`, `Breakeven: ${roi.breakevenMultiple}x`], 'roi.pdf')} className="flex items-center gap-1 bg-[#3fb950]/10 border border-[#3fb950]/30 text-[#3fb950] px-3 py-1.5 rounded text-xs font-bold hover:bg-[#3fb950]/20"><Download size={12} /> PDF</button>}
        </div>
        {roi && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3">
            {[['Gross Revenue', fmt(roi.grossRevenue)], ['Net Profit', fmt(roi.netProfit)], ['ROI', `${roi.roiPct}%`], ['Breakeven', `${roi.breakevenMultiple}x`]].map(([l, v]) => (
              <div key={l} className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-center"><div className="text-[8px] text-[#8b949e] uppercase tracking-wider">{l}</div><div className="text-sm font-bold" style={{ color: roi.netProfit >= 0 ? '#3fb950' : '#f85149' }}>{v}</div></div>
            ))}
          </div>
        )}
      </div>

      {/* DOOD */}
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><Clock size={14} className="text-[#60a5fa]" /><span className="text-xs font-bold text-[#60a5fa]">DOOD — Day Out Of Days</span></div>
        <div className="flex gap-2 mb-3">
          <input type="number" value={total} onChange={(e) => setTotal(e.target.value)} placeholder="Total budget $" className="flex-1 bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <input type="number" value={days} onChange={(e) => setDays(e.target.value)} placeholder="Shoot days" className="w-32 bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <button onClick={() => { setDood(calcDOOD(parseFloat(total) || 0, parseInt(days) || 0)); onUpdate?.({ shoot_days: parseInt(days) || 0 }); }} className="flex items-center gap-1.5 bg-[#60a5fa] text-black px-3 py-2 rounded text-xs font-bold hover:opacity-80"><Play size={12} /> Calculate</button>
        </div>
        {dood !== null && (
          <div className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-center"><div className="text-[8px] text-[#8b949e] uppercase tracking-wider">Cost Per Shoot Day</div><div className="text-lg text-[#60a5fa] font-bold">{fmt(dood)}</div></div>
        )}
      </div>

      {/* Shoot Schedule — drives Studio Analytics remaining-days calc */}
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><Clock size={14} className="text-[#4dd0e1]" /><span className="text-xs font-bold text-[#4dd0e1]">Shoot Schedule — Studio Analytics</span></div>
        <p className="text-[10px] text-[#8b949e] mb-3">Set the shoot window so the Studio Pool budget-vs-days summary can auto-compute remaining days. The AD can override progress with "days completed" for daily tracking.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-3">
          <div><label className="text-[8px] text-[#484f58] uppercase block mb-1">Shoot Start Date</label><input type="date" value={shootStart} onChange={(e) => setShootStart(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" /></div>
          <div><label className="text-[8px] text-[#484f58] uppercase block mb-1">Shoot End (Wrap) Date</label><input type="date" value={shootEnd} onChange={(e) => setShootEnd(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" /></div>
          <div><label className="text-[8px] text-[#484f58] uppercase block mb-1">Days Completed (AD override)</label><input type="number" value={daysCompleted} onChange={(e) => setDaysCompleted(e.target.value)} placeholder="0" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" /></div>
        </div>
        <button onClick={saveSchedule} className="flex items-center gap-1.5 bg-[#4dd0e1] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80"><Play size={12} /> Save Schedule</button>
      </div>
    </div>
  );
}