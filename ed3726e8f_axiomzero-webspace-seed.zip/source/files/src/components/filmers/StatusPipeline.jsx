/**
 * StatusPipeline — Cast & crew status pipeline with visual progress indicators.
 * Shows counts per status stage with member names as horizontal progress bars.
 */
import { User, Users, CheckCircle, Clock, FileText, X } from 'lucide-react';

// Pipeline stages for cast (SAG status) and crew (union status)
const CAST_STAGES = [
  { key: 'Pending', label: 'Pending', color: '#f85149', icon: Clock },
  { key: 'Non-Union', label: 'Non-Union', color: '#8b949e', icon: X },
  { key: 'Fi-Core', label: 'Fi-Core', color: '#f472b6', icon: FileText },
  { key: 'SAG-AFTRA', label: 'SAG-AFTRA', color: '#fbbf24', icon: CheckCircle },
];

const CREW_STAGES = [
  { key: 'Pending', label: 'Pending', color: '#f85149', icon: Clock },
  { key: 'Non-Union', label: 'Non-Union', color: '#8b949e', icon: X },
  { key: 'Fi-Core', label: 'Fi-Core', color: '#f472b6', icon: FileText },
  { key: 'IATSE', label: 'IATSE', color: '#3fb950', icon: CheckCircle },
  { key: 'DGA', label: 'DGA', color: '#58a6ff', icon: CheckCircle },
];

function PipelineSection({ title, icon: Icon, color, members, stages, statusField }) {
  const total = members.length;
  const byStage = stages.map(s => ({
    ...s,
    count: members.filter(m => m[statusField] === s.key).length,
    names: members.filter(m => m[statusField] === s.key).map(m => m.name),
  }));

  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        <Icon size={12} style={{ color }} />
        <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color }}>{title}</span>
        <span className="text-[8px] text-[#484f58]">({total} total)</span>
      </div>
      {total === 0 ? (
        <div className="text-[9px] text-[#484f58] italic py-2">No {title.toLowerCase()} yet.</div>
      ) : (
        <div className="space-y-1.5">
          {byStage.map(stage => {
            const pct = total > 0 ? (stage.count / total) * 100 : 0;
            return (
              <div key={stage.key} className="group">
                <div className="flex items-center justify-between mb-0.5">
                  <div className="flex items-center gap-1.5">
                    <stage.icon size={9} style={{ color: stage.color }} />
                    <span className="text-[9px] font-bold" style={{ color: stage.color }}>{stage.label}</span>
                  </div>
                  <span className="text-[9px] text-[#8b949e]">{stage.count}/{total}</span>
                </div>
                <div className="h-2 bg-[#0d1117] rounded-sm overflow-hidden border border-[#30363d]">
                  <div
                    className="h-full transition-all duration-500"
                    style={{ width: `${pct}%`, background: stage.color, boxShadow: `0 0 6px ${stage.color}40` }}
                  />
                </div>
                {stage.names.length > 0 && (
                  <div className="text-[8px] text-[#484f58] mt-0.5 truncate group-hover:text-[#8b949e] transition-colors">
                    {stage.names.join(' · ')}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function StatusPipeline({ cast, crew }) {
  return (
    <div className="glass-strong clip-corner p-4 h-full">
      <div className="flex items-center gap-2 mb-4">
        <Users size={12} className="text-[#58a6ff]" />
        <span className="text-[10px] font-bold text-[#58a6ff] uppercase tracking-wider">Cast & Crew Status Pipeline</span>
      </div>
      <div className="space-y-4">
        <PipelineSection title="Cast" icon={User} color="#fbbf24" members={cast} stages={CAST_STAGES} statusField="sag_status" />
        <div className="border-t border-[#30363d] pt-4">
          <PipelineSection title="Crew" icon={Users} color="#58a6ff" members={crew} stages={CREW_STAGES} statusField="union_status" />
        </div>
      </div>
    </div>
  );
}