/**
 * ScriptDashboard — Full production breakdown dashboard.
 * Sub-tabs: Overview, Scenes, Characters, Locations, Props, Schedule,
 * Budget/Scene, DOOD, Character Arcs, Dialogue Density, Department Sheets,
 * Scene Complexity, Revision Compare.
 */
import { useState, useMemo } from 'react';
import {
  BarChart3, Users, MapPin, Package, Calendar, DollarSign, Grid3x3,
  TrendingUp, MessageSquare, Camera, Shirt, Brush, Mic, Sparkles,
  AlertTriangle, Film, Layers, Gauge, GitCompare, Loader2, ClipboardCheck
} from 'lucide-react';
import { generateFullBreakdown } from '@/lib/filmers/breakdownSheets';
import { exportCSV, exportTXT } from '@/lib/filmers/filmExport';
import DepartmentReviewTab from './DepartmentReviewTab';

const SUB_TABS = [
  { id: 'overview', label: 'Overview', icon: BarChart3, color: '#4dd0e1' },
  { id: 'scenes', label: 'Scenes', icon: Film, color: '#a78bfa' },
  { id: 'characters', label: 'Characters', icon: Users, color: '#fbbf24' },
  { id: 'locations', label: 'Locations', icon: MapPin, color: '#34d399' },
  { id: 'props', label: 'Props/Set', icon: Package, color: '#58a6ff' },
  { id: 'schedule', label: 'Schedule', icon: Calendar, color: '#f472b6' },
  { id: 'budget_scene', label: 'Budget/Scene', icon: DollarSign, color: '#60a5fa' },
  { id: 'dood', label: 'DOOD', icon: Grid3x3, color: '#bc8cff' },
  { id: 'arcs', label: 'Character Arcs', icon: TrendingUp, color: '#fbbf24' },
  { id: 'dialogue', label: 'Dialogue', icon: MessageSquare, color: '#4dd0e1' },
  { id: 'dept_sheets', label: 'Dept Sheets', icon: Layers, color: '#f85149' },
  { id: 'dept_review', label: 'Dept Review', icon: ClipboardCheck, color: '#3fb950' },
  { id: 'complexity', label: 'Complexity', icon: Gauge, color: '#fbbf24' },
];

const COMPLEXITY_COLORS = { simple: '#3fb950', moderate: '#fbbf24', complex: '#f85149', extreme: '#bc8cff' };
const ARC_COLORS = { lead: '#fbbf24', principal: '#a78bfa', featured: '#58a6ff', supporting: '#8b949e' };
const SHEET_META = {
  camera: { label: 'Camera', icon: Camera, color: '#fbbf24' },
  wardrobe: { label: 'Wardrobe', icon: Shirt, color: '#f472b6' },
  hmu: { label: 'Hair & Makeup', icon: Brush, color: '#bc8cff' },
  sound: { label: 'Sound', icon: Mic, color: '#4dd0e1' },
  vfx: { label: 'VFX', icon: Sparkles, color: '#a78bfa' },
  stunts: { label: 'Stunts', icon: AlertTriangle, color: '#f85149' },
};

function StatCard({ label, value, color, icon: Icon }) {
  return (
    <div className="glass-panel clip-corner p-3 border-l-2" style={{ borderColor: color }}>
      <div className="flex items-center gap-2 mb-1">
        <Icon size={12} style={{ color }} />
        <span className="text-[9px] text-[#8b949e] uppercase tracking-wider">{label}</span>
      </div>
      <div className="text-lg font-bold" style={{ color }}>{value}</div>
    </div>
  );
}

function ComplexityBadge({ score, label }) {
  const color = COMPLEXITY_COLORS[label] || '#8b949e';
  return (
    <div className="flex items-center gap-1.5">
      <div className="w-16 h-2 bg-[#161b22] rounded-full overflow-hidden">
        <div className="h-full rounded-full" style={{ width: `${score}%`, background: color }} />
      </div>
      <span className="text-[9px] font-bold" style={{ color }}>{label}</span>
      <span className="text-[8px] text-[#484f58]">{score}</span>
    </div>
  );
}

export default function ScriptDashboard({ elements, scripts, project, cast, locations, scenes: dbScenes, onNavigate }) {
  const [subTab, setSubTab] = useState('overview');

  const breakdown = useMemo(() => {
    if (!elements || elements.length === 0) return null;
    return generateFullBreakdown(elements, cast || [], locations || []);
  }, [elements, cast, locations]);

  if (!breakdown || breakdown.stats.sceneCount === 0) {
    return (
      <div className="glass-strong clip-corner p-8 text-center">
        <Film size={28} className="text-[#484f58] mx-auto mb-3" />
        <p className="text-xs text-[#8b949e] mb-2">No script content to analyze.</p>
        <p className="text-[10px] text-[#484f58]">Import or create a screenplay in the Editor tab to see the full production breakdown.</p>
      </div>
    );
  }

  const { scenes, characters, locations: bkLocations, departmentItems, departmentSheets, characterArcs, dialogueDensity, stats } = breakdown;

  return (
    <div className="space-y-3">
      {/* Sub-tab navigation */}
      <div className="glass-panel clip-corner p-1.5 overflow-x-auto">
        <div className="flex items-center gap-1 min-w-max">
          {SUB_TABS.map(t => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setSubTab(t.id)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-[9px] font-bold border transition-all whitespace-nowrap ${subTab === t.id ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}
                style={subTab === t.id ? { background: t.color } : {}}
              >
                <Icon size={10} /> {t.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Overview */}
      {subTab === 'overview' && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
            <StatCard label="Scenes" value={stats.sceneCount} color="#a78bfa" icon={Film} />
            <StatCard label="Characters" value={stats.characterCount} color="#fbbf24" icon={Users} />
            <StatCard label="Locations" value={stats.locationCount} color="#34d399" icon={MapPin} />
            <StatCard label="Dept Items" value={stats.departmentItemCount} color="#58a6ff" icon={Package} />
            <StatCard label="VFX Flags" value={stats.vfxFlagCount} color="#a78bfa" icon={Sparkles} />
            <StatCard label="Stunt Flags" value={stats.stuntFlagCount} color="#f85149" icon={AlertTriangle} />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
            <StatCard label="Avg Complexity" value={`${stats.avgComplexity}/100`} color={COMPLEXITY_COLORS[stats.avgComplexity >= 75 ? 'extreme' : stats.avgComplexity >= 50 ? 'complex' : stats.avgComplexity >= 25 ? 'moderate' : 'simple']} icon={Gauge} />
            <StatCard label="Lead Characters" value={stats.leadCharacters} color="#fbbf24" icon={TrendingUp} />
            <StatCard label="Dialogue Lines" value={stats.totalDialogueLines} color="#4dd0e1" icon={MessageSquare} />
          </div>
        </div>
      )}

      {/* Scenes */}
      {subTab === 'scenes' && (
        <div className="glass-panel clip-corner overflow-x-auto">
          <table className="w-full text-[10px]">
            <thead className="bg-[#161b22] text-[#8b949e] uppercase">
              <tr>
                <th className="p-2 text-left">#</th>
                <th className="p-2 text-left">I/E</th>
                <th className="p-2 text-left">D/N</th>
                <th className="p-2 text-left">Location</th>
                <th className="p-2 text-left">Synopsis</th>
                <th className="p-2 text-right">Pages</th>
                <th className="p-2 text-left">Complexity</th>
              </tr>
            </thead>
            <tbody>
              {scenes.map((s, i) => (
                <tr key={i} className="border-t border-[#30363d] hover:bg-[#161b22]">
                  <td className="p-2 font-bold text-[#a78bfa]">{s.scene_number}</td>
                  <td className="p-2 text-[#8b949e]">{s.int_ext}</td>
                  <td className="p-2 text-[#8b949e]">{s.day_night}</td>
                  <td className="p-2 text-[#34d399]">{s.location_text}</td>
                  <td className="p-2 text-[#e6edf3] max-w-[200px] truncate">{s.synopsis}</td>
                  <td className="p-2 text-right text-[#fbbf24]">{s.pages}</td>
                  <td className="p-2"><ComplexityBadge score={s.complexity_score} label={s.complexity_label} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Characters */}
      {subTab === 'characters' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          {characterArcs.map((c, i) => (
            <div key={i} className="glass-panel clip-corner p-3 border-l-2" style={{ borderColor: ARC_COLORS[c.arcType] }}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-[#e6edf3]">{c.name}</span>
                <span className="text-[8px] px-1.5 py-0.5 rounded font-bold uppercase" style={{ background: `${ARC_COLORS[c.arcType]}20`, color: ARC_COLORS[c.arcType] }}>{c.arcType}</span>
              </div>
              <div className="text-[9px] text-[#8b949e] space-y-0.5">
                <div>{c.sceneCount} scenes · {c.dialogueCount} dialogue lines</div>
                <div>First: Scene {c.firstScene + 1} · Last: Scene {c.lastScene + 1}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Locations */}
      {subTab === 'locations' && (
        <div className="glass-panel clip-corner overflow-x-auto">
          <table className="w-full text-[10px]">
            <thead className="bg-[#161b22] text-[#8b949e] uppercase">
              <tr>
                <th className="p-2 text-left">Location</th>
                <th className="p-2 text-right">Scene Count</th>
                <th className="p-2 text-right">Total Pages</th>
                <th className="p-2 text-left">Status</th>
              </tr>
            </thead>
            <tbody>
              {bkLocations.map((l, i) => {
                const locScenes = scenes.filter(s => s.location_text.toLowerCase() === l.name.toLowerCase());
                const totalPages = locScenes.reduce((s, sc) => s + (parseFloat(sc.pages) || 0), 0);
                return (
                  <tr key={i} className="border-t border-[#30363d] hover:bg-[#161b22]">
                    <td className="p-2 font-bold text-[#34d399]">{l.name}</td>
                    <td className="p-2 text-right text-[#e6edf3]">{l._scene_count}</td>
                    <td className="p-2 text-right text-[#fbbf24]">{totalPages.toFixed(1)}</td>
                    <td className="p-2">{l._isNew ? <span className="text-[#3fb950] text-[8px]">NEW</span> : <span className="text-[#484f58] text-[8px]">exists</span>}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Props / Set Dressing */}
      {subTab === 'props' && (
        <div className="space-y-2">
          {Object.entries(
            departmentItems.reduce((acc, item) => {
              if (!acc[item.department]) acc[item.department] = [];
              acc[item.department].push(item);
              return acc;
            }, {})
          ).map(([dept, items]) => (
            <div key={dept}>
              <div className="text-[10px] font-bold uppercase mb-1 text-[#58a6ff]">{dept} ({items.length})</div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-1.5">
                {items.map((item, i) => (
                  <div key={i} className="glass-panel clip-corner p-2 flex items-center gap-2">
                    <span className="text-[10px] text-[#e6edf3] flex-1">{item.item_name}</span>
                    <span className="text-[8px] text-[#484f58]">#{item._scene_number || '?'}</span>
                    <span className="text-[8px] px-1 rounded" style={{ background: '#58a6ff20', color: '#58a6ff' }}>{Math.round(item.confidence * 100)}%</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Schedule */}
      {subTab === 'schedule' && (
        <div className="glass-panel clip-corner p-4">
          <div className="text-xs font-bold text-[#f472b6] mb-2">Pages-Per-Day Analysis</div>
          <div className="space-y-1">
            {scenes.map((s, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="text-[9px] text-[#a78bfa] w-6">#{s.scene_number}</span>
                <div className="flex-1 h-4 bg-[#161b22] rounded overflow-hidden">
                  <div className="h-full bg-[#f472b6]" style={{ width: `${Math.min(parseFloat(s.pages) * 20, 100)}%` }} />
                </div>
                <span className="text-[9px] text-[#fbbf24] w-10 text-right">{s.pages}p</span>
              </div>
            ))}
          </div>
          <div className="mt-3 text-[10px] text-[#8b949e]">
            Total: {scenes.reduce((s, sc) => s + (parseFloat(sc.pages) || 0), 0).toFixed(1)} pages · Est. {Math.ceil(scenes.reduce((s, sc) => s + (parseFloat(sc.pages) || 0), 0) / 5)} shoot days @ 5pp/day
          </div>
        </div>
      )}

      {/* Budget per Scene */}
      {subTab === 'budget_scene' && (
        <div className="glass-panel clip-corner overflow-x-auto">
          <table className="w-full text-[10px]">
            <thead className="bg-[#161b22] text-[#8b949e] uppercase">
              <tr>
                <th className="p-2 text-left">Scene</th>
                <th className="p-2 text-left">Location</th>
                <th className="p-2 text-right">Pages</th>
                <th className="p-2 text-right">Items</th>
                <th className="p-2 text-right">Est. Cost</th>
                <th className="p-2 text-left">Complexity</th>
              </tr>
            </thead>
            <tbody>
              {scenes.map((s, i) => {
                const sceneItems = departmentItems.filter(d => d._scene_index === s.sort_order);
                const itemCost = sceneItems.reduce((sum, d) => sum + (d.unit_cost || 0) * (d.quantity || 1), 0);
                const pageCost = (parseFloat(s.pages) || 0) * 1000; // rough $1k/page estimate
                const total = itemCost + pageCost;
                return (
                  <tr key={i} className="border-t border-[#30363d] hover:bg-[#161b22]">
                    <td className="p-2 font-bold text-[#a78bfa]">#{s.scene_number}</td>
                    <td className="p-2 text-[#34d399]">{s.location_text}</td>
                    <td className="p-2 text-right text-[#fbbf24]">{s.pages}</td>
                    <td className="p-2 text-right text-[#58a6ff]">{sceneItems.length}</td>
                    <td className="p-2 text-right text-[#3fb950]">${total.toLocaleString()}</td>
                    <td className="p-2"><ComplexityBadge score={s.complexity_score} label={s.complexity_label} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* DOOD */}
      {subTab === 'dood' && (
        <div className="glass-panel clip-corner overflow-x-auto">
          <table className="w-full text-[9px]">
            <thead className="bg-[#161b22] text-[#8b949e] uppercase">
              <tr>
                <th className="p-2 text-left sticky left-0 bg-[#161b22]">Character</th>
                {scenes.map((s, i) => <th key={i} className="p-1 text-center">{s.scene_number}</th>)}
                <th className="p-2 text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {characterArcs.map((c, i) => (
                <tr key={i} className="border-t border-[#30363d]">
                  <td className="p-2 font-bold text-[#e6edf3] sticky left-0 bg-[#0d1117]">{c.name}</td>
                  {scenes.map((s, si) => (
                    <td key={si} className="p-1 text-center">
                      {c.scenes.includes(s.sort_order) ? (
                        <span className="inline-block w-4 h-4 rounded text-[8px] font-bold leading-4" style={{ background: `${ARC_COLORS[c.arcType]}30`, color: ARC_COLORS[c.arcType] }}>W</span>
                      ) : (
                        <span className="text-[#30363d]">·</span>
                      )}
                    </td>
                  ))}
                  <td className="p-2 text-right font-bold text-[#fbbf24]">{c.sceneCount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Character Arcs */}
      {subTab === 'arcs' && (
        <div className="space-y-2">
          {characterArcs.map((c, i) => {
            const color = ARC_COLORS[c.arcType];
            return (
              <div key={i} className="glass-panel clip-corner p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#e6edf3]">{c.name}</span>
                    <span className="text-[8px] px-1.5 py-0.5 rounded font-bold uppercase" style={{ background: `${color}20`, color }}>{c.arcType}</span>
                  </div>
                  <span className="text-[9px] text-[#484f58]">{c.sceneCount} scenes · {c.dialogueCount} lines</span>
                </div>
                <div className="flex items-center gap-0.5">
                  {scenes.map((s, si) => (
                    <div key={si} className="flex-1 h-6 rounded-sm" style={{ background: c.scenes.includes(s.sort_order) ? `${color}40` : '#161b22' }} title={`Scene ${s.scene_number}`} />
                  ))}
                </div>
                <div className="flex justify-between mt-1 text-[8px] text-[#484f58]">
                  <span>Scene {c.firstScene + 1}</span>
                  <span>Scene {c.lastScene + 1}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Dialogue Density */}
      {subTab === 'dialogue' && (
        <div className="glass-panel clip-corner overflow-x-auto">
          <table className="w-full text-[10px]">
            <thead className="bg-[#161b22] text-[#8b949e] uppercase">
              <tr>
                <th className="p-2 text-left">Scene</th>
                <th className="p-2 text-right">Lines</th>
                <th className="p-2 text-right">Words</th>
                <th className="p-2 text-right">Chars</th>
                <th className="p-2 text-right">Density</th>
              </tr>
            </thead>
            <tbody>
              {dialogueDensity.map((d, i) => (
                <tr key={i} className="border-t border-[#30363d] hover:bg-[#161b22]">
                  <td className="p-2 font-bold text-[#a78bfa]">#{d.sceneNumber}</td>
                  <td className="p-2 text-right text-[#e6edf3]">{d.dialogueLines}</td>
                  <td className="p-2 text-right text-[#8b949e]">{d.wordCount}</td>
                  <td className="p-2 text-right text-[#fbbf24]">{d.charactersSpeaking}</td>
                  <td className="p-2 text-right">
                    <span style={{ color: d.density > 10 ? '#f85149' : d.density > 5 ? '#fbbf24' : '#3fb950' }}>{d.density}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Department Sheets */}
      {subTab === 'dept_sheets' && (
        <div className="space-y-3">
          {Object.entries(SHEET_META).map(([sheetKey, meta]) => {
            const Icon = meta.icon;
            const totalFlags = Object.values(departmentSheets).reduce((s, sh) => s + (sh[sheetKey]?.length || 0), 0);
            return (
              <div key={sheetKey} className="glass-panel clip-corner p-3 border-l-2" style={{ borderColor: meta.color }}>
                <div className="flex items-center gap-2 mb-2">
                  <Icon size={14} style={{ color: meta.color }} />
                  <span className="text-xs font-bold" style={{ color: meta.color }}>{meta.label}</span>
                  <span className="text-[9px] text-[#484f58]">{totalFlags} flags across scenes</span>
                </div>
                {totalFlags === 0 ? (
                  <div className="text-[10px] text-[#484f58] italic">No {meta.label.toLowerCase()} flags detected.</div>
                ) : (
                  <div className="space-y-1">
                    {Object.entries(departmentSheets).map(([sceneIdx, sheet]) => {
                      const flags = sheet[sheetKey] || [];
                      if (flags.length === 0) return null;
                      const scene = scenes.find(s => s.sort_order === Number(sceneIdx));
                      return (
                        <div key={sceneIdx} className="flex items-start gap-2 p-1.5 rounded bg-[#161b22]">
                          <span className="text-[9px] font-bold text-[#a78bfa] shrink-0 w-8">#{scene?.scene_number || '?'}</span>
                          <div className="flex flex-wrap gap-1">
                            {flags.map((f, fi) => (
                              <span key={fi} className="text-[8px] px-1.5 py-0.5 rounded border" style={{ borderColor: `${meta.color}40`, color: meta.color }}>{f.keyword}</span>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Department Head Review */}
      {subTab === 'dept_review' && (
        <DepartmentReviewTab breakdown={breakdown} project={project} scenes={dbScenes} />
      )}

      {/* Scene Complexity */}
      {subTab === 'complexity' && (
        <div className="space-y-2">
          {scenes.sort((a, b) => b.complexity_score - a.complexity_score).map((s, i) => (
            <div key={i} className="glass-panel clip-corner p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-[#a78bfa]">#{s.scene_number}</span>
                  <span className="text-[10px] text-[#34d399]">{s.location_text}</span>
                  <span className="text-[8px] text-[#484f58]">{s.int_ext}/{s.day_night} · {s.pages}p</span>
                </div>
                <ComplexityBadge score={s.complexity_score} label={s.complexity_label} />
              </div>
              <div className="text-[9px] text-[#8b949e] line-clamp-2">{s.synopsis}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}