import { useState, useEffect } from 'react';
import { Download, FileJson, Loader2, Upload } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { buildBudget, calcROI, generateOneLiner, generateCallSheet, generateScoutReport } from '@/lib/filmers/filmEngine';
import { exportPDF, exportCSV, exportTXT, exportJSON, importJSON, exportProjectBundle, importProjectBundle } from '@/lib/filmers/filmExport';

export default function ExportTab({ project }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [importing, setImporting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [scripts, scenes, locations, shots, panels, cast, crew, deptItems, shootDays, timeCards, permits, credits, resources, callSheets] = await Promise.all([
        base44.entities.Script.filter({ project_id: project.id }),
        base44.entities.Scene.filter({ project_id: project.id }, 'sort_order', 500),
        base44.entities.Location.filter({ project_id: project.id }),
        base44.entities.Shot.filter({ project_id: project.id }, 'sort_order', 500),
        base44.entities.StoryboardPanel.filter({ project_id: project.id }),
        base44.entities.CastMember.filter({ project_id: project.id }),
        base44.entities.CrewMember.filter({ project_id: project.id }),
        base44.entities.DepartmentItem.filter({ project_id: project.id }),
        base44.entities.ShootDay.filter({ project_id: project.id }, 'day_number', 500),
        base44.entities.TimeCard.filter({ project_id: project.id }, '-shoot_date', 500),
        base44.entities.Permit.filter({ project_id: project.id }),
        base44.entities.FilmCredit.filter({ project_id: project.id }),
        base44.entities.LocalResource.filter({ project_id: project.id }),
        base44.entities.CallSheet.filter({ project_id: project.id }, '-shoot_date', 500),
      ]);
      setData({ scripts, scenes, locations, shots, panels, cast, crew, deptItems, shootDays, timeCards, permits, credits, resources, callSheets });
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [project.id]);

  const fmt = (n) => `$${n.toLocaleString()}`;
  const safe = data || { scripts: [], scenes: [], locations: [], shots: [], panels: [], cast: [], crew: [], deptItems: [] };

  const exportBundle = () => {
    exportProjectBundle(project.id, { ...safe, project });
  };

  const importBundle = async (file) => {
    if (!file) return;
    setImporting(true);
    try {
      const bundle = await importJSON(file);
      const projData = bundle.project || bundle._project || {};
      const newProj = await base44.entities.FilmProject.create({
        title: `${projData.title || 'Imported'} (imported)`,
        synopsis: projData.synopsis || '',
        status: projData.status || 'Development',
        total_budget: projData.total_budget || 0,
        shoot_days: projData.shoot_days || 0,
        budget_overrides_json: projData.budget_overrides_json || '{}',
      });
      const results = await importProjectBundle(bundle, newProj.id, base44);
      const total = Object.values(results).filter(v => typeof v === 'number').reduce((s, v) => s + v, 0);
      alert(`Project bundle imported. ${total} records created.`);
    } catch (e) { alert('Import failed: ' + String(e?.message || e)); }
    setImporting(false);
  };

  const artifacts = [
    { label: 'Budget (PDF/CSV)', icon: Download, color: '#60a5fa', action: () => {
      const b = buildBudget(project.total_budget || 0);
      exportPDF('Production Budget', b.map((x) => `${x.category}: ${x.pct}% — ${fmt(x.amount)}`), 'budget.pdf');
      exportCSV(b.map((x) => ({ category: x.category, pct: x.pct, amount: x.amount })), 'budget.csv');
    } },
    { label: 'ROI Report (PDF)', icon: Download, color: '#60a5fa', action: () => {
      const r = calcROI(project.total_budget || 0, (project.total_budget || 0) * 3, 0.55);
      exportPDF('ROI Report', [`Budget: ${fmt(project.total_budget || 0)}`, `Net Profit: ${fmt(r.netProfit)}`, `ROI: ${r.roiPct}%`], 'roi.pdf');
    } },
    { label: 'One-Liner (PDF/TXT)', icon: Download, color: '#f472b6', action: () => {
      const ol = generateOneLiner(safe.scenes); exportPDF('One-Liner', ol, 'one_liner.pdf'); exportTXT(ol.join('\n'), 'one_liner.txt');
    } },
    { label: 'Call Sheet (PDF/TXT)', icon: Download, color: '#f472b6', action: () => {
      const cs = generateCallSheet(safe.scenes, safe.locations[0] || {}, ''); exportPDF('Call Sheet', cs, 'call_sheet.pdf'); exportTXT(cs, 'call_sheet.txt');
    } },
    { label: 'Scout Reports (PDF)', icon: Download, color: '#34d399', action: () => {
      safe.locations.forEach((l, i) => exportPDF(`Scout Report — ${l.name}`, generateScoutReport(l), `scout_${i + 1}.pdf`));
    } },
    { label: 'Shot List (CSV)', icon: Download, color: '#fbbf24', action: () => {
      exportCSV(safe.shots.map((s, i) => ({ order: i + 1, coverage: s.coverage_type, lens: s.lens, movement: s.movement, notes: s.notes })), 'shot_list.csv');
    } },
    { label: 'Cast List (CSV)', icon: Download, color: '#fbbf24', action: () => {
      exportCSV(safe.cast.map((c) => ({ name: c.name, role: c.role, sag_status: c.sag_status, agent: c.agent, contact: c.contact, day_rate: c.day_rate, notes: c.notes })), 'cast_list.csv');
    } },
    { label: 'Crew List (CSV)', icon: Download, color: '#58a6ff', action: () => {
      exportCSV(safe.crew.map((c) => ({ name: c.name, department: c.department, position: c.position, union_status: c.union_status, day_rate: c.day_rate, contact: c.contact, notes: c.notes })), 'crew_list.csv');
    } },
    { label: 'Dept Inventory (CSV)', icon: Download, color: '#34d399', action: () => {
      exportCSV(safe.deptItems.map((i) => ({
        department: i.department, item: i.item_name, category: i.category, qty: i.quantity,
        procurement_status: i.procurement_status || i.status || 'needed',
        vendor: i.source_vendor, unit_cost: i.unit_cost,
        total_cost: (i.unit_cost || 0) * (i.quantity || 1),
        storage_location: i.storage_location || '', po_number: i.po_number || '',
        order_date: i.order_date || '', expected_delivery: i.expected_delivery_date || '',
        notes: i.notes,
      })), 'department_inventory.csv');
    } },
  ];

  return (
    <div className="space-y-4">
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><Download size={14} className="text-[#3fb950]" /><span className="text-xs font-bold text-[#3fb950]">Export Artifacts</span></div>
        {loading ? <div className="flex justify-center py-4"><Loader2 className="animate-spin text-[#484f58]" size={16} /></div> : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {artifacts.map((a) => (
              <button key={a.label} onClick={a.action} disabled={!safe.scenes.length && !project.total_budget} className="flex items-center gap-2 p-3 border border-[#30363d] rounded hover:border-[#3fb950]/40 transition-colors text-left disabled:opacity-40">
                <a.icon size={14} style={{ color: a.color }} /><span className="text-[11px] text-[#e6edf3] font-bold">{a.label}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><FileJson size={14} className="text-[#a78bfa]" /><span className="text-xs font-bold text-[#a78bfa]">Project Bundle</span></div>
        <div className="flex flex-wrap gap-2">
          <button onClick={exportBundle} disabled={loading} className="flex items-center gap-1.5 bg-[#a78bfa] text-black px-3 py-2 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"><Download size={12} /> Export JSON Bundle</button>
          <label className="flex items-center gap-1.5 bg-[#a78bfa]/20 border border-[#a78bfa]/40 text-[#a78bfa] px-3 py-2 rounded text-xs font-bold hover:bg-[#a78bfa]/30 cursor-pointer">
            {importing ? <Loader2 size={12} className="animate-spin" /> : <Upload size={12} />} Import Bundle
            <input type="file" accept=".json" className="hidden" onChange={(e) => importBundle(e.target.files?.[0])} />
          </label>
        </div>
        <p className="text-[9px] text-[#484f58] mt-2">Full backup: project, scripts, scenes, locations, shots, storyboard panels, cast, crew, and all department inventory. Import creates a new production.</p>
      </div>
    </div>
  );
}