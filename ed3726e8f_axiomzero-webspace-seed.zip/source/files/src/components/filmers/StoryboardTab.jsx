/**
 * StoryboardTab — AI storyboard generator with clickable panels, export, and detail drawer.
 */
import { useState, useEffect } from 'react';
import { Sparkles, Loader2, Trash2, Download, Image as ImageIcon } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Image } from '@/components/ui/image';
import { exportCSV } from '@/lib/filmers/filmExport';
import { logActivity } from '@/lib/filmers/activityLog';
import ImportExportBar from './ImportExportBar';
import EntityDetailDrawer from './EntityDetailDrawer';

const PANEL_FIELDS = [
  { key: 'synopsis', label: 'Synopsis', type: 'textarea' },
  { key: 'prompt', label: 'Generation Prompt', type: 'textarea' },
];

const buildPrompt = (scene) => {
  const desc = scene.synopsis || scene.location_text || 'cinematic film still';
  return `Cinematic storyboard frame: ${desc}. ${scene.int_ext || 'INT'} ${scene.day_night || 'DAY'}. Professional cinematography, naturalistic lighting, film grain, color graded, high detail, 16:9, photorealistic.`;
};

export default function StoryboardTab({ project }) {
  const [scenes, setScenes] = useState([]);
  const [panels, setPanels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState(null);
  const [drawer, setDrawer] = useState({ open: false, entity: null });

  const load = async () => {
    setLoading(true);
    try {
      const [sc, pn] = await Promise.all([
        base44.entities.Scene.filter({ project_id: project.id }, 'sort_order', 500),
        base44.entities.StoryboardPanel.filter({ project_id: project.id }),
      ]);
      setScenes(sc); setPanels(pn);
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [project.id]);

  const genAll = async () => {
    if (!scenes.length || generating) return;
    setGenerating(true); setError(null);
    try {
      for (const scene of scenes) {
        const prompt = buildPrompt(scene);
        const { url } = await base44.integrations.Core.GenerateImage({ prompt });
        await base44.entities.StoryboardPanel.create({ project_id: project.id, scene_id: scene.id, image_url: url, prompt, synopsis: scene.synopsis || scene.location_text || '' });
      }
      logActivity(project.id, 'storyboard', `${scenes.length} panels`, 'created', 'AI generation');
      await load();
    } catch (e) { setError(String(e?.message || e)); }
    setGenerating(false);
  };

  const genOne = async (scene) => {
    setGenerating(true); setError(null);
    try {
      const prompt = buildPrompt(scene);
      const { url } = await base44.integrations.Core.GenerateImage({ prompt });
      await base44.entities.StoryboardPanel.create({ project_id: project.id, scene_id: scene.id, image_url: url, prompt, synopsis: scene.synopsis || scene.location_text || '' });
      await load();
    } catch (e) { setError(String(e?.message || e)); }
    setGenerating(false);
  };

  const del = async (id) => {
    await base44.entities.StoryboardPanel.delete(id);
    setPanels(panels.filter((p) => p.id !== id));
    setDrawer({ open: false, entity: null });
  };

  const save = async (id, formData) => {
    await base44.entities.StoryboardPanel.update(id, formData);
    setPanels(panels.map(p => p.id === id ? { ...p, ...formData } : p));
  };

  const doExport = () => {
    exportCSV(panels.map(p => ({ synopsis: p.synopsis, prompt: p.prompt, image_url: p.image_url })), 'storyboard_panels.csv');
  };

  return (
    <div className="space-y-4">
      <div className="glass-strong clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><Sparkles size={14} className="text-[#fbbf24]" /><span className="text-xs font-bold text-[#fbbf24]">AI Storyboard Generator</span><span className="text-[8px] text-[#484f58] ml-auto">consumes image credits</span></div>
        {loading ? <div className="flex justify-center py-4"><Loader2 className="animate-spin text-[#484f58]" size={16} /></div> : !scenes.length ? (
          <p className="text-[11px] text-[#8b949e] italic">No scenes yet. Import a script first, then generate storyboard panels per scene.</p>
        ) : (
          <>
            <button onClick={genAll} disabled={generating} className="flex items-center gap-1.5 bg-[#fbbf24] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40">
              {generating ? <Loader2 size={12} className="animate-spin" /> : <ImageIcon size={12} />} {generating ? 'Generating…' : `Generate ${scenes.length} Panel${scenes.length !== 1 ? 's' : ''}`}
            </button>
            {error && <div className="mt-2 text-[10px] text-[#f85149] border border-[#f85149]/30 rounded p-2">{error}</div>}
          </>
        )}
      </div>

      {/* Scenes without panels */}
      {!loading && scenes.length > 0 && (
        <div className="glass-panel clip-corner p-3">
          <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-2">Scenes</div>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {scenes.map((s, i) => (
              <div key={s.id} className="flex items-center gap-2 text-[10px] border border-[#30363d] rounded p-1.5">
                <span className="text-[#fbbf24] font-bold">{s.scene_number || i + 1}</span>
                <span className="text-[#8b949e]">{s.int_ext}/{s.day_night}</span>
                <span className="text-[#e6edf3] flex-1 truncate">{s.synopsis || s.location_text}</span>
                <button onClick={() => genOne(s)} disabled={generating} className="text-[#fbbf24] hover:bg-[#fbbf24]/10 px-2 py-1 rounded disabled:opacity-40"><Sparkles size={11} /></button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Panel gallery */}
      {panels.length > 0 && (
        <div className="glass-strong clip-corner p-4">
          <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
            <div className="text-[10px] text-[#8b949e] uppercase tracking-wider">Storyboard Panels ({panels.length})</div>
            <ImportExportBar onExportCSV={doExport} accent="#fbbf24" />
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {panels.map((p) => (
              <div key={p.id} className="border border-[#30363d] rounded overflow-hidden bg-[#0B0F13] group cursor-pointer hover:border-[#fbbf24]/40 transition-colors" onClick={() => setDrawer({ open: true, entity: p })}>
                <div className="aspect-video relative">
                  <Image src={p.image_url} alt={p.synopsis} className="w-full h-full" fittingType="fill" />
                  <div className="absolute top-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <a href={p.image_url} download={`panel_${p.id}.png`} onClick={(e) => e.stopPropagation()} className="bg-[#0B0F13]/80 p-1 rounded hover:bg-[#3fb950]/20"><Download size={10} className="text-[#3fb950]" /></a>
                    <button onClick={(e) => { e.stopPropagation(); del(p.id); }} className="bg-[#0B0F13]/80 p-1 rounded hover:bg-[#f85149]/20"><Trash2 size={10} className="text-[#f85149]" /></button>
                  </div>
                </div>
                <p className="text-[9px] text-[#8b949e] p-1.5 leading-snug line-clamp-2">{p.synopsis || p.prompt}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <EntityDetailDrawer
        open={drawer.open}
        entity={drawer.entity}
        entityName="StoryboardPanel"
        fields={PANEL_FIELDS}
        titleKey="synopsis"
        titleFallback="Storyboard Panel"
        accent="#fbbf24"
        onClose={() => setDrawer({ open: false, entity: null })}
        onSave={save}
        onDelete={del}
        exportRows={(entity) => [{ synopsis: entity.synopsis, prompt: entity.prompt, image_url: entity.image_url }]}
        exportFilename={`panel_${drawer.entity?.id || 'item'}.csv`}
      />
    </div>
  );
}