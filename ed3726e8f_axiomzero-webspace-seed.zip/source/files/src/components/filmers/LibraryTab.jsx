/**
 * LibraryTab — Merged Library view: Books first (prominent cards), Resources below.
 * Replaces the old sub-tab approach so books are immediately visible.
 */
import { useState } from 'react';
import { BookOpen, Clapperboard, ExternalLink } from 'lucide-react';
import BookReader from './BookReader';
import ResonanceGuides from './ResonanceGuides';
import { RESOURCE_CATEGORIES } from '@/lib/filmers/resources';
import { Code2, ClipboardList, Film, Music, Archive, Volume2, Image as ImageIcon, GraduationCap } from 'lucide-react';

const ICON_MAP = { Code2, ClipboardList, Film, Music, Archive, Volume2, Image: ImageIcon, GraduationCap };

const BOOKS = [
  {
    key: 'production',
    label: 'Axiom Omega Production Guide',
    icon: BookOpen,
    url: 'https://media.base44.com/files/public/6a51c0830aeacd39ab86c4f0/498851358_book-film-production-omega1.md',
    title: 'Axiom Omega Production Guide',
    subtitle: 'Film and Television: Fast, Humane, and Built to Last',
    accent: '#fbbf24',
  },
  {
    key: 'acting',
    label: 'The Living Instrument',
    icon: Clapperboard,
    url: 'https://media.base44.com/files/public/6a51c0830aeacd39ab86c4f0/6868b98c9_book-living-instrument-actors-craft.md',
    title: 'The Living Instrument',
    subtitle: "A Complete Manual of the Actor's Craft — From Ancient Ritual to the Modern Stage and Screen",
    accent: '#a78bfa',
  },
];

export default function LibraryTab() {
  const [activeBook, setActiveBook] = useState(null);
  const book = activeBook ? BOOKS.find((b) => b.key === activeBook) : null;

  return (
    <div className="space-y-4">
      {/* Books section — first, prominent */}
      <div className="glass-strong clip-corner p-4 border-l-2 border-[#a78bfa]">
        <div className="flex items-center gap-2 mb-3">
          <BookOpen size={14} className="text-[#a78bfa]" />
          <span className="text-xs font-bold text-[#a78bfa]">Production Library — Full Book Reproductions</span>
        </div>

        {/* Book selector cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-3">
          {BOOKS.map((b) => (
            <button
              key={b.key}
              onClick={() => setActiveBook(activeBook === b.key ? null : b.key)}
              className={`glass-panel clip-corner p-3 text-left transition-all ${activeBook === b.key ? 'border-2' : 'border border-[#30363d] hover:border-[#a78bfa]/40'}`}
              style={activeBook === b.key ? { borderColor: b.accent } : {}}
            >
              <div className="flex items-center gap-2 mb-1">
                <b.icon size={14} style={{ color: b.accent }} />
                <span className="text-xs font-bold" style={{ color: b.accent }}>{b.label}</span>
              </div>
              <p className="text-[9px] text-[#8b949e] leading-relaxed">{b.subtitle}</p>
            </button>
          ))}
        </div>

        <div className="text-[10px] text-[#484f58] px-1 mb-2">Full reproduction · Founding Fathers exhibit format · Progressive chapter loading · Licensed under Defensive Public Commons License v1.0 (2026)</div>

        {/* Active book reader — accordion: only renders when a book is selected */}
        {book && (
          <BookReader key={book.key} bookUrl={book.url} bookTitle={book.title} bookSubtitle={book.subtitle} accent={book.accent} />
        )}
      </div>

      {/* Merlin's Resonance Guides — pillar media library */}
      <ResonanceGuides />

      {/* Resources section — below books */}
      <div className="glass-strong clip-corner p-4">
        <h2 className="text-sm font-bold text-[#e6edf3] mb-1">Open-Source & Public Domain Resources</h2>
        <p className="text-[10px] text-[#8b949e] mb-3">Open-source tools, public domain archives, Creative Commons music, and educational resources for film and television production. All entries verified and linked.</p>
      </div>
      {RESOURCE_CATEGORIES.map((cat) => {
        const Icon = ICON_MAP[cat.icon] || Film;
        return (
          <div key={cat.title} className="glass-strong clip-corner p-4">
            <div className="flex items-center gap-2 mb-3">
              <Icon size={14} style={{ color: cat.color }} />
              <span className="text-xs font-bold" style={{ color: cat.color }}>{cat.title}</span>
              <span className="text-[8px] text-[#484f58]">({cat.resources.length})</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {cat.resources.map((r) => (
                <a key={r.name} href={r.url} target="_blank" rel="noopener noreferrer" className="glass-panel clip-corner p-2.5 glow-hover block group">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-[#e6edf3] group-hover:text-[#58a6ff] transition-colors">{r.name}</span>
                    <ExternalLink size={10} className="text-[#484f58] group-hover:text-[#58a6ff] transition-colors" />
                  </div>
                  <p className="text-[9px] text-[#8b949e] leading-relaxed">{r.desc}</p>
                </a>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}