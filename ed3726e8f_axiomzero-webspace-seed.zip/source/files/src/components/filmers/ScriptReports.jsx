/**
 * ScriptReports — Tabbed reports panel: Scene, Location, Character, Dialogue chart.
 * All computed client-side from screenplay elements + existing entities.
 */
import { useState, useMemo, useEffect } from 'react';
import { Film, MapPin, Users, BarChart3, Download, RefreshCw } from 'lucide-react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { base44 } from '@/api/base44Client';
import {
  computeSceneReport, computeLocationReport, computeCharacterReport,
  computeDialogueChart, computeElementStats, computeTotalPages,
} from '@/lib/filmers/scriptReports';
import { exportReportCSV } from '@/lib/filmers/scriptExport';

const TABS = [
  { id: 'scene', label: 'Scenes', icon: Film, color: '#a78bfa' },
  { id: 'location', label: 'Locations', icon: MapPin, color: '#34d399' },
  { id: 'character', label: 'Characters', icon: Users, color: '#fbbf24' },
  { id: 'dialogue', label: 'Dialogue', icon: BarChart3, color: '#4dd0e1' },
];

export default function ScriptReports({ elements, project }) {
  const [tab, setTab] = useState('scene');
  const [existingScenes, setExistingScenes] = useState([]);
  const [existingCast, setExistingCast] = useState([]);

  useEffect(() => {
    if (!project) return;
    Promise.all([
      base44.entities.Scene.filter({ project_id: project.id }).catch(() => []),
      base44.entities.CastMember.filter({ project_id: project.id }).catch(() => []),
    ]).then(([s, c]) => { setExistingScenes(s); setExistingCast(c); });
  }, [project]);

  const sceneReport = useMemo(() => computeSceneReport(elements), [elements]);
  const locationReport = useMemo(() => computeLocationReport(elements), [elements]);
  const characterReport = useMemo(() => computeCharacterReport(elements), [elements]);
  const dialogueData = useMemo(() => computeDialogueChart(elements), [elements]);
  const elementStats = useMemo(() => computeElementStats(elements), [elements]);
  const totalPages = useMemo(() => computeTotalPages(elements), [elements]);

  const handleExport = () => {
    if (tab === 'scene') exportReportCSV(sceneReport, 'scene_report.csv');
    else if (tab === 'location') exportReportCSV(locationReport, 'location_report.csv');
    else if (tab === 'character') exportReportCSV(characterReport, 'character_report.csv');
  };

  return (
    <div className="space-y-3">
      {/* Summary stats */}
      <div className="glass-panel clip-corner p-3 flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-1.5">
          <Film size={12} className="text-[#a78bfa]" />
          <span className="text-[10px] text-[#8b949e]">Scenes: <span className="text-[#e6edf3] font-bold">{sceneReport.length}</span></span>
        </div>
        <div className="flex items-center gap-1.5">
          <MapPin size={12} className="text-[#34d399]" />
          <span className="text-[10px] text-[#8b949e]">Locations: <span className="text-[#e6edf3] font-bold">{locationReport.length}</span></span>
        </div>
        <div className="flex items-center gap-1.5">
          <Users size={12} className="text-[#fbbf24]" />
          <span className="text-[10px] text-[#8b949e]">Characters: <span className="text-[#e6edf3] font-bold">{characterReport.length}</span></span>
        </div>
        <div className="flex items-center gap-1.5">
          <BarChart3 size={12} className="text-[#4dd0e1]" />
          <span className="text-[10px] text-[#8b949e]">Pages: <span className="text-[#e6edf3] font-bold">{totalPages}</span></span>
        </div>
      </div>

      {/* Tab bar */}
      <div className="flex items-center gap-1 flex-wrap">
        {TABS.map(t => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded text-[10px] font-bold border transition-colors ${tab === t.id ? 'text-black border-transparent' : 'border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]'}`}
              style={tab === t.id ? { background: t.color } : {}}
            >
              <Icon size={10} /> {t.label}
            </button>
          );
        })}
        {tab !== 'dialogue' && (
          <button onClick={handleExport} className="ml-auto flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3]">
            <Download size={10} /> CSV
          </button>
        )}
      </div>

      {/* Report content */}
      {tab === 'scene' && (
        <div className="glass-panel clip-corner p-3 overflow-x-auto">
          <table className="w-full text-[10px]">
            <thead>
              <tr className="border-b border-[#30363d] text-[#8b949e]">
                <th className="text-left p-1.5">#</th>
                <th className="text-left p-1.5">INT/EXT</th>
                <th className="text-left p-1.5">Day/Night</th>
                <th className="text-left p-1.5">Location</th>
                <th className="text-right p-1.5">Pages</th>
                <th className="text-left p-1.5">Characters</th>
              </tr>
            </thead>
            <tbody>
              {sceneReport.length === 0 ? (
                <tr><td colSpan={6} className="text-center text-[#484f58] italic p-4">No scenes in script</td></tr>
              ) : sceneReport.map((s, i) => (
                <tr key={i} className="border-b border-[#30363d]/50 hover:bg-[#161b22]">
                  <td className="p-1.5 text-[#a78bfa] font-bold">{s.scene_number}</td>
                  <td className="p-1.5 text-[#8b949e]">{s.int_ext}</td>
                  <td className="p-1.5 text-[#8b949e]">{s.day_night}</td>
                  <td className="p-1.5 text-[#e6edf3]">{s.location}</td>
                  <td className="p-1.5 text-right text-[#8b949e]">{s.pages}</td>
                  <td className="p-1.5 text-[#8b949e]">{s.characters || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'location' && (
        <div className="glass-panel clip-corner p-3 overflow-x-auto">
          <table className="w-full text-[10px]">
            <thead>
              <tr className="border-b border-[#30363d] text-[#8b949e]">
                <th className="text-left p-1.5">Location</th>
                <th className="text-left p-1.5">INT/EXT</th>
                <th className="text-right p-1.5">Scenes</th>
                <th className="text-right p-1.5">Pages</th>
                <th className="text-left p-1.5">Day/Night</th>
                <th className="text-left p-1.5">Scene #s</th>
              </tr>
            </thead>
            <tbody>
              {locationReport.length === 0 ? (
                <tr><td colSpan={6} className="text-center text-[#484f58] italic p-4">No locations in script</td></tr>
              ) : locationReport.map((l, i) => (
                <tr key={i} className="border-b border-[#30363d]/50 hover:bg-[#161b22]">
                  <td className="p-1.5 text-[#34d399] font-bold">{l.location}</td>
                  <td className="p-1.5 text-[#8b949e]">{l.int_ext}</td>
                  <td className="p-1.5 text-right text-[#e6edf3] font-bold">{l.scene_count}</td>
                  <td className="p-1.5 text-right text-[#8b949e]">{l.total_pages}</td>
                  <td className="p-1.5 text-[#8b949e]">{l.day_night}</td>
                  <td className="p-1.5 text-[#8b949e]">{l.scenes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'character' && (
        <div className="glass-panel clip-corner p-3 overflow-x-auto">
          <table className="w-full text-[10px]">
            <thead>
              <tr className="border-b border-[#30363d] text-[#8b949e]">
                <th className="text-left p-1.5">Character</th>
                <th className="text-right p-1.5">Scenes</th>
                <th className="text-right p-1.5">Dialogue Lines</th>
                <th className="text-right p-1.5">Word Count</th>
                <th className="text-left p-1.5">First Scene</th>
              </tr>
            </thead>
            <tbody>
              {characterReport.length === 0 ? (
                <tr><td colSpan={5} className="text-center text-[#484f58] italic p-4">No characters in script</td></tr>
              ) : characterReport.map((c, i) => (
                <tr key={i} className="border-b border-[#30363d]/50 hover:bg-[#161b22]">
                  <td className="p-1.5 text-[#fbbf24] font-bold">{c.name}</td>
                  <td className="p-1.5 text-right text-[#e6edf3]">{c.scene_count}</td>
                  <td className="p-1.5 text-right text-[#8b949e]">{c.dialogue_lines}</td>
                  <td className="p-1.5 text-right text-[#8b949e]">{c.word_count}</td>
                  <td className="p-1.5 text-[#8b949e]">{c.first_scene}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'dialogue' && (
        <div className="glass-panel clip-corner p-4">
          <h4 className="text-[10px] font-bold text-[#4dd0e1] uppercase tracking-wider mb-3">Dialogue Distribution (Word Count per Character)</h4>
          {dialogueData.length === 0 ? (
            <p className="text-[10px] text-[#484f58] italic text-center py-8">No dialogue data</p>
          ) : (
            <div className="space-y-4">
              {/* Donut chart */}
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={dialogueData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} innerRadius={40} label={d => d.name}>
                    {dialogueData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: '#161b22', border: '1px solid #30363d', fontSize: '10px' }} />
                </PieChart>
              </ResponsiveContainer>
              {/* Bar chart */}
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={dialogueData} layout="vertical" margin={{ left: 80, right: 20 }}>
                  <XAxis type="number" tick={{ fill: '#8b949e', fontSize: 9 }} />
                  <YAxis type="category" dataKey="name" tick={{ fill: '#8b949e', fontSize: 9 }} width={80} />
                  <Tooltip contentStyle={{ background: '#161b22', border: '1px solid #30363d', fontSize: '10px' }} />
                  <Bar dataKey="value" name="Words">
                    {dialogueData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}
    </div>
  );
}