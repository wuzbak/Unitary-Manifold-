/**
 * ActorPortalPanel — Production-managed actor dashboard.
 * Select an actor → view their call times, script sides, character notes,
 * wardrobe fitting schedule, and production notes. Export actor packet as PDF.
 */
import { useState, useEffect, useCallback } from 'react';
import { User, Download, Loader2, Clock, FileText, Shirt, Calendar, MessageSquare } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { exportPDF } from '@/lib/filmers/filmExport';
import { logActivity } from '@/lib/filmers/activityLog';

export default function ActorPortalPanel({ project }) {
  const [cast, setCast] = useState([]);
  const [scenes, setScenes] = useState([]);
  const [shootDays, setShootDays] = useState([]);
  const [scripts, setScripts] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [loading, setLoading] = useState(true);
  const [editingNotes, setEditingNotes] = useState(false);
  const [notesDraft, setNotesDraft] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [c, s, d, sc] = await Promise.all([
        base44.entities.CastMember.filter({ project_id: project.id }),
        base44.entities.Scene.filter({ project_id: project.id }, 'sort_order', 500),
        base44.entities.ShootDay.filter({ project_id: project.id }, 'day_number', 200),
        base44.entities.Script.filter({ project_id: project.id }, '-imported_date', 5),
      ]);
      setCast(c); setScenes(s); setShootDays(d); setScripts(sc);
      if (c.length > 0 && !selectedId) setSelectedId(c[0].id);
    } catch { /* best-effort */ }
    finally { setLoading(false); }
  }, [project.id]);

  useEffect(() => { load(); }, [load]);

  const actor = cast.find(c => c.id === selectedId);

  // Find scenes where this actor's character appears
  const actorScenes = actor ? scenes.filter(s => {
    const charName = (actor.role || actor.name || '').toUpperCase();
    return (s.synopsis || '').toUpperCase().includes(charName);
  }) : [];

  // Find shoot days where this actor works
  const actorDays = actor ? shootDays.filter(d => {
    let sceneIds = [];
    try { sceneIds = JSON.parse(d.scenes_json || '[]'); } catch {}
    return sceneIds.some(id => actorScenes.some(s => s.id === id));
  }) : [];

  // Extract script sides (character's dialogue lines)
  const scriptSides = actor ? (() => {
    const latestScript = scripts[0];
    if (!latestScript?.elements_json) return [];
    try {
      const elements = JSON.parse(latestScript.elements_json);
      const sides = [];
      let inDialogue = false;
      let currentChar = '';
      for (let i = 0; i < elements.length; i++) {
        const el = elements[i];
        if (el.type === 'character') {
          currentChar = el.text.trim().toUpperCase();
          inDialogue = currentChar === (actor.role || actor.name || '').toUpperCase();
        }
        if (el.type === 'scene' && actorScenes.length > 0) {
          // Check if this scene is one the actor is in
          const sceneParsed = el.text;
          const matchingScene = actorScenes.find(s => sceneParsed.includes(s.location_text || ''));
        }
        if (inDialogue && (el.type === 'dialogue' || el.type === 'parenthetical')) {
          sides.push({ type: el.type, text: el.text, scene: el.scene_index });
        }
      }
      return sides;
    } catch { return []; }
  })() : [];

  const saveNotes = async () => {
    if (!actor) return;
    await base44.entities.CastMember.update(actor.id, { character_notes: notesDraft });
    setCast(cast.map(c => c.id === actor.id ? { ...c, character_notes: notesDraft } : c));
    setEditingNotes(false);
    logActivity(project.id, 'cast', actor.name, 'updated', 'character notes');
  };

  const exportPacket = () => {
    if (!actor) return;
    const lines = [
      '='.repeat(60),
      `  ACTOR PACKET — ${actor.name}`,
      `  Role: ${actor.role || 'TBD'}`,
      `  Project: ${project.title}`,
      '='.repeat(60),
      '',
      '  UPCOMING CALL TIMES:',
    ];
    actorDays.forEach(d => {
      lines.push(`  Day ${d.day_number} — ${d.date} — Call: ${d.crew_call} — Location: ${d.location_name || 'TBD'}`);
    });
    lines.push('', '  SCRIPT SIDES:');
    if (scriptSides.length === 0) {
      lines.push('  (No dialogue extracted — ensure script elements are synced)');
    } else {
      scriptSides.forEach(s => {
        if (s.type === 'parenthetical') lines.push(`    (${s.text})`);
        else lines.push(`    ${s.text}`);
      });
    }
    lines.push('', '  CHARACTER NOTES:');
    lines.push(`  ${actor.character_notes || '(none)'}`);
    if (actor.fitting_date) lines.push('', `  WARDROBE FITTING: ${actor.fitting_date}`);
    lines.push('', '='.repeat(60));
    exportPDF(`Actor Packet — ${actor.name}`, lines.join('\n'), `actor_packet_${actor.name.replace(/\s/g, '_')}.pdf`);
    logActivity(project.id, 'cast', actor.name, 'exported', 'actor packet');
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-[#fbbf24]" size={18} /></div>;

  return (
    <div className="space-y-3">
      {/* Actor selector */}
      <div className="glass-strong clip-corner p-3 flex items-center gap-2 flex-wrap">
        <User size={14} className="text-[#fbbf24]" />
        <span className="text-xs font-bold text-[#fbbf24]">Actor Portal</span>
        <select value={selectedId} onChange={e => setSelectedId(e.target.value)} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] flex-1 min-w-[150px]">
          <option value="">Select actor...</option>
          {cast.map(c => <option key={c.id} value={c.id}>{c.name} {c.role ? `as ${c.role}` : ''}</option>)}
        </select>
        {actor && (
          <button onClick={exportPacket} className="flex items-center gap-1 px-2.5 py-1.5 rounded text-[10px] font-bold bg-[#fbbf24] text-black">
            <Download size={10} /> Export Packet
          </button>
        )}
      </div>

      {cast.length === 0 ? (
        <div className="glass-panel clip-corner p-8 text-center">
          <User size={28} className="text-[#484f58] mx-auto mb-3" />
          <p className="text-xs text-[#8b949e]">No cast members yet. Add cast in the Cast tab first.</p>
        </div>
      ) : !actor ? (
        <div className="glass-panel clip-corner p-8 text-center">
          <p className="text-xs text-[#8b949e]">Select an actor to view their portal.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {/* Call times */}
          <div className="glass-panel clip-corner p-3">
            <div className="flex items-center gap-2 mb-2">
              <Clock size={12} className="text-[#f472b6]" />
              <span className="text-[10px] font-bold text-[#f472b6] uppercase tracking-wider">Call Times</span>
              <span className="text-[9px] text-[#484f58]">{actorDays.length} days</span>
            </div>
            {actorDays.length === 0 ? (
              <p className="text-[10px] text-[#484f58] italic">No scheduled days yet.</p>
            ) : (
              <div className="space-y-1">
                {actorDays.map(d => (
                  <div key={d.id} className="flex items-center gap-2 p-1.5 border border-[#30363d] rounded">
                    <span className="text-[9px] font-bold text-[#f472b6]">Day {d.day_number}</span>
                    <span className="text-[10px] text-[#e6edf3]">{d.date}</span>
                    <span className="text-[9px] text-[#8b949e]">Call: {d.crew_call}</span>
                    <span className="text-[9px] text-[#34d399] truncate">{d.location_name || 'TBD'}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Wardrobe & fitting */}
          <div className="glass-panel clip-corner p-3">
            <div className="flex items-center gap-2 mb-2">
              <Shirt size={12} className="text-[#a78bfa]" />
              <span className="text-[10px] font-bold text-[#a78bfa] uppercase tracking-wider">Wardrobe & Fitting</span>
            </div>
            <div className="space-y-1.5 text-[10px]">
              <div className="flex items-center gap-2">
                <Calendar size={10} className="text-[#484f58]" />
                <span className="text-[#8b949e]">Fitting date:</span>
                <input type="date" value={actor.fitting_date || ''} onChange={async e => { await base44.entities.CastMember.update(actor.id, { fitting_date: e.target.value }); setCast(cast.map(c => c.id === actor.id ? { ...c, fitting_date: e.target.value } : c)); }} className="bg-[#0B0F13] border border-[#30363d] rounded px-2 py-1 text-[10px] text-[#e6edf3]" />
              </div>
              <div className="text-[#8b949e]">Wardrobe sizes: <span className="text-[#e6edf3]">{(() => { try { return JSON.stringify(JSON.parse(actor.wardrobe_sizes_json || '{}')); } catch { return 'not set'; } })()}</span></div>
            </div>
          </div>

          {/* Script sides */}
          <div className="glass-panel clip-corner p-3">
            <div className="flex items-center gap-2 mb-2">
              <FileText size={12} className="text-[#4dd0e1]" />
              <span className="text-[10px] font-bold text-[#4dd0e1] uppercase tracking-wider">Script Sides</span>
              <span className="text-[9px] text-[#484f58]">{scriptSides.length} lines</span>
            </div>
            {scriptSides.length === 0 ? (
              <p className="text-[10px] text-[#484f58] italic">No dialogue extracted. Ensure the script is written in the Script tab editor and the character name matches the role field.</p>
            ) : (
              <div className="space-y-1 max-h-48 overflow-y-auto">
                {scriptSides.map((s, i) => (
                  <div key={i} className={`text-[10px] font-mono ${s.type === 'parenthetical' ? 'text-[#8b949e] italic pl-4' : 'text-[#e6edf3]'}`}>
                    {s.type === 'parenthetical' ? `(${s.text})` : s.text}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Character notes */}
          <div className="glass-panel clip-corner p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <MessageSquare size={12} className="text-[#fbbf24]" />
                <span className="text-[10px] font-bold text-[#fbbf24] uppercase tracking-wider">Character Notes</span>
              </div>
              {!editingNotes && <button onClick={() => { setNotesDraft(actor.character_notes || ''); setEditingNotes(true); }} className="text-[9px] text-[#fbbf24] hover:underline">Edit</button>}
            </div>
            {editingNotes ? (
              <div className="space-y-2">
                <textarea value={notesDraft} onChange={e => setNotesDraft(e.target.value)} rows={5} placeholder="Backstory, motivation, arc notes..." className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-[10px] text-[#e6edf3] resize-y" />
                <div className="flex gap-2">
                  <button onClick={saveNotes} className="px-2.5 py-1 bg-[#fbbf24] text-black rounded text-[10px] font-bold">Save</button>
                  <button onClick={() => setEditingNotes(false)} className="px-2.5 py-1 bg-[#161b22] border border-[#30363d] rounded text-[10px] text-[#8b949e]">Cancel</button>
                </div>
              </div>
            ) : (
              <p className="text-[10px] text-[#e6edf3] whitespace-pre-wrap">{actor.character_notes || '(no character notes yet — click Edit to add)'}</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}