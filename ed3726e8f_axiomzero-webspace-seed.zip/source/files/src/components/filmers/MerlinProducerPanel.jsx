/**
 * MerlinProducerPanel — Film production expert chat (UPM/Producer/Department Assistant).
 * Uses the merlinFilmExpert persona with live project context injection.
 */
import { useState, useRef, useEffect } from 'react';
import { Sparkles, X, Send, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { buildFilmExpertPrompt } from '@/lib/merlinFilmExpert';
import { parseMerlinResponse } from '@/components/quantum-cat/parseMerlinResponse';

const SUGGESTED = [
  'Analyze my script structure — is the three-act shape working?',
  'Which characters need more development?',
  'What props and set dressing does my script imply?',
  'Optimize my shooting schedule — which scenes should group together?',
  'Check my turnaround compliance — any 12-hour violations?',
  'How much overtime am I burning? Which departments are over?',
  'Which permits are expiring soon? What do I need to renew?',
  'What should I prioritize for this production?',
  'Check my budget allocation against standards',
  'Which departments need the most prep attention?',
  'Generate a call sheet for my next shoot day',
  'How do I optimize my day-out-of-days to reduce cast hold days?',
];

export default function MerlinProducerPanel({ project, isOpen, onClose }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, [messages, loading]);

  const buildContext = async () => {
    if (!project) {
      return 'NO PROJECT SELECTED — The user is in sandbox mode. Help them create or select a project from the Projects tab, or answer general production questions.';
    }
    const [scenes, cast, crew, items, scripts, shootDays, timeCards, permits, credits, resources] = await Promise.all([
      base44.entities.Scene.filter({ project_id: project.id }),
      base44.entities.CastMember.filter({ project_id: project.id }),
      base44.entities.CrewMember.filter({ project_id: project.id }),
      base44.entities.DepartmentItem.filter({ project_id: project.id }),
      base44.entities.Script.filter({ project_id: project.id }, '-imported_date', 5),
      base44.entities.ShootDay.filter({ project_id: project.id }, 'day_number', 50),
      base44.entities.TimeCard.filter({ project_id: project.id }, '-shoot_date', 50),
      base44.entities.Permit.filter({ project_id: project.id }),
      base44.entities.FilmCredit.filter({ project_id: project.id }),
      base44.entities.LocalResource.filter({ project_id: project.id }),
    ]);
    const deptSummary = {};
    items.forEach(i => { deptSummary[i.department] = (deptSummary[i.department] || 0) + 1; });

    // Script analysis
    let scriptSummary = 'No scripts yet.';
    if (scripts.length > 0) {
      const latest = scripts[0];
      let elCount = 0, sceneCount = 0, charSet = new Set();
      try {
        const els = latest.elements_json ? JSON.parse(latest.elements_json) : [];
        elCount = els.length;
        sceneCount = els.filter(e => e.type === 'scene').length;
        els.filter(e => e.type === 'character').forEach(e => charSet.add(e.text.toUpperCase()));
      } catch {}
      scriptSummary = `Latest: "${latest.title}" (${latest.revision_color}) | ${elCount} elements | ${sceneCount} scenes | ${charSet.size} characters | Last edited: ${latest.last_edited || 'N/A'}`;
    }

    // Labor summary
    const approvedTC = timeCards.filter(tc => tc.status === 'approved');
    const pendingTC = timeCards.filter(tc => tc.status === 'pending');
    const laborCost = approvedTC.reduce((s, tc) => s + (tc.total_pay || 0), 0);
    const otTotal = approvedTC.reduce((s, tc) => s + (tc.ot_hours || 0), 0);

    // Permit summary
    const approvedPermits = permits.filter(p => p.status === 'approved').length;
    const pendingPermits = permits.filter(p => p.status === 'applied' || p.status === 'pending').length;
    const today = new Date().toISOString().split('T')[0];
    const expiringPermits = permits.filter(p => p.expiry_date && p.expiry_date <= today && p.status === 'approved');

    return `LIVE PROJECT DATA:
Title: ${project.title} | Status: ${project.status} | Budget: $${project.total_budget || 0} | Shoot Days: ${project.shoot_days || 0}
Scenes: ${scenes.length} | Cast: ${cast.length} | Crew: ${crew.length} | Department Items: ${items.length}
Department breakdown: ${Object.entries(deptSummary).map(([k, v]) => `${k}(${v})`).join(', ') || 'none'}
Cast: ${cast.map(c => `${c.name} (${c.role || 'TBD'}, ${c.sag_status})`).join('; ') || 'none'}
Crew: ${crew.map(c => `${c.name} (${c.department}/${c.position || 'TBD'}, ${c.above_below_line || 'below_line'})`).join('; ') || 'none'}
SCRIPT: ${scriptSummary}
SCHEDULE: ${shootDays.length} shoot days scheduled | ${shootDays.filter(d => d.status === 'shooting').length} shooting | ${shootDays.filter(d => d.status === 'wrapped').length} wrapped
LABOR: ${timeCards.length} time cards | ${approvedTC.length} approved | ${pendingTC.length} pending | Labor cost: $${laborCost.toLocaleString()} | OT: ${otTotal}h
PERMITS: ${permits.length} total | ${approvedPermits} approved | ${pendingPermits} pending | ${expiringPermits.length} expiring/expired
CREDITS: ${credits.length} (${credits.filter(c => c.credit_tier === 'above_line').length} ATL / ${credits.filter(c => c.credit_tier === 'below_line').length} BTL)
LOCAL RESOURCES: ${resources.length} resources`;
  };

  const send = async (text) => {
    const msg = text || input;
    if (!msg.trim() || loading) return;
    setInput('');
    setMessages(m => [...m, { role: 'user', content: msg }]);
    setLoading(true);
    try {
      const projectContext = await buildContext();
      const systemPrompt = buildFilmExpertPrompt() + '\n\n' + projectContext;
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `${systemPrompt}\n\nUSER QUESTION: ${msg}`,
        model: 'claude_sonnet_4_6',
      });
      const parsed = parseMerlinResponse(res);
      setMessages(m => [...m, { role: 'assistant', content: parsed.body || res, sources: parsed.sources, followUps: parsed.followups }]);
    } catch (e) {
      setMessages(m => [...m, { role: 'assistant', content: `Error: ${e.message}` }]);
    }
    setLoading(false);
  };

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/60 backdrop-blur-sm" onClick={onClose}>
          <div className="glass-strong clip-corner w-full max-w-2xl h-[80vh] md:h-[600px] flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-3 border-b border-[#30363d]">
              <div className="flex items-center gap-2">
                <Sparkles size={14} className="text-[#fbbf24]" />
                <span className="text-xs font-bold text-[#fbbf24]">Merlin — UPM / Producer Expert</span>
              </div>
              <button onClick={onClose} className="text-[#484f58] hover:text-[#e6edf3]"><X size={16} /></button>
            </div>
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-3">
              {messages.length === 0 && (
                <div className="text-center py-8">
                  <Sparkles size={24} className="text-[#fbbf24] mx-auto mb-3" />
                  <p className="text-xs text-[#8b949e] mb-4">{project ? "I'm your production expert. I can see your project data in real-time." : "I'm your production expert. Create or select a project, or ask me general production questions."}</p>
                  <div className="flex flex-col gap-2 max-w-sm mx-auto">
                    {SUGGESTED.map(s => (
                      <button key={s} onClick={() => send(s)} className="text-left text-[10px] text-[#e6edf3] bg-[#161b22] border border-[#30363d] rounded p-2 hover:border-[#fbbf24]/40 transition-colors">{s}</button>
                    ))}
                  </div>
                </div>
              )}
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] rounded p-2.5 text-[10px] ${m.role === 'user' ? 'bg-[#fbbf24] text-black' : 'bg-[#161b22] border border-[#30363d] text-[#e6edf3]'}`}>
                    <div className="whitespace-pre-wrap leading-relaxed">{m.content}</div>
                    {m.sources?.length > 0 && (
                      <div className="mt-2 pt-2 border-t border-[#30363d] space-y-1">
                        {m.sources.map((s, j) => <div key={j} className="text-[9px] text-[#58a6ff]">{s.label || JSON.stringify(s)}</div>)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {loading && <div className="flex justify-center"><Loader2 className="animate-spin text-[#fbbf24]" size={16} /></div>}
            </div>
            <div className="p-3 border-t border-[#30363d] flex gap-2">
              <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Ask Merlin about your production..." className="flex-1 bg-[#0B0F13] border border-[#30363d] rounded px-3 py-2 text-xs text-[#e6edf3] focus:border-[#fbbf24]/40" />
              <button onClick={() => send()} disabled={loading} className="px-3 py-2 bg-[#fbbf24] text-black rounded text-xs font-bold disabled:opacity-40"><Send size={12} /></button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}