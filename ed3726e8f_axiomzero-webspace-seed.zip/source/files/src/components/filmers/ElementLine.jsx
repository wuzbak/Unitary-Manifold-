/**
 * ElementLine — Single screenplay element renderer with type-aware styling.
 * Used by ScreenplayEditor for both Draft and Layout views.
 */
import { useRef, useEffect } from 'react';
import { TYPE_LABELS, TYPE_COLORS } from '@/lib/filmers/fountainSerializer';

const TYPE_CLASS = {
  scene: 'font-bold uppercase tracking-wide',
  action: '',
  character: 'uppercase text-center',
  dialogue: '',
  parenthetical: 'italic',
  transition: 'uppercase text-right',
  shot: 'uppercase font-bold',
  act_break: 'uppercase font-bold text-center',
  note: 'italic',
};

// Indentation in Tailwind classes (layout view)
const LAYOUT_INDENT = {
  scene: '',
  action: '',
  character: 'pl-[25%]',
  dialogue: 'pl-[15%] pr-[20%]',
  parenthetical: 'pl-[20%] pr-[25%]',
  transition: 'pl-[50%]',
  shot: '',
  act_break: 'text-center',
  note: 'pl-[10%]',
};

export default function ElementLine({
  element, index, isActive, viewMode, autoFocus,
  onChange, onTypeChange, onKeyDown, onFocus, castNames, locationNames,
}) {
  const ref = useRef(null);
  const type = element.type;
  const color = TYPE_COLORS[type] || '#e6edf3';
  const isMultiline = ['action', 'dialogue', 'note'].includes(type);

  // Auto-resize textarea
  useEffect(() => {
    if (ref.current) {
      ref.current.style.height = 'auto';
      ref.current.style.height = ref.current.scrollHeight + 'px';
    }
  }, [element.text]);

  // Auto-focus on new elements
  useEffect(() => {
    if (autoFocus && ref.current) {
      ref.current.focus();
      const len = ref.current.value.length;
      ref.current.setSelectionRange(len, len);
    }
  }, [autoFocus]);

  const handleChange = (e) => {
    onChange(index, e.target.value);
    // Auto-resize
    e.target.style.height = 'auto';
    e.target.style.height = e.target.scrollHeight + 'px';
  };

  const handleKeyDown = (e) => onKeyDown(e, index);

  // Layout view: read-only formatted display
  if (viewMode === 'layout') {
    const text = (element.text || '').trim();
    if (!text) return null;
    return (
      <div className={`text-xs font-mono leading-relaxed py-0.5 ${TYPE_CLASS[type]} ${LAYOUT_INDENT[type]}`}
        style={{ color: type === 'note' ? '#8b949e' : '#e6edf3' }}
        onClick={() => onFocus(index)}
      >
        {type === 'parenthetical' ? `(${text})` : text}
      </div>
    );
  }

  // Draft view: editable textarea with type indicator
  return (
    <div className={`flex items-start gap-1.5 group ${isActive ? 'bg-[#a78bfa]/5' : ''} rounded transition-colors`}>
      {/* Type indicator */}
      <button
        onClick={() => onTypeChange(index)}
        className="text-[7px] font-bold uppercase tracking-wider px-1.5 py-1 rounded shrink-0 mt-0.5 border transition-colors hover:brightness-125"
        style={{ color, borderColor: `${color}40`, background: `${color}10`, minWidth: '52px' }}
        title={`Click to change type (${TYPE_LABELS[type]})`}
      >
        {TYPE_LABELS[type]}
      </button>
      {/* Editable textarea */}
      <textarea
        ref={ref}
        value={element.text}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onFocus={() => onFocus(index)}
        rows={1}
        className={`flex-1 bg-transparent border-none outline-none resize-none text-xs font-mono leading-relaxed ${TYPE_CLASS[type]} ${LAYOUT_INDENT[type]}`}
        style={{ color: '#e6edf3', caretColor: color }}
        placeholder={type === 'scene' ? 'INT. LOCATION - DAY' : type === 'character' ? 'CHARACTER NAME' : type === 'dialogue' ? 'Dialogue...' : ''}
        data-index={index}
      />
    </div>
  );
}