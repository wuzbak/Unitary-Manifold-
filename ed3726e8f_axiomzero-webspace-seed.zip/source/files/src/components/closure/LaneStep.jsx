import { CheckCircle, AlertTriangle, Clock, ChevronDown, ChevronUp, Lock } from 'lucide-react';

const STATUS_CONFIG = {
  PASS: { color: '#3fb950', icon: CheckCircle, label: 'PASS' },
  BLOCKED: { color: '#f85149', icon: AlertTriangle, label: 'BLOCKED' },
  PARTIAL: { color: '#FF9F00', icon: Clock, label: 'PARTIAL' },
  TENSION: { color: '#FF9F00', icon: AlertTriangle, label: 'TENSION' },
};

export default function LaneStep({ lane, index, isExpanded, onToggle }) {
  const config = STATUS_CONFIG[lane.status] || STATUS_CONFIG.PARTIAL;
  const Icon = config.icon;

  return (
    <div
      className={`border clip-corner transition-colors ${
        isExpanded ? 'border-[#4dd0e1]/30 bg-[#4dd0e1]/5' : 'border-[#30363d] bg-[#0d1117] hover:border-[#4dd0e1]/20'
      }`}
    >
      {/* Lane header */}
      <button
        onClick={() => onToggle(index)}
        className="w-full flex items-center gap-2 p-2.5 text-left touch-manipulation"
      >
        <span className="text-[9px] font-mono text-[#484f58] shrink-0 w-8">LANE {index + 1}</span>
        <Icon size={14} className="shrink-0" style={{ color: config.color }} />
        <div className="flex-1 min-w-0">
          <div className="text-[10px] font-bold text-[#e6edf3] truncate">{lane.name}</div>
          <div className="text-[7px] text-[#484f58] font-mono">{lane.pillar}</div>
        </div>
        <span
          className="text-[7px] font-bold px-1.5 py-0.5 clip-corner border shrink-0"
          style={{ color: config.color, borderColor: `${config.color}40`, backgroundColor: `${config.color}10` }}
        >
          {config.label}
        </span>
        {isExpanded ? <ChevronUp size={12} className="text-[#484f58] shrink-0" /> : <ChevronDown size={12} className="text-[#484f58] shrink-0" />}
      </button>

      {/* Expanded content */}
      {isExpanded && (
        <div className="px-2.5 pb-2.5 space-y-2">
          <p className="text-[9px] text-[#8b949e] leading-relaxed">{lane.description}</p>
          <div className="p-2 border border-[#30363d] bg-[#0a0d11] clip-corner">
            <div className="text-[7px] text-[#484f58] uppercase mb-1">Attempt Result</div>
            <div className="text-[9px] text-[#e6edf3] leading-relaxed">{lane.detail}</div>
          </div>
          <div className="p-2 border-l-2 border-[#FF9F00]/30 bg-[#FF9F00]/5 clip-corner">
            <div className="flex items-center gap-1 mb-0.5">
              <Lock size={9} className="text-[#FF9F00]" />
              <span className="text-[7px] text-[#FF9F00] font-bold uppercase tracking-wider">Certificate</span>
            </div>
            <code className="text-[8px] text-[#8b949e] font-mono leading-relaxed block">{lane.certificate}</code>
          </div>
        </div>
      )}
    </div>
  );
}