/**
 * MedicinalTab — Medicinal Herbs body-systems index with search and filtering.
 * Extracted from BotanicaOS for the unified TerraOS page.
 */
import { useState, useMemo } from 'react';
import { MEDICINAL_HERBS } from '@/lib/sciCompute/botanica';
import { Flower2, Search } from 'lucide-react';

export function MedicinalTab() {
  const [search, setSearch] = useState('');
  const [systemFilter, setSystemFilter] = useState('All');

  const systems = useMemo(() => ['All', ...new Set(MEDICINAL_HERBS.map(h => h.system))], []);

  const filtered = useMemo(() => {
    return MEDICINAL_HERBS.filter(h => {
      const matchSystem = systemFilter === 'All' || h.system === systemFilter;
      const q = search.toLowerCase();
      const matchSearch = !q || h.herb.toLowerCase().includes(q) || h.condition.toLowerCase().includes(q) || h.compound.toLowerCase().includes(q) || h.action.toLowerCase().includes(q);
      return matchSystem && matchSearch;
    });
  }, [search, systemFilter]);

  const grouped = useMemo(() => {
    const map = {};
    filtered.forEach(h => { if (!map[h.system]) map[h.system] = []; map[h.system].push(h); });
    return map;
  }, [filtered]);

  return (
    <div className="space-y-4">
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3">
          <Flower2 size={14} className="text-[#FF9F00]" />
          <span className="text-xs font-bold text-[#FF9F00]">Medicinal Herbs — Body-Systems Index</span>
          <span className="text-[8px] text-[#484f58] border border-[#30363d] rounded px-1.5 py-0.5">4-IMPLICATIONS/botanical/MEDICINAL_HERBS.md</span>
        </div>
        <div className="flex flex-col md:flex-row gap-2">
          <div className="relative flex-1">
            <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-[#484f58]" />
            <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search herbs, conditions, compounds..." className="w-full bg-[#0d1117] border border-[#30363d] rounded pl-7 pr-2 py-1.5 text-xs text-[#e6edf3]" />
          </div>
          <select value={systemFilter} onChange={e => setSystemFilter(e.target.value)} className="bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-xs text-[#e6edf3]">
            {systems.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div className="text-[10px] text-[#484f58] mt-2">{filtered.length} herbs · Educational use only — consult a qualified practitioner for chronic or serious conditions.</div>
      </div>

      {Object.entries(grouped).map(([system, herbs]) => (
        <div key={system} className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
          <div className="text-xs font-bold text-[#FF9F00] mb-3">{system}</div>
          <div className="overflow-x-auto">
            <table className="w-full text-[10px]">
              <thead>
                <tr className="text-[#484f58] border-b border-[#30363d]">
                  <th className="text-left py-1.5 px-2">Herb</th>
                  <th className="text-left py-1.5 px-2">Tradition</th>
                  <th className="text-left py-1.5 px-2">Condition</th>
                  <th className="text-left py-1.5 px-2">Key Compound(s)</th>
                  <th className="text-left py-1.5 px-2">Action</th>
                  <th className="text-left py-1.5 px-2">Preparation</th>
                </tr>
              </thead>
              <tbody>
                {herbs.map((h, i) => (
                  <tr key={i} className="border-b border-[#30363d]/50 hover:bg-[#0d1117]/50">
                    <td className="py-1.5 px-2 font-bold text-[#e6edf3]">{h.herb}</td>
                    <td className="py-1.5 px-2 text-[#8b949e]">{h.tradition}</td>
                    <td className="py-1.5 px-2 text-[#8b949e]">{h.condition}</td>
                    <td className="py-1.5 px-2 text-[#3fb950]">{h.compound}</td>
                    <td className="py-1.5 px-2 text-[#8b949e]">{h.action}</td>
                    <td className="py-1.5 px-2 text-[#8b949e]">{h.preparation}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </div>
  );
}