/**
 * GrowingGuideTab — Growing conditions assessment for plants.
 * Extracted from BotanicaOS for the unified TerraOS page.
 */
import { useState } from 'react';
import ComputeLoader from '@/components/shared/ComputeLoader';
import { assessGrowingConditions, PLANTS } from '@/lib/sciCompute/botanica';
import { Sprout } from 'lucide-react';

export function GrowingGuideTab() {
  const [plantName, setPlantName] = useState(PLANTS[0].name);
  const [soilPh, setSoilPh] = useState(6.5);
  const [sunlight, setSunlight] = useState('Partial Sun');
  const [water, setWater] = useState('Medium');
  const [zone, setZone] = useState('8');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const runAssessment = async () => {
    setLoading(true);
    setResult(null);
    try {
      const res = await assessGrowingConditions({ plantName, soilPh, sunlight, water, zone });
      setResult(res);
    } catch (e) {
      setResult({ error: e.message });
    }
    setLoading(false);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3">
          <Sprout size={14} className="text-[#3fb950]" />
          <span className="text-xs font-bold text-[#3fb950]">Growing Conditions Assessment</span>
          <span className="text-[8px] text-[#484f58] border border-[#30363d] rounded px-1.5 py-0.5">USDA Hardiness · NRCS</span>
        </div>
        <div className="space-y-3">
          <div>
            <label className="text-[10px] text-[#8b949e] block mb-1">Plant</label>
            <select value={plantName} onChange={e => setPlantName(e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-xs text-[#e6edf3]">
              {PLANTS.map(p => <option key={p.name}>{p.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-[10px] text-[#8b949e] block mb-1">Soil pH: <span className="text-[#3fb950] font-bold">{soilPh.toFixed(1)}</span></label>
            <input type="range" min="3" max="9" step="0.1" value={soilPh} onChange={e => setSoilPh(+e.target.value)} className="w-full accent-[#3fb950]" />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-[10px] text-[#8b949e] block mb-1">Sunlight</label>
              <select value={sunlight} onChange={e => setSunlight(e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-xs text-[#e6edf3]">
                <option>Full Sun</option><option>Partial Sun</option><option>Shade</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] text-[#8b949e] block mb-1">Water</label>
              <select value={water} onChange={e => setWater(e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-xs text-[#e6edf3]">
                <option>Low</option><option>Medium</option><option>High</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] text-[#8b949e] block mb-1">Zone</label>
              <select value={zone} onChange={e => setZone(e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-xs text-[#e6edf3]">
                {['3','4','5','6','7','8','9','10','11'].map(z => <option key={z}>{z}</option>)}
              </select>
            </div>
          </div>
          <button onClick={runAssessment} disabled={loading} className="w-full bg-gradient-to-r from-[#3fb950] to-[#30d158] text-black py-2 rounded text-xs font-bold disabled:opacity-50">Assess Growing Conditions</button>
        </div>
      </div>
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="text-xs font-bold text-[#e6edf3] mb-3">Growing Compatibility Report</div>
        {loading ? (
          <ComputeLoader engine="math.js BigNumber" detail="Computing pH, sunlight, water, and zone compatibility scores" />
        ) : !result ? (
          <div className="text-xs text-[#8b949e] py-8 text-center">Select a plant and enter site conditions to receive a compatibility assessment.</div>
        ) : result.error ? (
          <div className="text-xs text-red-400 py-4 text-center">Error: {result.error}</div>
        ) : (
          <div className="space-y-3">
            <div className="bg-[#0d1117] border border-[#30363d] rounded p-3 text-center">
              <div className="text-3xl font-bold text-[#3fb950]">{result.score}/100</div>
              <div className="text-[10px] text-[#8b949e]">{result.classification}</div>
            </div>
            <div className="bg-[#0d1117] border border-[#30363d] rounded p-2">
              <div className="text-[9px] text-[#484f58] uppercase tracking-wider mb-1.5">Score Components</div>
              <div className="grid grid-cols-2 gap-1.5">
                {[['pH Score', result.components.phScore, '#3fb950'],['Sunlight Score', result.components.sunScore, '#FF9F00'],['Water Score', result.components.waterScore, '#3b8bff'],['Zone Score', result.components.zoneScore, '#3fb950']].map(([label, val, color]) => (
                  <div key={label} className="flex items-center justify-between text-[10px]">
                    <span className="text-[#8b949e]">{label}</span>
                    <span className="font-mono font-bold" style={{ color }}>{typeof val === 'number' ? val.toFixed(1) : val}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-1">Recommendations:</div>
              <ul className="text-[10px] text-[#e6edf3] space-y-1 list-disc pl-4">
                {result.recs.map((r, i) => <li key={i}>{r}</li>)}
              </ul>
            </div>
            <div className="pt-2 border-t border-[#30363d]">
              <div className="text-[9px] text-[#3fb950] font-bold mb-0.5">SHA-256 Attestation</div>
              <div className="text-[9px] text-[#3fb950] font-mono break-all bg-[#0d1117] border border-[#30363d] rounded p-1.5">{result.hash}</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}