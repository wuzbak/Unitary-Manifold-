/**
 * GuildVisualizer — Dual-mode companion planting visualizer.
 *
 * Mode 1: Network Graph — force-directed node-edge graph where each species
 *   is a node, beneficial pairs are green edges, antagonistic pairs are red
 *   edges. Node size/color reflects soil+water compatibility score.
 *
 * Mode 2: Spatial Garden Bed — top-down layout showing physical plant
 *   placement. Companion clusters grouped by guild role, antagonists
 *   separated. Soil/water zones rendered as background heatmap.
 *
 * Both renderers use Canvas 2D and accept guild composition + soil/water
 * scores as props, re-rendering on change.
 */
import { useState, useRef, useEffect, useCallback } from 'react';
import { Network, LayoutGrid } from 'lucide-react';

const BENEFICIAL_COLOR = '#30d158';
const ANTAGONIST_COLOR = '#ff7a45';
const TARGET_COLOR = '#FF9F00';

export function GuildVisualizer({ guild, soilResult, waterResult }) {
  const [mode, setMode] = useState('network');
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const [hovered, setHovered] = useState(null);

  // Compute soil/water compatibility score (0-1) for background coloring
  const envScore = useCallback(() => {
    let score = 0.5;
    if (soilResult?.score != null) score += (soilResult.score / 100) * 0.25;
    if (waterResult?.wqi != null) score += (waterResult.wqi / 100) * 0.25;
    return Math.min(1, score);
  }, [soilResult, waterResult]);

  // Build node/edge data from guild result
  const graphData = useCallback(() => {
    if (!guild) return { nodes: [], edges: [] };
    const nodes = [];
    const edges = [];
    // Target plant is the central node
    nodes.push({
      id: guild.targetPlant,
      label: guild.targetPlant,
      role: 'Target',
      score: 100,
      isTarget: true,
      x: 0, y: 0, vx: 0, vy: 0,
    });
    // Guild members
    for (const m of guild.guild || []) {
      nodes.push({
        id: m.plant,
        label: m.plant,
        role: m.role,
        score: m.score || 50,
        isTarget: false,
        x: 0, y: 0, vx: 0, vy: 0,
      });
      // Beneficial edge from target to member
      edges.push({ from: guild.targetPlant, to: m.plant, type: 'beneficial' });
    }
    // Beneficial edges between guild members (from beneficials list)
    const memberSet = new Set(nodes.map(n => n.id));
    for (const ben of guild.beneficials || []) {
      if (memberSet.has(ben.plant) && ben.plant !== guild.targetPlant) {
        edges.push({ from: guild.targetPlant, to: ben.plant, type: 'beneficial' });
      }
    }
    // Antagonist nodes (placed far away)
    for (const ant of guild.antagonists || []) {
      if (!memberSet.has(ant.plant)) {
        nodes.push({
          id: ant.plant,
          label: ant.plant,
          role: 'Avoid',
          score: 0,
          isAntagonist: true,
          x: 0, y: 0, vx: 0, vy: 0,
        });
      }
      edges.push({ from: guild.targetPlant, to: ant.plant, type: 'antagonistic' });
    }
    return { nodes, edges };
  }, [guild]);

  // Force-directed layout simulation
  const runForceLayout = useCallback((nodes, edges, width, height) => {
    const cx = width / 2;
    const cy = height / 2;
    // Initialize positions in a circle
    nodes.forEach((n, i) => {
      if (n.isTarget) {
        n.x = cx; n.y = cy;
      } else if (n.isAntagonist) {
        const angle = (i / nodes.length) * Math.PI * 2;
        n.x = cx + Math.cos(angle) * Math.min(width, height) * 0.42;
        n.y = cy + Math.sin(angle) * Math.min(width, height) * 0.42;
      } else {
        const angle = (i / nodes.length) * Math.PI * 2;
        n.x = cx + Math.cos(angle) * 120;
        n.y = cy + Math.sin(angle) * 120;
      }
      n.vx = 0; n.vy = 0;
    });

    const iterations = 200;
    const repulsion = 6000;
    const attraction = 0.02;
    const damping = 0.85;
    const centerForce = 0.003;

    for (let iter = 0; iter < iterations; iter++) {
      // Repulsive forces between all nodes
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          let dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 1) dist = 1;
          const force = repulsion / (dist * dist);
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;
          if (!nodes[i].isTarget) { nodes[i].vx += fx; nodes[i].vy += fy; }
          if (!nodes[j].isTarget) { nodes[j].vx -= fx; nodes[j].vy -= fy; }
        }
      }
      // Attractive forces along edges
      for (const edge of edges) {
        const a = nodes.find(n => n.id === edge.from);
        const b = nodes.find(n => n.id === edge.to);
        if (!a || !b) continue;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const targetDist = edge.type === 'antagonistic' ? 250 : 90;
        const force = (dist - targetDist) * attraction;
        const fx = (dx / dist) * force;
        const fy = (dy / dist) * force;
        if (!a.isTarget) { a.vx += fx; a.vy += fy; }
        if (!b.isTarget) { b.vx -= fx; b.vy -= fy; }
      }
      // Centering force + apply velocity
      for (const n of nodes) {
        if (n.isTarget) continue;
        n.vx += (cx - n.x) * centerForce;
        n.vy += (cy - n.y) * centerForce;
        n.vx *= damping;
        n.vy *= damping;
        n.x += n.vx;
        n.y += n.vy;
        // Keep within bounds
        n.x = Math.max(30, Math.min(width - 30, n.x));
        n.y = Math.max(25, Math.min(height - 25, n.y));
      }
    }
  }, []);

  // Draw network graph
  const drawNetwork = useCallback((ctx, width, height) => {
    const { nodes, edges } = graphData();
    if (nodes.length === 0) return;
    runForceLayout(nodes, edges, width, height);

    // Draw edges
    for (const edge of edges) {
      const a = nodes.find(n => n.id === edge.from);
      const b = nodes.find(n => n.id === edge.to);
      if (!a || !b) continue;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.strokeStyle = edge.type === 'antagonistic'
        ? 'rgba(255,122,69,0.5)'
        : 'rgba(48,209,88,0.4)';
      ctx.lineWidth = edge.type === 'antagonistic' ? 1.5 : 2;
      ctx.setLineDash(edge.type === 'antagonistic' ? [4, 4] : []);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Draw nodes
    for (const n of nodes) {
      const radius = n.isTarget ? 16 : Math.max(6, (n.score / 100) * 12 + 4);
      ctx.beginPath();
      ctx.arc(n.x, n.y, radius, 0, Math.PI * 2);
      if (n.isTarget) {
        ctx.fillStyle = TARGET_COLOR;
      } else if (n.isAntagonist) {
        ctx.fillStyle = ANTAGONIST_COLOR;
      } else {
        // Green with opacity based on score
        const alpha = 0.3 + (n.score / 100) * 0.7;
        ctx.fillStyle = `rgba(48,209,88,${alpha})`;
      }
      ctx.fill();
      ctx.strokeStyle = n.isTarget ? '#fff' : n.isAntagonist ? ANTAGONIST_COLOR : BENEFICIAL_COLOR;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Label
      ctx.fillStyle = '#e6edf3';
      ctx.font = `${n.isTarget ? 'bold ' : ''}10px 'JetBrains Mono', monospace`;
      ctx.textAlign = 'center';
      ctx.fillText(n.label, n.x, n.y + radius + 12);
      // Role label
      if (!n.isTarget) {
        ctx.fillStyle = '#484f58';
        ctx.font = '8px monospace';
        ctx.fillText(n.role, n.x, n.y + radius + 22);
      }
    }
  }, [graphData, runForceLayout]);

  // Draw spatial garden bed
  const drawSpatial = useCallback((ctx, width, height) => {
    const { nodes } = graphData();
    if (nodes.length === 0) return;
    const cx = width / 2;
    const cy = height / 2;
    const es = envScore();

    // Background heatmap — soil/water compatibility zones
    const gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(width, height) * 0.5);
    if (es > 0.7) {
      gradient.addColorStop(0, 'rgba(48,209,88,0.15)');
      gradient.addColorStop(0.5, 'rgba(48,209,88,0.06)');
      gradient.addColorStop(1, 'rgba(48,209,88,0.01)');
    } else if (es > 0.4) {
      gradient.addColorStop(0, 'rgba(255,159,0,0.12)');
      gradient.addColorStop(0.5, 'rgba(255,159,0,0.05)');
      gradient.addColorStop(1, 'rgba(255,159,0,0.01)');
    } else {
      gradient.addColorStop(0, 'rgba(255,122,69,0.12)');
      gradient.addColorStop(0.5, 'rgba(255,122,69,0.05)');
      gradient.addColorStop(1, 'rgba(255,122,69,0.01)');
    }
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Draw concentric ring guides
    const rings = [60, 110, 160, 210];
    for (const r of rings) {
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(48,79,88,0.3)';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 4]);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Place target in center
    const targetNode = nodes.find(n => n.isTarget);
    if (targetNode) {
      ctx.beginPath();
      ctx.arc(cx, cy, 18, 0, Math.PI * 2);
      ctx.fillStyle = TARGET_COLOR;
      ctx.fill();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = '#000';
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(targetNode.label.substring(0, 8), cx, cy + 3);
    }

    // Place guild members in rings by layer
    const members = nodes.filter(n => !n.isTarget && !n.isAntagonist);
    const layerMap = { 'Canopy': 0, 'Sub-canopy': 1, 'Shrub': 2, 'Herbaceous': 3, 'Ground cover': 4, 'Climber/Vine': 5 };
    const ringMembers = [[], [], [], [], [], []];
    members.forEach(m => {
      const ringIdx = layerMap[m.role] != null ? layerMap[m.role] : 3;
      ringMembers[ringIdx].push(m);
    });

    ringMembers.forEach((ring, ringIdx) => {
      const ringRadius = 60 + ringIdx * 35;
      ring.forEach((m, i) => {
        const angle = (i / Math.max(ring.length, 1)) * Math.PI * 2 - Math.PI / 2;
        const x = cx + Math.cos(angle) * ringRadius;
        const y = cy + Math.sin(angle) * ringRadius;
        const r = Math.max(6, (m.score / 100) * 8 + 4);
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        const alpha = 0.3 + (m.score / 100) * 0.7;
        ctx.fillStyle = `rgba(48,209,88,${alpha})`;
        ctx.fill();
        ctx.strokeStyle = BENEFICIAL_COLOR;
        ctx.lineWidth = 1;
        ctx.stroke();
        // Label
        ctx.fillStyle = '#e6edf3';
        ctx.font = '9px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(m.label.substring(0, 10), x, y + r + 11);
      });
    });

    // Place antagonists outside the bed (far corners)
    const antagonists = nodes.filter(n => n.isAntagonist);
    antagonists.forEach((a, i) => {
      const corner = i % 4;
      const positions = [
        [40, 40], [width - 40, 40], [40, height - 40], [width - 40, height - 40]
      ];
      const [x, y] = positions[corner];
      ctx.beginPath();
      ctx.arc(x, y, 8, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255,122,69,0.4)';
      ctx.fill();
      ctx.strokeStyle = ANTAGONIST_COLOR;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([3, 3]);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#ff7a45';
      ctx.font = '8px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(a.label.substring(0, 10), x, y - 14);
    });

    // Legend
    ctx.fillStyle = '#484f58';
    ctx.font = '8px monospace';
    ctx.textAlign = 'left';
    ctx.fillText('● Target  ● Companion  ○ Antagonist (avoid)', 8, height - 8);
    ctx.textAlign = 'right';
    ctx.fillText(`Env Score: ${(es * 100).toFixed(0)}%`, width - 8, height - 8);
  }, [graphData, envScore]);

  // Render canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;
    const dpr = window.devicePixelRatio || 1;
    const w = container.clientWidth;
    const h = 320;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, w, h);
    // Background
    ctx.fillStyle = '#0d1117';
    ctx.fillRect(0, 0, w, h);
    if (mode === 'network') drawNetwork(ctx, w, h);
    else drawSpatial(ctx, w, h);
  }, [mode, guild, soilResult, waterResult, drawNetwork, drawSpatial]);

  if (!guild) return null;

  return (
    <div className="bg-[#12161A] border border-[#3fb950]/30 rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-[#3fb950]">Guild Visualizer</span>
          <span className="text-[8px] text-[#484f58] border border-[#30363d] rounded px-1.5 py-0.5">Canvas 2D · {guild.guild?.length || 0} species</span>
        </div>
        <div className="flex gap-1">
          <button
            onClick={() => setMode('network')}
            className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold transition-colors ${mode === 'network' ? 'bg-[#3fb950] text-black' : 'bg-[#161b22] border border-[#30363d] text-[#8b949e]'}`}
          >
            <Network size={10} /> Network
          </button>
          <button
            onClick={() => setMode('spatial')}
            className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold transition-colors ${mode === 'spatial' ? 'bg-[#3fb950] text-black' : 'bg-[#161b22] border border-[#30363d] text-[#8b949e]'}`}
          >
            <LayoutGrid size={10} /> Garden Bed
          </button>
        </div>
      </div>
      <div ref={containerRef} className="w-full">
        <canvas ref={canvasRef} className="rounded border border-[#30363d]" />
      </div>
      <div className="mt-2 text-[9px] text-[#484f58]">
        {mode === 'network'
          ? 'Force-directed graph: green edges = beneficial companions, red dashed = antagonists. Node size reflects guild score. Target plant in amber.'
          : 'Spatial garden bed: target in center, companions in concentric rings by guild layer, antagonists in corners (avoid). Background heatmap reflects soil/water compatibility.'}
      </div>
    </div>
  );
}