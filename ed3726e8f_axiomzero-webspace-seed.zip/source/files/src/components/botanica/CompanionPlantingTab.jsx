/**
 * CompanionPlantingTab — Companion planting database search + interactive
 * guild builder + AI-assisted guild design.
 *
 * Three-panel layout: left = search/builder controls, center = results
 * (companion pairs or composed guild with role cards), right = AI guild
 * design panel via Merlin.
 *
 * Data: COMPANION_PAIRS (beneficial + antagonistic), GUILD_ROLES taxonomy,
 * buildGuild() deterministic polyculture composer.
 */
import { useState } from 'react';
import { searchCompanions, buildGuild, COMPANION_PAIRS, GUILD_ROLES, PLANTS } from '@/lib/sciCompute/botanica';
import ComputeLoader from '@/components/shared/ComputeLoader';
import { queryMerlin } from '@/lib/merlinEngine';
import { parseMerlinResponse } from '@/components/quantum-cat/parseMerlinResponse';
import { Search, Sprout, Trees, Sparkles, Send } from 'lucide-react';
import { GuildVisualizer } from '@/components/botanica/GuildVisualizer';

const SOIL_TYPES = ['Loamy', 'Sandy', 'Clay', 'Silt', 'Peat', 'Chalky'];
const ZONES = ['3','4','5','6','7','8','9','10','11'];
const GUILD_TARGETS = ['Apple', 'Pear', 'Cherry', 'Plum', 'Peach', 'Walnut', 'Hazelnut', 'Blueberry', 'Raspberry', 'Grape', 'Fig', 'Persimmon', 'Mulberry', 'Elderberry', 'Tomato', 'Squash', 'Corn', 'Bean', 'Potato', 'Cucumber'];

export function CompanionPlantingTab({ soilResult, waterResult }) {
  const [mode, setMode] = useState('search');
  const [searchQuery, setSearchQuery] = useState('');
  const [guildTarget, setGuildTarget] = useState('Apple');
  const [soilType, setSoilType] = useState('Loamy');
  const [zone, setZone] = useState('8');
  const [guildResult, setGuildResult] = useState(null);
  const [guildLoading, setGuildLoading] = useState(false);

  // AI guild design state
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiResponse, setAiResponse] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);

  const searchResults = searchQuery.trim() ? searchCompanions(searchQuery) : [];
  const beneficial = searchResults.filter(r => r.type === 'beneficial');
  const antagonistic = searchResults.filter(r => r.type === 'antagonistic');

  const runGuildBuilder = async () => {
    setGuildLoading(true);
    setGuildResult(null);
    try {
      const res = await buildGuild(guildTarget, soilType, zone);
      setGuildResult(res);
    } catch (e) {
      setGuildResult({ error: e.message });
    }
    setGuildLoading(false);
  };

  const runAiGuildDesign = async () => {
    if (!aiPrompt.trim()) return;
    setAiLoading(true);
    setAiResponse(null);
    try {
      // queryMerlin injects the earth-science expert prompt + RAG via pageContext
      // when path === '/terra-os'. We pass the guild design request directly.
      const guildPrompt = `The user wants an AI-designed companion planting guild. Their request: "${aiPrompt}". The target plant is ${guildTarget}, soil type is ${soilType}, USDA zone ${zone}.\n\nDesign a complete polyculture guild. For each plant, explain its role (canopy, understory, shrub, herbaceous, ground cover, nitrogen fixer, dynamic accumulator, pest repeller, pollinator attractor), why it was chosen, and its companion relationship to the target plant. Include antagonistic plants to AVOID. End with the --- FOLLOWUPS: and Sources: structure.`;
      const response = await queryMerlin(guildPrompt, [], () => {}, null, false, {
        pageContext: {
          path: '/terra-os',
          title: 'Earth Sciences — Soil · Water · Minerals · Plants',
          description: 'Unified earth science expert system with companion planting and guild ecology.',
        },
      });
      setAiResponse(response);
    } catch (e) {
      setAiResponse(`Error: ${e.message}`);
    }
    setAiLoading(false);
  };

  const parsed = aiResponse ? parseMerlinResponse(aiResponse) : null;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr_320px] gap-4">
      {/* ── Left: Search & Builder Controls ── */}
      <div className="space-y-4">
        <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <Search size={12} className="text-[#3fb950]" />
            <span className="text-xs font-bold text-[#3fb950]">Companion Search</span>
          </div>
          <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="e.g. Tomato, Basil, Bean..." className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-xs text-[#e6edf3] mb-2" />
          {searchQuery.trim() && (
            <div className="text-[10px] text-[#484f58]">{searchResults.length} pairs found ({beneficial.length} beneficial, {antagonistic.length} antagonistic)</div>
          )}
        </div>

        <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <Trees size={12} className="text-[#3fb950]" />
            <span className="text-xs font-bold text-[#3fb950]">Guild Builder</span>
            <span className="text-[8px] text-[#484f58] border border-[#30363d] rounded px-1.5 py-0.5">Jacke 2005</span>
          </div>
          <div className="space-y-2">
            <div>
              <label className="text-[10px] text-[#8b949e] block mb-1">Target Plant</label>
              <select value={guildTarget} onChange={e => setGuildTarget(e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-xs text-[#e6edf3]">
                {GUILD_TARGETS.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] text-[#8b949e] block mb-1">Soil Type</label>
              <select value={soilType} onChange={e => setSoilType(e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-xs text-[#e6edf3]">
                {SOIL_TYPES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] text-[#8b949e] block mb-1">USDA Zone</label>
              <select value={zone} onChange={e => setZone(e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-xs text-[#e6edf3]">
                {ZONES.map(z => <option key={z}>{z}</option>)}
              </select>
            </div>
            <button onClick={runGuildBuilder} disabled={guildLoading} className="w-full bg-gradient-to-r from-[#3fb950] to-[#30d158] text-black py-2 rounded text-xs font-bold disabled:opacity-50">Build Guild</button>
          </div>
        </div>
      </div>

      {/* ── Center: Results ── */}
      <div className="space-y-4">
        {/* Companion search results */}
        {searchQuery.trim() && (
          <>
            {beneficial.length > 0 && (
              <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
                <div className="text-xs font-bold text-[#3fb950] mb-3">✓ Beneficial Companions ({beneficial.length})</div>
                <div className="space-y-2">
                  {beneficial.map((pair, i) => (
                    <div key={i} className="bg-[#0d1117] border border-[#3fb950]/20 rounded p-2">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-[#e6edf3]">{pair.a === searchQuery ? `→ ${pair.b}` : `→ ${pair.a}`}</span>
                        <span className="text-[8px] text-[#484f58]">{pair.source}</span>
                      </div>
                      <div className="text-[10px] text-[#8b949e]"><span className="text-[#3fb950]">Mechanism:</span> {pair.mechanism}</div>
                      <div className="text-[10px] text-[#8b949e]"><span className="text-[#3fb950]">Benefit:</span> {pair.benefit}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {antagonistic.length > 0 && (
              <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
                <div className="text-xs font-bold text-[#ff7a45] mb-3">✗ Antagonistic — Avoid ({antagonistic.length})</div>
                <div className="space-y-2">
                  {antagonistic.map((pair, i) => (
                    <div key={i} className="bg-[#0d1117] border border-[#ff7a45]/20 rounded p-2">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-[#e6edf3]">{pair.a === searchQuery ? `→ ${pair.b}` : `→ ${pair.a}`}</span>
                        <span className="text-[8px] text-[#484f58]">{pair.source}</span>
                      </div>
                      <div className="text-[10px] text-[#8b949e]"><span className="text-[#ff7a45]">Mechanism:</span> {pair.mechanism}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {searchResults.length === 0 && (
              <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4 text-center text-xs text-[#8b949e]">No companion data found for "{searchQuery}". Try a different plant name.</div>
            )}
          </>
        )}

        {/* Guild builder results */}
        {guildLoading && <ComputeLoader engine="math.js BigNumber" detail="Composing polyculture guild from companion database + guild role taxonomy" />}
        {guildResult && !guildLoading && !guildResult.error && (
          <>
            <div className="bg-[#12161A] border border-[#3fb950]/40 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-xs font-bold text-[#3fb950]">Guild: {guildResult.targetPlant}</div>
                  <div className="text-[10px] text-[#8b949e]">{guildResult.soilType} soil · Zone {guildResult.climateZone}</div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-[#3fb950]">{guildResult.score}</div>
                  <div className="text-[9px] text-[#484f58]">Guild Score</div>
                </div>
              </div>
              <div className="space-y-2">
                {guildResult.guild.map((member, i) => (
                  <div key={i} className="bg-[#0d1117] border border-[#30363d] rounded p-2">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[8px] px-1.5 py-0.5 border border-[#3fb950]/30 text-[#3fb950] rounded font-bold">{member.role}</span>
                        <span className="text-xs font-bold text-[#e6edf3]">{member.plant}</span>
                      </div>
                      <span className="text-[10px] text-[#3fb950] font-mono">{member.score.toFixed(0)}</span>
                    </div>
                    <div className="text-[9px] text-[#8b949e]">{member.desc}</div>
                    {member.companionInfo && (
                      <div className="text-[9px] text-[#3fb950] mt-1">↳ {member.companionInfo.mechanism} ({member.companionInfo.source})</div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {guildResult.antagonists.length > 0 && (
              <div className="bg-[#12161A] border border-[#ff7a45]/30 rounded-lg p-4">
                <div className="text-xs font-bold text-[#ff7a45] mb-2">⚠ Avoid Near {guildResult.targetPlant}</div>
                <div className="grid grid-cols-2 gap-2">
                  {guildResult.antagonists.map((ant, i) => (
                    <div key={i} className="bg-[#0d1117] border border-[#ff7a45]/20 rounded p-2">
                      <div className="text-xs font-bold text-[#e6edf3]">{ant.plant}</div>
                      <div className="text-[9px] text-[#8b949e]">{ant.mechanism}</div>
                      <div className="text-[8px] text-[#484f58]">{ant.source}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
              <div className="text-[9px] text-[#3fb950] font-bold mb-0.5">SHA-256 Attestation</div>
              <div className="text-[9px] text-[#3fb950] font-mono break-all bg-[#0d1117] border border-[#30363d] rounded p-1.5">{guildResult.hash}</div>
            </div>

            <GuildVisualizer guild={guildResult} soilResult={soilResult} waterResult={waterResult} />
          </>
        )}

        {!searchQuery.trim() && !guildResult && !guildLoading && (
          <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Sprout size={14} className="text-[#3fb950]" />
              <span className="text-xs font-bold text-[#3fb950]">Companion Planting & Guild Ecology</span>
            </div>
            <p className="text-[10px] text-[#8b949e] mb-3">Search the companion database for beneficial and antagonistic plant pairs, or build a complete polyculture guild around a target plant.</p>
            <div className="grid grid-cols-2 gap-2 text-[10px]">
              <div className="bg-[#0d1117] border border-[#30363d] rounded p-2"><span className="text-[#3fb950] font-bold">{COMPANION_PAIRS.length}</span> companion pairs</div>
              <div className="bg-[#0d1117] border border-[#30363d] rounded p-2"><span className="text-[#3fb950] font-bold">{GUILD_ROLES.length}</span> guild roles</div>
              <div className="bg-[#0d1117] border border-[#30363d] rounded p-2"><span className="text-[#3fb950] font-bold">{COMPANION_PAIRS.filter(p => p.type === 'beneficial').length}</span> beneficial</div>
              <div className="bg-[#0d1117] border border-[#30363d] rounded p-2"><span className="text-[#ff7a45] font-bold">{COMPANION_PAIRS.filter(p => p.type === 'antagonistic').length}</span> antagonistic</div>
            </div>
            <div className="mt-3 text-[9px] text-[#484f58]">Sources: Riotte 1975 (Carrots Love Tomatoes) · Cunningham 1998 · Jacke & Toensmeier 2005 (Edible Forest Gardens) · Three Sisters (Iroquois)</div>
          </div>
        )}
      </div>

      {/* ── Right: AI Guild Design ── */}
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4 flex flex-col" style={{ maxHeight: '80vh' }}>
        <div className="flex items-center gap-2 mb-3">
          <Sparkles size={12} className="text-[#FF9F00]" />
          <span className="text-xs font-bold text-[#FF9F00]">AI Guild Design</span>
          <span className="text-[8px] text-[#484f58] border border-[#30363d] rounded px-1.5 py-0.5">Merlin Expert</span>
        </div>
        <textarea value={aiPrompt} onChange={e => setAiPrompt(e.target.value)} placeholder={`Describe your guild design goals for ${guildTarget}...\n\ne.g. "Design a food forest guild for apple trees in clay soil zone 8 with nitrogen fixers and pollinator attractors"`} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3] mb-2 resize-none" rows={4} />
        <button onClick={runAiGuildDesign} disabled={aiLoading || !aiPrompt.trim()} className="w-full bg-gradient-to-r from-[#FF9F00] to-[#ffb733] text-black py-2 rounded text-xs font-bold disabled:opacity-50 flex items-center justify-center gap-1.5 mb-3">
          <Send size={12} /> Design Guild
        </button>
        <div className="flex-1 overflow-y-auto space-y-2">
          {aiLoading && <ComputeLoader engine="Merlin Expert" detail="Designing companion planting guild with RAG + web search" />}
          {parsed && !aiLoading && (
            <>
              <div className="text-[10px] text-[#e6edf3] whitespace-pre-wrap leading-relaxed">{parsed.body}</div>
              {parsed.followups.length > 0 && (
                <div className="pt-2 border-t border-[#30363d]">
                  <div className="text-[9px] text-[#484f58] uppercase mb-1">Follow-ups</div>
                  {parsed.followups.map((f, i) => <div key={i} className="text-[9px] text-[#3b8bff] mb-0.5">{i + 1}. {f}</div>)}
                </div>
              )}
              {parsed.sources.length > 0 && (
                <div className="pt-2 border-t border-[#30363d]">
                  <div className="text-[9px] text-[#484f58] uppercase mb-1">Sources</div>
                  {parsed.sources.map((s, i) => (
                    <div key={i} className="text-[9px] text-[#8b949e] mb-0.5">
                      {s.type === 'WEB' && s.url ? <a href={s.url} target="_blank" rel="noopener noreferrer" className="text-[#3b8bff] hover:underline">{s.label}</a> : <span>{s.label}</span>}
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
          {!parsed && !aiLoading && (
            <div className="text-[10px] text-[#8b949e] text-center py-4">Merlin will design a custom guild using the companion database, guild ecology knowledge, and live web research — grounded in established sources.</div>
          )}
        </div>
      </div>
    </div>
  );
}