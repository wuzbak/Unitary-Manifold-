/**
 * PlantIdTab — Property-based plant identification using weighted
 * normalized Euclidean distance across 7 botanical properties × 30 species.
 * Extracted from BotanicaOS for the unified TerraOS page.
 */
import { useState } from 'react';
import ComputeLoader from '@/components/shared/ComputeLoader';
import { identifyPlant, PLANTS } from '@/lib/sciCompute/botanica';
import { Leaf } from 'lucide-react';

const LEAF_SHAPES = ['Lanceolate', 'Ovate', 'Cordate', 'Linear', 'Palmate', 'Needle', 'Scale', 'Pinnate'];
const LEAF_ARRANGEMENTS = ['Alternate', 'Opposite', 'Whorled', 'Rosette'];
const FLOWER_COLORS = ['White', 'Yellow', 'Pink', 'Purple', 'Blue', 'Red', 'Green', 'None'];
const BLOOM_SEASONS = ['Spring', 'Summer', 'Fall', 'Winter', 'None'];
const HABITATS = ['Forest', 'Meadow', 'Wetland', 'Desert', 'Alpine', 'Coastal', 'Cultivated'];
const CATEGORIES = ['Tree', 'Shrub', 'Herb', 'Vine', 'Groundcover', 'Succulent'];

export function PlantIdTab() {
  const [leafShape, setLeafShape] = useState('Ovate');
  const [leafArrangement, setLeafArrangement] = useState('Alternate');
  const [flowerColor, setFlowerColor] = useState('White');
  const [bloomSeason, setBloomSeason] = useState('Spring');
  const [habitat, setHabitat] = useState('Forest');
  const [category, setCategory] = useState('Tree');
  const [heightM, setHeightM] = useState(10);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const runIdentification = async () => {
    setLoading(true);
    setResult(null);
    try {
      const res = await identifyPlant({ leafShape, leafArrangement, flowerColor, bloomSeason, habitat, heightM, category });
      setResult(res);
    } catch (e) {
      setResult({ error: e.message });
    }
    setLoading(false);
  };

  const fields = [
    { label: 'Leaf shape', type: 'select', val: leafShape, set: setLeafShape, options: LEAF_SHAPES },
    { label: 'Leaf arrangement', type: 'select', val: leafArrangement, set: setLeafArrangement, options: LEAF_ARRANGEMENTS },
    { label: 'Flower color', type: 'select', val: flowerColor, set: setFlowerColor, options: FLOWER_COLORS },
    { label: 'Bloom season', type: 'select', val: bloomSeason, set: setBloomSeason, options: BLOOM_SEASONS },
    { label: 'Habitat', type: 'select', val: habitat, set: setHabitat, options: HABITATS },
    { label: 'Category', type: 'select', val: category, set: setCategory, options: CATEGORIES },
    { label: 'Height (m)', type: 'range', val: heightM, set: setHeightM, min: 0.1, max: 65, step: 0.5, display: heightM.toFixed(1) + 'm' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-[380px_1fr] gap-4">
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3">
          <Leaf size={12} className="text-[#3fb950]" />
          <span className="text-[8px] text-[#484f58] border border-[#30363d] rounded px-1.5 py-0.5">Weighted Euclidean · USDA PLANTS</span>
        </div>
        <div className="space-y-3">
          {fields.map(f => (
            <div key={f.label}>
              <label className="text-[10px] text-[#8b949e] block mb-1">{f.label}{f.display && <span className="text-[#3fb950] ml-2 font-bold">{f.display}</span>}</label>
              {f.type === 'select' ? (
                <select value={f.val} onChange={e => f.set(e.target.value)} className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-xs text-[#e6edf3]">
                  {f.options.map(o => <option key={o}>{o}</option>)}
                </select>
              ) : (
                <input type="range" min={f.min} max={f.max} step={f.step} value={f.val} onChange={e => f.set(+e.target.value)} className="w-full accent-[#3fb950]" />
              )}
            </div>
          ))}
          <button onClick={runIdentification} disabled={loading} className="w-full bg-gradient-to-r from-[#3fb950] to-[#30d158] text-black py-2 rounded text-xs font-bold disabled:opacity-50">Identify Plant</button>
        </div>
      </div>
      <div className="space-y-4">
        {loading ? (
          <ComputeLoader engine="math.js BigNumber" detail="Weighted normalized Euclidean distance across 7 properties × 30 species" />
        ) : !result ? (
          <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
            <div className="text-[10px] text-[#3fb950] uppercase tracking-wider mb-2">Top Match</div>
            <h2 className="text-sm font-bold text-[#e6edf3]">Awaiting identification</h2>
            <p className="text-[10px] text-[#8b949e] mt-1">Enter observed plant properties to score the botanical database using normalized Euclidean distance.</p>
          </div>
        ) : result.error ? (
          <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4 text-xs text-red-400">Error: {result.error}</div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {result.matches.map((m, i) => (
                <div key={i} className={`bg-[#12161A] border rounded-lg p-3 ${i === 0 ? 'border-[#3fb950]/40' : 'border-[#30363d]'}`}>
                  <div className="text-[10px] text-[#3fb950] uppercase tracking-wider">{i === 0 ? 'Top Match' : `Match ${i + 1}`}</div>
                  <h2 className="text-sm font-bold text-[#e6edf3] mt-1">{m.name}</h2>
                  <div className="text-[10px] text-[#8b949e] italic">{m.scientific}</div>
                  <div className="text-2xl font-bold mt-1" style={{ color: i === 0 ? '#3fb950' : '#8b949e' }}>{m.score.toFixed(1)}%</div>
                  <div className="text-[9px] text-[#484f58] font-mono">dist={m.distance.toFixed(4)}</div>
                  {m.medicinal && <span className="inline-block mt-1 text-[8px] px-1.5 py-0.5 border border-[#FF9F00]/40 text-[#FF9F00] rounded">Medicinal</span>}
                  <p className="text-[10px] text-[#8b949e] mt-1">{m.description}</p>
                </div>
              ))}
            </div>
            <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
              <div className="text-[10px] text-[#3fb950] uppercase tracking-wider mb-2">Property Match Breakdown — {result.matches[0].name}</div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {Object.entries(result.matches[0].breakdown).map(([prop, data]) => (
                  <div key={prop} className={`bg-[#0d1117] border rounded p-2 ${data.match ? 'border-[#3fb950]/40' : 'border-[#30363d]'}`}>
                    <span className="text-[10px] text-[#8b949e] block">{prop.replace(/([A-Z])/g, ' $1').trim()}</span>
                    <div className="text-[10px] text-[#e6edf3] font-mono">
                      <span className={data.match ? 'text-[#3fb950]' : 'text-[#ff7a45]'}>{String(data.specimen)}</span>
                      <span className="text-[#484f58]"> → </span>
                      <span className="text-[#8b949e]">{String(data.reference)}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-2 text-[9px] text-[#484f58]">Shannon entropy of top-3 confidence: {result.entropy.toFixed(3)} bits</div>
            </div>
            <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
              <div className="text-[9px] text-[#3fb950] font-bold mb-0.5">SHA-256 Attestation</div>
              <div className="text-[9px] text-[#3fb950] font-mono break-all bg-[#0d1117] border border-[#30363d] rounded p-1.5">{result.hash}</div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}