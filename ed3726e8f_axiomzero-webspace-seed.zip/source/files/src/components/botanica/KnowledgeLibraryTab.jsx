/**
 * KnowledgeLibraryTab — Botanical knowledge library with live-fetched
 * repo files from 4-IMPLICATIONS/botanical/ + curated external references.
 * Extracted from BotanicaOS for the unified TerraOS page.
 */
import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { BOTANICAL_LIBRARY } from '@/lib/sciCompute/botanica';
import { EARTH_SCIENCE_REFS } from '@/lib/earthScienceRag';
import { BookOpen, ExternalLink } from 'lucide-react';

export function KnowledgeLibraryTab() {
  const [contents, setContents] = useState({});
  const [loadingFile, setLoadingFile] = useState(null);

  const fetchContent = async (file) => {
    if (contents[file]) {
      setContents(prev => { const next = { ...prev }; delete next[file]; return next; });
      return;
    }
    setLoadingFile(file);
    try {
      const res = await base44.functions.invoke('fetchRepoFile', { path: `4-IMPLICATIONS/botanical/${file}` });
      const data = res?.data || res;
      const content = data?.content || data?.text || '';
      setContents(prev => ({ ...prev, [file]: String(content).slice(0, 5000) }));
    } catch (e) {
      setContents(prev => ({ ...prev, [file]: `Error loading: ${e.message}` }));
    }
    setLoadingFile(null);
  };

  return (
    <div className="space-y-4">
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <BookOpen size={14} className="text-[#3fb950]" />
          <span className="text-xs font-bold text-[#3fb950]">Botanical Knowledge Library</span>
          <span className="text-[8px] text-[#484f58] border border-[#30363d] rounded px-1.5 py-0.5">4-IMPLICATIONS/botanical/ · 11 files</span>
        </div>
        <p className="text-[10px] text-[#8b949e]">Living reference library unifying plant biology, phytochemistry, earth sciences, human health, and practical cultivation. Source: Unitary-Manifold- repository.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {BOTANICAL_LIBRARY.map(entry => (
          <div key={entry.file} className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
            <div className="flex items-start justify-between gap-2 mb-1">
              <h3 className="text-xs font-bold text-[#e6edf3]">{entry.title}</h3>
              <span className="text-[8px] text-[#484f58] border border-[#30363d] rounded px-1.5 py-0.5 shrink-0">{entry.audience}</span>
            </div>
            <p className="text-[10px] text-[#8b949e] mb-2">{entry.desc}</p>
            <button onClick={() => fetchContent(entry.file)} className="text-[10px] text-[#3fb950] hover:underline">
              {loadingFile === entry.file ? 'Loading...' : contents[entry.file] ? 'Hide' : 'Read excerpt →'}
            </button>
            {contents[entry.file] && (
              <div className="mt-2 bg-[#0d1117] border border-[#30363d] rounded p-2 max-h-64 overflow-y-auto">
                <pre className="text-[9px] text-[#8b949e] whitespace-pre-wrap font-mono">{contents[entry.file]}</pre>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3">
          <ExternalLink size={14} className="text-[#3b8bff]" />
          <span className="text-xs font-bold text-[#3b8bff]">Curated External References</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {EARTH_SCIENCE_REFS.map(ref => (
            <div key={ref.name} className="bg-[#0d1117] border border-[#30363d] rounded p-2">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-[8px] text-[#484f58] border border-[#30363d] rounded px-1.5 py-0.5 uppercase">{ref.domain}</span>
                {ref.url ? (
                  <a href={ref.url} target="_blank" rel="noopener noreferrer" className="text-[10px] font-bold text-[#3b8bff] hover:underline">{ref.name}</a>
                ) : (
                  <span className="text-[10px] font-bold text-[#e6edf3]">{ref.name}</span>
                )}
              </div>
              <p className="text-[9px] text-[#8b949e]">{ref.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}