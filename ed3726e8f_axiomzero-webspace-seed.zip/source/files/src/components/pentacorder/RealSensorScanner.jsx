/**
 * RealSensorScanner — Live device sensor readings via Web APIs.
 *
 * Five channels:
 * 1. Accelerometer (DeviceMotionEvent) → |a| vs g=9.807 m/s²
 * 2. Gyroscope (DeviceOrientationEvent) → α/β/γ vs 0°
 * 3. Ambient Light (AmbientLightSensor API) → lux
 * 4. Battery (navigator.getBattery) → level / charging
 * 5. Geolocation (navigator.geolocation) → lat / lon / alt
 *
 * Each channel shows: live value, baseline, PASS/ANOMALY/UNAVAILABLE status.
 * Permission-gated. Honest "not available on this device" when denied/unsupported.
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { Play, Pause, RotateCcw, Download, AlertTriangle, CheckCircle2, XCircle, MapPin, Battery, Sun, Compass, Activity } from 'lucide-react';
import { UM_CONSTANTS } from '@/lib/umConstants';

const G = UM_CONSTANTS.G_STANDARD; // 9.807 m/s²

const CHANNELS = [
  { id: 'accel', name: 'Accelerometer', icon: Activity, unit: 'm/s²', baseline: G, color: '#3b8bff', pillar: 1, desc: '|a| vs g=9.807' },
  { id: 'gyro', name: 'Gyroscope', icon: Compass, unit: '°', baseline: 0, color: '#30d158', pillar: 4, desc: 'α/β/γ orientation' },
  { id: 'light', name: 'Ambient Light', icon: Sun, unit: 'lx', baseline: 320, color: '#f0c040', pillar: 12, desc: 'Illuminance' },
  { id: 'battery', name: 'Battery', icon: Battery, unit: '%', baseline: 100, color: '#ff647c', pillar: 74, desc: 'Level / charging' },
  { id: 'geo', name: 'Geolocation', icon: MapPin, unit: '°', baseline: 0, color: '#7c4dff', pillar: 9, desc: 'Lat / lon / alt' },
];

export default function RealSensorScanner() {
  const [active, setActive] = useState(false);
  const [readings, setReadings] = useState({});
  const [history, setHistory] = useState({});
  const [statuses, setStatuses] = useState({});
  const [recording, setRecording] = useState(false);
  const [recordedData, setRecordedData] = useState([]);
  const recordRef = useRef([]);

  // Start all sensors
  const startSensors = useCallback(async () => {
    setActive(true);
    const newStatuses = {};

    // 1. Accelerometer — DeviceMotionEvent
    if (typeof DeviceMotionEvent !== 'undefined') {
      try {
        if (typeof DeviceMotionEvent.requestPermission === 'function') {
          const perm = await DeviceMotionEvent.requestPermission();
          if (perm === 'granted') {
            window.addEventListener('devicemotion', handleMotion);
            newStatuses.accel = 'ACTIVE';
          } else {
            newStatuses.accel = 'DENIED';
          }
        } else {
          window.addEventListener('devicemotion', handleMotion);
          newStatuses.accel = 'ACTIVE';
        }
      } catch {
        newStatuses.accel = 'UNAVAILABLE';
      }
    } else {
      newStatuses.accel = 'UNAVAILABLE';
    }

    // 2. Gyroscope — DeviceOrientationEvent
    if (typeof DeviceOrientationEvent !== 'undefined') {
      try {
        if (typeof DeviceOrientationEvent.requestPermission === 'function') {
          const perm = await DeviceOrientationEvent.requestPermission();
          if (perm === 'granted') {
            window.addEventListener('deviceorientation', handleOrientation);
            newStatuses.gyro = 'ACTIVE';
          } else {
            newStatuses.gyro = 'DENIED';
          }
        } else {
          window.addEventListener('deviceorientation', handleOrientation);
          newStatuses.gyro = 'ACTIVE';
        }
      } catch {
        newStatuses.gyro = 'UNAVAILABLE';
      }
    } else {
      newStatuses.gyro = 'UNAVAILABLE';
    }

    // 3. Ambient Light Sensor
    try {
      if ('AmbientLightSensor' in window) {
        const sensor = new window.AmbientLightSensor({ frequency: 1 });
        sensor.addEventListener('reading', () => {
          setReadings(r => ({ ...r, light: sensor.illuminance }));
          setStatuses(s => ({ ...s, light: 'ACTIVE' }));
        });
        sensor.addEventListener('error', () => {
          setStatuses(s => ({ ...s, light: 'UNAVAILABLE' }));
        });
        sensor.start();
        newStatuses.light = 'ACTIVE';
      } else {
        newStatuses.light = 'UNAVAILABLE';
      }
    } catch {
      newStatuses.light = 'UNAVAILABLE';
    }

    // 4. Battery
    try {
      if (navigator.getBattery) {
        const battery = await navigator.getBattery();
        const updateBattery = () => {
          setReadings(r => ({ ...r, battery: battery.level * 100, charging: battery.charging }));
          setStatuses(s => ({ ...s, battery: 'ACTIVE' }));
        };
        updateBattery();
        battery.addEventListener('levelchange', updateBattery);
        battery.addEventListener('chargingchange', updateBattery);
        newStatuses.battery = 'ACTIVE';
      } else {
        newStatuses.battery = 'UNAVAILABLE';
      }
    } catch {
      newStatuses.battery = 'UNAVAILABLE';
    }

    // 5. Geolocation
    try {
      if (navigator.geolocation) {
        navigator.geolocation.watchPosition(
          (pos) => {
            setReadings(r => ({
              ...r,
              geo: { lat: pos.coords.latitude, lon: pos.coords.longitude, alt: pos.coords.altitude },
            }));
            setStatuses(s => ({ ...s, geo: 'ACTIVE' }));
          },
          () => { setStatuses(s => ({ ...s, geo: 'DENIED' })); },
          { enableHighAccuracy: true, timeout: 10000 }
        );
        newStatuses.geo = 'ACTIVE';
      } else {
        newStatuses.geo = 'UNAVAILABLE';
      }
    } catch {
      newStatuses.geo = 'UNAVAILABLE';
    }

    setStatuses(s => ({ ...s, ...newStatuses }));
  }, []);

  // Event handlers
  const handleMotion = useCallback((e) => {
    const a = e.accelerationIncludingGravity;
    if (a) {
      const mag = Math.sqrt((a.x || 0) ** 2 + (a.y || 0) ** 2 + (a.z || 0) ** 2);
      setReadings(r => ({ ...r, accel: mag }));
    }
  }, []);

  const handleOrientation = useCallback((e) => {
    if (e.alpha != null || e.beta != null || e.gamma != null) {
      setReadings(r => ({ ...r, gyro: { alpha: e.alpha || 0, beta: e.beta || 0, gamma: e.gamma || 0 } }));
    }
  }, []);

  // Update history + recording every 500ms
  useEffect(() => {
    if (!active) return;
    const interval = setInterval(() => {
      setHistory(h => {
        const newH = { ...h };
        CHANNELS.forEach(c => {
          const val = readings[c.id];
          if (val != null) {
            const arr = [...(h[c.id] || []), typeof val === 'object' ? JSON.stringify(val) : val];
            newH[c.id] = arr.slice(-60);
          }
        });
        return newH;
      });
      if (recording) {
        recordRef.current.push({ t: Date.now(), ...readings });
      }
    }, 500);
    return () => clearInterval(interval);
  }, [active, readings, recording]);

  const stopSensors = () => {
    setActive(false);
    window.removeEventListener('devicemotion', handleMotion);
    window.removeEventListener('deviceorientation', handleOrientation);
  };

  const toggleRecording = () => {
    if (recording) {
      setRecordedData(recordRef.current);
      setRecording(false);
    } else {
      recordRef.current = [];
      setRecording(true);
    }
  };

  const downloadRecording = () => {
    const blob = new Blob([JSON.stringify(recordedData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pentacorder-readings-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const reset = () => {
    setHistory({});
    setReadings({});
    setRecordedData([]);
    recordRef.current = [];
  };

  const getStatusBadge = (channelId) => {
    const status = statuses[channelId] || 'IDLE';
    const val = readings[channelId];
    if (status === 'UNAVAILABLE' || status === 'DENIED') {
      return { label: status, color: '#ff3b30', icon: XCircle };
    }
    if (status === 'ACTIVE' && val != null) {
      // Check for anomaly
      if (channelId === 'accel') {
        const delta = Math.abs(val - G);
        return delta > 2 ? { label: 'ANOMALY', color: '#ff9f0a', icon: AlertTriangle } : { label: 'PASS', color: '#30d158', icon: CheckCircle2 };
      }
      return { label: 'PASS', color: '#30d158', icon: CheckCircle2 };
    }
    return { label: 'IDLE', color: '#8b949e', icon: Activity };
  };

  const formatValue = (channelId, val) => {
    if (val == null) return '—';
    if (channelId === 'accel') return val.toFixed(3);
    if (channelId === 'gyro') return `α:${val.alpha.toFixed(0)} β:${val.beta.toFixed(0)} γ:${val.gamma.toFixed(0)}`;
    if (channelId === 'light') return val.toFixed(1);
    if (channelId === 'battery') return `${val.toFixed(0)}${readings.charging ? '⚡' : ''}`;
    if (channelId === 'geo') return `${val.lat.toFixed(4)}, ${val.lon.toFixed(4)}`;
    return String(val);
  };

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex items-center gap-3 flex-wrap bg-[#12161A] border border-[#30363d] rounded-lg p-3">
        <button
          onClick={active ? stopSensors : startSensors}
          className={`px-3 py-1.5 rounded text-xs font-bold flex items-center gap-1.5 ${active ? 'bg-[#ff3b30] text-white' : 'bg-[#3b8bff] text-white'}`}
        >
          {active ? <><Pause size={12} /> Stop Sensors</> : <><Play size={12} /> Start Sensors</>}
        </button>
        <button
          onClick={toggleRecording}
          disabled={!active}
          className={`px-3 py-1.5 rounded text-xs font-bold flex items-center gap-1.5 disabled:opacity-40 ${recording ? 'bg-[#ff3b30] text-white' : 'border border-[#30363d] text-[#e6edf3] hover:border-[#3b8bff]'}`}
        >
          {recording ? <><span className="w-2 h-2 bg-white rounded-full animate-pulse" /> Recording...</> : <>Record 60s</>}
        </button>
        {recordedData.length > 0 && (
          <button onClick={downloadRecording} className="px-3 py-1.5 rounded text-xs border border-[#30d158]/40 text-[#30d158] flex items-center gap-1.5 hover:bg-[#30d158]/10">
            <Download size={12} /> Download ({recordedData.length} samples)
          </button>
        )}
        <button onClick={reset} className="px-3 py-1.5 rounded text-xs border border-[#30363d] text-[#e6edf3] hover:border-[#3b8bff] flex items-center gap-1.5">
          <RotateCcw size={12} /> Reset
        </button>
        <div className="ml-auto text-[10px] text-[#8b949e]">
          {active ? <span className="text-[#30d158]">● Sensors active</span> : <span className="text-[#8b949e]">○ Sensors idle</span>}
        </div>
      </div>

      {/* Disclaimer */}
      <div className="bg-[#2a1a0a] border border-[#FF9F00]/30 rounded-lg p-3">
        <div className="flex items-start gap-2">
          <AlertTriangle size={14} className="text-[#FF9F00] shrink-0 mt-0.5" />
          <p className="text-[10px] text-[#FF9F00]/90 leading-relaxed">
            Sensor readings are <strong>real device measurements</strong> from your hardware (accelerometer, gyroscope, ambient light, battery, GPS).
            UM pillar mappings are <strong>adjacent-track conceptual comparisons</strong>, not experimental validations.
            Some sensors may be unavailable on desktop browsers or require permission on mobile.
          </p>
        </div>
      </div>

      {/* Sensor grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        {CHANNELS.map(c => {
          const val = readings[c.id];
          const badge = getStatusBadge(c.id);
          const BadgeIcon = badge.icon;
          const hist = history[c.id] || [];
          return (
            <div key={c.id} className="bg-[#12161A] border border-[#30363d] rounded-lg p-3 relative overflow-hidden">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <div className="text-[9px] text-[#8b949e] uppercase tracking-wider">Pillar {c.pillar}</div>
                  <div className="text-[10px] text-[#e6edf3]">{c.name}</div>
                </div>
                <span className="text-[9px] px-2 py-0.5 rounded-full border flex items-center gap-1" style={{ color: badge.color, borderColor: `${badge.color}40`, background: `${badge.color}10` }}>
                  <BadgeIcon size={8} /> {badge.label}
                </span>
              </div>
              <div className="relative w-20 h-20 mx-auto my-2">
                <div className="absolute inset-0 rounded-full" style={{ background: `conic-gradient(${c.color} ${Math.min(100, (typeof val === 'number' ? Math.abs(val) : 0) / Math.max(c.baseline, 1) * 100)}deg, rgba(255,255,255,.08) 0deg 360deg)` }} />
                <div className="absolute inset-2 rounded-full bg-[#091325] border border-[#30363d] flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-xs font-bold" style={{ color: c.color }}>{formatValue(c.id, val)}</div>
                    <div className="text-[8px] text-[#8b949e]">{c.unit}</div>
                  </div>
                </div>
              </div>
              <div className="text-center text-[9px] text-[#8b949e]">{c.desc}</div>
              <div className="text-center text-[8px] text-[#484f58] mt-0.5">baseline: {c.baseline} {c.unit}</div>
              <div className="mt-2 bg-[#0d1117] border border-[#30363d] rounded p-1">
                <svg width="100%" height="24" viewBox="0 0 100 24" preserveAspectRatio="none">
                  {hist.length > 1 && (() => {
                    const nums = hist.map(h => typeof h === 'number' ? h : 0);
                    const min = Math.min(...nums), max = Math.max(...nums);
                    const range = max - min || 1;
                    const pts = nums.map((v, i) => `${(i / (nums.length - 1)) * 100},${24 - ((v - min) / range) * 22 - 1}`).join(' ');
                    return <polyline points={pts} fill="none" stroke={c.color} strokeWidth="1" />;
                  })()}
                </svg>
              </div>
            </div>
          );
        })}
      </div>

      {/* Live data table */}
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="text-xs font-bold text-[#e6edf3] mb-3 flex items-center gap-2">
          <Activity size={14} className="text-[#3b8bff]" /> Live Sensor Data
        </div>
        <div className="space-y-1.5">
          {CHANNELS.map(c => {
            const val = readings[c.id];
            const badge = getStatusBadge(c.id);
            return (
              <div key={c.id} className="bg-[#0d1117] border border-[#30363d] rounded p-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <c.icon size={12} style={{ color: c.color }} />
                  <span className="text-[10px] text-[#8b949e]">{c.name}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xs text-[#e6edf3]">{formatValue(c.id, val)} {c.unit}</span>
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded" style={{ color: badge.color, background: `${badge.color}15` }}>{badge.label}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}