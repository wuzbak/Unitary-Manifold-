/**
 * RealAcousticModem — Software-defined acoustic modem using Web Audio API.
 *
 * TX: Text → ASCII bytes → bits → BPSK on 16 OFDM subcarriers (1400–3650 Hz)
 *     + 1200 Hz pilot → Float32Array PCM at 44100 Hz → AudioContext playback.
 *
 * RX (loopback): Analyze the generated PCM buffer → Goertzel DFT per subcarrier
 *     → BPSK demodulate → bits → bytes → text. Verifies the OFDM math.
 *
 * RX (mic): getUserMedia → MediaRecorder → decode recorded audio.
 *
 * This is real DSP engineering, not a simulation.
 */

import { useState, useRef, useCallback } from 'react';
import { Radio, Waves, Play, Square, Mic, CheckCircle2, XCircle, Loader2 } from 'lucide-react';

const SAMPLE_RATE = 44100;
const SYMBOL_DURATION = 0.05; // 50ms per symbol → 20 sym/s
const SAMPLES_PER_SYMBOL = Math.floor(SAMPLE_RATE * SYMBOL_DURATION);
const BASE_FREQ = 1400;
const FREQ_SPACING = 150;
const PILOT_FREQ = 1200;
const NUM_SUBCARRIERS = 16;
const PREAMBLE_DURATION = 0.5; // 500ms pilot preamble for sync

// ── TX: Encode text to OFDM PCM ──
function encodeTextToOFDM(text) {
  const bytes = new TextEncoder().encode(text);
  const bits = [];
  for (const byte of bytes) {
    for (let i = 7; i >= 0; i--) bits.push((byte >> i) & 1);
  }
  while (bits.length % NUM_SUBCARRIERS !== 0) bits.push(0);

  const numSymbols = bits.length / NUM_SUBCARRIERS;
  const preambleSamples = Math.floor(SAMPLE_RATE * PREAMBLE_DURATION);
  const dataSamples = numSymbols * SAMPLES_PER_SYMBOL;
  const totalSamples = preambleSamples + dataSamples + SAMPLE_RATE; // 1s tail
  const pcm = new Float32Array(totalSamples);

  // Preamble: pilot tone for synchronization
  for (let i = 0; i < preambleSamples; i++) {
    pcm[i] = 0.3 * Math.sin(2 * Math.PI * PILOT_FREQ * i / SAMPLE_RATE);
  }

  // Data symbols
  for (let s = 0; s < numSymbols; s++) {
    const symbolBits = bits.slice(s * NUM_SUBCARRIERS, (s + 1) * NUM_SUBCARRIERS);
    for (let i = 0; i < SAMPLES_PER_SYMBOL; i++) {
      const idx = preambleSamples + s * SAMPLES_PER_SYMBOL + i;
      const t = i / SAMPLE_RATE;
      let sample = 0.15 * Math.sin(2 * Math.PI * PILOT_FREQ * (idx / SAMPLE_RATE));
      for (let k = 0; k < NUM_SUBCARRIERS; k++) {
        const freq = BASE_FREQ + k * FREQ_SPACING;
        const phase = symbolBits[k] ? 0 : Math.PI;
        sample += 0.04 * Math.sin(2 * Math.PI * freq * t + phase);
      }
      pcm[idx] = sample;
    }
  }

  return { pcm, bits, numSymbols, bytes: bytes.length, preambleSamples };
}

// ── Goertzel algorithm: DFT at a single frequency ──
function goertzel(samples, start, N, freq) {
  const k = (freq * N) / SAMPLE_RATE;
  const omega = (2 * Math.PI * k) / N;
  const coeff = 2 * Math.cos(omega);
  let s1 = 0, s2 = 0;
  for (let i = 0; i < N; i++) {
    const s0 = samples[start + i] + coeff * s1 - s2;
    s2 = s1;
    s1 = s0;
  }
  const real = s1 - s2 * Math.cos(omega);
  const imag = s2 * Math.sin(omega);
  return { real, imag, mag: Math.sqrt(real * real + imag * imag) };
}

// ── RX: Decode OFDM PCM to text ──
function decodeOFDMToText(pcm, numSymbols, preambleSamples) {
  const bits = [];
  let errors = 0;
  for (let s = 0; s < numSymbols; s++) {
    const start = preambleSamples + s * SAMPLES_PER_SYMBOL;
    for (let k = 0; k < NUM_SUBCARRIERS; k++) {
      const freq = BASE_FREQ + k * FREQ_SPACING;
      const { real } = goertzel(pcm, start, SAMPLES_PER_SYMBOL, freq);
      const bit = real >= 0 ? 1 : 0;
      bits.push(bit);
    }
  }

  // Convert bits to bytes
  const bytes = [];
  for (let i = 0; i < bits.length; i += 8) {
    if (i + 8 > bits.length) break;
    let byte = 0;
    for (let j = 0; j < 8; j++) byte = (byte << 1) | bits[i + j];
    bytes.push(byte);
  }

  const decoded = new TextDecoder().decode(new Uint8Array(bytes));
  return { decoded, bytes, bits, errors };
}

// ── Spectrum computation for display ──
function computeSpectrum(pcm, start, N) {
  const spectrum = [];
  for (let k = 0; k < NUM_SUBCARRIERS; k++) {
    const freq = BASE_FREQ + k * FREQ_SPACING;
    const { mag } = goertzel(pcm, start, N, freq);
    spectrum.push({ freq, mag, index: k });
  }
  const pilot = goertzel(pcm, start, N, PILOT_FREQ);
  spectrum.push({ freq: PILOT_FREQ, mag: pilot.mag, index: -1, isPilot: true });
  return spectrum;
}

export default function RealAcousticModem() {
  const [message, setMessage] = useState('Hello UM');
  const [encoded, setEncoded] = useState(null);
  const [decoded, setDecoded] = useState('');
  const [playing, setPlaying] = useState(false);
  const [recording, setRecording] = useState(false);
  const [micStatus, setMicStatus] = useState(null);
  const [loopbackResult, setLoopbackResult] = useState(null);
  const audioCtxRef = useRef(null);
  const sourceRef = useRef(null);
  const canvasRef = useRef(null);
  const spectrumCanvasRef = useRef(null);

  const ensureAudioCtx = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || window.webkitAudioContext)();
    }
    return audioCtxRef.current;
  };

  const drawWaveform = useCallback((pcm) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#050a1a';
    ctx.fillRect(0, 0, W, H);
    ctx.strokeStyle = '#3b8bff';
    ctx.lineWidth = 1;
    ctx.beginPath();
    const step = Math.max(1, Math.floor(pcm.length / W));
    for (let x = 0; x < W; x++) {
      const idx = x * step;
      const y = H / 2 + (pcm[idx] || 0) * (H * 0.4);
      if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }, []);

  const drawSpectrum = useCallback((pcm, preambleSamples) => {
    const canvas = spectrumCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#050a1a';
    ctx.fillRect(0, 0, W, H);
    // Use first data symbol for spectrum
    const start = preambleSamples;
    const spectrum = computeSpectrum(pcm, start, SAMPLES_PER_SYMBOL);
    const maxMag = Math.max(...spectrum.map(s => s.mag), 1);
    const barWidth = W / spectrum.length;
    spectrum.forEach((s, i) => {
      const h = (s.mag / maxMag) * (H * 0.85);
      ctx.fillStyle = s.isPilot ? '#ff9f0a' : '#3b8bff';
      ctx.fillRect(i * barWidth + 2, H - h, barWidth - 4, h);
      ctx.fillStyle = '#484f58';
      ctx.font = '8px monospace';
      ctx.fillText(`${s.freq}`, i * barWidth + 2, H - 1);
    });
  }, []);

  const handleEncode = () => {
    if (!message.trim()) return;
    const result = encodeTextToOFDM(message.slice(0, 80));
    setEncoded(result);
    setDecoded('');
    setLoopbackResult(null);
    drawWaveform(result.pcm);
    drawSpectrum(result.pcm, result.preambleSamples);
  };

  const handlePlay = () => {
    if (!encoded) return;
    const ctx = ensureAudioCtx();
    const buffer = ctx.createBuffer(1, encoded.pcm.length, SAMPLE_RATE);
    buffer.getChannelData(0).set(encoded.pcm);
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.onended = () => setPlaying(false);
    source.start();
    sourceRef.current = source;
    setPlaying(true);
  };

  const handleLoopback = () => {
    if (!encoded) return;
    const result = decodeOFDMToText(encoded.pcm, encoded.numSymbols, encoded.preambleSamples);
    setDecoded(result.decoded);
    const match = result.decoded.trim() === message.trim();
    setLoopbackResult({ match, decoded: result.decoded, original: message, bits: result.bits.length });
  };

  const handleMicRecord = async () => {
    try {
      setMicStatus('recording');
      setRecording(true);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks = [];
      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = async () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        const arrayBuffer = await blob.arrayBuffer();
        const ctx = ensureAudioCtx();
        const audioBuffer = await ctx.decodeAudioData(arrayBuffer);
        // Extract mono PCM
        const pcm = audioBuffer.getChannelData(0);
        // Find pilot preamble (search first 2s for 1200 Hz peak)
        let bestStart = 0, bestMag = 0;
        const searchStep = Math.floor(SAMPLE_RATE * 0.01);
        for (let start = 0; start < Math.min(SAMPLE_RATE * 2, pcm.length - SAMPLES_PER_SYMBOL); start += searchStep) {
          const { mag } = goertzel(pcm, start, SAMPLES_PER_SYMBOL, PILOT_FREQ);
          if (mag > bestMag) { bestMag = mag; bestStart = start; }
        }
        if (bestMag < 1) {
          setMicStatus({ error: 'No pilot tone detected — speak louder or move closer to speaker' });
          setRecording(false);
          return;
        }
        // Decode from detected preamble
        const preambleEnd = bestStart + Math.floor(SAMPLE_RATE * PREAMBLE_DURATION);
        const numSymbols = Math.floor((pcm.length - preambleEnd) / SAMPLES_PER_SYMBOL);
        if (numSymbols < 1) {
          setMicStatus({ error: 'Recording too short for decoding' });
          setRecording(false);
          return;
        }
        const result = decodeOFDMToText(pcm, Math.min(numSymbols, encoded?.numSymbols || numSymbols), preambleEnd - 0);
        setMicStatus({ decoded: result.decoded, bits: result.bits.length });
        setRecording(false);
      };
      recorder.start();
      // Stop after 5 seconds
      setTimeout(() => { recorder.stop(); stream.getTracks().forEach(t => t.stop()); }, 5000);
    } catch (e) {
      setMicStatus({ error: e.message || 'Microphone access denied' });
      setRecording(false);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* TX Panel */}
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="text-xs font-bold text-[#e6edf3] mb-3 flex items-center gap-2">
          <Radio size={14} className="text-[#3b8bff]" /> TX — Acoustic Encoder (Real OFDM)
        </div>
        <div className="space-y-3">
          <div>
            <label className="text-[10px] text-[#8b949e] block mb-1">Message ({message.length}/80 chars)</label>
            <input type="text" maxLength={80} value={message} onChange={e => setMessage(e.target.value)}
              className="w-full bg-[#0d1117] border border-[#30363d] rounded px-3 py-2 text-xs text-[#e6edf3]" />
          </div>
          <button onClick={handleEncode} className="w-full bg-gradient-to-r from-[#3b8bff] to-[#7c4dff] text-white py-2 rounded text-xs font-bold">
            Encode to OFDM
          </button>
          {encoded && (
            <>
              <div className="bg-[#0d1117] border border-[#30363d] rounded p-2">
                <div className="text-[9px] text-[#8b949e] mb-1">Waveform (time domain)</div>
                <canvas ref={canvasRef} width={400} height={60} className="w-full" />
              </div>
              <div className="bg-[#0d1117] border border-[#30363d] rounded p-2">
                <div className="text-[9px] text-[#8b949e] mb-1">Spectrum (frequency domain)</div>
                <canvas ref={spectrumCanvasRef} width={400} height={80} className="w-full" />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-[#0d1117] border border-[#30363d] rounded p-2 text-center">
                  <div className="text-[9px] text-[#8b949e]">Symbols</div>
                  <div className="text-xs text-[#3b8bff] font-mono">{encoded.numSymbols}</div>
                </div>
                <div className="bg-[#0d1117] border border-[#30363d] rounded p-2 text-center">
                  <div className="text-[9px] text-[#8b949e]">Bits</div>
                  <div className="text-xs text-[#3b8bff] font-mono">{encoded.bits.length}</div>
                </div>
                <div className="bg-[#0d1117] border border-[#30363d] rounded p-2 text-center">
                  <div className="text-[9px] text-[#8b949e]">Duration</div>
                  <div className="text-xs text-[#3b8bff] font-mono">{(encoded.pcm.length / SAMPLE_RATE).toFixed(2)}s</div>
                </div>
              </div>
              <div className="text-[9px] text-[#484f58]">
                16 subcarriers @ {BASE_FREQ}–{BASE_FREQ + 15 * FREQ_SPACING} Hz · 150 Hz spacing · BPSK · Pilot {PILOT_FREQ} Hz
              </div>
              <button onClick={handlePlay} disabled={playing} className="w-full bg-[#3b8bff] text-white py-2 rounded text-xs font-bold flex items-center justify-center gap-1.5 disabled:opacity-50">
                {playing ? <><Square size={12} /> Playing...</> : <><Play size={12} /> Play Audio</>}
              </button>
            </>
          )}
        </div>
      </div>

      {/* RX Panel */}
      <div className="bg-[#12161A] border border-[#30363d] rounded-lg p-4">
        <div className="text-xs font-bold text-[#e6edf3] mb-3 flex items-center gap-2">
          <Waves size={14} className="text-[#30d158]" /> RX — Acoustic Decoder
        </div>

        {/* Loopback test */}
        <div className="space-y-3">
          <div className="bg-[#0d1117] border border-[#30363d] rounded p-3">
            <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-2">Loopback Test (bypass speaker/mic)</div>
            <button onClick={handleLoopback} disabled={!encoded} className="w-full bg-[#30d158] text-black py-2 rounded text-xs font-bold disabled:opacity-40">
              Decode Generated Signal
            </button>
            {loopbackResult && (
              <div className="mt-2">
                {loopbackResult.match ? (
                  <div className="flex items-center gap-2 text-[#30d158]">
                    <CheckCircle2 size={14} />
                    <span className="text-xs font-bold">Round-trip PASS — OFDM math verified</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-[#ff3b30]">
                    <XCircle size={14} />
                    <span className="text-xs font-bold">Round-trip MISMATCH</span>
                  </div>
                )}
                <div className="mt-1 bg-[#0d1117] border border-[#30363d] rounded p-2">
                  <div className="text-[9px] text-[#8b949e]">Decoded: {loopbackResult.decoded}</div>
                  <div className="text-[9px] text-[#8b949e]">Original: {loopbackResult.original}</div>
                  <div className="text-[9px] text-[#484f58] mt-1">{loopbackResult.bits} bits recovered</div>
                </div>
              </div>
            )}
          </div>

          {/* Mic recording */}
          <div className="bg-[#0d1117] border border-[#30363d] rounded p-3">
            <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-2">Real Speaker → Mic Path</div>
            <p className="text-[9px] text-[#484f58] mb-2">Play the audio from the TX panel, then record with your mic. The decoder searches for the 1200 Hz pilot and demodulates the OFDM subcarriers.</p>
            <button onClick={handleMicRecord} disabled={recording} className="w-full bg-[#ff9f0a] text-black py-2 rounded text-xs font-bold flex items-center justify-center gap-1.5 disabled:opacity-50">
              {recording ? <><Loader2 size={12} className="animate-spin" /> Recording 5s...</> : <><Mic size={12} /> Record from Mic (5s)</>}
            </button>
            {micStatus && typeof micStatus === 'object' && (
              <div className="mt-2 bg-[#0d1117] border border-[#30363d] rounded p-2">
                {micStatus.error ? (
                  <div className="text-[10px] text-[#ff3b30]">{micStatus.error}</div>
                ) : (
                  <>
                    <div className="text-[9px] text-[#30d158] uppercase tracking-wider">Mic Decoded</div>
                    <div className="text-xs text-[#e6edf3] font-mono mt-1">{micStatus.decoded || '(empty)'}</div>
                    <div className="text-[9px] text-[#484f58] mt-1">{micStatus.bits} bits recovered</div>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Technical specs */}
          <div className="bg-[#0d1117] border border-[#30363d] rounded p-3">
            <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-2">Technical Specs</div>
            <div className="grid grid-cols-2 gap-2 text-[10px]">
              <div><span className="text-[#8b949e]">Sample rate:</span> <span className="text-[#e6edf3] font-mono">{SAMPLE_RATE} Hz</span></div>
              <div><span className="text-[#8b949e]">Symbol duration:</span> <span className="text-[#e6edf3] font-mono">{(SYMBOL_DURATION * 1000).toFixed(0)} ms</span></div>
              <div><span className="text-[#8b949e]">Subcarriers:</span> <span className="text-[#e6edf3] font-mono">{NUM_SUBCARRIERS}</span></div>
              <div><span className="text-[#8b949e]">Bits/symbol:</span> <span className="text-[#e6edf3] font-mono">{NUM_SUBCARRIERS} (BPSK)</span></div>
              <div><span className="text-[#8b949e]">Data rate:</span> <span className="text-[#e6edf3] font-mono">{(NUM_SUBCARRIERS / SYMBOL_DURATION).toFixed(0)} bps</span></div>
              <div><span className="text-[#8b949e]">Pilot:</span> <span className="text-[#e6edf3] font-mono">{PILOT_FREQ} Hz</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}