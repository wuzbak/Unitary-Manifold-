import IntegrationHealthPanel from '@/components/shared/IntegrationHealthPanel';
import { Key } from 'lucide-react';

/**
 * TabApiKeys — API Keys & Sources settings tab for the journalist app.
 * Delegates to the shared IntegrationHealthPanel, which shows live
 * configured/missing status AND a per-connector "test connection" action
 * that probes each fetcher end-to-end. Never exposes secret values.
 */
export default function TabApiKeys() {
  return (
    <div className="space-y-4">
      <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
        <div className="flex items-center gap-2 mb-2">
          <Key size={16} className="text-[#FF9F00]" />
          <h2 className="text-[#FF9F00] text-sm font-bold uppercase tracking-wider">API Keys & Data Sources</h2>
        </div>
        <p className="text-[#8b949e] text-xs leading-relaxed">
          Each data source requires an API key or token to fetch live records. Use "Test" to probe each connector end-to-end — a live request is sent and the real upstream response (record count or exact error) is shown. Keys are set in the app's secret settings and are never exposed.
        </p>
      </div>
      <IntegrationHealthPanel />
    </div>
  );
}