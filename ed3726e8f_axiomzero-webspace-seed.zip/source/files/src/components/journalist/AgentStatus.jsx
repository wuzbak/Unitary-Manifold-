import { CheckCircle2, Loader2, Circle, AlertTriangle } from 'lucide-react';
import { AGENTS, PIPELINE_STAGES } from '@/lib/journalist/pipeline';

/**
 * AgentStatus — shows the five agents and the six pipeline stages with live status.
 */
export default function AgentStatus({ stageStatus, agentStatus }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
      {/* Agents */}
      <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-3">
        <div className="text-[9px] text-[#4DD0E1] uppercase tracking-wider mb-2">Five-Agent Architecture</div>
        <div className="space-y-1.5">
          {AGENTS.map(a => {
            const status = agentStatus?.[a.id] || 'idle';
            const Icon = status === 'running' ? Loader2 : status === 'done' ? CheckCircle2 : Circle;
            const color = status === 'running' ? '#58a6ff' : status === 'done' ? '#3fb950' : status === 'error' ? '#f85149' : '#484f58';
            return (
              <div key={a.id} className="flex items-center gap-2">
                <Icon size={11} style={{ color }} className={status === 'running' ? 'animate-spin' : ''} />
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] font-bold text-[#e6edf3]">{a.name}</div>
                  <div className="text-[9px] text-[#8b949e]">{a.role}</div>
                </div>
                <span className="text-[9px] uppercase tracking-wider" style={{ color }}>{status}</span>
              </div>
            );
          })}
        </div>
      </div>
      {/* Stages */}
      <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-3">
        <div className="text-[9px] text-[#4DD0E1] uppercase tracking-wider mb-2">Six-Stage Pipeline</div>
        <div className="space-y-1">
          {PIPELINE_STAGES.map(s => {
            const status = stageStatus?.[s.id] || 'idle';
            const Icon = status === 'running' ? Loader2 : status === 'done' ? CheckCircle2 : status === 'error' ? AlertTriangle : Circle;
            const color = status === 'running' ? '#58a6ff' : status === 'done' ? '#3fb950' : status === 'error' ? '#f85149' : '#484f58';
            return (
              <div key={s.id} className="flex items-center gap-2">
                <Icon size={10} style={{ color }} className={status === 'running' ? 'animate-spin' : ''} />
                <span className="text-[10px] text-[#e6edf3] flex-1">{s.label}</span>
                <span className="text-[8px] uppercase tracking-wider" style={{ color }}>{status}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}