import { useState } from 'react';
import { Plus, Trash2, GitBranch, Network } from 'lucide-react';
import JournalistPanel from './JournalistPanel';
import EntityGraph from './EntityGraph';

const REL_TYPES = ['officer_of', 'director_of', 'shared_address', 'beneficial_owner', 'linked_in_leaks', 'linked_in_offshore', 'intermediary_for', 'contractual', 'familial'];

/**
 * TabRelationships — entity relationship graph with manual add and Editor-suggested relationships.
 */
export default function TabRelationships({ inv, onAdd, onRemove, suggestions }) {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [type, setType] = useState('officer_of');
  const [ref, setRef] = useState('');

  const entities = inv?.entities || [];
  const relationships = inv?.relationships || [];

  const add = () => {
    if (!from || !to || !inv) return;
    onAdd({ from_entity: from, to_entity: to, type, source_ref: ref.trim() });
    setFrom(''); setTo(''); setType('officer_of'); setRef('');
  };

  return (
    <div className="space-y-4">
      <JournalistPanel title="Entity Relationship Network" icon={Network} accent="#4DD0E1">
        <EntityGraph entities={entities} relationships={relationships} />
      </JournalistPanel>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="space-y-3">
          <JournalistPanel title="Add Relationship" icon={Plus} accent="#FF9F00">
            {!inv ? <p className="text-[#f85149] text-xs">Start or load an investigation first.</p> : (
              <div className="space-y-3">
                <div>
                  <label className="text-[9px] text-[#8b949e] block mb-1">From Entity *</label>
                  <select value={from} onChange={e => setFrom(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]">
                    <option value="">— Select entity —</option>
                    {entities.map((e, i) => <option key={i} value={e.name}>{e.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[9px] text-[#8b949e] block mb-1">Relationship Type</label>
                  <select value={type} onChange={e => setType(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]">
                    {REL_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[9px] text-[#8b949e] block mb-1">To Entity *</label>
                  <select value={to} onChange={e => setTo(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]">
                    <option value="">— Select entity —</option>
                    {entities.map((e, i) => <option key={i} value={e.name}>{e.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[9px] text-[#8b949e] block mb-1">Source Reference (URL or source title)</label>
                  <input value={ref} onChange={e => setRef(e.target.value)} placeholder="Where this relationship is documented" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
                </div>
                <button onClick={add} disabled={!from || !to} className="flex items-center gap-1.5 bg-[#FF9F00] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"><Plus size={12} /> Add Relationship</button>
              </div>
            )}
          </JournalistPanel>

          {suggestions && suggestions.length > 0 && (
            <JournalistPanel title="Editor-Suggested Relationships" icon={GitBranch} accent="#bc8cff">
              <div className="space-y-1">
                {suggestions.map((s, i) => (
                  <button key={i} onClick={() => onAdd({ from_entity: s.from_entity, to_entity: s.to_entity, type: s.type || 'linked_in_leaks', source_ref: s.source_ref || '' })}
                    className="w-full text-left p-2 rounded border border-[#30363d] hover:border-[#bc8cff]/40 text-xs">
                    <span className="text-[#bc8cff] font-bold">[{s.type}]</span> <span className="text-[#e6edf3]">{s.from_entity} → {s.to_entity}</span>
                  </button>
                ))}
              </div>
            </JournalistPanel>
          )}
        </div>

        <JournalistPanel title={`Relationships (${relationships.length})`} icon={GitBranch} accent="#4DD0E1" bodyClassName="p-3">
          {!relationships.length ? <p className="text-[#8b949e] text-xs italic text-center py-4">No relationships mapped yet. Run the pipeline or add manually.</p> : (
            <div className="space-y-2 max-h-[65vh] overflow-y-auto pr-1">
              {relationships.map((r, i) => (
                <div key={i} className="border border-[#30363d] clip-corner p-2.5 bg-[#0B0F13]/60 group">
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] px-1.5 py-0.5 rounded font-bold bg-[#bc8cff]/20 text-[#bc8cff]">{r.type}</span>
                    <span className="text-xs text-[#e6edf3] flex-1">{r.from_entity} → {r.to_entity}</span>
                    <button onClick={() => onRemove(i)} className="text-[#484f58] hover:text-[#f85149] opacity-0 group-hover:opacity-100"><Trash2 size={11} /></button>
                  </div>
                  {r.source_ref && <p className="text-[10px] text-[#8b949e] mt-1 truncate">Source: {r.source_ref}</p>}
                </div>
              ))}
            </div>
          )}
        </JournalistPanel>
      </div>
    </div>
  );
}