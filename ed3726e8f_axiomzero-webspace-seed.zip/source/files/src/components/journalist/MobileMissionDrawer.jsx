import { useState } from 'react';
import { ChevronUp, ChevronDown, Activity, Loader2 } from 'lucide-react';
import LocalAnalysisPanel from '@/components/journalist/LocalAnalysisPanel';
import { TEMPLATE_BY_ID } from '@/lib/journalist/templates';

/**
 * MobileMissionDrawer — bottom-anchored drawer that surfaces the desktop
 * sidebar's "mission control" context (active case card, pipeline mini-status,
 * local analysis panel) on mobile, where the sidebar is hidden.
 *
 * Renders a compact summary bar at the bottom of the screen. Tapping it
 * expands a bottom sheet with the full mission context.
 */
export default function MobileMissionDrawer({ inv, running, stageStatus, caseLibrary }) {
  const [open, setOpen] = useState(false);

  if (!inv) return null;

  return (
    <>
      {/* Compact summary bar — always visible on mobile when a case is active */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40">
        <button
          onClick={() => setOpen(!open)}
          className="w-full flex items-center gap-2 px-4 py-2.5 glass-strong border-t border-[#FF9F00]/30 text-left"
        >
          <div className="w-2 h-2 rounded-full bg-[#FF9F00] glow-pulse shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-[#FF9F00] text-[9px] font-bold uppercase tracking-wider">Active Case</div>
            <div className="text-[#e6edf3] text-xs font-bold truncate">{inv.title}</div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-[9px] text-[#4DD0E1] font-bold">{inv.entities.length}E</span>
            <span className="text-[9px] text-[#58a6ff] font-bold">{inv.sources.length}S</span>
            <span className="text-[9px] text-[#d29922] font-bold">{inv.claims.length}C</span>
            {running && <Loader2 size={12} className="animate-spin text-[#FF9F00]" />}
            {open ? <ChevronDown size={16} className="text-[#8b949e]" /> : <ChevronUp size={16} className="text-[#8b949e]" />}
          </div>
        </button>
      </div>

      {/* Expanded bottom sheet */}
      {open && (
        <>
          {/* Backdrop */}
          <div className="lg:hidden fixed inset-0 z-40 bg-black/60 backdrop-blur-sm" onClick={() => setOpen(false)} />

          {/* Sheet */}
          <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50 max-h-[70vh] overflow-y-auto glass-strong border-t-2 border-[#FF9F00]/40 rounded-t-lg fade-in">
            <div className="sticky top-0 flex items-center justify-between px-4 py-2.5 border-b border-[#30363d] bg-[#0d1117]/95 backdrop-blur-md">
              <div className="flex items-center gap-2">
                <Activity size={14} className="text-[#FF9F00]" />
                <span className="text-[#FF9F00] text-xs font-bold uppercase tracking-wider">Mission Control</span>
              </div>
              <button onClick={() => setOpen(false)} className="text-[#8b949e] hover:text-[#e6edf3]">
                <ChevronDown size={18} />
              </button>
            </div>

            <div className="p-3 space-y-3">
              {/* Active case card */}
              <div className="bg-[#0d1117]/80 border border-[#FF9F00]/20 clip-corner p-3">
                <div className="text-[8px] text-[#FF9F00] uppercase tracking-[0.2em] font-bold mb-1.5">Active Case</div>
                <div className="text-xs font-bold text-[#e6edf3] leading-snug mb-2">{inv.title}</div>
                {inv.template && (
                  <div className="text-[9px] text-[#bc8cff] mb-2">{TEMPLATE_BY_ID[inv.template]?.label || inv.template}</div>
                )}
                <div className="grid grid-cols-3 gap-1.5 text-[9px]">
                  <div className="bg-[#0B0F13]/60 border border-[#30363d] rounded px-1.5 py-1 text-center">
                    <div className="text-[#4DD0E1] font-bold">{inv.entities.length}</div>
                    <div className="text-[#484f58]">entities</div>
                  </div>
                  <div className="bg-[#0B0F13]/60 border border-[#30363d] rounded px-1.5 py-1 text-center">
                    <div className="text-[#58a6ff] font-bold">{inv.sources.length}</div>
                    <div className="text-[#484f58]">sources</div>
                  </div>
                  <div className="bg-[#0B0F13]/60 border border-[#30363d] rounded px-1.5 py-1 text-center">
                    <div className="text-[#d29922] font-bold">{inv.claims.length}</div>
                    <div className="text-[#484f58]">claims</div>
                  </div>
                  <div className="bg-[#0B0F13]/60 border border-[#30363d] rounded px-1.5 py-1 text-center">
                    <div className="text-[#bc8cff] font-bold">{inv.evidence.length}</div>
                    <div className="text-[#484f58]">evidence</div>
                  </div>
                  <div className="bg-[#0B0F13]/60 border border-[#30363d] rounded px-1.5 py-1 text-center">
                    <div className="text-[#FF9F00] font-bold">{inv.relationships?.length || 0}</div>
                    <div className="text-[#484f58]">relations</div>
                  </div>
                  <div className="bg-[#0B0F13]/60 border border-[#30363d] rounded px-1.5 py-1 text-center">
                    <div className="text-[#d29922] font-bold">{inv.comment_requests?.length || 0}</div>
                    <div className="text-[#484f58]">comments</div>
                  </div>
                </div>
              </div>

              {/* Pipeline mini-status */}
              {running && (
                <div className="bg-[#0d1117]/80 border border-[#FF9F00]/30 clip-corner p-2.5">
                  <div className="flex items-center gap-2 mb-1.5">
                    <Loader2 size={11} className="animate-spin text-[#FF9F00]" />
                    <span className="text-[9px] text-[#FF9F00] uppercase tracking-wider font-bold">Pipeline Running</span>
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    {['scope', 'research', 'crossref', 'entity', 'gap', 'brief'].map(s => (
                      <div key={s} className="flex items-center gap-1 text-[9px]">
                        <div className={`w-1.5 h-1.5 rounded-full ${stageStatus?.[s] === 'done' ? 'bg-[#3fb950]' : stageStatus?.[s] === 'running' ? 'bg-[#FF9F00] animate-pulse' : 'bg-[#30363d]'}`} />
                        <span className={stageStatus?.[s] === 'done' ? 'text-[#3fb950]' : stageStatus?.[s] === 'running' ? 'text-[#FF9F00]' : 'text-[#484f58]'}>{s}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Local deterministic analysis */}
              <LocalAnalysisPanel inv={inv} caseLibrary={caseLibrary} />
            </div>
          </div>
        </>
      )}
    </>
  );
}