/**
 * JournalistPanel — shared glassmorphic container with sharp clipped corners.
 * The structural atom of the AXIOM Journalist visual system.
 */
export default function JournalistPanel({ title, icon: Icon, accent = '#4DD0E1', actions, children, className = '', bodyClassName = '' }) {
  return (
    <div className={`bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner ${className}`}>
      {title && (
        <div className="flex items-center gap-2 px-4 py-2.5 border-b border-[#30363d]/60 bg-gradient-to-r from-[#161b22]/40 to-transparent">
          {Icon && <Icon size={12} style={{ color: accent }} className="shrink-0" />}
          <span className="text-[10px] uppercase tracking-[0.15em] font-bold" style={{ color: accent }}>{title}</span>
          {actions && <div className="ml-auto flex items-center gap-2">{actions}</div>}
        </div>
      )}
      <div className={`p-4 ${bodyClassName}`}>{children}</div>
    </div>
  );
}