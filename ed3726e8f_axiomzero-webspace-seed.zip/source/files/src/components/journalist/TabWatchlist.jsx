import { useState } from 'react';
import { Plus, Trash2, Eye, Loader2, Bell } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { scanWatchlistEntry } from '@/lib/journalist/pipeline';

const MONITORED_DBS = [
  { id: 'secEdgar', label: 'SEC Enforcement' },
  { id: 'echoEpa', label: 'EPA Penalties' },
  { id: 'openSanctions', label: 'Sanctions' },
  { id: 'courtListener', label: 'Court filings' },
];

/**
 * TabWatchlist — add entities to monitor; scan enforcement databases for new hits.
 * The scheduled workflow does this automatically on a cadence; this tab allows manual scans.
 */
export default function TabWatchlist({ entries, hits, onAdd, onRemove, onHits }) {
  const [name, setName] = useState('');
  const [type, setType] = useState('Person');
  const [dbs, setDbs] = useState(['secEdgar', 'echoEpa', 'openSanctions']);
  const [scanning, setScanning] = useState(false);

  const add = () => {
    if (!name.trim()) return;
    onAdd({ entity_name: name.trim(), entity_type: type, monitored_databases: dbs, notes: '' });
    setName('');
  };

  const toggleDb = (id) => setDbs(d => d.includes(id) ? d.filter(x => x !== id) : [...d, id]);

  const scanAll = async () => {
    setScanning(true);
    const newHits = [];
    for (const e of entries) {
      if (!e.active) continue;
      try {
        const entryObj = { entity_name: e.entity_name, monitored_databases: e.monitored_databases || ['echoEpa', 'openSanctions', 'secEdgar'] };
        const found = await scanWatchlistEntry(entryObj);
        newHits.push(...found);
      } catch (err) { /* log gap, continue */ }
    }
    // Persist hits
    for (const h of newHits) {
      try { await base44.entities.WatchlistHit.create({ ...h, detected_date: new Date().toISOString(), promoted: false }); } catch {}
    }
    onHits();
    setScanning(false);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="space-y-3">
        <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
          <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-3">Add Watchlist Entity</div>
          <label className="text-[9px] text-[#8b949e] block mb-1">Entity Name *</label>
          <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Acme Corp" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
          <label className="text-[9px] text-[#8b949e] block mb-1">Type</label>
          <select value={type} onChange={e => setType(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2">
            {['Person', 'Organization', 'Corporate Structure', 'Government Agency'].map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          <label className="text-[9px] text-[#8b949e] block mb-1">Monitored Databases</label>
          <div className="space-y-1 mb-3">
            {MONITORED_DBS.map(d => (
              <label key={d.id} className="flex items-center gap-2 text-[10px] text-[#e6edf3]">
                <input type="checkbox" checked={dbs.includes(d.id)} onChange={() => toggleDb(d.id)} className="accent-[#58a6ff]" /> {d.label}
              </label>
            ))}
          </div>
          <button onClick={add} disabled={!name.trim()} className="flex items-center gap-1.5 bg-[#FF9F00] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"><Plus size={12} /> Add to Watchlist</button>
        </div>
        <button onClick={scanAll} disabled={scanning || !entries.length} className="w-full flex items-center justify-center gap-2 bg-[#d29922]/10 border border-[#d29922]/40 text-[#d29922] px-3 py-2 rounded text-xs font-bold hover:bg-[#d29922]/20 disabled:opacity-40">
          {scanning ? <Loader2 size={12} className="animate-spin" /> : <Eye size={12} />} {scanning ? 'Scanning enforcement databases…' : 'Scan All Watchlists Now'}
        </button>
      </div>
      <div className="space-y-3">
        <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
          <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-3">Watched Entities ({entries.length})</div>
          {!entries.length ? <p className="text-[#8b949e] text-xs italic">No entities on watchlist.</p> : (
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {entries.map(e => (
                <div key={e.id} className="border border-[#30363d] rounded p-2 flex items-center gap-2">
                  <span className="text-[10px] border border-[#58a6ff]/30 text-[#58a6ff] px-1.5 py-0.5 rounded">{e.entity_type}</span>
                  <span className="text-xs font-bold text-[#e6edf3] flex-1">{e.entity_name}</span>
                  <button onClick={() => onRemove(e.id)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={11} /></button>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#d29922]/30 clip-corner p-4">
          <div className="flex items-center gap-2 mb-3"><Bell size={12} className="text-[#d29922]" /><span className="text-[10px] text-[#d29922] uppercase tracking-wider">Watchlist Hits ({hits.length})</span></div>
          {!hits.length ? <p className="text-[#8b949e] text-xs italic">No enforcement hits detected yet.</p> : (
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {hits.map(h => (
                <div key={h.id} className="border border-[#d29922]/20 rounded p-2">
                  <div className="flex items-center gap-2"><span className="text-[9px] bg-[#d29922]/20 text-[#d29922] px-1.5 py-0.5 rounded font-bold">{h.database}</span><span className="text-xs text-[#e6edf3]">{h.watchlist_name}</span></div>
                  <p className="text-[10px] text-[#8b949e] mt-1">{h.summary}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}