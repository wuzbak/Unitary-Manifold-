import { useState, useEffect, useRef } from 'react';

const TYPE_COLORS = {
  Person: '#58a6ff',
  Organization: '#3fb950',
  'Government Agency': '#d29922',
  'Corporate Structure': '#bc8cff',
  Location: '#f85149',
  'Financial Instrument': '#4dd0e1',
  Other: '#8b949e',
};

const REL_COLORS = {
  officer_of: '#FF9F00',
  director_of: '#FF9F00',
  shared_address: '#4DD0E1',
  beneficial_owner: '#3fb950',
  linked_in_leaks: '#bc8cff',
  linked_in_offshore: '#bc8cff',
  intermediary_for: '#d29922',
  contractual: '#58a6ff',
  familial: '#f85149',
};

/**
 * EntityGraph — SVG force-directed network graph of investigation entities and relationships.
 * Runs a simple physics simulation (repulsion + edge attraction + center gravity) for 300
 * iterations on mount, then renders the settled positions.
 */
export default function EntityGraph({ entities = [], relationships = [], onNodeClick }) {
  const [nodes, setNodes] = useState([]);
  const [hovered, setHovered] = useState(null);

  useEffect(() => {
    if (!entities.length) { setNodes([]); return; }
    const W = 600, H = 400;
    const simNodes = entities.map((e, i) => ({
      id: e.name,
      label: e.name,
      type: e.type || 'Other',
      x: W / 2 + Math.cos((2 * Math.PI * i) / entities.length) * 120,
      y: H / 2 + Math.sin((2 * Math.PI * i) / entities.length) * 80,
      vx: 0, vy: 0,
    }));
    const simEdges = relationships.filter(r => r.from_entity && r.to_entity);

    for (let iter = 0; iter < 300; iter++) {
      for (let i = 0; i < simNodes.length; i++) {
        for (let j = i + 1; j < simNodes.length; j++) {
          const dx = simNodes[i].x - simNodes[j].x;
          const dy = simNodes[i].y - simNodes[j].y;
          const dist = Math.max(1, Math.sqrt(dx * dx + dy * dy));
          const force = 3000 / (dist * dist);
          simNodes[i].vx += (dx / dist) * force;
          simNodes[i].vy += (dy / dist) * force;
          simNodes[j].vx -= (dx / dist) * force;
          simNodes[j].vy -= (dy / dist) * force;
        }
      }
      for (const edge of simEdges) {
        const s = simNodes.find(n => n.id === edge.from_entity);
        const t = simNodes.find(n => n.id === edge.to_entity);
        if (!s || !t) continue;
        const dx = t.x - s.x;
        const dy = t.y - s.y;
        const dist = Math.max(1, Math.sqrt(dx * dx + dy * dy));
        const force = (dist - 120) * 0.05;
        s.vx += (dx / dist) * force;
        s.vy += (dy / dist) * force;
        t.vx -= (dx / dist) * force;
        t.vy -= (dy / dist) * force;
      }
      for (const n of simNodes) {
        n.vx += (W / 2 - n.x) * 0.01;
        n.vy += (H / 2 - n.y) * 0.01;
      }
      for (const n of simNodes) {
        n.vx *= 0.9;
        n.vy *= 0.9;
        n.x += n.vx;
        n.y += n.vy;
        n.x = Math.max(30, Math.min(W - 30, n.x));
        n.y = Math.max(30, Math.min(H - 30, n.y));
      }
    }
    setNodes(simNodes);
  }, [entities, relationships]);

  if (!entities.length) {
    return <div className="text-center text-[#8b949e] text-xs py-8">No entities to graph. Add entities to see the network.</div>;
  }

  return (
    <div className="relative">
      <svg viewBox="0 0 600 400" className="w-full h-auto bg-[#0B0F13] border border-[#30363d] clip-corner">
        {relationships.filter(r => r.from_entity && r.to_entity).map((r, i) => {
          const s = nodes.find(n => n.id === r.from_entity);
          const t = nodes.find(n => n.id === r.to_entity);
          if (!s || !t) return null;
          const color = REL_COLORS[r.type] || '#484f58';
          return (
            <g key={i}>
              <line x1={s.x} y1={s.y} x2={t.x} y2={t.y} stroke={color} strokeWidth={1.5} strokeOpacity={0.5} />
              <text x={(s.x + t.x) / 2} y={(s.y + t.y) / 2} fill={color} fontSize={7} textAnchor="middle" className="pointer-events-none select-none">{r.type}</text>
            </g>
          );
        })}
        {nodes.map(n => {
          const color = TYPE_COLORS[n.type] || '#8b949e';
          const isHovered = hovered === n.id;
          return (
            <g key={n.id} onClick={() => onNodeClick?.(n)} onMouseEnter={() => setHovered(n.id)} onMouseLeave={() => setHovered(null)} className="cursor-pointer">
              <circle cx={n.x} cy={n.y} r={isHovered ? 10 : 7} fill={color} fillOpacity={0.3} stroke={color} strokeWidth={2} />
              <text x={n.x} y={n.y - 12} fill={color} fontSize={9} textAnchor="middle" fontWeight="bold" className="pointer-events-none select-none">{n.label.length > 22 ? n.label.slice(0, 20) + '…' : n.label}</text>
            </g>
          );
        })}
      </svg>
      <div className="flex flex-wrap gap-2 mt-2 text-[9px]">
        {Object.entries(TYPE_COLORS).filter(([t]) => entities.some(e => e.type === t)).map(([type, color]) => (
          <span key={type} className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full" style={{ background: color }} />
            <span className="text-[#8b949e]">{type}</span>
          </span>
        ))}
      </div>
    </div>
  );
}