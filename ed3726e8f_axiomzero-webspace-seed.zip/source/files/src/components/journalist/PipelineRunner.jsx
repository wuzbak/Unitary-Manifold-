import { useState } from 'react';
import { Play, Loader2, FileSearch, AlertTriangle } from 'lucide-react';
import AgentStatus from './AgentStatus';

/**
 * PipelineRunner — launches the five-agent investigation pipeline and shows live progress.
 */
export default function PipelineRunner({ inv, running, onRun, stageStatus, agentStatus, fetchLog, lastReport }) {
  const [confirm, setConfirm] = useState(false);
  return (
    <div className="space-y-3">
      <div className="bg-gradient-to-r from-[#FF9F00]/10 to-[#4dd0e1]/10 border border-[#FF9F00]/30 clip-corner p-4">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <FileSearch size={16} className="text-[#FF9F00]" />
              <span className="text-sm font-bold text-[#e6edf3]">Run Five-Agent Investigation Pipeline</span>
            </div>
            <p className="text-[10px] text-[#8b949e] max-w-2xl">
              Deploys the Researcher (live multi-source fetch), Fact Checker (dedup + 5-tier scoring + contradiction detection),
              Legal Auditor (statutory mapping), and Editor (steelman + synthesis), coordinated by the Orchestrator.
              Output is a structured brief — <span className="text-[#d29922] font-bold">FOR HUMAN REVIEW ONLY</span>.
            </p>
          </div>
          <button onClick={onRun} disabled={!inv || running}
            className="flex items-center gap-2 bg-[#FF9F00] text-black px-5 py-2.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40 whitespace-nowrap">
            {running ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />}
            {running ? 'Pipeline running…' : 'Run Pipeline'}
          </button>
        </div>
      </div>

      {(running || stageStatus) && <AgentStatus stageStatus={stageStatus} agentStatus={agentStatus} />}

      {fetchLog && fetchLog.length > 0 && (
        <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-3">
          <div className="text-[9px] text-[#4DD0E1] uppercase tracking-wider mb-2">Researcher Fetch Log</div>
          <div className="space-y-1 max-h-48 overflow-y-auto">
            {fetchLog.map((l, i) => (
              <div key={i} className="flex items-center gap-2 text-[10px]">
                <span className={`px-1.5 py-0.5 rounded font-bold ${l.status === 'ok' ? 'bg-[#3fb950]/20 text-[#3fb950]' : l.status === 'error' ? 'bg-[#f85149]/20 text-[#f85149]' : 'bg-[#8b949e]/20 text-[#8b949e]'}`}>
                  {l.status === 'ok' ? `${l.count} hits` : l.status === 'error' ? 'gap' : 'empty'}
                </span>
                <span className="text-[#e6edf3] font-bold">{l.source}</span>
                <span className="text-[#484f58] truncate">“{l.query}”</span>
                {l.error && <span className="text-[#f85149] truncate">⚠ {l.error}</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      {lastReport && (
        <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-3 flex items-center gap-3 flex-wrap text-[10px]">
          <span className="text-[#3fb950] font-bold">Pipeline complete</span>
          <span className="text-[#8b949e]">Sources: {lastReport.newSources} new</span>
          <span className="text-[#8b949e]">Contradictions: {lastReport.contradictions}</span>
          {lastReport.gaps > 0 && <span className="text-[#d29922]">Gaps logged: {lastReport.gaps}</span>}
        </div>
      )}
    </div>
  );
}