import { useState } from 'react';
import { Plus, FolderOpen, Trash2, ExternalLink, Loader2 } from 'lucide-react';
import { SourceTier, TIER_LABELS, TIER_SHORT, TIER_WEIGHT, generateId } from '@/lib/journalist/investigator';
import { SOURCE_REGISTRY, SOURCES_BY_TIER } from '@/lib/journalist/sourceRegistry';

const TIER_COLORS = { 1: '#3fb950', 2: '#4dd0e1', 3: '#d29922', 4: '#bc8cff', 5: '#f85149', 0: '#8b949e' };

/**
 * TabSources — log sources manually with a 5-tier picker, or let the Researcher fetch them.
 */
export default function TabSources({ inv, onAdd, onRemove, fetching, onFetchSingle, fetchLog }) {
  const [title, setTitle] = useState('');
  const [tier, setTier] = useState(SourceTier.TIER_1);
  const [type, setType] = useState('');
  const [ref, setRef] = useState('');
  const [date, setDate] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [pickerOpen, setPickerOpen] = useState(false);
  const [fetchQuery, setFetchQuery] = useState('');

  const add = () => {
    if (!title.trim() || !inv) return;
    onAdd({ id: generateId('src'), title: title.trim(), tier: parseInt(tier), source_type: type.trim(), url_or_ref: ref.trim(), date: date.trim(), excerpt: excerpt.trim(), provenance: { fetcher: 'Manual entry', fetcher_fn: 'manual', query: '', fetched_at: new Date().toISOString(), fingerprint: '' } });
    setTitle(''); setType(''); setRef(''); setDate(''); setExcerpt('');
  };

  const qScore = inv ? (inv.sources || []).reduce((s, x) => s + (TIER_WEIGHT[x.tier] || 0), 0) / ((inv.sources || []).length || 1) : 0;

  return (
    <div className="space-y-4">
      {/* Researcher quick-fetch */}
      <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#4DD0E1]/30 clip-corner p-3">
        <div className="text-[9px] text-[#4DD0E1] uppercase tracking-wider mb-2">Researcher — Quick Single-Source Fetch</div>
        <div className="flex gap-2 flex-wrap">
          <input value={fetchQuery} onChange={e => setFetchQuery(e.target.value)} placeholder="Entity / company / person / URL to fetch" className="flex-1 min-w-[200px] bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
          <select onChange={e => { if (e.target.value && fetchQuery.trim()) onFetchSingle(e.target.value, fetchQuery.trim()); e.target.value = ''; }} className="bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" disabled={fetching}>
            <option value="">Fetch from…</option>
            {SOURCE_REGISTRY.filter(s => s.fn).map(s => <option key={s.id} value={s.fn}>{s.name}</option>)}
          </select>
        </div>
        {fetching && <div className="flex items-center gap-2 mt-2 text-[10px] text-[#58a6ff]"><Loader2 size={11} className="animate-spin" /> Researcher fetching…</div>}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="space-y-3">
          <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
            <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-3">Log Source Manually</div>
            {!inv && <p className="text-[#f85149] text-xs">Start or load an investigation first.</p>}
            {inv && <>
              <label className="text-[9px] text-[#8b949e] block mb-1">Title *</label>
              <input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. SEC Filing 10-K 2025" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
              <label className="text-[9px] text-[#8b949e] block mb-1">Tier (trust score)</label>
              <select value={tier} onChange={e => setTier(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2">
                {[1, 2, 3, 4, 5].map(t => <option key={t} value={t}>{TIER_LABELS[t]} · weight {TIER_WEIGHT[t]}</option>)}
              </select>
              <label className="text-[9px] text-[#8b949e] block mb-1">Source Type</label>
              <input value={type} onChange={e => setType(e.target.value)} placeholder="e.g. Court filing, FOIA, News article" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
              <label className="text-[9px] text-[#8b949e] block mb-1">URL or Document Reference</label>
              <input value={ref} onChange={e => setRef(e.target.value)} placeholder="https://… or document ref #" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
              <label className="text-[9px] text-[#8b949e] block mb-1">Date</label>
              <input value={date} onChange={e => setDate(e.target.value)} placeholder="YYYY-MM-DD" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
              <label className="text-[9px] text-[#8b949e] block mb-1">Key Excerpt</label>
              <textarea value={excerpt} onChange={e => setExcerpt(e.target.value)} placeholder="The passage that matters" rows={3} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-3 resize-none" />
              <button onClick={add} disabled={!title.trim()} className="flex items-center gap-1.5 bg-[#FF9F00] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"><Plus size={12} /> Log Source</button>
            </>}
          </div>
          {/* Source registry picker */}
          <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-3">
            <button onClick={() => setPickerOpen(o => !o)} className="text-[9px] text-[#8b949e] uppercase tracking-wider hover:text-[#e6edf3]">Source Registry {pickerOpen ? '▲' : '▼'}</button>
            {pickerOpen && (
              <div className="mt-2 space-y-2 max-h-60 overflow-y-auto">
                {SOURCES_BY_TIER.map(group => (
                  <div key={group.tier}>
                    <div className="text-[9px] font-bold mb-1" style={{ color: TIER_COLORS[group.tier] }}>{group.label}</div>
                    {group.sources.map(s => (
                      <div key={s.id} className="text-[9px] text-[#8b949e] py-0.5 flex items-center gap-1">
                        <span className="text-[#e6edf3] font-bold">{s.name}</span>
                        {s.fn && <span className="text-[#3fb950] text-[8px]">●live</span>}
                        <a href={s.url} target="_blank" rel="noreferrer" className="text-[#58a6ff] hover:underline"><ExternalLink size={8} /></a>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2"><FolderOpen size={12} className="text-[#8b949e]" /><span className="text-[10px] text-[#8b949e] uppercase tracking-wider">Sources ({inv?.sources?.length || 0})</span></div>
            <div className="text-[10px] text-[#3fb950]">Quality: {qScore.toFixed(2)}</div>
          </div>
          {!inv?.sources?.length ? <p className="text-[#8b949e] text-xs italic">No sources yet. Run the pipeline or log one manually. The investigation is only as strong as its Tier-1 sources.</p> : (
            <div className="space-y-2 max-h-[60vh] overflow-y-auto">
              {inv.sources.map((s, i) => (
                <div key={i} className="border border-[#30363d] rounded p-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] px-1.5 py-0.5 rounded font-bold" style={{ background: `${TIER_COLORS[s.tier]}20`, color: TIER_COLORS[s.tier] }}>{TIER_SHORT[s.tier] || 'T?'}</span>
                    <span className="text-xs font-bold text-[#e6edf3] flex-1">{s.title}</span>
                    <button onClick={() => onRemove(i)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={11} /></button>
                  </div>
                  {s.source_type && <p className="text-[10px] text-[#8b949e] mt-1">Type: {s.source_type}</p>}
                  {s.url_or_ref && <p className="text-[10px] mt-1 truncate">{s.url_or_ref.startsWith('http') ? <a href={s.url_or_ref} target="_blank" rel="noreferrer" className="text-[#58a6ff] hover:underline flex items-center gap-1"><ExternalLink size={9} /> {s.url_or_ref}</a> : <span className="text-[#8b949e]">Ref: {s.url_or_ref}</span>}</p>}
                  {s.date && <p className="text-[10px] text-[#8b949e] mt-1">Date: {s.date}</p>}
                  {s.excerpt && <p className="text-[10px] text-[#8b949e] mt-1 italic">“{s.excerpt.slice(0, 140)}{s.excerpt.length > 140 ? '…' : ''}”</p>}
                  {s.provenance && (
                    <div className="text-[9px] text-[#484f58] mt-1 flex items-center gap-1.5 flex-wrap">
                      <span className="text-[#4DD0E1]">🔗 {s.provenance.fetcher}</span>
                      <span>· query: “{s.provenance.query}”</span>
                      <span>· {new Date(s.provenance.fetched_at).toLocaleDateString()}</span>
                      {s.provenance.fingerprint && <span className="text-[#30363d]">· fp:{s.provenance.fingerprint}</span>}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}