import { useState } from 'react';
import { Loader2, CheckCircle2, XCircle, KeyRound, Play, ArrowRight, Lightbulb, Database, FileText, Users, Search, Scale, FileSearch, ExternalLink } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { SOURCE_REGISTRY, FETCHABLE_SOURCES } from '@/lib/journalist/sourceRegistry';
import JournalistPanel from './JournalistPanel';

const KNOWN_SECRETS = ['OPENSANCTIONS_API_KEY', 'OPENCORPORATES_API_TOKEN', 'FEC_API_KEY', 'COURTLISTENER_API_TOKEN', 'GOVINFO_API_KEY', 'SEC_EDGAR_CONTACT_EMAIL', 'ALEPH_API_TOKEN'];

const STEPS = [
  { icon: FileText, label: 'Create a Case', desc: 'Define your lead and select a template', accent: '#FF9F00' },
  { icon: Users, label: 'Map Entities', desc: 'Add people, orgs, and agencies to investigate', accent: '#4DD0E1' },
  { icon: Search, label: 'Run Pipeline', desc: 'Five agents fetch, score, and synthesize', accent: '#FF9F00' },
  { icon: Scale, label: 'Review Claims', desc: 'Check 5-tier confidence and contradictions', accent: '#4DD0E1' },
  { icon: FileSearch, label: 'Generate Brief', desc: 'Export the structured investigative dossier', accent: '#FF9F00' },
];

/**
 * TabOnboarding — setup wizard with source diagnostics, quick-start guide, and sample case.
 */
export default function TabOnboarding({ onCreateSample, creating }) {
  const [testing, setTesting] = useState(false);
  const [results, setResults] = useState(null);

  const runDiagnostics = async () => {
    setTesting(true);
    setResults({});
    const testQuery = 'test';
    const entries = FETCHABLE_SOURCES;
    const outcomes = await Promise.allSettled(entries.map(s => base44.functions.invoke(s.fn, { query: testQuery })));
    const map = {};
    entries.forEach((s, i) => {
      const r = outcomes[i];
      const res = r.status === 'fulfilled' ? r.value?.data : null;
      const err = r.status === 'rejected' ? String(r.reason?.message || r.reason) : res?.error;
      const hasAuthError = err && /401|unauthorized|auth|token|api.?key/i.test(err);
      map[s.id] = {
        status: err ? (hasAuthError ? 'auth' : 'error') : 'ready',
        error: err,
        count: res?.sources?.length || 0,
      };
    });
    setResults(map);
    setTesting(false);
  };

  return (
    <div className="space-y-4">
      {/* Hero */}
      <div className="bg-gradient-to-br from-[#FF9F00]/8 via-[#0d1117]/80 to-[#4DD0E1]/8 border border-[#30363d] clip-corner p-6">
        <div className="flex items-center gap-2 mb-2">
          <Lightbulb size={18} className="text-[#FF9F00]" />
          <h2 className="text-[#FF9F00] text-lg font-bold tracking-tight">Investigative Suite Setup</h2>
        </div>
        <p className="text-[#8b949e] text-xs leading-relaxed max-w-3xl">
          AXIOM is an autonomous multi-agent investigative platform — not a chatbot. This setup guide verifies your
          source connectivity, walks you through the investigation workflow, and lets you launch a sample case to
          see the five-agent pipeline in action.
        </p>
      </div>

      {/* Source diagnostics */}
      <JournalistPanel title="Source Connectivity Diagnostics" icon={Database} accent="#4DD0E1"
        actions={
          <button onClick={runDiagnostics} disabled={testing}
            className="flex items-center gap-1.5 bg-[#4DD0E1]/10 border border-[#4DD0E1]/40 text-[#4DD0E1] px-3 py-1 rounded text-[10px] font-bold hover:bg-[#4DD0E1]/20 disabled:opacity-40">
            {testing ? <Loader2 size={10} className="animate-spin" /> : <Play size={10} />}
            {testing ? 'Testing…' : 'Run Diagnostics'}
          </button>
        }>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {FETCHABLE_SOURCES.map(s => {
            const r = results?.[s.id];
            const needsSecret = !!s.requires_secret;
            const status = r?.status || (needsSecret ? 'pending' : 'ready');
            const color = status === 'ready' ? '#3fb950' : status === 'auth' ? '#f85149' : status === 'error' ? '#d29922' : '#484f58';
            const Icon = status === 'ready' ? CheckCircle2 : status === 'auth' || status === 'error' ? XCircle : KeyRound;
            return (
              <div key={s.id} className="border border-[#30363d] clip-corner p-2.5 bg-[#0B0F13]/60">
                <div className="flex items-center gap-1.5 mb-1">
                  <Icon size={11} style={{ color }} className={testing && !r ? 'animate-pulse' : ''} />
                  <span className="text-[10px] font-bold text-[#e6edf3] truncate flex-1">{s.name}</span>
                  <a href={s.url} target="_blank" rel="noreferrer" className="text-[#58a6ff] hover:underline shrink-0" title={`Open ${s.name}`}><ExternalLink size={9} /></a>
                  <span className="text-[8px] uppercase tracking-wider font-bold" style={{ color }}>{status}</span>
                </div>
                <div className="text-[9px] text-[#8b949e] leading-snug">{s.category}</div>
                {needsSecret && (
                  <div className="text-[9px] text-[#484f58] mt-1 flex items-center gap-1">
                    <KeyRound size={8} /> {s.requires_secret}
                  </div>
                )}
                {r?.count > 0 && <div className="text-[9px] text-[#3fb950] mt-1">{r.count} results on test query</div>}
                {r?.error && !/401|unauthorized/i.test(r.error) && <div className="text-[9px] text-[#d29922] mt-1 truncate">{r.error}</div>}
              </div>
            );
          })}
        </div>
        <div className="mt-3 text-[9px] text-[#484f58] flex items-center gap-2 flex-wrap">
          <span>Configured secrets:</span>
          {KNOWN_SECRETS.map(k => (
            <span key={k} className="px-1.5 py-0.5 rounded border border-[#3fb950]/20 text-[#3fb950]/70 bg-[#3fb950]/5 text-[8px] font-mono">{k}</span>
          ))}
          <span className="text-[#8b949e]">— configure additional keys in Settings</span>
        </div>
      </JournalistPanel>

      {/* Quick start guide */}
      <JournalistPanel title="Quick Start — Investigation Workflow" icon={ArrowRight} accent="#FF9F00">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
          {STEPS.map((step, i) => (
            <div key={i} className="relative">
              <div className="border border-[#30363d] clip-corner p-3 bg-[#0B0F13]/60 h-full">
                <div className="flex items-center gap-2 mb-2">
                  <step.icon size={14} style={{ color: step.accent }} />
                  <span className="text-[8px] text-[#484f58] font-bold">{String(i + 1).padStart(2, '0')}</span>
                </div>
                <div className="text-[10px] font-bold text-[#e6edf3] mb-1">{step.label}</div>
                <div className="text-[9px] text-[#8b949e] leading-snug">{step.desc}</div>
              </div>
              {i < STEPS.length - 1 && <ArrowRight size={10} className="hidden md:block absolute top-1/2 -right-1.5 -translate-y-1/2 text-[#30363d] z-10" />}
            </div>
          ))}
        </div>
      </JournalistPanel>

      {/* Sample investigation */}
      <JournalistPanel title="Sample Investigation" icon={Lightbulb} accent="#FF9F00">
        <p className="text-[10px] text-[#8b949e] mb-3 leading-relaxed">
          Launch a pre-filled sample case to see the full pipeline in action. The sample uses a financial-crime
          template with a fictional lead — safe to delete after exploring.
        </p>
        <button onClick={onCreateSample} disabled={creating}
          className="flex items-center gap-2 bg-[#FF9F00] text-black px-5 py-2.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40">
          {creating ? <Loader2 size={12} className="animate-spin" /> : <Play size={12} />}
          {creating ? 'Creating sample…' : 'Create Sample Investigation'}
        </button>
      </JournalistPanel>
    </div>
  );
}