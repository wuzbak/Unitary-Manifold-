import { useState } from 'react';
import { Plus, Trash2, FileText, Image, Link as LinkIcon, StickyNote, ExternalLink, Loader2, Paperclip } from 'lucide-react';
import JournalistPanel from './JournalistPanel';
import { base44 } from '@/api/base44Client';
import { generateId } from '@/lib/journalist/investigator';

const EVIDENCE_TYPES = [
  { id: 'document', label: 'Document', icon: FileText, color: '#4DD0E1' },
  { id: 'screenshot', label: 'Screenshot', icon: Image, color: '#bc8cff' },
  { id: 'url', label: 'URL / Web Page', icon: LinkIcon, color: '#58a6ff' },
  { id: 'note', label: 'Evidence Note', icon: StickyNote, color: '#d29922' },
];

/**
 * TabEvidence — evidence locker for raw artifacts (documents, screenshots, URLs, notes)
 * attached to the investigation. File uploads use the UploadFile integration.
 */
export default function TabEvidence({ inv, onAdd, onRemove }) {
  const [title, setTitle] = useState('');
  const [type, setType] = useState('document');
  const [url, setUrl] = useState('');
  const [desc, setDesc] = useState('');
  const [claimRef, setClaimRef] = useState('');
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  const claimOptions = (inv?.claims || []).map((c, i) => ({ idx: i, id: c.id, label: c.statement?.slice(0, 60) }));

  const add = async () => {
    if (!title.trim() || !inv) return;
    setUploading(true);
    let fileUrl = '';
    if (file && (type === 'document' || type === 'screenshot')) {
      try {
        const res = await base44.integrations.Core.UploadFile({ file });
        fileUrl = res?.file_url || '';
      } catch (e) {
        console.error('Upload failed:', e);
      }
    }
    const linkedClaimId = claimRef ? inv.claims[parseInt(claimRef)]?.id : null;
    onAdd({
      id: generateId('ev'),
      title: title.trim(),
      type,
      url: type === 'url' ? url.trim() : fileUrl,
      description: desc.trim(),
      claim_id: linkedClaimId,
      added_date: new Date().toISOString(),
    });
    setTitle(''); setType('document'); setUrl(''); setDesc(''); setClaimRef(''); setFile(null);
    setUploading(false);
  };

  const evidence = inv?.evidence || [];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="space-y-3">
        <JournalistPanel title="Add Evidence Artifact" icon={Plus} accent="#FF9F00">
          {!inv ? <p className="text-[#f85149] text-xs">Start or load an investigation first.</p> : (
            <div className="space-y-3">
              <div>
                <label className="text-[9px] text-[#8b949e] block mb-1">Title *</label>
                <input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Acme 10-K filing excerpt" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
              </div>
              <div>
                <label className="text-[9px] text-[#8b949e] block mb-1">Type</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {EVIDENCE_TYPES.map(t => (
                    <button key={t.id} onClick={() => setType(t.id)}
                      className={`flex flex-col items-center gap-1 p-2 rounded border text-[9px] transition-all ${type === t.id ? 'border-[#FF9F00]/50 bg-[#FF9F00]/10 text-[#FF9F00]' : 'border-[#30363d] text-[#8b949e] hover:border-[#484f58]'}`}>
                      <t.icon size={14} />
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>
              {(type === 'document' || type === 'screenshot') && (
                <div>
                  <label className="text-[9px] text-[#8b949e] block mb-1">Upload File</label>
                  <div className="flex items-center gap-2 bg-[#0B0F13] border border-[#30363d] rounded p-2">
                    <Paperclip size={12} className="text-[#8b949e]" />
                    <input type="file" onChange={e => setFile(e.target.files?.[0] || null)} className="text-[9px] text-[#8b949e] file:mr-2 file:rounded file:border-0 file:bg-[#30363d] file:text-[#e6edf3] file:px-2 file:py-1 file:text-[9px]" />
                  </div>
                  {file && <span className="text-[9px] text-[#3fb950] mt-1 block">{file.name} ({(file.size / 1024).toFixed(1)} KB)</span>}
                </div>
              )}
              {type === 'url' && (
                <div>
                  <label className="text-[9px] text-[#8b949e] block mb-1">URL *</label>
                  <input value={url} onChange={e => setUrl(e.target.value)} placeholder="https://…" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
                </div>
              )}
              <div>
                <label className="text-[9px] text-[#8b949e] block mb-1">Description</label>
                <textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="What this evidence shows and why it matters" rows={2} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] resize-none" />
              </div>
              {claimOptions.length > 0 && (
                <div>
                  <label className="text-[9px] text-[#8b949e] block mb-1">Linked Claim (optional)</label>
                  <select value={claimRef} onChange={e => setClaimRef(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]">
                    <option value="">— No linked claim —</option>
                    {claimOptions.map(c => <option key={c.idx} value={c.idx}>#{c.idx + 1}: {c.label}{c.label.length >= 60 ? '…' : ''}</option>)}
                  </select>
                </div>
              )}
              <button onClick={add} disabled={!title.trim() || uploading} className="flex items-center gap-1.5 bg-[#FF9F00] text-black px-4 py-2 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40">
                {uploading ? <Loader2 size={12} className="animate-spin" /> : <Plus size={12} />}
                {uploading ? 'Uploading…' : 'Add to Evidence Locker'}
              </button>
            </div>
          )}
        </JournalistPanel>
      </div>

      <JournalistPanel title={`Evidence Locker (${evidence.length})`} icon={FileText} accent="#4DD0E1" bodyClassName="p-3">
        {!evidence.length ? (
          <p className="text-[#8b949e] text-xs italic px-1 py-4 text-center">No evidence artifacts yet. Upload documents, screenshots, or log URLs on the left.</p>
        ) : (
          <div className="space-y-2 max-h-[65vh] overflow-y-auto pr-1">
            {evidence.map((e, i) => {
              const typeMeta = EVIDENCE_TYPES.find(t => t.id === e.type) || EVIDENCE_TYPES[0];
              const linkedClaim = e.claim_id ? inv.claims?.find(c => c.id === e.claim_id) : (e.claim_index != null ? inv.claims?.[e.claim_index] : null);
              return (
                <div key={i} className="border border-[#30363d] clip-corner p-3 bg-[#0B0F13]/60 group">
                  <div className="flex items-center gap-2 mb-1.5">
                    <typeMeta.icon size={12} style={{ color: typeMeta.color }} />
                    <span className="text-[9px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded" style={{ background: `${typeMeta.color}15`, color: typeMeta.color }}>{typeMeta.label}</span>
                    <span className="text-xs font-bold text-[#e6edf3] flex-1 truncate">{e.title}</span>
                    <button onClick={() => onRemove(i)} className="text-[#484f58] hover:text-[#f85149] opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={11} /></button>
                  </div>
                  {e.description && <p className="text-[10px] text-[#8b949e] mb-1.5 leading-snug">{e.description}</p>}
                  {e.url && (
                    <a href={e.url} target="_blank" rel="noreferrer" className="text-[10px] text-[#58a6ff] hover:underline flex items-center gap-1 truncate">
                      <ExternalLink size={9} /> {e.url}
                    </a>
                  )}
                  <div className="flex items-center gap-2 mt-1.5 text-[9px] text-[#484f58]">
                    <span>{new Date(e.added_date).toLocaleDateString()}</span>
                    {linkedClaim && <span className="text-[#bc8cff]">→ Claim: {linkedClaim.statement?.slice(0, 40)}…</span>}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </JournalistPanel>
    </div>
  );
}