/**
 * DossierExamples — accordion section showing two investigative dossier
 * example books from the Unitary-Manifold repository.
 *
 * Each book expands to show its per-book tailored neutrality + trigger warning,
 * then an "Open Reader" button that launches the BookReaderOverlay.
 */
import { useState } from 'react';
import { ChevronDown, ChevronUp, BookOpen, ShieldAlert, FileSearch, ArrowRight } from 'lucide-react';
import { DOSSIER_EXAMPLES } from '@/lib/journalist/bookLibrary';

export default function DossierExamples({ onOpenBook }) {
  const [expandedId, setExpandedId] = useState(null);

  const toggle = (id) => setExpandedId((prev) => (prev === id ? null : id));

  return (
    <div className="space-y-3">
      {/* Section header */}
      <div className="flex items-center gap-2 mb-1">
        <FileSearch size={14} className="text-[#FF9F00]" />
        <h3 className="text-[12px] font-bold text-[#FF9F00] uppercase tracking-[0.15em]">Dossier Examples</h3>
        <span className="text-[8px] text-[#484f58]">· 2 books from the repository</span>
      </div>

      {/* Neutrality disclaimer */}
      <div className="bg-[#0a1a1a] border border-[#4DD0E1]/20 clip-corner px-3 py-2 flex items-start gap-2">
        <ShieldAlert size={12} className="text-[#4DD0E1] shrink-0 mt-0.5" />
        <p className="text-[9px] text-[#8b949e] leading-relaxed">
          <span className="text-[#4DD0E1] font-bold uppercase tracking-wider text-[8px]">Platform Neutrality:</span>{' '}
          AxiomZero Technologies &amp; Consulting, SPC maintains no political stance, endorsement, or partisan alignment.
          These dossiers are exercises in documented public-record journalism using the AXIOM OSINT Triangulation Chain.
          The same methodology is applied to any subject regardless of party or ideology.
        </p>
      </div>

      {/* Book accordion buttons */}
      {DOSSIER_EXAMPLES.map((book) => {
        const isExpanded = expandedId === book.id;
        return (
          <div key={book.id} className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner overflow-hidden">
            <button
              onClick={() => toggle(book.id)}
              className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-[#FF9F00]/5 transition-colors"
            >
              <BookOpen size={16} style={{ color: book.accent }} className="shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-[11px] font-bold text-[#e6edf3]">{book.title}</div>
                <div className="text-[9px] text-[#484f58] truncate">{book.subtitle}</div>
              </div>
              {isExpanded ? <ChevronUp size={14} className="text-[#FF9F00] shrink-0" /> : <ChevronDown size={14} className="text-[#484f58] shrink-0" />}
            </button>

            {isExpanded && (
              <div className="px-4 pb-3 fade-in">
                <p className="text-[10px] text-[#8b949e] leading-relaxed mb-2">{book.description}</p>

                {/* Per-book warnings */}
                <div className="space-y-1.5 mb-3">
                  {book.neutralityWarning && (
                    <div className="bg-[#0a1a1a] border border-[#4DD0E1]/15 px-2.5 py-1.5 flex items-start gap-1.5">
                      <ShieldAlert size={10} className="text-[#4DD0E1] shrink-0 mt-0.5" />
                      <p className="text-[9px] text-[#8b949e] leading-relaxed">
                        <span className="text-[#4DD0E1] font-bold text-[8px] uppercase tracking-wider">Neutrality:</span>{' '}
                        {book.neutralityWarning}
                      </p>
                    </div>
                  )}
                  {book.triggerWarning && (
                    <div className="bg-[#1a0a0a] border border-[#f85149]/15 px-2.5 py-1.5 flex items-start gap-1.5">
                      <ShieldAlert size={10} className="text-[#f85149] shrink-0 mt-0.5" />
                      <p className="text-[9px] text-[#d29922] leading-relaxed">
                        <span className="text-[#f85149] font-bold text-[8px] uppercase tracking-wider">Trigger Warning:</span>{' '}
                        {book.triggerWarning}
                      </p>
                    </div>
                  )}
                </div>

                {/* Open reader */}
                <button
                  onClick={() => onOpenBook(book)}
                  className="flex items-center gap-1.5 bg-[#FF9F00] text-black px-4 py-2 text-[10px] font-bold clip-corner hover:brightness-110 transition-all"
                >
                  <BookOpen size={12} /> Open Reader <ArrowRight size={11} />
                </button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}