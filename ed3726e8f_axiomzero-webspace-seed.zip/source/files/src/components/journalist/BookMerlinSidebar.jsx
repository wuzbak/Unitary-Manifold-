/**
 * BookMerlinSidebar — compact Merlin research assistant for the BookReaderOverlay.
 * Uses queryMerlin directly with the active book's context injected as pageContext.
 */
import { useState, useRef, useEffect } from 'react';
import { queryMerlin } from '@/lib/merlinEngine';
import { parseMerlinResponse } from '@/components/quantum-cat/parseMerlinResponse';
import { Send, Sparkles, BookOpen, ExternalLink } from 'lucide-react';

const SUGGESTED_QUESTIONS = [
  'What are the main investigative threads in this dossier?',
  'Summarize the key findings and their confidence levels.',
  'What primary sources are cited, and how reliable are they?',
  'What are the strongest pieces of evidence documented here?',
  'Are there any gaps or unverified claims in this investigation?',
];

export default function BookMerlinSidebar({ book, accent = '#FF9F00' }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [phase, setPhase] = useState(null);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading]);

  // Reset conversation when book changes
  useEffect(() => {
    setMessages([]);
    setInput('');
    setLoading(false);
    setPhase(null);
  }, [book?.id]);

  const send = async (text) => {
    const userMsg = text || input;
    if (!userMsg.trim() || loading) return;
    setInput('');
    const newMessages = [...messages, { role: 'user', text: userMsg }];
    setMessages(newMessages);
    setLoading(true);
    setPhase('thinking');

    try {
      const pageContext = {
        path: '/axiom-journalist/book-reader',
        title: book?.title || 'Investigative Dossier',
        description: book?.description || '',
      };
      const liveState = {
        activeBook: book?.title,
        bookCategory: book?.category,
        bookGithubUrl: book?.githubUrl,
        readerMode: 'book-overlay',
      };

      const response = await queryMerlin(
        userMsg,
        newMessages.map((m) => ({ role: m.role, text: m.text })),
        (s) =>
          setPhase(
            s.phase === 'searching'
              ? 'searching'
              : s.phase === 'crawling'
                ? 'crawling'
                : s.phase === 'rag'
                  ? 'analyzing'
                  : s.phase === 'tool'
                    ? 'using tools'
                    : null
          ),
        null,
        false,
        { pageContext, liveState }
      );

      setMessages((prev) => [...prev, { role: 'merlin', text: response }]);
    } catch (e) {
      setMessages((prev) => [...prev, { role: 'merlin', text: `Error: ${e.message}` }]);
    }
    setLoading(false);
    setPhase(null);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0d11] border-l border-[#30363d]">
      {/* Header */}
      <div className="flex items-center gap-2 px-3 py-2.5 border-b border-[#30363d] bg-[#12161A] shrink-0">
        <Sparkles size={12} style={{ color: accent }} />
        <span className="text-[10px] font-bold" style={{ color: accent }}>
          Merlin Research
        </span>
        {book?.githubUrl && (
          <a
            href={book.githubUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="ml-auto text-[#484f58] hover:text-[#e6edf3] flex items-center gap-1 text-[9px]"
            title="View on GitHub"
          >
            <ExternalLink size={10} /> Source
          </a>
        )}
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-2.5">
        {messages.length === 0 && (
          <div className="text-center py-4">
            <BookOpen size={22} className="mx-auto mb-2 opacity-50" style={{ color: accent }} />
            <p className="text-[9px] text-[#8b949e] mb-3 leading-relaxed">
              I'm your research assistant for this dossier. I can see the book's title, methodology, and source structure. Ask me about its findings, threads, or evidence.
            </p>
            <div className="space-y-1.5">
              {SUGGESTED_QUESTIONS.map((q, i) => (
                <button
                  key={i}
                  onClick={() => send(q)}
                  className="block w-full text-left text-[9px] bg-[#0d1117] border border-[#30363d] rounded p-2 hover:border-[#30363d] transition-colors text-left"
                  style={{ color: '#3b8bff' }}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}
        {messages.map((msg, i) => (
          <MessageBubble key={i} msg={msg} onFollowup={send} accent={accent} />
        ))}
        {loading && (
          <div className="flex items-center gap-2 text-[10px]" style={{ color: accent }}>
            <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: accent }} />
            {phase || 'thinking...'}
          </div>
        )}
      </div>

      {/* Input */}
      <div className="p-2.5 border-t border-[#30363d] bg-[#12161A] shrink-0">
        <div className="flex gap-1.5">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') send();
            }}
            placeholder="Ask about this dossier..."
            className="flex-1 bg-[#0d1117] border border-[#30363d] rounded px-2 py-1.5 text-[10px] text-[#e6edf3]"
            disabled={loading}
          />
          <button
            onClick={() => send()}
            disabled={loading || !input.trim()}
            className="text-black px-2.5 py-1.5 rounded text-[10px] font-bold disabled:opacity-50 flex items-center justify-center"
            style={{ background: accent }}
          >
            <Send size={11} />
          </button>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ msg, onFollowup, accent }) {
  const parsed = msg.role === 'merlin' ? parseMerlinResponse(msg.text) : null;

  if (msg.role === 'user') {
    return (
      <div className="flex justify-end">
        <div className="border rounded p-2 max-w-[90%]" style={{ background: `${accent}20`, borderColor: `${accent}30` }}>
          <span className="text-[9px] text-[#e6edf3]">{msg.text}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start">
      <div className="bg-[#12161A] border border-[#30363d] rounded p-2 max-w-[95%] w-full">
        <div className="flex items-center gap-1 mb-1">
          <Sparkles size={9} style={{ color: accent }} />
          <span className="text-[8px] font-bold" style={{ color: accent }}>
            Merlin
          </span>
        </div>
        {parsed ? (
          <>
            <div className="text-[9px] text-[#e6edf3] whitespace-pre-wrap leading-relaxed">{parsed.body}</div>
            {parsed.followups.length > 0 && (
              <div className="mt-1.5 pt-1.5 border-t border-[#30363d]">
                {parsed.followups.map((f, i) => (
                  <button
                    key={i}
                    onClick={() => onFollowup(f)}
                    className="block w-full text-left text-[8px] text-[#3b8bff] hover:text-[#00f5ff] py-0.5"
                  >
                    → {f}
                  </button>
                ))}
              </div>
            )}
            {parsed.sources.length > 0 && (
              <div className="mt-1.5 pt-1.5 border-t border-[#30363d]">
                <div className="text-[7px] text-[#484f58] uppercase mb-0.5">Sources</div>
                {parsed.sources.map((s, i) => (
                  <div key={i} className="text-[8px] text-[#8b949e] mb-0.5">
                    {s.type === 'WEB' && s.url ? (
                      <a href={s.url} target="_blank" rel="noopener noreferrer" className="text-[#3b8bff] hover:underline">
                        {s.label}
                      </a>
                    ) : (
                      <span>{s.label}</span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </>
        ) : (
          <div className="text-[9px] text-[#e6edf3] whitespace-pre-wrap leading-relaxed">{msg.text}</div>
        )}
      </div>
    </div>
  );
}