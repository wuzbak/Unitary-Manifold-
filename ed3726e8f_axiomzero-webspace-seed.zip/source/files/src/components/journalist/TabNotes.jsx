import { useState } from 'react';
import { Plus, Trash2, MessageSquare, Flag, HelpCircle, CheckSquare, Clock, Activity } from 'lucide-react';
import JournalistPanel from './JournalistPanel';

const NOTE_TYPES = [
  { id: 'note', label: 'Note', icon: MessageSquare, color: '#4DD0E1' },
  { id: 'annotation', label: 'Annotation', icon: Flag, color: '#FF9F00' },
  { id: 'question', label: 'Question', icon: HelpCircle, color: '#d29922' },
  { id: 'decision', label: 'Decision', icon: CheckSquare, color: '#3fb950' },
];

/**
 * TabNotes — collaboration notes, annotations, and a derived activity timeline.
 */
export default function TabNotes({ inv, onAdd, onRemove }) {
  const [content, setContent] = useState('');
  const [type, setType] = useState('note');
  const [author, setAuthor] = useState('');

  const add = () => {
    if (!content.trim() || !inv) return;
    onAdd({ content: content.trim(), type, author: author.trim() || inv.journalist || 'Investigator', created_date: new Date().toISOString() });
    setContent('');
  };

  const notes = inv?.notes || [];

  // Derive activity timeline from case data
  const timeline = [];
  if (inv?.id) {
    timeline.push({ date: inv.created_date || new Date().toISOString(), event: 'Investigation created', icon: Plus, color: '#3fb950' });
    if (inv.entities?.length) timeline.push({ date: null, event: `${inv.entities.length} entities mapped`, icon: Activity, color: '#4DD0E1' });
    if (inv.sources?.length) timeline.push({ date: null, event: `${inv.sources.length} sources logged`, icon: Activity, color: '#58a6ff' });
    if (inv.claims?.length) timeline.push({ date: null, event: `${inv.claims.length} claims filed`, icon: Activity, color: '#d29922' });
    if (inv.evidence?.length) timeline.push({ date: null, event: `${inv.evidence.length} evidence artifacts`, icon: Activity, color: '#bc8cff' });
    if (inv.brief_enriched) timeline.push({ date: inv.updated_date || new Date().toISOString(), event: 'Pipeline completed — brief generated', icon: CheckSquare, color: '#FF9F00' });
    if (inv.brief_cache) timeline.push({ date: null, event: 'Investigative brief exported', icon: CheckSquare, color: '#3fb950' });
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="space-y-3">
        <JournalistPanel title="Add Note / Annotation" icon={Plus} accent="#FF9F00">
          {!inv ? <p className="text-[#f85149] text-xs">Start or load an investigation first.</p> : (
            <div className="space-y-3">
              <div>
                <label className="text-[9px] text-[#8b949e] block mb-1">Type</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {NOTE_TYPES.map(t => (
                    <button key={t.id} onClick={() => setType(t.id)}
                      className={`flex flex-col items-center gap-1 p-2 rounded border text-[9px] transition-all ${type === t.id ? 'border-[#FF9F00]/50 bg-[#FF9F00]/10 text-[#FF9F00]' : 'border-[#30363d] text-[#8b949e] hover:border-[#484f58]'}`}>
                      <t.icon size={14} />
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-[9px] text-[#8b949e] block mb-1">Author</label>
                <input value={author} onChange={e => setAuthor(e.target.value)} placeholder={inv.journalist || 'Your name'} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
              </div>
              <div>
                <label className="text-[9px] text-[#8b949e] block mb-1">Content *</label>
                <textarea value={content} onChange={e => setContent(e.target.value)} placeholder="Your note, observation, question, or editorial decision…" rows={4} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] resize-none" />
              </div>
              <button onClick={add} disabled={!content.trim()} className="flex items-center gap-1.5 bg-[#FF9F00] text-black px-4 py-2 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40">
                <Plus size={12} /> Add Note
              </button>
            </div>
          )}
        </JournalistPanel>

        <JournalistPanel title="Activity Timeline" icon={Clock} accent="#4DD0E1">
          {!inv?.id ? <p className="text-[#8b949e] text-xs italic">No activity yet.</p> : (
            <div className="space-y-2">
              {timeline.map((t, i) => (
                <div key={i} className="flex items-start gap-2">
                  <div className="flex flex-col items-center pt-0.5">
                    <t.icon size={10} style={{ color: t.color }} />
                    {i < timeline.length - 1 && <div className="w-px h-4 bg-[#30363d] mt-1" />}
                  </div>
                  <div className="flex-1 pb-1">
                    <div className="text-[10px] text-[#e6edf3]">{t.event}</div>
                    {t.date && <div className="text-[9px] text-[#484f58]">{new Date(t.date).toLocaleString()}</div>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </JournalistPanel>
      </div>

      <JournalistPanel title={`Collaboration Notes (${notes.length})`} icon={MessageSquare} accent="#4DD0E1" bodyClassName="p-3">
        {!notes.length ? (
          <p className="text-[#8b949e] text-xs italic px-1 py-4 text-center">No notes yet. Add observations, questions, and editorial decisions on the left.</p>
        ) : (
          <div className="space-y-2 max-h-[65vh] overflow-y-auto pr-1">
            {[...notes].reverse().map((n, ri) => {
              const i = notes.length - 1 - ri;
              const typeMeta = NOTE_TYPES.find(t => t.id === n.type) || NOTE_TYPES[0];
              return (
                <div key={i} className="border border-[#30363d] clip-corner p-3 bg-[#0B0F13]/60 group">
                  <div className="flex items-center gap-2 mb-1.5">
                    <typeMeta.icon size={11} style={{ color: typeMeta.color }} />
                    <span className="text-[9px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded" style={{ background: `${typeMeta.color}15`, color: typeMeta.color }}>{typeMeta.label}</span>
                    <span className="text-[10px] text-[#e6edf3] font-bold flex-1">{n.author}</span>
                    <button onClick={() => onRemove(i)} className="text-[#484f58] hover:text-[#f85149] opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={10} /></button>
                  </div>
                  <p className="text-[10px] text-[#8b949e] leading-relaxed whitespace-pre-wrap">{n.content}</p>
                  <div className="text-[9px] text-[#484f58] mt-1.5">{new Date(n.created_date).toLocaleString()}</div>
                </div>
              );
            })}
          </div>
        )}
      </JournalistPanel>
    </div>
  );
}