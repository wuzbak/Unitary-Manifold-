import { useState } from 'react';
import { Plus, Scale, Trash2, CheckCircle2, AlertTriangle, Zap } from 'lucide-react';
import { LegalRisk, LEGAL_RISK_OPTIONS, resolveSources, getConfidence, generateId } from '@/lib/journalist/investigator';

const CONFIDENCE_COLORS = { CONFIRMED: '#3fb950', CORROBORATED: '#4dd0e1', ALLEGED: '#d29922', UNVERIFIED: '#f85149', DISPUTED: '#bc8cff' };

/**
 * TabClaims — add claims with auto-confidence-scoring; accept Editor-suggested claims.
 */
export default function TabClaims({ inv, onAdd, onRemove, suggestedClaims, onAcceptSuggested }) {
  const [stmt, setStmt] = useState('');
  const [sources, setSources] = useState('');
  const [entities, setEntities] = useState('');
  const [legal, setLegal] = useState(LegalRisk.NONE);

  const add = () => {
    if (!stmt.trim() || !inv) return;
    onAdd({ id: generateId('claim'), statement: stmt.trim(), source_titles: sources.split(',').map(s => s.trim()).filter(Boolean), entities_involved: entities.split(',').map(s => s.trim()).filter(Boolean), legal_risks: [legal], notes: '' });
    setStmt(''); setSources(''); setEntities(''); setLegal(LegalRisk.NONE);
  };

  return (
    <div className="space-y-4">
      {suggestedClaims && suggestedClaims.length > 0 && (
        <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#bc8cff]/30 clip-corner p-3">
          <div className="text-[9px] text-[#bc8cff] uppercase tracking-wider mb-2">Editor-Suggested Claims (from evidence)</div>
          <div className="space-y-1">
            {suggestedClaims.map((c, i) => (
              <button key={i} onClick={() => onAcceptSuggested(c)} className="w-full text-left p-2 rounded border border-[#30363d] hover:border-[#bc8cff]/40 text-xs">
                <div className="text-[#e6edf3]">{c.statement}</div>
                {c.source_titles?.length > 0 && <div className="text-[9px] text-[#8b949e] mt-0.5">Sources: {c.source_titles.join(', ')}</div>}
                {c.entities?.length > 0 && <div className="text-[9px] text-[#8b949e]">Entities: {c.entities.join(', ')}</div>}
              </button>
            ))}
          </div>
        </div>
      )}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
          <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-3">Add Claim</div>
          {!inv && <p className="text-[#f85149] text-xs">Start or load an investigation first.</p>}
          {inv && <>
            <label className="text-[9px] text-[#8b949e] block mb-1">Claim Statement *</label>
            <textarea value={stmt} onChange={e => setStmt(e.target.value)} placeholder="The factual claim your investigation is building toward" rows={2} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2 resize-none" />
            <label className="text-[9px] text-[#8b949e] block mb-1">Source Titles (comma-separated — must match logged sources)</label>
            <input value={sources} onChange={e => setSources(e.target.value)} placeholder="e.g. SEC Filing 10-K 2025, FOIA 2024-001" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
            {inv.sources?.length > 0 && <div className="text-[9px] text-[#484f58] mb-2">Available: {inv.sources.map(s => s.title).join(', ')}</div>}
            <label className="text-[9px] text-[#8b949e] block mb-1">Entities Involved (comma-separated)</label>
            <input value={entities} onChange={e => setEntities(e.target.value)} placeholder="e.g. Jane Smith, Acme Corp" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
            <label className="text-[9px] text-[#8b949e] block mb-1">Legal Risk Flag</label>
            <select value={legal} onChange={e => setLegal(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-3">
              {LEGAL_RISK_OPTIONS.map(r => <option key={r} value={r}>{r === 'NONE' ? 'None identified' : r}</option>)}
            </select>
            <button onClick={add} disabled={!stmt.trim()} className="flex items-center gap-1.5 bg-[#FF9F00] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"><Plus size={12} /> Add Claim</button>
          </>}
        </div>
        <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
          <div className="flex items-center gap-2 mb-3"><Scale size={12} className="text-[#8b949e]" /><span className="text-[10px] text-[#8b949e] uppercase tracking-wider">Claims ({inv?.claims?.length || 0})</span></div>
          {!inv?.claims?.length ? <p className="text-[#8b949e] text-xs italic">No claims yet. Add one above, or run the pipeline to get evidence-backed suggestions.</p> : (
            <div className="space-y-2 max-h-[55vh] overflow-y-auto">
              {inv.claims.map((c, i) => {
                const resolved = resolveSources(c.source_titles, inv.sources || []);
                const conf = c.confidence || getConfidence(resolved, c.disputed);
                const Icon = conf === 'CONFIRMED' || conf === 'CORROBORATED' ? CheckCircle2 : conf === 'DISPUTED' ? Zap : AlertTriangle;
                return (
                  <div key={i} className="border border-[#30363d] rounded p-2">
                    <div className="flex items-center gap-2">
                      <Icon size={12} style={{ color: CONFIDENCE_COLORS[conf] }} />
                      <span className="text-[9px] font-bold px-1.5 py-0.5 rounded" style={{ background: `${CONFIDENCE_COLORS[conf]}20`, color: CONFIDENCE_COLORS[conf] }}>{conf}</span>
                      <span className="text-xs text-[#e6edf3] flex-1">{c.statement}</span>
                      <button onClick={() => onRemove(i)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={11} /></button>
                    </div>
                    {c.entities_involved?.length > 0 && <p className="text-[10px] text-[#8b949e] mt-1">Entities: {c.entities_involved.join(', ')}</p>}
                    {resolved.length > 0 && <p className="text-[10px] text-[#8b949e] mt-1">Sources: {resolved.map(s => s.title).join(', ')}</p>}
                    {c.legal_risks && c.legal_risks.filter(r => r !== 'NONE').length > 0 && <p className="text-[10px] text-[#d29922] mt-1">⚖ {c.legal_risks.filter(r => r !== 'NONE').join(' | ')}</p>}
                  </div>
                );
              })}
            </div>
          )}
          <div className="mt-3 bg-[#0B0F13] border border-[#30363d] clip-corner p-2">
            <div className="text-[9px] text-[#8b949e] uppercase tracking-wider mb-1">5-Tier Confidence Criteria</div>
            <div className="text-[9px] text-[#8b949e] space-y-0.5">
              <div><span className="text-[#3fb950] font-bold">CONFIRMED</span> ≥0.85 — multiple Tier 1/2 in agreement</div>
              <div><span className="text-[#4dd0e1] font-bold">CORROBORATED</span> ≥0.65 — ≥2 independent, one Tier 1/2</div>
              <div><span className="text-[#d29922] font-bold">ALLEGED</span> ≥0.40 — single credible source</div>
              <div><span className="text-[#f85149] font-bold">UNVERIFIED</span> &lt;0.40 — single low-tier or none</div>
              <div><span className="text-[#bc8cff] font-bold">DISPUTED</span> — active contradiction between credible sources</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}