/**
 * BookReaderOverlay — full-screen reader for investigative dossier books.
 *
 * Three regions:
 * - Top bar: word search + match count + prev/next + GitHub link + close
 * - Main content: scrollable react-markdown rendering with elegant reading typography
 * - Right sidebar: Merlin research assistant (BookMerlinSidebar)
 *
 * Fetches markdown from the fetchBookMarkdown backend function on open.
 * Word search uses a DOM TreeWalker to highlight matches in rendered text nodes.
 */
import { useState, useEffect, useRef, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import { base44 } from '@/api/base44Client';
import {
  Search, X, ChevronUp, ChevronDown, ExternalLink, Loader2,
  ShieldAlert, BookOpen, MessageSquare, AlertTriangle,
} from 'lucide-react';
import BookMerlinSidebar from './BookMerlinSidebar';

export default function BookReaderOverlay({ book, onClose, accent = '#FF9F00' }) {
  const [markdown, setMarkdown] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Search state
  const [searchTerm, setSearchTerm] = useState('');
  const [matchCount, setMatchCount] = useState(0);
  const [currentMatch, setCurrentMatch] = useState(-1);
  const [showWarning, setShowWarning] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const contentRef = useRef(null);
  const matchRefs = useRef([]);
  const searchTimer = useRef(null);

  // Fetch markdown on open / book change
  useEffect(() => {
    if (!book?.filename) return;
    setLoading(true);
    setError(null);
    setMarkdown('');
    setShowWarning(true);
    setSearchTerm('');
    setMatchCount(0);
    setCurrentMatch(-1);

    base44.functions
      .invoke('fetchBookMarkdown', { filename: book.filename })
      .then((res) => {
        const data = res?.data || res;
        if (data?.error) {
          setError(data.error);
        } else if (data?.markdown) {
          setMarkdown(data.markdown);
        } else {
          setError('No content received');
        }
      })
      .catch((e) => setError(e.message || 'Failed to fetch book'))
      .finally(() => setLoading(false));
  }, [book?.filename]);

  // Clear all highlights
  const clearHighlights = useCallback(() => {
    if (!contentRef.current) return;
    const marks = contentRef.current.querySelectorAll('mark.search-match');
    marks.forEach((m) => {
      const parent = m.parentNode;
      parent.replaceChild(document.createTextNode(m.textContent), m);
      parent.normalize();
    });
    matchRefs.current = [];
  }, []);

  // Apply search highlights via DOM TreeWalker
  const applySearch = useCallback(
    (term) => {
      if (!contentRef.current) return;
      clearHighlights();
      if (!term.trim()) {
        setMatchCount(0);
        setCurrentMatch(-1);
        return;
      }

      const lower = term.toLowerCase();
      const newMatches = [];
      const walker = document.createTreeWalker(contentRef.current, NodeFilter.SHOW_TEXT, {
        acceptNode: (node) => {
          if (!node.textContent || !node.textContent.toLowerCase().includes(lower)) return NodeFilter.FILTER_REJECT;
          if (node.parentElement?.tagName === 'MARK') return NodeFilter.FILTER_REJECT;
          if (node.parentElement?.tagName === 'SCRIPT' || node.parentElement?.tagName === 'STYLE') return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        },
      });

      const textNodes = [];
      let node;
      while ((node = walker.nextNode())) textNodes.push(node);

      textNodes.forEach((textNode) => {
        const text = textNode.textContent;
        const textLower = text.toLowerCase();
        const fragments = [];
        let lastIndex = 0;
        let idx;
        while ((idx = textLower.indexOf(lower, lastIndex)) !== -1) {
          if (idx > lastIndex) fragments.push(document.createTextNode(text.slice(lastIndex, idx)));
          const mark = document.createElement('mark');
          mark.className = 'search-match';
          mark.style.background = 'rgba(255, 159, 0, 0.25)';
          mark.style.color = '#FF9F00';
          mark.style.borderRadius = '2px';
          mark.style.padding = '0 1px';
          mark.textContent = text.slice(idx, idx + term.length);
          fragments.push(mark);
          newMatches.push(mark);
          lastIndex = idx + term.length;
        }
        if (lastIndex < text.length) fragments.push(document.createTextNode(text.slice(lastIndex)));

        const parent = textNode.parentNode;
        fragments.forEach((f) => parent.insertBefore(f, textNode));
        parent.removeChild(textNode);
      });

      matchRefs.current = newMatches;
      setMatchCount(newMatches.length);
      setCurrentMatch(newMatches.length > 0 ? 0 : -1);

      if (newMatches.length > 0) {
        newMatches[0].style.background = 'rgba(255, 159, 0, 0.5)';
        newMatches[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    },
    [clearHighlights]
  );

  // Debounced search
  useEffect(() => {
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => applySearch(searchTerm), 300);
    return () => {
      if (searchTimer.current) clearTimeout(searchTimer.current);
    };
  }, [searchTerm, markdown, applySearch]);

  // Navigate matches
  const goToMatch = (dir) => {
    if (matchRefs.current.length === 0) return;
    // Reset previous highlight
    if (currentMatch >= 0 && matchRefs.current[currentMatch]) {
      matchRefs.current[currentMatch].style.background = 'rgba(255, 159, 0, 0.25)';
    }
    let next = currentMatch + dir;
    if (next < 0) next = matchRefs.current.length - 1;
    if (next >= matchRefs.current.length) next = 0;
    setCurrentMatch(next);
    const el = matchRefs.current[next];
    if (el) {
      el.style.background = 'rgba(255, 159, 0, 0.5)';
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // ESC to close
  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  if (!book) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-[#0B0F13] flex flex-col fade-in">
      {/* ── Top bar ── */}
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-[#30363d] bg-[#0a0d11] shrink-0">
        <BookOpen size={14} style={{ color: accent }} className="shrink-0" />
        <div className="min-w-0 flex-1">
          <div className="text-[11px] font-bold text-[#e6edf3] truncate">{book.title}</div>
          {book.subtitle && <div className="text-[9px] text-[#484f58] truncate hidden sm:block">{book.subtitle}</div>}
        </div>

        {/* Word search */}
        <div className="flex items-center gap-1 glass-panel clip-corner px-2 py-1 shrink-0">
          <Search size={12} className="text-[#484f58] shrink-0" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search…"
            className="bg-transparent text-[10px] text-[#e6edf3] w-24 sm:w-36 focus:outline-none placeholder:text-[#484f58]"
          />
          {matchCount > 0 && (
            <>
              <span className="text-[9px] text-[#8b949e] tabular-nums whitespace-nowrap">
                {currentMatch + 1}/{matchCount}
              </span>
              <button onClick={() => goToMatch(-1)} className="text-[#484f58] hover:text-[#FF9F00] p-0.5" aria-label="Previous match">
                <ChevronUp size={12} />
              </button>
              <button onClick={() => goToMatch(1)} className="text-[#484f58] hover:text-[#FF9F00] p-0.5" aria-label="Next match">
                <ChevronDown size={12} />
              </button>
            </>
          )}
          {searchTerm && matchCount === 0 && <span className="text-[9px] text-[#484f58]">0</span>}
        </div>

        {/* GitHub link */}
        <a
          href={book.githubUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1 px-2.5 py-1.5 border border-[#30363d] text-[#8b949e] hover:text-[#e6edf3] hover:border-[#30363d] text-[9px] font-bold clip-corner transition-colors shrink-0"
          title="View on GitHub"
        >
          <ExternalLink size={11} /> <span className="hidden sm:inline">GitHub</span>
        </a>

        {/* Sidebar toggle (mobile) */}
        <button
          onClick={() => setSidebarOpen((s) => !s)}
          className="lg:hidden flex items-center justify-center w-9 h-9 border border-[#30363d] text-[#8b949e] hover:text-[#FF9F00] clip-corner transition-colors shrink-0"
          aria-label="Toggle Merlin panel"
        >
          <MessageSquare size={13} />
        </button>

        {/* Close */}
        <button
          onClick={onClose}
          className="flex items-center justify-center w-9 h-9 border border-[#f85149]/40 text-[#f85149] hover:bg-[#f85149]/10 clip-corner transition-colors shrink-0"
          aria-label="Close reader"
        >
          <X size={16} />
        </button>
      </div>

      {/* ── Warning banner ── */}
      {showWarning && !loading && !error && (
        <div className="border-b border-[#FF9F00]/20 bg-[#1a1308] shrink-0">
          <div className="max-w-5xl mx-auto px-4 py-2.5">
            <div className="flex items-start gap-2.5">
              <ShieldAlert size={14} className="text-[#FF9F00] shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                {book.neutralityWarning && (
                  <p className="text-[9px] text-[#8b949e] leading-relaxed mb-1">
                    <span className="text-[#4DD0E1] font-bold uppercase tracking-wider text-[8px]">Neutrality:</span>{' '}
                    {book.neutralityWarning}
                  </p>
                )}
                {book.triggerWarning && (
                  <p className="text-[9px] text-[#d29922] leading-relaxed">
                    <span className="text-[#f85149] font-bold uppercase tracking-wider text-[8px]">Trigger Warning:</span>{' '}
                    {book.triggerWarning}
                  </p>
                )}
              </div>
              <button
                onClick={() => setShowWarning(false)}
                className="text-[#484f58] hover:text-[#e6edf3] text-[9px] shrink-0 mt-0.5"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Main content + Sidebar ── */}
      <div className="flex-1 flex overflow-hidden">
        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-full gap-3">
              <Loader2 size={28} className="animate-spin text-[#FF9F00]" />
              <p className="text-[10px] text-[#8b949e]">Fetching dossier from repository…</p>
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center h-full gap-3 px-4">
              <AlertTriangle size={28} className="text-[#f85149]" />
              <p className="text-[11px] text-[#f85149] font-bold">Failed to load dossier</p>
              <p className="text-[10px] text-[#8b949e] text-center max-w-md">{error}</p>
              <a
                href={book.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-2 border border-[#FF9F00]/40 text-[#FF9F00] text-[10px] font-bold clip-corner hover:bg-[#FF9F00]/10 transition-colors"
              >
                <ExternalLink size={12} /> Read on GitHub instead
              </a>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto px-4 sm:px-8 py-6">
              <div ref={contentRef} className="reading-content has-drop-cap">
                <ReactMarkdown
                  components={{
                    h1: ({ node, ...props }) => <h1 className="text-xl font-bold mb-4 mt-6 leading-tight" {...props} />,
                    h2: ({ node, ...props }) => <h2 className="text-lg font-bold mb-3 mt-5 leading-tight" {...props} />,
                    h3: ({ node, ...props }) => <h3 className="text-base font-bold mb-2 mt-4" {...props} />,
                    h4: ({ node, ...props }) => <h4 className="text-sm font-bold mb-2 mt-3" {...props} />,
                    p: ({ node, ...props }) => <p className="text-[13px] leading-[1.8] mb-4" {...props} />,
                    ul: ({ node, ...props }) => <ul className="list-disc list-inside mb-4 space-y-1 text-[13px] leading-[1.7]" {...props} />,
                    ol: ({ node, ...props }) => <ol className="list-decimal list-inside mb-4 space-y-1 text-[13px] leading-[1.7]" {...props} />,
                    blockquote: ({ node, ...props }) => (
                      <blockquote className="border-l-2 pl-4 my-4 italic text-[12px] leading-relaxed" style={{ borderColor: 'var(--rc-quote-border)', color: 'var(--rc-quote-text)' }} {...props} />
                    ),
                    a: ({ node, ...props }) => <a className="underline hover:brightness-125" target="_blank" rel="noopener noreferrer" {...props} />,
                    hr: ({ node, ...props }) => <hr className="my-6" {...props} />,
                    table: ({ node, ...props }) => (
                      <div className="overflow-x-auto my-4">
                        <table className="w-full text-[11px] border-collapse" {...props} />
                      </div>
                    ),
                    pre: ({ node, ...props }) => (
                      <pre className="p-3 my-3 overflow-x-auto text-[11px] rounded" style={{ background: 'var(--rc-code-bg)', border: '1px solid var(--rc-pre-border)' }} {...props} />
                    ),
                    code: ({ node, className, ...props }) => (
                      <code
                        className={className ? className : 'px-1 py-0.5 rounded text-[11px]'}
                        style={className ? {} : { background: 'var(--rc-code-bg)', color: 'var(--rc-code-text)' }}
                        {...props}
                      />
                    ),
                  }}
                >
                  {markdown}
                </ReactMarkdown>
              </div>
              <div className="h-12" />
            </div>
          )}
        </div>

        {/* Sidebar — desktop always visible, mobile toggle */}
        {sidebarOpen && !loading && !error && (
          <div className="w-80 shrink-0 hidden lg:flex">
            <BookMerlinSidebar book={book} accent={accent} />
          </div>
        )}
      </div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && !loading && !error && (
        <div className="lg:hidden fixed right-0 top-[49px] bottom-0 w-[85%] max-w-sm z-50 shadow-2xl">
          <BookMerlinSidebar book={book} accent={accent} />
          <button
            onClick={() => setSidebarOpen(false)}
            className="absolute top-2 right-2 w-8 h-8 flex items-center justify-center bg-[#0d1117] border border-[#30363d] text-[#484f58] rounded"
            aria-label="Close Merlin panel"
          >
            <X size={14} />
          </button>
        </div>
      )}
    </div>
  );
}