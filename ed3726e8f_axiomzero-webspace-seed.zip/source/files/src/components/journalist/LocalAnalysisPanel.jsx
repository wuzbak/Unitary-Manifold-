/**
 * LocalAnalysisPanel — Tier 1 local deterministic analysis for the AXIOM Journalist.
 *
 * Displays DataFrame source statistics (Danfo.js), entity embedding analysis
 * (TensorFlow.js), anomaly detection, and the 5-tier confidence score distribution.
 * All computation is local — no LLM required. Shows a signed SHA-256 hash.
 */
import { useState, useEffect, useCallback } from 'react';
import { runLocalAnalysis, crossCaseMatch } from '@/lib/journalist/localAnalysis';
import ComputeLoader from '@/components/shared/ComputeLoader';
import SignedResult from '@/components/shared/SignedResult';
import { BarChart3, Database, Brain, AlertTriangle, Fingerprint, Activity } from 'lucide-react';

export default function LocalAnalysisPanel({ inv, caseLibrary }) {
  const [analysis, setAnalysis] = useState(null);
  const [crossCase, setCrossCase] = useState(null);
  const [loading, setLoading] = useState(false);
  const [libsReady, setLibsReady] = useState(false);

  // Preload libraries
  useEffect(() => {
    import('@/lib/journalist/localAnalysis').then(() => setLibsReady(true));
  }, []);

  const runAnalysis = useCallback(async () => {
    if (!inv) return;
    setLoading(true);
    try {
      const result = await runLocalAnalysis(inv);
      setAnalysis(result);
      if (caseLibrary?.length > 0 && inv.entities?.length > 0) {
        const cc = await crossCaseMatch(inv.entities, caseLibrary.filter(c => c.id !== inv.id));
        setCrossCase(cc);
      }
    } catch (e) {
      console.error('Local analysis failed:', e);
    }
    setLoading(false);
  }, [inv, caseLibrary]);

  if (!inv) return null;

  return (
    <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#3fb950]/20 clip-corner p-3 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity size={12} className="text-[#3fb950]" />
          <span className="text-[10px] text-[#3fb950] font-bold uppercase tracking-wider">Tier 1 · Local Deterministic Analysis</span>
        </div>
        <button onClick={runAnalysis} disabled={!libsReady || loading}
          className="flex items-center gap-1.5 bg-[#0B0F13] border border-[#30363d] text-[#3fb950] px-2 py-1 rounded text-[9px] hover:border-[#3fb950] disabled:opacity-40">
          <BarChart3 size={9} /> {loading ? 'Analyzing…' : analysis ? 'Re-run' : 'Run Analysis'}
        </button>
      </div>

      {!libsReady ? (
        <ComputeLoader engine="Danfo.js + TensorFlow.js" detail="Lazy-loading data analysis libraries" compact />
      ) : !analysis ? (
        <div className="text-[9px] text-[#8b949e] py-3 text-center">
          Click "Run Analysis" for local deterministic source statistics, entity embeddings, and anomaly detection.
          <br />
          <span className="text-[#484f58]">No API calls — runs entirely in-browser.</span>
        </div>
      ) : (
        <div className="space-y-2.5">
          {/* Source DataFrame stats */}
          <div className="bg-[#0B0F13]/60 border border-[#30363d] rounded p-2">
            <div className="flex items-center gap-1.5 mb-1.5">
              <Database size={10} className="text-[#4DD0E1]" />
              <span className="text-[9px] text-[#4DD0E1] font-bold">Source DataFrame · {analysis.sourceStats.engine}</span>
            </div>
            <div className="grid grid-cols-3 gap-1.5 text-[9px]">
              <div><span className="text-[#8b949e]">Sources:</span> <span className="text-[#e6edf3] font-bold">{analysis.sourceStats.count}</span></div>
              <div><span className="text-[#8b949e]">Quality:</span> <span className="text-[#3fb950] font-bold">{analysis.sourceStats.qualityScore?.toFixed(3)}</span></div>
              <div><span className="text-[#8b949e]">Fetchers:</span> <span className="text-[#4DD0E1] font-bold">{analysis.sourceStats.provenanceSources?.length || 0}</span></div>
            </div>
            {analysis.sourceStats.tierDistribution && Object.keys(analysis.sourceStats.tierDistribution).length > 0 && (
              <div className="mt-1.5 flex gap-1">
                {Object.entries(analysis.sourceStats.tierDistribution).sort().map(([tier, count]) => (
                  <div key={tier} className="bg-[#161b22] border border-[#30363d] rounded px-1.5 py-0.5 text-[8px]">
                    <span className="text-[#8b949e]">T{tier}:</span> <span className="text-[#e6edf3] font-bold">{count}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Confidence distribution */}
          <div className="bg-[#0B0F13]/60 border border-[#30363d] rounded p-2">
            <div className="flex items-center gap-1.5 mb-1.5">
              <BarChart3 size={10} className="text-[#d29922]" />
              <span className="text-[9px] text-[#d29922] font-bold">5-Tier Confidence Distribution</span>
            </div>
            <div className="grid grid-cols-5 gap-1">
              {['CONFIRMED', 'CORROBORATED', 'ALLEGED', 'UNVERIFIED', 'DISPUTED'].map(level => {
                const count = analysis.claimScores.filter(c => c.confidence === level).length;
                const colors = { CONFIRMED: '#3fb950', CORROBORATED: '#4DD0E1', ALLEGED: '#d29922', UNVERIFIED: '#8b949e', DISPUTED: '#f85149' };
                return (
                  <div key={level} className="text-center bg-[#161b22] border border-[#30363d] rounded py-1">
                    <div className="text-[8px] text-[#8b949e]">{level.slice(0, 4)}</div>
                    <div className="text-sm font-bold" style={{ color: colors[level] }}>{count}</div>
                  </div>
                );
              })}
            </div>
            <div className="mt-1 text-[8px] text-[#8b949e]">Overall: <span className="text-[#3fb950] font-bold">{(analysis.overallConfidence * 100).toFixed(1)}%</span></div>
          </div>

          {/* Anomalies */}
          {analysis.anomalies.length > 0 && (
            <div className="bg-[#0B0F13]/60 border border-[#d29922]/20 rounded p-2">
              <div className="flex items-center gap-1.5 mb-1">
                <AlertTriangle size={10} className="text-[#d29922]" />
                <span className="text-[9px] text-[#d29922] font-bold">Anomaly Detection · {analysis.anomalies.length} flags</span>
              </div>
              {analysis.anomalies.map((a, i) => (
                <div key={i} className="text-[9px] text-[#e6edf3] flex items-start gap-1.5 mb-0.5">
                  <span className={a.severity === 'WARN' ? 'text-[#d29922]' : 'text-[#4DD0E1]'}>▸</span>
                  <span><span className="text-[#8b949e]">{a.type}:</span> {a.message}</span>
                </div>
              ))}
            </div>
          )}

          {/* Cross-case entity matching (TF.js embeddings) */}
          {crossCase && crossCase.matches.length > 0 && (
            <div className="bg-[#0B0F13]/60 border border-[#bc8cff]/20 rounded p-2">
              <div className="flex items-center gap-1.5 mb-1.5">
                <Brain size={10} className="text-[#bc8cff]" />
                <span className="text-[9px] text-[#bc8cff] font-bold">Cross-Case Entity Matching · {crossCase.engine}</span>
              </div>
              {crossCase.matches.slice(0, 5).map((m, i) => (
                <div key={i} className="text-[9px] flex items-center justify-between mb-0.5">
                  <span className="text-[#e6edf3]">{m.currentEntity} ↔ <span className="text-[#bc8cff]">{m.matchedEntity}</span></span>
                  <span className="text-[#8b949e]">{(m.similarity * 100).toFixed(0)}%</span>
                </div>
              ))}
              <div className="text-[8px] text-[#484f58] mt-1">via {crossCase.engine} · local cosine similarity</div>
            </div>
          )}

          {/* Signed hash */}
          {analysis.hash && <SignedResult hash={analysis.hash} compact />}
        </div>
      )}
    </div>
  );
}