import { Clock } from 'lucide-react';

/**
 * TimelineVisual — horizontal visual timeline of dated events from the enriched brief.
 * Events are plotted on a line proportional to their date, with alternating above/below labels.
 */
export default function TimelineVisual({ timeline = [] }) {
  if (!timeline.length) return null;

  const sorted = [...timeline].map((t, i) => ({
    ...t,
    _date: t.date ? new Date(t.date).getTime() || Infinity : Infinity,
    _idx: i,
  })).sort((a, b) => a._date - b._date);

  const dated = sorted.filter(t => t._date !== Infinity);
  if (!dated.length) return null;
  const minDate = Math.min(...dated.map(t => t._date));
  const maxDate = Math.max(...dated.map(t => t._date));
  const range = maxDate - minDate || 1;

  return (
    <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#4DD0E1]/30 clip-corner p-3">
      <div className="flex items-center gap-2 mb-3">
        <Clock size={12} className="text-[#4DD0E1]" />
        <span className="text-[10px] text-[#4DD0E1] uppercase tracking-wider font-bold">Investigative Timeline</span>
      </div>
      <div className="relative h-32 mb-2">
        <div className="absolute top-1/2 left-0 right-0 h-px bg-[#4DD0E1]/30" />
        {sorted.map((t, i) => {
          const pos = t._date === Infinity ? 50 : ((t._date - minDate) / range) * 100;
          const isTop = i % 2 === 0;
          return (
            <div key={i} className="absolute" style={{ left: `${Math.min(95, Math.max(5, pos))}%`, top: isTop ? '10%' : '50%' }}>
              <div className="w-2 h-2 rounded-full bg-[#4DD0E1] -translate-x-1/2 translate-y-4" />
              {isTop ? (
                <div className="absolute top-3 -translate-x-1/2 w-24 text-center">
                  <div className="text-[8px] text-[#4DD0E1] font-bold">{t.date || '????'}</div>
                  <div className="text-[7px] text-[#8b949e] leading-tight">{(t.event || '').slice(0, 35)}</div>
                </div>
              ) : (
                <div className="absolute bottom-3 -translate-x-1/2 w-24 text-center">
                  <div className="text-[7px] text-[#8b949e] leading-tight">{(t.event || '').slice(0, 35)}</div>
                  <div className="text-[8px] text-[#4DD0E1] font-bold">{t.date || '????'}</div>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div className="space-y-1 max-h-40 overflow-y-auto mt-4">
        {sorted.map((t, i) => (
          <div key={i} className="flex items-start gap-2 text-[10px]">
            <span className="text-[#4DD0E1] font-bold shrink-0 w-20">{t.date || '????'}</span>
            <span className="text-[#e6edf3]">{t.event}</span>
          </div>
        ))}
      </div>
    </div>
  );
}