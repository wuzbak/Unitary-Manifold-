/**
 * DocumentUploader — AI document extraction for the journalist pipeline.
 * Upload PDF/CSV/XLSX → UploadFile → ExtractDataFromUploadedFile → preview → import.
 * Merges extracted entities/claims/evidence into the active Investigation.
 * Consumes integration credits (extraction).
 */
import { useState, useRef } from 'react';
import { FileUp, Loader2, CheckCircle2, X, Sparkles, FileText } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const EXTRACTION_SCHEMA = {
  type: 'object',
  properties: {
    entities: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' },
          type: { type: 'string' },
          description: { type: 'string' },
        },
        required: ['name'],
      },
    },
    claims: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          statement: { type: 'string' },
          source_titles: { type: 'array', items: { type: 'string' } },
          entities: { type: 'array', items: { type: 'string' } },
        },
        required: ['statement'],
      },
    },
    evidence: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          excerpt: { type: 'string' },
          date: { type: 'string' },
        },
        required: ['title'],
      },
    },
  },
};

export default function DocumentUploader({ inv, onImport }) {
  const [stage, setStage] = useState('idle'); // idle | uploading | extracting | preview | error
  const [fileName, setFileName] = useState('');
  const [extracted, setExtracted] = useState(null);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState({ entities: {}, claims: {}, evidence: {} });
  const fileRef = useRef(null);

  const reset = () => {
    setStage('idle');
    setFileName('');
    setExtracted(null);
    setError(null);
    setSelected({ entities: {}, claims: {}, evidence: {} });
    if (fileRef.current) fileRef.current.value = '';
  };

  const handleFile = async (file) => {
    if (!file) return;
    setFileName(file.name);
    setError(null);
    setExtracted(null);
    setStage('uploading');
    try {
      const upRes = await base44.integrations.Core.UploadFile({ file });
      const fileUrl = upRes.file_url;
      if (!fileUrl) throw new Error('Upload failed — no file URL returned.');

      setStage('extracting');
      const exRes = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url: fileUrl,
        json_schema: EXTRACTION_SCHEMA,
      });
      if (exRes.status === 'error') throw new Error(exRes.details || 'Extraction failed.');
      const data = exRes.output || { entities: [], claims: [], evidence: [] };
      setExtracted(data);
      // Pre-select all rows
      setSelected({
        entities: Object.fromEntries((data.entities || []).map((_, i) => [i, true])),
        claims: Object.fromEntries((data.claims || []).map((_, i) => [i, true])),
        evidence: Object.fromEntries((data.evidence || []).map((_, i) => [i, true])),
      });
      setStage('preview');
    } catch (e) {
      setError(String(e?.message || e));
      setStage('error');
    }
  };

  const handleImport = () => {
    if (!extracted || !onImport) return;
    const picked = {
      entities: (extracted.entities || []).filter((_, i) => selected.entities[i]),
      claims: (extracted.claims || []).filter((_, i) => selected.claims[i]),
      evidence: (extracted.evidence || []).filter((_, i) => selected.evidence[i]),
    };
    onImport(picked);
    reset();
  };

  const toggleRow = (cat, i) => setSelected(s => ({ ...s, [cat]: { ...s[cat], [i]: !s[cat][i] } }));

  const counts = extracted
    ? { e: extracted.entities?.length || 0, c: extracted.claims?.length || 0, v: extracted.evidence?.length || 0 }
    : { e: 0, c: 0, v: 0 };

  return (
    <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#4DD0E1]/25 clip-corner p-4">
      <div className="flex items-center gap-2 mb-3">
        <FileUp size={14} className="text-[#4DD0E1]" />
        <span className="text-[10px] uppercase tracking-[0.15em] font-bold text-[#4DD0E1]">Upload & Extract Documents</span>
        <span className="text-[8px] text-[#484f58] ml-auto">PDF · CSV · XLSX · consumes credits</span>
      </div>

      {!inv && (
        <p className="text-[10px] text-[#8b949e] italic">Create or load an investigation first, then upload source documents to auto-extract entities, claims, and evidence.</p>
      )}

      {inv && stage === 'idle' && (
        <div
          onClick={() => fileRef.current?.click()}
          className="border border-dashed border-[#30363d] hover:border-[#4DD0E1]/50 rounded p-6 text-center cursor-pointer transition-colors"
        >
          <FileUp size={24} className="mx-auto text-[#484f58] mb-2" />
          <p className="text-[10px] text-[#8b949e]">Click to select a PDF, CSV, or XLSX source document</p>
          <p className="text-[9px] text-[#484f58] mt-1">Court filings · spreadsheets · 990s · contracts</p>
          <input ref={fileRef} type="file" accept=".pdf,.csv,.xlsx,.xls,.json,.html" className="hidden" onChange={(e) => handleFile(e.target.files?.[0])} />
        </div>
      )}

      {(stage === 'uploading' || stage === 'extracting') && (
        <div className="flex items-center gap-2 py-4">
          <Loader2 size={16} className="animate-spin text-[#4DD0E1]" />
          <span className="text-[11px] text-[#4DD0E1]">
            {stage === 'uploading' ? `Uploading ${fileName}…` : `Extracting structured data from ${fileName}…`}
          </span>
        </div>
      )}

      {stage === 'error' && (
        <div className="border border-[#f85149]/30 rounded p-3">
          <div className="flex items-center gap-2 mb-1">
            <X size={12} className="text-[#f85149]" />
            <span className="text-[10px] font-bold text-[#f85149]">Extraction failed</span>
          </div>
          <p className="text-[10px] text-[#8b949e] mb-2">{error}</p>
          <button onClick={reset} className="text-[10px] text-[#4DD0E1] hover:underline">Try another file</button>
        </div>
      )}

      {stage === 'preview' && extracted && (
        <div>
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <FileText size={12} className="text-[#3fb950]" />
            <span className="text-[10px] font-bold text-[#e6edf3] truncate max-w-[200px]">{fileName}</span>
            <span className="text-[9px] text-[#484f58]">· {counts.e} entities · {counts.c} claims · {counts.v} evidence</span>
            <div className="ml-auto flex gap-1.5">
              <button onClick={handleImport} className="flex items-center gap-1 bg-[#3fb950] text-black px-2.5 py-1 rounded text-[10px] font-bold hover:opacity-80">
                <CheckCircle2 size={11} /> Import Selected
              </button>
              <button onClick={reset} className="text-[#8b949e] hover:text-[#e6edf3] p-1"><X size={12} /></button>
            </div>
          </div>

          <div className="space-y-3 max-h-80 overflow-y-auto">
            {counts.e > 0 && (
              <div>
                <div className="text-[9px] text-[#4DD0E1] uppercase tracking-wider font-bold mb-1">Entities ({counts.e})</div>
                {extracted.entities.map((e, i) => (
                  <label key={i} className="flex items-start gap-2 py-1 cursor-pointer hover:bg-[#30363d]/20 px-1 rounded">
                    <input type="checkbox" checked={!!selected.entities[i]} onChange={() => toggleRow('entities', i)} className="accent-[#4DD0E1] mt-0.5" />
                    <div>
                      <span className="text-[10px] font-bold text-[#e6edf3]">{e.name}</span>
                      {e.type && <span className="text-[9px] text-[#bc8cff] ml-1.5">{e.type}</span>}
                      {e.description && <p className="text-[9px] text-[#8b949e]">{e.description}</p>}
                    </div>
                  </label>
                ))}
              </div>
            )}
            {counts.c > 0 && (
              <div>
                <div className="text-[9px] text-[#d29922] uppercase tracking-wider font-bold mb-1">Claims ({counts.c})</div>
                {extracted.claims.map((c, i) => (
                  <label key={i} className="flex items-start gap-2 py-1 cursor-pointer hover:bg-[#30363d]/20 px-1 rounded">
                    <input type="checkbox" checked={!!selected.claims[i]} onChange={() => toggleRow('claims', i)} className="accent-[#d29922] mt-0.5" />
                    <div>
                      <p className="text-[10px] text-[#e6edf3]">{c.statement}</p>
                      {c.entities?.length > 0 && <span className="text-[9px] text-[#bc8cff]">{c.entities.join(', ')}</span>}
                    </div>
                  </label>
                ))}
              </div>
            )}
            {counts.v > 0 && (
              <div>
                <div className="text-[9px] text-[#bc8cff] uppercase tracking-wider font-bold mb-1">Evidence ({counts.v})</div>
                {extracted.evidence.map((v, i) => (
                  <label key={i} className="flex items-start gap-2 py-1 cursor-pointer hover:bg-[#30363d]/20 px-1 rounded">
                    <input type="checkbox" checked={!!selected.evidence[i]} onChange={() => toggleRow('evidence', i)} className="accent-[#bc8cff] mt-0.5" />
                    <div>
                      <span className="text-[10px] font-bold text-[#e6edf3]">{v.title}</span>
                      {v.date && <span className="text-[9px] text-[#484f58] ml-1.5">{v.date}</span>}
                      {v.excerpt && <p className="text-[9px] text-[#8b949e] line-clamp-2">{v.excerpt}</p>}
                    </div>
                  </label>
                ))}
              </div>
            )}
            {counts.e + counts.c + counts.v === 0 && (
              <p className="text-[10px] text-[#8b949e] italic">No structured data extracted from this document.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}