import { CheckCircle2, XCircle, Circle, ListChecks } from 'lucide-react';
import { resolveSources } from '@/lib/journalist/investigator';

/**
 * PublicationChecklist — structured readiness gate before any export.
 * Combines computed checks (derived from case data) with manual sign-off checkboxes.
 */
export default function PublicationChecklist({ inv, checklist, onUpdate }) {
  const claims = inv?.claims || [];
  const sources = inv?.sources || [];
  const entities = inv?.entities || [];
  const commentRequests = inv?.comment_requests || [];

  const computed = [
    {
      id: 'claims_supported',
      label: 'Every claim has ≥1 Tier-1/2 source',
      desc: 'All claims must be backed by at least one primary government record or established journalism source.',
      passed: claims.length > 0 && claims.every(c => {
        const resolved = resolveSources(c.source_titles, sources);
        return resolved.some(s => s.tier <= 2);
      }),
      na: claims.length === 0,
    },
    {
      id: 'subjects_contacted',
      label: 'Every subject contacted for comment',
      desc: 'Right-of-reply: all named entities must have been given a fair opportunity to respond.',
      passed: entities.length > 0 && entities.every(e => commentRequests.some(cr => cr.subject === e.name)),
      na: entities.length === 0,
    },
    {
      id: 'has_steelman',
      label: 'Steelman generated and acknowledged',
      desc: 'The strongest case against the findings has been documented and reviewed.',
      passed: !!inv?.brief_enriched?.steelman && !!checklist.steelman_acknowledged,
      na: false,
    },
    {
      id: 'legal_review',
      label: 'Legal review completed',
      desc: 'A qualified attorney has reviewed the findings for libel, privacy, and source protection risks.',
      passed: !!checklist.legal_review_completed,
      na: false,
    },
    {
      id: 'editor_signoff',
      label: 'Editor sign-off',
      desc: 'The responsible editor has reviewed and approved the brief for the next stage of the editorial process.',
      passed: !!checklist.editor_signoff,
      na: false,
    },
  ];

  const completed = computed.filter(c => c.passed).length;
  const total = computed.length;
  const ready = completed === total;

  const manualItems = [
    { id: 'steelman_acknowledged', label: 'I have read and acknowledge the steelman' },
    { id: 'legal_review_completed', label: 'Legal review has been completed' },
    { id: 'editor_signoff', label: 'Editor has signed off' },
  ];

  return (
    <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
      <div className="flex items-center gap-2 mb-3">
        <ListChecks size={14} className={ready ? 'text-[#3fb950]' : 'text-[#d29922]'} />
        <span className="text-[10px] uppercase tracking-wider font-bold" style={{ color: ready ? '#3fb950' : '#d29922' }}>Publication Readiness Checklist</span>
        <span className="ml-auto text-[10px] font-bold" style={{ color: ready ? '#3fb950' : '#d29922' }}>{completed}/{total} {ready ? '✓ READY' : 'PENDING'}</span>
      </div>
      <div className="space-y-2">
        {computed.map(item => {
          const Icon = item.na ? Circle : item.passed ? CheckCircle2 : XCircle;
          const color = item.na ? '#484f58' : item.passed ? '#3fb950' : '#f85149';
          return (
            <div key={item.id} className="flex items-start gap-2 border border-[#30363d] rounded p-2 bg-[#0B0F13]/60">
              <Icon size={14} style={{ color }} className="shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="text-[11px] font-bold text-[#e6edf3]">{item.label}</div>
                <div className="text-[9px] text-[#8b949e]">{item.desc}</div>
              </div>
              {item.na ? <span className="text-[9px] text-[#484f58]">N/A</span> : <span className="text-[9px] font-bold" style={{ color }}>{item.passed ? 'PASS' : 'FAIL'}</span>}
            </div>
          );
        })}
      </div>
      <div className="mt-3 pt-3 border-t border-[#30363d] space-y-1.5">
        {manualItems.map(item => (
          <label key={item.id} className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={!!checklist[item.id]} onChange={e => onUpdate({ ...checklist, [item.id]: e.target.checked })}
              className="w-3.5 h-3.5 accent-[#FF9F00] bg-[#0B0F13] border-[#30363d]" />
            <span className="text-[10px] text-[#e6edf3]">{item.label}</span>
          </label>
        ))}
      </div>
    </div>
  );
}