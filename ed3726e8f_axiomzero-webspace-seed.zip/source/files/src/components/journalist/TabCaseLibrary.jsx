import { Play, Trash2, Library } from 'lucide-react';

/**
 * TabCaseLibrary — browse, load, and delete saved cases.
 */
export default function TabCaseLibrary({ cases, onLoad, onDelete, loading, activeId }) {
  return (
    <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
      <div className="flex items-center gap-2 mb-3"><Library size={12} className="text-[#8b949e]" /><span className="text-[10px] text-[#8b949e] uppercase tracking-wider">Saved Cases ({cases.length})</span></div>
      {!cases.length ? <p className="text-[#8b949e] text-xs italic">No cases saved yet.</p> : (
        <div className="space-y-2">
          {cases.map(c => (
            <div key={c.id} className={`border rounded p-3 flex items-center gap-3 ${activeId === c.id ? 'border-[#FF9F00]/40 bg-[#FF9F00]/5' : 'border-[#30363d]'}`}>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-bold text-[#e6edf3]">{c.title}</div>
                <div className="text-[10px] text-[#8b949e] mt-0.5">
                  {c.journalist || '—'} · {new Date(c.created_date).toLocaleDateString()} · <span className="text-[#3fb950]">{c.status}</span>
                  {c.template && <span className="text-[#bc8cff]"> · {c.template}</span>}
                </div>
                <div className="text-[10px] text-[#8b949e] mt-0.5 truncate">{c.lead?.slice(0, 120)}…</div>
              </div>
              <button onClick={() => onLoad(c.id)} disabled={loading} className="flex items-center gap-1 bg-[#FF9F00]/10 border border-[#FF9F00]/30 text-[#FF9F00] px-3 py-1.5 rounded text-xs hover:bg-[#58a6ff]/20"><Play size={10} /> Load</button>
              <button onClick={() => onDelete(c.id)} className="text-[#f85149] p-1.5 hover:bg-[#f85149]/10 rounded"><Trash2 size={12} /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}