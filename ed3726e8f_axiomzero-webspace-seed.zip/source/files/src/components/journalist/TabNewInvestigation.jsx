import { useState } from 'react';
import { Play, Loader2, BookOpen } from 'lucide-react';
import { INVESTIGATION_TEMPLATES } from '@/lib/journalist/templates';

/**
 * TabNewInvestigation — start a case with a lead, optionally selecting a template.
 */
export default function TabNewInvestigation({ onCreate, loading }) {
  const [title, setTitle] = useState('');
  const [lead, setLead] = useState('');
  const [journalist, setJournalist] = useState('');
  const [templateId, setTemplateId] = useState('');
  const [showTemplates, setShowTemplates] = useState(false);

  const selected = INVESTIGATION_TEMPLATES.find(t => t.id === templateId);

  const handleCreate = () => {
    if (!title.trim() || !lead.trim()) return;
    onCreate({ title: title.trim(), lead: lead.trim(), journalist: journalist.trim(), template: templateId });
    setTitle(''); setLead(''); setJournalist(''); setTemplateId('');
  };

  return (
    <div className="max-w-2xl space-y-3">
      <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
        <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-3">Start a New Investigation</div>
        <label className="text-[9px] text-[#8b949e] block mb-1">Case Title *</label>
        <input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Acme Corp Offshore Accounts" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-3" />
        <label className="text-[9px] text-[#8b949e] block mb-1">Journalist Name</label>
        <input value={journalist} onChange={e => setJournalist(e.target.value)} placeholder="Your name" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-3" />
        <label className="text-[9px] text-[#8b949e] block mb-1">Investigative Lead *</label>
        <textarea value={lead} onChange={e => setLead(e.target.value)} placeholder="The starting premise: the allegation, the tip, the document you received, or the pattern you spotted. The more specific the lead, the better the platform performs." rows={4} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-3 resize-none" />
        <label className="text-[9px] text-[#8b949e] block mb-1">Investigation Template (optional — pre-loads scoping questions & source targets)</label>
        <div className="flex gap-2 mb-2">
          <select value={templateId} onChange={e => setTemplateId(e.target.value)} className="flex-1 bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]">
            <option value="">— No template (blank investigation) —</option>
            {INVESTIGATION_TEMPLATES.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
          </select>
          <button onClick={() => setShowTemplates(s => !s)} className="flex items-center gap-1 border border-[#30363d] text-[#8b949e] px-2 py-1 rounded text-xs hover:text-[#e6edf3]"><BookOpen size={11} /> {showTemplates ? 'Hide' : 'Browse'}</button>
        </div>
        {selected && (
          <div className="bg-[#0B0F13] border border-[#FF9F00]/20 rounded p-2 mb-3">
            <div className="text-[10px] text-[#FF9F00] font-bold mb-1">{selected.label}</div>
            <div className="text-[9px] text-[#8b949e] mb-1">{selected.description}</div>
            <div className="text-[9px] text-[#8b949e]">Starting inputs: {selected.starting_inputs}</div>
            <div className="text-[9px] text-[#3fb950] mt-1">Sources: {selected.source_targets.join(', ')}</div>
          </div>
        )}
        {showTemplates && (
          <div className="max-h-60 overflow-y-auto space-y-1 mb-3 border border-[#30363d] rounded p-2">
            {INVESTIGATION_TEMPLATES.map(t => (
              <button key={t.id} onClick={() => { setTemplateId(t.id); setShowTemplates(false); }} className={`w-full text-left p-2 rounded text-xs ${templateId === t.id ? 'bg-[#FF9F00]/10 border border-[#FF9F00]/30' : 'hover:bg-[#30363d]/30 border border-transparent'}`}>
                <div className="font-bold text-[#e6edf3]">{t.label}</div>
                <div className="text-[9px] text-[#8b949e]">{t.description}</div>
              </button>
            ))}
          </div>
        )}
        <button onClick={handleCreate} disabled={!title.trim() || !lead.trim() || loading} className="flex items-center gap-1.5 bg-[#FF9F00] text-black px-4 py-2 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40">
          {loading ? <Loader2 size={12} className="animate-spin" /> : <Play size={12} />} {loading ? 'Creating…' : 'Start Investigation'}
        </button>
      </div>
      <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#d29922]/30 clip-corner p-4">
        <div className="text-xs font-bold text-[#d29922] mb-2">AxiomZero Investigative Methodology</div>
        <ul className="text-[10px] text-[#8b949e] space-y-1 list-disc list-inside">
          <li>AXIOM is an autonomous multi-agent investigative platform — not a chatbot. Submitting a lead initiates an investigation.</li>
          <li>Every claim is attached to a source. Every source has a 5-tier trust classification.</li>
          <li>The Researcher retrieves documents; the Fact Checker scores them; the Legal Auditor maps statutes; the Editor synthesizes.</li>
          <li>A single low-tier source can never score CONFIRMED — enforced structurally.</li>
          <li>Human judgment is structural, not optional — no output is presented as ready to publish.</li>
        </ul>
      </div>
    </div>
  );
}