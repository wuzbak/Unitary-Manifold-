/**
 * SocialJusticeBooks — expandable section showing the Manifold Social Justice
 * book collection (7 books) from the Unitary-Manifold repository.
 *
 * A single expandable button reveals a grid of book cards, each with its own
 * per-book tailored trigger warning badge. Clicking a card opens the
 * BookReaderOverlay.
 */
import { useState } from 'react';
import { ChevronDown, ChevronUp, BookOpen, ShieldAlert, Scale } from 'lucide-react';
import { SOCIAL_JUSTICE_BOOKS } from '@/lib/journalist/bookLibrary';

export default function SocialJusticeBooks({ onOpenBook }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="space-y-3">
      {/* Expandable header button */}
      <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner overflow-hidden">
        <button
          onClick={() => setExpanded((e) => !e)}
          className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-[#4DD0E1]/5 transition-colors"
        >
          <Scale size={16} className="text-[#4DD0E1] shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-[11px] font-bold text-[#e6edf3]">Manifold Social Justice</div>
            <div className="text-[9px] text-[#484f58]">7 investigative books from the repository</div>
          </div>
          {expanded ? <ChevronUp size={14} className="text-[#4DD0E1] shrink-0" /> : <ChevronDown size={14} className="text-[#484f58] shrink-0" />}
        </button>
      </div>

      {expanded && (
        <div className="fade-in">
          {/* Section description */}
          <div className="bg-[#0d1117]/60 border border-[#30363d] clip-corner px-3 py-2 mb-3">
            <p className="text-[9px] text-[#8b949e] leading-relaxed">
              A collection of investigative dossiers examining systemic injustice — food systems, military accountability,
              economic inequality, institutional confinement, racism, speculation harms, and educational failure.
              Each book carries a per-book trigger warning. AxiomZero takes no political stance; these are framework-driven
              structural investigations following the AXIOM OSINT Triangulation Chain methodology.
            </p>
          </div>

          {/* Book grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {SOCIAL_JUSTICE_BOOKS.map((book) => (
              <button
                key={book.id}
                onClick={() => onOpenBook(book)}
                className="text-left p-3 border bg-[#0d1117] clip-corner hover:border-[#30363d] transition-all group relative overflow-hidden"
                style={{ borderColor: `${book.accent}30` }}
              >
                {/* Trigger warning badge */}
                <div
                  className="absolute top-1.5 right-1.5 flex items-center gap-0.5 px-1.5 py-0.5 border text-[7px] font-bold uppercase tracking-wider"
                  style={{ borderColor: `${book.accent}40`, background: `${book.accent}10`, color: book.accent }}
                  title={book.triggerWarning}
                >
                  <ShieldAlert size={8} /> TW
                </div>

                <BookOpen size={18} style={{ color: book.accent }} className="mb-2 group-hover:scale-110 transition-transform" />
                <div className="text-[10px] font-bold text-[#e6edf3] mb-1 leading-snug pr-8">{book.title}</div>
                <div className="text-[8px] text-[#484f58] leading-tight line-clamp-2">{book.description}</div>

                {/* Trigger warning text */}
                <div className="mt-2 pt-2 border-t border-[#30363d]/50">
                  <p className="text-[8px] text-[#d29922] leading-relaxed line-clamp-2">{book.triggerWarning}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}