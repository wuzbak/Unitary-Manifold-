import { useState } from 'react';
import { FileSearch, Download, FileDown, FileJson, Plus, HelpCircle, AlertTriangle, Scale, Clock, GitBranch, ShieldAlert, ListChecks } from 'lucide-react';
import { generateBrief } from '@/lib/journalist/investigator';
import { downloadDossier } from '@/lib/journalist/dossierGenerator';
import TimelineVisual from './TimelineVisual';
import PublicationChecklist from './PublicationChecklist';

/**
 * TabBrief — generate the structured investigative brief with all enriched sections,
 * behind the hard HILS 'not for publication' gate.
 */
export default function TabBrief({ inv, enriched, onAddQuestion, onGenerate, generating, publicationChecklist, onUpdateChecklist }) {
  const [q, setQ] = useState('');
  const [brief, setBrief] = useState('');

  const handleGen = () => {
    const b = generateBrief(inv, enriched);
    setBrief(b);
    onGenerate(b);
  };

  const LIABILITY_WARNING = [
    '================================================================================',
    '  !! NOT FOR PUBLICATION -- EDITORIAL REVIEW ONLY !!',
    '================================================================================',
    '  All dossiers, briefs, claims, and evidence produced by this platform are',
    '  preliminary research artifacts generated for human editorial review and',
    '  verification. They are not verified reporting, are not fit for publication',
    '  without independent fact-checking and legal review, and must not be',
    '  distributed, cited, or republished in their raw form. The journalist and',
    '  their editorial team bear sole responsibility for any published work.',
    '================================================================================',
    '',
  ].join('\n');

  const exportTxt = () => {
    if (!brief) return;
    const blob = new Blob([LIABILITY_WARNING + '\n' + brief], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `axiom_brief_${(inv.title || 'case').replace(/\s+/g, '_')}.txt`; a.click(); URL.revokeObjectURL(url);
  };

  const exportJson = () => {
    const dossier = { metadata: { platform: 'AxiomZero Technologies & Consulting, SPC', tool: 'AXIOM Investigative Journalist AI', version: 'v2 · 5-agent', exported_at: new Date().toISOString(), publication_status: 'NOT FOR PUBLICATION', disclaimer: 'All dossiers, briefs, claims, and evidence produced by this platform are preliminary research artifacts generated for human editorial review and verification. They are not verified reporting, are not fit for publication without independent fact-checking and legal review, and must not be distributed, cited, or republished in their raw form. The journalist and their editorial team bear sole responsibility for any published work.' }, investigation: inv, enriched, brief };
    const blob = new Blob([JSON.stringify(dossier, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `axiom_dossier_${(inv.title || 'case').replace(/\s+/g, '_')}.json`; a.click(); URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* HILS gate — non-dismissable */}
      <div className="bg-[#3a1a1a] border border-[#f85149] clip-corner p-3 flex items-center gap-3">
        <AlertTriangle size={20} className="text-[#f85149] shrink-0" />
        <div>
          <div className="text-xs font-bold text-[#f85149]">FOR HUMAN REVIEW ONLY — NOT READY TO PUBLISH</div>
          <div className="text-[10px] text-[#e6edf3]">This brief is a research instrument. Editorial judgment — whether the story is ready to run, sources are sufficient, public interest outweighs risk — remains human. Always. The research capacity is amplified. The judgment is not delegated.</div>
        </div>
      </div>

      {/* Open questions */}
      <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><HelpCircle size={14} className="text-[#8b949e]" /><span className="text-[10px] text-[#8b949e] uppercase tracking-wider">Outstanding Questions</span></div>
        {inv && <>
          <div className="flex gap-2 mb-3">
            <input value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => e.key === 'Enter' && q.trim() && (onAddQuestion(q.trim()), setQ(''))} placeholder="Add an open research question…" className="flex-1 bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
            <button onClick={() => { if (q.trim()) { onAddQuestion(q.trim()); setQ(''); } }} disabled={!q.trim()} className="flex items-center gap-1 bg-[#30363d] text-[#e6edf3] px-3 py-2 rounded text-xs hover:bg-[#484f58] disabled:opacity-40"><Plus size={12} /></button>
          </div>
          {inv.open_questions?.length > 0 && (
            <div className="space-y-1">{inv.open_questions.map((qq, i) => <div key={i} className="text-[10px] text-[#8b949e] border-l-2 border-[#58a6ff]/30 pl-2">[{i + 1}] {qq}</div>)}</div>
          )}
        </>}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 flex-wrap">
        <button onClick={handleGen} disabled={!inv || generating} className="flex items-center gap-1.5 bg-[#FF9F00] text-black px-4 py-2 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"><FileSearch size={12} /> Generate Investigative Brief</button>
        {brief && <button onClick={exportTxt} className="flex items-center gap-1.5 bg-[#0B0F13] border border-[#30363d] text-[#3fb950] px-3 py-2 rounded text-xs hover:border-[#3fb950]"><Download size={12} /> Export (.txt)</button>}
        {inv && <button onClick={exportJson} className="flex items-center gap-1.5 bg-[#0B0F13] border border-[#30363d] text-[#bc8cff] px-3 py-2 rounded text-xs hover:border-[#bc8cff]"><FileJson size={12} /> Export Dossier (.json)</button>}
        {inv && <button onClick={() => downloadDossier(inv, brief, enriched)} className="flex items-center gap-1.5 bg-[#0B0F13] border border-[#30363d] text-[#58a6ff] px-3 py-2 rounded text-xs hover:border-[#58a6ff]"><FileDown size={12} /> Export Dossier (.md)</button>}
      </div>

      {/* Publication readiness checklist */}
      {inv && <PublicationChecklist inv={inv} checklist={publicationChecklist || {}} onUpdate={onUpdateChecklist} />}

      {/* Enriched sections */}
      {enriched && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {enriched.executive_summary && (
            <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#FF9F00]/30 clip-corner p-3 md:col-span-2">
              <div className="flex items-center gap-2 mb-1"><FileSearch size={12} className="text-[#FF9F00]" /><span className="text-[10px] text-[#FF9F00] uppercase tracking-wider">Executive Summary</span></div>
              <p className="text-[11px] text-[#e6edf3] leading-relaxed">{enriched.executive_summary}</p>
            </div>
          )}
          {enriched.legal_exposure && (
            <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#d29922]/30 clip-corner p-3">
              <div className="flex items-center gap-2 mb-1"><Scale size={12} className="text-[#d29922]" /><span className="text-[10px] text-[#d29922] uppercase tracking-wider">Legal Exposure</span></div>
              <p className="text-[10px] text-[#e6edf3] leading-relaxed whitespace-pre-wrap">{enriched.legal_exposure}</p>
              <p className="text-[9px] text-[#8b949e] mt-2 italic">Legal consciousness — NOT legal advice.</p>
            </div>
          )}
          {enriched.timeline?.length > 0 && <TimelineVisual timeline={enriched.timeline} />}
          {enriched.contradictions?.length > 0 && (
            <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#bc8cff]/30 clip-corner p-3">
              <div className="flex items-center gap-2 mb-2"><GitBranch size={12} className="text-[#bc8cff]" /><span className="text-[10px] text-[#bc8cff] uppercase tracking-wider">Contradictions (DISPUTED)</span></div>
              <div className="space-y-1">{enriched.contradictions.map((c, i) => <div key={i} className="text-[10px] text-[#e6edf3]"><span className="text-[#bc8cff]">⚡</span> {c.description}</div>)}</div>
              <p className="text-[9px] text-[#8b949e] mt-2 italic">Neither side is resolved by AXIOM — resolution is a human editorial judgment.</p>
            </div>
          )}
          {enriched.steelman && (
            <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#3fb950]/30 clip-corner p-3 md:col-span-2">
              <div className="flex items-center gap-2 mb-1"><ShieldAlert size={12} className="text-[#3fb950]" /><span className="text-[10px] text-[#3fb950] uppercase tracking-wider">Steelman (required — strongest case the findings are wrong)</span></div>
              <p className="text-[10px] text-[#e6edf3] leading-relaxed whitespace-pre-wrap">{enriched.steelman}</p>
            </div>
          )}
          {enriched.recommended_next_steps?.length > 0 && (
            <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-3 md:col-span-2">
              <div className="flex items-center gap-2 mb-2"><ListChecks size={12} className="text-[#FF9F00]" /><span className="text-[10px] text-[#FF9F00] uppercase tracking-wider">Recommended Next Steps</span></div>
              <ol className="text-[10px] text-[#e6edf3] space-y-1 list-decimal list-inside">{enriched.recommended_next_steps.map((s, i) => <li key={i}>{s}</li>)}</ol>
            </div>
          )}
        </div>
      )}

      {/* Brief text */}
      {brief && (
        <div className="bg-[#0B0F13] border border-[#30363d] clip-corner p-4">
          <pre className="text-[10px] text-[#e6edf3] whitespace-pre-wrap font-mono leading-relaxed">{brief}</pre>
        </div>
      )}
    </div>
  );
}