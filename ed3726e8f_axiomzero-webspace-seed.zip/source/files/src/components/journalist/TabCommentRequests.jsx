import { useState } from 'react';
import { Plus, Trash2, Mail, Phone, Mailbox, UserCheck, Clock, MessageSquare } from 'lucide-react';
import JournalistPanel from './JournalistPanel';

const METHODS = [
  { id: 'email', label: 'Email', icon: Mail, color: '#58a6ff' },
  { id: 'phone', label: 'Phone', icon: Phone, color: '#4dd0e1' },
  { id: 'certified_mail', label: 'Certified Mail', icon: Mailbox, color: '#d29922' },
  { id: 'in_person', label: 'In Person', icon: UserCheck, color: '#3fb950' },
];

const STATUSES = ['pending', 'responded', 'declined', 'no_response', 'deadline_passed'];
const STATUS_COLORS = { pending: '#d29922', responded: '#3fb950', declined: '#f85149', no_response: '#8b949e', deadline_passed: '#f85149' };

/**
 * TabCommentRequests — right-of-reply tracking for journalistic contact attempts.
 */
export default function TabCommentRequests({ inv, onAdd, onRemove, onUpdate }) {
  const [subject, setSubject] = useState('');
  const [method, setMethod] = useState('email');
  const [date, setDate] = useState('');
  const [deadline, setDeadline] = useState('');
  const [details, setDetails] = useState('');

  const entities = inv?.entities || [];
  const requests = inv?.comment_requests || [];

  const add = () => {
    if (!subject.trim() || !inv) return;
    onAdd({ subject: subject.trim(), method, date_contacted: date, deadline, contact_details: details.trim(), response_received: false, response_summary: '', status: 'pending' });
    setSubject(''); setMethod('email'); setDate(''); setDeadline(''); setDetails('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="space-y-3">
        <JournalistPanel title="Add Comment Request" icon={Plus} accent="#FF9F00">
          {!inv ? <p className="text-[#f85149] text-xs">Start or load an investigation first.</p> : (
            <div className="space-y-3">
              <div>
                <label className="text-[9px] text-[#8b949e] block mb-1">Subject (entity name) *</label>
                <input value={subject} onChange={e => setSubject(e.target.value)} placeholder="e.g. Jane Smith" list="entity-list" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
                <datalist id="entity-list">{entities.map((e, i) => <option key={i} value={e.name} />)}</datalist>
              </div>
              <div>
                <label className="text-[9px] text-[#8b949e] block mb-1">Contact Method</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {METHODS.map(m => (
                    <button key={m.id} onClick={() => setMethod(m.id)}
                      className={`flex flex-col items-center gap-1 p-2 rounded border text-[9px] transition-all ${method === m.id ? 'border-[#FF9F00]/50 bg-[#FF9F00]/10 text-[#FF9F00]' : 'border-[#30363d] text-[#8b949e] hover:border-[#484f58]'}`}>
                      <m.icon size={14} /> {m.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] text-[#8b949e] block mb-1">Date Contacted</label>
                  <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
                </div>
                <div>
                  <label className="text-[9px] text-[#8b949e] block mb-1">Response Deadline</label>
                  <input type="date" value={deadline} onChange={e => setDeadline(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
                </div>
              </div>
              <div>
                <label className="text-[9px] text-[#8b949e] block mb-1">Contact Details (email/phone/address)</label>
                <input value={details} onChange={e => setDetails(e.target.value)} placeholder="How to reach them" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3]" />
              </div>
              <button onClick={add} disabled={!subject.trim()} className="flex items-center gap-1.5 bg-[#FF9F00] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"><Plus size={12} /> Add Comment Request</button>
            </div>
          )}
        </JournalistPanel>
      </div>

      <JournalistPanel title={`Comment Requests (${requests.length})`} icon={MessageSquare} accent="#4DD0E1" bodyClassName="p-3">
        {!requests.length ? <p className="text-[#8b949e] text-xs italic text-center py-4">No comment requests yet. Track all contact attempts to subjects before publication.</p> : (
          <div className="space-y-2 max-h-[65vh] overflow-y-auto pr-1">
            {requests.map((cr, i) => {
              const methodMeta = METHODS.find(m => m.id === cr.method) || METHODS[0];
              const statusColor = STATUS_COLORS[cr.status] || '#8b949e';
              return (
                <div key={i} className="border border-[#30363d] clip-corner p-3 bg-[#0B0F13]/60 group">
                  <div className="flex items-center gap-2 mb-1.5">
                    <methodMeta.icon size={12} style={{ color: methodMeta.color }} />
                    <span className="text-xs font-bold text-[#e6edf3] flex-1">{cr.subject}</span>
                    <select value={cr.status} onChange={e => onUpdate(i, { status: e.target.value })} className="text-[9px] bg-[#0B0F13] border border-[#30363d] rounded px-1.5 py-0.5 text-[#e6edf3]">
                      {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                    <button onClick={() => onRemove(i)} className="text-[#484f58] hover:text-[#f85149] opacity-0 group-hover:opacity-100"><Trash2 size={11} /></button>
                  </div>
                  <div className="flex items-center gap-3 text-[9px] text-[#8b949e]">
                    {cr.date_contacted && <span className="flex items-center gap-1"><Clock size={9} /> Contacted: {cr.date_contacted}</span>}
                    {cr.deadline && <span className="flex items-center gap-1" style={{ color: statusColor }}>Deadline: {cr.deadline}</span>}
                  </div>
                  {cr.contact_details && <p className="text-[10px] text-[#8b949e] mt-1">Details: {cr.contact_details}</p>}
                  <textarea value={cr.response_summary || ''} onChange={e => onUpdate(i, { response_summary: e.target.value })} placeholder="Response summary…" rows={1} className="w-full mt-1.5 bg-[#0B0F13] border border-[#30363d] rounded p-1.5 text-[10px] text-[#e6edf3] resize-none" />
                </div>
              );
            })}
          </div>
        )}
      </JournalistPanel>
    </div>
  );
}