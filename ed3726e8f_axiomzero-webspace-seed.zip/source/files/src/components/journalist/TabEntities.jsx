import { useState } from 'react';
import { Plus, Users, Trash2 } from 'lucide-react';
import { EntityType, ENTITY_TYPE_OPTIONS } from '@/lib/journalist/investigator';

/**
 * TabEntities — map people, orgs, agencies; accepts Editor-suggested entities.
 */
export default function TabEntities({ inv, onAdd, onRemove, suggestions, crossCaseMatches }) {
  const [name, setName] = useState('');
  const [type, setType] = useState(EntityType.PERSON);
  const [desc, setDesc] = useState('');
  const [stated, setStated] = useState('');
  const [contradiction, setContradiction] = useState('');

  const add = () => {
    if (!name.trim() || !inv) return;
    onAdd({ name: name.trim(), type, description: desc.trim(), stated_position: stated.trim(), contradictions: contradiction.trim() ? [contradiction.trim()] : [] });
    setName(''); setDesc(''); setStated(''); setContradiction('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="space-y-3">
        <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
          <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-3">Add Entity</div>
          {!inv && <p className="text-[#f85149] text-xs">Start or load an investigation first.</p>}
          {inv && <>
            <label className="text-[9px] text-[#8b949e] block mb-1">Name *</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Jane Smith" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
            <label className="text-[9px] text-[#8b949e] block mb-1">Type</label>
            <select value={type} onChange={e => setType(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2">
              {ENTITY_TYPE_OPTIONS.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
            <label className="text-[9px] text-[#8b949e] block mb-1">Description</label>
            <textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="Who they are and their relationship to the investigation" rows={2} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2 resize-none" />
            <label className="text-[9px] text-[#8b949e] block mb-1">Stated Position</label>
            <input value={stated} onChange={e => setStated(e.target.value)} placeholder="What they have said publicly" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-2" />
            <label className="text-[9px] text-[#8b949e] block mb-1">Contradiction (documentary record vs. stated position)</label>
            <input value={contradiction} onChange={e => setContradiction(e.target.value)} placeholder="Where the record differs" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] mb-3" />
            <button onClick={add} disabled={!name.trim()} className="flex items-center gap-1.5 bg-[#FF9F00] text-black px-3 py-1.5 rounded text-xs font-bold hover:opacity-80 disabled:opacity-40"><Plus size={12} /> Add Entity</button>
          </>}
        </div>
        {suggestions && suggestions.length > 0 && (
          <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#bc8cff]/30 clip-corner p-3">
            <div className="text-[9px] text-[#bc8cff] uppercase tracking-wider mb-2">Editor-Suggested Entities</div>
            <div className="space-y-1">
              {suggestions.map((s, i) => (
                <button key={i} onClick={() => onAdd({ name: s.name, type: s.type || EntityType.OTHER, description: s.description || '', stated_position: '', contradictions: [] })}
                  className="w-full text-left p-2 rounded border border-[#30363d] hover:border-[#bc8cff]/40 text-xs">
                  <span className="text-[#bc8cff] font-bold">[{s.type || 'Other'}]</span> <span className="text-[#e6edf3]">{s.name}</span>
                  {s.description && <div className="text-[9px] text-[#8b949e] mt-0.5">{s.description}</div>}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
      <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
        <div className="flex items-center gap-2 mb-3"><Users size={12} className="text-[#8b949e]" /><span className="text-[10px] text-[#8b949e] uppercase tracking-wider">Mapped Entities ({inv?.entities?.length || 0})</span></div>
        {!inv?.entities?.length ? <p className="text-[#8b949e] text-xs italic">No entities yet. Add one above, or run the pipeline to get Editor suggestions.</p> : (
          <div className="space-y-2">
            {inv.entities.map((e, i) => (
              <div key={i} className="border border-[#30363d] rounded p-2">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] border border-[#58a6ff]/30 text-[#58a6ff] px-1.5 py-0.5 rounded">{e.type}</span>
                  <span className="text-xs font-bold text-[#e6edf3] flex-1">{e.name}</span>
                  <button onClick={() => onRemove(i)} className="text-[#484f58] hover:text-[#f85149]"><Trash2 size={11} /></button>
                </div>
                {e.description && <p className="text-[10px] text-[#8b949e] mt-1">{e.description}</p>}
                {e.stated_position && <p className="text-[10px] text-[#8b949e] mt-1">Stated: <em>“{e.stated_position}”</em></p>}
                {e.contradictions?.map((c, j) => <p key={j} className="text-[10px] text-[#f85149] mt-1">⚠ {c}</p>)}
                {crossCaseMatches?.[e.name]?.length > 0 && (
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {crossCaseMatches[e.name].map((mc, j) => (
                      <span key={j} className="text-[8px] px-1.5 py-0.5 rounded border border-[#FF9F00]/30 bg-[#FF9F00]/5 text-[#FF9F00]">↗ Also in: {mc.title}</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}