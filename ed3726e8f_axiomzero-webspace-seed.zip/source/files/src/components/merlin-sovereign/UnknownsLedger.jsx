/**
 * UnknownsLedger — the visible "what Merlin doesn't know yet" surface.
 *
 * Reads from the MerlinNote entity and surfaces open obligations — notes
 * where uncertainty_bounds is set or contradiction_flag is flagged — as data,
 * not footnotes. This is the books' demand made visible: unknowns are
 * obligations, and obligations are tracked.
 */
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2, AlertTriangle, CircleSlash, CheckCircle2, RefreshCw } from 'lucide-react';

const BOUNDS_COLORS = {
  ARCHITECTURE_LIMIT: '#8b949e',
  TENSION_ESCALATED: '#f85149',
  CERTIFIED: '#3fb950',
  OPEN_GAP: '#FF9F00',
  TELEMETRY: '#4dd0e1',
  DECOHERENCE_EVENT: '#bc8cff',
  RESOLVED: '#3fb950',
};

const DOMAIN_COLORS = {
  physics: '#00f5ff', film: '#fbbf24', journalism: '#FF9F00',
  'earth-science': '#3fb950', dnd: '#bc8cff', general: '#8b949e',
};

export default function UnknownsLedger({ compact = false }) {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [resolving, setResolving] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      // Fetch recent notes; filter client-side for those carrying uncertainty
      const recent = await base44.entities.MerlinNote.list('-updated_date', 60);
      const unknowns = (recent || []).filter(n =>
        (n.uncertainty_bounds && n.uncertainty_bounds !== '' && n.uncertainty_bounds !== 'RESOLVED') ||
        n.contradiction_flag === 'flagged'
      );
      setNotes(unknowns);
    } catch {
      setNotes([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const resolveUnknown = async (id) => {
    setResolving(id);
    try {
      await base44.entities.MerlinNote.update(id, { uncertainty_bounds: 'RESOLVED' });
      setNotes(notes.map(n => n.id === id ? { ...n, uncertainty_bounds: 'RESOLVED' } : n));
    } finally {
      setResolving(null);
    }
  };

  const openCount = notes.filter(n => n.uncertainty_bounds !== 'RESOLVED').length;
  const resolvedCount = notes.length - openCount;

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="animate-spin text-[#484f58]" size={18} />
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Summary */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <CircleSlash size={13} className="text-[#FF9F00]" />
          <span className="text-[11px] font-bold text-[#FF9F00]">Unknowns Ledger</span>
          <span className="text-[9px] text-[#484f58]">· {openCount} open · {resolvedCount} resolved</span>
        </div>
        <button onClick={load} className="flex items-center gap-1 text-[9px] text-[#8b949e] hover:text-[#e6edf3] transition-colors">
          <RefreshCw size={10} /> Refresh
        </button>
      </div>

      {!notes.length ? (
        <div className="glass-panel clip-corner p-4 text-center">
          <CheckCircle2 size={20} className="text-[#3fb950] mx-auto mb-2" />
          <p className="text-[10px] text-[#8b949e]">No open unknowns. The ledger is clear — every obligation is either resolved or never arose. This is honest, not empty.</p>
        </div>
      ) : (
        <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-1">
          {notes.map(n => {
            const isResolved = n.uncertainty_bounds === 'RESOLVED';
            const boundsColor = BOUNDS_COLORS[n.uncertainty_bounds] || '#8b949e';
            const domainColor = DOMAIN_COLORS[n.domain] || '#8b949e';
            return (
              <div key={n.id} className={`glass-panel clip-corner p-2.5 border-l-2 ${isResolved ? 'opacity-50' : ''}`} style={{ borderLeftColor: boundsColor }}>
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span className="text-[10px] font-bold text-[#e6edf3] flex-1 min-w-0 truncate">{n.title}</span>
                  <span className="text-[7px] px-1 py-0.5 rounded font-bold shrink-0" style={{ color: boundsColor, border: `1px solid ${boundsColor}40` }}>
                    {n.uncertainty_bounds || 'OPEN_GAP'}
                  </span>
                  <span className="text-[7px] px-1 py-0.5 rounded shrink-0" style={{ color: domainColor, background: `${domainColor}15` }}>
                    {n.domain}
                  </span>
                </div>
                {n.content && (
                  <p className="text-[9px] text-[#8b949e] leading-relaxed line-clamp-2 mb-1.5">{n.content}</p>
                )}
                <div className="flex items-center justify-between gap-2">
                  {n.epistemic_confidence != null && (
                    <span className="text-[8px] text-[#484f58]">confidence {n.epistemic_confidence}</span>
                  )}
                  {n.contradiction_flag === 'flagged' && (
                    <span className="flex items-center gap-1 text-[8px] text-[#f85149]">
                      <AlertTriangle size={9} /> contradiction flagged
                    </span>
                  )}
                  {!isResolved && !compact && (
                    <button
                      onClick={() => resolveUnknown(n.id)}
                      disabled={resolving === n.id}
                      className="text-[8px] text-[#3fb950] hover:underline disabled:opacity-50 ml-auto"
                    >
                      {resolving === n.id ? 'resolving…' : 'mark resolved'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <p className="text-[8px] text-[#484f58] italic leading-relaxed">
        Unknowns are obligations, not footnotes. This ledger is Merlin's honest boundary made visible — what he does not know yet, tracked as data, updated as he learns.
      </p>
    </div>
  );
}