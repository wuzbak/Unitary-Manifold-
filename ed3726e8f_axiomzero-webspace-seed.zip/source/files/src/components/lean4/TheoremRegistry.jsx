import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { FileCode, Shield, Loader2, ChevronRight, Search } from 'lucide-react';
import FidelityBadge from '@/components/shared/FidelityBadge';

const VERDICT_COLORS = {
  PASS: '#3fb950',
  TENSION: '#FF9F00',
  FALSIFIED: '#f85149',
  ARCHITECTURE_LIMIT: '#bc8cff',
  EXTERNAL_WAIT: '#4dd0e1',
  OPEN: '#FF9F00',
  AWAITING_LISA: '#4dd0e1',
};

export default function TheoremRegistry({ onSelectTheorem }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const res = await base44.functions.invoke('lean4ProofRegistry', {});
        const r = res?.data || res;
        if (r?.ok) setData(r);
        else setError(r?.error || 'Failed to load registry');
      } catch (e) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-8 text-[10px] text-[#484f58]">
        <Loader2 size={14} className="animate-spin" /> Fetching Lean4 registry from repo…
      </div>
    );
  }

  if (error) {
    return <div className="text-[10px] text-[#f85149] text-center py-4">{error}</div>;
  }

  const { registry, hardgates, lean_files, lean_file_count, recent_sprints } = data;

  const filteredGates = hardgates.filter(
    (g) => !search || g.id.toLowerCase().includes(search.toLowerCase()) || g.verdict.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-3">
      {/* Registry summary */}
      <div className="glass-panel clip-corner p-3 tactical-hud">
        <div className="flex items-center gap-2 mb-2">
          <FileCode size={13} className="text-[#4dd0e1]" />
          <span className="text-[10px] font-bold text-[#4dd0e1] tracking-wider">LEAN4 THEOREM REGISTRY</span>
          <FidelityBadge tier="repo_mirror" className="ml-auto" />
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <div className="border border-[#30363d] clip-corner p-2">
            <div className="text-[8px] text-[#484f58] uppercase">Theorems</div>
            <div className="text-[#4dd0e1] font-mono text-lg">{registry.theorem_count.toLocaleString()}</div>
          </div>
          <div className="border border-[#30363d] clip-corner p-2">
            <div className="text-[8px] text-[#484f58] uppercase">Hardgates</div>
            <div className="text-[#FF9F00] font-mono text-lg">{registry.hardgate_count}</div>
          </div>
          <div className="border border-[#30363d] clip-corner p-2">
            <div className="text-[8px] text-[#484f58] uppercase">Total Pillars</div>
            <div className="text-[#3fb950] font-mono text-lg">{registry.pillars_total}</div>
          </div>
          <div className="border border-[#30363d] clip-corner p-2">
            <div className="text-[8px] text-[#484f58] uppercase">Lean Files</div>
            <div className="text-[#bc8cff] font-mono text-lg">{lean_file_count}</div>
          </div>
        </div>
        <div className="mt-2 text-[8px] text-[#484f58] leading-relaxed">
          {registry.version} {registry.sprint} · Next pillar slot: {registry.next_slot} · {registry.count_scope}
        </div>
      </div>

      {/* Hardgate verdicts */}
      <div className="glass-panel clip-corner p-3 tactical-hud">
        <div className="flex items-center gap-2 mb-2">
          <Shield size={13} className="text-[#FF9F00]" />
          <span className="text-[10px] font-bold text-[#FF9F00] tracking-wider">HARDGATE VERDICTS</span>
          <div className="flex items-center gap-1 ml-auto">
            <Search size={10} className="text-[#484f58]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Filter gates…"
              className="bg-[#0a0d11] border border-[#30363d] text-[9px] text-[#e6edf3] px-2 py-1 clip-corner w-32 focus:border-[#4dd0e1]/40 outline-none"
            />
          </div>
        </div>
        <div className="max-h-[300px] overflow-y-auto space-y-1">
          {filteredGates.map((g) => {
            const color = VERDICT_COLORS[g.verdict] || '#484f58';
            return (
              <button
                key={g.id}
                onClick={() => onSelectTheorem?.(g)}
                className="w-full flex items-center gap-2 p-2 border border-[#30363d] clip-corner hover:border-[#4dd0e1]/30 hover:bg-[#4dd0e1]/5 transition-colors text-left"
              >
                <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: color, boxShadow: `0 0 4px ${color}` }} />
                <div className="flex-1 min-w-0">
                  <div className="text-[9px] font-bold text-[#e6edf3] truncate">{g.id}</div>
                  <div className="text-[7px] text-[#484f58] truncate">{g.note}</div>
                </div>
                <span
                  className="text-[7px] font-bold px-1.5 py-0.5 clip-corner border shrink-0"
                  style={{ color, borderColor: `${color}40`, backgroundColor: `${color}10` }}
                >
                  {g.verdict}
                </span>
                <span className="text-[7px] text-[#484f58] font-mono shrink-0">P{g.pillar}</span>
                <ChevronRight size={10} className="text-[#484f58] shrink-0" />
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent sprints */}
      {recent_sprints?.length > 0 && (
        <div className="glass-panel clip-corner p-3 tactical-hud">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] font-bold text-[#bc8cff] tracking-wider">RECENT SPRINT PROVENANCE</span>
          </div>
          <div className="space-y-1">
            {recent_sprints.map((s, i) => (
              <div key={i} className="flex items-center gap-2 p-1.5 border border-[#30363d] clip-corner">
                <span className="text-[8px] font-mono text-[#FF9F00] shrink-0">{s.version}</span>
                <span className="text-[8px] text-[#4dd0e1] shrink-0">{s.sprint}</span>
                <span className="text-[8px] text-[#8b949e] flex-1 truncate">{s.title}</span>
                <span className="text-[7px] text-[#484f58] font-mono shrink-0">P{s.pillars}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}