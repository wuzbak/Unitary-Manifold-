import { useState } from 'react';
import { Play, Loader2, CheckCircle, AlertTriangle, Terminal } from 'lucide-react';
import FidelityBadge from '@/components/shared/FidelityBadge';
import { checkProof, SAMPLE_THEOREMS } from '@/lib/lean4Checker';

const VERDICT_COLORS = {
  PASS: '#3fb950',
  TENSION: '#FF9F00',
  FALSIFIED: '#f85149',
  OPEN: '#FF9F00',
};

export default function ProofChecker({ selectedTheorem }) {
  const [theorem, setTheorem] = useState(selectedTheorem || SAMPLE_THEOREMS[0]);
  const [script, setScript] = useState('intro\ninduction\nsimp\nrfl');
  const [result, setResult] = useState(null);
  const [running, setRunning] = useState(false);

  // Sync with parent selection
  if (selectedTheorem && selectedTheorem.id !== theorem.id) {
    setTheorem(selectedTheorem);
    setResult(null);
  }

  const runCheck = () => {
    setRunning(true);
    setResult(null);
    // Simulate brief processing for UX
    setTimeout(() => {
      const res = checkProof(theorem, script);
      setResult(res);
      setRunning(false);
    }, 400);
  };

  const verdictColor = VERDICT_COLORS[theorem.repo_verdict] || '#484f58';

  return (
    <div className="glass-panel clip-corner p-3 tactical-hud border-[#FF9F00]/30">
      {/* Header */}
      <div className="flex items-center gap-2 mb-3">
        <Terminal size={13} className="text-[#FF9F00]" />
        <span className="text-[10px] font-bold text-[#FF9F00] tracking-wider">INTERACTIVE PROOF CHECKER</span>
        <FidelityBadge tier="simulation" className="ml-auto" />
      </div>

      {/* Theorem selector */}
      <div className="mb-3">
        <label className="text-[8px] text-[#484f58] uppercase tracking-wider mb-1 block">Theorem Obligation</label>
        <select
          value={theorem.id}
          onChange={(e) => {
            const t = SAMPLE_THEOREMS.find((x) => x.id === e.target.value);
            if (t) { setTheorem(t); setResult(null); }
          }}
          className="w-full bg-[#0a0d11] border border-[#30363d] text-[10px] text-[#e6edf3] px-2 py-1.5 clip-corner focus:border-[#FF9F00]/40 outline-none"
        >
          {SAMPLE_THEOREMS.map((t) => (
            <option key={t.id} value={t.id}>{t.id} — {t.title}</option>
          ))}
        </select>
      </div>

      {/* Theorem statement */}
      <div className="mb-3 p-2 border border-[#30363d] bg-[#0a0d11] clip-corner">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-[8px] text-[#484f58] uppercase">Statement</span>
          <span
            className="text-[7px] font-bold px-1.5 py-0.5 clip-corner border ml-auto"
            style={{ color: verdictColor, borderColor: `${verdictColor}40`, backgroundColor: `${verdictColor}10` }}
            title={theorem.repo_note}
          >
            REPO: {theorem.repo_verdict}
          </span>
        </div>
        <code className="text-[10px] text-[#4dd0e1] font-mono leading-relaxed block">{theorem.statement}</code>
        {theorem.repo_note && (
          <div className="mt-1.5 text-[8px] text-[#8b949e] italic leading-relaxed border-l-2 border-[#30363d] pl-2">
            {theorem.repo_note}
          </div>
        )}
      </div>

      {/* Proof script editor */}
      <div className="mb-3">
        <label className="text-[8px] text-[#484f58] uppercase tracking-wider mb-1 block">
          Proof Script (tactics: intro, induction, simp, rfl, exact h, apply h)
        </label>
        <textarea
          value={script}
          onChange={(e) => setScript(e.target.value)}
          rows={5}
          className="w-full bg-[#0a0d11] border border-[#30363d] text-[10px] text-[#e6edf3] font-mono px-2 py-1.5 clip-corner focus:border-[#FF9F00]/40 outline-none resize-none"
          placeholder="intro&#10;induction&#10;simp&#10;rfl"
        />
      </div>

      {/* Run button */}
      <button
        onClick={runCheck}
        disabled={running}
        className="w-full flex items-center justify-center gap-2 px-3 py-2 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner hover:bg-[#FF9F00]/20 transition-colors disabled:opacity-50 touch-manipulation mb-3"
      >
        {running ? <Loader2 size={12} className="animate-spin" /> : <Play size={12} />}
        {running ? 'Checking…' : 'Run Proof Check'}
      </button>

      {/* Results */}
      {result && (
        <div className="space-y-2">
          {/* Verdict */}
          <div
            className={`p-2.5 border clip-corner ${
              result.verdict === 'closure_earned'
                ? 'border-[#3fb950]/40 bg-[#3fb950]/5'
                : 'border-[#f85149]/40 bg-[#f85149]/5'
            }`}
          >
            <div className="flex items-center gap-2 mb-1">
              {result.verdict === 'closure_earned' ? (
                <CheckCircle size={14} className="text-[#3fb950]" />
              ) : (
                <AlertTriangle size={14} className="text-[#f85149]" />
              )}
              <span
                className={`text-[10px] font-bold tracking-wider ${
                  result.verdict === 'closure_earned' ? 'text-[#3fb950]' : 'text-[#f85149]'
                }`}
              >
                {result.verdict === 'closure_earned' ? 'CLOSURE EARNED' : 'BLOCKER CERTIFICATE'}
              </span>
            </div>
            <code className="text-[9px] text-[#8b949e] font-mono leading-relaxed block">{result.certificate}</code>
          </div>

          {/* Step trace */}
          <div className="border border-[#30363d] clip-corner p-2">
            <div className="text-[8px] text-[#484f58] uppercase tracking-wider mb-1.5">Tactic Trace</div>
            <div className="space-y-1">
              {result.steps.map((step, i) => (
                <div key={i} className="flex items-center gap-2 text-[9px]">
                  <span className="text-[#484f58] font-mono shrink-0 w-5">{i + 1}.</span>
                  <span className="text-[#4dd0e1] font-mono shrink-0">{step.tactic}</span>
                  <span
                    className={`text-[8px] ml-auto shrink-0 ${
                      step.result === 'solved'
                        ? 'text-[#3fb950]'
                        : step.result === 'error'
                        ? 'text-[#f85149]'
                        : 'text-[#8b949e]'
                    }`}
                  >
                    {step.result}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Fidelity notice */}
          <div className="text-[8px] text-[#484f58] italic leading-relaxed border-l-2 border-[#FF9F00]/30 pl-2">
            <FidelityBadge tier="simulation" size="sm" /> This JS checker is a faithful simulation of Lean4 tactic
            evaluation — it does not use the real Lean4 kernel. The REPO verdict above shows the repo's actual
            computed result.
          </div>
        </div>
      )}
    </div>
  );
}