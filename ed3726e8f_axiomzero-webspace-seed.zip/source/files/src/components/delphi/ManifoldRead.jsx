/**
 * ManifoldRead — Combined Manifold Read Component
 * Runs all 5 oracle types and synthesizes them into one unified
 * manifold interpretation via Merlin (InvokeLLM).
 */
import { useState } from 'react';
import { Sparkles, Loader2, Download, AlertTriangle } from 'lucide-react';
import { buildAstrologyReading } from '@/lib/delphi/astrologyEngine';
import { buildRuneReading } from '@/lib/delphi/runeEngine';
import { buildChineseZodiacReading } from '@/lib/delphi/chineseZodiacEngine';
import { buildReading } from '@/lib/tarotEngine';
import { BIRTH_CITIES } from '@/lib/delphi/natalEngine';
import { getManifoldState, generateManifoldSynthesis } from '@/lib/delphi/dynamicReading';

const MERLIN_AVATAR = 'https://media.base44.com/images/public/6a51c0830aeacd39ab86c4f0/ddeaeeb0c_generated_image.png';

function formatResults(results) {
  const parts = [];
  if (results.astrology) {
    const a = results.astrology;
    parts.push(`[WESTERN ASTROLOGY]\nSun: ${a.sun_sign.name} at ${a.sun_degree}° (${a.sun_sign.element}, ${a.sun_sign.modality})\nMoon: ${a.moon_sign.name} at ${a.moon_degree}°${a.moon_note || ''}\nRising: ${a.rising_sign ? a.rising_sign.name + (a.rising_note || '') : 'Unknown (no birth time)'}\nSummary: ${a.natal_summary}`);
  }
  if (results.zodiac) {
    const z = results.zodiac;
    parts.push(`[CHINESE ZODIAC]\nAnimal: ${z.animal} (${z.yin_yang} ${z.element})\nTrine: ${z.trine_group}\nStrengths: ${z.strengths}\nWeaknesses: ${z.weaknesses}\nDescription: ${z.description}`);
  }
  if (results.runes) {
    const r = results.runes;
    parts.push(`[ELDER FUTHARK RUNES — ${r.spread_type.toUpperCase()}]\n${r.cast.map((c) => `${c.position.name}: ${c.rune.name}${c.rune.is_reversed ? ' (Reversed)' : ''} — ${c.rune.active_meaning}`).join('\n')}\nSynthesis: ${r.synthesis}`);
  }
  if (results.tarot) {
    const t = results.tarot;
    parts.push(`[TAROT — CELTIC CROSS]\nMajor Arcana density: ${t.manifold_metadata.major_count}/10 (${(t.manifold_metadata.major_density * 100).toFixed(0)}%)\n${t.draw.map((c) => `${c.position_number}. ${c.position_name}: ${c.card_name} (${c.arcana})`).join('\n')}\nSynthesis: ${t.interpretation.synthesis.join(' ')}`);
  }
  if (results.oracle) {
    const o = results.oracle;
    parts.push(`[ORACLE ENGINE — SYSTEMIC VECTOR]\n${o.draw.map((c) => `${c.position_number}. ${c.position_name}: ${c.card_name}`).join('\n')}\nSynthesis: ${o.interpretation.synthesis.join(' ')}`);
  }
  return parts.join('\n\n');
}

export default function ManifoldRead() {
  const [birthDate, setBirthDate] = useState('');
  const [birthTime, setBirthTime] = useState('');
  const [cityIndex, setCityIndex] = useState(0);
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [phase, setPhase] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleManifoldRead = async () => {
    if (!birthDate && !question.trim()) return;
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const results = {};
      const today = new Date().toISOString().slice(0, 10);
      const city = BIRTH_CITIES[cityIndex];
      const lat = city.lat ?? 0;
      const lon = city.lon ?? 0;

      setPhase('Casting natal chart...');
      if (birthDate) {
        try {
          results.astrology = buildAstrologyReading(birthDate, birthTime || null, lat, lon);
          const year = new Date(birthDate + 'T00:00').getFullYear();
          results.zodiac = buildChineseZodiacReading(year);
        } catch (e) { /* skip */ }
      }

      setPhase('Drawing runes and tarot...');
      if (question.trim()) {
        try {
          results.runes = await buildRuneReading(question.trim(), 'manifold', today, 'three_rune');
        } catch (e) { /* skip */ }
        try {
          results.tarot = await buildReading(question.trim(), 'manifold', today, 'MANIFOLD_TAROT');
        } catch (e) { /* skip */ }
        try {
          results.oracle = await buildReading(question.trim(), 'governance', today, 'MANIFOLD_ORACLE');
        } catch (e) { /* skip */ }
      }

      setPhase('Merlin synthesizes through the manifold...');
      const resultsText = formatResults(results);
      const state = getManifoldState();
      const synthesis = await generateManifoldSynthesis(resultsText, question.trim(), state);

      setResult({ synthesis, details: results, timestamp: today, manifoldState: state });
    } catch (e) {
      setError(e.message || 'The manifold channel wavered...');
    }
    setLoading(false);
    setPhase('');
  };

  const exportResult = () => {
    if (!result) return;
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'manifold_read.json'; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* Input */}
      <div className="bg-[#0a0a12]/80 backdrop-blur-md border border-[#bc8cff]/20 rounded-lg p-4 clip-corner">
        <div className="flex items-center gap-3 mb-4">
          <div className="relative">
            <img src={MERLIN_AVATAR} alt="Merlin" className="w-12 h-12 rounded-full border-2 border-[#bc8cff]/40" />
            <div className="absolute inset-0 rounded-full border-2 border-[#00f5ff]/20 animate-pulse" />
          </div>
          <div>
            <div className="text-[#bc8cff] text-sm font-bold">Merlin's Manifold Read</div>
            <div className="text-[#8b949e] text-[10px]">All 5 oracles synthesized into one unified interpretation</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
          <div>
            <label className="text-[9px] text-[#8b949e] block mb-1">Birth Date <span className="text-[#484f58]">(Astrology + Zodiac)</span></label>
            <input type="date" value={birthDate} onChange={(e) => setBirthDate(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] focus:border-[#bc8cff]/40" />
          </div>
          <div>
            <label className="text-[9px] text-[#8b949e] block mb-1">Birth Time <span className="text-[#484f58]">(optional — Rising Sign)</span></label>
            <input type="time" value={birthTime} onChange={(e) => setBirthTime(e.target.value)} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] focus:border-[#bc8cff]/40" />
          </div>
        </div>

        <div className="mb-3">
          <label className="text-[9px] text-[#8b949e] block mb-1">Birth Location <span className="text-[#484f58]">(Rising Sign accuracy)</span></label>
          <select value={cityIndex} onChange={(e) => setCityIndex(parseInt(e.target.value))} className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] focus:border-[#bc8cff]/40">
            {BIRTH_CITIES.map((c, i) => <option key={i} value={i}>{c.name}</option>)}
          </select>
        </div>

        <div className="mb-4">
          <label className="text-[9px] text-[#8b949e] block mb-1">Question <span className="text-[#484f58]">(Runes + Tarot + Oracle Engine)</span></label>
          <textarea value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="What shall the manifold reveal?" className="w-full bg-[#0B0F13] border border-[#30363d] rounded p-2 text-xs text-[#e6edf3] resize-none focus:border-[#bc8cff]/40" rows={2} />
        </div>

        <button onClick={handleManifoldRead} disabled={loading || (!birthDate && !question.trim())}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded text-sm font-bold hover:opacity-90 disabled:opacity-40 transition-opacity text-black"
          style={{ background: 'linear-gradient(90deg, #bc8cff, #00f5ff, #FF9F00)' }}>
          {loading ? <><Loader2 size={16} className="animate-spin" /> {phase}</> : <><Sparkles size={16} /> Cast Manifold Read</>}
        </button>
        {!birthDate && !question.trim() && <div className="text-[9px] text-[#484f58] text-center mt-1">Enter a birth date or question to begin</div>}
      </div>

      {/* Error */}
      {error && (
        <div className="flex items-start gap-2 bg-[#2d0a0a] border border-[#f85149] rounded p-3">
          <AlertTriangle size={14} className="text-[#f85149] shrink-0 mt-0.5" />
          <div className="text-[#f85149] text-xs">{error}</div>
        </div>
      )}

      {/* Result */}
      {result && (
        <div className="space-y-3">
          <div className="bg-[#0a0a12]/80 backdrop-blur-md border border-[#bc8cff]/30 rounded-lg p-4 clip-corner">
            <div className="flex items-center gap-2 mb-3">
              <img src={MERLIN_AVATAR} alt="Merlin" className="w-8 h-8 rounded-full border border-[#bc8cff]/30" />
              <div className="text-[#bc8cff] text-sm font-bold">Merlin Speaks — The Unified Manifold</div>
            </div>
            <div className="text-[11px] text-[#e6edf3] leading-relaxed whitespace-pre-wrap">{result.synthesis}</div>
          </div>

          {/* Component summary */}
          <div className="bg-[#12161A] border border-[#30363d] rounded p-3">
            <div className="text-[10px] text-[#8b949e] uppercase tracking-wider mb-2">Component Readings</div>
            <div className="flex flex-wrap gap-2">
              {result.details.astrology && <span className="text-[9px] px-2 py-1 rounded border border-[#bc8cff]/30 text-[#bc8cff]">Astrology: {result.details.astrology.sun_sign.name}</span>}
              {result.details.zodiac && <span className="text-[9px] px-2 py-1 rounded border border-[#ff9f00]/30 text-[#ff9f00]">Zodiac: {result.details.zodiac.animal}</span>}
              {result.details.runes && <span className="text-[9px] px-2 py-1 rounded border border-[#4dd0e1]/30 text-[#4dd0e1]">Runes: {result.details.runes.cast.length} cast</span>}
              {result.details.tarot && <span className="text-[9px] px-2 py-1 rounded border border-[#bc8cff]/30 text-[#bc8cff]">Tarot: {result.details.tarot.manifold_metadata.major_count}/10 Major</span>}
              {result.details.oracle && <span className="text-[9px] px-2 py-1 rounded border border-[#FF9F00]/30 text-[#FF9F00]">Oracle: cast</span>}
            </div>
          </div>

          <button onClick={exportResult} className="w-full flex items-center justify-center gap-1.5 bg-[#0B0F13] border border-[#30363d] text-[#3fb950] px-3 py-2 rounded text-xs hover:border-[#3fb950] transition-colors">
            <Download size={12} /> Export Manifold Read JSON
          </button>
        </div>
      )}
    </div>
  );
}