import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { buildPersonaPrompt } from '@/lib/merlinPersona';

export default function RagQuery() {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query.trim() || loading) return;
    setLoading(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: buildPersonaPrompt({ personaMode: 'serious' }) + `

You are the AxiomZero RAG Sentinel Engine for the Unitary Manifold Physics Framework (v18.0).
Respond to the following query with technical precision. Classify it into an epistemic tier:
- Tier 1: Core Physics Invariant (5D Kaluza-Klein metric, braided winding, radion field, k_CS=74)
- Tier 2: Speculative Engineering (conjectures lacking field-theoretic derivation)
- Tier 3: Analogical Mapping (metaphorical social/ecological applications)

Query: "${query}"`,
        add_context_from_internet: true,
        model: 'gemini_3_flash',
        response_json_schema: {
          type: 'object',
          properties: {
            response: { type: 'string' },
            epistemic_tier: { type: 'string' },
            references: { type: 'array', items: { type: 'string' } }
          }
        }
      });
      setResult(res);
    } catch (e) {
      setResult({ response: `Error: ${e.message}`, epistemic_tier: 'N/A', references: [] });
    }
    setLoading(false);
  };

  return (
    <div className="text-sm">
      <label className="block text-[#8b949e] text-xs mb-1">Query</label>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
        placeholder="5D winding number braided sound speed…"
        className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-2 py-1.5 rounded text-sm mb-3 focus:outline-none focus:border-[#58a6ff]"
      />
      <button
        onClick={handleSearch}
        disabled={loading}
        className="bg-[#58a6ff] text-black px-3 py-1.5 rounded text-sm font-bold hover:opacity-80 disabled:opacity-50"
      >
        {loading ? 'Searching…' : '⚡ Search'}
      </button>
      {result && (
        <div className="mt-3 bg-[#0a0d11] border border-[#30363d] rounded p-2 text-xs max-h-40 overflow-y-auto">
          <div className="text-[#bc8cff] font-bold mb-1">{result.epistemic_tier}</div>
          <p className="text-[#e6edf3] mb-2 whitespace-pre-wrap">{result.response}</p>
          {result.references?.length > 0 && (
            <div className="text-[#8b949e]">
              <div className="font-bold mb-0.5">References:</div>
              {result.references.map((r, i) => <div key={i}>• {r}</div>)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}