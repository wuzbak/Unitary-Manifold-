const MANAGERS = [
  { id: 'M1', name: 'Geometry' },
  { id: 'M2', name: 'Field Solver' },
  { id: 'M3', name: 'Symbolic', verified: true },
  { id: 'M4', name: 'Test Guard', verified: true },
  { id: 'M5', name: 'RAG Engine' },
  { id: 'M6', name: 'Web OSINT' },
  { id: 'M7', name: 'Executive' }
];

export default function ManagerPipeline({ active }) {
  return (
    <div className="text-sm">
      {MANAGERS.map((m) => (
        <div key={m.id} className="flex justify-between items-center py-1 border-b border-[#30363d] last:border-0">
          <span className="text-[#e6edf3]">
            {m.id} {m.name} {m.verified && <span className="text-[#3fb950]">✓</span>}
          </span>
          <span className={`px-1.5 py-0.5 rounded text-xs font-bold ${active ? 'bg-[#1a3a25] text-[#3fb950]' : 'bg-[#0d2040] text-[#58a6ff]'}`}>
            {active ? 'active' : 'ready'}
          </span>
        </div>
      ))}
    </div>
  );
}