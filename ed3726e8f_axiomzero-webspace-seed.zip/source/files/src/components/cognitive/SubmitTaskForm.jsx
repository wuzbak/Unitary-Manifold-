import { useState } from 'react';

export default function SubmitTaskForm({ onSubmit }) {
  const [desc, setDesc] = useState('');
  const [label, setLabel] = useState('HARDGATE');
  const [result, setResult] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!desc.trim() || submitting) return;
    setSubmitting(true);
    const r = await onSubmit(desc.trim(), label);
    setResult(r);
    setDesc('');
    setSubmitting(false);
  };

  return (
    <div className="text-sm">
      <label className="block text-[#8b949e] text-xs mb-1">Description</label>
      <input
        type="text"
        value={desc}
        onChange={(e) => setDesc(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
        placeholder="Check Pillar 300 geometric consistency…"
        className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-2 py-1.5 rounded text-sm mb-2 focus:outline-none focus:border-[#58a6ff]"
      />
      <label className="block text-[#8b949e] text-xs mb-1">Epistemic Label</label>
      <select
        value={label}
        onChange={(e) => setLabel(e.target.value)}
        className="w-full bg-[#0d1117] border border-[#30363d] text-[#e6edf3] px-2 py-1.5 rounded text-sm mb-3"
      >
        <option value="HARDGATE">HARDGATE</option>
        <option value="ADJACENT-TRACK">ADJACENT-TRACK</option>
        <option value="GOVERNANCE">GOVERNANCE</option>
      </select>
      <button
        onClick={handleSubmit}
        disabled={submitting}
        className="bg-[#58a6ff] text-black px-3 py-1.5 rounded text-sm font-bold hover:opacity-80 disabled:opacity-50"
      >
        {submitting ? 'Submitting…' : '▶ Submit'}
      </button>
      {result && <p className="mt-2 text-xs text-[#3fb950]">{result}</p>}
    </div>
  );
}