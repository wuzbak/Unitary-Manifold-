export default function AuditTable({ logs }) {
  if (logs.length === 0) {
    return <p className="text-[#8b949e] text-sm py-4">No audit events recorded.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-[#30363d] text-[#8b949e] text-xs">
            <th className="text-left py-2 px-2 font-medium">Timestamp</th>
            <th className="text-left py-2 px-2 font-medium">Event</th>
            <th className="text-left py-2 px-2 font-medium">Manager</th>
            <th className="text-left py-2 px-2 font-medium">Task Ref</th>
            <th className="text-left py-2 px-2 font-medium">Details</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log) => (
            <tr key={log.id} className="border-b border-[#30363d] last:border-0 hover:bg-[#21262d]">
              <td className="py-2 px-2 text-[#8b949e] text-xs whitespace-nowrap">
                {new Date(log.created_date).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </td>
              <td className="py-2 px-2">
                <span className="text-[#58a6ff] font-mono text-xs">{log.event_type}</span>
              </td>
              <td className="py-2 px-2 text-[#e6edf3] text-xs">{log.manager}</td>
              <td className="py-2 px-2 text-[#8b949e] text-xs font-mono">{log.task_ref ? log.task_ref.slice(0, 8) : '—'}</td>
              <td className="py-2 px-2 text-[#8b949e] text-xs">{log.details || '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}