/**
 * BatchAudioGenerator — Lane A/C batch TTS generation UI.
 *
 * Admin enters text → generateBatchAudio() calls GenerateSpeech (Lane A) →
 * creates a PsiCatRadioTrack. If GenerateSpeech fails, falls back to
 * SpeechSynthesis live-speak track (Lane C).
 *
 * Appears in the PsiCat Radio audio tab for admin users.
 */
import { useState } from 'react';
import { generateBatchAudio } from '@/lib/psicatTts/router';
import { Loader2, Sparkles, CheckCircle2, AlertTriangle, Volume2 } from 'lucide-react';

export default function BatchAudioGenerator({ onGenerated }) {
  const [text, setText] = useState('');
  const [title, setTitle] = useState('');
  const [tier, setTier] = useState('Outreach');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const handleGenerate = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setResult(null);
    try {
      const res = await generateBatchAudio(text, title || `TTS — ${new Date().toLocaleDateString()}`, { tier });
      setResult(res);
      if (res.success) {
        setText('');
        setTitle('');
        if (onGenerated) onGenerated();
      }
    } catch (e) {
      setResult({ success: false, error: e.message });
    } finally {
      setLoading(false);
    }
  };

  const charCount = text.length;
  const maxChars = 5000;

  return (
    <div className="glass-panel clip-corner p-2.5 tactical-hud border-[#bc8cff]/20 mb-3">
      <div className="flex items-center gap-2 mb-2">
        <Sparkles size={13} className="text-[#bc8cff]" />
        <span className="text-[10px] font-bold text-[#bc8cff] tracking-wider">BATCH AUDIO GENERATOR</span>
        <span className="text-[8px] text-[#484f58] ml-auto">Lane A · GenerateSpeech</span>
      </div>

      <div className="space-y-2">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Track title (optional)…"
          className="w-full bg-[#0a0d11] border border-[#bc8cff]/20 text-[10px] text-[#e6edf3] px-2 py-1.5 clip-corner focus:outline-none focus:border-[#bc8cff]/40 placeholder:text-[#484f58]"
        />
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Paste outreach article, book excerpt, or any text to generate audio…"
          rows={4}
          className="w-full bg-[#0a0d11] border border-[#bc8cff]/20 text-[10px] text-[#e6edf3] px-2 py-1.5 clip-corner focus:outline-none focus:border-[#bc8cff]/40 placeholder:text-[#484f58] resize-y"
        />
        <div className="flex items-center gap-2">
          <select
            value={tier}
            onChange={(e) => setTier(e.target.value)}
            className="bg-[#0a0d11] border border-[#30363d] text-[10px] text-[#e6edf3] px-2 py-1.5 clip-corner focus:outline-none"
          >
            <option value="Outreach">Outreach</option>
            <option value="Foundational">Foundational</option>
            <option value="Core">Core</option>
            <option value="Advanced">Advanced</option>
            <option value="Frontier">Frontier</option>
          </select>
          <span className={`text-[8px] font-mono ${charCount > maxChars ? 'text-[#ff6b6b]' : 'text-[#484f58]'}`}>
            {charCount}/{maxChars}
          </span>
          <button
            onClick={handleGenerate}
            disabled={loading || !text.trim() || charCount > maxChars}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#bc8cff]/15 border border-[#bc8cff]/40 text-[#bc8cff] text-[10px] font-bold clip-corner hover:bg-[#bc8cff]/25 disabled:opacity-50 transition-colors touch-manipulation ml-auto"
          >
            {loading ? <Loader2 size={11} className="animate-spin" /> : <Volume2 size={11} />}
            {loading ? 'Generating…' : 'Generate Audio'}
          </button>
        </div>
      </div>

      {result?.success && (
        <div className="mt-2 p-2 border border-[#3fb950]/30 bg-[#3fb950]/5 clip-corner text-[9px] text-[#8b949e] flex items-start gap-1.5">
          <CheckCircle2 size={11} className="text-[#3fb950] shrink-0 mt-0.5" />
          <div>
            <span className="text-[#3fb950] font-bold">Track created:</span> {result.track?.title}
            {result.fallback && (
              <span className="text-[#ff9f0a] block mt-0.5">
                ⚠ Fallback (Lane C) — GenerateSpeech was unavailable. Track will play via browser SpeechSynthesis.
              </span>
            )}
          </div>
        </div>
      )}
      {result?.success === false && (
        <div className="mt-2 p-2 border border-[#ff6b6b]/30 bg-[#ff6b6b]/5 clip-corner text-[9px] text-[#ff6b6b] flex items-start gap-1.5">
          <AlertTriangle size={11} className="shrink-0 mt-0.5" />
          <span>Generation failed: {result.error}</span>
        </div>
      )}
    </div>
  );
}