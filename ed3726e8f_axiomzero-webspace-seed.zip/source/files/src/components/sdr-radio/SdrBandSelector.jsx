import { Radio, RadioTower, Satellite, Globe, Disc3, Waves } from 'lucide-react';

/**
 * SdrBandSelector — prominent band navigation for the All-Band SDR Console.
 * Seven bands: HF, VHF, UHF, WA FM, WA AM, Internet, PsiCat Radio.
 */
const BANDS = [
  { id: 'psicat_radio', label: 'PsiCat Radio', sub: 'Autonomous DJ', icon: Disc3, color: '#FF9F00' },
  { id: 'hf', label: 'HF', sub: 'Shortwave', icon: Radio, color: '#bc8cff' },
  { id: 'vhf', label: 'VHF', sub: '30–300 MHz', icon: RadioTower, color: '#bc8cff' },
  { id: 'uhf', label: 'UHF', sub: '300–3000 MHz', icon: Satellite, color: '#ff6b6b' },
  { id: 'wa_fm', label: 'FM', sub: 'FM Broadcast', icon: Radio, color: '#4dd0e1' },
  { id: 'wa_am', label: 'AM', sub: 'AM Broadcast', icon: Waves, color: '#3fb950' },
  { id: 'internet', label: 'Internet', sub: 'Global Streams', icon: Globe, color: '#00f5ff' },
];

export default function SdrBandSelector({ activeBand, onChange }) {
  return (
    <div className="glass-panel clip-corner p-2 tactical-hud mb-3">
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {BANDS.map((band) => {
          const Icon = band.icon;
          const isActive = activeBand === band.id;
          return (
            <button
              key={band.id}
              onClick={() => onChange(band.id)}
              className={`flex flex-col items-center justify-center gap-0.5 px-3 py-2 clip-corner border transition-all shrink-0 touch-manipulation min-w-[72px] ${
                isActive
                  ? 'border-[var(--band-color)] bg-[var(--band-color)]/15'
                  : 'border-[#30363d] bg-[#0d1117] hover:border-[#00f5ff]/30'
              }`}
              style={{ '--band-color': band.color }}
            >
              <Icon size={16} style={{ color: isActive ? band.color : '#484f58' }} />
              <span
                className="text-[10px] font-bold tracking-wider whitespace-nowrap"
                style={{ color: isActive ? band.color : '#8b949e' }}
              >
                {band.label}
              </span>
              <span className="text-[7px] text-[#484f58] whitespace-nowrap hidden sm:block">
                {band.sub}
              </span>
              {isActive && (
                <span
                  className="w-1 h-1 rounded-full mt-0.5 glow-pulse"
                  style={{ background: band.color }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}