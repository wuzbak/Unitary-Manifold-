import { useState } from 'react';
import { Search, Loader2, X, MapPin, Globe } from 'lucide-react';

/**
 * GeoPrompt — persistent "Personalize Your Station" location search bar.
 *
 * Replaces the former one-time dismissible card + the redundant
 * GlobalLocationSearch bar. Always visible on FM/AM/Internet bands, with a
 * location input, Find button, clear button when a search is active, and
 * cache/LIVE-API + region status indicators.
 *
 * Props:
 *   onSearch(query) — callback when user submits a search
 *   onClear() — callback when user clears the search
 *   isSearching — boolean loading state
 *   searchedRegion — string | null (resolved region name from the search)
 *   fromCache — boolean (whether results came from cache)
 */
export default function GeoPrompt({
  onSearch,
  onClear,
  isSearching = false,
  searchedRegion = null,
  fromCache = false,
}) {
  const [input, setInput] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (trimmed && !isSearching) {
      onSearch(trimmed);
    }
  };

  const handleClear = () => {
    setInput('');
    if (onClear) onClear();
  };

  const hasSearch = searchedRegion !== null;

  return (
    <div className="glass-panel clip-corner p-2.5 tactical-hud mb-3 border-[#4dd0e1]/30 fade-in">
      <div className="flex items-start gap-2.5">
        <div className="flex items-center justify-center w-8 h-8 bg-[#4dd0e1]/10 border border-[#4dd0e1]/30 clip-corner shrink-0">
          <MapPin size={14} className="text-[#4dd0e1]" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-[11px] font-bold text-[#4dd0e1] mb-0.5">Personalize Your Stations</div>
          <p className="text-[9px] text-[#8b949e] leading-relaxed mb-2">
            Enter your zip code or city to find local radio stations anywhere in the world.
            WA stations are loaded by default — search any global location for instant results.
          </p>
          <form onSubmit={handleSubmit} className="flex items-center gap-1.5">
            <div className="relative flex-1 min-w-0">
              <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-[#484f58] pointer-events-none" />
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Zip code or city (e.g. 10001, London, Tokyo)…"
                disabled={isSearching}
                className="w-full bg-[#0a0d11] border border-[#00f5ff]/20 text-[10px] text-[#e6edf3] pl-7 pr-2 py-2 clip-corner focus:outline-none focus:border-[#00f5ff]/40 font-mono placeholder:text-[#484f58] disabled:opacity-50"
              />
            </div>
            {hasSearch && !isSearching && (
              <button
                type="button"
                onClick={handleClear}
                className="flex items-center gap-1 px-2.5 py-2 text-[9px] font-bold border border-[#f85149]/30 bg-[#f85149]/10 text-[#f85149] clip-corner hover:bg-[#f85149]/20 transition-colors shrink-0 touch-manipulation min-h-[44px]"
              >
                <X size={11} /> Clear
              </button>
            )}
            <button
              type="submit"
              disabled={isSearching || !input.trim()}
              className="flex items-center gap-1 px-2.5 py-2 text-[9px] font-bold border border-[#4dd0e1]/40 bg-[#4dd0e1]/10 text-[#4dd0e1] clip-corner hover:bg-[#4dd0e1]/20 transition-colors shrink-0 disabled:opacity-50 touch-manipulation min-h-[44px]"
            >
              {isSearching ? <Loader2 size={11} className="animate-spin" /> : <Search size={11} />}
              <span className="hidden sm:inline">{isSearching ? 'Searching…' : 'Find'}</span>
            </button>
          </form>

          {/* Status line */}
          {hasSearch && (
            <div className="flex items-center gap-2 mt-2 text-[9px]">
              <Globe size={10} className="text-[#4dd0e1] shrink-0" />
              <span className="text-[#8b949e]">
                Showing stations for <span className="text-[#e6edf3] font-bold">{searchedRegion}</span>
              </span>
              {fromCache && (
                <span className="flex items-center gap-0.5 text-[7px] text-[#3fb950] border border-[#3fb950]/30 px-1 clip-corner">
                  CACHED
                </span>
              )}
              {!fromCache && !isSearching && (
                <span className="flex items-center gap-0.5 text-[7px] text-[#bc8cff] border border-[#bc8cff]/30 px-1 clip-corner">
                  LIVE API
                </span>
              )}
            </div>
          )}
          {isSearching && (
            <div className="flex items-center gap-2 mt-2 text-[9px] text-[#FF9F00]">
              <Loader2 size={10} className="animate-spin" />
              Searching global stations for "{input.trim()}"…
            </div>
          )}
        </div>
      </div>
    </div>
  );
}