import { Star, Play, Pause, Trash2, Loader2, Heart } from 'lucide-react';
import StationHealthBadge from './StationHealthBadge';

/**
 * FavoritesPanel — the user's saved radio stations. Each favorite shows a
 * play/pause button, health badge, and remove. Backed by the UserRadioFavorite
 * entity (owner RLS) via the useRadioFavorites hook.
 */
export default function FavoritesPanel({ favorites, loading, activeStationId, onPlay, onRemove }) {
  return (
    <div className="glass-panel clip-corner p-2.5 tactical-hud border-[#FF9F00]/20">
      <div className="flex items-center gap-2 mb-2">
        <Heart size={13} className="text-[#FF9F00]" fill="#FF9F00" />
        <span className="text-[10px] font-bold text-[#FF9F00] uppercase tracking-wider">Favorites</span>
        <span className="text-[8px] text-[#484f58] ml-auto">{favorites.length} saved</span>
      </div>

      <div className="max-h-[300px] overflow-y-auto space-y-1">
        {loading ? (
          <div className="flex items-center justify-center gap-2 py-4 text-[10px] text-[#484f58]">
            <Loader2 size={12} className="animate-spin" /> Loading…
          </div>
        ) : favorites.length === 0 ? (
          <div className="text-[10px] text-[#484f58] text-center py-4">
            No favorites yet. Tap the ★ on any station to save it here.
          </div>
        ) : (
          favorites.map((fav) => {
            const isActive = activeStationId === fav.id || activeStationId === fav.stream_url;
            return (
              <div
                key={fav.id}
                className={`flex items-center gap-2 p-1.5 border clip-corner transition-colors ${
                  isActive
                    ? 'border-[#FF9F00]/50 bg-[#FF9F00]/10'
                    : 'border-[#30363d] bg-[#0d1117] hover:border-[#FF9F00]/30'
                }`}
              >
                <button
                  onClick={() => onPlay(fav)}
                  className="flex items-center justify-center w-7 h-7 bg-[#FF9F00]/10 border border-[#FF9F00]/30 text-[#FF9F00] clip-corner hover:bg-[#FF9F00]/20 transition-colors shrink-0 touch-manipulation"
                >
                  {isActive ? <Pause size={11} /> : <Play size={11} />}
                </button>
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] font-bold text-[#e6edf3] truncate">{fav.station_name}</div>
                  <div className="flex items-center gap-1.5 mt-0.5 text-[7px] text-[#484f58]">
                    {fav.region && <span>{fav.region}</span>}
                    {fav.codec && <span className="text-[#4dd0e1]">{fav.codec}</span>}
                    <StationHealthBadge station={fav} size={6} showLabel={false} />
                  </div>
                </div>
                <button
                  onClick={() => onRemove(fav.id)}
                  className="text-[#484f58] hover:text-[#ff3b30] transition-colors shrink-0 p-1 touch-manipulation"
                  title="Remove favorite"
                >
                  <Trash2 size={11} />
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}