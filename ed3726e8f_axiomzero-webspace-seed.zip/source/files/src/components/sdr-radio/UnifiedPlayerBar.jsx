import { useEffect } from 'react';
import { Play, Pause, ExternalLink, Volume2, AlertTriangle, Loader2, X, Radio, Star } from 'lucide-react';
import { useAudioStream } from '@/hooks/useAudioStream';
import { useMediaSession, setMediaPlaybackState } from '@/hooks/useMediaSession';
import { audioGraph } from '@/lib/sdr-radio/audioGraph';
import StationHealthBadge from './StationHealthBadge';
import ProxyPlayButton from './ProxyPlayButton';

/**
 * UnifiedPlayerBar — now-playing bar for direct-stream stations (WA FM/AM with
 * streams, internet streams, discovery results, favorites). Uses one
 * useAudioStream hook with multi-URL cascade, playlist resolution, and proxy
 * fallback. Web-SDR receivers and PsiCat Radio have their own audio.
 *
 * New: health badge, PsiCat proxy fallback, favorite star, Media Session
 * integration (mobile lock-screen / native-build controls), and play-history
 * callback.
 */
function parseAltUrls(station) {
  try {
    const raw = station?.alt_urls_json;
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.filter(Boolean) : [];
  } catch {
    return [];
  }
}

export default function UnifiedPlayerBar({
  station,
  volume,
  onVolumeChange,
  onStop,
  isFavorite = false,
  onToggleFavorite = null,
  onPlayed = null,
}) {
  const meta = {
    altUrls: parseAltUrls(station),
    name: station?.name,
    codec: station?.codec,
    favicon: station?.favicon_url,
    homepage: station?.homepage_url,
  };

  const {
    audioRef, playing, error, loading, corsEnabled,
    proxyRecommended, usingProxy, togglePlay, stop, playViaProxy, playNative,
  } = useAudioStream(station?.stream_url, volume, true, meta);

  // Connect to the Web Audio graph only after CORS-confirmed successful playback
  useEffect(() => {
    if (audioRef.current && station?.stream_url && playing && (corsEnabled || usingProxy)) {
      audioGraph.connectElement(audioRef.current);
    }
  }, [station?.stream_url, playing, corsEnabled, usingProxy]);

  // Media Session — lock-screen / headset / native-build controls
  useMediaSession(
    {
      title: station?.name || 'Live Radio',
      artist: station?.region || station?.country || 'AxiomZero SDR Console',
      album: 'Live Radio',
      artwork: station?.favicon_url || '',
    },
    {
      onPlay: () => { if (!playing) togglePlay(); },
      onPause: () => { if (playing) togglePlay(); },
      onStop: () => stop(),
    },
  );

  // Playback state + history
  useEffect(() => {
    setMediaPlaybackState(playing ? 'playing' : 'paused');
    if (playing && onPlayed) onPlayed(station);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing]);

  if (!station) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 glass-strong border-t border-[#FF9F00]/30 px-3 py-2.5 tactical-hud">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
        <button
          onClick={togglePlay}
          className="flex items-center justify-center w-10 h-10 bg-[#FF9F00]/10 border border-[#FF9F00]/30 text-[#FF9F00] clip-corner hover:bg-[#FF9F00]/20 transition-colors shrink-0 touch-manipulation"
          aria-label={playing ? 'Pause' : 'Play'}
        >
          {loading ? <Loader2 size={16} className="animate-spin" /> : playing ? <Pause size={16} /> : <Play size={16} />}
        </button>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <Radio size={11} className="text-[#FF9F00] shrink-0" />
            <span className="text-[11px] font-bold text-[#e6edf3] truncate">{station.name}</span>
            {playing && <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] glow-pulse shrink-0" />}
            <StationHealthBadge station={station} size={6} showLabel={false} className="shrink-0" />
            {usingProxy && (
              <span className="text-[7px] text-[#bc8cff] border border-[#bc8cff]/40 px-1 clip-corner shrink-0" title="Streaming via PsiCat server-side relay">PROXY</span>
            )}
            {!corsEnabled && !error && !usingProxy && (
              <span className="text-[7px] text-[#484f58] border border-[#484f58]/40 px-1 clip-corner shrink-0">NO CORS · direct</span>
            )}
          </div>
          <div className="text-[9px] text-[#8b949e] truncate flex items-center gap-1.5">
            {loading ? 'Buffering…' : station.description || station.region}
            {station.codec && <span className="text-[#4dd0e1]">· {station.codec}</span>}
            {station.bitrate > 0 && <span>· {station.bitrate}kbps</span>}
          </div>
        </div>

        {/* Favorite star */}
        {onToggleFavorite && (
          <button
            onClick={() => onToggleFavorite(station)}
            className={`shrink-0 p-1.5 transition-colors touch-manipulation ${isFavorite ? 'text-[#FF9F00]' : 'text-[#484f58] hover:text-[#FF9F00]'}`}
            title={isFavorite ? 'Remove favorite' : 'Add favorite'}
          >
            <Star size={14} fill={isFavorite ? '#FF9F00' : 'none'} />
          </button>
        )}

        {/* Proxy fallback */}
        <ProxyPlayButton
          proxyRecommended={proxyRecommended}
          usingProxy={usingProxy}
          onPlayProxy={playViaProxy}
          onPlayNative={playNative}
          loading={loading}
        />

        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1.5">
            <Volume2 size={11} className="text-[#484f58]" />
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
              className="w-16 accent-[#FF9F00]"
            />
            <span className="text-[8px] text-[#484f58] font-mono w-7">{Math.round(volume * 100)}%</span>
          </div>
          {station.homepage_url && (
            <a
              href={station.homepage_url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#484f58] hover:text-[#00f5ff] transition-colors"
              title="Visit station website"
            >
              <ExternalLink size={13} />
            </a>
          )}
          <button onClick={onStop} className="text-[#484f58] hover:text-[#ff3b30] transition-colors" aria-label="Stop">
            <X size={14} />
          </button>
        </div>
      </div>

      {error && !proxyRecommended && (
        <div className="flex items-center gap-1.5 mt-2 text-[8px] text-[#fbbf24]">
          <AlertTriangle size={11} className="shrink-0" />
          Stream blocked (mixed-content or offline). Try the external link → or use “Play via Proxy”.
        </div>
      )}

      </div>
      <audio ref={audioRef} preload="none" />
    </div>
  );
}