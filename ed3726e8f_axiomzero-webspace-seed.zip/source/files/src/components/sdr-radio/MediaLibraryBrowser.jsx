import { useState, useEffect, useContext } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Music,
  Video,
  Upload,
  Calendar,
  Layers,
  Folder,
  Play,
  Pause,
  Trash2,
  Loader2,
  Tag,
  ListPlus,
} from 'lucide-react';
import { PsiCatQueueContext } from './PsiCatQueueContext';
import MediaUploader from './MediaUploader';
import TrackDownloadButton from './TrackDownloadButton';
import VideoPlayerOverlay from './VideoPlayerOverlay';
import { MediaDisclaimerBanner, MediaDisclaimerBadge } from './MediaDisclaimer';
import { getTrackCategory } from '@/lib/sdr-radio/trackCategory';
import { speak, stopSpeaking } from '@/lib/psicatTts/router';

/**
 * MediaLibraryBrowser — browses the PsiCatRadioTrack library filtered by
 * category. Each track has play/pause, download, and (admin-only) delete.
 *
 * Audio tracks route through the shared audioGraph so VisualizerCanvas and
 * EqRack react in real-time. Video tracks use a standalone <video> element
 * NOT connected to audioGraph (per PRD requirement).
 *
 * Props:
 *   category — 'audio' | 'short_form_audio' | 'video' (which sub-tab)
 *   externalUploaderOpen — boolean to open the uploader from parent
 *   onUploaderClose — callback when uploader closes
 *   isAdmin — gate upload/delete to admin users
 *   onTrackPlay — callback(track) when a track starts playing (for external player sync)
 */
export default function MediaLibraryBrowser({
  category = 'audio',
  externalUploaderOpen,
  onUploaderClose,
  isAdmin = false,
  onTrackPlay,
}) {
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [videoPlayingId, setVideoPlayingId] = useState(null);
  const [showUploader, setShowUploader] = useState(false);
  const [organizing, setOrganizing] = useState(false);
  const queueCtx = useContext(PsiCatQueueContext);
  const playNext = queueCtx?.playNext;
  const hasQueue = !!queueCtx;

  const loadTracks = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.PsiCatRadioTrack.list('-date_created', 500);
      setTracks(list);
    } catch (e) {
      // empty on error
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTracks();
  }, []);

  useEffect(() => {
    if (externalUploaderOpen) setShowUploader(true);
  }, [externalUploaderOpen]);

  useEffect(() => {
    if (!externalUploaderOpen && showUploader === 'external') setShowUploader(false);
  }, [externalUploaderOpen]);

  // Filter tracks by category
  const categoryTracks = tracks.filter((t) => getTrackCategory(t) === category);
  const isVideoCategory = category === 'video';
  // Audio playing state is derived from the shared queue; video uses local state.
  const playingId = isVideoCategory
    ? videoPlayingId
    : (queueCtx?.currentTrack?.id && categoryTracks.some((t) => t.id === queueCtx.currentTrack.id)
       ? queueCtx.currentTrack.id : null);

  // Group by tier (if tiers exist), then sort by date
  const groupedTracks = (() => {
    const tiered = categoryTracks.filter((t) => t.tier);
    const untiered = categoryTracks.filter((t) => !t.tier);

    if (tiered.length === 0) {
      return { Untiered: [...categoryTracks].sort((a, b) => {
        const da = a.proposed_date || a.date_created || '';
        const db = b.proposed_date || b.date_created || '';
        return db.localeCompare(da);
      }) };
    }

    const groups = {};
    for (const t of tiered) {
      if (!groups[t.tier]) groups[t.tier] = [];
      groups[t.tier].push(t);
    }
    // Sort each group by date (newest first)
    for (const tier of Object.keys(groups)) {
      groups[tier].sort((a, b) => {
        const da = a.proposed_date || a.date_created || '';
        const db = b.proposed_date || b.date_created || '';
        return db.localeCompare(da);
      });
    }
    if (untiered.length > 0) groups['Untiered'] = untiered;
    return groups;
  })();

  const isLiveSpeakTrack = (track) => {
    return !track.file_url && track.notes?.includes('TTS_FALLBACK:LIVE_SPEAK');
  };

  const playTrack = (track) => {
    stopSpeaking();

    if (isVideoCategory) {
      // Video: open the VideoPlayerOverlay (overlay manages its own playback)
      if (videoPlayingId === track.id) {
        setVideoPlayingId(null); // toggle close
        return;
      }
      setVideoPlayingId(track.id);
      if (onTrackPlay) onTrackPlay(track);
      return;
    }

    // Audio: route through PsiCatQueueContext for sticky player + visualizer
    if (!queueCtx) return;

    // Lane C fallback track — play via browser SpeechSynthesis
    if (isLiveSpeakTrack(track)) {
      const text = track.notes?.split('---TEXT---\n')[1] || track.notes || '';
      speak(text, { onEnd: () => {} });
      return;
    }

    // If this track is already the current queue track, toggle play/pause
    if (queueCtx.currentTrack?.id === track.id) {
      queueCtx.togglePlay();
      return;
    }

    // Set queue to this category's tracks (library order) and play from clicked track
    const trackIndex = categoryTracks.findIndex((t) => t.id === track.id);
    if (trackIndex < 0) return;
    queueCtx.setQueue(categoryTracks);
    queueCtx.playTrackAt(trackIndex);
    if (onTrackPlay) onTrackPlay(track);
  };

  // Listen for video overlay "next track" events (overlay handles auto-advance)
  useEffect(() => {
    if (!isVideoCategory) return;
    const handler = (e) => {
      const { trackId } = e.detail || {};
      if (trackId) {
        setVideoPlayingId(trackId);
        const t = categoryTracks.find((tr) => tr.id === trackId);
        if (t && onTrackPlay) onTrackPlay(t);
      }
    };
    window.addEventListener('video-overlay-next', handler);
    return () => window.removeEventListener('video-overlay-next', handler);
  }, [isVideoCategory, categoryTracks, onTrackPlay]);

  const deleteTrack = async (track) => {
    if (!confirm(`Delete "${track.title}"?`)) return;
    try {
      await base44.entities.PsiCatRadioTrack.delete(track.id);
      setTracks((prev) => prev.filter((t) => t.id !== track.id));
    } catch (e) {
      alert('Delete failed: ' + e.message);
    }
  };

  const fmtDuration = (s) => {
    if (!s) return '--:--';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const fmtSize = (b) => {
    if (!b) return '--';
    if (b < 1024) return `${b}B`;
    if (b < 1048576) return `${(b / 1024).toFixed(0)}KB`;
    if (b < 1073741824) return `${(b / 1048576).toFixed(1)}MB`;
    return `${(b / 1073741824).toFixed(2)}GB`;
  };

  const renderTrackRow = (track) => {
    const isPlaying = playingId === track.id;
    return (
      <div
        key={track.id}
        className={`flex items-center gap-2 p-2 border clip-corner transition-colors ${
          isPlaying
            ? 'border-[#FF9F00]/40 bg-[#FF9F00]/5'
            : 'border-[#30363d] bg-[#0d1117] hover:border-[#00f5ff]/20'
        }`}
      >
        <button
          onClick={() => playTrack(track)}
          className="flex items-center justify-center w-8 h-8 bg-[#00f5ff]/10 border border-[#00f5ff]/30 text-[#00f5ff] clip-corner hover:bg-[#00f5ff]/20 transition-colors shrink-0 touch-manipulation"
        >
          {isPlaying ? <Pause size={13} /> : <Play size={13} />}
        </button>
        <div className="flex-1 min-w-0">
          <div className="text-[10px] font-bold text-[#e6edf3] truncate">{track.title}</div>
          <div className="flex items-center gap-2 mt-0.5 text-[7px] text-[#484f58]">
            {(track.proposed_date || track.date_created) && (
              <span className="flex items-center gap-0.5">
                <Calendar size={8} className="text-[#4dd0e1]" /> {track.proposed_date || track.date_created}
              </span>
            )}
            {track.manifold_version && (
              <span className="flex items-center gap-0.5 text-[#bc8cff]">
                <Layers size={8} /> {track.manifold_version}
              </span>
            )}
            {track.tier && (
              <span className="flex items-center gap-0.5 text-[#FF9F00]">
                <Tag size={8} /> {track.tier}
              </span>
            )}
            {track.source_folder && (
              <span className="flex items-center gap-0.5 truncate">
                <Folder size={8} /> {track.source_folder}
              </span>
            )}
            {track.original_size_bytes > 0 && (
              <span className="text-[#484f58]">{fmtSize(track.original_size_bytes)}</span>
            )}
            <span className="font-mono">{fmtDuration(track.duration_seconds)}</span>
          </div>
        </div>
        {track.quality_tier === 'compressed_playback' && (
          <span
            className="text-[7px] text-[#bc8cff] shrink-0 border border-[#bc8cff]/30 px-1 clip-corner"
            title="Compressed playback copy"
          >
            COMP
          </span>
        )}
        <MediaDisclaimerBadge className="mr-0.5" />
        {hasQueue && !isVideoCategory && (
          <button
            onClick={() => playNext(track)}
            className="flex items-center justify-center w-7 h-7 text-[#484f58] hover:text-[#FF9F00] transition-colors shrink-0 touch-manipulation"
            title="Play next in PsiCat Radio queue"
          >
            <ListPlus size={11} />
          </button>
        )}
        <TrackDownloadButton track={track} size={11} />
        {isAdmin && (
          <button
            onClick={() => deleteTrack(track)}
            className="text-[#484f58] hover:text-[#ff3b30] transition-colors shrink-0 p-1"
            title="Delete track"
          >
            <Trash2 size={11} />
          </button>
        )}
      </div>
    );
  };

  const categoryLabel = category === 'audio' ? 'Full-Length Audio' : category === 'short_form_audio' ? 'Short Form Audio' : 'Video';

  return (
    <div className="glass-panel clip-corner p-2.5 tactical-hud">
      {/* Header + upload button */}
      <div className="flex items-center gap-2 mb-2">
        {isVideoCategory ? (
          <Video size={13} className="text-[#4dd0e1]" />
        ) : (
          <Music size={13} className={category === 'audio' ? 'text-[#FF9F00]' : 'text-[#bc8cff]'} />
        )}
        <span
          className="text-[10px] font-bold tracking-wider"
          style={{ color: category === 'audio' ? '#FF9F00' : category === 'short_form_audio' ? '#bc8cff' : '#4dd0e1' }}
        >
          {categoryLabel}
        </span>
        <span className="text-[9px] text-[#484f58] ml-auto">{categoryTracks.length} tracks</span>
        {isAdmin && (
          <button
            onClick={() => setShowUploader(!showUploader)}
            className="flex items-center gap-1 px-2.5 py-1.5 text-[9px] font-bold tracking-wider clip-corner border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] hover:bg-[#FF9F00]/20 transition-colors touch-manipulation"
          >
            <Upload size={11} /> Upload
          </button>
        )}
      </div>

      {showUploader && (
        <MediaUploader
          mediaType={isVideoCategory ? 'video' : 'audio'}
          onUploaded={loadTracks}
          onClose={() => {
            setShowUploader(false);
            if (onUploaderClose) onUploaderClose();
          }}
        />
      )}

      {/* Gemini Notebook provenance disclaimer */}
      <MediaDisclaimerBanner className="mb-2" />

      {/* Video player overlay (replaces hidden inline video — large centered modal) */}
      {isVideoCategory && videoPlayingId && (
        <VideoPlayerOverlay
          tracks={categoryTracks}
          currentTrackId={videoPlayingId}
          onClose={() => setVideoPlayingId(null)}
        />
      )}

      {/* Track list grouped by tier */}
      <div className="max-h-[340px] overflow-y-auto space-y-3 mt-2">
        {loading ? (
          <div className="flex items-center justify-center gap-2 py-6 text-[10px] text-[#484f58]">
            <Loader2 size={14} className="animate-spin" /> Loading library…
          </div>
        ) : categoryTracks.length === 0 ? (
          <div className="text-[10px] text-[#484f58] text-center py-6">
            No {categoryLabel.toLowerCase()} tracks.{' '}
            {isAdmin ? 'Upload media to populate this library.' : 'Check back once the admin uploads media.'}
          </div>
        ) : (
          Object.entries(groupedTracks).map(([tier, tierTracks]) => (
            <div key={tier}>
              <div className="flex items-center gap-1.5 mb-1.5 border-b border-[#30363d] pb-1">
                {tier !== 'Untiered' && <Tag size={9} className="text-[#FF9F00]" />}
                <span
                  className={`text-[9px] font-bold uppercase tracking-wider ${tier === 'Untiered' ? 'text-[#484f58]' : 'text-[#FF9F00]'}`}
                >
                  {tier}
                </span>
                <span className="text-[8px] text-[#484f58] ml-auto">{tierTracks.length}</span>
              </div>
              <div className="space-y-1">{tierTracks.map(renderTrackRow)}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}