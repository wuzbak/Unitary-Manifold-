import { Moon, X, Clock } from 'lucide-react';

/**
 * SleepTimerControl — compact sleep-timer control for the sticky player.
 * Presets: 15 / 30 / 45 / 60 min. Fades audio over the final 10 seconds,
 * then pauses. Shows a live countdown when active.
 *
 * Props: sleepTimer — the return value of useSleepTimer({ getAudio, onPause })
 */
const PRESETS = [15, 30, 45, 60];

export default function SleepTimerControl({ sleepTimer }) {
  const { active, remaining, fmtRemaining, start, cancel } = sleepTimer;

  if (active) {
    return (
      <div className="flex items-center gap-1.5 shrink-0">
        <span className="flex items-center gap-1 text-[8px] text-[#bc8cff] font-mono">
          <Moon size={10} /> {fmtRemaining()}
        </span>
        <button
          onClick={cancel}
          className="flex items-center justify-center w-6 h-6 text-[#484f58] hover:text-[#ff3b30] transition-colors touch-manipulation"
          title="Cancel sleep timer"
        >
          <X size={11} />
        </button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1 shrink-0">
      <Clock size={11} className="text-[#484f58]" />
      <div className="flex items-center gap-0.5">
        {PRESETS.map((m) => (
          <button
            key={m}
            onClick={() => start(m)}
            className="text-[7px] px-1.5 py-1 border border-[#30363d] text-[#484f58] hover:text-[#bc8cff] hover:border-[#bc8cff]/40 clip-corner transition-colors touch-manipulation"
            title={`Sleep in ${m} minutes`}
          >
            {m}
          </button>
        ))}
      </div>
    </div>
  );
}