import { useState, useEffect, useCallback } from 'react';
import { Loader2, Flame, TrendingUp, BarChart3, Shuffle, Star, Play, Pause, Globe, Languages, Tag, Sliders } from 'lucide-react';
import { searchStations, fetchBrowseFacets, GENRE_PRESETS, DISCOVERY_MODES } from '@/lib/sdr-radio/radioBrowserClient';
import StationHealthBadge from './StationHealthBadge';

/**
 * DiscoveryPanel — global radio discovery engine for the Internet band.
 *
 * Browse 50,000+ stations by:
 *   - Mode: Popular (votes), Trending (clicktrend), Top Played (clicks), Discover (random)
 *   - Genre/tag chips (curated presets + live top tags from radio-browser)
 *   - Country / language / codec facet chips
 *
 * Results render as compact cards with a health badge, codec/bitrate, and a
 * favorite star. Clicking a result calls onPlayStation(station).
 */
const MODE_ICONS = { Flame, TrendingUp, BarChart3, Shuffle };

export default function DiscoveryPanel({ onPlayStation, activeStationId, isFavorite, onToggleFavorite }) {
  const [mode, setMode] = useState('popular');
  const [tag, setTag] = useState('');
  const [country, setCountry] = useState('');
  const [language, setLanguage] = useState('');
  const [codec, setCodec] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [facets, setFacets] = useState({ tags: [], countries: [], languages: [], codecs: [] });
  const [facetsLoading, setFacetsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load browse facets once
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const f = await fetchBrowseFacets();
        if (!cancelled) setFacets(f);
      } catch { /* non-fatal */ }
      finally { if (!cancelled) setFacetsLoading(false); }
    })();
    return () => { cancelled = true; };
  }, []);

  // Run search on mode/facet change
  const runSearch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const r = await searchStations({
        mode,
        tag: tag || undefined,
        country: country || undefined,
        language: language || undefined,
        codec: codec || undefined,
        limit: 60,
      });
      setResults(r.stations || []);
    } catch (e) {
      setError(e.message || 'Search failed');
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, [mode, tag, country, language, codec]);

  useEffect(() => {
    const t = setTimeout(runSearch, 250); // debounce facet changes
    return () => clearTimeout(t);
  }, [runSearch]);

  const resetFacets = () => { setTag(''); setCountry(''); setLanguage(''); setCodec(''); };
  const hasFacets = tag || country || language || codec;

  return (
    <div className="glass-panel clip-corner p-2.5 tactical-hud border-[#00f5ff]/20">
      {/* Header */}
      <div className="flex items-center gap-2 mb-2">
        <Globe size={13} className="text-[#00f5ff]" />
        <span className="text-[10px] font-bold text-[#00f5ff] uppercase tracking-wider">Global Discovery</span>
        <span className="text-[8px] text-[#484f58] ml-auto">50,000+ stations · radio-browser.info</span>
      </div>

      {/* Mode tabs */}
      <div className="flex items-center gap-1 mb-2 overflow-x-auto pb-1">
        {DISCOVERY_MODES.map((m) => {
          const Icon = MODE_ICONS[m.icon] || Flame;
          const active = mode === m.id;
          return (
            <button
              key={m.id}
              onClick={() => setMode(m.id)}
              className={`flex items-center gap-1 px-2.5 py-1.5 text-[9px] font-bold clip-corner border transition-all shrink-0 touch-manipulation ${
                active
                  ? 'border-[#00f5ff]/50 bg-[#00f5ff]/15 text-[#00f5ff]'
                  : 'border-[#30363d] text-[#8b949e] hover:border-[#00f5ff]/30'
              }`}
            >
              <Icon size={11} /> {m.label}
            </button>
          );
        })}
      </div>

      {/* Genre presets */}
      <div className="mb-1.5">
        <div className="flex items-center gap-1 mb-1 text-[8px] text-[#484f58] uppercase tracking-wider">
          <Tag size={8} /> Genre
        </div>
        <div className="flex items-center gap-1 overflow-x-auto pb-1">
          <button
            onClick={() => setTag('')}
            className={`text-[8px] px-2 py-1 clip-corner border shrink-0 touch-manipulation ${
              !tag ? 'border-[#bc8cff]/50 bg-[#bc8cff]/15 text-[#bc8cff]' : 'border-[#30363d] text-[#484f58] hover:text-[#bc8cff]'
            }`}
          >
            All
          </button>
          {GENRE_PRESETS.map((g) => (
            <button
              key={g.tag}
              onClick={() => setTag(tag === g.tag ? '' : g.tag)}
              className={`text-[8px] px-2 py-1 clip-corner border shrink-0 touch-manipulation ${
                tag === g.tag
                  ? 'border-[#bc8cff]/50 bg-[#bc8cff]/15 text-[#bc8cff]'
                  : 'border-[#30363d] text-[#8b949e] hover:border-[#bc8cff]/40'
              }`}
            >
              {g.label}
            </button>
          ))}
        </div>
      </div>

      {/* Country / Language / Codec facets */}
      <div className="grid grid-cols-3 gap-2 mb-2">
        <FacetSelect
          icon={Globe} label="Country" value={country}
          options={facets.countries.map((c) => ({ value: c.name, label: `${c.name} (${c.count})` }))}
          onChange={setCountry} loading={facetsLoading}
        />
        <FacetSelect
          icon={Languages} label="Language" value={language}
          options={facets.languages.map((l) => ({ value: l.name, label: `${l.name} (${l.count})` }))}
          onChange={setLanguage} loading={facetsLoading}
        />
        <FacetSelect
          icon={Sliders} label="Codec" value={codec}
          options={facets.codecs.map((c) => ({ value: c.name, label: `${c.name} (${c.count})` }))}
          onChange={setCodec} loading={facetsLoading}
        />
      </div>

      {hasFacets && (
        <button
          onClick={resetFacets}
          className="text-[8px] text-[#fbbf24] hover:underline mb-2"
        >
          Clear filters
        </button>
      )}

      {/* Results */}
      <div className="flex items-center gap-2 mb-1.5 border-t border-[#30363d] pt-2">
        <span className="text-[8px] text-[#484f58] uppercase tracking-wider">
          {loading ? 'Searching…' : `${results.length} stations`}
        </span>
        {error && <span className="text-[8px] text-[#f85149] ml-auto">{error}</span>}
      </div>

      <div className="max-h-[380px] overflow-y-auto space-y-1">
        {loading && results.length === 0 ? (
          <div className="flex items-center justify-center gap-2 py-6 text-[10px] text-[#00f5ff]">
            <Loader2 size={14} className="animate-spin" /> Discovering stations…
          </div>
        ) : results.length === 0 ? (
          <div className="text-[10px] text-[#484f58] text-center py-6">
            No stations match these filters. Try clearing filters or switching modes.
          </div>
        ) : (
          results.map((station) => {
            const isActive = !!(activeStationId && station.stream_url && activeStationId === station.stream_url);
            const fav = isFavorite && isFavorite(station.id || station.stream_url);
            return (
              <div
                key={station.id || station.stream_url}
                className={`flex items-center gap-2 p-1.5 border clip-corner transition-colors ${
                  isActive
                    ? 'border-[#FF9F00]/50 bg-[#FF9F00]/10'
                    : 'border-[#30363d] bg-[#0d1117] hover:border-[#00f5ff]/30'
                }`}
              >
                <button
                  onClick={() => onPlayStation(station)}
                  className="flex items-center justify-center w-7 h-7 bg-[#00f5ff]/10 border border-[#00f5ff]/30 text-[#00f5ff] clip-corner hover:bg-[#00f5ff]/20 transition-colors shrink-0 touch-manipulation"
                >
                  {isActive ? <Pause size={11} /> : <Play size={11} />}
                </button>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[10px] font-bold truncate ${isActive ? 'text-[#FF9F00]' : 'text-[#e6edf3]'}`}>
                      {station.name}
                    </span>
                    <StationHealthBadge station={station} size={6} showLabel={false} />
                  </div>
                  <div className="flex items-center gap-2 mt-0.5 text-[7px] text-[#484f58]">
                    {station.country && <span>{station.country}</span>}
                    {station.codec && <span className="text-[#4dd0e1]">{station.codec}</span>}
                    {station.bitrate > 0 && <span>{station.bitrate}kbps</span>}
                    {station.vote_count > 0 && <span className="text-[#bc8cff]">★{station.vote_count}</span>}
                  </div>
                </div>
                {onToggleFavorite && (
                  <button
                    onClick={() => onToggleFavorite(station)}
                    className={`shrink-0 p-1 transition-colors touch-manipulation ${fav ? 'text-[#FF9F00]' : 'text-[#484f58] hover:text-[#FF9F00]'}`}
                    title={fav ? 'Remove favorite' : 'Add favorite'}
                  >
                    <Star size={11} fill={fav ? '#FF9F00' : 'none'} />
                  </button>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

function FacetSelect({ icon: Icon, label, value, options, onChange, loading }) {
  return (
    <div>
      <div className="flex items-center gap-1 mb-0.5 text-[8px] text-[#484f58] uppercase tracking-wider">
        <Icon size={8} /> {label}
      </div>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={loading}
        className="w-full bg-[#0a0d11] border border-[#30363d] text-[9px] text-[#e6edf3] px-1.5 py-1 clip-corner focus:outline-none focus:border-[#00f5ff]/40 font-mono"
      >
        <option value="">Any</option>
        {options.map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
    </div>
  );
}