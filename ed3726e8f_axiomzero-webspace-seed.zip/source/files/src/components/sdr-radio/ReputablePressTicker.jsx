import { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Newspaper, ExternalLink, ShieldCheck } from 'lucide-react';
import TickerHeadlineOverlay from './TickerHeadlineOverlay';
import AllArticlesOverlay from './AllArticlesOverlay';

/**
 * ReputablePressTicker — scrolling news ticker + feed panel for the SDR Radio
 * Console, pulling breaking headlines from reputable outlets via the
 * trustedNewsFeed backend function (global-wires category: BBC, AP, Guardian,
 * DW, PBS, ProPublica, Economist, NYT, etc.).
 *
 * Reuses the existing ticker-marquee CSS animation. Blocked outlets are
 * excluded by definition since feeds are curated in the backend.
 *
 * Tactical-HUD aesthetic: glass-panel, clip-corner, source badges.
 */
const OUTLET_COLORS = {
  'BBC News': '#bb1919',
  'BBC Business': '#bb1919',
  'BBC Technology': '#bb1919',
  'Associated Press (AP)': '#0a6ebd',
  'The Guardian (US)': '#052962',
  'The Guardian (World)': '#052962',
  'Deutsche Welle': '#0a3b8c',
  'PBS NewsHour': '#003087',
  'ProPublica': '#a02c02',
  'The Economist': '#e3120b',
  'Christian Science Monitor': '#4a6da7',
  'NYT (Home)': '#121212',
  'NYT (World)': '#121212',
  'NYT (Business)': '#121212',
  'NYT (Technology)': '#121212',
  'NYT (Science)': '#121212',
};

const STATUS_META = {
  live: { label: 'LIVE', color: '#3fb950' },
  partial: { label: 'PARTIAL', color: '#FF9F00' },
  unavailable: { label: 'OFFLINE', color: '#8b949e' },
  loading: { label: 'SYNC', color: '#4dd0e1' },
};

export default function ReputablePressTicker({ stations, onPlayStation }) {
  const [headlines, setHeadlines] = useState([]);
  const [status, setStatus] = useState('loading');
  const [expanded, setExpanded] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [selectedHeadline, setSelectedHeadline] = useState(null);
  const [showAllArticles, setShowAllArticles] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = (e) => setReducedMotion(e.matches);
    mq.addEventListener?.('change', handler);
    return () => mq.removeEventListener?.('change', handler);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const res = await base44.functions.invoke('trustedNewsFeed', {
          categories: ['global-wires', 'nyt'],
        });
        const d = res.data || res;
        if (cancelled) return;
        setHeadlines(d.headlines || []);
        setStatus(d.status || (d.headlines?.length ? 'live' : 'unavailable'));
      } catch {
        if (!cancelled) {
          setHeadlines([]);
          setStatus('unavailable');
        }
      }
    };
    load();
    const id = setInterval(load, 300000); // refresh every 5 min
    return () => { cancelled = true; clearInterval(id); };
  }, []);

  const tickerItems = useMemo(() => {
    const items = headlines.slice(0, 30);
    return items;
  }, [headlines]);

  const statusMeta = STATUS_META[status] || STATUS_META.loading;

  const fmtTime = (iso) => {
    if (!iso) return '';
    const d = new Date(iso);
    const now = new Date();
    const diff = (now - d) / 1000;
    if (diff < 60) return 'just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return d.toLocaleDateString();
  };

  if (status === 'loading') {
    return (
      <div className="glass-panel clip-corner p-2.5 tactical-hud">
        <div className="flex items-center gap-2 text-[9px] text-[#484f58]">
          <Newspaper size={12} className="text-[#4dd0e1] animate-pulse" />
          <span>Syncing reputable press feeds…</span>
        </div>
      </div>
    );
  }

  if (status === 'unavailable' || tickerItems.length === 0) {
    return (
      <div className="glass-panel clip-corner p-2.5 tactical-hud">
        <div className="flex items-center gap-2 text-[9px] text-[#484f58]">
          <Newspaper size={12} className="text-[#8b949e]" />
          <span>Press feeds temporarily unavailable.</span>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-panel clip-corner tactical-hud overflow-hidden">
      {/* Header bar */}
      <div className="flex items-center gap-2 px-3 py-1.5 border-b border-[#4dd0e1]/15 bg-[#0a0d11]">
        <Newspaper size={12} className="text-[#4dd0e1] shrink-0" />
        <button
          onClick={() => setShowAllArticles(true)}
          className="text-[9px] font-bold text-[#4dd0e1] uppercase tracking-wider hover:text-[#00f5ff] transition-colors"
          title="View all articles"
        >
          Reputable Press
        </button>
        <span className="text-[8px] text-[#484f58]">{tickerItems.length} headlines</span>
        <div className="flex items-center gap-1 ml-auto">
          <span
            className="w-1.5 h-1.5 rounded-full glow-pulse"
            style={{ background: statusMeta.color, color: statusMeta.color }}
          />
          <span className="text-[8px] font-bold tracking-wider" style={{ color: statusMeta.color }}>
            {statusMeta.label}
          </span>
        </div>
        <button
          onClick={() => setExpanded(!expanded)}
          className="text-[8px] text-[#484f58] hover:text-[#4dd0e1] transition-colors ml-1"
        >
          {expanded ? '−' : '+'}
        </button>
      </div>

      {/* Scrolling ticker */}
      {!reducedMotion && !expanded && (
        <div className="overflow-hidden py-1.5" style={{ maskImage: 'linear-gradient(90deg, transparent, #000 3%, #000 97%, transparent)' }}>
          <div className="ticker-marquee flex items-center gap-4 whitespace-nowrap">
            {[...tickerItems, ...tickerItems].map((h, i) => (
              <button
                key={i}
                onClick={() => setSelectedHeadline(h)}
                className="flex items-center gap-2 text-[9px] text-[#8b949e] hover:opacity-90 transition-opacity cursor-pointer"
              >
                <span
                  className="px-1.5 py-0.5 text-[7px] font-bold clip-corner shrink-0"
                  style={{
                    color: OUTLET_COLORS[h.outlet] || '#4dd0e1',
                    border: `1px solid ${OUTLET_COLORS[h.outlet] || '#4dd0e1'}40`,
                    background: `${OUTLET_COLORS[h.outlet] || '#4dd0e1'}10`,
                  }}
                >
                  {h.outlet}
                </span>
                <span className="text-[#e6edf3] hover:text-[#4dd0e1] transition-colors text-left">
                  {h.title}
                </span>
                <span className="text-[#30363d]">◆</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Expanded feed panel */}
      {expanded && (
        <div className="max-h-[280px] overflow-y-auto p-2 space-y-1.5">
          {tickerItems.map((h, i) => (
            <button
              key={i}
              onClick={() => setSelectedHeadline(h)}
              className="flex items-start gap-2 p-1.5 border border-transparent clip-corner hover:border-[#4dd0e1]/20 hover:bg-[#4dd0e1]/5 transition-colors group w-full text-left"
            >
              <span
                className="px-1.5 py-0.5 text-[7px] font-bold clip-corner shrink-0 mt-0.5"
                style={{
                  color: OUTLET_COLORS[h.outlet] || '#4dd0e1',
                  border: `1px solid ${OUTLET_COLORS[h.outlet] || '#4dd0e1'}40`,
                  background: `${OUTLET_COLORS[h.outlet] || '#4dd0e1'}10`,
                }}
              >
                {h.outlet}
              </span>
              <div className="flex-1 min-w-0">
                <div className="text-[9px] text-[#e6edf3] leading-snug group-hover:text-[#4dd0e1] transition-colors">
                  {h.title}
                  <ExternalLink size={8} className="inline ml-1 text-[#484f58] group-hover:text-[#4dd0e1]" />
                </div>
                {h.published && (
                  <div className="text-[7px] text-[#484f58] mt-0.5">{fmtTime(h.published)}</div>
                )}
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Footer — empirical strategy note */}
      <div className="flex items-center gap-1.5 px-3 py-1 border-t border-[#4dd0e1]/10 bg-[#080b0f]">
        <ShieldCheck size={9} className="text-[#3fb950] shrink-0" />
        <span className="text-[7px] text-[#484f58] truncate">
          Curated from empirically-rated outlets — no authoritarian state media or disinformation sources
        </span>
      </div>

      {/* Headline overlay — outlet info, article link, stream play */}
      {selectedHeadline && (
        <TickerHeadlineOverlay
          headline={selectedHeadline}
          stations={stations}
          onPlayStation={onPlayStation}
          onClose={() => setSelectedHeadline(null)}
        />
      )}

      {/* All-articles overlay — full feed grouped by outlet */}
      {showAllArticles && (
        <AllArticlesOverlay
          headlines={headlines}
          onClose={() => setShowAllArticles(false)}
        />
      )}
    </div>
  );
}