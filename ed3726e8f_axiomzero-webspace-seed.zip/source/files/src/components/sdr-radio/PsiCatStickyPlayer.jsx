import { useEffect } from 'react';
import { usePsiCatQueue } from './PsiCatQueueContext';
import { Play, Pause, SkipForward, SkipBack, Rewind, FastForward, Volume2, Disc3, Tag, Layers } from 'lucide-react';
import { useSleepTimer } from '@/hooks/useSleepTimer';
import { useMediaSession, setMediaPlaybackState } from '@/hooks/useMediaSession';
import SleepTimerControl from './SleepTimerControl';

/**
 * PsiCatStickyPlayer — a persistent, sticky media player bar for the PsiCat
 * Radio autonomous DJ. Stays visible at the bottom of the viewport across
 * all SDR Radio Console tabs so playback continues when browsing other bands.
 *
 * Uses the shared PsiCatQueueContext for queue state and audio controls.
 * Only renders when there's a track in the queue.
 */
export default function PsiCatStickyPlayer() {
  const {
    queue,
    currentIndex,
    isPlaying,
    setIsPlaying,
    currentTrack,
    volume,
    setVolume,
    togglePlay,
    skipNext,
    skipPrev,
    seek,
    skipBack15,
    skipForward15,
    currentTime,
    duration,
    setCurrentIndex,
    audioRef,
  } = usePsiCatQueue();

  const sleepTimer = useSleepTimer({
    getAudio: () => audioRef.current,
    onPause: () => setIsPlaying(false),
  });

  useMediaSession(
    {
      title: currentTrack?.title || 'PsiCat Radio',
      artist: currentTrack?.tier || 'PsiCat Radiokitty',
      album: currentTrack?.manifold_version || 'Unitary Manifold Archive',
      artwork: '',
    },
    {
      onPlay: () => { if (!isPlaying) togglePlay(); },
      onPause: () => { if (isPlaying) togglePlay(); },
      onStop: () => { audioRef.current?.pause(); setIsPlaying(false); },
    },
  );

  useEffect(() => {
    setMediaPlaybackState(isPlaying ? 'playing' : 'paused');
  }, [isPlaying]);

  if (!currentTrack) return null;

  const fmtTime = (s) => {
    if (!s) return '--:--';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const progressPct = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 glass-strong clip-corner border-t border-[#FF9F00]/30 tactical-hud">
      {/* Seek bar — thin progress line at the very top of the sticky bar */}
      <div
        className="relative h-1 bg-[#30363d] cursor-pointer group"
        onClick={(e) => {
          if (!duration) return;
          const rect = e.currentTarget.getBoundingClientRect();
          const pct = (e.clientX - rect.left) / rect.width;
          seek(Math.max(0, Math.min(duration, pct * duration)));
        }}
      >
        <div
          className="absolute top-0 left-0 h-full bg-gradient-to-r from-[#FF9F00] to-[#ffb733]"
          style={{ width: `${progressPct}%` }}
        />
        <div
          className="absolute top-1/2 -translate-y-1/2 w-2.5 h-2.5 bg-[#FF9F00] clip-corner opacity-0 group-hover:opacity-100 transition-opacity"
          style={{ left: `calc(${progressPct}% - 5px)` }}
        />
      </div>

      <div className="max-w-7xl mx-auto flex items-center gap-3 px-3 py-2">
        {/* Disc icon */}
        <Disc3
          size={20}
          className={`text-[#FF9F00] shrink-0 ${isPlaying ? 'animate-spin' : ''}`}
          style={{ animationDuration: '3s' }}
        />

        {/* Track info + time */}
        <div className="flex-1 min-w-0">
          <div className="text-[11px] font-bold text-[#e6edf3] truncate">{currentTrack.title}</div>
          <div className="flex items-center gap-2.5 mt-0.5 text-[8px] text-[#484f58]">
            {currentTrack.tier && (
              <span className="flex items-center gap-0.5 text-[#FF9F00]">
                <Tag size={8} /> {currentTrack.tier}
              </span>
            )}
            {currentTrack.manifold_version && (
              <span className="flex items-center gap-0.5 text-[#bc8cff]">
                <Layers size={8} /> {currentTrack.manifold_version}
              </span>
            )}
            <span className="font-mono text-[#FF9F00]">{fmtTime(currentTime)}</span>
            <span className="font-mono text-[#484f58]">/ {fmtTime(duration || currentTrack.duration_seconds)}</span>
            <span className="text-[#FF9F00] font-bold uppercase tracking-wider hidden sm:inline">PsiCat Radio</span>
          </div>
        </div>

        {/* Queue position */}
        <div className="hidden sm:flex items-center gap-1 text-[8px] text-[#484f58] shrink-0">
          <span className="font-mono">{currentIndex + 1}/{queue.length}</span>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={skipPrev}
            className="flex items-center justify-center w-7 h-7 text-[#484f58] hover:text-[#FF9F00] transition-colors touch-manipulation"
            title="Previous track (or restart)"
          >
            <SkipBack size={12} />
          </button>
          <button
            onClick={skipBack15}
            className="flex items-center justify-center w-7 h-7 text-[#484f58] hover:text-[#FF9F00] transition-colors touch-manipulation"
            title="Skip back 15s"
          >
            <Rewind size={12} />
          </button>
          <button
            onClick={togglePlay}
            className="flex items-center justify-center w-9 h-9 bg-[#FF9F00]/15 border border-[#FF9F00]/40 text-[#FF9F00] clip-corner hover:bg-[#FF9F00]/25 transition-colors touch-manipulation"
          >
            {isPlaying ? <Pause size={15} /> : <Play size={15} />}
          </button>
          <button
            onClick={skipForward15}
            className="flex items-center justify-center w-7 h-7 text-[#484f58] hover:text-[#FF9F00] transition-colors touch-manipulation"
            title="Skip forward 15s"
          >
            <FastForward size={12} />
          </button>
          <button
            onClick={skipNext}
            className="flex items-center justify-center w-7 h-7 text-[#484f58] hover:text-[#FF9F00] transition-colors touch-manipulation"
            title="Skip to next track"
          >
            <SkipForward size={12} />
          </button>
        </div>

        {/* Volume */}
        <div className="hidden md:flex items-center gap-1.5 shrink-0 w-24">
          <Volume2 size={11} className="text-[#484f58] shrink-0" />
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={volume}
            onChange={(e) => setVolume(parseFloat(e.target.value))}
            className="flex-1 accent-[#FF9F00]"
          />
        </div>

        {/* Sleep timer */}
        <SleepTimerControl sleepTimer={sleepTimer} />

        {/* Live indicator */}
        {isPlaying && (
          <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] glow-pulse shrink-0" />
        )}
      </div>
    </div>
  );
}