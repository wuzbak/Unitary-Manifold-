import { createContext, useContext, useState, useRef, useEffect, useCallback } from 'react';
import { audioGraph } from '@/lib/sdr-radio/audioGraph';

/**
 * PsiCatQueueContext — shared state for the PsiCat Radio autonomous DJ queue.
 *
 * Centralizes the playlist queue, current index, playing state, and audio
 * element so that:
 *   - PsiCatRadioPlayer can build/manage the queue
 *   - PsiCatStickyPlayer (persistent bar) can display + control playback
 *   - MediaLibraryBrowser's "Play Next" button can inject tracks
 *
 * The audio element lives at the provider level so playback persists across
 * tab switches (the player doesn't unmount when the user browses other bands).
 *
 * Exposes full playback controls: play/pause, skip next/prev, seek, skip
 * back/forward 15s, currentTime, duration, and volume.
 */
export const PsiCatQueueContext = createContext(null);

export function PsiCatQueueProvider({ children }) {
  const [queue, setQueue] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef(null);
  const lastTimeUpdateRef = useRef(0);

  const currentTrack = queue[currentIndex];

  // Load + play current track when index or track changes
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !currentTrack?.file_url) return;
    audio.crossOrigin = 'anonymous';
    try {
      audioGraph.connectElement(audio);
    } catch (e) {
      /* best-effort */
    }
    audio.src = currentTrack.file_url;
    setCurrentTime(0);
    setDuration(0);
    if (isPlaying) {
      audio.play().catch(() => {});
    }
  }, [currentIndex, currentTrack?.file_url]);

  // Auto-advance on track end
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const onEnded = () => {
      setCurrentIndex((prev) => (prev < queue.length - 1 ? prev + 1 : 0));
    };
    audio.addEventListener('ended', onEnded);
    return () => audio.removeEventListener('ended', onEnded);
  }, [queue.length]);

  // Listen to timeupdate + loadedmetadata for seek bar
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTimeUpdate = () => {
      const now = Date.now();
      // Throttle to at most every 250ms to avoid excessive re-renders
      if (now - lastTimeUpdateRef.current < 250) return;
      lastTimeUpdateRef.current = now;
      setCurrentTime(audio.currentTime || 0);
    };

    const onLoadedMetadata = () => {
      setDuration(audio.duration || 0);
      setCurrentTime(0);
    };

    const onDurationChange = () => {
      setDuration(audio.duration || 0);
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('durationchange', onDurationChange);

    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('durationchange', onDurationChange);
    };
  }, []);

  // Sync volume
  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
  }, [volume]);

  const togglePlay = useCallback(() => {
    const audio = audioRef.current;
    if (!audio || !currentTrack) return;
    try {
      audioGraph.connectElement(audio);
    } catch (e) {
      /* best-effort */
    }
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().catch(() => {});
      setIsPlaying(true);
    }
  }, [isPlaying, currentTrack]);

  const skipNext = useCallback(() => {
    if (queue.length === 0) return;
    setCurrentIndex((prev) => (prev < queue.length - 1 ? prev + 1 : 0));
  }, [queue.length]);

  const skipPrev = useCallback(() => {
    if (queue.length === 0) return;
    // If more than 3 seconds in, restart current track; otherwise go to previous
    const audio = audioRef.current;
    if (audio && audio.currentTime > 3) {
      audio.currentTime = 0;
      setCurrentTime(0);
      return;
    }
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : queue.length - 1));
  }, [queue.length]);

  const seek = useCallback((timeSeconds) => {
    const audio = audioRef.current;
    if (!audio || !Number.isFinite(timeSeconds)) return;
    audio.currentTime = timeSeconds;
    setCurrentTime(timeSeconds);
  }, []);

  const skipBack15 = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const newTime = Math.max(0, audio.currentTime - 15);
    audio.currentTime = newTime;
    setCurrentTime(newTime);
  }, []);

  const skipForward15 = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const maxTime = audio.duration || 0;
    const newTime = Math.min(maxTime, audio.currentTime + 15);
    audio.currentTime = newTime;
    setCurrentTime(newTime);
  }, []);

  const playNext = useCallback(
    (track) => {
      setQueue((prev) => {
        const newQueue = [...prev];
        const insertIndex = currentIndex + 1;
        newQueue.splice(insertIndex, 0, track);
        return newQueue;
      });
    },
    [currentIndex],
  );

  const playTrackAt = useCallback((index) => {
    setCurrentIndex(index);
    setIsPlaying(true);
  }, []);

  const value = {
    queue,
    setQueue,
    currentIndex,
    setCurrentIndex,
    isPlaying,
    setIsPlaying,
    currentTrack,
    volume,
    setVolume,
    togglePlay,
    skipNext,
    skipPrev,
    seek,
    skipBack15,
    skipForward15,
    currentTime,
    duration,
    playNext,
    playTrackAt,
    audioRef,
  };

  return (
    <PsiCatQueueContext.Provider value={value}>
      <audio ref={audioRef} preload="auto" className="hidden" />
      {children}
    </PsiCatQueueContext.Provider>
  );
}

export function usePsiCatQueue() {
  const ctx = useContext(PsiCatQueueContext);
  if (!ctx) throw new Error('usePsiCatQueue must be used within PsiCatQueueProvider');
  return ctx;
}