import { X, ExternalLink, Play, Radio, ShieldCheck, AlertCircle } from 'lucide-react';
import { findStationForOutlet } from '@/lib/sdr-radio/outletStreamMatcher';

/**
 * TickerHeadlineOverlay — modal overlay shown when a user clicks a headline in
 * the Reputable Press ticker. Displays the outlet name/description, a button to
 * open the full article in a new tab, and a play button if a matching stream
 * exists for that outlet in the station catalog.
 *
 * Props:
 *   headline — { title, outlet, link, published } the clicked headline
 *   stations — station catalog groups from SdrRadioConsole
 *   onPlayStation(station) — callback to start playback via UnifiedPlayerBar
 *   onClose() — close the overlay
 */
export default function TickerHeadlineOverlay({ headline, stations, onPlayStation, onClose }) {
  if (!headline) return null;

  const matchedStation = findStationForOutlet(headline.outlet, stations);
  const hasStream = matchedStation && matchedStation.stream_url;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm fade-in"
      onClick={onClose}
    >
      <div
        className="glass-strong clip-corner tactical-hud max-w-lg w-full overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-[#4dd0e1]/20 bg-[#0a0d11]">
          <div className="flex items-center gap-2 min-w-0">
            <Radio size={14} className="text-[#4dd0e1] shrink-0" />
            <span className="text-[10px] font-bold text-[#4dd0e1] uppercase tracking-wider truncate">
              {headline.outlet}
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-[#484f58] hover:text-[#e6edf3] transition-colors p-1 shrink-0"
            aria-label="Close"
          >
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-3">
          {/* Headline title */}
          <h2 className="text-sm font-bold text-[#e6edf3] leading-snug">
            {headline.title}
          </h2>

          {/* Outlet description */}
          <p className="text-[10px] text-[#8b949e] leading-relaxed">
            {OUTLET_DESCRIPTIONS[headline.outlet] ||
              `Headline from ${headline.outlet} — a curated reputable press source.`}
          </p>

          {/* Published time */}
          {headline.published && (
            <div className="text-[9px] text-[#484f58]">
              {new Date(headline.published).toLocaleString()}
            </div>
          )}

          {/* Stream play button */}
          {hasStream ? (
            <div className="border border-[#4dd0e1]/30 bg-[#4dd0e1]/5 clip-corner p-3">
              <div className="flex items-center gap-2 mb-2">
                <ShieldCheck size={12} className="text-[#3fb950] shrink-0" />
                <span className="text-[9px] font-bold text-[#3fb950] uppercase tracking-wider">
                  Stream Available
                </span>
              </div>
              <div className="text-[10px] text-[#e6edf3] font-bold mb-1.5 leading-snug">
                {matchedStation.name}
              </div>
              <div className="flex flex-wrap gap-1.5 mb-2 text-[9px] text-[#8b949e]">
                {matchedStation.region && (
                  <span className="text-[#8b949e]">{matchedStation.region}</span>
                )}
                {matchedStation.country && (
                  <span className="text-[#484f58]">· {matchedStation.country}</span>
                )}
                {matchedStation.frequency_mhz > 0 && (
                  <span className="text-[#484f58]">· {matchedStation.frequency_mhz} MHz</span>
                )}
                {matchedStation.codec && (
                  <span className="text-[#484f58]">· {matchedStation.codec}</span>
                )}
                {matchedStation.bitrate > 0 && (
                  <span className="text-[#484f58]">· {matchedStation.bitrate}kbps</span>
                )}
              </div>
              {matchedStation.description && (
                <p className="text-[9px] text-[#8b949e] leading-relaxed mb-2">
                  {matchedStation.description}
                </p>
              )}
              {(() => {
                let tags = [];
                try { tags = JSON.parse(matchedStation.tags_json || '[]'); } catch { tags = []; }
                if (!Array.isArray(tags) || tags.length === 0) return null;
                return (
                  <div className="flex flex-wrap gap-1 mb-2.5">
                    {tags.slice(0, 8).map((t, i) => (
                      <span key={i} className="text-[7px] px-1.5 py-0.5 border border-[#30363d] text-[#8b949e] clip-corner">
                        {t}
                      </span>
                    ))}
                  </div>
                );
              })()}
              <button
                onClick={() => {
                  onPlayStation?.(matchedStation);
                  onClose();
                }}
                className="flex items-center gap-2 w-full px-3 py-2.5 bg-[#4dd0e1] text-black text-[10px] font-bold clip-corner hover:brightness-110 transition-all touch-manipulation min-h-[44px]"
              >
                <Play size={13} /> Play {matchedStation.name}
              </button>
            </div>
          ) : (
            <div className="flex items-start gap-2 border border-[#30363d] bg-[#0a0d11] clip-corner p-2.5">
              <AlertCircle size={12} className="text-[#8b949e] shrink-0 mt-0.5" />
              <span className="text-[9px] text-[#8b949e] leading-relaxed">
                No live audio stream available for {headline.outlet}. Open the article below to read the full story.
              </span>
            </div>
          )}

          {/* Article link button */}
          {headline.link && (
            <a
              href={headline.link}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full px-3 py-2.5 border border-[#00f5ff]/40 bg-[#00f5ff]/10 text-[#00f5ff] text-[10px] font-bold clip-corner hover:bg-[#00f5ff]/20 transition-colors touch-manipulation min-h-[44px]"
            >
              <ExternalLink size={13} /> Open Full Article
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

const OUTLET_DESCRIPTIONS = {
  'BBC News': "BBC World Service — the world's most trusted international news broadcaster. Global news, analysis, and English-language programming from London.",
  'BBC Business': 'BBC business & finance desk — data-driven reporting on global markets, economics, and corporate news.',
  'BBC Technology': 'BBC technology desk — empirical tech industry reporting from London.',
  'Associated Press (AP)': 'Global non-profit cooperative — strict neutral style guide. One of the world\'s most trusted wire services.',
  'The Guardian (US)': 'British daily — Pulitzer-level investigative work; center-left editorial, rigorous news desk.',
  'The Guardian (World)': 'Guardian world desk — international coverage and Pulitzer-level investigative journalism.',
  'Deutsche Welle': "Germany's international broadcaster. English-language news, analysis, and documentary programming from Berlin — outside US polarization.",
  'PBS NewsHour': 'Least biased TV news — uninterrupted time to both sides. America\'s premier public television news program.',
  'ProPublica': 'Non-profit investigative journalism — public records, data analysis, and deep-dive accountability reporting.',
  'The Economist': 'Anonymous bylines — evidence-based collective stance. Global affairs, finance, and analysis.',
  'Christian Science Monitor': 'Secular weekly — avoids outrage cycle, low bias. International and national news with a solutions focus.',
  'NYT (Home)': 'New York Times home page — premium newspaper, rigorous news desk.',
  'NYT (World)': 'NYT world desk — international reporting, primary-source focus.',
  'NYT (Business)': 'NYT business desk — data-driven financial reporting.',
  'NYT (Technology)': 'NYT technology desk — empirical tech industry reporting.',
  'NYT (Science)': 'NYT science desk — peer-reviewed research reporting.',
  'NASA JPL': 'Jet Propulsion Lab — breaking news and deep-space mission features.',
  'NASA': 'NASA site-wide master news stream — official agency feed.',
  'NASA CNEOS': 'Center for Near-Earth Object Studies — NEO tracking data.',
  'ScienceDaily': 'Top research summaries — peer-reviewed study aggregations.',
  'Nature': 'Current issue headlines — peer-reviewed premier journal.',
  'Science Magazine': 'Science Express — early-release peer-reviewed papers.',
  'Cell': 'Articles in press — peer-reviewed life-science journal.',
  'CDC EID': 'Emerging Infectious Diseases — ahead-of-print peer-reviewed.',
};