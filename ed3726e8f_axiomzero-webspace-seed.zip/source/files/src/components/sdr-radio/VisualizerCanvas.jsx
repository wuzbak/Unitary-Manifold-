import { useState, useRef, useEffect } from 'react';
import { Maximize2, Minimize2 } from 'lucide-react';
import { audioGraph } from '@/lib/sdr-radio/audioGraph';
import {
  VISUALIZER_STYLES, renderBars, renderWaveform, renderRadial,
  renderParticles, renderWaterfall, renderLiquid,
  createParticleState, createWaterfallState,
} from '@/lib/sdr-radio/visualizerEngine';
import { createTorusVisualizer } from '@/lib/sdr-radio/torusVisualizer';

/**
 * VisualizerCanvas — full-width audio visualizer with 7 switchable styles.
 * Reads from the shared audioGraph analyser. Two stacked canvases: 2D for
 * six styles, WebGL for the Manifold Torus.
 *
 * Fullscreen overlay: toggles a fixed viewport overlay without destroying
 * or recreating the canvases — the RAF loop and audio graph keep running
 * uninterrupted. Only the container size changes.
 */
export default function VisualizerCanvas({ height = 200 }) {
  const [style, setStyle] = useState('torus');
  const [fullscreen, setFullscreen] = useState(false);
  const canvas2dRef = useRef(null);
  const canvas3dRef = useRef(null);
  const rafRef = useRef(null);
  const torusRef = useRef(null);
  const particleStateRef = useRef(null);
  const waterfallStateRef = useRef(null);

  // Resize canvases to parent dimensions — re-runs on fullscreen toggle
  useEffect(() => {
    const resize = () => {
      for (const ref of [canvas2dRef, canvas3dRef]) {
        const c = ref.current;
        if (!c) continue;
        const parent = c.parentElement;
        const w = parent.clientWidth;
        const h = parent.clientHeight;
        c.width = w;
        c.height = h;
      }
      if (torusRef.current && canvas3dRef.current) {
        torusRef.current.resize(canvas3dRef.current.width, canvas3dRef.current.height);
      }
    };
    // Resize immediately + defer one frame so the DOM layout has settled
    resize();
    requestAnimationFrame(resize);
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [fullscreen]);

  // Init torus on mount
  useEffect(() => {
    if (canvas3dRef.current && !torusRef.current) {
      torusRef.current = createTorusVisualizer(canvas3dRef.current);
      const c = canvas3dRef.current;
      torusRef.current.resize(c.width, c.height);
    }
    return () => {
      if (torusRef.current) { torusRef.current.dispose(); torusRef.current = null; }
    };
  }, []);

  // RAF render loop — restarts when style changes
  useEffect(() => {
    // Resize torus canvas when entering torus mode (canvas may have been display:none)
    if (style === 'torus' && canvas3dRef.current && torusRef.current) {
      const c = canvas3dRef.current;
      const parent = c.parentElement;
      const w = parent.clientWidth;
      const h = parent.clientHeight;
      c.width = w;
      c.height = h;
      torusRef.current.resize(w, h);
    }

    const analyser = audioGraph.getAnalyser();
    if (!analyser) return;
    const freqData = new Uint8Array(analyser.frequencyBinCount);
    const timeData = new Uint8Array(analyser.frequencyBinCount);

    const loop = () => {
      analyser.getByteFrequencyData(freqData);
      analyser.getByteTimeDomainData(timeData);
      const canvas = canvas2dRef.current;
      if (!canvas) { rafRef.current = requestAnimationFrame(loop); return; }
      const ctx = canvas.getContext('2d');
      const w = canvas.width, h = canvas.height;

      if (style === 'torus') {
        if (torusRef.current) torusRef.current.update(freqData);
      } else {
        switch (style) {
          case 'bars': renderBars(ctx, freqData, timeData, w, h); break;
          case 'waveform': renderWaveform(ctx, freqData, timeData, w, h); break;
          case 'radial': renderRadial(ctx, freqData, timeData, w, h); break;
          case 'particles':
            if (!particleStateRef.current) particleStateRef.current = createParticleState(80);
            renderParticles(ctx, freqData, timeData, w, h, particleStateRef.current);
            break;
          case 'waterfall':
            if (!waterfallStateRef.current) waterfallStateRef.current = createWaterfallState(w, h);
            renderWaterfall(ctx, freqData, timeData, w, h, waterfallStateRef.current);
            break;
          case 'liquid': renderLiquid(ctx, freqData, timeData, w, h); break;
        }
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [style]);

  return (
    <div className={fullscreen
      ? "fixed inset-0 z-50 bg-[#0B0F13] flex flex-col"
      : "glass-panel clip-corner tactical-hud overflow-hidden neon-edge"
    }>
      <div className="flex items-center gap-1 p-2 border-b border-[#00f5ff]/15 overflow-x-auto">
        <span className="text-[8px] text-[#484f58] uppercase tracking-wider shrink-0 mr-1">Visualizer</span>
        {VISUALIZER_STYLES.map((s) => (
          <button
            key={s.id}
            onClick={() => setStyle(s.id)}
            className={`px-2 py-1 text-[9px] font-bold clip-corner transition-colors shrink-0 touch-manipulation ${
              style === s.id
                ? 'bg-[#00f5ff]/15 text-[#00f5ff] border border-[#00f5ff]/40'
                : 'text-[#484f58] border border-[#30363d] hover:text-[#8b949e]'
            }`}
          >
            <span className="mr-1">{s.glyph}</span>{s.label}
          </button>
        ))}
        <button
          onClick={() => setFullscreen(!fullscreen)}
          className="flex items-center gap-1 px-2.5 py-1 ml-auto text-[9px] font-bold clip-corner border border-[#FF9F00]/50 bg-[#FF9F00]/15 text-[#FF9F00] hover:bg-[#FF9F00]/25 transition-colors shrink-0 touch-manipulation min-h-[28px]"
          aria-label={fullscreen ? 'Exit fullscreen visuals' : 'Fullscreen visuals'}
          title={fullscreen ? 'Exit Fullscreen Visuals' : 'Fullscreen Visuals'}
        >
          {fullscreen ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
          <span>{fullscreen ? 'Exit' : 'Fullscreen Visuals'}</span>
        </button>
      </div>
      <div className="relative hud-scanline flex-1" style={{ height: fullscreen ? 'calc(100vh - 38px)' : height }}>
        <canvas ref={canvas2dRef} className="absolute inset-0 w-full h-full" style={{ display: style === 'torus' ? 'none' : 'block' }} />
        <canvas ref={canvas3dRef} className="absolute inset-0 w-full h-full" style={{ display: style === 'torus' ? 'block' : 'none' }} />
      </div>
    </div>
  );
}