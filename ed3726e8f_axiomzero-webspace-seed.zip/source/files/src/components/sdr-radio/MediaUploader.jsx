import { useState, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { compressMedia, shouldCompress } from '@/lib/sdr-radio/mediaCompressor';
import { supportsDirectoryUpload } from '@/lib/sdr-radio/supportsDirectory';
import DropZone from './DropZone';
import { Upload, Loader2, CheckCircle, AlertCircle, X, FolderUp, FileUp, Link2, Play, Zap, Clock, Gauge } from 'lucide-react';

const CONCURRENCY = 3;
const MAX_RETRIES = 3;
const UPLOAD_TIMEOUT_MS = 5 * 60 * 1000; // 5 min per file

/**
 * MediaUploader — resilient large-file upload with three modes:
 *   Files  — multi-file picker for individual files
 *   Folder — webkitdirectory drag-drop preserving folder structure
 *   URLs   — paste remote URLs (one per line), cataloged server-side
 *
 * Features:
 *   - Parallel uploads (3 concurrent) with a simple concurrency pool
 *   - Per-file progress: elapsed time, transfer rate, size-based estimate
 *   - Automatic retry (3x with exponential backoff)
 *   - Optional client-side compression for playback-quality copies
 *   - 5-min per-file upload timeout (no silent hangs)
 */
export default function MediaUploader({ mediaType = 'audio', onUploaded, onClose }) {
  const [showUrls, setShowUrls] = useState(false);
  const [queue, setQueue] = useState([]);
  const [urls, setUrls] = useState('');
  const [uploading, setUploading] = useState(false);
  const [compressToggle, setCompressToggle] = useState(false);
  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);
  const [dirSupported] = useState(() => supportsDirectoryUpload());

  const setFolderAttrs = (el) => {
    folderInputRef.current = el;
    if (el) { el.setAttribute('webkitdirectory', ''); el.setAttribute('directory', ''); }
  };

  const updateItem = useCallback((id, patch) => {
    setQueue((prev) => prev.map((q) => (q.id === id ? { ...q, ...patch } : q)));
  }, []);

  const extractFileDuration = (file) =>
    new Promise((resolve) => {
      const url = URL.createObjectURL(file);
      const el = document.createElement(mediaType === 'video' ? 'video' : 'audio');
      el.preload = 'metadata';
      el.onloadedmetadata = () => { URL.revokeObjectURL(url); resolve(el.duration || 0); };
      el.onerror = () => { URL.revokeObjectURL(url); resolve(0); };
      el.src = url;
    });

  const extractUrlDuration = (url) =>
    new Promise((resolve) => {
      const el = document.createElement(mediaType === 'video' ? 'video' : 'audio');
      el.preload = 'metadata';
      el.onloadedmetadata = () => resolve(el.duration || 0);
      el.onerror = () => resolve(0);
      el.src = url;
    });

  const handleFiles = (fileList, pathMap) => {
    const items = Array.from(fileList)
      .filter((f) =>
        mediaType === 'audio'
          ? f.type.startsWith('audio/') || /\.(mp3|wav|ogg|m4a|flac|aac|opus)$/.test(f.name)
          : f.type.startsWith('video/') || /\.(mp4|webm|mov|avi|mkv)$/.test(f.name),
      )
      .map((f, i) => ({
        id: `file-${Date.now()}-${i}`,
        name: f.name,
        size: f.size,
        file: f,
        sourceFolder:
          pathMap?.get(f) ||
          (f.webkitRelativePath ? f.webkitRelativePath.split('/').slice(0, -1).join('/') : ''),
        status: 'queued',
        progress: 0,
        elapsed: 0,
        rate: 0,
        attempt: 0,
      }));
    setQueue((prev) => [...prev, ...items]);
  };

  const handleUrls = () => {
    const urlList = urls.split('\n').map((u) => u.trim()).filter((u) => u && /^https?:\/\//.test(u));
    const items = urlList.map((u, i) => ({
      id: `url-${Date.now()}-${i}`,
      name: decodeURIComponent(u.split('/').pop() || `url-${i}`),
      size: 0,
      url: u,
      sourceFolder: '',
      status: 'queued',
      progress: 0,
      attempt: 0,
    }));
    setQueue((prev) => [...prev, ...items]);
    setUrls('');
  };

  /**
   * Upload a single file with timeout, progress estimation, and retry.
   * The SDK's UploadPublicFile is opaque (no byte-level progress), so we
   * estimate progress from elapsed time vs. a size-based expected duration.
   */
  const uploadWithRetry = async (item) => {
    const expectedSeconds = Math.max(8, item.size / (2 * 1024 * 1024)); // ~2MB/s baseline

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      updateItem(item.id, { status: 'uploading', progress: 0, elapsed: 0, rate: 0, attempt, error: '' });

      const startTime = performance.now();
      let progressTimer = null;

      // Size-based progress estimator (UploadPublicFile is opaque)
      progressTimer = setInterval(() => {
        const elapsed = (performance.now() - startTime) / 1000;
        const estProgress = Math.min(elapsed / expectedSeconds, 0.92);
        const rate = elapsed > 0 ? item.size / elapsed : 0;
        updateItem(item.id, { progress: estProgress, elapsed, rate });
      }, 500);

      try {
        // Timeout wrapper
        const uploadPromise = base44.integrations.Core.UploadPublicFile({ file: item.file });
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Upload timed out')), UPLOAD_TIMEOUT_MS),
        );
        const uploadRes = await Promise.race([uploadPromise, timeoutPromise]);
        clearInterval(progressTimer);

        const fileUrl = uploadRes.file_url;
        if (!fileUrl) throw new Error('Upload returned no file_url');

        updateItem(item.id, { status: 'cataloging', progress: 1 });
        return fileUrl;
      } catch (e) {
        clearInterval(progressTimer);
        if (attempt < MAX_RETRIES) {
          const backoff = Math.pow(2, attempt) * 1000; // 2s, 4s, 8s
          updateItem(item.id, { status: 'retrying', error: `${e.message} — retry ${attempt}/${MAX_RETRIES} in ${backoff / 1000}s` });
          await new Promise((r) => setTimeout(r, backoff));
        } else {
          throw e;
        }
      }
    }
  };

  const processItem = async (item) => {
    try {
      let fileUrl = item.url;
      let duration = 0;
      let dateCreated = '';
      let qualityTier = 'original';
      let originalSize = item.size;
      let uploadFile = item.file;
      let uploadName = item.name;

      if (item.file) {
        duration = await extractFileDuration(item.file);
        dateCreated = item.file.lastModified ? new Date(item.file.lastModified).toISOString().split('T')[0] : '';

        // Optional compression for large files
        if (compressToggle && shouldCompress(item.file)) {
          updateItem(item.id, { status: 'compressing', progress: 0, error: '' });
          try {
            const { blob, compressedName } = await compressMedia(item.file, (p) =>
              updateItem(item.id, { progress: p }),
            );
            uploadFile = new File([blob], compressedName, { type: blob.type });
            uploadName = compressedName;
            qualityTier = 'compressed_playback';
            updateItem(item.id, { size: uploadFile.size });
          } catch (ce) {
            // Compression failed — fall back to original
            updateItem(item.id, { status: 'queued', error: `Compression failed: ${ce.message} — uploading original` });
            uploadFile = item.file;
            uploadName = item.name;
            qualityTier = 'original';
          }
        }

        fileUrl = await uploadWithRetry({ ...item, file: uploadFile, size: uploadFile.size });
      } else if (item.url) {
        // URL re-host: fetch bytes server-side, upload to this site, catalog
        duration = await extractUrlDuration(item.url);
        updateItem(item.id, { status: 'rehosting', progress: 0.3 });
        const rehostRes = await base44.functions.invoke('psicatRadioRehostUrl', {
          url: item.url,
          title: uploadName.replace(/\.[^.]+$/, ''),
          media_type: mediaType,
          duration_seconds: Math.round(duration),
          source_folder: item.sourceFolder,
        });
        const rr = rehostRes?.data || rehostRes;
        if (rr?.error) throw new Error(rr.error);
        const track = rr.tracks?.[0];
        if (track?.error) throw new Error(track.error);

        updateItem(item.id, {
          status: 'done',
          progress: 1,
          v: track?.manifold_version,
          qualityTier: 'rehosted',
          size: track?.original_size_bytes || 0,
        });
        return;
      }

      updateItem(item.id, { status: 'cataloging' });
      const catRes = await base44.functions.invoke('psicatRadioUpload', {
        file_url: fileUrl,
        title: uploadName.replace(/\.[^.]+$/, ''),
        media_type: mediaType,
        duration_seconds: Math.round(duration),
        date_created: dateCreated,
        source_folder: item.sourceFolder,
        original_size_bytes: originalSize,
        quality_tier: qualityTier,
      });
      const r = catRes?.data || catRes;
      if (r?.error) throw new Error(r.error);

      updateItem(item.id, { status: 'done', progress: 1, v: r.tracks?.[0]?.manifold_version, qualityTier });
    } catch (e) {
      updateItem(item.id, { status: 'error', error: e.message });
    }
  };

  const startUpload = async () => {
    setUploading(true);
    const pending = queue.filter((q) => q.status === 'queued' || q.status === 'error' || q.status === 'retrying');

    // Simple concurrency pool: run CONCURRENCY items at a time
    let index = 0;
    const runNext = async () => {
      while (index < pending.length) {
        const item = pending[index++];
        await processItem(item);
      }
    };

    // Launch CONCURRENCY workers
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, pending.length) }, () => runNext()));

    setUploading(false);
    if (onUploaded) onUploaded();
  };

  const retryItem = (item) => processItem(item);
  const removeItem = (id) => setQueue((prev) => prev.filter((q) => q.id !== id));
  const clearCompleted = () => setQueue((prev) => prev.filter((q) => q.status !== 'done'));

  const doneCount = queue.filter((q) => q.status === 'done').length;
  const errorCount = queue.filter((q) => q.status === 'error').length;
  const queuedCount = queue.filter((q) => q.status === 'queued').length;
  const activeCount = queue.filter((q) => ['uploading', 'compressing', 'cataloging', 'rehosting', 'retrying'].includes(q.status)).length;
  const totalSize = queue.reduce((sum, q) => sum + (q.size || 0), 0);

  const fmtSize = (b) => {
    if (!b) return '--';
    if (b < 1024) return `${b}B`;
    if (b < 1048576) return `${(b / 1024).toFixed(0)}KB`;
    if (b < 1073741824) return `${(b / 1048576).toFixed(1)}MB`;
    return `${(b / 1073741824).toFixed(2)}GB`;
  };

  const fmtTime = (s) => {
    if (s < 1) return '<1s';
    if (s < 60) return `${s.toFixed(0)}s`;
    const m = Math.floor(s / 60);
    return `${m}m ${Math.floor(s % 60)}s`;
  };

  const fmtRate = (bps) => {
    if (!bps) return '--';
    if (bps < 1048576) return `${(bps / 1024).toFixed(0)}KB/s`;
    return `${(bps / 1048576).toFixed(1)}MB/s`;
  };

  return (
    <div className="mb-3 p-2.5 border border-[#FF9F00]/30 bg-[#FF9F00]/5 clip-corner">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[9px] font-bold text-[#FF9F00] uppercase tracking-wider flex items-center gap-1.5">
          <Upload size={11} /> Upload {mediaType === 'video' ? 'Video' : 'Audio'} Archive
        </span>
        <button onClick={onClose} className="text-[#484f58] hover:text-[#e6edf3] p-1"><X size={13} /></button>
      </div>

      <DropZone
        mediaType={mediaType}
        onFiles={(files, pathMap) => handleFiles(files, pathMap)}
        onPick={() => fileInputRef.current?.click()}
        dirSupported={dirSupported}
        onFolderPick={() => folderInputRef.current?.click()}
      />

      {/* Compression toggle */}
      <button
        onClick={() => setCompressToggle((v) => !v)}
        className={`w-full flex items-center gap-2 px-2 py-1.5 mt-2 mb-2 text-[8px] clip-corner border transition-colors touch-manipulation ${
          compressToggle
            ? 'border-[#bc8cff]/40 bg-[#bc8cff]/10 text-[#bc8cff]'
            : 'border-[#30363d] text-[#484f58]'
        }`}
      >
        <Zap size={10} className={compressToggle ? 'text-[#bc8cff]' : 'text-[#484f58]'} />
        <span className="font-bold uppercase tracking-wider">Compress for playback</span>
        <span className="ml-auto text-[7px] text-[#484f58]">
          {compressToggle ? 'ON · audio→128k opus · video→720p vp8' : 'OFF · upload originals'}
        </span>
      </button>

      {/* URL paste toggle */}
      <button
        onClick={() => setShowUrls((v) => !v)}
        className="w-full flex items-center gap-1.5 px-2 py-1.5 mb-2 text-[8px] font-bold clip-corner border border-[#30363d] text-[#484f58] hover:text-[#00f5ff] hover:border-[#00f5ff]/30 transition-colors touch-manipulation"
      >
        <Link2 size={10} /> {showUrls ? 'Hide URL paste' : 'Paste remote URLs instead'}
      </button>
      {showUrls && (
        <div>
          <textarea
            value={urls}
            onChange={(e) => setUrls(e.target.value)}
            placeholder={'Paste remote URLs, one per line\nhttps://example.com/track1.mp3\nhttps://example.com/track2.mp3'}
            className="w-full bg-[#0a0d11] border border-[#00f5ff]/20 text-[10px] text-[#e6edf3] p-2 clip-corner focus:outline-none focus:border-[#00f5ff]/40 font-mono placeholder:text-[#484f58] resize-y"
            rows={4}
          />
          <button onClick={handleUrls} disabled={!urls.trim()} className="mt-1 px-3 py-1.5 border border-[#00f5ff]/30 bg-[#00f5ff]/10 text-[#00f5ff] text-[9px] font-bold clip-corner hover:bg-[#00f5ff]/20 disabled:opacity-50 touch-manipulation">
            Add URLs to Queue
          </button>
        </div>
      )}

      <input ref={fileInputRef} type="file" multiple accept={mediaType === 'video' ? 'video/*' : 'audio/*'} onChange={(e) => handleFiles(e.target.files)} className="hidden" />
      <input ref={setFolderAttrs} type="file" multiple onChange={(e) => handleFiles(e.target.files)} className="hidden" />

      {queue.length > 0 && (
        <div className="mt-3 pt-2 border-t border-[#30363d]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[8px] text-[#484f58] uppercase">Queue: {queue.length} items · {fmtSize(totalSize)}</span>
            <div className="flex gap-1">
              <button onClick={startUpload} disabled={uploading || queuedCount === 0} className="flex items-center gap-1 px-2.5 py-1 border border-[#FF9F00]/40 bg-[#FF9F00]/15 text-[#FF9F00] text-[8px] font-bold clip-corner hover:bg-[#FF9F00]/25 disabled:opacity-50 touch-manipulation">
                {uploading ? <Loader2 size={10} className="animate-spin" /> : <Play size={10} />} {uploading ? `Uploading (${activeCount} active)` : `Start (${queuedCount})`}
              </button>
              {doneCount > 0 && <button onClick={clearCompleted} className="px-2 py-1 text-[8px] text-[#484f58] hover:text-[#e6edf3] border border-[#30363d] clip-corner">Clear Done</button>}
            </div>
          </div>
          <div className="flex gap-2 text-[8px] mb-2">
            <span className="text-[#3fb950]">{doneCount} done</span>
            <span className="text-[#f85149]">{errorCount} errors</span>
            <span className="text-[#00f5ff]">{activeCount} active</span>
            <span className="text-[#484f58]">{queuedCount} queued</span>
          </div>
          <div className="max-h-[220px] overflow-y-auto space-y-1">
            {queue.map((item) => (
              <div key={item.id} className="p-1.5 border border-[#30363d] clip-corner text-[9px]">
                <div className="flex items-center gap-2">
                  {item.status === 'queued' && <span className="text-[#484f58] shrink-0">●</span>}
                  {item.status === 'uploading' && <Loader2 size={10} className="animate-spin text-[#00f5ff] shrink-0" />}
                  {item.status === 'compressing' && <Zap size={10} className="text-[#bc8cff] shrink-0 animate-pulse" />}
                  {item.status === 'cataloging' && <Loader2 size={10} className="animate-spin text-[#bc8cff] shrink-0" />}
                  {item.status === 'rehosting' && <Loader2 size={10} className="animate-spin text-[#4dd0e1] shrink-0" />}
                  {item.status === 'retrying' && <Loader2 size={10} className="animate-spin text-[#fbbf24] shrink-0" />}
                  {item.status === 'done' && <CheckCircle size={10} className="text-[#3fb950] shrink-0" />}
                  {item.status === 'error' && <AlertCircle size={10} className="text-[#f85149] shrink-0" />}
                  <div className="flex-1 min-w-0">
                    <div className="text-[#8b949e] truncate">{item.name}</div>
                    {item.sourceFolder && <div className="text-[7px] text-[#484f58] truncate">📁 {item.sourceFolder}</div>}
                  </div>
                  {item.size > 0 && <span className="text-[7px] text-[#484f58] shrink-0">{fmtSize(item.size)}</span>}
                  {item.qualityTier === 'compressed_playback' && item.status === 'done' && (
                    <span className="text-[7px] text-[#bc8cff] shrink-0 border border-[#bc8cff]/30 px-1 clip-corner">COMPRESSED</span>
                  )}
                  {item.v && <span className="text-[7px] text-[#bc8cff] shrink-0">{item.v}</span>}
                  {item.status === 'error' && <button onClick={() => retryItem(item)} className="text-[7px] text-[#FF9F00] hover:underline shrink-0">Retry</button>}
                  {item.status === 'queued' && <button onClick={() => removeItem(item.id)} className="text-[#484f58] hover:text-[#ff3b30] shrink-0"><X size={10} /></button>}
                </div>

                {/* Progress bar for active items */}
                {(item.status === 'uploading' || item.status === 'compressing') && item.progress > 0 && (
                  <div className="mt-1.5">
                    <div className="h-1 bg-[#0a0d11] clip-corner overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${item.status === 'compressing' ? 'bg-[#bc8cff]' : 'bg-[#00f5ff]'}`}
                        style={{ width: `${Math.round(item.progress * 100)}%` }}
                      />
                    </div>
                    <div className="flex items-center gap-2 mt-0.5 text-[7px] text-[#484f58]">
                      <span className="flex items-center gap-0.5">
                        {item.status === 'compressing' ? <Zap size={8} /> : <Gauge size={8} />}
                        {Math.round(item.progress * 100)}%
                      </span>
                      {item.elapsed > 0 && (
                        <span className="flex items-center gap-0.5">
                          <Clock size={8} /> {fmtTime(item.elapsed)}
                        </span>
                      )}
                      {item.rate > 0 && item.status === 'uploading' && (
                        <span>{fmtRate(item.rate)}</span>
                      )}
                    </div>
                  </div>
                )}

                {/* Error / retry messages */}
                {item.status === 'error' && item.error && (
                  <div className="text-[7px] text-[#f85149] truncate mt-0.5">{item.error}</div>
                )}
                {item.status === 'retrying' && item.error && (
                  <div className="text-[7px] text-[#fbbf24] truncate mt-0.5">{item.error}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}