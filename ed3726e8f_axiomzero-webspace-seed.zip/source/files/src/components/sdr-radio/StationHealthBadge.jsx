import { classifyStation } from '@/lib/sdr-radio/streamHealth';

/**
 * StationHealthBadge — compact health/codec indicator for station cards.
 *   green  = healthy native-playable
 *   amber  = proxy recommended (CORS/codec risk)
 *   grey   = dead / no stream
 *
 * Shows a colored dot + short label with a tooltip explaining the verdict.
 */
export default function StationHealthBadge({ station, size = 7, showLabel = true, className = '' }) {
  const verdict = classifyStation(station);
  const dot = (
    <span
      className="rounded-full shrink-0"
      style={{
        width: size,
        height: size,
        background: verdict.color,
        boxShadow: verdict.level === 'ok' ? `0 0 4px ${verdict.color}` : 'none',
      }}
    />
  );

  if (!showLabel) {
    return (
      <span className={`inline-flex items-center ${className}`} title={verdict.reason}>
        {dot}
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center gap-1 ${className}`}
      title={verdict.reason}
    >
      {dot}
      <span className="text-[7px] font-mono" style={{ color: verdict.color }}>{verdict.label}</span>
    </span>
  );
}