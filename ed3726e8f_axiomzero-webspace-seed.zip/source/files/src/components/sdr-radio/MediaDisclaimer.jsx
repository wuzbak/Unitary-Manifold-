import { AlertTriangle } from 'lucide-react';

/**
 * MediaDisclaimer — Gemini Notebook provenance notice for the PsiCat Radio
 * media archive. All audio/video in the library is unedited 1st-pass research
 * material with errors, omissions, overclaims, and confabulation — posted as
 * open and researchable.
 *
 * Variants:
 *   banner  — full-width notice for library tabs / player panels
 *   badge   — compact icon-only badge for track rows
 */
const DISCLAIMER_TEXT =
  'These audio and video files were created using Gemini Notebook to help think about and understand the work along the way. They are mostly accurate and aligned to the work via the date and version of the repository, but ALL are unedited 1st-pass works and contain errors, omissions, overclaims, and confabulation. They are posted here as open and researchable material.';

export function MediaDisclaimerBanner({ className = '' }) {
  return (
    <div className={`flex items-start gap-2 p-2 border border-[#f0883e]/30 bg-[#f0883e]/8 clip-corner ${className}`}>
      <AlertTriangle size={12} className="text-[#f0883e] shrink-0 mt-0.5" />
      <p className="text-[8px] text-[#d29922] leading-relaxed">{DISCLAIMER_TEXT}</p>
    </div>
  );
}

export function MediaDisclaimerBadge({ className = '' }) {
  return (
    <span
      title={DISCLAIMER_TEXT}
      className={`inline-flex items-center gap-0.5 shrink-0 px-1 py-0.5 border border-[#f0883e]/30 bg-[#f0883e]/10 text-[#f0883e] clip-corner ${className}`}
    >
      <AlertTriangle size={8} />
      <span className="text-[6px] font-bold uppercase tracking-wider">1st-Pass</span>
    </span>
  );
}

export { DISCLAIMER_TEXT };