import { useState } from 'react';
import { Download, Loader2, Check, AlertCircle } from 'lucide-react';

/**
 * TrackDownloadButton — per-track download with fetch-as-blob fallback.
 *
 * Tries to fetch the file as a blob (works for same-origin and CORS-enabled
 * URLs), creates a temporary object URL, and triggers a download with the
 * proper filename. Falls back to a direct anchor download if the fetch fails
 * (cross-origin without CORS — may open in a new tab instead).
 */
export default function TrackDownloadButton({ track, size = 11, className = '' }) {
  const [state, setState] = useState('idle'); // idle | downloading | done | error

  const getExt = (url) => {
    const match = (url || '').match(/\.([a-z0-9]+)(\?|$)/i);
    return match ? `.${match[1].toLowerCase()}` : '';
  };

  const handleDownload = async (e) => {
    e.stopPropagation();
    e.preventDefault();
    setState('downloading');
    const filename = track.title + getExt(track.file_url);

    try {
      const res = await fetch(track.file_url);
      if (!res.ok) throw new Error('Fetch failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setState('done');
      setTimeout(() => setState('idle'), 2500);
    } catch (err) {
      // Fallback: direct link with download attribute (may open in new tab cross-origin)
      const a = document.createElement('a');
      a.href = track.file_url;
      a.download = filename;
      a.target = '_blank';
      a.rel = 'noopener';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setState('done');
      setTimeout(() => setState('idle'), 2500);
    }
  };

  return (
    <button
      onClick={handleDownload}
      className={`transition-colors shrink-0 p-1 ${className}`}
      title={`Download ${track.title}`}
    >
      {state === 'downloading' ? (
        <Loader2 size={size} className="animate-spin text-[#00f5ff]" />
      ) : state === 'done' ? (
        <Check size={size} className="text-[#3fb950]" />
      ) : state === 'error' ? (
        <AlertCircle size={size} className="text-[#f85149]" />
      ) : (
        <Download size={size} className="text-[#484f58] hover:text-[#00f5ff]" />
      )}
    </button>
  );
}