import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePsiCatQueue } from './PsiCatQueueContext';
import {
  Disc3,
  Play,
  Pause,
  Loader2,
  SkipForward,
  SkipBack,
  Rewind,
  FastForward,
  Calendar,
  Layers,
  Volume2,
  Tag,
  Sparkles,
  RotateCw,
  MessageSquare,
} from 'lucide-react';
import { MediaDisclaimerBanner } from './MediaDisclaimer';
import TrackDownloadButton from './TrackDownloadButton';

/**
 * PsiCatRadioPlayer — fully autonomous, tier-aware DJ station.
 *
 * Uses the shared PsiCatQueueContext for queue state and audio playback.
 * The audio element lives in the PsiCatQueueProvider, so playback persists
 * across tab switches. The sticky PsiCatStickyPlayer bar mirrors the state.
 *
 * Features:
 *   - Tier-aware playlist with per-track DJ commentary
 *   - Per-track download buttons
 *   - Live interaction: request era/tier, ask about current track
 *   - "Organize Library" button (admin-only) triggers psicatRadioOrganize
 *   - Auto-advance through the intelligent queue (handled by context)
 */
export default function PsiCatRadioPlayer({
  onOpenLibrary,
  trackCount = 0,
  isAdmin = false,
  onAskPsiCat,
}) {
  const {
    queue: playlist,
    setQueue: setPlaylist,
    currentIndex,
    setCurrentIndex,
    isPlaying,
    setIsPlaying,
    currentTrack,
    volume,
    setVolume,
    togglePlay,
    skipNext,
    skipPrev,
    seek,
    skipBack15,
    skipForward15,
    currentTime,
    duration,
  } = usePsiCatQueue();

  const [commentary, setCommentary] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [totalDuration, setTotalDuration] = useState(0);
  const [tierTaxonomy, setTierTaxonomy] = useState([]);
  const [organizing, setOrganizing] = useState(false);
  const [organizeResult, setOrganizeResult] = useState(null);
  const [focusTier, setFocusTier] = useState('');

  const buildPlaylist = async (focus = '') => {
    setLoading(true);
    setError(null);
    setFocusTier(focus);
    try {
      const res = await base44.functions.invoke('psicatRadioBuildPlaylist', {
        focus_tier: focus || undefined,
      });
      const r = res?.data || res;
      if (r?.error) throw new Error(r.error);
      setPlaylist(r.playlist || []);
      setCommentary(r.commentary || '');
      setTotalDuration(r.total_duration || 0);
      setTierTaxonomy(r.tier_taxonomy || []);
      setCurrentIndex(0);
      if ((r.playlist || []).length > 0) {
        setIsPlaying(true);
      }
    } catch (e) {
      setError(e.message || 'Failed to build playlist');
    } finally {
      setLoading(false);
    }
  };

  // Organize library (admin-only)
  const organizeLibrary = async () => {
    setOrganizing(true);
    setOrganizeResult(null);
    try {
      const res = await base44.functions.invoke('psicatRadioOrganize', {});
      const r = res?.data || res;
      if (r?.error) throw new Error(r.error);
      setOrganizeResult(r);
      // Rebuild playlist after organizing
      if (r.tracks_organized > 0) {
        await buildPlaylist();
      }
    } catch (e) {
      setOrganizeResult({ error: e.message });
    } finally {
      setOrganizing(false);
    }
  };

  const fmtTime = (s) => {
    if (!s) return '--:--';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const fmtTotal = (s) => {
    if (!s) return '0 min';
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  };

  return (
    <div className="glass-panel clip-corner p-3 tactical-hud border-[#FF9F00]/30">
      {/* Header */}
      <div className="flex items-center gap-2 mb-2">
        <Disc3
          size={16}
          className={`text-[#FF9F00] ${isPlaying ? 'animate-spin' : ''}`}
          style={{ animationDuration: '3s' }}
        />
        <span className="text-[11px] font-bold text-[#FF9F00] tracking-wider">PSICAT RADIO</span>
        <span className="text-[8px] text-[#484f58]">Autonomous DJ</span>
        {isPlaying && <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] glow-pulse ml-auto" />}
        {isAdmin && (
          <button
            onClick={organizeLibrary}
            disabled={organizing}
            className="flex items-center gap-1 px-2 py-1 text-[8px] font-bold border border-[#bc8cff]/30 bg-[#bc8cff]/10 text-[#bc8cff] clip-corner hover:bg-[#bc8cff]/20 disabled:opacity-50 transition-colors touch-manipulation"
            title="PsiCat analyzes the library, proposes tiers, and removes duplicates"
          >
            {organizing ? <Loader2 size={10} className="animate-spin" /> : <Sparkles size={10} />}
            {organizing ? 'Organizing…' : 'Organize'}
          </button>
        )}
      </div>

      {/* Organize result */}
      {organizeResult && !organizeResult.error && (
        <div className="mb-2 p-2 border border-[#bc8cff]/30 bg-[#bc8cff]/5 clip-corner text-[9px] text-[#8b949e]">
          <div className="font-bold text-[#bc8cff] mb-1 flex items-center gap-1">
            <Sparkles size={10} /> PsiCat Library Analysis
          </div>
          <p className="leading-relaxed mb-1">{organizeResult.summary}</p>
          <div className="flex gap-3 text-[8px] text-[#484f58]">
            <span>{organizeResult.tracks_organized} tracks tiered</span>
            <span className="text-[#f85149]">{organizeResult.duplicates_removed} duplicates removed</span>
            <span>{organizeResult.total_tracks} total</span>
          </div>
          {organizeResult.tier_taxonomy?.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5">
              {organizeResult.tier_taxonomy.map((t, i) => (
                <span
                  key={i}
                  className="flex items-center gap-0.5 text-[7px] px-1.5 py-0.5 border border-[#FF9F00]/30 bg-[#FF9F00]/10 text-[#FF9F00] clip-corner"
                >
                  <Tag size={8} /> {t.tier} ({t.count})
                </span>
              ))}
            </div>
          )}
        </div>
      )}
      {organizeResult?.error && (
        <div className="mb-2 text-[9px] text-[#f85149] text-center py-1">
          Organize failed: {organizeResult.error}
        </div>
      )}

      {/* Gemini Notebook provenance disclaimer */}
      <MediaDisclaimerBanner className="mb-3" />

      {playlist.length === 0 && !loading && (
        <div className="text-center py-6">
          <Disc3 size={32} className="mx-auto mb-3 text-[#484f58]" />
          <p className="text-[10px] text-[#8b949e] mb-1">
            {trackCount === 0
              ? 'No audio tracks in the library yet.'
              : `${trackCount} audio tracks ready to broadcast.`}
          </p>
          <p className="text-[9px] text-[#484f58] mb-4">
            PsiCat will autonomously sequence the archive by tier and manifold-era alignment.
          </p>
          <button
            onClick={() => buildPlaylist()}
            disabled={trackCount === 0 || organizing}
            className="flex items-center gap-2 mx-auto px-4 py-2.5 border border-[#FF9F00]/40 bg-[#FF9F00]/10 text-[#FF9F00] text-[10px] font-bold clip-corner hover:bg-[#FF9F00]/20 transition-colors disabled:opacity-50 touch-manipulation"
          >
            <Disc3 size={13} /> Start PsiCat Radio
          </button>
          {trackCount === 0 && (
            <button
              onClick={onOpenLibrary}
              className="block mx-auto mt-3 text-[9px] text-[#4dd0e1] hover:underline"
            >
              Upload media to the library →
            </button>
          )}
        </div>
      )}

      {loading && (
        <div className="flex items-center justify-center gap-2 py-8 text-[10px] text-[#FF9F00]">
          <Loader2 size={14} className="animate-spin" />
          {focusTier ? `Building ${focusTier} tier broadcast…` : 'PsiCat is building the broadcast…'}
        </div>
      )}

      {error && <div className="text-[9px] text-[#f85149] text-center py-2">{error}</div>}

      {playlist.length > 0 && (
        <>
          {/* DJ Commentary */}
          {commentary && (
            <div className="mb-3 p-2 border-l-2 border-[#FF9F00]/40 bg-[#FF9F00]/5 text-[10px] text-[#8b949e] italic leading-relaxed">
              {commentary}
            </div>
          )}

          {/* Tier quick-filter chips */}
          {tierTaxonomy.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-2">
              <button
                onClick={() => buildPlaylist('')}
                className={`flex items-center gap-1 text-[8px] px-2 py-1 clip-corner border transition-colors touch-manipulation ${
                  !focusTier
                    ? 'border-[#FF9F00]/40 bg-[#FF9F00]/15 text-[#FF9F00]'
                    : 'border-[#30363d] text-[#484f58] hover:text-[#FF9F00]'
                }`}
              >
                <RotateCw size={9} /> All Tiers
              </button>
              {tierTaxonomy.map((t, i) => (
                <button
                  key={i}
                  onClick={() => buildPlaylist(t.tier)}
                  className={`flex items-center gap-1 text-[8px] px-2 py-1 clip-corner border transition-colors touch-manipulation ${
                    focusTier === t.tier
                      ? 'border-[#FF9F00]/40 bg-[#FF9F00]/15 text-[#FF9F00]'
                      : 'border-[#30363d] text-[#484f58] hover:text-[#FF9F00]'
                  }`}
                >
                  <Tag size={8} /> {t.tier} ({t.count})
                </button>
              ))}
            </div>
          )}

          {/* Now Playing */}
          {currentTrack && (
            <div className="mb-3 p-2.5 border border-[#FF9F00]/30 bg-[#0a0d11] clip-corner">
              {/* Track info */}
              <div className="flex items-center gap-2 mb-2">
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] font-bold text-[#e6edf3] truncate">{currentTrack.title}</div>
                  <div className="flex items-center gap-3 mt-0.5 text-[8px] text-[#484f58]">
                    {currentTrack.tier && (
                      <span className="flex items-center gap-1 text-[#FF9F00]">
                        <Tag size={9} /> {currentTrack.tier}
                      </span>
                    )}
                    {currentTrack.manifold_version && (
                      <span className="flex items-center gap-1">
                        <Layers size={9} className="text-[#bc8cff]" /> {currentTrack.manifold_version}
                      </span>
                    )}
                    {(currentTrack.date_created || currentTrack.proposed_date) && (
                      <span className="flex items-center gap-1">
                        <Calendar size={9} className="text-[#4dd0e1]" />{' '}
                        {currentTrack.proposed_date || currentTrack.date_created}
                      </span>
                    )}
                  </div>
                </div>
                <TrackDownloadButton track={currentTrack} size={14} />
              </div>

              {/* Seek bar / timeline */}
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-mono text-[#FF9F00] w-8 shrink-0 text-right">{fmtTime(currentTime)}</span>
                <div
                  className="flex-1 relative h-1.5 bg-[#30363d] cursor-pointer group"
                  onClick={(e) => {
                    if (!duration) return;
                    const rect = e.currentTarget.getBoundingClientRect();
                    const pct = (e.clientX - rect.left) / rect.width;
                    seek(Math.max(0, Math.min(duration, pct * duration)));
                  }}
                >
                  <div
                    className="absolute top-0 left-0 h-full bg-gradient-to-r from-[#FF9F00] to-[#ffb733]"
                    style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
                  />
                  <div
                    className="absolute top-1/2 -translate-y-1/2 w-2.5 h-2.5 bg-[#FF9F00] clip-corner opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ left: `calc(${duration > 0 ? (currentTime / duration) * 100 : 0}% - 5px)` }}
                  />
                </div>
                <span className="text-[8px] font-mono text-[#484f58] w-8 shrink-0">{fmtTime(duration || currentTrack.duration_seconds)}</span>
              </div>

              {/* Playback controls */}
              <div className="flex items-center gap-1">
                <button
                  onClick={skipPrev}
                  className="flex items-center justify-center w-8 h-8 text-[#484f58] hover:text-[#FF9F00] transition-colors shrink-0 touch-manipulation"
                  title="Previous track (or restart)"
                >
                  <SkipBack size={13} />
                </button>
                <button
                  onClick={skipBack15}
                  className="flex items-center justify-center w-8 h-8 text-[#484f58] hover:text-[#FF9F00] transition-colors shrink-0 touch-manipulation"
                  title="Skip back 15s"
                >
                  <Rewind size={13} />
                </button>
                <button
                  onClick={togglePlay}
                  className="flex items-center justify-center w-10 h-10 bg-[#FF9F00]/15 border border-[#FF9F00]/40 text-[#FF9F00] clip-corner hover:bg-[#FF9F00]/25 transition-colors shrink-0 touch-manipulation"
                >
                  {isPlaying ? <Pause size={16} /> : <Play size={16} />}
                </button>
                <button
                  onClick={skipForward15}
                  className="flex items-center justify-center w-8 h-8 text-[#484f58] hover:text-[#FF9F00] transition-colors shrink-0 touch-manipulation"
                  title="Skip forward 15s"
                >
                  <FastForward size={13} />
                </button>
                <button
                  onClick={skipNext}
                  className="flex items-center justify-center w-8 h-8 text-[#484f58] hover:text-[#FF9F00] transition-colors shrink-0 touch-manipulation"
                  title="Skip to next track"
                >
                  <SkipForward size={13} />
                </button>
                <div className="flex items-center gap-1.5 ml-2 flex-1">
                  <Volume2 size={11} className="text-[#484f58] shrink-0" />
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={volume}
                    onChange={(e) => setVolume(parseFloat(e.target.value))}
                    className="flex-1 accent-[#FF9F00]"
                  />
                  <span className="text-[8px] text-[#484f58] font-mono w-7 shrink-0">
                    {Math.round(volume * 100)}%
                  </span>
                </div>
              </div>

              {/* DJ note for current track */}
              {currentTrack.note && (
                <div className="mt-2 p-1.5 border-l-2 border-[#00f5ff]/30 bg-[#00f5ff]/5 text-[9px] text-[#8b949e] italic leading-relaxed">
                  <span className="text-[#00f5ff] font-bold not-italic">PsiCat: </span>
                  {currentTrack.note}
                </div>
              )}

              {/* Live interaction: Ask PsiCat about current track */}
              {onAskPsiCat && currentTrack && (
                <button
                  onClick={() => onAskPsiCat(currentTrack)}
                  className="mt-2 flex items-center gap-1 text-[8px] text-[#00f5ff] hover:underline"
                >
                  <MessageSquare size={9} /> Ask PsiCat about this track
                </button>
              )}
            </div>
          )}

          {/* Queue */}
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[8px] text-[#484f58] uppercase tracking-wider">Broadcast Queue</span>
            <span className="text-[8px] text-[#484f58]">
              {currentIndex + 1}/{playlist.length} · {fmtTotal(totalDuration)}
            </span>
          </div>
          <div className="max-h-[200px] overflow-y-auto space-y-0.5">
            {playlist.map((track, i) => (
              <div
                key={track.id || i}
                className={`flex items-center gap-2 p-1.5 clip-corner transition-colors ${
                  i === currentIndex
                    ? 'bg-[#FF9F00]/10 border border-[#FF9F00]/30'
                    : 'border border-transparent hover:bg-[#00f5ff]/5'
                }`}
              >
                <button
                  onClick={() => setCurrentIndex(i)}
                  className="flex items-center gap-2 flex-1 text-left min-w-0"
                >
                  <span className="text-[8px] font-mono text-[#484f58] shrink-0 w-5">{i + 1}</span>
                  <span
                    className={`text-[9px] truncate flex-1 ${i === currentIndex ? 'text-[#FF9F00] font-bold' : 'text-[#8b949e]'}`}
                  >
                    {track.title}
                  </span>
                  {track.tier && (
                    <span className="text-[7px] text-[#FF9F00] shrink-0 flex items-center gap-0.5">
                      <Tag size={7} /> {track.tier}
                    </span>
                  )}
                  <span className="text-[7px] text-[#bc8cff] shrink-0">{track.manifold_version}</span>
                  <span className="text-[7px] text-[#484f58] font-mono shrink-0">
                    {fmtTime(track.duration_seconds)}
                  </span>
                </button>
                <TrackDownloadButton track={track} size={10} />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}