import { Disc3, FileAudio, Zap, Video } from 'lucide-react';

/**
 * PsiCatRadioSubTabs — sub-tab navigation within the PsiCat Radio band.
 *
 * Three sub-tabs: Audio (full-length), Short Form Audio (clips/tests), Video.
 * Shows live track counts per tab.
 */
const SUB_TABS = [
  { id: 'audio', label: 'Audio', sub: 'Full-length', icon: Disc3, color: '#FF9F00' },
  { id: 'short_form_audio', label: 'Short Form', sub: 'Clips & tests', icon: Zap, color: '#bc8cff' },
  { id: 'video', label: 'Video', sub: 'Visual media', icon: Video, color: '#4dd0e1' },
];

export default function PsiCatRadioSubTabs({ activeTab, onChange, counts = {} }) {
  return (
    <div className="glass-panel clip-corner p-1.5 tactical-hud mb-3">
      <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
        {SUB_TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          const count = counts[tab.id] || 0;
          return (
            <button
              key={tab.id}
              onClick={() => onChange(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-2 clip-corner border transition-all shrink-0 touch-manipulation min-w-[88px] ${
                isActive
                  ? 'border-[var(--tab-color)] bg-[var(--tab-color)]/15'
                  : 'border-[#30363d] bg-[#0d1117] hover:border-[#00f5ff]/30'
              }`}
              style={{ '--tab-color': tab.color }}
            >
              <Icon size={14} style={{ color: isActive ? tab.color : '#484f58' }} />
              <div className="flex flex-col items-start leading-tight">
                <span
                  className="text-[10px] font-bold tracking-wider whitespace-nowrap"
                  style={{ color: isActive ? tab.color : '#8b949e' }}
                >
                  {tab.label}
                </span>
                <span className="text-[7px] text-[#484f58] whitespace-nowrap hidden sm:block">
                  {tab.sub} · {count}
                </span>
              </div>
              {isActive && (
                <span
                  className="w-1 h-1 rounded-full glow-pulse"
                  style={{ background: tab.color }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}