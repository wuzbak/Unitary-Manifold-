import { useState, useEffect } from 'react';
import { ExternalLink, AlertTriangle, RadioTower } from 'lucide-react';

/**
 * SdrReceiverEmbed — iframe embed for Web-SDR receivers (KiwiSDR, WebSDR, OpenWebRX).
 * Detects mixed-content blocking (HTTP receiver on HTTPS site) and shows a fallback.
 */
export default function SdrReceiverEmbed({ receiver }) {
  const [blocked, setBlocked] = useState(false);

  useEffect(() => {
    if (!receiver?.embed_url) return;
    setBlocked(false);
    // HTTP embed on HTTPS site = mixed-content block
    if (receiver.embed_url.startsWith('http://') && window.location.protocol === 'https:') {
      setBlocked(true);
    }
  }, [receiver?.embed_url]);

  if (!receiver) {
    return (
      <div className="glass-panel clip-corner p-8 tactical-hud flex flex-col items-center justify-center text-center min-h-[300px]">
        <RadioTower size={32} className="text-[#484f58] mb-3" />
        <p className="text-xs text-[#8b949e]">Select a Web-SDR receiver from the directory to connect.</p>
        <p className="text-[10px] text-[#484f58] mt-1">KiwiSDR, WebSDR, and OpenWebRX receivers across HF bands.</p>
      </div>
    );
  }

  return (
    <div className="glass-panel clip-corner tactical-hud overflow-hidden">
      <div className="flex items-center justify-between p-2.5 border-b border-[#00f5ff]/20 bg-[#0a0d11]">
        <div className="flex items-center gap-2 min-w-0">
          <RadioTower size={13} className="text-[#00f5ff] shrink-0" />
          <div className="min-w-0">
            <div className="text-[11px] font-bold text-[#e6edf3] truncate">{receiver.name}</div>
            <div className="text-[9px] text-[#484f58] truncate">{receiver.region} · {receiver.description}</div>
          </div>
        </div>
        <a
          href={receiver.embed_url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#484f58] hover:text-[#00f5ff] transition-colors shrink-0"
          title="Open receiver in new tab"
        >
          <ExternalLink size={14} />
        </a>
      </div>
      <div className="relative" style={{ height: '420px' }}>
        {blocked ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-[#0a0d11]">
            <AlertTriangle size={28} className="text-[#fbbf24] mb-3" />
            <p className="text-xs text-[#e6edf3] font-bold mb-1">Mixed-Content Blocked</p>
            <p className="text-[10px] text-[#8b949e] mb-4 max-w-sm leading-relaxed">
              This receiver uses HTTP, which can't be embedded on this HTTPS page. Open it directly in a new tab to tune in.
            </p>
            <a
              href={receiver.embed_url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-4 py-2 border border-[#00f5ff]/40 bg-[#00f5ff]/10 text-[#00f5ff] text-[10px] font-bold clip-corner hover:bg-[#00f5ff]/20 transition-colors"
            >
              <ExternalLink size={12} /> Open Receiver Externally
            </a>
          </div>
        ) : (
          <iframe
            src={receiver.embed_url}
            title={receiver.name}
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
          />
        )}
      </div>
    </div>
  );
}