import { useMemo } from 'react';
import { X, ExternalLink, Newspaper, ShieldCheck } from 'lucide-react';

/**
 * AllArticlesOverlay — full-screen modal listing every fetched headline from
 * the Reputable Press feed, grouped by outlet. Each row links to the source
 * article in a new tab. Triggered by clicking the "Reputable Press" header.
 *
 * Props:
 *   headlines — full array from trustedNewsFeed (not just the 30 sliced for marquee)
 *   onClose() — close the overlay
 */
const OUTLET_COLORS = {
  'BBC News': '#bb1919',
  'BBC Business': '#bb1919',
  'BBC Technology': '#bb1919',
  'Associated Press (AP)': '#0a6ebd',
  'The Guardian (US)': '#052962',
  'The Guardian (World)': '#052962',
  'Deutsche Welle': '#0a3b8c',
  'PBS NewsHour': '#003087',
  'ProPublica': '#a02c02',
  'The Economist': '#e3120b',
  'Christian Science Monitor': '#4a6da7',
  'NYT (Home)': '#121212',
  'NYT (World)': '#121212',
  'NYT (Business)': '#121212',
  'NYT (Technology)': '#121212',
  'NYT (Science)': '#121212',
};

const fmtTime = (iso) => {
  if (!iso) return '';
  const d = new Date(iso);
  const now = new Date();
  const diff = (now - d) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return d.toLocaleDateString();
};

export default function AllArticlesOverlay({ headlines, onClose }) {
  // Group headlines by outlet, preserving first-seen order
  const grouped = useMemo(() => {
    const map = new Map();
    for (const h of headlines) {
      if (!map.has(h.outlet)) map.set(h.outlet, []);
      map.get(h.outlet).push(h);
    }
    return Array.from(map.entries());
  }, [headlines]);

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm fade-in"
      onClick={onClose}
    >
      <div
        className="glass-strong clip-corner tactical-hud max-w-3xl w-full overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-[#4dd0e1]/20 bg-[#0a0d11]">
          <div className="flex items-center gap-2 min-w-0">
            <Newspaper size={14} className="text-[#4dd0e1] shrink-0" />
            <span className="text-[10px] font-bold text-[#4dd0e1] uppercase tracking-wider truncate">
              Reputable Press — All Articles
            </span>
            <span className="text-[8px] text-[#484f58] shrink-0">{headlines.length} total</span>
          </div>
          <button
            onClick={onClose}
            className="text-[#484f58] hover:text-[#e6edf3] transition-colors p-1 shrink-0"
            aria-label="Close"
          >
            <X size={16} />
          </button>
        </div>

        {/* Scrollable body — grouped by outlet */}
        <div className="max-h-[80vh] overflow-y-auto p-3 space-y-4">
          {grouped.length === 0 ? (
            <div className="text-center py-8 text-[10px] text-[#484f58]">
              No articles available.
            </div>
          ) : (
            grouped.map(([outlet, items]) => {
              const color = OUTLET_COLORS[outlet] || '#4dd0e1';
              return (
                <div key={outlet}>
                  {/* Outlet section header */}
                  <div className="flex items-center gap-2 mb-2 sticky top-0 bg-[#0a0d11]/95 backdrop-blur-sm py-1 z-10">
                    <span
                      className="px-2 py-0.5 text-[8px] font-bold clip-corner"
                      style={{
                        color,
                        border: `1px solid ${color}40`,
                        background: `${color}10`,
                      }}
                    >
                      {outlet}
                    </span>
                    <span className="text-[8px] text-[#484f58]">{items.length} article{items.length !== 1 ? 's' : ''}</span>
                    <div className="flex-1 h-px" style={{ background: `${color}20` }} />
                  </div>

                  {/* Article rows */}
                  <div className="space-y-1">
                    {items.map((h, i) => (
                      <a
                        key={i}
                        href={h.link || '#'}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-start gap-2 p-2 border border-transparent clip-corner hover:border-[#4dd0e1]/20 hover:bg-[#4dd0e1]/5 transition-colors group"
                      >
                        <div className="flex-1 min-w-0">
                          <div className="text-[10px] text-[#e6edf3] leading-snug group-hover:text-[#4dd0e1] transition-colors">
                            {h.title}
                          </div>
                          {h.published && (
                            <div className="text-[8px] text-[#484f58] mt-0.5">{fmtTime(h.published)}</div>
                          )}
                        </div>
                        <ExternalLink size={11} className="text-[#484f58] group-hover:text-[#4dd0e1] shrink-0 mt-0.5" />
                      </a>
                    ))}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center gap-1.5 px-4 py-2 border-t border-[#4dd0e1]/10 bg-[#080b0f]">
          <ShieldCheck size={10} className="text-[#3fb950] shrink-0" />
          <span className="text-[8px] text-[#484f58] truncate">
            Curated from empirically-rated outlets — click any headline to open the source in a new tab
          </span>
        </div>
      </div>
    </div>
  );
}