import { Zap, Loader2, RefreshCw } from 'lucide-react';

/**
 * ProxyPlayButton — shown when a station is flagged for proxy playback
 * (mixed-content HTTP stream, CORS failure, or unsupported codec). Offers
 * "Play via PsiCat Proxy" which routes the stream through the server-side
 * streamProxy relay (same-origin, no CORS/mixed-content restrictions).
 *
 * When the proxy is active, shows a "Return to native" option.
 *
 * Props:
 *   proxyRecommended — boolean (show the offer)
 *   usingProxy — boolean (currently proxying)
 *   onPlayProxy — () => void
 *   onPlayNative — () => void
 *   loading — boolean
 */
export default function ProxyPlayButton({ proxyRecommended, usingProxy, onPlayProxy, onPlayNative, loading }) {
  if (usingProxy) {
    return (
      <button
        onClick={onPlayNative}
        className="flex items-center gap-1 px-2 py-1 text-[8px] font-bold border border-[#bc8cff]/40 bg-[#bc8cff]/10 text-[#bc8cff] clip-corner hover:bg-[#bc8cff]/20 transition-colors touch-manipulation"
        title="Return to direct native playback"
      >
        <RefreshCw size={10} /> Native
      </button>
    );
  }

  if (!proxyRecommended) return null;

  return (
    <button
      onClick={onPlayProxy}
      disabled={loading}
      className="flex items-center gap-1 px-2 py-1 text-[8px] font-bold border border-[#fbbf24]/40 bg-[#fbbf24]/10 text-[#fbbf24] clip-corner hover:bg-[#fbbf24]/20 transition-colors disabled:opacity-50 touch-manipulation"
      title="Route through the PsiCat server-side relay (bypasses CORS / mixed-content)"
    >
      {loading ? <Loader2 size={10} className="animate-spin" /> : <Zap size={10} />}
      Play via Proxy
    </button>
  );
}