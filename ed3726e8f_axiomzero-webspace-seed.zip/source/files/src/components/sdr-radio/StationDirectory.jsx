import { useState, useMemo, useEffect } from 'react';
import { Search, Play, Pause, ExternalLink, Radio, Globe, RadioTower, Waves, MapPin, Star } from 'lucide-react';
import { resolveGeoQuery } from '@/lib/sdr-radio/waZipMap';
import StationHealthBadge from './StationHealthBadge';

/**
 * StationDirectory — unified station directory for WA FM, WA AM, Internet streams,
 * and Web-SDR receivers. Reads from the SdrStation entity via the sdrStationCatalog
 * backend function. Searchable, grouped by region.
 *
 * Props:
 *   stations — array of SdrStation records
 *   stationType — 'wa_fm' | 'wa_am' | 'internet_stream' | 'web_sdr'
 *   activeStationId — id of the currently playing station
 *   onPlayStation — callback(station) for direct-stream stations
 *   onConnectReceiver — callback(station) for web-SDR receivers
 *   activeReceiverId — id of the currently connected receiver
 */
const TYPE_CONFIG = {
  wa_fm: { icon: Radio, color: '#4dd0e1', label: 'FM Broadcast' },
  wa_am: { icon: Waves, color: '#3fb950', label: 'AM Broadcast' },
  fm: { icon: Radio, color: '#4dd0e1', label: 'FM Broadcast' },
  am: { icon: Waves, color: '#3fb950', label: 'AM Broadcast' },
  internet_stream: { icon: Globe, color: '#00f5ff', label: 'Internet Streams' },
  web_sdr: { icon: RadioTower, color: '#bc8cff', label: 'Web-SDR Receivers' },
};

export default function StationDirectory({
  stations = [],
  stationType,
  activeStationId,
  onPlayStation,
  onConnectReceiver,
  activeReceiverId,
  externalSearch,
  isFavorite = null,
  onToggleFavorite = null,
}) {
  const [search, setSearch] = useState('');

  // Sync external search (e.g. user zip code) into the search field
  useEffect(() => {
    if (externalSearch !== undefined && externalSearch !== null) setSearch(externalSearch);
  }, [externalSearch]);
  const config = TYPE_CONFIG[stationType] || TYPE_CONFIG.internet_stream;
  const Icon = config.icon;

  const geoRegion = useMemo(() => resolveGeoQuery(search), [search]);

  const filtered = useMemo(() => {
    if (!search.trim()) return stations;
    const q = search.toLowerCase();
    // If the query resolves to a geo region (zip/city), match against region
    if (geoRegion) {
      const regionQ = geoRegion.toLowerCase();
      return stations.filter(
        (s) =>
          s.region?.toLowerCase().includes(regionQ) ||
          s.name?.toLowerCase().includes(q) ||
          s.description?.toLowerCase().includes(q),
      );
    }
    return stations.filter(
      (s) =>
        s.name?.toLowerCase().includes(q) ||
        s.region?.toLowerCase().includes(q) ||
        s.description?.toLowerCase().includes(q) ||
        String(s.frequency_mhz || '').includes(q),
    );
  }, [stations, search, geoRegion]);

  // Group by region for WA stations
  const grouped = useMemo(() => {
    if (stationType === 'internet_stream' || stationType === 'web_sdr') {
      return { 'All': filtered };
    }
    return filtered.reduce((acc, s) => {
      const region = s.region || 'Unknown';
      if (!acc[region]) acc[region] = [];
      acc[region].push(s);
      return acc;
    }, {});
  }, [filtered, stationType]);

  return (
    <div className="glass-panel clip-corner p-2.5 tactical-hud">
      <div className="flex items-center gap-2 mb-2">
        <Icon size={13} style={{ color: config.color }} />
        <span className="text-[10px] font-bold tracking-wider" style={{ color: config.color }}>
          {config.label}
        </span>
        <span className="text-[9px] text-[#484f58] ml-auto">{filtered.length} stations</span>
      </div>

      <div className="relative mb-2">
        <Search size={11} className="absolute left-2 top-1/2 -translate-y-1/2 text-[#484f58]" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search name, city, zip, frequency…"
          className="w-full bg-[#0a0d11] border border-[#00f5ff]/20 text-[10px] text-[#e6edf3] pl-7 pr-2 py-1.5 clip-corner focus:outline-none focus:border-[#00f5ff]/40 font-mono placeholder:text-[#484f58]"
        />
        {geoRegion && (
          <div className="flex items-center gap-1 mt-1 text-[8px] text-[#4dd0e1]">
            <MapPin size={9} /> Geo-search: {geoRegion}
          </div>
        )}
      </div>

      <div className="max-h-[420px] overflow-y-auto space-y-3">
        {Object.entries(grouped).map(([region, regionStations]) => (
          <div key={region}>
            {stationType !== 'internet_stream' && stationType !== 'web_sdr' && (
              <div className="text-[9px] font-bold text-[#484f58] uppercase tracking-wider mb-1.5 border-b border-[#30363d] pb-1">
                {region}
              </div>
            )}
            <div className="space-y-1">
              {regionStations.map((station) => {
                const isWebSdr = station.station_type === 'web_sdr';
                const isActive = isWebSdr
                  ? activeReceiverId === station.id
                  : activeStationId === station.id;
                const hasStream = !!station.stream_url;
                return (
                  <button
                    key={station.id}
                    onClick={() => (isWebSdr ? onConnectReceiver(station) : hasStream ? onPlayStation(station) : null)}
                    disabled={!isWebSdr && !hasStream}
                    className={`w-full flex items-start gap-2 p-1.5 border clip-corner text-left transition-all touch-manipulation disabled:opacity-50 disabled:cursor-default ${
                      isActive
                        ? 'border-[#FF9F00]/50 bg-[#FF9F00]/10 neon-edge-amber'
                        : 'border-[#30363d] bg-[#0d1117] hover:border-[#00f5ff]/30 glow-hover'
                    }`}
                  >
                    <span className="text-base shrink-0 leading-none mt-0.5">
                      {isWebSdr ? '📡' : station.frequency_mhz ? '📻' : '🌐'}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1 mb-0.5">
                        {station.frequency_mhz > 0 && (
                          <span className="text-[9px] font-mono text-[#00f5ff] shrink-0">
                            {station.frequency_mhz}
                          </span>
                        )}
                        <span className={`text-[10px] font-bold truncate ${isActive ? 'text-[#FF9F00]' : 'text-[#e6edf3]'}`}>
                          {station.name}
                        </span>
                        <StationHealthBadge station={station} size={6} showLabel={false} className="shrink-0" />
                        {station.source === 'radio_browser_api' && (
                          <span className="text-[6px] text-[#bc8cff] border border-[#bc8cff]/30 px-0.5 clip-corner shrink-0" title="From Radio Browser API">API</span>
                        )}
                        {station.bitrate > 0 && (
                          <span className="text-[6px] text-[#4dd0e1] font-mono shrink-0">{station.bitrate}k</span>
                        )}
                        {isActive && (
                          <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] glow-pulse shrink-0" />
                        )}
                      </div>
                      <div className="text-[8px] text-[#8b949e] line-clamp-1 leading-tight">
                        {station.description}
                      </div>
                      {!hasStream && !isWebSdr && (
                        <div className="text-[7px] text-[#484f58] mt-0.5">No live stream — tune via FM/AM or SDR</div>
                      )}
                    </div>
                    {onToggleFavorite && !isWebSdr && hasStream && (
                      <span
                        role="button"
                        tabIndex={0}
                        onClick={(e) => { e.stopPropagation(); onToggleFavorite(station); }}
                        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); e.stopPropagation(); onToggleFavorite(station); } }}
                        className={`shrink-0 mt-0.5 p-0.5 transition-colors ${isFavorite && isFavorite(station.id || station.stream_url) ? 'text-[#FF9F00]' : 'text-[#484f58] hover:text-[#FF9F00]'}`}
                        title={isFavorite && isFavorite(station.id || station.stream_url) ? 'Remove favorite' : 'Add favorite'}
                      >
                        <Star size={10} fill={isFavorite && isFavorite(station.id || station.stream_url) ? '#FF9F00' : 'none'} />
                      </span>
                    )}
                    <span className="shrink-0 mt-0.5">
                      {isWebSdr ? (
                        isActive ? <Pause size={11} className="text-[#FF9F00]" /> : <Play size={11} className="text-[#484f58]" />
                      ) : hasStream ? (
                        isActive ? <Pause size={11} className="text-[#FF9F00]" /> : <Play size={11} className="text-[#484f58]" />
                      ) : (
                        <ExternalLink size={10} className="text-[#484f58]" />
                      )}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="text-[10px] text-[#484f58] text-center py-6">
            {stations.length === 0 ? 'Loading stations…' : 'No matches — try a different search.'}
          </div>
        )}
      </div>
    </div>
  );
}