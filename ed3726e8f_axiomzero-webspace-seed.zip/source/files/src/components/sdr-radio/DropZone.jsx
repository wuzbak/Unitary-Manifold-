import { useState, useRef, useCallback } from 'react';
import { UploadCloud, FolderOpen, Loader2, FileAudio, FileVideo } from 'lucide-react';

/**
 * DropZone — drag-and-drop file and folder uploader for the PsiCat Radio library.
 *
 * Supports dropping entire folders via the webkitGetAsEntry API, which allows
 * recursive traversal of directory structures. Also tappable for mobile file
 * selection (drag-drop is not available on touch devices).
 *
 * Props:
 *   mediaType    — 'audio' | 'video' (for file filtering)
 *   onFiles      — callback(files, pathMap) where pathMap is Map<File, string>
 *   onPick       — callback to trigger file picker click
 *   dirSupported — whether webkitdirectory is supported (for folder picker button)
 *   onFolderPick — callback to trigger folder picker click
 */
export default function DropZone({ mediaType, onFiles, onPick, dirSupported, onFolderPick }) {
  const [dragOver, setDragOver] = useState(false);
  const [traversing, setTraversing] = useState(false);
  const [fileCount, setFileCount] = useState(0);
  const [rejectedCount, setRejectedCount] = useState(0);
  const dragDepth = useRef(0);

  const isAudioExt = /\.(mp3|wav|ogg|oga|m4a|flac|aac|opus|wma)$/i;
  const isVideoExt = /\.(mp4|webm|mov|avi|mkv|m4v)$/i;

  const isAccepted = useCallback(
    (file) => {
      if (mediaType === 'video') {
        return file.type.startsWith('video/') || isVideoExt.test(file.name);
      }
      return file.type.startsWith('audio/') || isAudioExt.test(file.name);
    },
    [mediaType],
  );

  // Recursively traverse a FileSystemDirectoryEntry, collecting accepted files.
  // readEntries returns max ~100 entries at a time, so we loop until empty.
  const traverseDirectory = (dirEntry, path, collected, rejected) => {
    return new Promise((resolve) => {
      const reader = dirEntry.createReader();
      const readBatch = () => {
        reader.readEntries(async (entries) => {
          if (entries.length === 0) {
            resolve();
            return;
          }
          for (const entry of entries) {
            if (entry.isFile) {
              try {
                const file = await new Promise((res, rej) => entry.file(res, rej));
                if (isAccepted(file)) {
                  collected.push({ file, path });
                  setFileCount(collected.length);
                } else {
                  rejected.count++;
                  setRejectedCount(rejected.count);
                }
              } catch (e) {
                /* skip unreadable file */
              }
            } else if (entry.isDirectory) {
              await traverseDirectory(
                entry,
                path ? `${path}/${entry.name}` : entry.name,
                collected,
                rejected,
              );
            }
          }
          readBatch();
        }, () => resolve());
      };
      readBatch();
    });
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);
    dragDepth.current = 0;

    const items = e.dataTransfer.items;
    if (!items || items.length === 0) {
      const files = Array.from(e.dataTransfer.files || []).filter(isAccepted);
      if (files.length > 0) onFiles(files, new Map());
      return;
    }

    const hasEntryApi = typeof items[0].webkitGetAsEntry === 'function';

    if (hasEntryApi) {
      setTraversing(true);
      setFileCount(0);
      setRejectedCount(0);
      const collected = [];
      const rejected = { count: 0 };

      for (let i = 0; i < items.length; i++) {
        const entry = items[i].webkitGetAsEntry();
        if (!entry) continue;

        if (entry.isFile) {
          try {
            const file = await new Promise((res, rej) => entry.file(res, rej));
            if (isAccepted(file)) {
              collected.push({ file, path: '' });
              setFileCount(collected.length);
            } else {
              rejected.count++;
              setRejectedCount(rejected.count);
            }
          } catch (e) {
            /* skip */
          }
        } else if (entry.isDirectory) {
          await traverseDirectory(entry, entry.name, collected, rejected);
        }
      }

      setTraversing(false);
      if (collected.length > 0) {
        const pathMap = new Map();
        for (const { file, path } of collected) {
          pathMap.set(file, path);
        }
        onFiles(
          collected.map((c) => c.file),
          pathMap,
        );
      }
    } else {
      const files = Array.from(e.dataTransfer.files || []).filter(isAccepted);
      if (files.length > 0) onFiles(files, new Map());
    }
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    dragDepth.current++;
    setDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    dragDepth.current--;
    if (dragDepth.current <= 0) {
      setDragOver(false);
      dragDepth.current = 0;
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
  };

  return (
    <div
      onDrop={handleDrop}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onClick={onPick}
      role="button"
      tabIndex={0}
      className={`relative p-5 border-2 border-dashed clip-corner transition-all cursor-pointer touch-manipulation ${
        dragOver
          ? 'border-[#FF9F00] bg-[#FF9F00]/10 neon-edge-amber'
          : 'border-[#00f5ff]/30 bg-[#0a0d11] hover:border-[#00f5ff]/50 hover:bg-[#00f5ff]/5'
      }`}
    >
      {traversing ? (
        <div className="flex flex-col items-center gap-2 py-3">
          <Loader2 size={26} className="animate-spin text-[#FF9F00]" />
          <div className="text-[11px] font-bold text-[#FF9F00] tracking-wider">SCANNING FOLDERS…</div>
          <div className="text-[9px] text-[#8b949e]">
            {fileCount} {mediaType} file{fileCount === 1 ? '' : 's'} found
          </div>
          {rejectedCount > 0 && (
            <div className="text-[8px] text-[#484f58]">{rejectedCount} non-{mediaType} files skipped</div>
          )}
        </div>
      ) : (
        <div className="flex flex-col items-center gap-2 text-center">
          <div
            className={`p-3 clip-corner border transition-colors ${
              dragOver ? 'border-[#FF9F00]/40 bg-[#FF9F00]/10' : 'border-[#00f5ff]/20 bg-[#00f5ff]/5'
            }`}
          >
            <UploadCloud size={26} className={dragOver ? 'text-[#FF9F00]' : 'text-[#00f5ff]'} />
          </div>
          <div className="text-[11px] font-bold text-[#e6edf3]">
            {dragOver ? 'Drop to upload' : `Drop ${mediaType} files or folders here`}
          </div>
          <div className="text-[9px] text-[#484f58]">or click to browse · entire folders supported on desktop</div>
          {dirSupported && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onFolderPick();
              }}
              className="mt-1 flex items-center gap-1.5 px-3 py-1.5 border border-[#bc8cff]/30 bg-[#bc8cff]/10 text-[#bc8cff] text-[9px] font-bold clip-corner hover:bg-[#bc8cff]/20 transition-colors touch-manipulation"
            >
              <FolderOpen size={11} /> Pick a Folder
            </button>
          )}
          <div className="flex items-center gap-3 mt-1 text-[8px] text-[#484f58]">
            <span className="flex items-center gap-1">
              {mediaType === 'video' ? <FileVideo size={9} /> : <FileAudio size={9} />}{' '}
              {mediaType === 'video' ? 'Video files' : 'Audio files'}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}