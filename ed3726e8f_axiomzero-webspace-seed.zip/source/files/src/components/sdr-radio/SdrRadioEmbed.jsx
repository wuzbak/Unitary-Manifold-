/**
 * SdrRadioEmbed — Compact, embeddable version of the All-Band SDR Radio Console
 * for the GeoMonitor page. Includes the band selector, global location search,
 * and a link to the full /sdr-radio page.
 *
 * "Keep but upgrade" — replaces the old SdrRadioConsole component on GeoMonitor
 * with the new global-search-enabled version.
 */
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Radio, Search, Globe, MapPin, Loader2, ExternalLink, X } from 'lucide-react';
import SdrBandSelector from '@/components/sdr-radio/SdrBandSelector';

export default function SdrRadioEmbed() {
  const [activeBand, setActiveBand] = useState('wa_fm');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchedStations, setSearchedStations] = useState(null);
  const [searchedRegion, setSearchedRegion] = useState(null);
  const [showSearch, setShowSearch] = useState(false);

  const handleGlobalSearch = async (e) => {
    e?.preventDefault();
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    try {
      const res = await base44.functions.invoke('globalStationSearch', { query: searchQuery });
      const r = res?.data || res;
      if (r?.error) {
        alert(r.error);
      } else {
        setSearchedStations(r.groups || {});
        setSearchedRegion(r.resolved?.region || searchQuery);
      }
    } catch (e) {
      alert('Search failed: ' + (e.message || 'Unknown error'));
    } finally {
      setIsSearching(false);
    }
  };

  const clearSearch = () => {
    setSearchedStations(null);
    setSearchedRegion(null);
    setSearchQuery('');
  };

  const isWaBand = activeBand === 'wa_fm' || activeBand === 'wa_am';
  const isInternet = activeBand === 'internet';
  const showGlobalSearch = isWaBand || isInternet;

  const totalResults = searchedStations
    ? (searchedStations.fm?.length || 0) + (searchedStations.am?.length || 0) + (searchedStations.internet_stream?.length || 0)
    : 0;

  return (
    <div className="glass-strong clip-corner p-3 lg:p-4 mt-4 tactical-hud hud-scanline">
      {/* Header */}
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Radio size={16} className="text-[#00f5ff] shrink-0" />
          <span className="text-xs font-bold text-[#e6edf3] tracking-wider whitespace-nowrap">
            ALL-BAND SDR CONSOLE
          </span>
          <span className="text-[8px] text-[#484f58] hidden sm:inline">| Global Radio</span>
        </div>
        <Link
          to="/sdr-radio"
          className="flex items-center gap-1 px-2.5 py-1.5 text-[9px] font-bold border border-[#00f5ff]/40 bg-[#00f5ff]/10 text-[#00f5ff] clip-corner hover:bg-[#00f5ff]/20 transition-colors touch-manipulation shrink-0"
        >
          <ExternalLink size={10} /> Full Console
        </Link>
      </div>

      {/* Band selector */}
      <SdrBandSelector activeBand={activeBand} onChange={setActiveBand} />

      {/* Global search bar */}
      {showGlobalSearch && (
        <div className="mt-3">
          <form onSubmit={handleGlobalSearch} className="flex gap-1.5">
            <div className="relative flex-1">
              <Search size={11} className="absolute left-2 top-1/2 -translate-y-1/2 text-[#484f58]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search any city or zip worldwide…"
                className="w-full bg-[#0a0d11] border border-[#00f5ff]/20 text-[10px] text-[#e6edf3] pl-7 pr-2 py-1.5 clip-corner focus:outline-none focus:border-[#00f5ff]/40 font-mono placeholder:text-[#484f58]"
              />
            </div>
            <button
              type="submit"
              disabled={isSearching || !searchQuery.trim()}
              className="flex items-center gap-1 px-3 py-1.5 bg-[#00f5ff]/15 border border-[#00f5ff]/30 text-[#00f5ff] text-[10px] font-bold clip-corner hover:bg-[#00f5ff]/25 disabled:opacity-50 transition-colors touch-manipulation"
            >
              {isSearching ? <Loader2 size={11} className="animate-spin" /> : <Globe size={11} />}
              Search
            </button>
          </form>

          {/* Search results summary */}
          {searchedStations && (
            <div className="mt-2 flex items-center gap-2 text-[9px]">
              <MapPin size={10} className="text-[#4dd0e1]" />
              <span className="text-[#4dd0e1] font-bold">{searchedRegion}</span>
              <span className="text-[#484f58]">· {totalResults} stations found</span>
              <button onClick={clearSearch} className="ml-auto text-[#484f58] hover:text-[#ff6b6b] flex items-center gap-0.5">
                <X size={9} /> Clear
              </button>
            </div>
          )}

          {/* Quick result preview */}
          {searchedStations && totalResults > 0 && (
            <div className="mt-2 max-h-[200px] overflow-y-auto space-y-1">
              {[
                ...(searchedStations.fm || []).slice(0, 3),
                ...(searchedStations.am || []).slice(0, 2),
                ...(searchedStations.internet_stream || []).slice(0, 3),
              ].map((s, i) => (
                <div key={s.id || i} className="flex items-center gap-2 p-1.5 border border-[#30363d] bg-[#0d1117] clip-corner">
                  <span className="text-base shrink-0">
                    {s.station_type === 'internet_stream' ? '🌐' : s.frequency_mhz > 0 ? '📻' : '📡'}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="text-[10px] font-bold text-[#e6edf3] truncate">{s.name}</div>
                    <div className="text-[8px] text-[#8b949e] truncate">
                      {s.frequency_mhz > 0 ? `${s.frequency_mhz} MHz · ` : ''}
                      {s.description?.slice(0, 60)}
                    </div>
                  </div>
                  {s.stream_url && (
                    <a href={s.stream_url} target="_blank" rel="noopener noreferrer" className="text-[#00f5ff] hover:text-[#00f5ff]/80 shrink-0">
                      <ExternalLink size={11} />
                    </a>
                  )}
                </div>
              ))}
              <Link
                to="/sdr-radio"
                className="block text-center text-[9px] text-[#00f5ff] hover:underline py-1.5"
              >
                View all {totalResults} stations in full console →
              </Link>
            </div>
          )}
        </div>
      )}

      {/* Non-searchable band info */}
      {!showGlobalSearch && (
        <div className="mt-3 text-[10px] text-[#8b949e] leading-relaxed">
          {activeBand === 'psicat_radio' ? (
            <span>PsiCat Radio autonomous DJ — broadcasting from the manifold media archive. Open the full console for the complete library, tier-aware playlists, and upload tools.</span>
          ) : (
            <span>Web-SDR receivers for {activeBand.toUpperCase()} band. Open the full console for receiver embedding, tuning dial, and waterfall display.</span>
          )}
        </div>
      )}
    </div>
  );
}