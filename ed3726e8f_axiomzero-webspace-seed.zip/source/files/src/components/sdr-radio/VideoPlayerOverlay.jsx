import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  X,
  Rewind,
  FastForward,
  ListVideo,
} from 'lucide-react';

/**
 * VideoPlayerOverlay — large centered modal video player with full custom
 * controls and a horizontal "up next" queue strip.
 *
 * Props:
 *   tracks       — array of video PsiCatRadioTrack records (the full video library)
 *   currentTrackId — the track id to start playing (null = closed)
 *   onClose       — callback when the overlay is closed
 *
 * The video element is standalone (NOT routed through audioGraph per PRD).
 * Auto-advances to the next track on end. Clicking an "up next" card jumps to it.
 */
export default function VideoPlayerOverlay({ tracks, currentTrackId, onClose }) {
  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [muted, setMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const controlsTimeoutRef = useRef(null);

  const currentIndex = tracks.findIndex((t) => t.id === currentTrackId);
  const currentTrack = currentIndex >= 0 ? tracks[currentIndex] : null;

  const nextTracks = tracks.slice(currentIndex + 1, currentIndex + 6);

  const fmtTime = (s) => {
    if (!s || !Number.isFinite(s)) return '0:00';
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = Math.floor(s % 60);
    if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  // Load + play the current track
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !currentTrack?.file_url) return;
    video.src = currentTrack.file_url;
    video.volume = volume;
    video.muted = muted;
    video.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    setCurrentTime(0);
    setDuration(0);
  }, [currentTrackId]);

  // Time update + metadata listeners
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onTimeUpdate = () => setCurrentTime(video.currentTime || 0);
    const onLoadedMetadata = () => {
      setDuration(video.duration || 0);
      setCurrentTime(0);
    };
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onEnded = () => handleNext();

    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('loadedmetadata', onLoadedMetadata);
    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('ended', onEnded);

    return () => {
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('loadedmetadata', onLoadedMetadata);
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('ended', onEnded);
    };
  }, [currentTrackId, tracks.length]);

  // Fullscreen detection
  useEffect(() => {
    const onFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  // Auto-hide controls after 3s of inactivity during playback
  const resetControlsTimer = useCallback(() => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    if (isPlaying) {
      controlsTimeoutRef.current = setTimeout(() => setShowControls(false), 3000);
    }
  }, [isPlaying]);

  useEffect(() => {
    resetControlsTimer();
    return () => { if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current); };
  }, [isPlaying, currentTime]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().catch(() => {});
    } else {
      video.pause();
    }
  };

  const handleSeek = (e) => {
    const video = videoRef.current;
    if (!video || !duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    const newTime = Math.max(0, Math.min(duration, pct * duration));
    video.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const skipBack15 = () => {
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = Math.max(0, video.currentTime - 15);
    setCurrentTime(video.currentTime);
  };

  const skipForward15 = () => {
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = Math.min(duration || video.duration, video.currentTime + 15);
    setCurrentTime(video.currentTime);
  };

  const handleNext = useCallback(() => {
    if (currentIndex < tracks.length - 1) {
      // Trigger via parent by calling onClose and reopening — but we manage internally
      // We use a custom event to signal the parent to switch tracks
      const nextTrack = tracks[currentIndex + 1];
      if (nextTrack) {
        window.dispatchEvent(new CustomEvent('video-overlay-next', { detail: { trackId: nextTrack.id } }));
      }
    }
  }, [currentIndex, tracks]);

  const playTrack = (trackId) => {
    window.dispatchEvent(new CustomEvent('video-overlay-next', { detail: { trackId } }));
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setMuted(video.muted);
  };

  const handleVolumeChange = (e) => {
    const video = videoRef.current;
    if (!video) return;
    const v = parseFloat(e.target.value);
    video.volume = v;
    video.muted = v === 0;
    setVolume(v);
    setMuted(v === 0);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  if (!currentTrack) return null;

  const progressPct = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center bg-black/85 backdrop-blur-sm fade-in"
      onMouseMove={resetControlsTimer}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        ref={containerRef}
        className="relative w-[90vw] max-w-6xl glass-strong clip-corner border border-[#4dd0e1]/30 tactical-hud"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute -top-1 -right-1 z-30 flex items-center justify-center w-9 h-9 bg-[#0a0d11] border border-[#ff3b30]/40 text-[#ff3b30] clip-corner hover:bg-[#ff3b30]/20 transition-colors"
          title="Close video player"
        >
          <X size={16} />
        </button>

        {/* Video */}
        <div className="relative bg-black clip-corner overflow-hidden" style={{ maxHeight: '60vh' }}>
          <video
            ref={videoRef}
            className="w-full max-h-[60vh] mx-auto"
            style={{ aspectRatio: '16/9' }}
            playsInline
            onClick={togglePlay}
          />

          {/* Center play/pause overlay (when paused) */}
          {!isPlaying && (
            <button
              onClick={togglePlay}
              className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/20 transition-colors"
            >
              <div className="flex items-center justify-center w-16 h-16 bg-[#4dd0e1]/20 border-2 border-[#4dd0e1]/50 text-[#4dd0e1] clip-corner backdrop-blur-md">
                <Play size={28} className="ml-1" />
              </div>
            </button>
          )}

          {/* Track title overlay (top) */}
          <div
            className={`absolute top-0 left-0 right-0 p-3 bg-gradient-to-b from-black/80 to-transparent transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}
          >
            <div className="text-[11px] font-bold text-[#e6edf3] truncate">{currentTrack.title}</div>
            <div className="flex items-center gap-2 mt-0.5 text-[8px] text-[#8b949e]">
              {currentTrack.tier && <span className="text-[#FF9F00]">▸ {currentTrack.tier}</span>}
              {currentTrack.manifold_version && <span className="text-[#bc8cff]">{currentTrack.manifold_version}</span>}
              <span className="font-mono">{fmtTime(duration)}</span>
            </div>
          </div>
        </div>

        {/* Controls bar */}
        <div
          className={`px-3 py-2.5 border-t border-[#4dd0e1]/20 bg-[#0a0d11] transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}
        >
          {/* Seek bar */}
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[9px] font-mono text-[#4dd0e1] w-10 shrink-0 text-right">{fmtTime(currentTime)}</span>
            <div
              className="flex-1 relative h-1.5 bg-[#30363d] cursor-pointer group"
              onClick={handleSeek}
            >
              <div
                className="absolute top-0 left-0 h-full bg-gradient-to-r from-[#4dd0e1] to-[#00f5ff]"
                style={{ width: `${progressPct}%` }}
              />
              <div
                className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-[#00f5ff] clip-corner opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ left: `calc(${progressPct}% - 6px)` }}
              />
            </div>
            <span className="text-[9px] font-mono text-[#484f58] w-10 shrink-0">{fmtTime(duration)}</span>
          </div>

          {/* Button row */}
          <div className="flex items-center gap-1.5">
            {/* Skip back 15s */}
            <button
              onClick={skipBack15}
              className="flex items-center justify-center w-8 h-8 text-[#8b949e] hover:text-[#4dd0e1] transition-colors touch-manipulation"
              title="Skip back 15s"
            >
              <Rewind size={15} />
            </button>

            {/* Previous track */}
            <button
              onClick={() => currentIndex > 0 && playTrack(tracks[currentIndex - 1].id)}
              disabled={currentIndex === 0}
              className="flex items-center justify-center w-8 h-8 text-[#8b949e] hover:text-[#4dd0e1] transition-colors disabled:opacity-30 disabled:hover:text-[#8b949e] touch-manipulation"
              title="Previous track"
            >
              <SkipBack size={15} />
            </button>

            {/* Play/Pause */}
            <button
              onClick={togglePlay}
              className="flex items-center justify-center w-10 h-10 bg-[#4dd0e1]/15 border border-[#4dd0e1]/40 text-[#4dd0e1] clip-corner hover:bg-[#4dd0e1]/25 transition-colors touch-manipulation"
            >
              {isPlaying ? <Pause size={18} /> : <Play size={18} className="ml-0.5" />}
            </button>

            {/* Next track */}
            <button
              onClick={handleNext}
              disabled={currentIndex >= tracks.length - 1}
              className="flex items-center justify-center w-8 h-8 text-[#8b949e] hover:text-[#4dd0e1] transition-colors disabled:opacity-30 disabled:hover:text-[#8b949e] touch-manipulation"
              title="Next track"
            >
              <SkipForward size={15} />
            </button>

            {/* Skip forward 15s */}
            <button
              onClick={skipForward15}
              className="flex items-center justify-center w-8 h-8 text-[#8b949e] hover:text-[#4dd0e1] transition-colors touch-manipulation"
              title="Skip forward 15s"
            >
              <FastForward size={15} />
            </button>

            {/* Volume */}
            <div className="flex items-center gap-1 ml-1">
              <button
                onClick={toggleMute}
                className="flex items-center justify-center w-8 h-8 text-[#8b949e] hover:text-[#4dd0e1] transition-colors touch-manipulation"
                title={muted ? 'Unmute' : 'Mute'}
              >
                {muted || volume === 0 ? <VolumeX size={15} /> : <Volume2 size={15} />}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={muted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-16 accent-[#4dd0e1]"
              />
            </div>

            {/* Queue position */}
            <span className="text-[9px] font-mono text-[#484f58] ml-1">
              {currentIndex + 1} / {tracks.length}
            </span>

            {/* Fullscreen */}
            <button
              onClick={toggleFullscreen}
              className="flex items-center justify-center w-8 h-8 text-[#8b949e] hover:text-[#4dd0e1] transition-colors ml-auto touch-manipulation"
              title={isFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
            >
              {isFullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
            </button>
          </div>
        </div>

        {/* Up Next queue strip */}
        {nextTracks.length > 0 && (
          <div className="px-3 py-2.5 border-t border-[#4dd0e1]/15 bg-[#080b0f]">
            <div className="flex items-center gap-1.5 mb-2">
              <ListVideo size={11} className="text-[#4dd0e1]" />
              <span className="text-[9px] font-bold text-[#4dd0e1] uppercase tracking-wider">Up Next</span>
              <span className="text-[8px] text-[#484f58]">{nextTracks.length} track{nextTracks.length !== 1 ? 's' : ''}</span>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'thin' }}>
              {nextTracks.map((track, i) => (
                <button
                  key={track.id || i}
                  onClick={() => playTrack(track.id)}
                  className="flex-shrink-0 w-44 p-2 border border-[#30363d] bg-[#0d1117] clip-corner hover:border-[#4dd0e1]/40 hover:bg-[#4dd0e1]/5 transition-colors text-left group"
                >
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-[8px] font-mono text-[#484f58]">{currentIndex + i + 2}</span>
                    <Play size={8} className="text-[#4dd0e1] opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="text-[9px] font-bold text-[#e6edf3] truncate group-hover:text-[#4dd0e1] transition-colors">
                    {track.title}
                  </div>
                  <div className="flex items-center gap-1.5 mt-0.5 text-[7px] text-[#484f58]">
                    {track.tier && <span className="text-[#FF9F00]">{track.tier}</span>}
                    {track.manifold_version && <span className="text-[#bc8cff]">{track.manifold_version}</span>}
                    <span className="font-mono ml-auto">{fmtTime(track.duration_seconds)}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}