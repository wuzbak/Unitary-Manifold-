import { useState, useEffect } from 'react';
import { audioGraph, BAND_FREQS } from '@/lib/sdr-radio/audioGraph';
import { EQ_PRESETS, BAND_LABELS } from '@/lib/sdr-radio/eqPresets';
import { Sliders, Power, RotateCcw, ChevronDown, ChevronUp } from 'lucide-react';

/**
 * EqRack — graphic + parametric hybrid EQ.
 * 10-band graphic mode with vertical sliders; parametric mode adds per-band
 * frequency and Q controls. Presets apply instantly. Bypass toggle A/B compares.
 */
export default function EqRack() {
  const [open, setOpen] = useState(true);
  const [mode, setMode] = useState('graphic');
  const [bypass, setBypass] = useState(false);
  const [gains, setGains] = useState(new Array(10).fill(0));
  const [params, setParams] = useState(BAND_FREQS.map((f) => ({ frequency: f, Q: 1, gain: 0 })));
  const [activePreset, setActivePreset] = useState('flat');

  useEffect(() => {
    if (mode === 'graphic') gains.forEach((g, i) => audioGraph.setBandGain(i, g));
    else params.forEach((p, i) => audioGraph.setBandParam(i, p));
  }, [gains, params, mode]);

  useEffect(() => { audioGraph.setBypass(bypass); }, [bypass]);

  const applyPreset = (key) => {
    setActivePreset(key);
    const preset = EQ_PRESETS[key];
    if (mode === 'graphic') setGains([...preset.gains]);
    else setParams(preset.gains.map((g, i) => ({ frequency: BAND_FREQS[i], Q: 1, gain: g })));
  };

  const reset = () => {
    setGains(new Array(10).fill(0));
    setParams(BAND_FREQS.map((f) => ({ frequency: f, Q: 1, gain: 0 })));
    setActivePreset('flat');
  };

  const setGain = (i, val) => {
    setActivePreset('custom');
    if (mode === 'graphic') setGains((p) => { const n = [...p]; n[i] = val; return n; });
    else setParams((p) => { const n = [...p]; n[i] = { ...n[i], gain: val }; return n; });
  };

  const setParam = (i, field, val) => {
    setActivePreset('custom');
    setParams((p) => { const n = [...p]; n[i] = { ...n[i], [field]: val }; return n; });
  };

  const currentGains = mode === 'graphic' ? gains : params.map((p) => p.gain);

  return (
    <div className="glass-panel clip-corner tactical-hud overflow-hidden">
      <div className="flex items-center gap-2 p-2.5 border-b border-[#FF9F00]/15">
        <Sliders size={13} className="text-[#FF9F00]" />
        <span className="text-[10px] font-bold text-[#FF9F00] uppercase tracking-wider">EQ Rack</span>
        <div className="flex gap-1 ml-1">
          <button onClick={() => setMode('graphic')} className={`px-2 py-1 text-[8px] font-bold clip-corner touch-manipulation ${mode === 'graphic' ? 'bg-[#FF9F00]/15 text-[#FF9F00] border border-[#FF9F00]/40' : 'text-[#484f58] border border-[#30363d]'}`}>Graphic</button>
          <button onClick={() => setMode('parametric')} className={`px-2 py-1 text-[8px] font-bold clip-corner touch-manipulation ${mode === 'parametric' ? 'bg-[#FF9F00]/15 text-[#FF9F00] border border-[#FF9F00]/40' : 'text-[#484f58] border border-[#30363d]'}`}>Parametric</button>
        </div>
        <button onClick={() => setBypass(!bypass)} className={`flex items-center gap-1 px-2 py-1 text-[8px] font-bold clip-corner touch-manipulation ml-auto ${bypass ? 'bg-[#f85149]/15 text-[#f85149] border border-[#f85149]/40' : 'bg-[#3fb950]/10 text-[#3fb950] border border-[#3fb950]/30'}`}>
          <Power size={10} /> {bypass ? 'Bypassed' : 'Active'}
        </button>
        <button onClick={reset} className="flex items-center gap-1 px-2 py-1 text-[8px] text-[#484f58] hover:text-[#e6edf3] border border-[#30363d] clip-corner touch-manipulation">
          <RotateCcw size={10} /> Reset
        </button>
        <button onClick={() => setOpen(!open)} className="text-[#484f58] hover:text-[#e6edf3] p-1">
          {open ? <ChevronDown size={14} /> : <ChevronUp size={14} />}
        </button>
      </div>

      {open && (
        <div className="p-3">
          <div className="flex items-center gap-1 mb-3 overflow-x-auto pb-1">
            <span className="text-[8px] text-[#484f58] uppercase shrink-0">Presets</span>
            {Object.entries(EQ_PRESETS).map(([key, p]) => (
              <button key={key} onClick={() => applyPreset(key)} className={`px-2 py-1 text-[8px] font-bold clip-corner shrink-0 transition-colors touch-manipulation ${activePreset === key ? 'bg-[#00f5ff]/15 text-[#00f5ff] border border-[#00f5ff]/40' : 'text-[#484f58] border border-[#30363d] hover:text-[#8b949e]'}`}>
                {p.label}
              </button>
            ))}
            {activePreset === 'custom' && <span className="px-2 py-1 text-[8px] text-[#bc8cff] border border-[#bc8cff]/30 clip-corner">Custom</span>}
          </div>

          <div className="flex items-end gap-1 lg:gap-2 overflow-x-auto pb-2">
            {BAND_LABELS.map((label, i) => (
              <div key={i} className="flex flex-col items-center gap-1 shrink-0" style={{ width: mode === 'parametric' ? '72px' : '38px' }}>
                <span className="text-[7px] text-[#00f5ff] font-mono">{currentGains[i] > 0 ? '+' : ''}{currentGains[i].toFixed(1)}dB</span>
                <input
                  type="range" min="-12" max="12" step="0.5"
                  value={currentGains[i]}
                  onChange={(e) => setGain(i, parseFloat(e.target.value))}
                  className="sdr-eq-slider"
                  style={{ height: '80px' }}
                />
                <span className="text-[7px] text-[#484f58] font-mono">{label}</span>
                {mode === 'parametric' && (
                  <div className="flex flex-col gap-0.5 w-full mt-0.5">
                    <div className="flex items-center gap-0.5">
                      <span className="text-[6px] text-[#bc8cff] w-3">F</span>
                      <input type="range" min="20" max="20000" step="10" value={params[i].frequency} onChange={(e) => setParam(i, 'frequency', parseFloat(e.target.value))} className="w-full accent-[#bc8cff]" style={{ height: '10px' }} />
                    </div>
                    <div className="flex items-center gap-0.5">
                      <span className="text-[6px] text-[#4dd0e1] w-3">Q</span>
                      <input type="range" min="0.1" max="10" step="0.1" value={params[i].Q} onChange={(e) => setParam(i, 'Q', parseFloat(e.target.value))} className="w-full accent-[#4dd0e1]" style={{ height: '10px' }} />
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}