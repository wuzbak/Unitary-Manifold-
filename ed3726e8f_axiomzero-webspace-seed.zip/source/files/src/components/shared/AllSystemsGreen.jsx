/**
 * AllSystemsGreen — unified "All Systems Green" health dashboard.
 * Pings every backend integration via systemHealthCheck and displays
 * a real-time status grid with green/amber/red indicators.
 *
 * Used in System Status → "All Systems" tab.
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { CheckCircle2, AlertTriangle, XCircle, RefreshCw, Activity, ShieldCheck, Database, Globe, Zap, KeyRound, Github } from 'lucide-react';

const STATUS_CONFIG = {
  green: { color: '#3fb950', bg: 'bg-[#3fb950]/10', border: 'border-[#3fb950]/40', icon: CheckCircle2, label: 'Operational' },
  amber: { color: '#FF9F00', bg: 'bg-[#FF9F00]/10', border: 'border-[#FF9F00]/40', icon: AlertTriangle, label: 'Warning' },
  red: { color: '#f85149', bg: 'bg-[#f85149]/10', border: 'border-[#f85149]/40', icon: XCircle, label: 'Down' },
};

const CATEGORY_ICONS = {
  'AI / LLM': Zap,
  'Investigative': KeyRound,
  'Space / Earth': Globe,
  'News / RSS': Activity,
  'Connector': Github,
  'Entities': Database,
};

export default function AllSystemsGreen({ embedded = false }) {
  const [health, setHealth] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastChecked, setLastChecked] = useState(null);

  const fetchHealth = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('systemHealthCheck', {});
      const data = res.data || res;
      if (data.error) setError(data.error);
      setHealth(data);
      setLastChecked(new Date());
    } catch (e) {
      setError(e.message || 'Health check failed');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchHealth();
    const interval = setInterval(fetchHealth, 5 * 60 * 1000); // auto-refresh every 5 min
    return () => clearInterval(interval);
  }, [fetchHealth]);

  if (loading && !health) {
    return (
      <div className="flex items-center justify-center py-16">
        <RefreshCw className="animate-spin text-[#4DD0E1]" size={24} />
        <span className="ml-3 text-xs text-[#8b949e] font-mono">Pinging all systems…</span>
      </div>
    );
  }

  if (error && !health) {
    return (
      <div className="glass-panel clip-corner p-6 text-center">
        <XCircle size={24} className="text-[#f85149] mx-auto mb-3" />
        <p className="text-xs text-[#f85149] font-mono mb-3">{error}</p>
        <button onClick={fetchHealth} className="px-4 py-2 bg-[#00f5ff]/10 border border-[#00f5ff]/40 text-[#00f5ff] text-xs font-bold clip-corner hover:bg-[#00f5ff]/20">
          Retry
        </button>
      </div>
    );
  }

  const { summary, categories, overall, timestamp } = health || {};
  const overallColor = overall === 'all-green' ? '#3fb950' : overall === 'issues' ? '#f85149' : '#FF9F00';
  const overallLabel = overall === 'all-green' ? 'ALL SYSTEMS GREEN' : overall === 'issues' ? 'SYSTEMS WITH ISSUES' : 'SYSTEMS WITH WARNINGS';

  return (
    <div className="space-y-4">
      {/* ── Overall Status Header ── */}
      <div className="glass-strong clip-corner p-5 tactical-hud">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <ShieldCheck size={28} style={{ color: overallColor }} className="glow-pulse" />
            <div>
              <h2 className="text-lg font-bold font-heading tracking-wider" style={{ color: overallColor }}>{overallLabel}</h2>
              <p className="text-[10px] text-[#8b949e] font-mono">
                {summary?.green || 0} green · {summary?.amber || 0} warnings · {summary?.red || 0} down · {summary?.total || 0} total
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {lastChecked && (
              <span className="text-[10px] text-[#484f58] font-mono">
                Last checked: {lastChecked.toLocaleTimeString()}
              </span>
            )}
            <button
              onClick={fetchHealth}
              disabled={loading}
              className="flex items-center gap-1.5 px-3 py-2 border border-[#00f5ff]/40 bg-[#00f5ff]/10 text-[#00f5ff] text-xs font-bold clip-corner hover:bg-[#00f5ff]/20 transition-colors disabled:opacity-50"
            >
              <RefreshCw size={12} className={loading ? 'animate-spin' : ''} />
              Refresh
            </button>
          </div>
        </div>

        {/* Summary bar */}
        <div className="flex h-2 clip-corner overflow-hidden">
          <div className="bg-[#3fb950]" style={{ width: `${((summary?.green || 0) / (summary?.total || 1)) * 100}%` }} />
          <div className="bg-[#FF9F00]" style={{ width: `${((summary?.amber || 0) / (summary?.total || 1)) * 100}%` }} />
          <div className="bg-[#f85149]" style={{ width: `${((summary?.red || 0) / (summary?.total || 1)) * 100}%` }} />
        </div>
      </div>

      {/* ── Category sections ── */}
      {categories &&
        Object.entries(categories).map(([catName, checks]) => {
          const CatIcon = CATEGORY_ICONS[catName] || Activity;
          const catGreen = checks.filter((c) => c.status === 'green').length;
          const catTotal = checks.length;
          const catColor = catGreen === catTotal ? '#3fb950' : catGreen === 0 ? '#f85149' : '#FF9F00';

          return (
            <div key={catName} className="glass-panel clip-corner p-4">
              {/* Category header */}
              <div className="flex items-center gap-2 mb-3 pb-2 border-b border-[#00f5ff]/10">
                <CatIcon size={14} style={{ color: catColor }} />
                <h3 className="text-xs font-bold uppercase tracking-wider" style={{ color: catColor }}>{catName}</h3>
                <span className="ml-auto text-[10px] text-[#484f58] font-mono">{catGreen}/{catTotal} operational</span>
              </div>

              {/* Integration grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                {checks.map((check, i) => {
                  const cfg = STATUS_CONFIG[check.status] || STATUS_CONFIG.amber;
                  const StatusIcon = cfg.icon;
                  return (
                    <div
                      key={i}
                      className={`flex items-center gap-2.5 p-2.5 border clip-corner ${cfg.bg} ${cfg.border} transition-colors`}
                    >
                      <StatusIcon size={14} style={{ color: cfg.color }} className="shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-[11px] font-bold text-[#e6edf3] truncate">{check.label}</div>
                        <div className="text-[9px] text-[#484f58] font-mono truncate">{check.detail}</div>
                      </div>
                      <span
                        className="text-[8px] px-1.5 py-0.5 clip-corner font-bold uppercase tracking-wider shrink-0"
                        style={{ color: cfg.color, background: `${cfg.color}15`, border: `1px solid ${cfg.color}30` }}
                      >
                        {check.status}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}

      {/* ── Footer note ── */}
      <div className="glass-panel clip-corner p-3">
        <p className="text-[10px] text-[#484f58] leading-relaxed">
          <strong className="text-[#8b949e]">Auto-refresh:</strong> Every 5 minutes ·{' '}
          <strong className="text-[#8b949e]">Secrets:</strong> Checked for presence (values never exposed) ·{' '}
          <strong className="text-[#8b949e]">Public endpoints:</strong> Probed via HTTP GET (8s timeout) ·{' '}
          <strong className="text-[#8b949e]">Entities:</strong> Queried for record count
        </p>
      </div>
    </div>
  );
}