/**
 * ErrorBoundary — top-level render-crash safety net.
 *
 * Catches uncaught render errors anywhere in the tree and shows a full-page
 * recovery card ("Something went wrong — Retry / Back to home") instead of a
 * white screen. Logs the error to the console for triage. Never re-throws.
 *
 * Place once near the root (main.jsx). Use <FeatureBoundary> for per-region
 * data-call failures; this is the last-resort net for true render crashes.
 */
import React from 'react';
import { AlertOctagon, RotateCw, Home } from 'lucide-react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error('[ErrorBoundary] render crash:', error, info);
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null });
  };

  handleHome = () => {
    this.setState({ hasError: false, error: null });
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="fixed inset-0 flex items-center justify-center bg-[#0B0F13] p-4">
          <div className="glass-strong clip-corner p-6 max-w-md w-full text-center">
            <div className="flex justify-center mb-3">
              <AlertOctagon size={28} className="text-[#f85149]" />
            </div>
            <p className="text-sm font-bold text-[#e6edf3] mb-1.5 font-heading">Something went wrong</p>
            <p className="text-[11px] text-[#8b949e] mb-4 leading-relaxed">
              An unexpected error occurred while rendering this page. Your data is safe.
              Try again, or return to the home screen.
            </p>
            {this.state.error?.message && (
              <p className="text-[9px] text-[#484f58] mb-4 font-mono break-all bg-[#0d1117] border border-[#30363d] p-2 clip-corner">
                {this.state.error.message}
              </p>
            )}
            <div className="flex gap-2 justify-center">
              <button onClick={this.handleRetry}
                className="flex items-center gap-1.5 px-4 py-2.5 bg-[#FF9F00] text-black text-xs font-bold clip-corner touch-manipulation hover:brightness-110">
                <RotateCw size={13} /> Retry
              </button>
              <button onClick={this.handleHome}
                className="flex items-center gap-1.5 px-4 py-2.5 border border-[#30363d] text-[#8b949e] text-xs font-bold clip-corner touch-manipulation hover:text-[#e6edf3]">
                <Home size={13} /> Home
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}