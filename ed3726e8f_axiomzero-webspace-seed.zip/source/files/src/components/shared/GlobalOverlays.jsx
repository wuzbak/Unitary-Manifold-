import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import SiteMapOverlay from '@/components/axiomzero/SiteMapOverlay';
import UserManualDeck from '@/components/axiomzero/UserManualDeck';
import MobileBottomTabBar from '@/components/shared/MobileBottomTabBar';

const AUTH_ROUTES = ['/login', '/register', '/forgot-password', '/reset-password'];

/**
 * GlobalOverlays — app-root mount for global overlays and the mobile nav shell.
 * Renders the Site Map and User Manual overlays (event-driven), plus the
 * persistent MobileBottomTabBar (mobile only). Rendered once in App.jsx so
 * every page gets the bottom tab bar without per-page mounting. Auth routes
 * (login/register/forgot/reset) get a clean chrome-free surface.
 */
export default function GlobalOverlays() {
  const [siteMapOpen, setSiteMapOpen] = useState(false);
  const [manualOpen, setManualOpen] = useState(false);
  const location = useLocation();

  const isAuthRoute = AUTH_ROUTES.some((r) => location.pathname.startsWith(r));

  useEffect(() => {
    const openMap = () => setSiteMapOpen(true);
    const openManual = () => setManualOpen(true);
    window.addEventListener('site-map-toggle', openMap);
    window.addEventListener('user-manual-toggle', openManual);
    return () => {
      window.removeEventListener('site-map-toggle', openMap);
      window.removeEventListener('user-manual-toggle', openManual);
    };
  }, []);

  return (
    <>
      {/* Persistent mobile bottom tab bar — hidden on auth routes */}
      {!isAuthRoute && <MobileBottomTabBar />}
      {siteMapOpen && <SiteMapOverlay onClose={() => setSiteMapOpen(false)} />}
      {manualOpen && <UserManualDeck onClose={() => setManualOpen(false)} />}
    </>
  );
}