import { Activity, FlaskConical, Eye } from 'lucide-react';

const TIERS = {
  live: { label: 'LIVE EXECUTION', color: '#3fb950', icon: Activity, desc: 'Real change made in this environment' },
  simulation: { label: 'FAITHFUL SIMULATION', color: '#FF9F00', icon: FlaskConical, desc: 'Demo/sandbox replaying repo logic' },
  repo_mirror: { label: 'REPO MIRROR', color: '#4dd0e1', icon: Eye, desc: 'Read-only display of repo-computed results' },
};

/**
 * FidelityBadge — visible label on every subsystem surface so the user
 * always knows the fidelity tier: LIVE (green), SIMULATION (amber), or
 * REPO MIRROR (ice-blue). Consistent with the tactical-HUD aesthetic.
 *
 * Props:
 *   tier — 'live' | 'simulation' | 'repo_mirror'
 *   size — 'sm' | 'md' (default sm)
 *   showIcon — boolean (default true)
 */
export default function FidelityBadge({ tier = 'repo_mirror', size = 'sm', showIcon = true, className = '' }) {
  const config = TIERS[tier] || TIERS.repo_mirror;
  const Icon = config.icon;
  const sizeClasses = size === 'md' ? 'text-[9px] px-2.5 py-1' : 'text-[7px] px-1.5 py-0.5';
  const iconSize = size === 'md' ? 11 : 9;

  return (
    <span
      className={`inline-flex items-center gap-1 font-bold tracking-wider clip-corner border ${sizeClasses} ${className}`}
      style={{
        color: config.color,
        borderColor: `${config.color}40`,
        backgroundColor: `${config.color}10`,
      }}
      title={config.desc}
    >
      {showIcon && <Icon size={iconSize} />}
      {config.label}
    </span>
  );
}

export { TIERS };