/**
 * ComputeLoader — deterministic "initializing engine" loading state.
 * Shown while a lazy-loaded scientific library (math.js, TF.js, etc.)
 * downloads and initializes. Matches the AxiomZero dark aesthetic.
 */
import { Loader2, Cpu } from 'lucide-react';

export default function ComputeLoader({ engine = 'compute engine', detail = '' }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4">
      <div className="flex items-center gap-2 text-[#00f5ff] mb-3">
        <Cpu size={16} className="animate-pulse" />
        <span className="text-xs font-mono font-bold tracking-wider uppercase">Initializing {engine}</span>
      </div>
      <Loader2 size={20} className="animate-spin text-[#4dd0e1] mb-2" />
      {detail && <p className="text-[10px] text-[#8b949e] font-mono">{detail}</p>}
      <p className="text-[9px] text-[#484f58] font-mono mt-1">Local compute · no API required</p>
    </div>
  );
}