/**
 * FeatureBoundary — per-feature graceful-degradation wrapper.
 *
 * Composes with useGracefulData: pass the hook's loading/unavailable/empty flags
 * and an onRetry, and FeatureBoundary renders the appropriate state (loading
 * skeleton, unavailable card, empty state, or the children) so a failed region
 * never blanks the page and never toasts a 500.
 *
 * Usage:
 *   const { data, loading, unavailable, retry } = useGracefulData(() => fetchFeed());
 *   <FeatureBoundary loading={loading} unavailable={unavailable} onRetry={retry} title="Live feed">
 *     <FeedView data={data} />
 *   </FeatureBoundary>
 */
import { Loader2, Inbox } from 'lucide-react';
import UnavailableCard from './UnavailableCard';

export default function FeatureBoundary({
  loading = false,
  unavailable = false,
  empty = false,
  onRetry,
  title = 'This feed',
  emptyLabel,
  minHeight = 'auto',
  children,
}) {
  if (loading) {
    return (
      <div className="flex items-center justify-center glass-panel clip-corner p-4" style={{ minHeight }}>
        <Loader2 size={16} className="text-[#4dd0e1] animate-spin" />
        <span className="text-[10px] text-[#8b949e] ml-2">Loading{title ? ` ${title.toLowerCase()}` : ''}…</span>
      </div>
    );
  }

  if (unavailable) {
    return (
      <UnavailableCard
        message={`${title} is temporarily unavailable`}
        onRetry={onRetry}
      />
    );
  }

  if (empty) {
    return (
      <div className="flex flex-col items-center justify-center glass-panel clip-corner p-4 text-center" style={{ minHeight }}>
        <Inbox size={18} className="text-[#484f58] mb-1.5" />
        <span className="text-[10px] text-[#484f58]">{emptyLabel || `No ${title.toLowerCase()} found`}</span>
      </div>
    );
  }

  return children;
}