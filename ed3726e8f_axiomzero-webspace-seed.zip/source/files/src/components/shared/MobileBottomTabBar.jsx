import { Link, useLocation } from 'react-router-dom';
import { Home, MessageCircle, FlaskConical, Map, Volume2, VolumeX, Radio, Play } from 'lucide-react';
import { useSomaFm, setVolume, toggleMute, handlePlayClick } from '@/lib/somaFmAudio';
import FidelitySlider from '@/components/shared/FidelitySlider';

/**
 * MobileBottomTabBar — persistent thumb-reachable bottom navigation (mobile only).
 * 4 destinations: Home, Merlin (opens chat), Labs, Site Map (opens overlay).
 * Glass-strong with a top cyan accent line. Active tab gets a cyan tint +
 * glow-pulse icon. Renders globally via GlobalOverlays. lg:hidden — desktop
 * is unaffected. The Merlin tab is the sole mobile Merlin entry point.
 *
 * When the SomaFmPlayer singleton is active (topology page only), an integrated
 * audio slider row renders UNDER the tab buttons — combining the soundscape
 * controls directly into the bottom bar.
 */
const TABS = [
  { key: 'home', to: '/', label: 'Home', icon: Home },
  { key: 'merlin', action: 'merlin', label: 'PsiCat', icon: MessageCircle },
  { key: 'labs', to: '/labs', label: 'Labs', icon: FlaskConical },
  { key: 'sitemap', action: 'sitemap', label: 'Map', icon: Map },
];

function MobileAudioRow() {
  const s = useSomaFm();
  if (!s.ready) return null; // only on topology page where SomaFmPlayer is mounted

  const statusLabel = s.error ? 'SIGNAL LOST' : s.loading ? 'BUFFERING' : 'LIVE';
  const statusColor = s.error ? '#FF9F00' : s.loading ? '#8b949e' : '#00ff88';
  const sliderColor = s.muted ? '#FF9F00' : '#00f5ff';

  return (
    <div className="flex items-center gap-2 px-3 py-1.5 border-t border-[#00f5ff]/20 bg-[#0a0a12]/90">
      <Radio size={13} className={s.error ? 'text-[#FF9F00] shrink-0' : 'text-[#00f5ff] shrink-0'} />
      <span className="text-[8px] uppercase tracking-wider text-[#00f5ff]/60 font-bold shrink-0">SOMAFM</span>
      <span className="text-[8px] tracking-wider font-bold shrink-0" style={{ color: statusColor }}>● {statusLabel}</span>
      {s.playBlocked && !s.error ? (
        <>
          <div className="flex-1" />
          <button onClick={handlePlayClick} className="merlin-pulse flex items-center gap-1 px-3 py-1.5 border border-[#FF9F00]/60 bg-[#FF9F00]/15 text-[#FF9F00] text-[9px] font-bold tracking-wider clip-corner min-h-[36px]">
            <Play size={11} /> TAP TO PLAY
          </button>
        </>
      ) : !s.error && (
        <>
          <button onClick={toggleMute} className={`shrink-0 transition-transform active:scale-110 min-w-[32px] min-h-[36px] flex items-center justify-center ${s.muted ? 'text-[#FF9F00]' : 'text-[#00f5ff]'}`} aria-label={s.muted ? 'Unmute SomaFM' : 'Mute SomaFM'}>
            {s.muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
          <div className="flex-1 min-w-[80px]">
            <FidelitySlider value={s.volume} onChange={setVolume} min={0} max={1} step={0.01} color={sliderColor} />
          </div>
        </>
      )}
    </div>
  );
}

export default function MobileBottomTabBar() {
  const location = useLocation();

  const isActive = (tab) => {
    if (tab.key === 'home') return location.pathname === '/';
    if (tab.to) return location.pathname === tab.to || location.pathname.startsWith(tab.to + '/');
    return false;
  };

  const handleAction = (tab) => {
    if (tab.action === 'merlin') window.dispatchEvent(new Event('merlin-toggle'));
    else if (tab.action === 'sitemap') window.dispatchEvent(new Event('site-map-toggle'));
  };

  return (
    <nav
      className="lg:hidden fixed bottom-0 left-0 right-0 z-[60] glass-strong border-t border-[#00f5ff]/25"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      {/* top accent line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#00f5ff]/40 to-transparent" />
      <div className="flex items-stretch max-w-md mx-auto">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const active = isActive(tab);
          const inner = (
            <span
              className={`flex flex-col items-center justify-center gap-0.5 py-1.5 min-h-[52px] w-full transition-colors ${
                active ? 'text-[#00f5ff] bg-[#00f5ff]/10' : 'text-[#8b949e] active:text-[#00f5ff]'
              }`}
            >
              <Icon size={20} className={active ? 'glow-pulse' : ''} />
              <span className="text-[9px] font-bold tracking-wider">{tab.label}</span>
            </span>
          );
          if (tab.to) {
            return (
              <Link key={tab.key} to={tab.to} className="flex-1 flex touch-manipulation" aria-label={tab.label}>
                {inner}
              </Link>
            );
          }
          return (
            <button key={tab.key} onClick={() => handleAction(tab)} className="flex-1 flex touch-manipulation" aria-label={tab.label}>
              {inner}
            </button>
          );
        })}
      </div>
      {/* Integrated SomaFM audio slider — under the tab buttons (topology page only) */}
      <MobileAudioRow />
    </nav>
  );
}