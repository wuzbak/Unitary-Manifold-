import { useLiveStatus } from '@/hooks/useLiveStatus';

/**
 * MobileStatusStrip — compact live-telemetry strip for the mobile top bar.
 * Shows repo-synced version, sprint, Lean4 theorems, pillars, and tests with a
 * glowing LIVE/OFFLINE badge so no mobile page looks static. Hidden on home
 * (home has its own telemetry in MobileDock). Uses the existing useLiveStatus
 * hook (GitHub-anchored via fetchRepoContext).
 */
export default function MobileStatusStrip() {
  const { status, live } = useLiveStatus();
  const lean4 = (status.lean4_theorems || 0).toLocaleString();
  const tests = (status.tests_passed || 0).toLocaleString();
  const pillars = status.pillars_total || 0;

  return (
    <div className="lg:hidden relative glass-panel border-t border-[#00f5ff]/10 overflow-hidden">
      {/* sliding accent line — uses merlin-pulse keyframe for a gentle glow sweep */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#00f5ff]/40 to-transparent glow-pulse" />
      <div className="flex items-center gap-1.5 px-3 h-7 text-[9px] font-mono overflow-hidden whitespace-nowrap">
        <span className={`flex items-center gap-1 px-1.5 py-0.5 font-bold shrink-0 ${live ? 'text-[#00ff88]' : 'text-[#FF9F00]'}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${live ? 'bg-[#00ff88]' : 'bg-[#FF9F00]'} glow-pulse`} />
          {live ? 'LIVE' : 'SYNC'}
        </span>
        <span className="text-[#00f5ff] font-bold shrink-0">{status.version}</span>
        <Dot />
        <span className="text-[#8b949e] shrink-0">{status.sprint}</span>
        <Dot />
        <span className="text-[#8b949e] shrink-0">{lean4} thm</span>
        <Dot />
        <span className="text-[#8b949e] shrink-0">{pillars} pil</span>
        <Dot />
        <span className="text-[#8b949e] shrink-0">{tests}✓</span>
        <span className="text-[#484f58] truncate ml-1">{live ? 'repo-synced' : 'static fallback'}</span>
      </div>
    </div>
  );
}

function Dot() {
  return <span className="text-[#30363d] shrink-0">·</span>;
}