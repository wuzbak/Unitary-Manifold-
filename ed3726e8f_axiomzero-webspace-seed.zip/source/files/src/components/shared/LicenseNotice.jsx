import { Link } from 'react-router-dom';
import { AlertTriangle } from 'lucide-react';

/**
 * LicenseNotice — compact global licensing + user-warning pill.
 * Fixed at bottom-center on every page. Links to the full
 * licensing & disclaimer section on the Repository page.
 * Non-intrusive: slim, muted, pointer-events only on the link itself.
 */
export default function LicenseNotice() {
  return (
    <div className="fixed bottom-0 left-1/2 -translate-x-1/2 z-40 pointer-events-none">
      <Link
        to="/corporate"
        className="pointer-events-auto flex items-center gap-1.5 px-3 py-1 glass-panel glow-hover clip-corner text-[9px] sm:text-[10px] text-[#8b949e] hover:text-[#00f5ff] transition-colors whitespace-nowrap"
        title="Integrated Licensing Policy · Dual License (DPC v1.0 + AGPL-3.0) · Zero Liability"
      >
        <AlertTriangle size={9} className="text-[#d29922] shrink-0" />
        <span>DPC v1.0 + AGPL-3.0 · Use at Your Own Risk · Zero Liability</span>
        <span className="text-[#00f5ff]/40">→</span>
      </Link>
    </div>
  );
}