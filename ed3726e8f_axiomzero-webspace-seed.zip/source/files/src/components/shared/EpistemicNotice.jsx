import { ShieldCheck } from 'lucide-react';

/**
 * EpistemicNotice — standardized epistemic honesty notice.
 * Usage: <EpistemicNotice type="adjacent" /> or <EpistemicNotice text="Custom text" />
 */
const TYPES = {
  adjacent: { color: '#3b8bff', label: '🔵 Adjacent Track', text: 'This is a speculative engineering application, not a hardgate physics claim. Outputs are analytical tools. All findings require human expert review.' },
  hardgate: { color: '#3fb950', label: '🟢 Hardgate', text: 'This is a core physics invariant, machine-verified in Lean4. The claim is mathematically proven within the framework; external empirical confirmation may be pending.' },
  architecture: { color: '#ff3b30', label: '🔴 Architecture Limit', text: 'This claim has an irreducible gap in the current 5D-EFT scope. The limit is acknowledged and documented in the canonical ledger.' },
  open_gap: { color: '#d29922', label: '🟡 Open Gap', text: 'This claim awaits external experimental data. The prediction is preregistered with explicit falsification conditions.' },
  governance: { color: '#a78bfa', label: '🟣 Governance', text: 'This is a governance and operational tool, not a physics claim. All outputs are advisory and require human decision-making.' },
};

export default function EpistemicNotice({ type = 'adjacent', text, label }) {
  const config = TYPES[type] || TYPES.adjacent;
  return (
    <div className="rounded-lg p-3 border" style={{ borderColor: `${config.color}20`, background: `${config.color}05` }}>
      <div className="text-[10px]" style={{ color: config.color }}>
        <strong>{label || config.label}</strong> — {text || config.text}
      </div>
    </div>
  );
}