/**
 * EnrichmentButton — Tier 2 paid-API enrichment trigger.
 *
 * Visually distinct (amber accent border) so users always know this is a
 * paid-enrichment action, not free local compute. Shows loading, cached,
 * and enrichment-paused states. Never auto-fires — only on explicit click.
 */
import { useState } from 'react';
import { Sparkles, Loader2, CheckCircle2, PauseCircle, AlertCircle } from 'lucide-react';

export default function EnrichmentButton({
  label = 'Enrich',
  onEnrich,
  disabled = false,
  cached = false,
  compact = false,
}) {
  const [state, setState] = useState('idle'); // idle | loading | paused | error
  const [errorMsg, setErrorMsg] = useState('');

  const handleClick = async () => {
    if (disabled || state === 'loading') return;
    setState('loading');
    setErrorMsg('');
    try {
      const result = await onEnrich();
      if (result && result.enrichmentPaused) {
        setState('paused');
      } else if (result && result.error) {
        setState('error');
        setErrorMsg(result.error);
      } else {
        setState('idle');
      }
    } catch (e) {
      setState('error');
      setErrorMsg(e && e.message ? e.message : String(e));
    }
  };

  const base = `flex items-center gap-1.5 rounded border font-mono font-bold transition-colors ${compact ? 'px-2 py-1 text-[9px]' : 'px-3 py-1.5 text-[10px]'}`;
  const styles = {
    idle: `border-[#ff9f00]/40 bg-[#ff9f00]/5 text-[#ff9f00] hover:bg-[#ff9f00]/10 ${disabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}`,
    loading: 'border-[#ff9f00]/40 bg-[#ff9f00]/10 text-[#ff9f00] cursor-wait',
    paused: 'border-[#8b949e]/30 bg-[#161b22] text-[#8b949e] cursor-help',
    error: 'border-[#f85149]/40 bg-[#f85149]/5 text-[#f85149] cursor-pointer',
  };

  let icon;
  if (state === 'loading') {
    icon = <Loader2 size={compact ? 9 : 11} className="animate-spin" />;
  } else if (state === 'paused') {
    icon = <PauseCircle size={compact ? 9 : 11} />;
  } else if (state === 'error') {
    icon = <AlertCircle size={compact ? 9 : 11} />;
  } else {
    icon = (
      <>
        <Sparkles size={compact ? 9 : 11} />
        {cached && <CheckCircle2 size={compact ? 9 : 11} className="text-[#3fb950]" />}
      </>
    );
  }

  let label2;
  if (state === 'loading') {
    label2 = 'Enriching…';
  } else if (state === 'paused') {
    label2 = 'Enrichment paused';
  } else if (state === 'error') {
    label2 = 'Retry';
  } else if (cached) {
    label2 = `${label} (cached)`;
  } else {
    label2 = label;
  }

  return (
    <div className="flex flex-col gap-1">
      <button onClick={handleClick} disabled={disabled || state === 'loading'} className={`${base} ${styles[state]}`}>
        {icon}
        <span>{label2}</span>
      </button>
      {state === 'paused' && (
        <div className="text-[9px] text-[#8b949e] font-mono leading-tight">
          Credits exhausted — core engine active.
          <br />
          <span className="text-[#484f58]">Local computation unaffected.</span>
        </div>
      )}
      {state === 'error' && errorMsg && (
        <div className="text-[9px] text-[#f85149] font-mono leading-tight break-all">{errorMsg}</div>
      )}
    </div>
  );
}