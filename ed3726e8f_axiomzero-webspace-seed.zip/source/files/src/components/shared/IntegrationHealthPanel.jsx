/**
 * IntegrationHealthPanel — live status + per-connector "test connection" action
 * for all eight token-backed integrations. Backed by checkSecretStatus for
 * configured/missing state, and invokes each fetcher with a probe query to
 * return a real success/failure result. Shared by Integration Hub and the
 * Journalist API Keys tab.
 */
import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { SOURCE_REGISTRY } from '@/lib/journalist/sourceRegistry';
import { Key, CheckCircle2, AlertCircle, ExternalLink, Loader2, RefreshCw, ShieldCheck, Zap, FlaskConical } from 'lucide-react';

// Map fetcher function name → source website URL (from the journalist source registry)
const URL_BY_FN = Object.fromEntries(SOURCE_REGISTRY.filter(s => s.fn && s.url).map(s => [s.fn, s.url]));

// Probe query per fetcher — a neutral term likely to return at least one hit
// on every source, so a working key proves it returns real data.
const PROBE_QUERY = 'Exxon';
const OPENROUTER_PROBE = { messages: [{ role: 'user', content: 'Reply with: OK' }], max_tokens: 5 };

export default function IntegrationHealthPanel({ compact = false }) {
  const [sources, setSources] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [testState, setTestState] = useState({}); // { [fetcher]: { status: 'idle'|'testing'|'ok'|'fail', detail, count } }

  const fetchStatus = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('checkSecretStatus', {});
      const data = res.data || res;
      setSources(data.sources || []);
    } catch (e) {
      setError(e.message || 'Failed to check integration status');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchStatus(); }, [fetchStatus]);

  const runTest = async (src) => {
    setTestState((s) => ({ ...s, [src.fetcher]: { status: 'testing' } }));
    try {
      const payload = src.fetcher === 'openRouterChat' ? OPENROUTER_PROBE : { query: PROBE_QUERY };
      const res = await base44.functions.invoke(src.fetcher, payload);
      const data = res.data || res;
      // All journalist fetchers return { sources, count, error? }; openRouterChat returns { content, error? }
      if (data.error) {
        setTestState((s) => ({ ...s, [src.fetcher]: { status: 'fail', detail: data.error } }));
      } else if (src.fetcher === 'openRouterChat') {
        setTestState((s) => ({ ...s, [src.fetcher]: { status: 'ok', detail: `Model responded (${data.model || 'ok'})`, count: 1 } }));
      } else if (typeof data.count === 'number') {
        if (data.count > 0) {
          setTestState((s) => ({ ...s, [src.fetcher]: { status: 'ok', detail: `${data.count} record${data.count === 1 ? '' : 's'} returned`, count: data.count } }));
        } else {
          setTestState((s) => ({ ...s, [src.fetcher]: { status: 'ok', detail: 'Connected (0 records for probe query)', count: 0 } }));
        }
      } else {
        setTestState((s) => ({ ...s, [src.fetcher]: { status: 'ok', detail: 'Connected' } }));
      }
    } catch (e) {
      setTestState((s) => ({ ...s, [src.fetcher]: { status: 'fail', detail: e.message || 'Request failed' } }));
    }
  };

  const configuredCount = sources.filter((s) => s.configured).length;
  const testedCount = Object.values(testState).filter((t) => t.status === 'ok').length;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-10">
        <Loader2 className="animate-spin text-[#4DD0E1]" size={22} />
      </div>
    );
  }
  if (error) {
    return (
      <div className="bg-[#2a1a0a] border border-[#f85149]/30 clip-corner p-4">
        <AlertCircle size={16} className="text-[#f85149] mb-2" />
        <p className="text-[#f85149] text-xs">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Summary header */}
      <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
        <div className="flex items-center gap-2 mb-2 flex-wrap">
          <FlaskConical size={16} className="text-[#4DD0E1]" />
          <h2 className="text-[#4DD0E1] text-sm font-bold uppercase tracking-wider">Live Integration Health</h2>
          <div className="flex items-center gap-1.5 ml-auto">
            <ShieldCheck size={14} className={configuredCount === sources.length ? 'text-[#3fb950]' : 'text-[#FF9F00]'} />
            <span className="text-xs text-[#e6edf3] font-bold">{configuredCount}/{sources.length} configured</span>
            {testedCount > 0 && <span className="text-[10px] text-[#3fb950] ml-1">· {testedCount} verified live</span>}
          </div>
          <button
            onClick={fetchStatus}
            className="flex items-center gap-1.5 text-[10px] text-[#8b949e] hover:text-[#e6edf3] border border-[#30363d] px-2 py-1 rounded transition-colors"
          >
            <RefreshCw size={11} /> Refresh
          </button>
        </div>
        <p className="text-[#8b949e] text-xs leading-relaxed">
          Each integration is exercised through its backend function. "Test" sends a live probe query and reports the real upstream response — success, record count, or the exact error (401/402/quota). Secrets are set in app settings and never exposed.
        </p>
      </div>

      {/* Connector grid */}
      <div className={`grid gap-3 ${compact ? 'grid-cols-1' : 'grid-cols-1 md:grid-cols-2'}`}>
        {sources.map((src) => {
          const ts = testState[src.fetcher] || { status: 'idle' };
          const isAI = src.fetcher === 'openRouterChat';
          return (
            <div
              key={src.key}
              className={`bg-[#0d1117]/80 backdrop-blur-md border clip-corner p-3 transition-colors ${
                ts.status === 'ok' ? 'border-[#3fb950]/40' :
                ts.status === 'fail' ? 'border-[#f85149]/40' :
                src.configured ? 'border-[#4DD0E1]/25' : 'border-[#FF9F00]/30'
              }`}
            >
              <div className="flex items-start gap-2.5">
                <div className="shrink-0 mt-0.5">
                  {ts.status === 'ok' ? <CheckCircle2 size={16} className="text-[#3fb950]" /> :
                   ts.status === 'fail' ? <AlertCircle size={16} className="text-[#f85149]" /> :
                   src.configured ? <Key size={16} className="text-[#4DD0E1]" /> :
                   <AlertCircle size={16} className="text-[#FF9F00]" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                    <span className="text-xs font-bold text-[#e6edf3]">{src.label}</span>
                    {URL_BY_FN[src.fetcher] && (
                      <a href={URL_BY_FN[src.fetcher]} target="_blank" rel="noreferrer" className="text-[#58a6ff] hover:underline" title={`Open ${src.label} website`}><ExternalLink size={10} /></a>
                    )}
                    <span className={`text-[8px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ${
                      ts.status === 'ok' ? 'bg-[#3fb950]/10 text-[#3fb950]' :
                      ts.status === 'fail' ? 'bg-[#f85149]/10 text-[#f85149]' :
                      src.configured ? 'bg-[#4DD0E1]/10 text-[#4DD0E1]' : 'bg-[#FF9F00]/10 text-[#FF9F00]'
                    }`}>
                      {ts.status === 'ok' ? 'Live' : ts.status === 'fail' ? 'Error' : ts.status === 'testing' ? 'Testing…' : src.configured ? 'Configured' : 'Missing'}
                    </span>
                    {isAI && <span className="text-[8px] text-[#bc8cff] font-bold uppercase">AI</span>}
                  </div>
                  <p className="text-[10px] text-[#8b949e] leading-relaxed mb-1.5">{src.description}</p>

                  {/* Test result detail */}
                  {ts.detail && (
                    <div className={`text-[9px] font-mono mb-1.5 px-2 py-1 rounded border ${
                      ts.status === 'ok' ? 'bg-[#3fb950]/5 border-[#3fb950]/20 text-[#3fb950]' :
                      'bg-[#f85149]/5 border-[#f85149]/20 text-[#f85149]'
                    }`}>
                      {ts.detail}
                    </div>
                  )}

                  {/* Missing-key instructions */}
                  {!src.configured && (
                    <div className="flex items-start gap-1.5 bg-[#FF9F00]/5 border border-[#FF9F00]/20 rounded p-2 mb-1.5">
                      <span className="text-[9px] text-[#FF9F00]/80">{src.instructions}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between gap-2 mt-1.5">
                    <span className="text-[9px] text-[#484f58] font-mono truncate">{src.key}</span>
                    <button
                      onClick={() => runTest(src)}
                      disabled={ts.status === 'testing' || !src.configured}
                      className="flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider px-2 py-1 rounded border transition-colors disabled:opacity-30 disabled:cursor-not-allowed ${
                        ts.status === 'ok' ? 'border-[#3fb950]/40 text-[#3fb950] hover:bg-[#3fb950]/10' :
                        ts.status === 'fail' ? 'border-[#f85149]/40 text-[#f85149] hover:bg-[#f85149]/10' :
                        'border-[#4DD0E1]/40 text-[#4DD0E1] hover:bg-[#4DD0E1]/10'
                      }"
                    >
                      {ts.status === 'testing' ? <Loader2 size={10} className="animate-spin" /> : <Zap size={10} />}
                      {ts.status === 'testing' ? 'Testing' : ts.status === 'ok' || ts.status === 'fail' ? 'Retest' : 'Test'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Keyless sources */}
      <div className="bg-[#0d1117]/80 backdrop-blur-md border border-[#30363d] clip-corner p-4">
        <div className="flex items-center gap-2 mb-2">
          <ExternalLink size={14} className="text-[#4DD0E1]" />
          <h3 className="text-[#4DD0E1] text-xs font-bold uppercase tracking-wider">Keyless Sources (Always Active)</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[10px] text-[#8b949e]">
          <div>• <a href="https://github.com" target="_blank" rel="noreferrer" className="text-[#e6edf3] font-bold hover:text-[#58a6ff] hover:underline">GitHub API <ExternalLink size={8} className="inline" /></a> — Repo tree, files, README</div>
          <div>• <a href="https://offshoreleaks.icij.org" target="_blank" rel="noreferrer" className="text-[#e6edf3] font-bold hover:text-[#58a6ff] hover:underline">ICIJ Offshore Leaks <ExternalLink size={8} className="inline" /></a> — Reconciliation API</div>
          <div>• <a href="https://echo.epa.gov" target="_blank" rel="noreferrer" className="text-[#e6edf3] font-bold hover:text-[#58a6ff] hover:underline">EPA ECHO <ExternalLink size={8} className="inline" /></a> — Facility compliance records</div>
          <div>• <a href="https://www.propublica.org/nonprofits" target="_blank" rel="noreferrer" className="text-[#e6edf3] font-bold hover:text-[#58a6ff] hover:underline">ProPublica Nonprofit Explorer <ExternalLink size={8} className="inline" /></a> — Form 990 disclosures</div>
          <div>• <a href="https://web.archive.org" target="_blank" rel="noreferrer" className="text-[#e6edf3] font-bold hover:text-[#58a6ff] hover:underline">Wayback Machine <ExternalLink size={8} className="inline" /></a> — Archived web page history</div>
          <div>• <a href="https://www.justice.gov/epstein/search" target="_blank" rel="noreferrer" className="text-[#e6edf3] font-bold hover:text-[#58a6ff] hover:underline">DOJ Epstein Library <ExternalLink size={8} className="inline" /></a> — Pre-filled deep links</div>
        </div>
      </div>
    </div>
  );
}