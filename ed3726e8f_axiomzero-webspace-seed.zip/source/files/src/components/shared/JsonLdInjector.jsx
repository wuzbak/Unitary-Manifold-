import { useEffect } from 'react';
import { base44 } from '@/api/base44Client';

/**
 * JsonLdInjector — fetches repo-driven JSON-LD blocks from generateCrawlManifest
 * and injects them as <script type="application/ld+json"> tags into <head> at runtime.
 * Dynamic, adaptive, zero write-backs. Cleans up on unmount.
 */
export default function JsonLdInjector() {
  useEffect(() => {
    let scripts = [];
    let cancelled = false;

    // Defer JSON-LD injection to idle time — it's for SEO crawlers, not human
    // visitors, so moving it off the critical path improves FCP/LCP/TBT without
    // any UX impact.
    const timer = setTimeout(() => {
      if (cancelled) return;
      base44.functions.invoke('generateCrawlManifest', {})
        .then((res) => {
          if (cancelled) return;
          const blocks = res.data && res.data.jsonLdBlocks;
          if (!Array.isArray(blocks)) return;
          // Remove any previously injected blocks
          document.querySelectorAll('script[data-az-jsonld]').forEach((s) => s.remove());
          scripts = blocks.map((block) => {
            const el = document.createElement('script');
            el.type = 'application/ld+json';
            el.setAttribute('data-az-jsonld', 'true');
            el.textContent = JSON.stringify(block);
            document.head.appendChild(el);
            return el;
          });
        })
        .catch(() => { /* non-fatal — structured data is enhancement only */ });
    }, 2000);

    return () => {
      cancelled = true;
      clearTimeout(timer);
      scripts.forEach((s) => { if (s.parentNode) s.parentNode.removeChild(s); });
    };
  }, []);

  return null;
}