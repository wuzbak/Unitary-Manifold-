/**
 * FidelitySlider — styled range input with a glowing fill + thumb.
 * Used by both the desktop SomaFmPlayer panel and the mobile bottom-bar audio row.
 */
export default function FidelitySlider({ value, onChange, min, max, step, color }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="relative h-4 flex items-center group">
      <div className="absolute inset-x-0 h-1.5 rounded-full bg-[#0a0a12] border border-[#30363d]" />
      <div className="absolute h-1.5 rounded-full transition-all duration-75" style={{ width: `${pct}%`, background: color, boxShadow: `0 0 6px ${color}` }} />
      <div className="absolute w-3 h-3 rounded-full border-2 bg-[#0a0a12] transition-all duration-75 group-hover:scale-125 group-active:scale-150" style={{ left: `calc(${pct}% - 6px)`, borderColor: color, boxShadow: `0 0 8px ${color}` }} />
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
    </div>
  );
}