/**
 * FreshnessBadge — small pill showing repo-freshness status.
 * green dot + 'Fresh' · amber dot + 'Stale' · red dot + 'Stale — data mismatch'
 */
import { CheckCircle2, AlertTriangle, CircleDashed } from 'lucide-react';

export default function FreshnessBadge({ freshness, accent = '#00f5ff' }) {
  if (!freshness || freshness.status === 'unknown') {
    return (
      <span className="flex items-center gap-1.5 text-[8px] lg:text-[9px] px-2 py-0.5 border clip-corner font-bold tracking-wider whitespace-nowrap"
        style={{ color: '#8b949e', borderColor: '#30363d', background: '#0d1117' }}>
        <CircleDashed size={9} className="text-[#8b949e]" /> Checking…
      </span>
    );
  }

  if (freshness.status === 'fresh') {
    return (
      <span className="flex items-center gap-1.5 text-[8px] lg:text-[9px] px-2 py-0.5 border clip-corner font-bold tracking-wider whitespace-nowrap"
        style={{ color: '#3fb950', borderColor: '#3fb95040', background: '#3fb95010' }}>
        <span className="w-1.5 h-1.5 rounded-full bg-[#3fb950] glow-pulse" /> Fresh
      </span>
    );
  }

  const hasMismatches = freshness.mismatches?.length > 0;
  const color = hasMismatches ? '#ff3b30' : '#fbbf24';
  const label = hasMismatches ? 'Stale — data mismatch' : 'Stale';

  return (
    <span className="flex items-center gap-1.5 text-[8px] lg:text-[9px] px-2 py-0.5 border clip-corner font-bold tracking-wider whitespace-nowrap"
      style={{ color, borderColor: `${color}40`, background: `${color}10` }}
      title={hasMismatches ? freshness.mismatches.join('\n') : 'Page data may be behind the repository'}>
      <AlertTriangle size={9} style={{ color }} /> {label}
    </span>
  );
}