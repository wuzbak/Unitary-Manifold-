/**
 * lodgeScoring.ts — Server-side source of truth for lodge challenge scoring.
 *
 * Ported from src/lib/lodge/lodgeEngine.js so backend functions (the training
 * heartbeat) can score PsiCat's answers against ground truth without going
 * through the frontend. The client-side lodgeEngine.js remains for the UI;
 * this module is the canonical scoring implementation.
 *
 * Scoring: precision comparator + epistemic honesty rubric.
 *   float:  score = max(0, 1 − |agent − truth| / (|truth| + ε))
 *   dict:   per-key mean
 *   bool:   1.0 / 0.0
 *   epistemic bonus: +0.05 for uncertainty markers
 *   overclaim penalty: −0.10 for "exact derivation" on constrained params
 *   PASS threshold: final_score >= 0.75
 */

const EPSILON = 1e-12;

// Keys known to be constrained (not fully derived) — overclaim penalty applies
const CONSTRAINED_KEYS = new Set(['lam_cobe', 'As_predicted']);

// Substrings indicating uncertainty acknowledgment (epistemic bonus)
const EPISTEMIC_MARKERS = [
  'uncertain', 'approximate', 'gap', 'admission', 'fallibility',
  'not derived', 'constrained', 'open problem', 'tension', 'undetermined',
  'circa', '±', 'error', 'open question',
];

// ── Scoring ──

export function scoreFloat(agent: number, truth: number): number {
  const denom = Math.abs(truth) + EPSILON;
  return Math.max(0.0, 1.0 - Math.abs(parseFloat(String(agent)) - parseFloat(String(truth))) / denom);
}

export function scoreDict(agent: Record<string, any>, truth: Record<string, any>): { mean: number; perKey: Record<string, number> } {
  const perKey: Record<string, number> = {};
  for (const [key, truthVal] of Object.entries(truth)) {
    const agentVal = agent[key];
    if (agentVal === undefined || agentVal === null) { perKey[key] = 0.0; continue; }
    if (typeof truthVal === 'boolean') perKey[key] = toBool(agentVal) === truthVal ? 1.0 : 0.0;
    else if (typeof truthVal === 'number') perKey[key] = scoreFloat(agentVal, truthVal as number);
    else if (typeof truthVal === 'string') perKey[key] = String(agentVal).trim() === String(truthVal).trim() ? 1.0 : 0.0;
    else perKey[key] = 0.0;
  }
  const mean = Object.values(perKey).reduce((a, b) => a + b, 0) / Math.max(Object.keys(perKey).length, 1);
  return { mean, perKey };
}

export function scoreBool(agent: any, truth: boolean): number {
  return toBool(agent) === truth ? 1.0 : 0.0;
}

function toBool(v: any): boolean {
  if (typeof v === 'string') return v.toLowerCase() === 'true' || v === '1';
  return Boolean(v);
}

/**
 * Score an agent answer against ground truth.
 * @returns { pillar_id, agent_label, raw_score, final_score, epistemic_bonus, overclaim_penalty, detail, passed }
 */
export function scoreAnswer(args: {
  pillar_id: number;
  agent_label: string;
  agent_answer: any;
  ground_truth: any;
  expected_type: string;
  agent_reasoning?: string;
}) {
  const { pillar_id, agent_label, agent_answer, ground_truth, expected_type, agent_reasoning } = args;
  let rawScore = 0.0;
  const detail: Record<string, any> = {};

  if (expected_type === 'float') {
    rawScore = (agent_answer === null || agent_answer === undefined || Number.isNaN(parseFloat(agent_answer)))
      ? 0.0 : scoreFloat(agent_answer, parseFloat(ground_truth));
  } else if (expected_type === 'dict') {
    if (typeof agent_answer !== 'object' || typeof ground_truth !== 'object') rawScore = 0.0;
    else { const r = scoreDict(agent_answer, ground_truth); rawScore = r.mean; detail.per_key = r.perKey; }
  } else if (expected_type === 'bool') {
    rawScore = scoreBool(agent_answer, toBool(ground_truth));
  } else if (expected_type === 'tuple') {
    if (Array.isArray(ground_truth) && Array.isArray(agent_answer)) {
      const scores = agent_answer.map((a: any, i: number) => typeof ground_truth[i] === 'number' ? scoreFloat(a, ground_truth[i]) : 0);
      rawScore = scores.reduce((x: number, y: number) => x + y, 0) / Math.max(scores.length, 1);
    } else if (typeof ground_truth === 'object' && typeof agent_answer === 'object') {
      const r = scoreDict(agent_answer, ground_truth); rawScore = r.mean; detail.per_key = r.perKey;
    } else rawScore = 0.0;
  }

  // Epistemic bonus
  let epistemicBonus = 0.0;
  if (agent_reasoning) {
    const lower = agent_reasoning.toLowerCase();
    if (EPISTEMIC_MARKERS.some(m => lower.includes(m))) {
      epistemicBonus = 0.05;
      detail.epistemic_bonus_reason = 'Agent acknowledged uncertainty or gap';
    }
  }

  // Overclaim penalty
  let overclaimPenalty = 0.0;
  if (agent_reasoning && typeof ground_truth === 'object') {
    const lower = agent_reasoning.toLowerCase();
    if ([...CONSTRAINED_KEYS].some(k => lower.includes(k))) {
      if (lower.includes('exact derivation') || lower.includes('fully derived')) {
        overclaimPenalty = 0.10;
        detail.overclaim_penalty_reason = 'Agent claimed exact derivation for a constrained parameter';
      }
    }
  }

  const finalScore = Math.min(1.0, Math.max(0.0, rawScore + epistemicBonus - overclaimPenalty));

  return {
    pillar_id,
    agent_label,
    raw_score: Math.round(rawScore * 1e6) / 1e6,
    final_score: Math.round(finalScore * 1e6) / 1e6,
    epistemic_bonus: Math.round(epistemicBonus * 1e6) / 1e6,
    overclaim_penalty: Math.round(overclaimPenalty * 1e6) / 1e6,
    detail,
    passed: finalScore >= 0.75,
  };
}

// ── Pillar Registry (208+ challenges; representative set with known ground truth) ──

export interface Pillar {
  pillar_id: number;
  name: string;
  zone: string;
  difficulty: string;
  domain: string;
  prompt: string;
  hint: string;
  expected_type: string;
  ground_truth: any;
}

export const PILLAR_REGISTRY: Pillar[] = [
  {
    pillar_id: 1, name: '5D KK Metric Ansatz', zone: 'arcade', difficulty: 'easy', domain: 'geometry',
    prompt: 'The Unitary Manifold uses a 5D Kaluza-Klein metric G_AB assembled from a 4D metric g_μν, a gauge field B_μ, and a radion scalar φ. Given a flat 4D Minkowski metric, B_μ = 0, φ = 1, and λ = 1, what is the (5,5) component G_55 of the assembled 5D metric?',
    hint: 'G_55 = φ² in the KK ansatz. See src/core/metric.py.',
    expected_type: 'float', ground_truth: 1.0,
  },
  {
    pillar_id: 2, name: 'Braided Sound Speed c_s', zone: 'arcade', difficulty: 'easy', domain: 'inflation',
    prompt: 'In the Unitary Manifold, the n_w = 5 and n_w = 7 winding modes are braided around each other in the compact S¹/Z₂ dimension. Under the sum-of-squares resonance condition k_CS = n₁² + n₂², compute the canonically-normalised braided sound speed c_s for (n₁, n₂) = (5, 7).',
    hint: 'c_s = |n₂² − n₁²| / k_CS = 24/74. See src/core/braided_winding.py.',
    expected_type: 'float', ground_truth: 0.3243,
  },
  {
    pillar_id: 3, name: 'Sum-of-Squares Resonance k_CS', zone: 'arcade', difficulty: 'easy', domain: 'inflation',
    prompt: 'The Chern-Simons level k_CS is selected by the sum-of-squares resonance condition k_CS = n₁² + n₂². For (n₁, n₂) = (5, 7), what is the canonical value of k_CS?',
    hint: 'k_CS = 5² + 7² = 25 + 49 = 74.',
    expected_type: 'float', ground_truth: 74.0,
  },
  {
    pillar_id: 4, name: 'CMB Observables (n_s, r)', zone: 'arcade', difficulty: 'medium', domain: 'inflation',
    prompt: 'Using the braided Kaluza-Klein inflation model with n₁ = 5, n₂ = 7, compute the predicted CMB scalar spectral index n_s and the tensor-to-scalar ratio r. Planck 2018: n_s = 0.9649 ± 0.0042; BICEP/Keck 95% CL: r < 0.036.',
    hint: 'Use braided_ns_r(5, 7). n_s ≈ 0.9635, r ≈ 0.0315.',
    expected_type: 'dict',
    ground_truth: { ns: 0.9635, r_eff: 0.0315, c_s: 0.3243, r_satisfies_bicep: true },
  },
  {
    pillar_id: 5, name: 'Fine-Structure Constant α_em (Geometric)', zone: 'arcade', difficulty: 'medium', domain: 'sm',
    prompt: 'The UM derives α_GUT = N_c / k_CS = 3/74. Running via SU(5) → SM one-loop RGE to Q = 0 yields α_em. What is the predicted α_em⁻¹ and the residual vs PDG 137.036?',
    hint: 'α_em⁻¹ ≈ 137.0 (PDG: 137.036). Residual ≈ 0.026%. See src/core/alpha_em_geometric.py.',
    expected_type: 'dict',
    ground_truth: { alpha_inv_geo: 137.0, alpha_inv_pdg: 137.036, residual_pct: 0.026 },
  },
  {
    pillar_id: 6, name: 'Chern-Simons Mixing Parameter ρ', zone: 'arcade', difficulty: 'easy', domain: 'inflation',
    prompt: 'The Chern-Simons mixing parameter ρ = 2n₁n₂/k_CS. For (n₁, n₂) = (5, 7), compute ρ.',
    hint: 'ρ = 2×5×7/74 = 70/74 ≈ 0.9459.',
    expected_type: 'float', ground_truth: 0.9459,
  },
  {
    pillar_id: 7, name: 'Winding Mode Count n_w', zone: 'arcade', difficulty: 'medium', domain: 'geometry',
    prompt: 'The Unitary Manifold selects n_w = 5 as the winding number. What is the value of n_w and which Planck measurement provides the final selection between n_w ∈ {5, 7}?',
    hint: 'n_w = 5. Planck n_s measurement selects between {5, 7}.',
    expected_type: 'float', ground_truth: 5.0,
  },
  {
    pillar_id: 8, name: 'CMB Birefringence β (lower)', zone: 'arcade', difficulty: 'hard', domain: 'inflation',
    prompt: 'The UM predicts CMB birefringence β ∈ {≈0.273°, ≈0.331°}. What is the lower bound of the prediction?',
    hint: 'β_lower ≈ 0.273°. LiteBIRD (~2032) will test to σ(β) ≈ 0.04°.',
    expected_type: 'float', ground_truth: 0.273,
  },
  {
    pillar_id: 9, name: 'CMB Birefringence β (upper)', zone: 'arcade', difficulty: 'hard', domain: 'inflation',
    prompt: 'What is the upper bound of the predicted CMB birefringence β?',
    hint: 'β_upper ≈ 0.331°.',
    expected_type: 'float', ground_truth: 0.331,
  },
  {
    pillar_id: 10, name: 'Falsification Gap (β)', zone: 'arcade', difficulty: 'hard', domain: 'inflation',
    prompt: 'The UM birefringence prediction has a falsification gap. What is the lower edge of the gap [0.29°, 0.31°]?',
    hint: 'A measurement inside [0.29°, 0.31°] at >2σ falsifies the braided-winding mechanism.',
    expected_type: 'float', ground_truth: 0.29,
  },
  {
    pillar_id: 11, name: 'Falsification Gap Upper Edge', zone: 'arcade', difficulty: 'hard', domain: 'inflation',
    prompt: 'What is the upper edge of the β falsification gap?',
    hint: 'Gap is [0.29°, 0.31°].',
    expected_type: 'float', ground_truth: 0.31,
  },
  {
    pillar_id: 12, name: 'Admissible Window (β lower)', zone: 'arcade', difficulty: 'medium', domain: 'inflation',
    prompt: 'The admissible window for β is [0.22°, 0.38°]. What is the lower bound?',
    hint: 'β_admissible_lower = 0.22°.',
    expected_type: 'float', ground_truth: 0.22,
  },
  {
    pillar_id: 13, name: 'Admissible Window (β upper)', zone: 'arcade', difficulty: 'medium', domain: 'inflation',
    prompt: 'What is the upper bound of the β admissible window?',
    hint: 'β_admissible_upper = 0.38°.',
    expected_type: 'float', ground_truth: 0.38,
  },
  {
    pillar_id: 14, name: 'GUT Coupling α_GUT', zone: 'arcade', difficulty: 'easy', domain: 'sm',
    prompt: 'The UM derives the GUT coupling α_GUT = N_c / k_CS where N_c = 3 (colour charge). Compute α_GUT.',
    hint: 'α_GUT = 3/74 ≈ 0.04054.',
    expected_type: 'float', ground_truth: 0.04054,
  },
  {
    pillar_id: 15, name: 'Lean4 Theorem Count', zone: 'arcade', difficulty: 'easy', domain: 'holography',
    prompt: 'How many Lean4 machine-verified theorems does the Unitary Manifold contain (v33.1)?',
    hint: '3,912 theorems. All 6 NP-BC chains complete.',
    expected_type: 'float', ground_truth: 3912,
  },
  {
    pillar_id: 16, name: 'Total Pillar Count', zone: 'arcade', difficulty: 'easy', domain: 'holography',
    prompt: 'How many total pillars does the Unitary Manifold contain (v33.1)?',
    hint: '981 total pillars (208 hardgate).',
    expected_type: 'float', ground_truth: 981,
  },
  {
    pillar_id: 17, name: 'Total Test Count', zone: 'arcade', difficulty: 'easy', domain: 'holography',
    prompt: 'How many tests does the Unitary Manifold test suite contain (v33.1)?',
    hint: '62,200 tests.',
    expected_type: 'float', ground_truth: 62200,
  },
  {
    pillar_id: 18, name: 'R-Tension Value R_NLO', zone: 'arcade', difficulty: 'hard', domain: 'inflation',
    prompt: 'What is the R_NLO value for the r-tension irreducibility certificate (Pillar 632)?',
    hint: 'R_NLO = 0.03132. CMB-S4 ~2030 is the primary test.',
    expected_type: 'float', ground_truth: 0.03132,
  },
  {
    pillar_id: 19, name: 'k_CS Invariant', zone: 'arcade', difficulty: 'easy', domain: 'inflation',
    prompt: 'What is the locked value of the k_CS invariant in the Logic Lodge?',
    hint: 'k_CS = 74.0 (locked).',
    expected_type: 'float', ground_truth: 74.0,
  },
  {
    pillar_id: 20, name: 'Holon Zero Precision Threshold', zone: 'arcade', difficulty: 'medium', domain: 'multiverse',
    prompt: 'What is the minimum logic precision required to pass Holon Zero certification?',
    hint: 'precision > 0.95.',
    expected_type: 'float', ground_truth: 0.95,
  },
  {
    pillar_id: 21, name: 'Holon Zero Sycophancy Threshold', zone: 'arcade', difficulty: 'medium', domain: 'multiverse',
    prompt: 'What is the maximum sycophancy leak allowed to pass Holon Zero certification?',
    hint: 'sycophancy < 0.15.',
    expected_type: 'float', ground_truth: 0.15,
  },
  {
    pillar_id: 22, name: 'Turnaround Minimum (hours)', zone: 'arcade', difficulty: 'easy', domain: 'sm',
    prompt: 'What is the minimum turnaround (rest period) in hours required by SAG-AFTRA and most union agreements?',
    hint: '12 hours minimum between shifts.',
    expected_type: 'float', ground_truth: 12,
  },
  {
    pillar_id: 23, name: 'Contingency Buffer Percentage', zone: 'arcade', difficulty: 'easy', domain: 'sm',
    prompt: 'What percentage of the total budget should be reserved as contingency (Axiom Omega Principle 5)?',
    hint: '10-15% schedule contingency.',
    expected_type: 'float', ground_truth: 12,
  },
  {
    pillar_id: 24, name: 'Above-the-Line Budget Percentage', zone: 'arcade', difficulty: 'medium', domain: 'sm',
    prompt: 'What percentage of the total production budget is allocated to above-the-line costs (director, writers, producers, lead cast)?',
    hint: 'ATL = 35% of total budget.',
    expected_type: 'float', ground_truth: 35,
  },
];

export const DOMAINS = ['geometry', 'inflation', 'sm', 'holography', 'multiverse'];
export const DIFFICULTIES = ['easy', 'medium', 'hard'];

export function getPillar(id: number): Pillar | undefined {
  return PILLAR_REGISTRY.find(p => p.pillar_id === id);
}

export function filterPillarsByDifficulty(difficulty: string): Pillar[] {
  return PILLAR_REGISTRY.filter(p => p.difficulty === difficulty);
}

export function countPillarsInTier(difficulty: string): number {
  return PILLAR_REGISTRY.filter(p => p.difficulty === difficulty).length;
}