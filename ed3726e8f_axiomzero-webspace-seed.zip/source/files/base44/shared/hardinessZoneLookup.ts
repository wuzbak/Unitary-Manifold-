/**
 * USDA Plant Hardiness Zone Lookup — Hybrid Authoritative System
 *
 * Three-tier lookup:
 * 1. phzmapi.org API (wraps official USDA 2023 PHZM data) — for US zip codes
 * 2. Open-Meteo historical temperature method — empirical 10-year avg annual extreme min
 * 3. Improved latitude model — final fallback
 *
 * Sources:
 *   - USDA ARS Plant Hardiness Zone Map (2023 edition)
 *   - PRISM Climate Group, Oregon State University (prism.oregonstate.edu/phzm)
 *   - phzmapi.org (Frostline project, public domain USDA data)
 *   - Open-Meteo Archive API (historical temperature data, free, no key)
 */

function fToC(f) { return (f - 32) * 5 / 9; }
function cToF(c) { return c * 9 / 5 + 32; }

// USDA half-zone boundaries (each half-zone is 5°F wide)
// Zone N spans (N*10 - 90)°F to (N*10 - 80)°F, split into a (lower) and b (upper)
const HALF_ZONES = [
  { halfZone: '1a', lowF: -65, highF: -60 },
  { halfZone: '1b', lowF: -60, highF: -55 },
  { halfZone: '2a', lowF: -55, highF: -50 },
  { halfZone: '2b', lowF: -50, highF: -45 },
  { halfZone: '3a', lowF: -45, highF: -40 },
  { halfZone: '3b', lowF: -40, highF: -35 },
  { halfZone: '4a', lowF: -35, highF: -30 },
  { halfZone: '4b', lowF: -30, highF: -25 },
  { halfZone: '5a', lowF: -25, highF: -20 },
  { halfZone: '5b', lowF: -20, highF: -15 },
  { halfZone: '6a', lowF: -15, highF: -10 },
  { halfZone: '6b', lowF: -10, highF: -5 },
  { halfZone: '7a', lowF: -5, highF: 0 },
  { halfZone: '7b', lowF: 0, highF: 5 },
  { halfZone: '8a', lowF: 5, highF: 10 },
  { halfZone: '8b', lowF: 10, highF: 15 },
  { halfZone: '9a', lowF: 15, highF: 20 },
  { halfZone: '9b', lowF: 20, highF: 25 },
  { halfZone: '10a', lowF: 25, highF: 30 },
  { halfZone: '10b', lowF: 30, highF: 35 },
  { halfZone: '11a', lowF: 35, highF: 40 },
  { halfZone: '11b', lowF: 40, highF: 45 },
  { halfZone: '12a', lowF: 45, highF: 50 },
  { halfZone: '12b', lowF: 50, highF: 55 },
  { halfZone: '13a', lowF: 55, highF: 60 },
  { halfZone: '13b', lowF: 60, highF: 65 },
];

function halfZoneFromTempF(tempF) {
  for (const z of HALF_ZONES) {
    if (tempF >= z.lowF && tempF < z.highF) return z;
  }
  if (tempF < -65) return HALF_ZONES[0];
  return HALF_ZONES[HALF_ZONES.length - 1];
}

// Frost dates by zone number
const ZONE_FROST = {
  1: { lastFrost: '06-15', firstFrost: '08-15', growingDays: 60, minTemp: 'below -45°C' },
  2: { lastFrost: '05-15', firstFrost: '09-01', growingDays: 105, minTemp: '-45 to -40°C' },
  3: { lastFrost: '05-15', firstFrost: '09-15', growingDays: 120, minTemp: '-40 to -34°C' },
  4: { lastFrost: '05-01', firstFrost: '10-01', growingDays: 150, minTemp: '-34 to -29°C' },
  5: { lastFrost: '04-15', firstFrost: '10-15', growingDays: 180, minTemp: '-29 to -23°C' },
  6: { lastFrost: '04-01', firstFrost: '11-01', growingDays: 210, minTemp: '-23 to -18°C' },
  7: { lastFrost: '03-15', firstFrost: '11-15', growingDays: 240, minTemp: '-18 to -12°C' },
  8: { lastFrost: '03-01', firstFrost: '11-30', growingDays: 270, minTemp: '-12 to -7°C' },
  9: { lastFrost: '02-15', firstFrost: '12-15', growingDays: 300, minTemp: '-7 to -2°C' },
  10: { lastFrost: '01-15', firstFrost: '12-30', growingDays: 350, minTemp: '-2 to 4°C' },
  11: { lastFrost: '01-01', firstFrost: '12-31', growingDays: 365, minTemp: 'above 4°C' },
  12: { lastFrost: '01-01', firstFrost: '12-31', growingDays: 365, minTemp: 'above 10°C' },
  13: { lastFrost: '01-01', firstFrost: '12-31', growingDays: 365, minTemp: 'above 16°C' },
};

export function getFrostDates(zoneNum) {
  return ZONE_FROST[zoneNum] || ZONE_FROST[7];
}

// ── Tier 1: phzmapi.org (USDA 2023 PHZM wrapper) ──
async function lookupByZip(zip) {
  try {
    const resp = await fetch(`https://phzmapi.org/${encodeURIComponent(zip)}.json`);
    if (!resp.ok) return null;
    const data = await resp.json();
    if (!data.zone) return null;
    const zoneNum = parseInt(data.zone);
    const tempParts = (data.temperature_range || '').split(' to ');
    const lowF = parseFloat(tempParts[0]);
    const highF = parseFloat(tempParts[1]);
    return {
      zone: data.zone,
      zoneNum,
      halfZone: data.zone,
      tempRangeF: data.temperature_range,
      tempRangeC: isNaN(lowF) || isNaN(highF) ? null : `${fToC(lowF).toFixed(1)} to ${fToC(highF).toFixed(1)}`,
      coordinates: data.coordinates ? { lat: parseFloat(data.coordinates.lat), lon: parseFloat(data.coordinates.lon) } : null,
      source: 'USDA PHZM 2023 (phzmapi.org)',
      sourceTier: 'TRUSTED',
    };
  } catch {
    return null;
  }
}

// ── Tier 2: Open-Meteo historical temperature method ──
// Fetches ~10 years of daily minimum temperatures, computes the average
// annual extreme minimum, and maps it to the USDA half-zone.
// The USDA zone IS defined as the 30-year average annual extreme minimum
// temperature — this method uses 10 years as a practical approximation.
async function lookupByHistoricalTemp(lat, lon) {
  try {
    const endYear = new Date().getFullYear();
    const startYear = endYear - 11;
    const startDate = `${startYear}-01-01`;
    const endDate = `${endYear - 1}-12-31`;
    const url = `https://archive-api.open-meteo.com/v1/archive?latitude=${lat}&longitude=${lon}` +
      `&start_date=${startDate}&end_date=${endDate}` +
      `&daily=temperature_2m_min&timezone=auto`;
    const resp = await fetch(url);
    if (!resp.ok) return null;
    const data = await resp.json();
    if (!data.daily || !data.daily.temperature_2m_min || !data.daily.time) return null;
    const temps = data.daily.temperature_2m_min;
    const dates = data.daily.time;
    // Group by year and find minimum for each year
    const yearlyMins = {};
    for (let i = 0; i < temps.length; i++) {
      if (temps[i] == null) continue;
      const year = dates[i].split('-')[0];
      if (!(year in yearlyMins) || temps[i] < yearlyMins[year]) {
        yearlyMins[year] = temps[i];
      }
    }
    const minValues = Object.values(yearlyMins);
    if (minValues.length < 3) return null; // Need at least 3 years
    const avgExtremeMinC = minValues.reduce((s, t) => s + t, 0) / minValues.length;
    const avgExtremeMinF = cToF(avgExtremeMinC);
    const hz = halfZoneFromTempF(avgExtremeMinF);
    return {
      zone: hz.halfZone,
      zoneNum: parseInt(hz.halfZone),
      halfZone: hz.halfZone,
      tempRangeF: `${hz.lowF} to ${hz.highF}`,
      tempRangeC: `${fToC(hz.lowF).toFixed(1)} to ${fToC(hz.highF).toFixed(1)}`,
      avgExtremeMinC: avgExtremeMinC.toFixed(1),
      avgExtremeMinF: avgExtremeMinF.toFixed(1),
      yearsAnalyzed: minValues.length,
      source: 'Open-Meteo Historical (10-year avg annual extreme min)',
      sourceTier: 'EMPIRICAL',
    };
  } catch {
    return null;
  }
}

// ── Tier 3: Improved latitude model ──
function lookupByLatitude(lat) {
  const absLat = Math.abs(lat);
  const hemiAdjust = lat < 0 ? 1 : 0; // Southern hemisphere tends to be milder
  let zoneNum;
  if (absLat >= 58) zoneNum = 1;
  else if (absLat >= 54) zoneNum = 2;
  else if (absLat >= 49) zoneNum = 3;
  else if (absLat >= 45) zoneNum = 4;
  else if (absLat >= 41) zoneNum = 5;
  else if (absLat >= 37) zoneNum = 6;
  else if (absLat >= 33) zoneNum = 7;
  else if (absLat >= 29) zoneNum = 8;
  else if (absLat >= 25) zoneNum = 9;
  else if (absLat >= 20) zoneNum = 10;
  else if (absLat >= 15) zoneNum = 11;
  else zoneNum = 12;
  zoneNum = Math.max(1, Math.min(13, zoneNum + hemiAdjust));
  const halfZone = `${zoneNum}a`;
  const lowF = zoneNum * 10 - 90;
  return {
    zone: halfZone,
    zoneNum,
    halfZone,
    tempRangeF: `${lowF} to ${lowF + 5}`,
    tempRangeC: `${fToC(lowF).toFixed(1)} to ${fToC(lowF + 5).toFixed(1)}`,
    source: 'Latitude-based estimation (improved)',
    sourceTier: 'ESTIMATED',
  };
}

export async function lookupHardinessZone({ zip, lat, lon }) {
  let result = null;

  // Tier 1: phzmapi.org (US zip code)
  if (zip) {
    result = await lookupByZip(zip);
  }

  // Tier 2: Open-Meteo historical temperature method
  if (!result && lat != null && lon != null) {
    result = await lookupByHistoricalTemp(lat, lon);
  }

  // Tier 3: Improved latitude model
  if (!result && lat != null) {
    result = lookupByLatitude(lat);
  }

  // Ultimate fallback
  if (!result) {
    result = { zone: '7a', zoneNum: 7, halfZone: '7a', source: 'Default fallback', sourceTier: 'ESTIMATED' };
  }

  // Add frost dates
  const frost = getFrostDates(result.zoneNum);
  if (frost) {
    result.frostDates = {
      lastSpring: frost.lastFrost,
      firstFall: frost.firstFrost,
      growingDays: frost.growingDays,
    };
  }

  return result;
}