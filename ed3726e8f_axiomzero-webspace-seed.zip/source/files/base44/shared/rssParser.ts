/** XXE-safe RSS/Atom XML parsing utilities shared across feed proxy functions. */

export function stripCdata(s: string): string {
  if (!s) return '';
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').trim();
}

/** Decode XML/HTML entities — critical for URLs extracted from attribute values. */
export function decodeEntities(s: string): string {
  if (!s) return '';
  return s
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(parseInt(n, 10)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)));
}

export function stripHtml(s: string): string {
  if (!s) return '';
  return stripCdata(s).replace(/<[^>]*>/g, '').replace(/&[a-z]+;/gi, ' ').replace(/\s+/g, ' ').trim();
}

/** Parse RSS 2.0 <item> XML — returns items with title, link, description, pubDate, guid, raw. */
export function parseRss(xml: string): any[] {
  const items: any[] = [];
  const itemRegex = /<item[^>]*>([\s\S]*?)<\/item>/gi;
  let m;
  while ((m = itemRegex.exec(xml)) !== null) {
    const raw = m[1];
    const titleMatch = raw.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const linkMatch = raw.match(/<link[^>]*>([\s\S]*?)<\/link>/i);
    const descMatch = raw.match(/<description[^>]*>([\s\S]*?)<\/description>/i);
    const pubMatch = raw.match(/<pubDate[^>]*>([\s\S]*?)<\/pubDate>/i);
    const guidMatch = raw.match(/<guid[^>]*>([\s\S]*?)<\/guid>/i);
    items.push({
      title: stripCdata(titleMatch?.[1] || ''),
      link: stripCdata(linkMatch?.[1] || ''),
      description: stripHtml(descMatch?.[1] || ''),
      pubDate: stripCdata(pubMatch?.[1] || ''),
      guid: stripCdata(guidMatch?.[1] || ''),
      raw,
    });
  }
  return items;
}

/** Extract a field value from raw XML block by tag name(s) — first match wins. */
export function field(raw: string, ...names: string[]): string {
  for (const name of names) {
    const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const m = raw.match(new RegExp(`<${escaped}[^>]*>([\\s\\S]*?)<\\/${escaped}>`, 'i'));
    if (m) return stripCdata(m[1]);
  }
  return '';
}

/** Extract geo coordinates from raw XML block (geo:lat/geo:long or georss:point). */
export function geoPoint(raw: string): [number, number] | null {
  const latMatch = raw.match(/<(?:geo:)?lat[^>]*>([\s\S]*?)<\/(?:geo:)?lat>/i);
  const lonMatch = raw.match(/<(?:geo:)?long[^>]*>([\s\S]*?)<\/(?:geo:)?long>/i);
  if (latMatch && lonMatch) {
    const lat = parseFloat(stripCdata(latMatch[1]));
    const lon = parseFloat(stripCdata(lonMatch[1]));
    if (!isNaN(lat) && !isNaN(lon)) return [lat, lon];
  }
  const pointMatch = raw.match(/<georss:point[^>]*>([\s\S]*?)<\/georss:point>/i);
  if (pointMatch) {
    const parts = stripCdata(pointMatch[1]).trim().split(/\s+/);
    if (parts.length >= 2) {
      const lat = parseFloat(parts[0]);
      const lon = parseFloat(parts[1]);
      if (!isNaN(lat) && !isNaN(lon)) return [lat, lon];
    }
  }
  return null;
}

export interface FeedConfig {
  id: string;
  outlet: string;
  feedCategory: string;
  category?: string;
  trustTag?: string;
  url: string;
  [key: string]: any;
}

/**
 * Parse RSS 2.0 (<item>) or Atom (<entry>) XML — XXE-safe regex parser
 * (no external entity resolution). Extracts title, link, date, description.
 * Used by trustedNewsFeed and sdrRadioFeed.
 */
export function parseFeed(xml: string, feed: FeedConfig): any[] {
  const items: any[] = [];
  const itemRegex = /<(?:item|entry)[^>]*>([\s\S]*?)<\/(?:item|entry)>/gi;
  let m;
  while ((m = itemRegex.exec(xml)) !== null) {
    const block = m[1];
    const titleMatch = block.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const linkTextMatch = block.match(/<link[^>]*>([\s\S]*?)<\/link>/i);
    const linkAttrMatch = block.match(/<link[^>]*href=["']([^"']+)["'][^>]*\/?>/i);
    const pubMatch = block.match(/<(?:pubDate|published|updated)[^>]*>([\s\S]*?)<\/(?:pubDate|published|updated)>/i);
    const descMatch = block.match(/<(?:description|summary|content)[^>]*>([\s\S]*?)<\/(?:description|summary|content)>/i);
    const enclosureMatch = block.match(/<enclosure[^>]*url=["']([^"']+)["'][^>]*\/?>/i);
    const title = stripCdata(titleMatch?.[1] || '');
    const link = linkTextMatch ? stripCdata(linkTextMatch[1]) : (linkAttrMatch ? linkAttrMatch[1] : null);
    if (!title) continue;
    items.push({
      id: feed.id,
      title,
      url: link ? decodeEntities(link) : null,
      outlet: feed.outlet,
      category: feed.category,
      feedCategory: feed.feedCategory,
      trustTag: feed.trustTag,
      description: descMatch ? stripHtml(descMatch[1]).slice(0, 280) : '',
      published: pubMatch ? stripCdata(pubMatch[1]) : null,
      audioUrl: enclosureMatch ? decodeEntities(enclosureMatch[1]).replace('https://prfx.byspotify.com/e/', 'https://') : null,
    });
  }
  return items;
}