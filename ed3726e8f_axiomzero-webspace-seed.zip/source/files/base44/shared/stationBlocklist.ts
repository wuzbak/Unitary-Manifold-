/**
 * stationBlocklist — curated list of authoritarian state-sponsored propaganda
 * and known disinformation outlets to prune from the SDR Radio Console catalog.
 *
 * Scope: state media from regimes that aggressively violate human rights or
 * systematically propagate disinformation, plus watchdog-flagged outlets.
 * This is a code-level constant — no UI, no announcement. Stations simply
 * stop appearing in search results and the catalog.
 *
 * Matching is conservative: name matches use word boundaries (or exact match)
 * to avoid false positives; domain matches check substring inclusion in
 * stream_url, homepage_url, and favicon_url.
 */

// Outlet name substrings — matched with word-boundary awareness (see helper)
export const BLOCKED_NAMES: string[] = [
  // Infowars / Alex Jones (watchdog-flagged disinformation)
  'infowars',

  // Russian state media
  'russia today',
  'rt news',
  'sputnik',
  'voice of russia',
  'radio vr',
  'rt tv',

  // Chinese state media
  'cgtn',
  'china radio international',
  'china global television',
  'cctv news',
  'cctv 13',
  'cctv 4',

  // Iranian state media
  'press tv',
  'presstv',
  'irib',
  'voice of the islamic republic',
  'radio tehran',

  // North Korean state media
  'korean central broadcasting',
  'voice of korea',
  'radio pyongyang',
  'pyongyang radio',

  // Syrian state media
  'syrian tv',
  'sana radio',
  'syrian arab news',
  'syria satellite',

  // Belarusian state media
  'belarus radio',
  'radio belarus',
  'belarusian radio',

  // Eritrean state media
  'radio eritrea',
  'eritrea radio',
  'voice of the broad masses',

  // Turkmen state media
  'turkmenistan radio',
  'radio turkmenistan',

  // Other authoritarian state broadcasters
  'radio cuba',
  'radio habana',
  'cuban radio',

  // Breitbart (far-right disinformation outlet)
  'breitbart',
  'breitbart news',

  // Steve Bannon / War Room (far-right disinformation)
  'steve bannon',
  'war room',
  'war room pandemic',
  'real america\'s voice',
  'real americas voice',

  // Fox News (NOT generic 'fox' — avoids false positives on Fox FM, Fox Sports, local affiliates)
  'fox news',
  'fox news radio',
  'fox news channel',
];

// URL domains — matched as substrings in stream_url, homepage_url, favicon_url
export const BLOCKED_DOMAINS: string[] = [
  // Infowars
  'infowars.com',

  // Russian state media
  'rt.com',
  'rttv.com',
  'sputniknews.com',
  'sputniknews.ru',
  'sputnikradio.com',
  'voiceofrussia.com',
  'radiovr.ru',
  'rtr-vesti.ru',
  'radiosputnik.ru',

  // Chinese state media
  'cgtn.com',
  'cgtn.cn',
  'cri.cn',
  'cctv.com',
  'cctv.cn',
  'radio.cn',

  // Iranian state media
  'presstv.com',
  'presstv.ir',
  'irib.ir',
  'iribworld.com',

  // North Korean state media
  'dprkradio.com',
  'voiceofkorea.com',

  // Syrian state media
  'sana.sy',
  'sana.com.sy',

  // Belarusian state media
  'belarusradio.by',
  'btr.by',
  'belarus-radio.com',

  // Eritrean state media
  'eritrea-radio.com',
  'radioeritrea.org',

  // Turkmen state media
  'tmtm.gov.tm',
  'turkmenradio.gov.tm',

  // Breitbart
  'breitbart.com',

  // Steve Bannon / Real America's Voice
  'warroom.org',
  'realamericasvoice.com',
  'real-americas-voice.com',

  // Fox News (NOT fox.com — that's the entertainment/network TV site)
  'foxnews.com',
  'foxnewsradio.com',
];

/**
 * Extract the hostname from a URL (handles unusual radio stream URL formats).
 */
function extractHostname(url: string): string {
  if (!url) return '';
  const lower = url.toLowerCase();
  const withoutProto = lower.replace(/^https?:\/\//, '');
  const hostPart = withoutProto.split('/')[0].split('?')[0].split('#')[0];
  return hostPart.split(':')[0];
}

/**
 * Check if a URL's hostname equals or is a subdomain of a blocked domain.
 * This prevents false positives like "iheart.com" matching "rt.com".
 */
function urlDomainMatches(url: string, blockedDomain: string): boolean {
  const hostname = extractHostname(url);
  if (!hostname) return false;
  return hostname === blockedDomain || hostname.endsWith('.' + blockedDomain);
}

/**
 * Check whether a station record matches the blocklist.
 * Checks name (word-boundary aware), stream_url, homepage_url, and favicon_url.
 */
export function isBlockedStation(station: any): boolean {
  if (!station) return false;

  const name = (station.name || '').toLowerCase().trim();
  const streamUrl = station.stream_url || '';
  const homepageUrl = station.homepage_url || '';
  const faviconUrl = station.favicon_url || '';

  // Domain match — hostname-based to avoid false positives (e.g. "rt.com" in "iheart.com")
  for (const domain of BLOCKED_DOMAINS) {
    if (urlDomainMatches(streamUrl, domain) || urlDomainMatches(homepageUrl, domain) || urlDomainMatches(faviconUrl, domain)) {
      return true;
    }
  }

  // Name match — word-boundary aware to avoid false positives on short strings
  for (const blocked of BLOCKED_NAMES) {
    if (name === blocked) return true;
    if (name.startsWith(blocked + ' ')) return true;
    if (name.endsWith(' ' + blocked)) return true;
    if (name.includes(' ' + blocked + ' ')) return true;
    // For longer unique strings (>= 7 chars), substring match is safe enough
    if (blocked.length >= 7 && name.includes(blocked)) return true;
  }

  return false;
}