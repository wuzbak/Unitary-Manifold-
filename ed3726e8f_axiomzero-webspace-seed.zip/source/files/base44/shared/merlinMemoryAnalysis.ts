/**
 * merlinMemoryAnalysis.ts — Shared helpers for analyzing MerlinNote records.
 *
 * Consumed by: merlinConsolidateMemory (memory consolidation engine) and
 * merlinSelfAudit (calibration / alignment tracking). Extracted here so both
 * functions share the same analysis primitives — no duplicated logic.
 *
 * Server-side only — never imported from the frontend.
 */

export const ALL_DOMAINS = ['physics', 'film', 'journalism', 'earth-science', 'dnd', 'general'];

/**
 * Compute aggregate statistics from a set of MerlinNote records.
 * Returns domain coverage, confidence distribution, contradiction rate,
 * decoherence events, and identified knowledge gaps.
 */
export function computeNoteStats(notes) {
  const total = notes.length;
  if (total === 0) {
    return {
      total: 0,
      byDomain: {},
      bySource: {},
      byConfidence: { high: 0, medium: 0, low: 0, none: 0 },
      contradictionRate: 0,
      decoherenceEvents: 0,
      avgConfidence: 0,
      domainsCovered: [],
      domainsSparse: ALL_DOMAINS.slice(),
      knowledgeGaps: ALL_DOMAINS.map((d) => ({ domain: d, count: 0, gap: 'No notes in this domain' })),
    };
  }

  const byDomain = {};
  const bySource = {};
  const byConfidence = { high: 0, medium: 0, low: 0, none: 0 };
  let contradictionCount = 0;
  let decoherenceCount = 0;
  let confidenceSum = 0;
  let confidenceCount = 0;

  for (const n of notes) {
    const domain = n.domain || 'general';
    byDomain[domain] = (byDomain[domain] || 0) + 1;

    const source = n.source || 'reasoning';
    bySource[source] = (bySource[source] || 0) + 1;

    if (n.epistemic_confidence != null) {
      confidenceSum += n.epistemic_confidence;
      confidenceCount++;
      if (n.epistemic_confidence >= 0.8) byConfidence.high++;
      else if (n.epistemic_confidence >= 0.4) byConfidence.medium++;
      else byConfidence.low++;
    } else {
      byConfidence.none++;
    }

    if (n.contradiction_flag === 'flagged') contradictionCount++;
    if (n.decoherence_count && n.decoherence_count > 0) decoherenceCount += n.decoherence_count;
  }

  const avgConfidence = confidenceCount > 0 ? confidenceSum / confidenceCount : 0;
  const contradictionRate = total > 0 ? contradictionCount / total : 0;

  // Domain coverage — a domain is "covered" if it has >= 3 notes, "sparse" if < 3
  const domainsCovered = ALL_DOMAINS.filter((d) => (byDomain[d] || 0) >= 3);
  const domainsSparse = ALL_DOMAINS.filter((d) => (byDomain[d] || 0) < 3);

  // Knowledge gaps — domains with low coverage or low average confidence
  const knowledgeGaps = ALL_DOMAINS.map((d) => {
    const count = byDomain[d] || 0;
    if (count === 0) return { domain: d, count: 0, gap: 'No notes — complete knowledge gap' };
    if (count < 3) return { domain: d, count, gap: 'Sparse coverage — fewer than 3 notes' };
    const domainNotes = notes.filter((n) => (n.domain || 'general') === d);
    const domainConfident = domainNotes.filter((n) => n.epistemic_confidence != null);
    if (domainConfident.length > 0) {
      const avgConf = domainConfident.reduce((s, n) => s + n.epistemic_confidence, 0) / domainConfident.length;
      if (avgConf < 0.4) return { domain: d, count, gap: `Low average confidence (${avgConf.toFixed(2)}) — uncertain knowledge base` };
    }
    return null;
  }).filter(Boolean);

  return {
    total,
    byDomain,
    bySource,
    byConfidence,
    contradictionRate,
    decoherenceEvents: decoherenceCount,
    avgConfidence,
    domainsCovered,
    domainsSparse,
    knowledgeGaps,
  };
}

/**
 * Group notes by domain for domain-specific consolidation.
 */
export function groupNotesByDomain(notes) {
  const groups = {};
  for (const n of notes) {
    const d = n.domain || 'general';
    if (!groups[d]) groups[d] = [];
    groups[d].push(n);
  }
  return groups;
}

/**
 * Extract tags from a note's tags_json field.
 */
export function extractTags(note) {
  try {
    const tags = JSON.parse(note.tags_json || '[]');
    return Array.isArray(tags) ? tags : [];
  } catch {
    return [];
  }
}

/**
 * Extract distilled primitives from a note's distilled_primitives_json field.
 */
export function extractPrimitives(note) {
  try {
    const primitives = JSON.parse(note.distilled_primitives_json || '{}');
    return primitives || {};
  } catch {
    return {};
  }
}

/**
 * Group notes by shared tags for cross-domain consolidation.
 */
export function groupNotesByTagClusters(notes) {
  const tagMap = {};
  for (const n of notes) {
    const tags = extractTags(n);
    for (const tag of tags) {
      if (!tagMap[tag]) tagMap[tag] = [];
      tagMap[tag].push(n);
    }
  }
  // Only return clusters with 2+ notes — single-note tags aren't clusters
  const clusters = {};
  for (const [tag, clusterNotes] of Object.entries(tagMap)) {
    if (clusterNotes.length >= 2) {
      clusters[tag] = clusterNotes;
    }
  }
  return clusters;
}

/**
 * Compute confidence evolution — how confidence has changed over time.
 * Returns a timeline of average confidence per time bucket.
 */
export function computeConfidenceEvolution(notes) {
  const sorted = [...notes]
    .filter((n) => n.epistemic_confidence != null && n.created_date)
    .sort((a, b) => new Date(a.created_date).getTime() - new Date(b.created_date).getTime());

  if (sorted.length === 0) return [];

  // Bucket by week
  const buckets = {};
  for (const n of sorted) {
    const d = new Date(n.created_date);
    const weekKey = `${d.getFullYear()}-W${Math.ceil((d.getDate() + d.getDay()) / 7)}`;
    if (!buckets[weekKey]) buckets[weekKey] = [];
    buckets[weekKey].push(n.epistemic_confidence);
  }

  return Object.entries(buckets).map(([week, confidences]) => ({
    week,
    avgConfidence: confidences.reduce((s, c) => s + c, 0) / confidences.length,
    count: confidences.length,
  }));
}

/**
 * Build a compact summary of notes for LLM consolidation input.
 * Truncates each note to a reasonable length for token efficiency.
 */
export function buildNoteSummaries(notes, maxPerNote = 300) {
  return notes.map((n, i) => {
    const title = n.title || 'Untitled';
    const content = (n.content || '').slice(0, maxPerNote);
    const domain = n.domain || 'general';
    const confidence = n.epistemic_confidence != null ? ` [conf=${n.epistemic_confidence}]` : '';
    const bounds = n.uncertainty_bounds ? ` (${n.uncertainty_bounds})` : '';
    const tags = extractTags(n);
    const tagStr = tags.length > 0 ? ` {${tags.join(',')}}` : '';
    return `${i + 1}. [${n.source || 'reasoning'}]${tagStr} (${domain})${confidence}${bounds}: ${title} — ${content}`;
  }).join('\n');
}