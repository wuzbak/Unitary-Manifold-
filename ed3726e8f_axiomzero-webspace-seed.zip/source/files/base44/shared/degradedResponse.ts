/**
 * degradedResponse — shared graceful-degradation helper for backend functions.
 *
 * Instead of throwing and returning a raw 500 to the frontend, functions return
 * HTTP 200 with the EMPTY version of their normal payload plus a `status` field
 * and a human-readable `message`. The frontend always receives a known shape
 * and can render a quiet "temporarily unavailable" state — never a 500 toast.
 *
 * Status vocabulary:
 *   'ok'                 — normal success (added for symmetry; success paths may omit it)
 *   'unavailable'        — upstream API down, WAF-blocked, or network failure
 *   'missing-credentials' — required secret not configured
 *   'rate-limited'       — upstream returned 429
 *   'bad-request'        — caller sent an invalid query
 *
 * Theory, methodology: ThomasCory Walker-Pearson / AxiomZero Technologies & Consulting, SPC.
 */
export type DegradedStatus =
  | 'ok'
  | 'unavailable'
  | 'missing-credentials'
  | 'rate-limited'
  | 'bad-request';

/**
 * Returns an HTTP 200 response carrying the empty payload + status + message.
 * Use on every failure path in a backend function so the frontend degrades
 * gracefully instead of surfacing a 500.
 */
export function unavailableResponse(
  payload: Record<string, any>,
  status: DegradedStatus,
  message: string,
): Response {
  return Response.json({ ...payload, status, message }, { status: 200 });
}