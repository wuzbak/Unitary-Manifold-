/**
 * resilientFetch — shared resilient HTTP fetch with retry, timeout,
 * circuit-breaker, and short-lived cached fallback.
 *
 * Used by data-fetching backend functions so a transient upstream 5xx/timeout
 * returns the last good cached response with a 'degraded' status flag instead
 * of an empty panel.
 *
 * Theory, methodology: ThomasCory Walker-Pearson / AxiomZero Technologies & Consulting, SPC.
 * Implementation: GitHub Copilot (AI).
 */

interface ResilientOptions {
  retries?: number;           // retry attempts after the first failure (default 2)
  timeoutMs?: number;         // per-attempt timeout in ms (default 12000)
  breakerThreshold?: number;  // consecutive failures before breaker opens (default 5)
  cacheTtl?: number;          // cached-fallback TTL in ms (default 300000 = 5 min)
  headers?: Record<string, string>;
  method?: string;
  body?: string;
  cacheKey?: string;          // explicit cache key (defaults to url+method)
}

export interface ResilientResult<T> {
  data: T | null;
  status: 'live' | 'cached' | 'degraded' | 'unavailable';
  source: string;
  cachedAt?: string;
  error?: string;
  attempts?: number;
}

// Module-level warm cache + breaker state — persists across warm invocations.
const cache = new Map<string, { data: any; at: number; ttl: number }>();
const breakerFails = new Map<string, number>();

function breakerOpen(host: string, threshold: number): boolean {
  return (breakerFails.get(host) || 0) >= threshold;
}

function recordFailure(host: string) {
  breakerFails.set(host, (breakerFails.get(host) || 0) + 1);
}

function recordSuccess(host: string) {
  breakerFails.delete(host);
}

function hostOf(url: string): string {
  try { return new URL(url).host; } catch { return url; }
}

function withTimeout(ms: number): { signal: AbortSignal; cancel: () => void } {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), ms);
  return { signal: controller.signal, cancel: () => clearTimeout(t) };
}

/**
 * Fetch with resilience. Returns { data, status, source, cachedAt }.
 * - status 'live': fresh successful fetch.
 * - status 'cached': breaker open OR fetch failed, but a fresh (<ttl) cached copy was served.
 * - status 'degraded': fetch failed, a stale (>ttl) cached copy was served.
 * - status 'unavailable': fetch failed and no cache exists.
 */
export async function fetchWithResilience<T = any>(
  url: string,
  opts: ResilientOptions = {},
): Promise<ResilientResult<T>> {
  const retries = opts.retries ?? 2;
  const timeoutMs = opts.timeoutMs ?? 12000;
  const breakerThreshold = opts.breakerThreshold ?? 5;
  const cacheTtl = opts.cacheTtl ?? 300000;
  const host = hostOf(url);
  const key = opts.cacheKey || `${opts.method || 'GET'}:${url}`;

  // Circuit-breaker short-circuit: if open, serve cache immediately.
  if (breakerOpen(host, breakerThreshold)) {
    const entry = cache.get(key);
    if (entry) {
      const age = Date.now() - entry.at;
      return {
        data: entry.data,
        status: age < entry.ttl ? 'cached' : 'degraded',
        source: host,
        cachedAt: new Date(entry.at).toISOString(),
        error: 'circuit-breaker-open',
      };
    }
    return { data: null, status: 'unavailable', source: host, error: 'circuit-breaker-open' };
  }

  let lastErr = '';
  for (let attempt = 0; attempt <= retries; attempt++) {
    const { signal, cancel } = withTimeout(timeoutMs);
    try {
      const res = await fetch(url, {
        method: opts.method || 'GET',
        headers: opts.headers,
        body: opts.body,
        signal,
      });
      cancel();
      if (!res.ok) {
        // 5xx and 429 are retryable; 4xx (except 429) are not.
        if ((res.status >= 500 || res.status === 429) && attempt < retries) {
          lastErr = `HTTP ${res.status}`;
          const retryAfter = parseInt(res.headers.get('retry-after') || '', 10);
          const delay = res.status === 429 ? 2500 * Math.pow(2, attempt) : 400 * Math.pow(2, attempt);
          await new Promise((r) => setTimeout(r, retryAfter ? Math.min(retryAfter * 1000, 8000) : delay));
          continue;
        }
        // Non-retryable error — try cache, then bail.
        const entry = cache.get(key);
        if (entry) {
          const age = Date.now() - entry.at;
          return {
            data: entry.data,
            status: age < entry.ttl ? 'cached' : 'degraded',
            source: host,
            cachedAt: new Date(entry.at).toISOString(),
            error: `HTTP ${res.status}`,
          };
        }
        return { data: null, status: 'unavailable', source: host, error: `HTTP ${res.status}`, attempts: attempt + 1 };
      }
      const data = await res.json();
      // Success — cache it and reset breaker.
      cache.set(key, { data, at: Date.now(), ttl: cacheTtl });
      recordSuccess(host);
      return { data, status: 'live', source: host, attempts: attempt + 1 };
    } catch (e) {
      cancel();
      lastErr = (e as Error).message || 'fetch error';
      if (attempt < retries) {
        await new Promise((r) => setTimeout(r, 400 * Math.pow(2, attempt)));
        continue;
      }
    }
  }

  // All retries exhausted — serve cache if available.
  recordFailure(host);
  const entry = cache.get(key);
  if (entry) {
    const age = Date.now() - entry.at;
    return {
      data: entry.data,
      status: age < entry.ttl ? 'cached' : 'degraded',
      source: host,
      cachedAt: new Date(entry.at).toISOString(),
      error: lastErr,
    };
  }
  return { data: null, status: 'unavailable', source: host, error: lastErr };
}

/** Fetch raw text (XML/HTML) with the same resilience — used by RSS proxies. */
export async function fetchTextWithResilience(
  url: string,
  opts: ResilientOptions = {},
): Promise<ResilientResult<string>> {
  const retries = opts.retries ?? 2;
  const timeoutMs = opts.timeoutMs ?? 12000;
  const breakerThreshold = opts.breakerThreshold ?? 5;
  const cacheTtl = opts.cacheTtl ?? 300000;
  const host = hostOf(url);
  const key = `TEXT:${opts.method || 'GET'}:${url}`;

  if (breakerOpen(host, breakerThreshold)) {
    const entry = cache.get(key);
    if (entry) {
      const age = Date.now() - entry.at;
      return {
        data: entry.data as string,
        status: age < entry.ttl ? 'cached' : 'degraded',
        source: host,
        cachedAt: new Date(entry.at).toISOString(),
        error: 'circuit-breaker-open',
      };
    }
    return { data: null, status: 'unavailable', source: host, error: 'circuit-breaker-open' };
  }

  let lastErr = '';
  for (let attempt = 0; attempt <= retries; attempt++) {
    const { signal, cancel } = withTimeout(timeoutMs);
    try {
      const res = await fetch(url, {
        method: opts.method || 'GET',
        headers: opts.headers,
        body: opts.body,
        signal,
      });
      cancel();
      if (!res.ok) {
        if ((res.status >= 500 || res.status === 429) && attempt < retries) {
          lastErr = `HTTP ${res.status}`;
          const retryAfter = parseInt(res.headers.get('retry-after') || '', 10);
          const delay = res.status === 429 ? 2500 * Math.pow(2, attempt) : 400 * Math.pow(2, attempt);
          await new Promise((r) => setTimeout(r, retryAfter ? Math.min(retryAfter * 1000, 8000) : delay));
          continue;
        }
        const entry = cache.get(key);
        if (entry) {
          const age = Date.now() - entry.at;
          return {
            data: entry.data as string,
            status: age < entry.ttl ? 'cached' : 'degraded',
            source: host,
            cachedAt: new Date(entry.at).toISOString(),
            error: `HTTP ${res.status}`,
          };
        }
        return { data: null, status: 'unavailable', source: host, error: `HTTP ${res.status}` };
      }
      const text = await res.text();
      cache.set(key, { data: text, at: Date.now(), ttl: cacheTtl });
      recordSuccess(host);
      return { data: text, status: 'live', source: host };
    } catch (e) {
      cancel();
      lastErr = (e as Error).message || 'fetch error';
      if (attempt < retries) {
        await new Promise((r) => setTimeout(r, 400 * Math.pow(2, attempt)));
        continue;
      }
    }
  }
  recordFailure(host);
  const entry = cache.get(key);
  if (entry) {
    const age = Date.now() - entry.at;
    return {
      data: entry.data as string,
      status: age < entry.ttl ? 'cached' : 'degraded',
      source: host,
      cachedAt: new Date(entry.at).toISOString(),
      error: lastErr,
    };
  }
  return { data: null, status: 'unavailable', source: host, error: lastErr };
}