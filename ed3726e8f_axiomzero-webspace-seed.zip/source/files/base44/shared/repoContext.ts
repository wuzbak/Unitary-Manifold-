/**
 * repoContext.ts — Shared module: fetches + caches live repository context.
 *
 * Used by both fetchRepoContext and oxQuery backend functions.
 * Single source of truth: https://github.com/wuzbak/Unitary-Manifold-
 *
 * Cache strategy: module-level variables persist across requests within the
 * same isolate lifecycle. TTL = 1 hour. forceRefresh clears the cache.
 */

const REPO_BASE = 'https://raw.githubusercontent.com/wuzbak/Unitary-Manifold-/main/';
const CACHE_TTL = 3600 * 1000; // 1 hour

let statusCache = null;
let trimmedContextCache = null;
let fullContextCache = null;

async function fetchRaw(path) {
  try {
    const res = await fetch(REPO_BASE + path, {
      headers: { 'User-Agent': 'AxiomZero-App' },
    });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

/**
 * Parse STATUS.md first line for live values.
 * Fallback when the machine-readable JSON artifact is unavailable.
 * Expected format: "v23.2 | Sprint AR | 57,450 tests | 1,066 lean4 | 794 pillars | 795 next"
 */
function parseStatusMd(content) {
  // STATUS.md is prose-based: version in italic header, counts embedded in text.
  // Parse the first ~5000 chars for all relevant values.
  const head = content.slice(0, 5000);

  const versionMatch = head.match(/v(\d+\.\d+)/);
  const sprintMatch = head.match(/Sprint\s+([A-Z]{1,2})/);
  const testsMatch = head.match(/~?([\d,]+)\s*passed/i);
  const skippedMatch = head.match(/([\d,]+)\s*skipped/i);
  const failedMatch = head.match(/([\d,]+)\s*failed/i);
  // Lean4: "Lean4 +105 (1141→1246)" — take the maximum final value across all
  // Lean4-tagged progressions. The latest sprint always has the highest count.
  const lean4Matches = [...content.matchAll(/Lean4[^)]*?\((\d{3,4})\s*→\s*(\d{3,4})\)/gi)];
  const lean4Final = lean4Matches.length > 0
    ? Math.max(...lean4Matches.map((m) => parseInt(m[2])))
    : 0;
  const nextSlotMatch = head.match(/next slot\s*(\d+)/i);

  return {
    version: versionMatch ? 'v' + versionMatch[1] : 'unknown',
    sprint: sprintMatch ? 'Sprint ' + sprintMatch[1] : 'unknown',
    testsPassed: testsMatch ? parseInt(testsMatch[1].replace(/,/g, '')) : 0,
    testsSkipped: skippedMatch ? parseInt(skippedMatch[1].replace(/,/g, '')) : 0,
    testsFailed: failedMatch ? parseInt(failedMatch[1].replace(/,/g, '')) : 0,
    lean4Theorems: lean4Final,
    nextPillarSlot: nextSlotMatch ? parseInt(nextSlotMatch[1]) : 0,
    pillarsTotal: nextSlotMatch ? parseInt(nextSlotMatch[1]) - 1 : 0,
    source: 'STATUS.md (parsed)',
    fetchedAt: new Date().toISOString(),
  };
}

/**
 * Get live status — primary: um_live_status.json, fallback: parse STATUS.md.
 */
export async function getLiveStatus() {
  if (statusCache && Date.now() - statusCache.fetchedAt < CACHE_TTL) {
    return statusCache.data;
  }

  // Primary: machine-readable JSON artifact (committed by the repo sprint pipeline)
  const jsonContent = await fetchRaw('9-INFRASTRUCTURE/um_live_status.json');
  if (jsonContent) {
    try {
      const data = JSON.parse(jsonContent);
      data.source = data.source || 'um_live_status.json';
      data.fetchedAt = new Date().toISOString();
      statusCache = { data, fetchedAt: Date.now() };
      return data;
    } catch {
      // Fall through to STATUS.md parsing
    }
  }

  // Fallback: parse STATUS.md prose
  const statusMd = await fetchRaw('STATUS.md');
  if (statusMd) {
    const parsed = parseStatusMd(statusMd);
    statusCache = { data: parsed, fetchedAt: Date.now() };
    return parsed;
  }

  return null;
}

/**
 * Get trimmed context (~5k tokens) — STATUS.md + FALLIBILITY.md.
 * Used for high-frequency assistant chat (Gemini Flash tier).
 */
export async function getTrimmedContext() {
  if (trimmedContextCache && Date.now() - trimmedContextCache.fetchedAt < CACHE_TTL) {
    return trimmedContextCache.data;
  }

  const [statusMd, fallibilityMd] = await Promise.all([
    fetchRaw('STATUS.md'),
    fetchRaw('FALLIBILITY.md'),
  ]);

  const parts = [];
  if (statusMd) parts.push('=== STATUS.md ===\n' + statusMd.slice(0, 8000));
  if (fallibilityMd) parts.push('=== FALLIBILITY.md ===\n' + fallibilityMd.slice(0, 8000));

  if (parts.length === 0) {
    return 'Framework context unavailable — repository fetch failed.';
  }

  const context = parts.join('\n\n');
  trimmedContextCache = { data: context, fetchedAt: Date.now() };
  return context;
}

/**
 * Get full context (~85k tokens) — ox_full_context.md.
 * Used for Interrogator KB, Oracle synthesis, OmegaHolon analysis (Claude Sonnet tier).
 * Falls back to trimmed context if the full pack is unavailable.
 */
export async function getFullContext() {
  if (fullContextCache && Date.now() - fullContextCache.fetchedAt < CACHE_TTL) {
    return fullContextCache.data;
  }

  const content = await fetchRaw('9-INFRASTRUCTURE/ox_full_context.md');
  if (content && content.length > 1000) {
    fullContextCache = { data: content, fetchedAt: Date.now() };
    return content;
  }

  // Fallback to trimmed if full context unavailable
  return await getTrimmedContext();
}

export function clearCache() {
  statusCache = null;
  trimmedContextCache = null;
  fullContextCache = null;
}