/**
 * Manifold Version Timeline — maps calendar dates to Unitary Manifold sprint versions.
 *
 * Used by psicatRadioUpload and psicatRadioBuildPlaylist to tag each media track
 * with the manifold version (V#) that was active when the media was originally
 * created. This lets PsiCat Radio sequence tracks by manifold-version alignment.
 *
 * Source: UM_STATUS sprint history (um_live_status.json). Dates are anchored to
 * the latest sprint (v36.7 · 2026-09-08) and interpolated backwards at roughly
 * one sprint per month. Earlier sprints use the committed date anchors where
 * available; pre-v23.2 maps to "pre-manifold".
 */

interface SprintAnchor {
  version: string;
  date: string; // ISO date — the sprint was active ON OR AFTER this date
}

// Ordered newest-first (same as UM_STATUS.sprints). Dates are approximate
// month-anchored boundaries working backwards from 2026-09-08.
const SPRINT_ANCHORS: SprintAnchor[] = [
  { version: 'v36.7', date: '2026-09-01' },
  { version: 'v36.4', date: '2026-07-01' },
  { version: 'v35.7', date: '2026-05-01' },
  { version: 'v35.6', date: '2026-04-01' },
  { version: 'v35.5', date: '2026-03-01' },
  { version: 'v35.4', date: '2026-02-01' },
  { version: 'v35.3', date: '2026-01-01' },
  { version: 'v35.2', date: '2025-12-01' },
  { version: 'v35.0', date: '2025-11-01' },
  { version: 'v34.9', date: '2025-10-01' },
  { version: 'v34.8', date: '2025-09-01' },
  { version: 'v34.2', date: '2025-08-01' },
  { version: 'v34.0', date: '2025-07-01' },
  { version: 'v33.5', date: '2025-06-01' },
  { version: 'v33.4', date: '2025-05-01' },
  { version: 'v33.3', date: '2025-04-01' },
  { version: 'v33.2', date: '2025-03-01' },
  { version: 'v33.1', date: '2025-02-01' },
  { version: 'v33.0', date: '2025-01-01' },
  { version: 'v32.1', date: '2024-11-01' },
  { version: 'v24.6', date: '2024-06-01' },
  { version: 'v24.1', date: '2024-03-01' },
  { version: 'v23.2', date: '2024-01-01' },
];

/**
 * Compute the manifold version active on a given date.
 * Returns the V# string, or "pre-manifold" for dates before v23.2.
 * Returns "unknown" for invalid/empty dates.
 */
export function computeManifoldVersion(dateStr: string): string {
  if (!dateStr || typeof dateStr !== 'string') return 'unknown';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return 'unknown';

  for (const anchor of SPRINT_ANCHORS) {
    if (d >= new Date(anchor.date)) {
      return anchor.version;
    }
  }
  return 'pre-manifold';
}

/**
 * Get the full sprint anchor list (for display or debugging).
 */
export function getManifoldTimeline(): SprintAnchor[] {
  return SPRINT_ANCHORS;
}