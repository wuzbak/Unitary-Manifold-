/**
 * Shared source normalizer for AXIOM live-fetch backend functions.
 * Each fetcher returns an array of normalized source records via this helper,
 * so the Researcher agent logs a consistent shape regardless of the upstream API.
 *
 * Theory, methodology: ThomasCory Walker-Pearson / AxiomZero Technologies & Consulting, SPC.
 * Implementation: GitHub Copilot (AI).
 */

export interface NormalizedSource {
  title: string;
  tier: number;
  source_type: string;
  url_or_ref: string;
  date: string;
  excerpt: string;
  raw_metadata: Record<string, any>;
}

export function makeSource(fields: {
  title: string;
  tier: number;
  source_type: string;
  url_or_ref?: string;
  date?: string;
  excerpt?: string;
  raw_metadata?: Record<string, any>;
}): NormalizedSource {
  return {
    title: fields.title || 'Untitled record',
    tier: fields.tier,
    source_type: fields.source_type || '',
    url_or_ref: fields.url_or_ref || '',
    date: fields.date || '',
    excerpt: (fields.excerpt || '').slice(0, 500),
    raw_metadata: fields.raw_metadata || {},
  };
}

export function okResponse(sources: NormalizedSource[], query: string, source_name: string) {
  return Response.json({ sources, query, source_name, count: sources.length, status: 'ok' });
}

export function errResponse(query: string, source_name: string, error: string) {
  // Graceful degradation: HTTP 200 with empty results + status, so the frontend
  // renders a quiet "unavailable" state instead of surfacing a 500 toast.
  return Response.json({ sources: [], query, source_name, count: 0, error, status: 'unavailable', message: error });
}

export async function readQuery(req: Request): Promise<{ query: string; body: any }> {
  const body = await req.json().catch(() => ({}));
  const query = String(body.query || body.q || body.entity || body.name || '').trim();
  return { query, body };
}