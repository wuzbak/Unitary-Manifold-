import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { secrets } from 'base44:runtime';
import { makeSource, okResponse, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'SEC EDGAR', 'No query provided');
    // SEC EDGAR requires a contact email in the User-Agent header (fair-access policy).
    // If the secret is unset, we surface a graceful "not configured" gap rather than crashing.
    let contactEmail = '';
    try { contactEmail = secrets.get('SEC_EDGAR_CONTACT_EMAIL') || ''; } catch { contactEmail = ''; }
    if (!contactEmail) return errResponse(query, 'SEC EDGAR', 'SEC_EDGAR_CONTACT_EMAIL not set — configure it to enable SEC filings fetch');
    const url = `https://efts.sec.gov/LATEST/search-index?q=${encodeURIComponent(query)}&forms=10-K,10-Q,8-K,4,SC-13D`;
    const res = await fetch(url, { headers: { 'User-Agent': `AxiomZero AXIOM Journalist ${contactEmail}` } });
    if (!res.ok) return errResponse(query, 'SEC EDGAR', `API ${res.status}`);
    const data = await res.json();
    const hits = (data.hits && data.hits.hits) || [];
    const sources = hits.slice(0, 10).map((h: any) => {
      const s = h._source || {};
      const adsh = s.adsh || '';
      const cik = Array.isArray(s.ciks) ? s.ciks[0] : (s.cik || '');
      const cikNum = cik ? String(parseInt(cik, 10)) : '';
      const displayName = Array.isArray(s.display_names) ? s.display_names[0] : (s.entity_name || s.company_name || query);
      const form = s.form || s.root_forms?.[0] || s.file_type || 'Filing';
      return makeSource({
        title: `SEC EDGAR: ${form} — ${displayName}`,
        tier: 1, source_type: `SEC filing (${form})`,
        url_or_ref: adsh && cikNum ? `https://www.sec.gov/Archives/edgar/data/${cikNum}/${adsh.replace(/-/g, '')}/` : (cik ? `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=${cik}&type=${encodeURIComponent(form)}` : ''),
        date: s.file_date || s.period_ending || '',
        excerpt: `Form: ${form} · Filer: ${displayName} · Filed: ${s.file_date || 'N/A'} · CIK: ${cik || 'N/A'}`,
        raw_metadata: s,
      });
    });
    return okResponse(sources, query, 'SEC EDGAR');
  } catch (error) {
    return errResponse('', 'SEC EDGAR', (error as Error).message);
  }
}