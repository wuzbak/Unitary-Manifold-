import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { isBlockedStation } from '../../shared/stationBlocklist.ts';

/**
 * globalStationSearch — resolves any global zip code or city name to a
 * country/region via Nominatim (free, no key), queries the Radio Browser API
 * for streamable internet radio stations in that area, caches results as
 * SdrStation records for instant repeat searches, and returns grouped stations.
 *
 * Flow:
 *   1. Resolve query → { lat, lon, country, state, city, region } via Nominatim
 *   2. Check SdrStation cache for this region + source='radio_browser_api'
 *   3. If cache miss → query Radio Browser API by country/state
 *   4. Filter to streamable stations (non-empty URL, lastcheckok, valid codec)
 *   5. Cache as SdrStation records via asServiceRole (bypasses admin-only RLS)
 *   6. Return grouped stations + resolved geo info
 */

const NOMINATIM_URL = 'https://nominatim.openstreetmap.org/search';
const RADIO_BROWSER_MIRRORS = [
  'https://all.api.radio-browser.info',
  'https://fi1.api.radio-browser.info',
  'https://de1.api.radio-browser.info',
  'https://nl1.api.radio-browser.info',
];
const VALID_CODECS = ['MP3', 'AAC', 'AAC+', 'OGG', 'FLAC', 'OPUS'];
const MAX_RESULTS = 60;
const USER_AGENT = 'AxiomZero-SDR-Radio/1.0 (https://axiomzero-webspace-prototype.base44.app)';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    // Public endpoint — no auth gate. SdrStation has public read RLS ({}) and
    // writes use asServiceRole, so anonymous visitors can search globally.

    const body = await req.json().catch(() => ({}));
    const query: string = (body?.query || '').trim();
    if (!query) return Response.json({ error: 'Query is required' }, { status: 400 });

    // 1. Resolve query via Nominatim
    const geo = await resolveGeo(query);
    if (!geo) {
      return Response.json({
        error: 'Could not resolve location. Try a city name or zip code.',
        query,
      }, { status: 404 });
    }

    // 2. Check cache — SdrStation records with this region + radio_browser_api source
    let cached: any[] = [];
    try {
      cached = await base44.entities.SdrStation.filter({
        region: geo.region,
        source: 'radio_browser_api',
      }, '-created_date', 200);
    } catch (e) {
      // If filter fails, proceed to API search
    }

    let stations: any[];
    let fromCache = false;

    if (cached && cached.length > 0) {
      stations = cached;
      fromCache = true;
    } else {
      // 3. Query Radio Browser API
      const apiStations = await searchRadioBrowser(geo);

      // 4. Normalize + cache
      if (apiStations.length > 0) {
        const records = apiStations.map(s => normalizeStation(s, geo)).filter(s => !isBlockedStation(s));
        try {
          await base44.asServiceRole.entities.SdrStation.bulkCreate(records);
        } catch (e) {
          // If cache write fails, still return the results
        }
        stations = records;
      } else {
        stations = [];
      }
    }

    // 5. Filter blocked stations and return grouped results
    stations = stations.filter(s => !isBlockedStation(s));
    const grouped = {
      fm: stations.filter(s => s.station_type === 'fm' || s.station_type === 'wa_fm'),
      am: stations.filter(s => s.station_type === 'am' || s.station_type === 'wa_am'),
      internet_stream: stations.filter(s => s.station_type === 'internet_stream'),
      web_sdr: stations.filter(s => s.station_type === 'web_sdr'),
    };

    return Response.json({
      query,
      resolved: geo,
      fromCache,
      total: stations.length,
      groups: grouped,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

/**
 * Resolve a zip code or city name to geo coordinates + address via Nominatim.
 */
async function resolveGeo(query: string): Promise<any | null> {
  try {
    // If query looks like a US zip code (5 digits), bias to US
    const isUsZip = /^\d{5}$/.test(query.trim());
    const countryCodeParam = isUsZip ? '&countrycodes=us' : '';
    const url = `${NOMINATIM_URL}?q=${encodeURIComponent(query)}&format=json&limit=1&addressdetails=1${countryCodeParam}`;
    const res = await fetch(url, {
      headers: {
        'User-Agent': USER_AGENT,
        'Accept': 'application/json',
      },
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (!data || data.length === 0) return null;

    const result = data[0];
    const addr = result.address || {};

    const city = addr.city || addr.town || addr.village || addr.hamlet || addr.county || '';
    const state = addr.state || '';
    const country = addr.country || '';
    const region = city || state || country || result.display_name || query;

    return {
      lat: parseFloat(result.lat),
      lon: parseFloat(result.lon),
      country,
      state,
      city,
      region,
      displayName: result.display_name,
    };
  } catch (e) {
    return null;
  }
}

/**
 * Query Radio Browser API for streamable stations by country + state.
 * Falls back to country-only if state-level search returns nothing.
 */
async function searchRadioBrowser(geo: any): Promise<any[]> {
  for (const mirror of RADIO_BROWSER_MIRRORS) {
    try {
      // Build search URL — by country + state
      let url = `${mirror}/json/stations/search?limit=${MAX_RESULTS}&order=clickcount&reverse=true&hidebroken=true`;
      if (geo.country) url += `&country=${encodeURIComponent(geo.country)}`;
      if (geo.state) url += `&state=${encodeURIComponent(geo.state)}`;

      const res = await fetch(url, {
        headers: {
          'User-Agent': USER_AGENT,
          'Accept': 'application/json',
        },
      });

      if (!res.ok) continue;
      let data = await res.json();

      // Fallback: if state-level search returns nothing, try country-only
      if ((!data || data.length === 0) && geo.state && geo.country) {
        let url2 = `${mirror}/json/stations/search?limit=${MAX_RESULTS}&order=clickcount&reverse=true&hidebroken=true&country=${encodeURIComponent(geo.country)}`;
        const res2 = await fetch(url2, {
          headers: {
            'User-Agent': USER_AGENT,
            'Accept': 'application/json',
          },
        });
        if (res2.ok) {
          data = await res2.json();
        }
      }

      if (data && data.length > 0) {
        // Filter to streamable stations with valid codecs
        return data.filter((s: any) =>
          s.url_resolved &&
          s.url_resolved.length > 0 &&
          s.lastcheckok === 1 &&
          VALID_CODECS.includes(s.codec)
        ).slice(0, MAX_RESULTS);
      }

      // If this mirror returned empty but didn't error, try next mirror
      continue;
    } catch (e) {
      // Try next mirror
      continue;
    }
  }
  return [];
}

/**
 * Normalize a Radio Browser API station to the SdrStation schema.
 */
function normalizeStation(apiStation: any, geo: any): any {
  const tags = (apiStation.tags || '').toLowerCase();
  let stationType = 'internet_stream';
  // Classify as FM/AM simulcast if tagged and has geo coordinates
  if (tags.includes('fm') && apiStation.geo_lat) stationType = 'fm';
  else if (tags.includes('am') && apiStation.geo_lat) stationType = 'am';

  const codecInfo = [apiStation.codec, apiStation.bitrate ? `${apiStation.bitrate}kbps` : ''].filter(Boolean).join(' ');

  return {
    name: (apiStation.name || 'Unknown Station').trim(),
    station_type: stationType,
    band: stationType === 'fm' ? 'FM' : stationType === 'am' ? 'AM' : 'Internet',
    region: geo.region,
    country: geo.country || '',
    frequency_mhz: 0,
    stream_url: apiStation.url_resolved || apiStation.url || '',
    embed_url: '',
    description: codecInfo || 'Internet radio stream',
    status: 'active',
    geo_lat: apiStation.geo_lat || geo.lat || 0,
    geo_lng: apiStation.geo_long || geo.lon || 0,
    source: 'radio_browser_api',
  };
}