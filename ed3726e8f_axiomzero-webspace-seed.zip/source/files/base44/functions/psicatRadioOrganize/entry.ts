import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { getManifoldTimeline } from '../../shared/manifoldVersionTimeline.ts';

/**
 * psicatRadioOrganize — PsiCat analyzes the entire media library, proposes a
 * tier taxonomy, assigns each track to a tier with a refined date, and
 * auto-removes exact duplicates.
 *
 * Flow:
 *   1. Load all PsiCatRadioTrack records
 *   2. Dedup: group by (title + original_size_bytes + duration_seconds), keep oldest
 *   3. Build a compact manifest of surviving tracks
 *   4. InvokeLLM with the manifest + manifold version timeline to propose tiers + dates
 *   5. Update each track with tier + proposed_date
 *
 * Returns: { tier_taxonomy, summary, duplicates_removed, tracks_organized, total_tracks }
 */
export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // ── Step 1: Load all tracks ──
    const tracks = await base44.entities.PsiCatRadioTrack.list('-created_date', 500);

    // ── Step 2: Dedup ──
    const groups: Record<string, any[]> = {};
    for (const t of tracks) {
      const key = `${t.title}|${t.original_size_bytes || 0}|${t.duration_seconds || 0}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(t);
    }

    let duplicatesRemoved = 0;
    const toDelete: string[] = [];
    const surviving: any[] = [];

    for (const key of Object.keys(groups)) {
      const group = groups[key];
      if (group.length > 1) {
        group.sort((a, b) => {
          const da = new Date(a.created_date || a.date_created || 0).getTime();
          const db = new Date(b.created_date || b.date_created || 0).getTime();
          return da - db;
        });
        surviving.push(group[0]);
        for (let i = 1; i < group.length; i++) {
          toDelete.push(group[i].id);
          duplicatesRemoved++;
        }
      } else {
        surviving.push(group[0]);
      }
    }

    for (const id of toDelete) {
      try {
        await base44.entities.PsiCatRadioTrack.delete(id);
      } catch (e) {
        /* skip */
      }
    }

    if (surviving.length === 0) {
      return Response.json({
        tier_taxonomy: [],
        summary: 'The media library is empty — upload tracks first, then I can organize them.',
        duplicates_removed: duplicatesRemoved,
        tracks_organized: 0,
        total_tracks: 0,
      });
    }

    // ── Step 3: Build manifest ──
    const manifest = surviving.map((t, i) => ({
      idx: i,
      title: t.title,
      duration: t.duration_seconds || 0,
      date: t.date_created || '',
      v: t.manifold_version || 'unknown',
      folder: t.source_folder || '',
      size: t.original_size_bytes || 0,
      media_type: t.media_type || 'audio',
    }));

    const timeline = getManifoldTimeline()
      .map((a) => `${a.version} (${a.date})`)
      .join(', ');

    // ── Step 4: InvokeLLM for tier proposal ──
    const prompt = `You are PsiCat — the autonomous archivist and DJ for the Unitary Manifold media archive.

Analyze the media library below and propose a TIER taxonomy that organizes the tracks by their significance, complexity, and role in the manifold's evolution. Also propose a refined creation date for each track.

MANIFOLD VERSION TIMELINE (newest first):
${timeline}

TRACK LIBRARY (${surviving.length} tracks):
${JSON.stringify(manifest, null, 0)}

RULES:
1. Propose 4-6 tier labels (e.g., "Foundational", "Core", "Advanced", "Frontier", "Transitional") — choose names that fit the content and the manifold's evolution.
2. Assign each track to exactly one tier.
3. Propose a refined date for each track — use the existing date if it seems accurate, or infer a better date from the manifold version, title context, and folder structure. The date should reflect when the media was likely created in the repo's history.
4. Write a 1-sentence note for each track explaining what it likely contains and why it's in that tier.
5. Consider the source_folder and title for context — test files, short clips, and experimental audio may belong in different tiers than full-length content.

Return JSON with this exact schema:
{
  "tier_taxonomy": [
    { "tier": "<name>", "description": "<1 sentence>", "count": <number> }
  ],
  "assignments": [
    { "idx": <track index>, "tier": "<tier name>", "proposed_date": "<YYYY-MM-DD>", "note": "<1 sentence>" }
  ],
  "summary": "<2-3 sentence PsiCat commentary on the archive's structure and what the tiers reveal>"
}`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          tier_taxonomy: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                tier: { type: 'string' },
                description: { type: 'string' },
                count: { type: 'number' },
              },
              required: ['tier', 'description', 'count'],
            },
          },
          assignments: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                idx: { type: 'number' },
                tier: { type: 'string' },
                proposed_date: { type: 'string' },
                note: { type: 'string' },
              },
              required: ['idx', 'tier', 'proposed_date'],
            },
          },
          summary: { type: 'string' },
        },
        required: ['tier_taxonomy', 'assignments', 'summary'],
      },
    });

    // ── Step 5: Update tracks with tier + proposed_date ──
    let updated = 0;
    for (const assignment of response.assignments || []) {
      const track = surviving[assignment.idx];
      if (!track) continue;
      try {
        await base44.entities.PsiCatRadioTrack.update(track.id, {
          tier: assignment.tier || '',
          proposed_date: assignment.proposed_date || '',
        });
        updated++;
      } catch (e) {
        /* skip update errors */
      }
    }

    return Response.json({
      tier_taxonomy: response.tier_taxonomy || [],
      summary: response.summary || 'PsiCat has organized the archive.',
      duplicates_removed: duplicatesRemoved,
      tracks_organized: updated,
      total_tracks: surviving.length,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}