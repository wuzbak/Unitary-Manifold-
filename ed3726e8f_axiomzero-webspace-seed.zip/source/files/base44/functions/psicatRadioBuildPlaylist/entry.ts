import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

/**
 * psicatRadioBuildPlaylist — PsiCat autonomous DJ with tier-aware sequencing.
 *
 * Reads the audio PsiCatRadioTrack library and uses InvokeLLM to autonomously
 * sequence a continuous playlist. Tracks are grouped into era blocks by tier
 * then by manifold-version (V#) then by date, with per-track expert commentary
 * explaining why each track was selected and its context in the manifold's
 * evolution.
 *
 * Supports an optional `focus_tier` or `focus_era` parameter to let the user
 * request a specific tier or era for live interaction.
 */
export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Parse optional focus parameters from request body
    let focusTier = '';
    let focusEra = '';
    let userRequest = '';
    try {
      const body = await req.json();
      focusTier = body.focus_tier || '';
      focusEra = body.focus_era || '';
      userRequest = body.user_request || '';
    } catch {
      // GET or empty body — no focus
    }

    // Load all audio tracks
    const tracks = await base44.entities.PsiCatRadioTrack.filter(
      { media_type: 'audio' },
      '-date_created',
      500,
    );

    if (!tracks.length) {
      return Response.json({
        playlist: [],
        commentary:
          "PsiCat Radio is off-air — the media library has no audio tracks yet. Upload your audio archive and I'll build the broadcast.",
        total_duration: 0,
        track_count: 0,
        tier_taxonomy: [],
      });
    }

    // Compact track manifest for the LLM — includes tier + proposed_date
    const manifest = tracks.map((t, i) => ({
      idx: i,
      title: t.title,
      duration: t.duration_seconds || 0,
      date: t.proposed_date || t.date_created || '',
      v: t.manifold_version || 'unknown',
      tier: t.tier || 'untiered',
      tags: (() => {
        try {
          return JSON.parse(t.tags_json || '[]');
        } catch {
          return [];
        }
      })(),
    }));

    // Build tier summary for the prompt
    const tierCounts: Record<string, number> = {};
    for (const t of manifest) {
      tierCounts[t.tier] = (tierCounts[t.tier] || 0) + 1;
    }
    const tierSummary = Object.entries(tierCounts)
      .map(([tier, count]) => `${tier} (${count} tracks)`)
      .join(', ');

    const focusInstruction = focusTier
      ? `\n\nUSER REQUEST: The listener has requested to hear tracks from the "${focusTier}" tier. Prioritize tracks in this tier, but you may include transitional tracks from adjacent tiers to create flow.`
      : focusEra
        ? `\n\nUSER REQUEST: The listener has requested to hear tracks from the "${focusEra}" manifold era. Prioritize tracks with manifold_version matching or near "${focusEra}".`
        : userRequest
          ? `\n\nUSER REQUEST: ${userRequest}`
          : '';

    const prompt = `You are PsiCat — the autonomous DJ for PsiCat Radio, an AI radio station that broadcasts from the Unitary Manifold media archive.

Your job: build a continuous audio playlist from the track library below. You are a master radioman, DJ, and communications engineer who deeply understands the manifold's physics, the repository's evolution, and the story each track tells.

TIER TAXONOMY (tracks are pre-classified into tiers):
${tierSummary}

SEQUENCING RULES:
1. Group tracks into "era blocks" by TIER first — play through tiers in a deliberate order that tells the story of the manifold's evolution (e.g., Foundational → Core → Advanced → Frontier, or whatever order reveals the narrative arc).
2. Within each tier block, order by manifold-version (V#) alignment — group tracks from the same sprint together.
3. Within each version group, order by proposed/refined date (chronological).
4. Suggest crossfade timing (in seconds) between tracks — longer crossfades (4-8s) for ambient/transition tracks, shorter (0-3s) for distinct content.
5. For each track, write a "note" — a 1-2 sentence expert DJ commentary explaining what this track is about, its significance in the manifold's evolution, and why it's placed here in the broadcast.
6. Open with a strong track from the foundational tier and close with a reflective track if the library supports it.
7. Include ALL tracks in the playlist — every track gets played.
${focusInstruction}

Return a JSON object with this exact schema:
{
  "commentary": "A 2-4 sentence PsiCat DJ intro — your voice opening the broadcast, referencing the tiers and manifold eras you'll be traversing, and the story the archive tells",
  "playlist": [
    { "idx": <track index from manifest>, "crossfade_in_seconds": <number 0-8>, "note": "<1-2 sentence expert DJ note about this track's content and significance>" }
  ]
}

TRACK LIBRARY (${tracks.length} audio tracks):
${JSON.stringify(manifest, null, 0)}

Build the playlist now. Return only the JSON object.`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          commentary: { type: 'string' },
          playlist: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                idx: { type: 'number' },
                crossfade_in_seconds: { type: 'number' },
                note: { type: 'string' },
              },
              required: ['idx', 'note'],
            },
          },
        },
        required: ['commentary', 'playlist'],
      },
    });

    // Map LLM playlist back to full track records
    const orderedPlaylist = (response.playlist || [])
      .map((entry) => {
        const track = tracks[entry.idx];
        if (!track) return null;
        return {
          id: track.id,
          title: track.title,
          file_url: track.file_url,
          duration_seconds: track.duration_seconds,
          date_created: track.proposed_date || track.date_created,
          manifold_version: track.manifold_version,
          tier: track.tier || '',
          crossfade_in_seconds: entry.crossfade_in_seconds || 3,
          note: entry.note || '',
        };
      })
      .filter(Boolean);

    const totalDuration = orderedPlaylist.reduce(
      (sum, t) => sum + (t.duration_seconds || 0),
      0,
    );

    return Response.json({
      playlist: orderedPlaylist,
      commentary: response.commentary || 'PsiCat Radio — broadcasting from the manifold archive.',
      total_duration: totalDuration,
      track_count: orderedPlaylist.length,
      tier_taxonomy: Object.entries(tierCounts).map(([tier, count]) => ({
        tier,
        count,
      })),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}