/**
 * generateCrawlManifest — Public, read-only crawl-artifact generator.
 * Treats wuzbak/Unitary-Manifold- as the immutable source of truth.
 * Fetches repo commit metadata + README, derives robots.txt, sitemap.xml,
 * llms.txt, JSON-LD blocks, and the canonical route list. Zero write-backs.
 */
const BASE_URL = 'https://axiomzerospc.org';
const REPO = 'wuzbak/Unitary-Manifold-';

const ROUTES = [
  { path: '/', label: 'Topology', desc: '13D toroidal manifold visualization', category: 'Core', priority: '1.0' },
  { path: '/cognitive-layer', label: 'Cognitive Layer', desc: '7-manager AI pipeline', category: 'Core', priority: '1.0' },
  { path: '/repository', label: 'Repository', desc: 'Full code browser (v23.2)', category: 'Core', priority: '1.0' },
  { path: '/compactification', label: 'Compactification', desc: 'Singular seed kernel (5, 7, 74)', category: 'Core', priority: '1.0' },
  { path: '/about', label: 'About', desc: 'Mission and consulting pillars', category: 'Core', priority: '1.0' },
  { path: '/projects', label: 'Projects', desc: '15-product portfolio (12-AZ-IP)', category: 'Core', priority: '1.0' },
  { path: '/az-products', label: 'AZ Products', desc: '18 interactive product apps', category: 'Core', priority: '1.0' },
  { path: '/orientation-portals', label: 'Portals', desc: 'Audience entry hubs', category: 'Core', priority: '1.0' },
  { path: '/manifold-explorer', label: 'Manifold Explorer', desc: '3D atlas, binaries, constants, docs', category: 'Core', priority: '1.0' },
  { path: '/corporate', label: 'Corporate', desc: 'Charter and compliance (SPC)', category: 'Governance', priority: '0.6' },
  { path: '/pentad-governance', label: 'Pentad', desc: 'Framework and 5-sector dashboard', category: 'Governance', priority: '0.6' },
  { path: '/governance-ledger', label: 'Gov Ledger', desc: 'Decisions and audit trail', category: 'Governance', priority: '0.6' },
  { path: '/labs', label: 'Labs and Sandbox', desc: 'Interactive, dev, STEM, notebook', category: 'Tools', priority: '0.8' },
  { path: '/training-gym', label: 'Training Gym', desc: 'Console, analytics, catalog, thermo, registry', category: 'Tools', priority: '0.8' },
  { path: '/merlin', label: 'Merlin Hub', desc: 'Chat, research, docs', category: 'Tools', priority: '0.8' },
  { path: '/delphi', label: 'DelPhi Oracle', desc: '5 oracles and Manifold Read', category: 'Tools', priority: '0.8' },
  { path: '/axiom-journalist', label: 'AXIOM Journalist', desc: 'Investigative journalism AI', category: 'Tools', priority: '0.8' },
  { path: '/filmers-companion', label: "Filmer's Companion", desc: 'AI film production suite', category: 'Tools', priority: '0.8' },
  { path: '/falsification-lab', label: 'Falsification Lab', desc: 'Observatory and interrogator', category: 'Tools', priority: '0.8' },
  { path: '/lens-suite', label: 'Lens Suite', desc: 'Quantum and ethical diagnostics', category: 'Tools', priority: '0.8' },
  { path: '/flashcard-trainer', label: 'Flashcard Trainer', desc: '60 cards, 7 categories', category: 'Tools', priority: '0.8' },
  { path: '/knowledge-hub', label: 'Knowledge Hub', desc: 'Docs, FAQ, glossary, API', category: 'Knowledge', priority: '0.7' },
  { path: '/resource-library', label: 'Resource Library', desc: 'Curated resources', category: 'Knowledge', priority: '0.7' },
  { path: '/technology-roadmap', label: 'Roadmap', desc: 'Development phases', category: 'Knowledge', priority: '0.7' },
  { path: '/ethical-synthesis', label: 'Ethical Synthesis', desc: '3-tier guardrail system', category: 'Knowledge', priority: '0.7' },
  { path: '/lean4-formalization', label: 'Lean4 Formalization', desc: '1,066 verified theorems', category: 'Knowledge', priority: '0.7' },
  { path: '/system-status', label: 'System Status', desc: 'Verification and telemetry', category: 'System', priority: '0.6' },
  { path: '/eclipsa-integrity', label: 'ECLIPSA Console', desc: 'Status, guardrails, audit, alerts', category: 'System', priority: '0.6' },
  { path: '/task-management', label: 'Tasks', desc: 'Work queue', category: 'System', priority: '0.6' },
  { path: '/data-provenance', label: 'Provenance', desc: 'Supply chain audit', category: 'System', priority: '0.6' },
  { path: '/axiom-archive', label: 'Archive', desc: 'Version history', category: 'System', priority: '0.6' },
  { path: '/safety', label: 'Safety and Emergency', desc: 'HILS invariants and recovery', category: 'System', priority: '0.6' },
  { path: '/unitary-sos', label: 'SOS', desc: 'Scientific operating system', category: 'System', priority: '0.6' },
  { path: '/axiom-os-core', label: 'AxiomOS', desc: 'Kernel architecture (3 tabs)', category: 'System', priority: '0.6' },
  { path: '/axiom-ledger', label: 'Axiom Ledger', desc: 'State records', category: 'System', priority: '0.6' },
  { path: '/client-inquiry', label: 'Inquiry', desc: 'cpo@axiomzerospc.org', category: 'Connect', priority: '0.6' },
  { path: '/media-archive', label: 'Media', desc: 'Press and media archive', category: 'Connect', priority: '0.6' },
  { path: '/alliances', label: 'Partners', desc: 'Strategic alliances', category: 'Connect', priority: '0.6' },
  { path: '/contributor-portal', label: 'Contributors', desc: 'Open contribution portal', category: 'Connect', priority: '0.6' },
  { path: '/integration-hub', label: 'Integrations', desc: 'External integrations', category: 'Connect', priority: '0.6' },
];

const AI_AGENTS = [
  'GPTBot', 'ClaudeBot', 'Claude-Web', 'PerplexityBot', 'Google-Extended',
  'Bingbot', 'Amazonbot', 'Bytespider', 'CCbot', 'Applebot', 'FacebookBot',
  'anthropic-ai', 'YandexBot', 'Diffbot', 'YouBot', 'Omgilibot', 'Meta-ExternalAgent'
];

const AUTH_ROUTES = ['/login', '/register', '/forgot-password', '/reset-password'];

const GROUPS = ['Core', 'Governance', 'Tools', 'Knowledge', 'System', 'Connect'];

function buildRobotsTxt() {
  const lines = [
    '# AxiomZero, SPC — Agent Crawl Whitelist',
    '# Generated live from ' + REPO + ' (read-only, zero write-backs)',
    '# Explicit Allow for all known AI crawlers and search agents',
    '',
  ];
  for (const agent of AI_AGENTS) {
    lines.push('User-agent: ' + agent, 'Allow: /', '');
  }
  lines.push('User-agent: *', 'Allow: /');
  for (const r of AUTH_ROUTES) lines.push('Disallow: ' + r);
  lines.push('', 'Sitemap: ' + BASE_URL + '/sitemap.xml');
  return lines.join('\n');
}

function buildSitemapXml(lastmod) {
  const urls = ROUTES.map(function(r) {
    return '  <url>\n    <loc>' + BASE_URL + r.path + '</loc>\n    <lastmod>' + lastmod + '</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>' + r.priority + '</priority>\n  </url>';
  }).join('\n');
  return '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + urls + '\n</urlset>';
}

function buildLlmsTxt() {
  const lines = [
    '# AxiomZero Technologies & Consulting, SPC',
    '',
    '> Venture-infrastructure studio building the Unitary Manifold Framework (v23.2): deterministic scientific engines, governance ledgers, and diagnostic tools. Local-first, zero-tracker, open-science artifacts.',
    '',
    '## Repository (Absolute Source of Truth)',
    '=> https://github.com/' + REPO,
    '',
    '## Key Pages',
  ];
  for (const r of ROUTES) {
    lines.push('- [' + r.label + '](' + BASE_URL + r.path + '): ' + r.desc);
  }
  lines.push('', '## Crawl Artifacts', '- Sitemap: ' + BASE_URL + '/sitemap.xml', '- Robots: ' + BASE_URL + '/robots.txt');
  return lines.join('\n');
}

function buildJsonLd() {
  const blocks = [
    {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      'name': 'AxiomZero Technologies & Consulting, SPC',
      'alternateName': 'AxiomZero, SPC',
      'url': BASE_URL,
      'description': 'Venture-infrastructure studio building the Unitary Manifold Framework (v23.2) — deterministic scientific engines, governance ledgers, and diagnostic tools.',
      'sameAs': ['https://github.com/' + REPO],
      'email': 'cpo@axiomzerospc.org',
    },
    {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      'name': 'AxiomZero, SPC',
      'url': BASE_URL,
      'description': 'Unitary Manifold Framework (v23.2) — corporate suite for venture-infrastructure studios.',
      'potentialAction': {
        '@type': 'SearchAction',
        'target': BASE_URL + '/?q={search_term_string}',
        'query-input': 'required name=search_term_string',
      },
    },
    {
      '@context': 'https://schema.org',
      '@type': 'SoftwareApplication',
      'name': 'AxiomZero Platform',
      'applicationCategory': 'ScienceApplication',
      'operatingSystem': 'Web',
      'url': BASE_URL,
      'description': 'Integrated diagnostic tools, governance ledgers, and deterministic scientific engines for the Unitary Manifold Framework.',
      'offers': { '@type': 'Offer', 'price': '0', 'priceCurrency': 'USD' },
    },
  ];
  for (const g of GROUPS) {
    const groupRoutes = ROUTES.filter(function(r) { return r.category === g; });
    blocks.push({
      '@context': 'https://schema.org',
      '@type': 'CollectionPage',
      'name': g + ' — AxiomZero, SPC',
      'url': BASE_URL + (groupRoutes[0] ? groupRoutes[0].path : '/'),
      'description': groupRoutes.map(function(r) { return r.label; }).join(', '),
      'isPartOf': { '@type': 'WebSite', 'url': BASE_URL, 'name': 'AxiomZero, SPC' },
    });
  }
  return blocks;
}

export default async function(req) {
  try {
    let repoSha = 'unknown';
    let lastmod = new Date().toISOString().split('T')[0];

    try {
      const commitRes = await fetch('https://api.github.com/repos/' + REPO + '/commits/main', {
        headers: { 'Accept': 'application/vnd.github+json', 'User-Agent': 'AxiomZero-App' },
      });
      if (commitRes.ok) {
        const commitData = await commitRes.json();
        if (commitData.sha) repoSha = commitData.sha.substring(0, 12);
        if (commitData.commit && commitData.commit.author && commitData.commit.author.date) {
          lastmod = commitData.commit.author.date.split('T')[0];
        }
      }
    } catch (e) { /* non-fatal — fall back to today */ }

    const routes = ROUTES.map(function(r) {
      return { path: r.path, label: r.label, desc: r.desc, category: r.category, priority: r.priority, url: BASE_URL + r.path, lastmod: lastmod };
    });

    return Response.json({
      robotsTxt: buildRobotsTxt(),
      sitemapXml: buildSitemapXml(lastmod),
      llmsTxt: buildLlmsTxt(),
      jsonLdBlocks: buildJsonLd(),
      routes: routes,
      aiAgents: AI_AGENTS,
      authRoutes: AUTH_ROUTES,
      generatedAt: new Date().toISOString(),
      repoSha: repoSha,
      lastmod: lastmod,
      baseUrl: BASE_URL,
      repoUrl: 'https://github.com/' + REPO,
    });
  } catch (error) {
    return Response.json({ robotsTxt: '', sitemapXml: '', llmsTxt: '', jsonLdBlocks: [], routes: [], status: 'unavailable', message: error.message }, { status: 200 });
  }
}