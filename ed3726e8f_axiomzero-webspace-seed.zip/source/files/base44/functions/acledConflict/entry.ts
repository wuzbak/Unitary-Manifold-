/**
 * acledConflict — ACLED read API for authoritatively verified political-
 * violence events (battles, protests, riots, violence against civilians).
 * Requires ACLED_API_KEY + ACLED_EMAIL secrets (free academic account).
 * Surfaces a 'key-required' status when the secret is absent so the UI can
 * show a clear UnavailableCard.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    const key = secrets.get('ACLED_API_KEY');
    const email = secrets.get('ACLED_EMAIL');
    if (!key || !email) {
      return Response.json({ events: [], status: 'key-required', message: 'ACLED_API_KEY and ACLED_EMAIL secrets required (free academic account at access.acleddata.com/registration).' });
    }

    const body = await req.json().catch(() => ({}));
    const days = body.days || 7;
    const end = new Date();
    const start = new Date(Date.now() - days * 86400000);
    const fmt = (d) => d.toISOString().slice(0, 10);
    const params = new URLSearchParams({
      key, email, terms: 'accept',
      event_date_start: fmt(start), event_date_end: fmt(end), limit: '500',
    });
    if (body.country) params.set('country', String(body.country));

    const res = await fetch(`https://api.acleddata.com/acled/read?${params}`, { headers: { 'User-Agent': 'AxiomZero-GeoMonitor' } });
    if (!res.ok) return Response.json({ events: [], status: 'unavailable', message: `ACLED returned ${res.status}` });

    const data = await res.json();
    const rows = data.data || data.events || [];
    const events = [];
    for (const r of rows) {
      if (r.latitude == null || r.longitude == null) continue;
      const fat = Number(r.fatalities || 0);
      events.push({
        id: `acled-${r.data_id || r.event_id_cnt || (r.latitude + ',' + r.longitude + r.event_date)}`,
        type: 'conflict',
        title: `${r.event_type || 'Conflict'}${r.sub_event_type ? ' · ' + r.sub_event_type : ''}`,
        place: `${r.location || ''}${r.country ? ', ' + r.country : ''}`,
        time: r.event_date || null,
        url: null,
        coords: [Number(r.latitude), Number(r.longitude)],
        eventType: r.event_type,
        subEventType: r.sub_event_type,
        fatalities: fat,
        country: r.country,
        severity: fat > 0 ? 'severe' : 'moderate',
      });
    }
    return Response.json({ events, count: events.length, source: 'ACLED', timestamp: new Date().toISOString() });
  } catch (error) {
    return Response.json({ events: [], status: 'unavailable', message: (error as Error).message });
  }
}