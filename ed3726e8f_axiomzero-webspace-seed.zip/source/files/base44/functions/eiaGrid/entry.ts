/**
 * eiaGrid — proxies EIA electricity region-data (hourly demand D + total
 * interchange TI) for all RTO regions. Computes a relative grid-stress
 * indicator (demand share + interchange imbalance). Requires EIA_API_KEY.
 * Public data proxy (no auth). Honest labeling: stress, not grid collapse.
 */
import { secrets } from 'base44:runtime';
import { unavailableResponse } from '../../shared/degradedResponse.ts';

export default async function (req: Request): Promise<Response> {
  try {
    const key = secrets.get('EIA_API_KEY');
    if (!key) return unavailableResponse({ regions: [], totalDemand: 0, period: null, count: 0 }, 'missing-credentials', 'EIA_API_KEY not set');
    const url = `https://api.eia.gov/v2/electricity/rto/region-data/data/?api_key=${key}&frequency=hourly&data[0]=value&facets[type][]=D&facets[type][]=TI&sort[0][column]=period&sort[0][direction]=desc&length=500`;
    const res = await fetch(url, { headers: { 'User-Agent': 'AxiomZero/1.0' } });
    if (!res.ok) return unavailableResponse({ regions: [], totalDemand: 0, period: null, count: 0 }, 'unavailable', `EIA ${res.status}`);
    const data = await res.json();
    const rows = (data.response && data.response.data) || [];
    const byRegion: Record<string, any> = {};
    for (const row of rows) {
      const region = row.respondent || row['respondent-name'] || row.regionid || row.region || 'Unknown';
      const type = row.type;
      const period = row.period;
      const value = parseFloat(row.value);
      if (!byRegion[region]) byRegion[region] = { region, period };
      const r = byRegion[region];
      if (type === 'D' && r.demand == null) { r.demand = value; r.period = period; }
      if (type === 'TI' && r.interchange == null) { r.interchange = value; }
    }
    const regions = Object.values(byRegion).filter((r) => r.demand != null && !isNaN(r.demand));
    const maxDemand = regions.reduce((m, r) => Math.max(m, r.demand || 0), 0);
    regions.forEach((r) => {
      r.loadLevel = maxDemand > 0 ? (r.demand || 0) / maxDemand : 0;
      r.interchangeStress = r.interchange != null ? Math.max(0, -(r.interchange)) : 0;
    });
    const totalDemand = regions.reduce((s, r) => s + (r.demand || 0), 0);
    const latestPeriod = regions.length ? regions[0].period : null;
    return Response.json({ regions, totalDemand, period: latestPeriod, count: regions.length, debugKeys: rows[0] ? Object.keys(rows[0]) : [] });
  } catch (error) {
    return unavailableResponse({ regions: [], totalDemand: 0, period: null, count: 0 }, 'unavailable', (error as Error).message);
  }
}