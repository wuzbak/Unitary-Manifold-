/**
 * worldMonitorFeeds — returns supply-chain chokepoint + commodity vulnerability
 * data for the GeoMonitor WorldMonitor fusion layer.
 *
 * Chokepoint coordinates are static geographic facts; criticality is derived
 * from public trade-volume statistics (UNCTAD, EIA, IMO). This function is a
 * thin server-side data source — extensible to live UN Comtrade / commodity
 * API integration without changing the client contract.
 *
 * Public data (no auth required) — supply-chain topology is public information.
 */
import { unavailableResponse } from '../../shared/degradedResponse.ts';

export default async function (req: Request): Promise<Response> {
  try {
    // Maritime chokepoints — static geographic + trade data
    const chokepoints = [
      { id: 'suez', name: 'Suez Canal', coords: [30.5, 32.35], type: 'canal', criticality: 5, tradePct: 12, commodities: ['oil', 'containers', 'grain'], region: 'Egypt · Red Sea', notes: 'Connects Mediterranean to Red Sea. ~12% of global trade, 10% of seaborne oil.' },
      { id: 'hormuz', name: 'Strait of Hormuz', coords: [26.57, 56.25], type: 'strait', criticality: 5, tradePct: 20, commodities: ['oil', 'lng'], region: 'Oman · Iran', notes: '~20% of global oil supply transits. Single most critical energy chokepoint.' },
      { id: 'babmandeb', name: 'Bab el-Mandeb', coords: [12.58, 43.34], type: 'strait', criticality: 4, tradePct: 8, commodities: ['oil', 'containers', 'grain'], region: 'Yemen · Djibouti', notes: 'Connects Red Sea to Gulf of Aden. Key route to Suez.' },
      { id: 'goodhope', name: 'Cape of Good Hope', coords: [-34.35, 18.47], type: 'cape', criticality: 4, tradePct: 6, commodities: ['oil', 'containers', 'iron_ore'], region: 'South Africa', notes: 'Alternative to Suez when Suez is disrupted. Adds ~10 days transit.' },
      { id: 'taiwan', name: 'Taiwan Strait', coords: [24.5, 119.5], type: 'strait', criticality: 4, tradePct: 11, commodities: ['containers', 'semiconductors', 'oil'], region: 'China · Taiwan', notes: '~11% of global trade. Critical semiconductor supply route.' },
      { id: 'gibraltar', name: 'Strait of Gibraltar', coords: [35.95, -5.6], type: 'strait', criticality: 3, tradePct: 5, commodities: ['oil', 'containers', 'lng'], region: 'Spain · Morocco', notes: 'Only exit from Mediterranean to Atlantic.' },
      { id: 'panama', name: 'Panama Canal', coords: [9.08, -79.68], type: 'canal', criticality: 5, tradePct: 5, commodities: ['containers', 'grain', 'lng'], region: 'Panama', notes: 'Connects Atlantic to Pacific. Drought-sensitive (water levels).' },
      { id: 'malacca', name: 'Strait of Malacca', coords: [2.5, 101.25], type: 'strait', criticality: 5, tradePct: 16, commodities: ['oil', 'containers', 'lng'], region: 'Malaysia · Indonesia', notes: '~16% of global trade. Main route between Asia and Europe.' },
      { id: 'bosporus', name: 'Bosporus Strait', coords: [41.12, 29.07], type: 'strait', criticality: 3, tradePct: 3, commodities: ['oil', 'grain', 'coal'], region: 'Türkiye', notes: 'Only sea route from Black Sea to Mediterranean.' },
      { id: 'danish', name: 'Danish Straits', coords: [55.35, 11.0], type: 'strait', criticality: 3, tradePct: 4, commodities: ['oil', 'containers', 'coal'], region: 'Denmark', notes: 'Route from Baltic Sea to North Sea.' },
      { id: 'horn', name: 'Cape Horn', coords: [-55.98, -67.27], type: 'cape', criticality: 2, tradePct: 1, commodities: ['containers'], region: 'Chile · Argentina', notes: 'Alternative to Panama/Strait of Magellan.' },
      { id: 'luzon', name: 'Luzon Strait', coords: [20.5, 121.0], type: 'strait', criticality: 3, tradePct: 4, commodities: ['containers', 'oil'], region: 'Taiwan · Philippines', notes: 'Alternative to Taiwan Strait. Typhoon-prone.' },
    ];

    // Commodity vulnerability — simplified static model
    const commodities = [
      { id: 'oil', name: 'Crude Oil', vulnerability: 0.85, keyChokepoints: ['hormuz', 'malacca', 'suez', 'babmandeb'], notes: '40% of seaborne oil transits Hormuz + Malacca.' },
      { id: 'lng', name: 'LNG (Natural Gas)', vulnerability: 0.70, keyChokepoints: ['hormuz', 'suez', 'panama', 'malacca'], notes: 'Growing LNG trade increasingly exposed to canal disruptions.' },
      { id: 'grain', name: 'Grain', vulnerability: 0.65, keyChokepoints: ['bosporus', 'suez', 'panama'], notes: 'Black Sea grain via Bosporus. Food security critical.' },
      { id: 'containers', name: 'Container Shipping', vulnerability: 0.75, keyChokepoints: ['suez', 'panama', 'malacca', 'taiwan'], notes: 'Just-in-time supply chains highly exposed.' },
      { id: 'iron_ore', name: 'Iron Ore', vulnerability: 0.45, keyChokepoints: ['malacca', 'goodhope'], notes: 'Australia → China via Malacca.' },
      { id: 'coal', name: 'Coal', vulnerability: 0.40, keyChokepoints: ['malacca', 'danish'], notes: 'Indonesia/Australia exports.' },
      { id: 'semiconductors', name: 'Semiconductors', vulnerability: 0.80, keyChokepoints: ['taiwan', 'luzon'], notes: 'Taiwan ~60% of global foundry output.' },
    ];

    return Response.json({ chokepoints, commodities, count: chokepoints.length, source: 'static-public-data' });
  } catch (error) {
    return unavailableResponse({ chokepoints: [], commodities: [], count: 0, source: 'static-public-data' }, 'unavailable', (error as Error).message);
  }
}