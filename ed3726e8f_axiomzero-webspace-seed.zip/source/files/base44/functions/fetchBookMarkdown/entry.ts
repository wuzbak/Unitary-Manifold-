import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const REPO_BASE = 'https://raw.githubusercontent.com/wuzbak/Unitary-Manifold-/main/7-OUTREACH/substack/books/';

// In-memory cache (per-isolate) — avoids re-fetching on every open
const _cache: Record<string, { markdown: string; fetchedAt: number }> = {};
const CACHE_TTL = 30 * 60 * 1000; // 30 minutes

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    let body: any = {};
    try { body = await req.json(); } catch (e) {}
    const filename: string = body.filename;
    if (!filename) return Response.json({ error: 'filename required' }, { status: 400 });

    // Sanitize filename — only allow .md files, no path traversal
    if (!/^[\w.-]+\.md$/.test(filename)) {
      return Response.json({ error: 'Invalid filename — only .md files allowed' }, { status: 400 });
    }

    const sourceUrl = REPO_BASE + filename;

    // Check cache
    const cached = _cache[filename];
    if (cached && (Date.now() - cached.fetchedAt) < CACHE_TTL) {
      return Response.json({
        filename,
        markdown: cached.markdown,
        sourceUrl,
        cached: true,
      });
    }

    const response = await fetch(sourceUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; AxiomZero-Merlin-Bot/1.0; +https://axiomzerospc.org)',
        'Accept': 'text/plain, text/markdown',
      },
      redirect: 'follow',
      signal: AbortSignal.timeout(20000),
    });

    if (!response.ok) {
      return Response.json({
        filename,
        markdown: '',
        sourceUrl,
        error: `Fetch failed: ${response.status} ${response.statusText}`,
      }, { status: 200 });
    }

    const markdown = await response.text();
    _cache[filename] = { markdown, fetchedAt: Date.now() };

    return Response.json({
      filename,
      markdown,
      sourceUrl,
      cached: false,
      contentLength: markdown.length,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}