import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { secrets } from 'base44:runtime';

/**
 * checkSecretStatus — reports which API secrets are configured (boolean only, never values).
 * Powers the journalist "API Keys & Sources" settings tab so the journalist knows
 * which fetchers are live and which need configuration.
 *
 * Theory, methodology: ThomasCory Walker-Pearson / AxiomZero Technologies & Consulting, SPC.
 * Implementation: GitHub Copilot (AI).
 */

const SECRET_REGISTRY = [
  { key: 'OPENROUTER_API_KEY', label: 'OpenRouter (AI)', fetcher: 'openRouterChat', description: 'Multi-model LLM backend powering all AI features (Merlin, Journalist, DelPhi, Filmer, OX Navigator). Defaults to strong free models — works at zero credit balance.', instructions: 'Key works with free models at no cost. Add credits at https://openrouter.ai/settings/credits only if you want paid model overrides.' },
  { key: 'OPENSANCTIONS_API_KEY', label: 'OpenSanctions', fetcher: 'openSanctions', description: 'Sanctions / PEP / offshore-leak screening', instructions: 'Register a free key at https://www.opensanctions.org/api/' },
  { key: 'OPENCORPORATES_API_TOKEN', label: 'OpenCorporates', fetcher: 'openCorporates', description: 'Corporate registration records worldwide', instructions: 'Get a token at https://opencorporates.com/api/' },
  { key: 'FEC_API_KEY', label: 'FEC (Campaign Finance)', fetcher: 'fec', description: 'Federal Election Commission candidates & committees', instructions: 'Register a free key at https://api.open.fec.gov/' },
  { key: 'COURTLISTENER_API_TOKEN', label: 'CourtListener', fetcher: 'courtListener', description: 'Federal/state court opinions, RECAP dockets, judge profiles', instructions: 'Get a token at https://www.courtlistener.com/api/rest-v4/' },
  { key: 'GOVINFO_API_KEY', label: 'GovInfo', fetcher: 'govInfo', description: 'U.S. Code, CFR, Federal Register publications', instructions: 'Register at https://api.govinfo.gov/' },
  { key: 'SEC_EDGAR_CONTACT_EMAIL', label: 'SEC EDGAR', fetcher: 'secEdgar', description: 'SEC filings (10-K, 10-Q, 8-K, 13D)', instructions: 'Set SEC_EDGAR_CONTACT_EMAIL to your contact email — no API key needed, but SEC requires a User-Agent contact.' },
  { key: 'ALEPH_API_TOKEN', label: 'OCCRP Aleph', fetcher: 'alephOccrp', description: 'Cross-jurisdictional leak & corporate record search', instructions: 'Get a token at https://aleph.occrp.org/api' },
  { key: 'NASA_API_KEY', label: 'NASA CNEOS (NEOs)', fetcher: 'nasaCneos', description: 'Near-Earth Objects & potentially hazardous asteroids (NeoWS feed)', instructions: 'Get a free key at https://api.nasa.gov/' },
  { key: 'FIRMS_MAP_KEY', label: 'NASA FIRMS (Fires)', fetcher: 'nasaFirms', description: 'Active fire detections from VIIRS satellite (last 24h, global)', instructions: 'Get a free MAP_KEY at https://firms.modaps.eosdis.nasa.gov/api/mapkey/' },
  { key: 'EIA_API_KEY', label: 'EIA Grid Stress', fetcher: 'eiaGrid', description: 'Hourly US electricity demand & interchange (grid-stress indicator)', instructions: 'Register a free key at https://www.eia.gov/opendata/' },
  { key: 'AIRNOW_API_KEY', label: 'AirNow AQI', fetcher: 'airNow', description: 'Current air quality index for major US metros', instructions: 'Get a key at https://docs.airnowapi.org/' },
  { key: 'OPENSKY_CLIENT_ID', label: 'OpenSky (Flights)', fetcher: 'openskyFlights', description: 'Live global aircraft tracking via OpenSky Network', instructions: 'Register at https://opensky-network.org/index.php?option=com_users&view=registration' },
  { key: 'ACLED_EMAIL', label: 'ACLED (Conflict)', fetcher: 'acledConflict', description: 'Armed Conflict Location & Event Data', instructions: 'Register at https://acleddata.com/register/' },
];

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const sources = SECRET_REGISTRY.map((s) => {
      let configured = false;
      try {
        const val = secrets.get(s.key);
        configured = !!(val && val.trim().length > 0);
      } catch { configured = false; }
      return { ...s, configured };
    });

    const configuredCount = sources.filter((s) => s.configured).length;

    return Response.json({ sources, configuredCount, totalCount: sources.length });
  } catch (error) {
    return Response.json({ sources: [], configuredCount: 0, totalCount: 0, status: 'unavailable', message: (error as Error).message }, { status: 200 });
  }
}