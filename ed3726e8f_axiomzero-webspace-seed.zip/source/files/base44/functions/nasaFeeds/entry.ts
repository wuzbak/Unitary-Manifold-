/**
 * nasaFeeds — RSS/Atom proxy for NASA + ScienceDaily news feeds.
 *
 * Fetches headlines from NASA JPL, NASA Main (site-wide), NASA CNEOS
 * (near-Earth objects), and ScienceDaily Space & Time. Normalizes them
 * with outlet / category / trust tags into a unified array.
 *
 * Handles both RSS (<item>) and Atom (<entry>) feed formats. On total
 * fetch failure, returns status 'unavailable' with an empty array —
 * the frontend degrades gracefully. Never a red error.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const FEEDS = [
  { id: 'nasa_jpl', outlet: 'NASA JPL', category: 'space', trustTag: 'Jet Propulsion Laboratory — breaking news & deep-space mission features',
    url: 'https://www.jpl.nasa.gov/feeds/news/' },
  { id: 'nasa_main', outlet: 'NASA', category: 'space', trustTag: 'NASA site-wide master news stream',
    url: 'https://www.nasa.gov/feed/' },
  { id: 'nasa_cneos', outlet: 'NASA CNEOS', category: 'space', trustTag: 'Center for Near-Earth Object Studies — NEO tracking & data',
    url: 'https://cneos.jpl.nasa.gov/feed/' },
  { id: 'sciencedaily', outlet: 'ScienceDaily', category: 'science', trustTag: 'Peer-reviewed research summaries — space & time',
    url: 'https://www.sciencedaily.com/rss/space_time.xml' },
];

function stripCdata(s: string): string {
  if (!s) return '';
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').trim();
}

function parseBlock(block: string, f: { id: string; outlet: string; category: string; trustTag: string }) {
  const titleMatch = block.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = stripCdata(titleMatch?.[1] || '');
  if (!title) return null;

  // RSS: <link>url</link>  ·  Atom: <link href="url" />
  let link = '';
  const rssLink = block.match(/<link[^>]*>([\s\S]*?)<\/link>/i);
  if (rssLink) {
    link = stripCdata(rssLink[1]);
  }
  if (!link) {
    const atomLink = block.match(/<link[^>]*href="([^"]*)"[^>]*>/i);
    if (atomLink) link = atomLink[1];
  }

  const pubMatch = block.match(/<pubDate[^>]*>([\s\S]*?)<\/pubDate>/i)
    || block.match(/<published[^>]*>([\s\S]*?)<\/published>/i)
    || block.match(/<updated[^>]*>([\s\S]*?)<\/updated>/i);

  return {
    id: f.id,
    title,
    url: link || null,
    outlet: f.outlet,
    category: f.category,
    trustTag: f.trustTag,
    published: pubMatch ? stripCdata(pubMatch[1]) : null,
  };
}

function parseFeed(xml: string, f: { id: string; outlet: string; category: string; trustTag: string }) {
  const items: any[] = [];
  // RSS <item> tags
  const itemRegex = /<item[^>]*>([\s\S]*?)<\/item>/gi;
  let m: RegExpExecArray | null;
  while ((m = itemRegex.exec(xml)) !== null) {
    const parsed = parseBlock(m[1], f);
    if (parsed) items.push(parsed);
  }
  // Atom <entry> tags
  const entryRegex = /<entry[^>]*>([\s\S]*?)<\/entry>/gi;
  while ((m = entryRegex.exec(xml)) !== null) {
    const parsed = parseBlock(m[1], f);
    if (parsed) items.push(parsed);
  }
  return items;
}

export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    const results = await Promise.allSettled(FEEDS.map((f) =>
      fetch(f.url, {
        headers: {
          'User-Agent': 'AxiomZero-GeoMonitor/1.0',
          Accept: 'application/rss+xml,application/atom+xml,application/xml,text/xml',
        },
      }).then((r) => (r.ok ? r.text() : null)).then((xml) => (xml ? parseFeed(xml, f).slice(0, 5) : []))
    ));

    const headlines: any[] = [];
    let okCount = 0;
    results.forEach((res) => {
      if (res.status === 'fulfilled' && res.value.length) {
        headlines.push(...res.value);
        okCount++;
      }
    });

    headlines.sort((a, b) =>
      (new Date(b.published || 0).getTime()) - (new Date(a.published || 0).getTime())
    );

    const status = okCount === 0 ? 'unavailable' : okCount < FEEDS.length ? 'partial' : 'live';

    return Response.json({
      headlines,
      count: headlines.length,
      status,
      sources: okCount,
      total: FEEDS.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ headlines: [], status: 'unavailable', message: (error as Error).message });
  }
}