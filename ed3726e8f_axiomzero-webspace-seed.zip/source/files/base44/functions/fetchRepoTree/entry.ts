import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';

const REPO_OWNER = 'wuzbak';
const REPO_NAME = 'Unitary-Manifold-';
const REPO_BRANCH = 'main';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Authenticated GitHub access via OAuth connector (public_repo, read:user).
    // Raises the rate limit from 60/hr (unauthenticated) to 5,000/hr.
    let headers = {
      'Accept': 'application/vnd.github+json',
      'User-Agent': 'AxiomZero-App',
      'X-GitHub-Api-Version': '2022-11-28',
    };
    try {
      const { accessToken } = await base44.asServiceRole.connectors.getConnection('github');
      if (accessToken) headers = { ...headers, Authorization: `Bearer ${accessToken}` };
    } catch {
      // Connector unavailable — fall through to unauthenticated (60/hr limit)
    }

    const response = await fetch(
      `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/git/trees/${REPO_BRANCH}?recursive=1`,
      { headers }
    );

    if (response.status === 403) {
      const remaining = response.headers.get('x-ratelimit-remaining');
      if (remaining === '0') {
        const reset = response.headers.get('x-ratelimit-reset');
        const resetIn = reset ? Math.ceil((parseInt(reset) * 1000 - Date.now()) / 60000) : 60;
        return Response.json({
          entries: [],
          truncated: false,
          totalFiles: 0,
          status: 'rate-limited',
          message: `GitHub API rate limit exceeded. Resets in ~${resetIn} min.`,
          resetInMinutes: resetIn,
        }, { status: 200 });
      }
      return Response.json({ entries: [], truncated: false, totalFiles: 0, status: 'unavailable', message: 'GitHub API access forbidden (403).' }, { status: 200 });
    }

    if (!response.ok) return Response.json({ entries: [], truncated: false, totalFiles: 0, status: 'unavailable', message: `GitHub API error: ${response.status}` }, { status: 200 });

    const data = await response.json();
    const entries = (data.tree || [])
      .filter((e) => e.type === 'blob')
      .map((e) => ({ path: e.path, type: 'blob', size: e.size }));

    return Response.json({ entries, truncated: data.truncated || false, totalFiles: entries.length });
  } catch (error) {
    return Response.json({ entries: [], truncated: false, totalFiles: 0, status: 'unavailable', message: error.message }, { status: 200 });
  }
});