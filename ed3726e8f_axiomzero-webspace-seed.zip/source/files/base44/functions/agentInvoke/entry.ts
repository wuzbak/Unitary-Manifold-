import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import {
  findFunction, findIntegration, findEntity,
  ENTITY_TOOL_RE, CONNECTOR_TOOL_RE,
} from '../../shared/agentRegistry.ts';

/**
 * agentInvoke — Unified tool router. Lets an AI agent execute any registered
 * tool (backend function, Core integration, entity operation, connector) through
 * one consistent interface.
 *
 * Input: { tool: string, args: object }
 * Returns: { ok, tool, type, result, error, duration_ms }
 *
 * Routing:
 *   - plain name (e.g. 'fetchRepoContext')  → base44.functions.invoke(name, args)
 *   - 'Core.<Endpoint>' (e.g. 'Core.InvokeLLM') → base44.asServiceRole.integrations.Core.<Endpoint>(args)
 *   - 'entity.<Name>.<op>' (e.g. 'entity.Task.list') → base44.entities.<Name>.<op>(args)
 *   - 'connector.<type>' (e.g. 'connector.github') → asServiceRole.connectors.getConnection(type)
 *
 * User-scoped by default. asServiceRole used only for tools marked admin:true AND caller is admin.
 * Secret values and connector tokens never serialized into responses.
 */
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let body = {};
    try { body = await req.json(); } catch {}
    const { tool, args = {} } = body;
    if (!tool) return Response.json({ error: 'tool param required.' }, { status: 400 });

    const start = Date.now();
    const result = await routeTool(base44, user, tool, args);
    const duration_ms = Date.now() - start;
    return Response.json({ ...result, tool, duration_ms });
  } catch (error) {
    return Response.json({ ok: false, error: error.message, status: 'unavailable', tool: null, type: 'unknown', duration_ms: 0 }, { status: 200 });
  }
}

async function routeTool(base44, user, tool, args) {
  // 1. Backend function
  const fn = findFunction(tool);
  if (fn) {
    if (fn.admin && user.role !== 'admin') return { ok: false, type: 'function', error: 'Admin role required for this tool.' };
    try {
      const res = await base44.functions.invoke(tool, args);
      const result = res?.data !== undefined ? res.data : res;
      return { ok: true, type: 'function', result };
    } catch (e) {
      return { ok: false, type: 'function', error: e.message };
    }
  }

  // 2. Core integration: Core.<Endpoint>
  if (tool.startsWith('Core.')) {
    const integ = findIntegration(tool);
    if (!integ) return { ok: false, type: 'integration', error: `Unknown integration: ${tool}` };
    if (integ.admin && user.role !== 'admin') return { ok: false, type: 'integration', error: 'Admin role required for this tool.' };
    const endpoint = tool.slice(5); // 'InvokeLLM', 'SendEmail', etc.
    try {
      const result = await base44.asServiceRole.integrations.Core[endpoint](args);
      return { ok: true, type: 'integration', result };
    } catch (e) {
      return { ok: false, type: 'integration', error: e.message };
    }
  }

  // 3. Entity operation: entity.<Name>.<op>
  const em = tool.match(ENTITY_TOOL_RE);
  if (em) {
    const [, entityName, op] = em;
    const ent = findEntity(entityName);
    if (!ent) return { ok: false, type: 'entity', error: `Unknown entity: ${entityName}` };
    const entityClient = base44.entities[entityName];
    if (!entityClient) return { ok: false, type: 'entity', error: `Entity client not available: ${entityName}` };
    try {
      let result;
      switch (op) {
        case 'list': result = await entityClient.list(args.sort, args.limit); break;
        case 'get': result = await entityClient.get(args.id); break;
        case 'create': result = await entityClient.create(args.data || args); break;
        case 'update': result = await entityClient.update(args.id, args.data || args); break;
        case 'delete': result = await entityClient.delete(args.id); break;
        case 'filter': result = await entityClient.filter(args.query || {}, args.sort, args.limit); break;
        case 'bulkCreate': result = await entityClient.bulkCreate(args.records || []); break;
        case 'bulkUpdate': result = await entityClient.bulkUpdate(args.records || []); break;
        case 'updateMany': result = await entityClient.updateMany(args.query || {}, args.update || {}); break;
        case 'deleteMany': result = await entityClient.deleteMany(args.query || {}); break;
        case 'schema': result = await entityClient.schema(); break;
        default: return { ok: false, type: 'entity', error: `Unknown entity operation: ${op}` };
      }
      return { ok: true, type: 'entity', result };
    } catch (e) {
      return { ok: false, type: 'entity', error: e.message };
    }
  }

  // 4. Connector: connector.<type>
  const cm = tool.match(CONNECTOR_TOOL_RE);
  if (cm) {
    const [, connType] = cm;
    try {
      const conn = await base44.asServiceRole.connectors.getConnection(connType);
      // Never return the raw access token — only that it's authorized + non-sensitive config
      return { ok: true, type: 'connector', result: { authorized: true, type: connType, connectionConfig: conn?.connectionConfig || null } };
    } catch (e) {
      return { ok: false, type: 'connector', error: `Connector ${connType} not authorized or unavailable: ${e.message}` };
    }
  }

  return { ok: false, type: 'unknown', error: `Tool not found in registry: ${tool}. Use agentToolkit view=index to list tools.` };
}