import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { makeSource, okResponse, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'ProPublica Nonprofit Explorer', 'No query provided');
    const url = `https://projects.propublica.org/nonprofits/api/v2/search.json?q=${encodeURIComponent(query)}`;
    const res = await fetch(url);
    if (!res.ok) return errResponse(query, 'ProPublica Nonprofit Explorer', `API ${res.status}`);
    const data = await res.json();
    const orgs = (data.organizations || []).slice(0, 10);
    const sources = orgs.map((o: any) => makeSource({
      title: `ProPublica 990: ${o.name || query}`,
      tier: 2, source_type: 'Nonprofit Form 990 disclosure',
      url_or_ref: o.ein ? `https://projects.propublica.org/nonprofits/organizations/${o.ein}` : '',
      date: o.latest_filing_date || o.filing_date || '',
      excerpt: `EIN: ${o.ein || 'N/A'} · State: ${o.state || 'N/A'} · Income: ${o.income_amount || 'N/A'} · Assets: ${o.asset_amount || 'N/A'}`,
      raw_metadata: o,
    }));
    return okResponse(sources, query, 'ProPublica Nonprofit Explorer');
  } catch (error) {
    return errResponse('', 'ProPublica Nonprofit Explorer', (error as Error).message);
  }
}