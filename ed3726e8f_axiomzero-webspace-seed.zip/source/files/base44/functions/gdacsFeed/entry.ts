/**
 * gdacsFeed — proxies the UN GDACS multi-hazard RSS feed (no key required).
 * Returns normalized event objects with alert levels + geo coordinates.
 * Public data proxy (no auth) — disaster alerts are public information.
 */
import { parseRss, field, geoPoint } from '../../shared/rssParser.ts';
import { unavailableResponse } from '../../shared/degradedResponse.ts';

export default async function (req: Request): Promise<Response> {
  try {
    const res = await fetch('https://gdacs.org/xml/rss_24h.xml', {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; AxiomZeroGeoMonitor/1.0)' },
    });
    if (!res.ok) return unavailableResponse({ events: [], count: 0 }, 'unavailable', `GDACS ${res.status}`);
    const xml = await res.text();
    const items = parseRss(xml);
    const events = items.map((it) => ({
      id: it.guid || it.link,
      type: 'gdacs',
      eventType: field(it.raw, 'gdacs:eventtype'),
      title: it.title,
      link: it.link,
      description: it.description,
      alertLevel: field(it.raw, 'gdacs:alertlevel'),
      pubDate: it.pubDate,
      coords: geoPoint(it.raw),
    })).filter((e) => e.coords && e.title);
    return Response.json({ events, count: events.length });
  } catch (error) {
    return unavailableResponse({ events: [], count: 0 }, 'unavailable', (error as Error).message);
  }
}