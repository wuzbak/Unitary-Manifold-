/**
 * fetchMerlinNavigator — Live Merlin Navigator data from the repository.
 *
 * Fetches Product 20 (12-AZ-IP/20-merlin-navigator) data: the v1 replacement
 * program (MERLIN_PROGRAM.md), README, directory tree, the nested engine
 * modules (ox_navigator/engine/), and any benchmark/telemetry/readiness JSON
 * output files. Parses the v1 program into a structured summary (toolkit
 * functions, direct API views, policy surfaces) the frontend and Merlin's
 * system prompt can consume directly.
 *
 * Uses the authorized GitHub OAuth connector (read-only).
 * Source: https://github.com/wuzbak/Unitary-Manifold-
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const REPO_OWNER = 'wuzbak';
const REPO_NAME = 'Unitary-Manifold-';
const REPO_BRANCH = 'main';
const MERLIN_PATHS = ['12-AZ-IP/20-psicat-navigator', '12-AZ-IP/20-merlin-navigator', '12-AZ-IP/20-ox-navigator'];
const MAX_CHARS = 200000;

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json().catch(() => ({}));

    // Authenticated GitHub access via OAuth connector — read-only token
    let accessToken;
    try {
      const conn = await base44.asServiceRole.connectors.getConnection('github');
      accessToken = conn.accessToken;
    } catch {
      return Response.json({ error: 'GitHub connector not authorized', status: 'missing-credentials', path: null, tree: [], engineFiles: [], program: null, readme: null, benchmarks: null, telemetry: null, readiness: null, programSummary: null, fetchedAt: new Date().toISOString() }, { status: 200 });
    }

    const headers = {
      'Authorization': `Bearer ${accessToken}`,
      'Accept': 'application/vnd.github+json',
      'User-Agent': 'AxiomZero-App',
      'X-GitHub-Api-Version': '2022-11-28',
    };

    // 1. Find the merlin navigator directory (try both possible paths)
    let merlinPath = null;
    let treeEntries = [];
    for (const path of MERLIN_PATHS) {
      try {
        const res = await fetch(
          `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${path}?ref=${REPO_BRANCH}`,
          { headers }
        );
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) {
            merlinPath = path;
            treeEntries = data
              .filter(e => e.type === 'file')
              .map(e => ({ name: e.name, path: e.path, size: e.size }));
            break;
          }
        }
      } catch {}
    }

    if (!merlinPath) {
      return Response.json({
        error: 'Merlin Navigator directory not found in repository',
        status: 'unavailable',
        triedPaths: MERLIN_PATHS,
        path: null, tree: [], engineFiles: [], program: null, readme: null, benchmarks: null, telemetry: null, readiness: null, programSummary: null,
        fetchedAt: new Date().toISOString(),
      }, { status: 200 });
    }

    // 2. Fetch the nested engine directory (ox_navigator/engine/)
    let engineFiles = [];
    try {
      const engineRes = await fetch(
        `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${merlinPath}/ox_navigator/engine?ref=${REPO_BRANCH}`,
        { headers }
      );
      if (engineRes.ok) {
        const engineData = await engineRes.json();
        if (Array.isArray(engineData)) {
          engineFiles = engineData
            .filter(e => e.type === 'file')
            .map(e => ({ name: e.name, path: e.path, size: e.size }));
        }
      }
    } catch {}

    // 3. Fetch key files in parallel
    const result = {
      path: merlinPath,
      tree: treeEntries,
      engineFiles,
      program: null,
      readme: null,
      benchmarks: null,
      telemetry: null,
      readiness: null,
      programSummary: null,
      fetchedAt: new Date().toISOString(),
    };

    const fileFetches = [];
    for (const entry of treeEntries) {
      const name = entry.name.toLowerCase();

      // Fetch MERLIN_PROGRAM.md and README.md
      if (name === 'merlin_program.md' || name === 'psicat_program.md' || name === 'readme.md') {
        fileFetches.push(
          fetchFile(entry.path, headers).then(content => {
            if (!content) return;
            if (name === 'merlin_program.md' || name === 'psicat_program.md') result.program = { content, path: entry.path };
            else result.readme = { content, path: entry.path };
          }).catch(() => {})
        );
      }

      // Fetch JSON files that might contain benchmark/telemetry/readiness data
      if (name.endsWith('.json')) {
        if (name.includes('benchmark') || name.includes('receipt')) {
          fileFetches.push(
            fetchAndParseJson(entry.path, headers).then(data => {
              if (data) result.benchmarks = { data, path: entry.path };
            }).catch(() => {})
          );
        } else if (name.includes('telemetry') || name.includes('run')) {
          fileFetches.push(
            fetchAndParseJson(entry.path, headers).then(data => {
              if (data) result.telemetry = { data, path: entry.path };
            }).catch(() => {})
          );
        } else if (name.includes('readiness') || name.includes('replacement') || name.includes('promotion')) {
          fileFetches.push(
            fetchAndParseJson(entry.path, headers).then(data => {
              if (data) result.readiness = { data, path: entry.path };
            }).catch(() => {})
          );
        }
      }

      // Also fetch markdown files that might contain benchmark/telemetry/readiness sections
      if (name.endsWith('.md') && name !== 'merlin_program.md' && name !== 'psicat_program.md' && name !== 'readme.md') {
        if (name.includes('benchmark') || name.includes('receipt')) {
          fileFetches.push(
            fetchFile(entry.path, headers).then(content => {
              if (content) result.benchmarks = { content, path: entry.path, isMarkdown: true };
            }).catch(() => {})
          );
        } else if (name.includes('telemetry')) {
          fileFetches.push(
            fetchFile(entry.path, headers).then(content => {
              if (content) result.telemetry = { content, path: entry.path, isMarkdown: true };
            }).catch(() => {})
          );
        } else if (name.includes('readiness') || name.includes('replacement')) {
          fileFetches.push(
            fetchFile(entry.path, headers).then(content => {
              if (content) result.readiness = { content, path: entry.path, isMarkdown: true };
            }).catch(() => {})
          );
        }
      }
    }

    // Fetch merlin_kernel_routing.py for Pentad kernel routing parsing
    let kernelRoutingContent = null;
    for (const entry of engineFiles) {
      if (entry.name.toLowerCase() === 'merlin_kernel_routing.py') {
        fileFetches.push(
          fetchFile(entry.path, headers).then(content => {
            if (content) kernelRoutingContent = content;
          }).catch(() => {})
        );
        break;
      }
    }

    // Also scan the nested engine directory for JSON output files
    for (const entry of engineFiles) {
      const name = entry.name.toLowerCase();
      if (name.endsWith('.json')) {
        if (name.includes('benchmark') || name.includes('receipt')) {
          fileFetches.push(
            fetchAndParseJson(entry.path, headers).then(data => {
              if (data && !result.benchmarks) result.benchmarks = { data, path: entry.path };
            }).catch(() => {})
          );
        } else if (name.includes('telemetry') || name.includes('run')) {
          fileFetches.push(
            fetchAndParseJson(entry.path, headers).then(data => {
              if (data && !result.telemetry) result.telemetry = { data, path: entry.path };
            }).catch(() => {})
          );
        } else if (name.includes('readiness') || name.includes('replacement') || name.includes('promotion')) {
          fileFetches.push(
            fetchAndParseJson(entry.path, headers).then(data => {
              if (data && !result.readiness) result.readiness = { data, path: entry.path };
            }).catch(() => {})
          );
        }
      }
    }

    await Promise.all(fileFetches);

    // 4. Parse the v1 program into a structured summary
    if (result.program?.content) {
      result.programSummary = parseProgramSummary(
        result.program.content,
        engineFiles.map(e => e.name),
        kernelRoutingContent
      );
    }

    return Response.json(result);
  } catch (error) {
    return Response.json({ error: error.message, status: 'unavailable', path: null, tree: [], engineFiles: [], program: null, readme: null, benchmarks: null, telemetry: null, readiness: null, programSummary: null, fetchedAt: new Date().toISOString() }, { status: 200 });
  }
}

/**
 * Parse the v1 MERLIN_PROGRAM.md into a structured summary:
 * toolkit functions, direct API views, and policy surfaces.
 */
function parseProgramSummary(content, engineFileNames, kernelRoutingContent) {
  const toolkitFunctions = [];
  const apiViews = [];
  const lines = content.split('\n');
  let section = null;

  for (const line of lines) {
    // Section detection — top-level bullets or headers
    if (/^##\s/.test(line)) { section = null; continue; }
    if (/^-\s.*Toolkit functions exposed/i.test(line)) { section = 'toolkit'; continue; }
    if (/^-\s.*Direct API views/i.test(line)) { section = 'api'; continue; }
    if (/^-\s/.test(line) && section) { section = null; continue; }

    if (section === 'toolkit') {
      const m = line.match(/^\s+-\s+`([a-zA-Z]+)`/);
      if (m) toolkitFunctions.push(m[1]);
    } else if (section === 'api') {
      const m = line.match(/^\s+-\s+`([A-Z]+\s+[^`]+)`/);
      if (m) apiViews.push(m[1]);
    }
  }

  // Derive policy surfaces from the toolkit function names
  const policySurfaces = [];
  if (toolkitFunctions.includes('getMerlinIdentityPolicy') || toolkitFunctions.includes('verifyMerlinIdentity')) policySurfaces.push('Identity');
  if (toolkitFunctions.includes('getMerlinSentinelPolicy')) policySurfaces.push('Sentinel');
  if (toolkitFunctions.includes('getMerlinMythosAstraContract')) policySurfaces.push('Mythos-Astra');
  if (toolkitFunctions.includes('getMerlinBackendPolicy')) policySurfaces.push('Backend');
  if (toolkitFunctions.includes('getMerlinGovernancePolicy')) policySurfaces.push('Governance');
  if (toolkitFunctions.includes('getGovernanceIntegrationPolicy')) policySurfaces.push('Pentad');

  // Detect Pentad kernel routing capability
  const hasPentadKernelRouting = toolkitFunctions.includes('getGovernanceIntegrationPolicy') ||
    engineFileNames.includes('merlin_kernel_routing.py');

  // Parse kernel routing definitions from merlin_kernel_routing.py if available
  const kernelRouting = kernelRoutingContent ? parseKernelRouting(kernelRoutingContent) : null;

  return {
    version: 'v1',
    toolkitFunctions,
    apiViews,
    policySurfaces,
    engineFiles: engineFileNames,
    hasPentadKernelRouting,
    kernelRouting,
  };
}

/**
 * Parse merlin_kernel_routing.py to extract kernel definitions.
 * Detects which kernel IDs are present, their priorities, keywords,
 * and whether the governance integration policy function is defined.
 */
function parseKernelRouting(content) {
  // The file defines KERNEL_RULES as a list of dicts with keys:
  //   "kernel_id": "kernel_p", "priority": 4, "keywords": ("lean", "theorem", ...)
  // Match each dict block containing a kernel_id and extract its fields.
  const kernels = [];
  const blockRegex = /\{[^{}]*"kernel_id"\s*:\s*"([^"]+)"[^{}]*\}/gs;
  let match;
  while ((match = blockRegex.exec(content)) !== null) {
    const block = match[0];
    const id = match[1];

    const prioMatch = block.match(/"priority"\s*:\s*(\d+)/);
    const priority = prioMatch ? parseInt(prioMatch[1]) : null;

    // Keywords are a tuple: ("kw1", "kw2", ...) or list: ["kw1", "kw2", ...]
    const kwMatch = block.match(/"keywords"\s*:\s*[\(\[]([^)\]]*)[\)\]]/);
    const keywords = kwMatch
      ? (kwMatch[1].match(/"([^"]+)"/g) || []).map(k => k.replace(/"/g, ''))
      : [];

    kernels.push({ id, priority, keywords });
  }

  const detectedKernels = kernels.map(k => k.id);
  const hasGovernanceIntegration = /get_governance_integration_policy/i.test(content);

  return {
    active: true,
    module: 'merlin_kernel_routing.py',
    detectedKernels,
    hasGovernanceIntegration,
    kernels,
    contentLength: content.length,
  };
}

async function fetchFile(path, headers) {
  const res = await fetch(
    `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${path}?ref=${REPO_BRANCH}`,
    { headers: { ...headers, 'Accept': 'application/vnd.github.raw+json' } }
  );
  if (!res.ok) return null;
  const content = await res.text();
  return content.slice(0, MAX_CHARS);
}

async function fetchAndParseJson(path, headers) {
  const content = await fetchFile(path, headers);
  if (!content) return null;
  try {
    return JSON.parse(content);
  } catch {
    return null;
  }
}