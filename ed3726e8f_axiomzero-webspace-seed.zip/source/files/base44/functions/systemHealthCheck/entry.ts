/**
 * systemHealthCheck — unified "All Systems Green" health checker.
 *
 * Pings every backend integration in parallel and returns a structured
 * health object with per-system status (green/amber/red). Powers the
 * All Systems Green dashboard in System Status.
 *
 * Categories:
 *   secrets   — token-backed integrations (checks secret presence)
 *   public    — keyless public endpoints (quick HTTP probe)
 *   connector — OAuth connectors (GitHub)
 *   entities  — entity record-count sanity checks
 *
 * Theory, methodology: ThomasCory Walker-Pearson / AxiomZero Technologies & Consulting, SPC.
 * Implementation: GitHub Copilot (AI).
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';

const SECRET_CHECKS = [
  { key: 'OPENROUTER_API_KEY', label: 'OpenRouter (AI)', category: 'AI / LLM' },
  { key: 'OPENSANCTIONS_API_KEY', label: 'OpenSanctions', category: 'Investigative' },
  { key: 'OPENCORPORATES_API_TOKEN', label: 'OpenCorporates', category: 'Investigative' },
  { key: 'FEC_API_KEY', label: 'FEC (Campaign Finance)', category: 'Investigative' },
  { key: 'COURTLISTENER_API_TOKEN', label: 'CourtListener', category: 'Investigative' },
  { key: 'GOVINFO_API_KEY', label: 'GovInfo', category: 'Investigative' },
  { key: 'SEC_EDGAR_CONTACT_EMAIL', label: 'SEC EDGAR', category: 'Investigative' },
  { key: 'ALEPH_API_TOKEN', label: 'OCCRP Aleph', category: 'Investigative' },
  { key: 'NASA_API_KEY', label: 'NASA CNEOS', category: 'Space / Earth' },
  { key: 'FIRMS_MAP_KEY', label: 'NASA FIRMS (Fires)', category: 'Space / Earth' },
  { key: 'EIA_API_KEY', label: 'EIA Grid Stress', category: 'Space / Earth' },
  { key: 'AIRNOW_API_KEY', label: 'AirNow AQI', category: 'Space / Earth' },
  { key: 'OPENSKY_CLIENT_ID', label: 'OpenSky (Flights)', category: 'Space / Earth' },
  { key: 'ACLED_EMAIL', label: 'ACLED (Conflict)', category: 'Space / Earth' },
];

const PUBLIC_ENDPOINTS = [
  { label: 'NOAA SWPC Space Weather', url: 'https://services.swpc.noaa.gov/json/planetary_k_index_1m.json', category: 'Space / Earth' },
  { label: 'USGS Earthquakes', url: 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/significant_day.geojson', category: 'Space / Earth' },
  { label: 'NASA EONET', url: 'https://eonet.gsfc.nasa.gov/api/v2.1/events?limit=1&days=1', category: 'Space / Earth' },
  { label: 'GDACS', url: 'https://www.gdacs.org/xml/rss.xml', category: 'Space / Earth' },
  { label: 'NHC Cyclones', url: 'https://www.nhc.noaa.gov/index-at.xml', category: 'Space / Earth' },
  { label: 'BBC News RSS', url: 'http://feeds.bbci.co.uk/news/world/rss.xml', category: 'News / RSS' },
  { label: 'NPR News RSS', url: 'https://feeds.npr.org/1001/rss.xml', category: 'News / RSS' },
  { label: 'Defense.gov News RSS', url: 'https://www.defense.gov/DesktopModules/ArticleCS/RSS.ashx?ContentType=1&Site=1065&max=20', category: 'News / RSS' },
  { label: 'ICIJ Offshore Leaks', url: 'https://offshoreleaks.icij.org', category: 'Investigative' },
  { label: 'DOJ Epstein Library', url: 'https://www.justice.gov/epstein', category: 'Investigative' },
  { label: 'USGS Volcanoes', url: 'https://volcanoes.usgs.gov/hans-public/api/volcano/getElevatedVolcanoes', category: 'Space / Earth' },
  { label: 'EPA ECHO', url: 'https://echo.epa.gov', category: 'Investigative' },
  { label: 'Wayback Machine', url: 'https://web.archive.org', category: 'Investigative' },
  { label: 'ProPublica Nonprofits', url: 'https://projects.propublica.org/nonprofits/api/v2/search.json?q=test', category: 'Investigative' },
];

async function probeEndpoint(url: string): Promise<{ ok: boolean; status: number; latency: number }> {
  const start = Date.now();
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    const res = await fetch(url, {
      method: 'GET',
      signal: controller.signal,
      headers: { 'User-Agent': 'Mozilla/5.0 (AxiomZero-HealthCheck/1.0; +https://axiomzerospc.org)' },
    });
    clearTimeout(timeout);
    return { ok: res.ok, status: res.status, latency: Date.now() - start };
  } catch {
    return { ok: false, status: 0, latency: Date.now() - start };
  }
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    // Auth optional — works in both user context (dashboard) and workflow context (scheduled)
    try { await base44.auth.me(); } catch { /* workflow context — service role */ }

    // 1. Check secrets
    const secretResults = SECRET_CHECKS.map((s) => {
      let configured = false;
      try {
        const val = secrets.get(s.key);
        configured = !!(val && val.trim().length > 0);
      } catch { configured = false; }
      return { ...s, type: 'secret', status: configured ? 'green' : 'amber', detail: configured ? 'Configured' : 'Missing key' };
    });

    // 2. Probe public endpoints in parallel
    const publicPromises = PUBLIC_ENDPOINTS.map(async (ep) => {
      const probe = await probeEndpoint(ep.url);
      return {
        ...ep,
        type: 'public',
        status: probe.ok ? 'green' : 'red',
        detail: probe.ok ? `HTTP ${probe.status} · ${probe.latency}ms` : `HTTP ${probe.status || 'timeout'}`,
        latency: probe.latency,
      };
    });
    const publicResults = await Promise.all(publicPromises);

    // 3. Check GitHub connector
    let connectorStatus = { label: 'GitHub Connector', category: 'Connector', type: 'connector', status: 'red' as 'red'|'green'|'amber', detail: 'Not connected' };
    try {
      const conn = await base44.asServiceRole.connectors.getConnection('github');
      if (conn?.accessToken) {
        connectorStatus = { label: 'GitHub Connector', category: 'Connector', type: 'connector', status: 'green', detail: 'Connected (public_repo, read:user)' };
      }
    } catch {
      connectorStatus = { label: 'GitHub Connector', category: 'Connector', type: 'connector', status: 'amber', detail: 'Connection check failed' };
    }

    // 4. Entity count sanity checks
    const entityChecks = [
      { label: 'MerlinNote (Memory)', entity: 'MerlinNote', min: 1, category: 'Entities' },
      { label: 'DnDCampaign', entity: 'DnDCampaign', min: 0, category: 'Entities' },
      { label: 'FilmProject', entity: 'FilmProject', min: 0, category: 'Entities' },
      { label: 'GeoMonitorView', entity: 'GeoMonitorView', min: 0, category: 'Entities' },
    ];
    const entityResults = await Promise.all(entityChecks.map(async (e) => {
      try {
        const items = await (base44 as any).asServiceRole.entities[e.entity].list(1);
        const count = items?.length || 0;
        return { ...e, type: 'entity', status: count >= e.min ? 'green' : 'amber', detail: `${count} records`, count };
      } catch {
        return { ...e, type: 'entity', status: 'red', detail: 'Entity query failed' };
      }
    }));

    // Aggregate
    const allChecks = [...secretResults, ...publicResults, connectorStatus, ...entityResults];
    const greenCount = allChecks.filter((c) => c.status === 'green').length;
    const amberCount = allChecks.filter((c) => c.status === 'amber').length;
    const redCount = allChecks.filter((c) => c.status === 'red').length;
    const totalCount = allChecks.length;

    // Group by category
    const categories: Record<string, any[]> = {};
    for (const c of allChecks) {
      if (!categories[c.category]) categories[c.category] = [];
      categories[c.category].push(c);
    }

    return Response.json({
      overall: greenCount === totalCount ? 'all-green' : redCount > 0 ? 'issues' : 'warnings',
      summary: { green: greenCount, amber: amberCount, red: redCount, total: totalCount },
      categories,
      checks: allChecks,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({
      overall: 'error',
      summary: { green: 0, amber: 0, red: 0, total: 0 },
      categories: {},
      checks: [],
      error: (error as Error).message,
      timestamp: new Date().toISOString(),
    }, { status: 200 });
  }
}