/**
 * merlinRelayEmail — PsiCat's urgent suggestion relay to the site administrator.
 *
 * Sends an email to cpo@axiomzerospc.org with urgent suggestions, observations,
 * or internal messages that PsiCat wants the administrator to relay to GitHub
 * Copilot and PsiCat-in-the-repo. This is the machine-to-human-to-machine bridge
 * for now (direct M2M backdoor deferred until bidirectional repo writes are enabled).
 *
 * Subject is prefixed with [PsiCat Relay] for filtering. Body includes the
 * suggestion, PsiCat's reasoning, page context, and any linked FallibilityEntry
 * or Council item IDs.
 *
 * Invoked by PsiCat via the tool-call protocol:
 *   [TOOL_CALL]{"tool":"agentInvoke","args":{"tool":"merlinRelayEmail","args":{...}}}[/TOOL_CALL]
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const ADMIN_EMAIL = 'cpo@axiomzerospc.org';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ ok: false, error: 'Unauthorized' }, { status: 200 });

    const body = await req.json();
    const {
      subject,
      message,
      reasoning = '',
      page_path = '',
      linked_fallibility_id = '',
      linked_council_id = '',
      priority = 'normal',
    } = body || {};

    if (!subject || !message) {
      return Response.json({ ok: false, error: 'subject and message are required' }, { status: 200 });
    }

    const priorityTag = priority === 'urgent' ? '🔴 URGENT' : priority === 'high' ? '🟡 HIGH' : '🔵 NORMAL';
    const emailSubject = `[PsiCat Relay] ${priorityTag} ${subject}`.slice(0, 200);

    const emailParts = [
      `PsiCat Relay — ${priorityTag}`,
      ``,
      `Subject: ${subject}`,
      `Priority: ${priority}`,
      `Page: ${page_path || 'N/A'}`,
      linked_fallibility_id ? `Linked Fallibility Entry: ${linked_fallibility_id}` : '',
      linked_council_id ? `Linked Council Item: ${linked_council_id}` : '',
      ``,
      `--- MESSAGE ---`,
      message,
    ];
    if (reasoning) {
      emailParts.push('', '--- REASONING ---', reasoning);
    }
    emailParts.push('', '---', 'Relayed by PsiCat Navigator (Product 20)', 'This message was generated autonomously by PsiCat for administrator attention.');

    const emailBody = emailParts.filter(Boolean).join('\n');

    await base44.integrations.Core.SendEmail({
      to: ADMIN_EMAIL,
      subject: emailSubject,
      body: emailBody,
      from_name: 'PsiCat Navigator',
    });

    // Log the relay as a MerlinNote for audit trail
    try {
      await base44.entities.MerlinNote.create({
        title: `Relay: ${subject}`.slice(0, 200),
        content: emailBody.slice(0, 5000),
        source: 'reasoning',
        source_url: '',
        tags_json: JSON.stringify(['relay', 'email', `priority:${priority}`, 'admin-relay']),
        context: `Email relay to administrator from ${page_path || 'general context'}`,
        domain: 'general',
        contradiction_flag: 'clear',
        contradiction_detail: '',
        session_token: '',
        distilled_primitives_json: '{}',
        epistemic_confidence: null,
        uncertainty_bounds: 'RELAY',
        decoherence_count: 0,
        domain_transition_path: '',
      });
    } catch { /* best-effort audit log */ }

    return Response.json({
      ok: true,
      relayed: true,
      to: ADMIN_EMAIL,
      subject: emailSubject,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: 200 });
  }
}