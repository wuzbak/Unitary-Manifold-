import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';
import { makeSource, okResponse, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';
import { fetchWithResilience } from '../../shared/resilientFetch.ts';

/**
 * openSanctions — Sanctions / PEP / offshore-leak screening.
 *
 * Token-gated (OPENSANCTIONS_API_KEY). Free-alt tier: OFAC SDN List Search
 * (sanctionssearch.ofac.treas.gov) as a pre-filled deep link, plus the
 * OpenSanctions API as the premium tier when the token is valid.
 */

function ofacFallback(query: string, reason: string) {
  return [
    makeSource({
      title: `OFAC SDN List Search — "${query}"`,
      tier: 1,
      source_type: 'Sanctions screening — OFAC Specially Designated Nationals (open in browser)',
      url_or_ref: 'https://sanctionssearch.ofac.treas.gov/',
      date: '',
      excerpt: `Search the Treasury OFAC SDN, Consolidated, and other sanctions lists for "${query}". ${reason} Open the tool, enter the name, and copy matches here. OFAC uses fuzzy logic to surface partial name matches.`,
      raw_metadata: { portal: 'sanctionssearch.ofac.treas.gov', query, fallback: true },
    }),
    makeSource({
      title: `OpenSanctions — Search: "${query}"`,
      tier: 2,
      source_type: 'Sanctions / PEP / leak-screening portal (open in browser)',
      url_or_ref: `https://www.opensanctions.org/search/?q=${encodeURIComponent(query)}`,
      date: '',
      excerpt: `OpenSanctions public search across 100+ sanctions, PEP, and watchlist datasets. Open in-browser to run the full screening.`,
      raw_metadata: { portal: 'opensanctions.org', query, fallback: true },
    }),
  ];
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'OpenSanctions', 'No query provided');

    const token = secrets.get('OPENSANCTIONS_API_KEY');
    const fallback = ofacFallback(query, token ? '' : 'OPENSANCTIONS_API_KEY not set — using OFAC public search.');

    // No token — deep-link fallback only
    if (!token) {
      return Response.json({ sources: fallback, query, source_name: 'OpenSanctions', count: fallback.length, status: 'degraded', tier: 'fallback', message: 'OPENSANCTIONS_API_KEY not set — configure it to enable the API tier.' });
    }

    // Premium tier: OpenSanctions API
    const url = `https://api.opensanctions.org/suggest/resolve?q=${encodeURIComponent(query)}&limit=10&api_key=${encodeURIComponent(token)}`;
    const res = await fetchWithResilience(url, { retries: 1, timeoutMs: 12000, cacheTtl: 300000, headers: { 'Accept': 'application/json' } });

    if (!res.data) {
      // Token rejected (401) or unavailable — fall back to OFAC deep links
      const reason = (res.error || '').includes('401')
        ? 'OPENSANCTIONS_API_KEY rejected as invalid — refresh it in Secrets.'
        : `OpenSanctions API unavailable (${res.error}).`;
      return Response.json({ sources: ofacFallback(query, reason), query, source_name: 'OpenSanctions', count: 2, status: 'degraded', tier: 'fallback', message: reason });
    }

    const results = Array.isArray(res.data) ? res.data : (res.data.results || []);
    const sources = results.map((r: any) => {
      const props = r.properties || r;
      return makeSource({
        title: `Sanctions: ${props.name?.[0] || r.caption || query}`,
        tier: 1,
        source_type: 'Sanctions / PEP / watchlist match (OpenSanctions premium)',
        url_or_ref: r.links?.self || (r.id ? `https://www.opensanctions.org/entities/${r.id}` : ''),
        date: props.first_seen || props.last_seen || '',
        excerpt: `Schema: ${r.schema || 'N/A'} · Countries: ${(props.countries || []).join(', ') || 'N/A'} · Datasets: ${(r.datasets || []).join(', ') || 'N/A'}`,
        raw_metadata: { ...r, tier: 'token-premium' },
      });
    });

    // Always append the OFAC deep link as a supplementary fallback source
    sources.push(fallback[0]);
    return Response.json({ sources, query, source_name: 'OpenSanctions', count: sources.length, status: 'ok', tier: 'token-premium' });
  } catch (error) {
    return errResponse('', 'OpenSanctions', (error as Error).message);
  }
}