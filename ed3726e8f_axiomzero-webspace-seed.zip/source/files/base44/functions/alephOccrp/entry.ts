import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';
import { makeSource, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';
import { fetchWithResilience } from '../../shared/resilientFetch.ts';

/**
 * alephOccrp — OCCRP Aleph cross-jurisdictional leak / corporate search.
 *
 * Free-alt tier (primary): ICIJ Offshore reconciliation API (no auth, working) +
 * pre-filled deep-link searches. Premium tier (secondary): OCCRP Aleph API
 * (ALEPH_API_TOKEN) when valid.
 */

function deepLinkFallback(query: string) {
  return [
    makeSource({
      title: `ICIJ Offshore Leaks — All: "${query}"`,
      tier: 2,
      source_type: 'Cross-jurisdictional leak database — pre-filled web search',
      url_or_ref: `https://offshoreleaks.icij.org/search?q=${encodeURIComponent(query)}&e=true`,
      date: '',
      excerpt: `Pre-filled search of the ICIJ Offshore Leaks Database (810k+ offshore entities across all investigations). Open in-browser and copy results here.`,
      raw_metadata: { portal: 'offshoreleaks.icij.org', query, fallback: true },
    }),
    makeSource({
      title: `OCCRP Aleph — Search: "${query}"`,
      tier: 2,
      source_type: 'Cross-jurisdictional leak / corporate search (open in browser)',
      url_or_ref: `https://aleph.occrp.org/search?filter:entities&q=${encodeURIComponent(query)}`,
      date: '',
      excerpt: `Search OCCRP Aleph's cross-jurisdictional leak + corporate registry. Open in-browser to run the full search.`,
      raw_metadata: { portal: 'aleph.occrp.org', query, fallback: true },
    }),
  ];
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'OCCRP Aleph', 'No query provided');

    const sources: any[] = [];
    const tiers: string[] = [];

    // ── Free-alt tier: ICIJ Offshore reconciliation API (no auth) ──
    try {
      const icijRes = await base44.functions.invoke('icijOffshore', { query });
      const icij = icijRes?.data || icijRes;
      if (icij && Array.isArray(icij.sources)) {
        for (const s of icij.sources) {
          sources.push({ ...s, raw_metadata: { ...s.raw_metadata, free_alt: 'icij_reconcile' } });
        }
        if (icij.sources.length > 0) tiers.push('free-alt:icij');
      }
    } catch { /* ignore — fall through */ }

    // ── Premium tier: OCCRP Aleph API (if token valid) ──
    let token = '';
    try { token = secrets.get('ALEPH_API_TOKEN') || ''; } catch { token = ''; }
    if (token) {
      try {
        const url = `https://aleph.occrp.org/api/2/search?q=${encodeURIComponent(query)}&limit=10`;
        const res = await fetchWithResilience(url, {
          headers: { Authorization: `Apikey ${token}`, Accept: 'application/json' },
          retries: 1, timeoutMs: 12000, cacheTtl: 300000,
        });
        if (res.data && Array.isArray(res.data.results)) {
          for (const r of res.data.results) {
            const props = r.properties || {};
            sources.push(makeSource({
              title: `Aleph: ${props.name || r.caption || query}`,
              tier: 2, source_type: 'Cross-jurisdictional leak / corporate record (Aleph premium)',
              url_or_ref: r.links?.self || (r.id ? `https://aleph.occrp.org/entities/${r.id}` : ''),
              date: props.date || props.created_at || '',
              excerpt: `Schema: ${r.schema || 'N/A'} · Countries: ${(props.countries || []).join(', ') || 'N/A'} · ${props.summary || ''}`,
              raw_metadata: { ...r, tier: 'token-premium' },
            }));
          }
          tiers.push('token-premium:aleph');
        } else if ((res.error || '').includes('401')) {
          tiers.push('token-premium:aleph:token-invalid');
        }
      } catch { tiers.push('token-premium:aleph:failed'); }
    } else {
      tiers.push('token-premium:aleph:no-token');
    }

    // Always append deep-link fallback
    sources.push(...deepLinkFallback(query));

    if (sources.length === 0) return errResponse(query, 'OCCRP Aleph', 'No results');
    return Response.json({ sources, query, source_name: 'OCCRP Aleph', count: sources.length, status: 'ok', tiers });
  } catch (error) {
    return errResponse('', 'OCCRP Aleph', (error as Error).message);
  }
}