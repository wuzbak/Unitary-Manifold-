/**
 * nasaDonki — proxies NASA DONKI for solar flares (FLR), CMEs, and geomagnetic
 * storms (GST) over the last 7 days. Feeds the Space-Weather console panel.
 * Requires NASA_API_KEY. Public data proxy (no auth).
 */
import { secrets } from 'base44:runtime';
import { unavailableResponse } from '../../shared/degradedResponse.ts';

function daysAgo(n: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - n);
  return d.toISOString().slice(0, 10);
}

export default async function (req: Request): Promise<Response> {
  try {
    const key = secrets.get('NASA_API_KEY');
    if (!key) return unavailableResponse({ flares: [], cmes: [], storms: [], count: 0 }, 'missing-credentials', 'NASA_API_KEY not set');
    const start = daysAgo(7);
    const endpoints = {
      flares: `https://api.nasa.gov/DONKI/FLR?startDate=${start}&api_key=${key}`,
      cmes: `https://api.nasa.gov/DONKI/CME?startDate=${start}&api_key=${key}`,
      storms: `https://api.nasa.gov/DONKI/GST?startDate=${start}&api_key=${key}`,
    };
    const [flr, cme, gst] = await Promise.all([
      fetch(endpoints.flares).then((r) => r.json()),
      fetch(endpoints.cmes).then((r) => r.json()),
      fetch(endpoints.storms).then((r) => r.json()),
    ]);
    const flares = (Array.isArray(flr) ? flr : []).map((f: any) => ({
      id: f.flrID, startTime: f.beginTime, endTime: f.endTime, peakTime: f.peakTime,
      classType: f.classType, sourceLocation: f.sourceLocation, link: f.link,
    }));
    const cmes = (Array.isArray(cme) ? cme : []).map((c: any) => ({
      id: c.activityID, startTime: c.startTime, note: c.note, link: c.link,
      analysis: c.cmeAnalyses ? c.cmeAnalyses.length : 0,
    }));
    const storms = (Array.isArray(gst) ? gst : []).map((g: any) => ({
      id: g.gstID, startTime: g.startTime, link: g.link,
      kp: g.allKpIndex && g.allKpIndex.length ? g.allKpIndex[g.allKpIndex.length - 1] : null,
    }));
    return Response.json({ flares, cmes, storms, count: flares.length + cmes.length + storms.length });
  } catch (error) {
    return unavailableResponse({ flares: [], cmes: [], storms: [], count: 0 }, 'unavailable', (error as Error).message);
  }
}