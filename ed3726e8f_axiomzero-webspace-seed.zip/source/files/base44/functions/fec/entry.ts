import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { secrets } from 'base44:runtime';
import { makeSource, okResponse, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'FEC', 'No query provided');
    const key = secrets.get('FEC_API_KEY');
    if (!key) return errResponse(query, 'FEC', 'FEC_API_KEY not set');
    const sources: any[] = [];
    const base = 'https://api.open.fec.gov/v1';

    // Candidate search
    const candUrl = `${base}/candidates/?api_key=${encodeURIComponent(key)}&q=${encodeURIComponent(query)}&per_page=5`;
    const candRes = await fetch(candUrl);
    if (candRes.ok) {
      const cd = await candRes.json();
      for (const r of (cd.results || [])) {
        sources.push(makeSource({
          title: `FEC Candidate: ${r.name || query}`,
          tier: 1, source_type: 'FEC campaign finance (candidate)',
          url_or_ref: `https://www.fec.gov/data/candidate/${r.candidate_id || ''}/`,
          date: r.last_file_date || '',
          excerpt: `Party: ${r.party || 'N/A'} · Office: ${r.office || 'N/A'} · State: ${r.state || 'N/A'}`,
          raw_metadata: r,
        }));
      }
    }
    // Committee search
    const commUrl = `${base}/committees/?api_key=${encodeURIComponent(key)}&q=${encodeURIComponent(query)}&per_page=5`;
    const commRes = await fetch(commUrl);
    if (commRes.ok) {
      const cd = await commRes.json();
      for (const r of (cd.results || [])) {
        sources.push(makeSource({
          title: `FEC Committee: ${r.name || query}`,
          tier: 1, source_type: 'FEC campaign finance (committee/PAC)',
          url_or_ref: `https://www.fec.gov/data/committee/${r.committee_id || ''}/`,
          date: r.last_file_date || '',
          excerpt: `Treasurer: ${r.treasurer_name || 'N/A'} · Type: ${r.committee_type || 'N/A'}`,
          raw_metadata: r,
        }));
      }
    }
    return okResponse(sources, query, 'FEC');
  } catch (error) {
    return errResponse('', 'FEC', (error as Error).message);
  }
}