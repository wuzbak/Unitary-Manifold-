/**
 * dndImportParse — Multi-modal import orchestrator for D&D data.
 *
 * Accepts an uploaded file_url, auto-classifies the file type (JSON export,
 * image of a handwritten sheet, or typed notes), and extracts structured
 * entity payloads (characters, items, spells, notes, campaign) using:
 *   - InvokeLLM with file_urls (vision) for handwritten/image documents
 *   - direct JSON parsing for structured export files
 *   - InvokeLLM text parsing for typed notes
 *
 * Returns normalized payloads keyed by type for client-side confirm-and-merge.
 * Merlin oversees classification and extraction.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { file_url, hint } = body;
    if (!file_url) return Response.json({ error: 'file_url is required' }, { status: 400 });

    // Classify file type from URL extension or hint
    const lowerUrl = file_url.toLowerCase();
    let fileType = hint || 'unknown';
    if (fileType === 'unknown') {
      if (/\.(json)$/.test(lowerUrl)) fileType = 'json';
      else if (/\.(png|jpg|jpeg|webp|gif|bmp)$/.test(lowerUrl)) fileType = 'image';
      else if (/\.(txt|md|csv)$/.test(lowerUrl)) fileType = 'text';
      else fileType = 'image'; // default to vision for unknown
    }

    // ── JSON export: fetch and parse directly ─────────────────────────────────
    if (fileType === 'json') {
      try {
        const resp = await fetch(file_url);
        const text = await resp.text();
        const data = JSON.parse(text);
        return Response.json({
          fileType: 'json',
          ...normalizeJsonBundle(data),
          summary: 'Parsed JSON export file.',
        });
      } catch (e) {
        return Response.json({ error: 'Failed to parse JSON file: ' + e.message }, { status: 422 });
      }
    }

    // ── Image or text: use InvokeLLM to extract structured data ──────────────
    const isImage = fileType === 'image';
    const prompt = buildExtractionPrompt(fileType);

    const schema = {
      type: 'object',
      properties: {
        characters: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              species: { type: 'string' },
              klass: { type: 'string' },
              background: { type: 'string' },
              level: { type: 'number' },
              alignment: { type: 'string' },
              ability_scores: {
                type: 'object',
                properties: {
                  strength: { type: 'number' }, dexterity: { type: 'number' },
                  constitution: { type: 'number' }, intelligence: { type: 'number' },
                  wisdom: { type: 'number' }, charisma: { type: 'number' },
                },
              },
              hp_max: { type: 'number' },
              armor_class: { type: 'number' },
              gold: { type: 'number' },
              xp: { type: 'number' },
              spellcasting_ability: { type: 'string' },
              spellbook: { type: 'array', items: { type: 'string' } },
              inventory: { type: 'array', items: { type: 'string' } },
              abilities: { type: 'array', items: { type: 'string' } },
              notes: { type: 'array', items: { type: 'string' } },
            },
          },
        },
        items: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              type: { type: 'string' },
              rarity: { type: 'string' },
              description: { type: 'string' },
              value: { type: 'number' },
              attunement: { type: 'boolean' },
            },
          },
        },
        spells: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              level: { type: 'number' },
              school: { type: 'string' },
              casting_time: { type: 'string' },
              range: { type: 'string' },
              duration: { type: 'string' },
              components: { type: 'string' },
              concentration: { type: 'boolean' },
              ritual: { type: 'boolean' },
              description: { type: 'string' },
              classes: { type: 'array', items: { type: 'string' } },
            },
          },
        },
        notes: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              title: { type: 'string' },
              body: { type: 'string' },
              tags: { type: 'array', items: { type: 'string' } },
            },
          },
        },
        campaign: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            setting: { type: 'string' },
            tone: { type: 'string' },
            summary: { type: 'string' },
          },
        },
        summary: { type: 'string' },
      },
    };

    const llmArgs = {
      prompt,
      response_json_schema: schema,
    };
    if (isImage) {
      llmArgs.file_urls = [file_url];
      llmArgs.model = 'gemini_3_flash';
    }

    const result = await base44.integrations.Core.InvokeLLM(llmArgs);

    return Response.json({
      fileType,
      characters: result.characters || [],
      items: result.items || [],
      spells: result.spells || [],
      notes: result.notes || [],
      campaign: result.campaign || null,
      summary: result.summary || `Extracted data from ${fileType} file.`,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

function buildExtractionPrompt(fileType) {
  if (fileType === 'image') {
    return `You are a D&D 5e/5.5e character sheet and campaign document parser. Examine this image carefully — it may be a handwritten character sheet, a printed character sheet, a campaign notebook page, or a photo of notes. Extract ALL D&D-relevant data you can read into structured JSON.

Look for:
- Character name, species, class, background, level, alignment
- Ability scores (STR/DEX/CON/INT/WIS/CHA)
- HP, AC, gold, XP
- Spellcasting ability and known/prepared spells
- Inventory items
- Abilities, features, and traits
- Any campaign setting, tone, or summary notes
- Free-text notes

For handwritten content, use your best OCR interpretation. If a field is illegible or missing, omit it rather than guessing. Only include entries you can actually read from the image.`;
  }
  return `You are a D&D 5e/5.5e data parser. The user has pasted typed notes or text describing their character, campaign, items, or spells. Extract all D&D-relevant data into structured JSON. Parse character stats, inventory, spells, campaign details, and any free-text notes from the text provided.`;
}

function normalizeJsonBundle(data) {
  // Handle a full export bundle or a single character export
  if (data.characters || data.items || data.spells || data.campaign) {
    return {
      characters: data.characters || [],
      items: data.items || [],
      spells: data.spells || [],
      notes: data.notes || [],
      campaign: data.campaign || null,
    };
  }
  // Single character export shape
  if (data.name && (data.klass || data.species)) {
    return {
      characters: [data],
      items: data.inventory || [],
      spells: [],
      notes: data.notes || [],
      campaign: null,
    };
  }
  return { characters: [], items: [], spells: [], notes: [], campaign: null };
}