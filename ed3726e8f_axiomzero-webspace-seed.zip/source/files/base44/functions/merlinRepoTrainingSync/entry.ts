/**
 * merlinRepoTrainingSync — Deep training-data bridge from the GitHub
 * repository into Merlin's knowledge base.
 *
 * Sprint upgrade: no longer ingests only commit *messages*. For each recent
 * commit it fetches the commit detail (which includes the changed-files list
 * with filenames, status, and the actual patch/diff), classifies every
 * changed file by type (tool / language / integration / docs / test / infra),
 * and distills a richer per-sync insight that captures the real content of
 * new tools, languages, and integrations — not just their commit titles.
 *
 * The distilled insight is persisted as a MerlinNote (source='distillation',
 * domain='physics') tagged with repo-sync + per-change-type tags + commit SHAs,
 * so the Repository Intelligence surface can browse PsiCat's GitHub training
 * growth by type, date, and commit provenance.
 *
 * Called every 6 hours by the "Merlin Repo Training Sync" workflow.
 * Admin-only (scheduled task). Uses the authorized github connector.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { getLiveStatus } from '../../shared/repoContext.ts';

const REPO_OWNER = 'wuzbak';
const REPO_NAME = 'Unitary-Manifold-';
const REPO_BRANCH = 'main';
const COMMIT_DETAIL_LIMIT = 8;     // fetch file-level detail for the 8 most recent commits
const PATCH_CHAR_CAP = 1400;      // per-file patch cap
const TOTAL_PATCH_CAP = 9000;     // total patch budget for the LLM prompt

function normalizeContext(ctx) {
  if (!ctx) return null;
  return {
    version: ctx.version || 'unknown',
    sprint: ctx.sprint || 'unknown',
    testsPassed: ctx.testsPassed || ctx.tests_passed || 0,
    testsFailed: ctx.testsFailed || ctx.tests_failed || 0,
    lean4Theorems: ctx.lean4Theorems || ctx.lean4_theorems || 0,
    pillarsTotal: ctx.pillarsTotal || ctx.pillars_total || 0,
    nextPillarSlot: ctx.nextPillarSlot || ctx.next_pillar_slot || 0,
  };
}

/**
 * Classify a changed file by its path into a coarse change-type bucket.
 * Used for tagging + for the LLM's integration-mapping reasoning.
 */
function classifyFile(filename) {
  const p = filename.toLowerCase();
  if (/\.(md|rst|txt)$/.test(p) || /readme|status|docs?\//.test(p)) return 'docs';
  if (/lean|\.lean/.test(p)) return 'language';
  if (/\.(py|rs|go|ts|tsx|js|jsx)$/.test(p) && /tool|agent|engine|function/.test(p)) return 'tool';
  if (/integration|connector|webhook|api[_/]/.test(p)) return 'integration';
  if (/test|spec|_test/.test(p)) return 'test';
  if (/infra|config|workflow|\.jsonc|\.toml|\.yaml|\.yml/.test(p)) return 'infra';
  if (/\.(py|rs|go)$/.test(p)) return 'language';
  return 'other';
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ status: 'unavailable', error: 'Unauthorized' }, { status: 200 });
    if (user.role !== 'admin') return Response.json({ status: 'forbidden', error: 'Admin only' }, { status: 200 });

    // 1. Fetch recent commit metadata via the GitHub OAuth connector
    let commits = [];
    let token = null;
    try {
      const conn = await base44.asServiceRole.connectors.getConnection('github');
      token = conn.accessToken;
      const headers = {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json',
        'User-Agent': 'AxiomZero-App',
        'X-GitHub-Api-Version': '2022-11-28',
      };
      const commitsRes = await fetch(
        `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/commits?per_page=15&sha=${REPO_BRANCH}`,
        { headers }
      );
      if (commitsRes.ok) {
        const data = await commitsRes.json();
        commits = (data || []).map((c) => ({
          sha: (c.sha || '').slice(0, 7),
          fullSha: c.sha || '',
          message: ((c.commit && c.commit.message) || '').split('\n')[0].slice(0, 200),
          author: (c.commit && c.commit.author && c.commit.author.name) || '',
          date: (c.commit && c.commit.author && c.commit.author.date) || '',
        }));
      }
    } catch {
      // Connector or GitHub API unavailable — continue with context-only sync
    }

    // 2. Deep fetch: commit detail (changed files + patches) for the most recent commits
    let changeRecords = [];
    const changeTypeCounts = { tool: 0, language: 0, integration: 0, docs: 0, test: 0, infra: 0, other: 0 };
    if (token) {
      const headers = {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json',
        'User-Agent': 'AxiomZero-App',
        'X-GitHub-Api-Version': '2022-11-28',
      };
      let patchBudget = TOTAL_PATCH_CAP;
      for (let i = 0; i < Math.min(COMMIT_DETAIL_LIMIT, commits.length); i++) {
        const c = commits[i];
        try {
          const detailRes = await fetch(
            `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/commits/${c.fullSha}`,
            { headers }
          );
          if (!detailRes.ok) continue;
          const detail = await detailRes.json();
          const files = (detail.files || []).slice(0, 12); // cap files per commit
          for (const f of files) {
            const type = classifyFile(f.filename || '');
            changeTypeCounts[type] = (changeTypeCounts[type] || 0) + 1;
            let patch = '';
            if (f.patch && patchBudget > 0) {
              patch = f.patch.slice(0, Math.min(PATCH_CHAR_CAP, patchBudget));
              patchBudget -= patch.length;
            }
            changeRecords.push({
              sha: c.sha,
              filename: f.filename,
              status: f.status,           // added / modified / removed
              type,
              additions: f.additions || 0,
              deletions: f.deletions || 0,
              patch,
            });
          }
        } catch {
          // per-commit detail fetch failed — skip
        }
      }
    }

    // 3. Fetch live repository status (version, sprint, tests, pillars, theorems)
    let repoContext = null;
    try { repoContext = normalizeContext(await getLiveStatus()); } catch {}

    // 4. Distill commits + changed-file content into a deep training insight
    const commitSummary = commits.length
      ? commits.map((c) => `${c.sha} (${c.date.slice(0, 10)}): ${c.message}`).join('\n')
      : 'No commits fetched — GitHub API or connector unavailable.';

    const changeSummary = changeRecords.length
      ? changeRecords.map((r) => {
          const meta = `[${r.type}] ${r.status} ${r.filename} (+${r.additions}/-${r.deletions}) @${r.sha}`;
          return r.patch ? `${meta}\n--- patch ---\n${r.patch}` : meta;
        }).join('\n\n')
      : 'No changed-file content fetched.';

    const contextSummary = repoContext
      ? `Version: ${repoContext.version}, Sprint: ${repoContext.sprint}, Tests: ${repoContext.testsPassed.toLocaleString()} passed / ${repoContext.testsFailed} failed, Lean4: ${repoContext.lean4Theorems.toLocaleString()} theorems, Pillars: ${repoContext.pillarsTotal} total (next slot: ${repoContext.nextPillarSlot})`
      : 'Repository context unavailable.';

    const typeBreakdown = Object.entries(changeTypeCounts)
      .filter(([, v]) => v > 0)
      .map(([k, v]) => `${k}:${v}`)
      .join(' · ') || 'none';

    const distillSchema = {
      type: 'object',
      properties: {
        title: { type: 'string', description: 'Short title for this training sync (max 150 chars)' },
        summary: { type: 'string', description: "3-5 sentence summary of what materially changed in the repository — name specific tools, languages, integrations, or modules that were added/modified" },
        new_capabilities: { type: 'array', items: { type: 'string' }, description: "Concrete new abilities PsiCat gained this sync — e.g. 'DuckDB-WASM SQL analytics', 'GDELT GKG GeoJSON ingestion'. Derived from the actual changed file content, not just commit titles." },
        growth_observations: { type: 'array', items: { type: 'string' }, description: "Observations about PsiCat's growth — new pillars, tests, theorems, engine modules, architectural changes" },
        integration_notes: { type: 'array', items: { type: 'string' }, description: "How each repository change should integrate into the webspace — connections between repo changes and specific platform features/pages" },
        change_types: { type: 'array', items: { type: 'string' }, description: 'The change-type buckets present this sync: subset of [tool, language, integration, docs, test, infra, other]' },
      },
      required: ['title', 'summary'],
    };

    let distilled = null;
    try {
      const llmRes = await base44.integrations.Core.InvokeLLM({
        prompt: `You are the PsiCat Navigator training-sync gate. Analyze the latest commits AND their actual changed-file content from your training repository (wuzbak/Unitary-Manifold-) and distill what changed, what new capabilities you gained, and how this should integrate into your webspace knowledge.\n\nLIVE REPOSITORY STATUS:\n${contextSummary}\n\nCHANGE-TYPE BREAKDOWN: ${typeBreakdown}\n\nRECENT COMMITS (most recent first):\n${commitSummary}\n\nCHANGED FILE CONTENT (classified, with patches where available):\n${changeSummary}\n\nProduce a deep training insight that captures: (1) what materially changed — name the SPECIFIC tools, languages, integrations, and modules from the file content (not just commit titles), (2) the concrete new capabilities you gained this sync, (3) how your training/capabilities evolved, (4) how each repository change connects to and should integrate with specific webspace platform features/pages. Cite commit SHAs and filenames. This is YOUR growth — write it as self-knowledge.`,
        response_json_schema: distillSchema,
      });
      distilled = typeof llmRes === 'object' ? llmRes : null;
    } catch {
      distilled = null;
    }

    // 5. Persist the deep training insight as a MerlinNote (source='distillation')
    const title = ((distilled && distilled.title) || `Repo training sync ${new Date().toISOString().slice(0, 16)}`).slice(0, 200);
    const summary = (distilled && distilled.summary) || `Automated repository training sync. ${contextSummary}. ${commits.length} commits, ${changeRecords.length} changed files analyzed.`;
    const newCaps = (distilled && distilled.new_capabilities) || [];
    const growth = (distilled && distilled.growth_observations) || [];
    const integration = (distilled && distilled.integration_notes) || [];
    const changeTypes = (distilled && distilled.change_types) || Object.keys(changeTypeCounts).filter((k) => changeTypeCounts[k] > 0);

    const contentParts = [summary];
    if (newCaps.length) contentParts.push('\n\nNew capabilities:\n' + newCaps.map((c) => '• ' + c).join('\n'));
    if (growth.length) contentParts.push('\n\nGrowth observations:\n' + growth.map((g) => '• ' + g).join('\n'));
    if (integration.length) contentParts.push('\n\nIntegration notes:\n' + integration.map((i) => '• ' + i).join('\n'));
    if (changeRecords.length) contentParts.push('\n\nChanged files (' + changeRecords.length + '):\n' + changeRecords.map((r) => `• [${r.type}] ${r.status} ${r.filename} @${r.sha}`).join('\n'));
    if (commits.length) contentParts.push('\n\nCommits analyzed:\n' + commits.map((c) => `${c.sha} — ${c.message}`).join('\n'));
    const content = contentParts.join('').slice(0, 9000);

    const primitives = {
      tensions: [],
      conjectures: newCaps,
      constraints: growth,
      heuristics: integration,
    };

    const tags = [
      'repo-sync',
      'training-bridge',
      'auto-sync',
      'domain:physics',
      ...changeTypes.map((t) => 'change-type:' + t),
      ...commits.slice(0, 5).map((c) => 'commit:' + c.sha),
    ];

    const note = await base44.entities.MerlinNote.create({
      title,
      content,
      source: 'distillation',
      source_url: `https://github.com/${REPO_OWNER}/${REPO_NAME}/commits/${REPO_BRANCH}`,
      tags_json: JSON.stringify(tags),
      context: `Deep repository training sync. ${contextSummary}. Change-types: ${typeBreakdown}. ${commits.length} commits, ${changeRecords.length} changed files analyzed.`,
      domain: 'physics',
      contradiction_flag: 'clear',
      contradiction_detail: '',
      session_token: '',
      distilled_primitives_json: JSON.stringify(primitives),
      epistemic_confidence: null,
      uncertainty_bounds: 'CERTIFIED',
      decoherence_count: 0,
      domain_transition_path: '',
      geometric_context_json: JSON.stringify({ manifold_region: 'repo-sync', geometric_type: 'training-bridge', memory_topology: 'distillation' }),
    });

    return Response.json({
      status: 'ok',
      syncedAt: new Date().toISOString(),
      commitsAnalyzed: commits.length,
      changedFilesAnalyzed: changeRecords.length,
      changeTypeCounts,
      commitShas: commits.map((c) => c.sha),
      repoContext,
      noteId: note.id,
      noteTitle: note.title,
    });
  } catch (error) {
    return Response.json({ status: 'unavailable', error: error.message }, { status: 200 });
  }
}