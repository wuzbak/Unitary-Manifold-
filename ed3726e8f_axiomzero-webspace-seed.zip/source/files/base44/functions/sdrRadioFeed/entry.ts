/**
 * sdrRadioFeed — RSS/Atom proxy for the All-Band SDR Radio Console.
 *
 * Fetches and normalizes feeds from SDR software hubs, community blogs,
 * audio archives, and NASA space feeds. Handles both RSS 2.0 and Atom XML.
 *
 * Categories:
 *   software   — SDR++, Gqrx, SDRangel (GitHub Atom release feeds)
 *   community  — SWLing Post, RTL-SDR Blog
 *   archive    — Shortwave Radio Audio Archive
 *   nasa       — NASA main, JPL, CNEOS
 *
 * Query param: { categories: string[] } — filters feeds by feedCategory.
 * Safeguards: UA-masking, XXE-safe regex parsing, partial-outage tolerant.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const FEEDS = [
  // ── SDR Software Releases (GitHub Atom) ──
  { id: 'sdrpp', outlet: 'SDR++', feedCategory: 'software', trustTag: 'Modular multi-platform SDR receiver — AlexandreRouma/SDRPlusPlus',
    url: 'https://github.com/AlexandreRouma/SDRPlusPlus/releases.atom' },
  { id: 'gqrx', outlet: 'Gqrx SDR', feedCategory: 'software', trustTag: 'Open-source multi-band SDR via GNU Radio — gqrx-sdr/gqrx',
    url: 'https://github.com/gqrx-sdr/gqrx/releases.atom' },
  { id: 'sdrangel', outlet: 'SDRangel', feedCategory: 'software', trustTag: 'High-tier open source TX/RX signal analyzer — f4exb/sdrangel',
    url: 'https://github.com/f4exb/sdrangel/releases.atom' },
  // ── Community Blogs ──
  { id: 'swling', outlet: 'The SWLing Post', feedCategory: 'community', trustTag: 'All-band monitoring, hardware reviews, propagation',
    url: 'https://swling.com/blog/feed/' },
  { id: 'rtlsdr', outlet: 'RTL-SDR Blog', feedCategory: 'community', trustTag: 'Open-source radio tutorials, driver releases, and fixes',
    url: 'https://www.rtl-sdr.com/feed/' },
  // ── Audio Archive ──
  { id: 'swarchive', outlet: 'Shortwave Radio Audio Archive', feedCategory: 'archive', trustTag: 'Digital recordings of modern/historical SW bands',
    url: 'https://shortwavearchive.com/feed/' },
  // ── NASA Space Feeds ──
  { id: 'nasa_main', outlet: 'NASA', feedCategory: 'nasa', trustTag: 'NASA site-wide master news stream — official agency feed',
    url: 'https://www.nasa.gov/feed/' },
  { id: 'nasa_jpl', outlet: 'NASA JPL', feedCategory: 'nasa', trustTag: 'Jet Propulsion Lab — deep-space robotic telemetry',
    url: 'https://www.jpl.nasa.gov/feeds/news/' },
  { id: 'nasa_cneos', outlet: 'NASA CNEOS', feedCategory: 'nasa', trustTag: 'Center for Near-Earth Object Studies — NEO tracking',
    url: 'https://cneos.jpl.nasa.gov/feed/' },
  // ── NPR News & Topic Feeds ──
  { id: 'npr_top', outlet: 'NPR Top Stories', feedCategory: 'npr', trustTag: 'NPR main national and global headlines',
    url: 'https://feeds.npr.org/1001/rss.xml' },
  { id: 'npr_world', outlet: 'NPR World', feedCategory: 'npr', trustTag: 'NPR international bureau reporting',
    url: 'https://feeds.npr.org/1004/rss.xml' },
  { id: 'npr_science', outlet: 'NPR Science', feedCategory: 'npr', trustTag: 'NPR empirical research and space science',
    url: 'https://feeds.npr.org/1007/rss.xml' },
  { id: 'npr_health', outlet: 'NPR Health', feedCategory: 'npr', trustTag: 'NPR medicine, virology, healthcare policy',
    url: 'https://feeds.npr.org/1128/rss.xml' },
  { id: 'npr_tech', outlet: 'NPR Technology', feedCategory: 'npr', trustTag: 'NPR computing, tech policy, engineering',
    url: 'https://feeds.npr.org/1009/rss.xml' },
  // ── NPR Audio Podcast (hourly news update) ──
  { id: 'npr_news_now', outlet: 'NPR News Now', feedCategory: 'npr-audio', trustTag: 'Hourly 5-minute global briefing — NPR podcast',
    url: 'https://feeds.npr.org/500005/podcast.xml' },
];

import { parseFeed } from '../../shared/rssParser.ts';

// Module-level cache — RSS feeds update every 5-30 min; cache for 5 min
const feedCache = new Map<string, { data: any; fetchedAt: number }>();
const FEED_CACHE_TTL = 5 * 60 * 1000;

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    let body: any = {};
    try { body = await req.json(); } catch {}
    const requestedCategories: string[] | undefined = body.categories;

    const cacheKey = (requestedCategories || ['all']).sort().join(',');
    const cached = feedCache.get(cacheKey);
    if (cached && Date.now() - cached.fetchedAt < FEED_CACHE_TTL) {
      return Response.json({ ...cached.data, cached: true });
    }

    const feeds = requestedCategories && requestedCategories.length
      ? FEEDS.filter((f) => requestedCategories.includes(f.feedCategory))
      : FEEDS;

    const results = await Promise.allSettled(feeds.map((f) =>
      fetch(f.url, {
        headers: { 'User-Agent': 'AxiomZero-SDR-Monitor/1.0', Accept: 'application/rss+xml,application/xml,text/xml' },
      }).then((r) => (r.ok ? r.text() : null)).then((xml) => (xml ? parseFeed(xml, f).slice(0, 6) : []))
    ));

    const headlines: any[] = [];
    let okCount = 0;
    results.forEach((res) => {
      if (res.status === 'fulfilled' && res.value.length) {
        headlines.push(...res.value);
        okCount++;
      }
    });

    headlines.sort((a, b) =>
      (new Date(b.published || 0).getTime()) - (new Date(a.published || 0).getTime())
    );

    const status = okCount === 0 ? 'unavailable' : okCount < feeds.length ? 'partial' : 'live';

    const result = {
      headlines,
      count: headlines.length,
      status,
      sources: okCount,
      total: feeds.length,
      timestamp: new Date().toISOString(),
    };
    feedCache.set(cacheKey, { data: result, fetchedAt: Date.now() });
    return Response.json({ ...result, cached: false });
  } catch (error) {
    return Response.json({ headlines: [], status: 'unavailable', message: error.message });
  }
}