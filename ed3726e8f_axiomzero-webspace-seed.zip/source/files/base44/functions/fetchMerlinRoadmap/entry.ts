/**
 * fetchMerlinRoadmap — Live PsiCat frontier & smart roadmap data from the repository.
 *
 * Fetches PSICAT_FRONTIER_ROADMAP.md and PSICAT_SMART_ROADMAP.md from
 * 12-AZ-IP/20-psicat-navigator/ via the authorized GitHub OAuth connector.
 * Falls back to the legacy merlin-navigator path + MERLIN_ prefix if the new
 * path 404s (repo was renamed merlin-navigator → psicat-navigator).
 *
 * Parses them into a structured summary (frontier items, smart roadmap items,
 * timeline, capabilities) that Merlin's system prompt can inject.
 *
 * Source: https://github.com/wuzbak/Unitary-Manifold-
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const REPO_OWNER = 'wuzbak';
const REPO_NAME = 'Unitary-Manifold-';
const REPO_BRANCH = 'main';
const PSICAT_PATH = '12-AZ-IP/20-psicat-navigator';
const LEGACY_PATH = '12-AZ-IP/20-merlin-navigator';
const MAX_CHARS = 200000;

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    let accessToken;
    try {
      const conn = await base44.asServiceRole.connectors.getConnection('github');
      accessToken = conn.accessToken;
    } catch {
      return Response.json({
        error: 'GitHub connector not authorized', status: 'missing-credentials',
        frontierRoadmap: null, smartRoadmap: null, roadmapSummary: null,
        fetchedAt: new Date().toISOString(),
      }, { status: 200 });
    }

    const headers = {
      'Authorization': `Bearer ${accessToken}`,
      'Accept': 'application/vnd.github+json',
      'User-Agent': 'AxiomZero-App',
      'X-GitHub-Api-Version': '2022-11-28',
    };

    // Try PSICAT_ filenames in psicat-navigator first, fall back to MERLIN_ in merlin-navigator
    const [frontierContent, smartContent] = await Promise.all([
      fetchFileWithFallback('PSICAT_FRONTIER_ROADMAP.md', 'MERLIN_FRONTIER_ROADMAP.md', headers),
      fetchFileWithFallback('PSICAT_SMART_ROADMAP.md', 'MERLIN_SMART_ROADMAP.md', headers),
    ]);

    const result = {
      frontierRoadmap: frontierContent ? { content: frontierContent, path: `${PSICAT_PATH}/PSICAT_FRONTIER_ROADMAP.md` } : null,
      smartRoadmap: smartContent ? { content: smartContent, path: `${PSICAT_PATH}/PSICAT_SMART_ROADMAP.md` } : null,
      roadmapSummary: null,
      fetchedAt: new Date().toISOString(),
    };

    if (frontierContent || smartContent) {
      result.roadmapSummary = parseRoadmapSummary(frontierContent, smartContent);
    }

    return Response.json(result);
  } catch (error) {
    return Response.json({
      error: error.message, status: 'unavailable',
      frontierRoadmap: null, smartRoadmap: null, roadmapSummary: null,
      fetchedAt: new Date().toISOString(),
    }, { status: 200 });
  }
}

async function fetchFileWithFallback(primaryName: string, legacyName: string, headers: Record<string, string>) {
  let content = await fetchFile(`${PSICAT_PATH}/${primaryName}`, headers);
  if (content) return content;
  content = await fetchFile(`${LEGACY_PATH}/${legacyName}`, headers);
  return content;
}

async function fetchFile(fullPath: string, headers: Record<string, string>) {
  try {
    const res = await fetch(
      `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${fullPath}?ref=${REPO_BRANCH}`,
      { headers: { ...headers, 'Accept': 'application/vnd.github.raw+json' } }
    );
    if (!res.ok) return null;
    const content = await res.text();
    return content.slice(0, MAX_CHARS);
  } catch {
    return null;
  }
}

function parseRoadmapSummary(frontierContent, smartContent) {
  const frontierItems = [];
  const smartItems = [];
  const phases = [];
  const themes = new Set();

  if (frontierContent) {
    const lines = frontierContent.split('\n');
    let currentSection = null;
    for (const line of lines) {
      const h2 = line.match(/^##\s+(.+)/);
      if (h2) { currentSection = h2[1].trim(); phases.push(currentSection); continue; }
      const bullet = line.match(/^\s*[-*]\s+\*\*([^*]+)\*\*[:\s]*(.*)/);
      if (bullet && currentSection) {
        frontierItems.push({ section: currentSection, title: bullet[1].trim(), description: bullet[2].trim().slice(0, 300) });
        bullet[1].trim().toLowerCase().split(/\s+/).forEach(w => { if (w.length > 4) themes.add(w); });
      }
    }
  }

  if (smartContent) {
    const lines = smartContent.split('\n');
    let currentSection = null;
    for (const line of lines) {
      const h2 = line.match(/^##\s+(.+)/);
      if (h2) { currentSection = h2[1].trim(); continue; }
      const bullet = line.match(/^\s*[-*]\s+\*\*([^*]+)\*\*[:\s]*(.*)/);
      if (bullet) {
        smartItems.push({ section: currentSection || 'Smart Roadmap', title: bullet[1].trim(), description: bullet[2].trim().slice(0, 300) });
      }
      const numbered = line.match(/^\s*(\d+)\.\s+\*\*([^*]+)\*\*[:\s]*(.*)/);
      if (numbered) {
        smartItems.push({ section: currentSection || 'Smart Roadmap', priority: parseInt(numbered[1]), title: numbered[2].trim(), description: numbered[3].trim().slice(0, 300) });
      }
    }
  }

  return {
    frontierItems: frontierItems.slice(0, 25),
    smartItems: smartItems.slice(0, 15),
    phases: [...new Set(phases)].slice(0, 10),
    themes: [...themes].slice(0, 15),
    frontierItemCount: frontierItems.length,
    smartItemCount: smartItems.length,
    hasFrontier: !!frontierContent,
    hasSmart: !!smartContent,
  };
}