/**
 * merlinSeedMemory — Foundational memory seeding for Merlin's sovereign knowledge.
 *
 * Admin-only. Creates MerlinNote records in bulk from the seed data below.
 * Tags every note source:'internal' and domain-tagged for the ECLIPSA firewall.
 *
 * Seed sets:
 *   - 'physics'      — 208 pillars, open gaps, tensions, sprints
 *   - 'platform'     — governance, 22 products, ECLIPSA, Pentad
 *   - 'cross-domain' — film, journalism, earth-science, dnd baselines
 *   - 'all'          — everything (default)
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

interface SeedNote {
  title: string;
  content: string;
  domain: string;
  tags: string[];
  context: string;
  epistemic_confidence?: number;
  uncertainty_bounds?: string;
}

const PHYSICS_SEED: SeedNote[] = [
  {
    title: '208 Hardgate Pillars — Certified Invariants',
    domain: 'physics',
    tags: ['hardgate', 'pillars', 'certified', 'kernel'],
    context: 'Foundational physics backbone — the non-negotiable certified truths',
    content: 'The Unitary Manifold Framework has 208 hardgate pillars — certified invariants that cannot be crossed. These include: k_CS = 74 (Chern-Simons level, the (5,7) sector fingerprint), n_w = 5 (winding resonance, Pillar 789 — unique integer satisfying all three CMB constraints), w_a = 0 (cosmological constant, Pillar 301), r = 0.0315 (tensor-to-scalar ratio, Pillar 396), n_s = 0.9635 (scalar spectral index), 5D Kaluza-Klein dimensionality. The compactification kernel compresses all pillars into a singular seed with fingerprint (5, 7, 74). Every physics claim must cite the relevant Pillar number and its gate status (HARDGATE / ADJACENT_TRACK / OPEN_GAP / ARCHITECTURE_LIMIT).',
  },
  {
    title: 'Open Gaps — Known Architecture Limits',
    domain: 'physics',
    tags: ['open-gap', 'architecture-limit', 'certified'],
    context: 'Known gaps that are ARCHITECTURE_LIMIT — not bugs, but structural boundaries',
    content: 'Six open gaps classified as ARCHITECTURE_LIMIT: (1) CMB acoustic peak amplitude suppressed x4-7 (33.6% irreducible A_s mismatch), (2) DESI w_a != 0 tension at 2.30 sigma (Pillar 301, ARCHITECTURE_LIMIT_CERTIFIED), (3) dm2_21 residual tension above closure threshold (1.71 sigma, TENSION_ESCALATED, Pillar 774/796 — JUNO 2026 will resolve), (4) Cosmological constant KK hierarchy (10^55 gap, Pillar 792), (5) ADM time synchronisation, (6) Yukawa sector is FITTED, not top-down derived. These are not failures — they are the honest boundaries of what the current framework can derive from geometry alone.',
    epistemic_confidence: 0.336,
    uncertainty_bounds: 'ARCHITECTURE_LIMIT',
  },
  {
    title: 'Certified Tensions — Live Experiment Watch',
    domain: 'physics',
    tags: ['tension', 'certified', 'falsification', 'live-experiments'],
    context: 'Tensions being monitored against kill conditions by the Empirical Observatory',
    content: 'Five certified tensions under active monitoring: (1) dm2_21 at 1.71 sigma — TENSION_ESCALATED, Pillar 774/796, JUNO 2026 is the primary resolver. (2) CMB peak suppression at 33.6% — ARCHITECTURE_LIMIT, irreducible A_s mismatch. (3) r-tension: r=0.0315 vs ACT DR6 r<0.016, gap ~2 sigma, ARCHITECTURE_LIMIT_CERTIFIED, Pillar 396. (4) w_a tension with DESI DR2 at 2.30 sigma, ARCHITECTURE_LIMIT_CERTIFIED, Pillar 301; DESI DR3 tripwire Pillar 486. (5) CC KK hierarchy at 10^55, ARCHITECTURE_LIMIT, Pillar 792. The Empirical Observatory Monitor workflow polls DESI DR3, JUNO, and LiteBIRD weekly (Monday 9am PT) for new releases against these kill thresholds.',
    epistemic_confidence: 0.91,
    uncertainty_bounds: 'TENSION_ESCALATED',
  },
  {
    title: 'v23 Sprint Results — Certified Pillars',
    domain: 'physics',
    tags: ['sprint', 'v23', 'certified', 'pillars'],
    context: 'Sprint CH certified results — the latest physics derivations',
    content: 'v23 sprint certified seven pillars: Pillar 786 (neutrino mass ordering — NH preferred, m1~0, m2~8.6 meV, m3~50.9 meV, Sum m_nu~0.0596 eV). Pillar 787 (falsification routing oracle — 7 live experiments with explicit kill conditions). Pillar 789 (winding resonance stability basin — n_w=5 is the unique integer satisfying all three CMB constraints). Pillar 790 (dark matter KK tower — M_KK~1.0 TeV candidate). Pillar 792 (cosmological constant KK vacuum energy). Pillar 793 (graviton mass bound — zero-mode massless, KK graviton ~1.0 TeV, HL-LHC PASS). The G4 criterion 2 is TYPE_B_CANDIDATE (frac_diff=0.1816, partial score 0.8184).',
  },
  {
    title: '5D Kaluza-Klein Metric — Geometric Foundation',
    domain: 'physics',
    tags: ['kaluza-klein', 'metric', 'geometry', 'foundation'],
    context: 'The geometric foundation from which all SM parameters are derived',
    content: 'The 5D Kaluza-Klein metric G_AB packages g_munu (4D gravity), B_mu (gauge field), and phi (radion). The (5,7) sector gives k_CS = 5^2 + 7^2 = 74. Irreversibility is geometrised into the 5th dimension. Standard Model parameters are derived from geometry — not fitted. The compactification kernel compresses the entire framework into a singular seed with fingerprint (5, 7, 74) from which it can be reconstructed. Current status: repository-level internal mathematical self-consistency established; external empirical confirmation pending. The Yukawa sector remains FITTED, not top-down derived (ARCHITECTURE_LIMIT).',
    epistemic_confidence: 1.0,
    uncertainty_bounds: 'CERTIFIED',
  },
  {
    title: 'Falsification Routing Oracle — 7 Live Experiments',
    domain: 'physics',
    tags: ['falsification', 'oracle', 'experiments', 'kill-conditions'],
    context: 'Pillar 787 — the falsification routing oracle with explicit kill conditions',
    content: 'Pillar 787 established the falsification routing oracle — 7 live experiments with explicit kill conditions: (1) LiteBIRD ~2032 — tests r=0.0315, kill if r<0.016 confirmed. (2) DESI DR3 — tests w_a=0, kill if w_a!=0 at >3 sigma. (3) JUNO 2026 — tests dm2_21, resolves 1.71 sigma tension. (4) CMB-S4 — tests n_s and spectral features. (5) HL-LHC — tests KK graviton ~1.0 TeV, PASS so far. (6) nEDM — tests CP violation geometry. (7) XENON-nT — tests dark matter KK tower M_KK~1.0 TeV. Each experiment has a PASS/TENSION/FALSIFIED verdict and z-test statistics. Results are SHA-256 signed.',
    epistemic_confidence: 0.95,
    uncertainty_bounds: 'CERTIFIED',
  },
];

const PLATFORM_SEED: SeedNote[] = [
  {
    title: 'Pentad Governance — 3:2 Scaffold Framework',
    domain: 'physics',
    tags: ['pentad', 'governance', 'framework', 'sectors'],
    context: 'The governance framework with 5-sector distributed authority',
    content: 'The Pentad governance framework implements a 3:2 Scaffold — 5 sectors of distributed authority: (1) Computational — logic, verification, Lean4. (2) Relational — data flow, entity relationships. (3) Intentional — goal routing, agent orchestration. (4) Physical — physics derivations, empirical grounding. (5) Biological — living systems, ecological modeling. Cross-sector attestation uses SHA-256 state hashing. HILS (Human-in-the-Loop Systems) invariants are enforced: humans retain exclusive control over pillar numbering, authorship claims, and falsification conditions. The Omega Oracle provides capstone synthesis across all 5 sectors.',
  },
  {
    title: 'ECLIPSA Sentinel — Epistemic Containment Watchdog',
    domain: 'physics',
    tags: ['eclipsa', 'sentinel', 'guardrails', 'safety', 'epistemic'],
    context: 'The epistemic containment watchdog — note the spelling: E-C-L-I-P-S-A',
    content: 'ECLIPSA is the epistemic containment sentinel (spelling: E-C-L-I-P-S-A). It enforces: (1) PII sanitization on all distilled insights before durable commit. (2) Contradiction gating against the 208 hardgate pillars — premises conflicting with certified invariants are tagged [CONTRADICTION_FLAGGED] and routed to Falsification Lab. (3) Epistemic firewall — domain-tagged notes prevent speculative creative work from contaminating the Lean4-verified physics core. (4) Threat level monitoring (GREEN/AMBER/CRIMSON). (5) Audit reports and alert feed. ECLIPSA does not override Merlin — Merlin works within its guardrails. Every distilled insight passes through three gates: ECLIPSA PII sanitization, LLM distillation, contradiction gate.',
  },
  {
    title: '22 AZ Products — Canonical Portfolio',
    domain: 'general',
    tags: ['products', 'portfolio', 'az-products', 'catalog'],
    context: 'The complete 12-AZ-IP product portfolio — 22 canonical products',
    content: 'The 12-AZ-IP repository houses 22 canonical products: 01-axiom-os (162 tests), 02-az-kernel (5D KK Rust kernel), 03-eige (Election Guardian, 449 tests), 04-um-sos (7-layer Scientific OS), 05-uos-kernel (566 tests), 06-omega-synthesis (170 tests), 07-holon-zero (347 tests), 08-axiom-journalist, 09-omegaholon, 10-filmers-companion, 11-terra-os (Earth Sciences: TerraOS + LithosOS + BotanicaOS), 12-lithos-os, 13-delphi (9 reads), 14-sdam (ggwave/AES-256-GCM), 15-pentacorder (108 tests), 16-oracle (Omega Oracle, 83 tests), 17-um-image-generator (113 tests), 18-um-reader (302 entries, 90 tests), 19-falsification-observatory (112 tests), 20-merlin-navigator (149 tests — this is Merlin), 21-geo-monitor (121 tests), 22-az-sge (229 tests). Theory by ThomasCory Walker-Pearson; code architecture by GitHub Copilot (AI). Licensed under Defensive Public Commons License v1.0.',
  },
  {
    title: 'Merlin Navigator — Product 20 Self-Knowledge',
    domain: 'physics',
    tags: ['merlin', 'navigator', 'self-knowledge', 'product-20'],
    context: 'Merlin own architecture — Product 20 in the 12-AZ-IP portfolio',
    content: 'Merlin is Product 20 (12-AZ-IP/20-merlin-navigator) — the sovereign-local AI navigator running the v1 Replacement Program. Architecture: primary sovereign local model lane with OpenRouter fallback. Multi-stage benchmark corpus (Stage A/B/C) measuring latency, token cost, energy, and quality against the incumbent external-model path. Per-run telemetry tracks every inference. Multi-tier sovereign memory: volatile ephemeral (browser holds zero history), durable cross-device (MerlinSession), distilled insights (MerlinNote), contradiction tracking. 53 toolkit functions via /api/agentInvoke. Pentad kernel routing (KERNEL_P/R/A/G/S) gates every inference deterministically. The Identity surface cryptographically verifies Merlin is genuine. The Sentinel surface enforces ECLIPSA guardrails.',
  },
  {
    title: 'Pentad Kernel Routing Architecture',
    domain: 'physics',
    tags: ['pentad', 'kernel', 'routing', 'architecture'],
    context: 'The 5-kernel routing model that gates every Merlin inference',
    content: 'The Pentad kernel routing architecture routes each query to one of five specialized kernels based on keyword analysis: KERNEL_P (priority 4 — Proof/Lean): lean, theorem, proof, formal, verify. Routes to Lean4 formal verification. KERNEL_R (priority 3 — Routing/Tools): tool, route, schema, orchestrate, invoke. Routes to tool-routing for agent backend orchestration. KERNEL_A (priority 2 — Audit/Memory): memory, contradiction, audit, recall, drift. Routes to audit/memory for contradiction tracking and distilled insight recall. KERNEL_G (priority 1 — Governance/Safety): governance, refusal, safety, boundary, privilege, sentinel, policy. Routes to governance for ECLIPSA enforcement and privilege authorization. KERNEL_S (priority 0 — Standard, default fallback): routes to standard sovereign-local model lane. Routing is deterministic — keyword matching selects the kernel, and the kernel gates which model lane and tools are available.',
  },
  {
    title: 'Empirical Observatory Monitor — Weekly Workflow',
    domain: 'physics',
    tags: ['empirical', 'observatory', 'workflow', 'cron', 'monitoring'],
    context: 'The existing platform-side workflow that polls DESI, JUNO, LiteBIRD weekly',
    content: 'The Empirical Observatory Monitor is a platform-side workflow (base44/workflows/Empirical Observatory Monitor.jsonc) that runs as a weekly cron every Monday at 9am PT. It calls the empiricalObservatoryCheck backend function, which polls DESI DR3, JUNO, and LiteBIRD via web search for new releases and data drops. Tripwires are checked against certified kill thresholds: dm2_21 (1.71 sigma tension), w_a (2.30 sigma tension with DESI), r (0.0315 vs ACT DR6), CMB peak suppression (33.6%). When a tripwire fires, the workflow logs a MerlinNote with source:internal and kill-condition-triggered tags, and routes to Falsification Lab. Merlin can tell users "the empirical observatory is already being monitored weekly" — this is not a planned feature, it is an existing platform-side process.',
  },
];

const CROSS_DOMAIN_SEED: SeedNote[] = [
  {
    title: "Film Production Baseline — Filmer's Companion",
    domain: 'film',
    tags: ['film', 'production', 'filmer', 'baseline'],
    context: 'Foundational memory for the film production domain',
    content: "The Filmer's Companion is Product 10 — the Ultimate Film/Television Production Suite. 7 main sections: Dashboard, Pre-Production (Script, Cinematography, Locations), 10 IATSE-style Departments (Props, Set Dec, Camera, Wardrobe, HMU, Sound, Art, Lighting, Grip, Stunts — each with full PO procurement tracking), Cast & Crew (SAG/IATSE status pipeline), Production (Finance, AD Suite, Storyboard, Export), Library, Projects. Key standards: Axiom Omega 10 Principles, Guild minimums (SAG/DGA/WGA/IATSE/PGA), OSHA compliance, budget allocation across 11 categories, turnaround checker, DOOD (Day Out of Days), coverage validation. Merlin operates as a UPM/Producer expert on this page. Full book reproductions: Axiom Omega Production Guide + The Living Instrument.",
  },
  {
    title: 'Investigative Journalism Baseline — AXIOM Journalist',
    domain: 'journalism',
    tags: ['journalism', 'investigation', 'axiom-journalist', 'baseline'],
    context: 'Foundational memory for the investigative journalism domain',
    content: 'AXIOM Journalist is Product 08 — an autonomous multi-agent investigative platform. 5-agent pipeline: Researcher, Fact Checker, Legal Auditor, Editor, coordinated by Orchestrator. 6-stage investigation lifecycle. 5-tier confidence scoring. Live public records sources: SEC EDGAR, OpenCorporates, OCCRP Aleph, CourtListener, FEC, GovInfo, ICIJ Offshore Leaks, OpenSanctions, ProPublica Nonprofits, Wayback Machine. HILS gate on all publications. Watchlist monitoring with hit detection. Source tier hierarchy: (1) Trusted legitimate — court records, regulatory filings, FOIA. (2) Scholarly/academic. (3) Empirical. (4) Social media — avoid unless explicitly asked. Merlin operates as an investigative journalist expert with source tiering and confidence scoring.',
  },
  {
    title: 'Earth Science Baseline — TerraOS + LithosOS + BotanicaOS',
    domain: 'earth-science',
    tags: ['earth-science', 'terra', 'soil', 'plants', 'baseline'],
    context: 'Foundational memory for the earth science domain',
    content: 'TerraOS is Product 11 — unified Earth Sciences (TerraOS + LithosOS + BotanicaOS). 11 tabs: Soil & Water, Mineral ID, Plant ID, Medicinal Herbs, Image ID, Growing Guide, Companions & Guilds, Data Upload, Site Survey, Knowledge Library, Data Sources. Key data sources: USDA NRCS soil data, NSF Water Quality Index, IMA mineral standards, 4-IMPLICATIONS/botanical/ knowledge library (11 files), permaculture literature. Companion planting principles: nitrogen fixers, pest confusers, trap crops, pollinator attractors, dynamic accumulators. Merlin operates as a legitimate earth-science expert — not a physicist pretending to know plants. Hardiness zone lookup is hybrid (authoritative USDA data + latitude estimation).',
  },
  {
    title: 'D&D 5e/5.5e Baseline — Merlin DM Assistant',
    domain: 'dnd',
    tags: ['dnd', 'dungeon-master', 'campaign', 'baseline', '5e'],
    context: 'Foundational memory for the D&D domain',
    content: 'The Merlin D&D Assistant is a D&D 5e/5.5e campaign platform with DM, Player, and Solo modes. Core systems: deterministic dice engine (not random — reproducible), combat tracker with initiative and condition tracking, SRD compendium (classes, spells, items, monsters, backgrounds, species, conditions), encounter builder with CR-based balancing, character builder, world forge (locations, lore, factions, calendars, random tables), VTT battlemap with fog of war and tokens, homebrew forge (custom monsters, spells, items, subclasses), marketplace for homebrew packs. The ImportExportBar handles bundle compilation and parsing. Merlin operates as a DM assistant with full SRD knowledge — he does not hallucinate rules. When uncertain, he says so and cites the SRD page.',
  },
];

const ALL_SEEDS: Record<string, SeedNote[]> = {
  physics: PHYSICS_SEED,
  platform: PLATFORM_SEED,
  'cross-domain': CROSS_DOMAIN_SEED,
  all: [...PHYSICS_SEED, ...PLATFORM_SEED, ...CROSS_DOMAIN_SEED],
};

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Admin-only — regular users cannot seed Merlin's foundational memory
    if (user.role !== 'admin') {
      return Response.json({
        error: 'Admin access required to seed foundational memory',
        status: 'forbidden',
      }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const seedSet = body.seed_set || 'all';
    const dryRun = body.dry_run || false;

    const seeds = ALL_SEEDS[seedSet] || ALL_SEEDS.all;
    if (seeds.length === 0) {
      return Response.json({ error: `Unknown seed set: ${seedSet}`, status: 'error' }, { status: 400 });
    }

    if (dryRun) {
      return Response.json({
        status: 'dry-run',
        seed_set: seedSet,
        count: seeds.length,
        titles: seeds.map(s => s.title),
      });
    }

    // Build the bulk-create payload
    const records = seeds.map((seed: SeedNote) => ({
      title: seed.title,
      content: seed.content,
      source: 'internal',
      source_url: '',
      tags_json: JSON.stringify(['seed', 'foundational', `domain:${seed.domain}`, ...seed.tags]),
      context: seed.context,
      domain: seed.domain,
      contradiction_flag: 'clear',
      contradiction_detail: '',
      session_token: 'seed:foundation',
      distilled_primitives_json: '{}',
      sanitization_ledger: '[]',
      epistemic_confidence: seed.epistemic_confidence ?? null,
      uncertainty_bounds: seed.uncertainty_bounds || '',
      decoherence_count: 0,
      domain_transition_path: '',
    }));

    const created = await base44.entities.MerlinNote.bulkCreate(records);

    return Response.json({
      status: 'ok',
      seed_set: seedSet,
      seeded: created.length,
      titles: created.map((n: any) => n.title),
    });
  } catch (error) {
    return Response.json({
      status: 'unavailable',
      error: error.message,
    }, { status: 200 });
  }
}