/**
 * spaceWeatherProxy — server-side fetch of all NOAA SWPC space-weather slices
 * (solar wind plasma+mag, GOES X-ray, planetary Kp, alerts, OVATION aurora,
 * GOES proton flux / radiation, GOES EUV photon flux, F10.7 radio flux) plus
 * static NASA SDO/AIA imagery URLs. Centralizes parsing server-side to
 * eliminate client-side CORS gaps. Every slice is tolerant — a failed source
 * leaves its slice null and the consuming card renders an UnavailableCard.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const KP_SCALE = [
  { max: 4, level: 'G0', label: 'Quiet', color: '#3fb950' },
  { max: 5, level: 'G1', label: 'Minor', color: '#4dd0e1' },
  { max: 6, level: 'G2', label: 'Moderate', color: '#ffd60a' },
  { max: 7, level: 'G3', label: 'Strong', color: '#ff9f0a' },
  { max: 8, level: 'G4', label: 'Severe', color: '#ff6b6b' },
  { max: 10, level: 'G5', label: 'Extreme', color: '#bc8cff' },
];

function parseSolarWind(plasma, mag) {
  let speed = null, density = null, bz = null, bt = null;
  if (Array.isArray(plasma) && plasma.length > 1) {
    const last = plasma[plasma.length - 1];
    speed = parseFloat(last[2]); density = parseFloat(last[1]);
  }
  if (Array.isArray(mag) && mag.length > 1) {
    const last = mag[mag.length - 1];
    bz = parseFloat(last[3]); bt = parseFloat(last[4]);
  }
  if (speed == null && bz == null) return null;
  return { speed, density, bz, bt };
}

function parseAurora(json) {
  if (!json || !Array.isArray(json.coordinates)) return null;
  const THRESH = 0.3;
  let northMin = 90, southMax = -90;
  for (const entry of json.coordinates) {
    const lon = entry[0], lat = entry[1], prob = entry[2];
    if (prob >= THRESH) {
      if (lat > 0 && lat < northMin) northMin = lat;
      if (lat < 0 && lat > southMax) southMax = lat;
    }
  }
  return {
    northMin: northMin === 90 ? null : northMin,
    southMax: southMax === -90 ? null : southMax,
    forecastTime: json['Forecast Time'] || json['Observation Time'] || '',
  };
}

function parseRadiation(val) {
  let flux10 = null;
  if (Array.isArray(val) && val.length > 1) {
    for (let i = val.length - 1; i >= 0; i--) {
      const row = val[i];
      const ch = String(row[3] || row.energy_channel || '');
      if (ch.includes('10')) { flux10 = parseFloat(row[4] || row.flux); break; }
    }
    if (flux10 == null) { const last = val[val.length - 1]; flux10 = parseFloat(last[4] || last.flux); }
  }
  if (flux10 == null || isNaN(flux10)) return null;
  const sLevel = flux10 >= 1e5 ? { level: 'S5', color: '#bc8cff' } : flux10 >= 1e4 ? { level: 'S4', color: '#ff6b6b' } : flux10 >= 1e3 ? { level: 'S3', color: '#ff9f0a' } : flux10 >= 100 ? { level: 'S2', color: '#ffd60a' } : flux10 >= 10 ? { level: 'S1', color: '#4dd0e1' } : { level: 'S0', color: '#3fb950' };
  return { flux10, sLevel };
}

function parseEuv(val) {
  // GOES EUVS: per-minute per-wavelength records {time_tag, line, value, ...}.
  // Scan from the end (chronological) for the latest non-null 304 Å irradiance.
  if (!Array.isArray(val) || val.length === 0) return null;
  for (let i = val.length - 1; i >= 0; i--) {
    const row = val[i];
    if (String(row?.line) === '304' && row?.value != null && !isNaN(Number(row.value))) {
      return { flux: Number(row.value), band: '304 Å' };
    }
  }
  for (let i = val.length - 1; i >= 0; i--) {
    const row = val[i];
    if (row?.value != null && !isNaN(Number(row.value))) {
      return { flux: Number(row.value), band: `${row.line} Å` };
    }
  }
  return null;
}

function parseF107(val) {
  // f107_cm_flux.json: reverse-chronological array of {time_tag, flux, ...}.
  if (!Array.isArray(val) || val.length === 0) return null;
  const latest = val[0];
  const f = parseFloat(latest?.flux);
  if (isNaN(f)) return null;
  return { flux: f, time: latest?.time_tag || null };
}

// Module-level cache — SWPC data updates every 1-5 minutes; cache for 3 min to avoid rate limits
let swCache: any = null;
const SW_CACHE_TTL = 3 * 60 * 1000;

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    // Return cached data if fresh
    if (swCache && Date.now() - swCache.fetchedAt < SW_CACHE_TTL) {
      return Response.json({ ...swCache.data, cached: true, timestamp: new Date().toISOString() });
    }

    const SW = 'https://services.swpc.noaa.gov';
    // Migrated from deprecated /products/ endpoints to modern /json/ API paths (C3 fix)
    const [xrayRes, kpRes, alertsRes, auroraRes, plasmaRes, magRes, radRes, euvRes, f107Res] = await Promise.allSettled([
      fetch(`${SW}/json/goes/primary/xrays-6-hour.json`).then((r) => r.json()),
      fetch(`${SW}/json/planetary_k_index_1m.json`).then((r) => r.json()),
      fetch(`${SW}/products/alerts.json`).then((r) => r.json()),  // alerts has no /json/ equivalent yet
      fetch(`${SW}/json/ovation_aurora_latest.json`).then((r) => r.json()),
      fetch(`${SW}/json/ace/swepam/ace_swepam_1h.json`).then((r) => r.json()),
      fetch(`${SW}/json/ace/mag/ace_mag_1h.json`).then((r) => r.json()),
      fetch(`${SW}/json/goes/primary/integral-protons-1-day.json`).then((r) => r.json()),
      fetch(`${SW}/json/goes/primary/euvs-6-hour.json`).then((r) => r.json()),
      fetch(`${SW}/json/f107_cm_flux.json`).then((r) => r.json()),
    ]);

    let xray = null, kp = null, alerts = [];
    if (xrayRes.status === 'fulfilled' && Array.isArray(xrayRes.value) && xrayRes.value.length) {
      const short = xrayRes.value.filter((x) => x.energy === '0.05-0.4nm').slice(-1)[0];
      xray = short || xrayRes.value[xrayRes.value.length - 1];
    }
    if (kpRes.status === 'fulfilled' && Array.isArray(kpRes.value) && kpRes.value.length) {
      const last = kpRes.value[kpRes.value.length - 1];
      const v = parseFloat(last?.estimated_kp ?? last?.kp_index);
      if (!isNaN(v)) {
        const gi = KP_SCALE.find((s) => v <= s.max) || KP_SCALE[KP_SCALE.length - 1];
        kp = { time: last.time_tag, value: v, level: gi.level, label: gi.label, color: gi.color };
      }
    }
    if (alertsRes.status === 'fulfilled' && Array.isArray(alertsRes.value)) {
      alerts = alertsRes.value.slice(-15).reverse();
    }
    const aurora = auroraRes.status === 'fulfilled' ? parseAurora(auroraRes.value) : null;
    const solarWind = parseSolarWind(plasmaRes.status === 'fulfilled' ? plasmaRes.value : null, magRes.status === 'fulfilled' ? magRes.value : null);
    const radiation = radRes.status === 'fulfilled' ? parseRadiation(radRes.value) : null;
    const euv = euvRes.status === 'fulfilled' ? parseEuv(euvRes.value) : null;
    const f107 = f107Res.status === 'fulfilled' ? parseF107(f107Res.value) : null;

    const sdo = {
      channels: [
        { label: 'AIA 171 Å', band: 'gold', url: 'https://sdo.gsfc.nasa.gov/assets/img/latest/latest_512_0171.jpg' },
        { label: 'AIA 193 Å', band: 'yellow-green', url: 'https://sdo.gsfc.nasa.gov/assets/img/latest/latest_512_0193.jpg' },
        { label: 'AIA 304 Å', band: 'red', url: 'https://sdo.gsfc.nasa.gov/assets/img/latest/latest_512_0304.jpg' },
        { label: 'AIA 211 Å', band: 'purple', url: 'https://sdo.gsfc.nasa.gov/assets/img/latest/latest_512_0211.jpg' },
      ],
    };

    const result = {
      xray, kp, alerts, aurora, solarWind, radiation, euv, f107, sdo,
      timestamp: new Date().toISOString(),
    };
    swCache = { data: result, fetchedAt: Date.now() };
    return Response.json({ ...result, cached: false });
  } catch (error) {
    return Response.json({ error: (error as Error).message }, { status: 500 });
  }
}