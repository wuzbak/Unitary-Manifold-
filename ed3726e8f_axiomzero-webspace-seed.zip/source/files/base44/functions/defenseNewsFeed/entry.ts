/**
 * defenseNewsFeed — RSS proxy for the Defense & Tactical News Ticker on the
 * Geo Monitor page.
 *
 * Fetches headlines from NATO, National Guard, and DVIDS feeds, normalizes
 * them with outlet / category tags, and returns a unified array.
 *
 * Sources:
 *   NATO Press Releases (RSS)
 *   NATO Through Time podcast (Buzzsprout RSS)
 *   US National Guard News (RSS)
 *   DVIDS NATO TV (RSS)
 *
 * Safeguards: UA-masking (avoids 403s), XXE-safe regex parsing (no external
 * entity resolution). Partial-outage tolerant.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { parseFeed } from '../../shared/rssParser.ts';

const FEEDS = [
  { id: 'nato-press', outlet: 'Defense.gov News', feedCategory: 'defense', category: 'military',
    trustTag: 'Official US Department of Defense news and press releases',
    url: 'https://www.defense.gov/DesktopModules/ArticleCS/RSS.ashx?ContentType=1&Site=1065&max=20' },
  { id: 'nato-act', outlet: 'NATO ACT', feedCategory: 'defense', category: 'nato',
    trustTag: 'Allied Command Transformation — NATO news & insights',
    url: 'https://www.act.nato.int/feed/' },
  { id: 'national-guard', outlet: 'National Guard', feedCategory: 'defense', category: 'military',
    trustTag: 'Official US National Guard news wire',
    url: 'http://www.nationalguard.mil/DesktopModules/ArticleCS/RSS.ashx?ContentType=1&Site=688&Category=11199&max=20' },
  { id: 'dvids', outlet: 'DVIDS', feedCategory: 'defense', category: 'military',
    trustTag: 'Defense Visual Information Distribution Service — military media',
    url: 'https://www.dvidshub.net/rss/news' },
];

// Module-level cache — defense news updates every 5-30 min; cache for 5 min
let defCache: any = null;
const DEF_CACHE_TTL = 5 * 60 * 1000;

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    if (defCache && Date.now() - defCache.fetchedAt < DEF_CACHE_TTL) {
      return Response.json({ ...defCache.data, cached: true });
    }

    const results = await Promise.allSettled(FEEDS.map((f) =>
      fetch(f.url, {
        headers: { 'User-Agent': 'AxiomZero-DefenseMonitor/1.0', Accept: 'application/rss+xml,application/xml,text/xml' },
      }).then((r) => (r.ok ? r.text() : null)).then((xml) => (xml ? parseFeed(xml, f).slice(0, 8) : []))
    ));

    const headlines: any[] = [];
    let okCount = 0;
    results.forEach((res) => {
      if (res.status === 'fulfilled' && res.value.length) {
        headlines.push(...res.value);
        okCount++;
      }
    });

    headlines.sort((a, b) =>
      (new Date(b.published || 0).getTime()) - (new Date(a.published || 0).getTime())
    );

    const status = okCount === 0 ? 'unavailable' : okCount < FEEDS.length ? 'partial' : 'live';

    const result = {
      headlines,
      count: headlines.length,
      status,
      sources: okCount,
      total: FEEDS.length,
      timestamp: new Date().toISOString(),
    };
    defCache = { data: result, fetchedAt: Date.now() };
    return Response.json({ ...result, cached: false });
  } catch (error) {
    return Response.json({ headlines: [], status: 'unavailable', message: error.message });
  }
}