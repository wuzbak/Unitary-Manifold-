/**
 * gdeltEvents — keyless GDELT GKG GeoJSON v1 API for geolocated civil-unrest
 * news events. Queries the PROTEST / RIOT / MILITARY / COUP GDELT themes
 * (last 6h) in parallel and merges the GeoJSON point features into normalized
 * map events. ~15-min cadence.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const THEMES = ['PROTEST', 'RIOT', 'MILITARY', 'COUP'];

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    const results = await Promise.allSettled(THEMES.map((t) =>
      fetch(`https://api.gdeltproject.org/api/v1/gkg_geojson?QUERY=${encodeURIComponent(t)}&TIMESPAN=360&OUTPUTFIELDS=url,name,sharingimage,tone`, {
        headers: { 'User-Agent': 'AxiomZero-GeoMonitor' },
      }).then((r) => (r.ok ? r.json() : null))
    ));

    // Aggregate by ~0.1° location + theme (one event per location, count = mentions)
    const buckets: Record<string, any> = {};
    results.forEach((res, idx) => {
      if (res.status !== 'fulfilled' || !res.value) return;
      const feats = res.value.features || [];
      const theme = THEMES[idx];
      for (const f of feats) {
        const lon = f.geometry?.coordinates?.[0];
        const lat = f.geometry?.coordinates?.[1];
        if (lat == null || lon == null) continue;
        const rLat = Math.round(lat * 10) / 10;
        const rLon = Math.round(lon * 10) / 10;
        const k = `${theme}:${rLat},${rLon}`;
        const p = f.properties || {};
        if (!buckets[k]) buckets[k] = { theme, lat: rLat, lon: rLon, name: p.name || theme, url: p.url || null, count: 0 };
        const b = buckets[k];
        b.count++;
      }
    });

    const events = Object.values(buckets).map((b: any) => ({
      id: `gdelt-${b.theme}-${b.lat},${b.lon}`,
      type: 'civilUnrest',
      title: `${b.theme.charAt(0) + b.theme.slice(1).toLowerCase()} · ${b.name}${b.count > 1 ? ` (${b.count})` : ''}`,
      place: b.name,
      time: null,
      url: b.url,
      coords: [b.lat, b.lon],
      theme: b.theme,
      magnitude: b.count,
      severity: b.count >= 10 ? 'severe' : b.count >= 3 ? 'moderate' : 'minor',
    })).sort((a: any, b: any) => (b.magnitude as number) - (a.magnitude as number)).slice(0, 300);

    return Response.json({ events, count: events.length, source: 'GDELT GKG GeoJSON', timestamp: new Date().toISOString() });
  } catch (error) {
    return Response.json({ events: [], status: 'unavailable', message: (error as Error).message });
  }
}