import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { secrets } from 'base44:runtime';
import { makeSource, okResponse, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'GovInfo', 'No query provided');
    const key = secrets.get('GOVINFO_API_KEY');
    if (!key) return errResponse(query, 'GovInfo', 'GOVINFO_API_KEY not set');
    // GovInfo search is a POST with a JSON body (api.data.gov style key as query param).
    const url = `https://api.govinfo.gov/search?api_key=${encodeURIComponent(key)}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, pageSize: '10', offsetMark: '*', sorts: [{ field: 'score', sortOrder: 'DESC' }] }),
    });
    if (!res.ok) return errResponse(query, 'GovInfo', `API ${res.status}`);
    const data = await res.json();
    const results = data.results || data.packages || [];
    const sources = results.map((r: any) => makeSource({
      title: r.title || r.packageId || 'GovInfo result',
      tier: 1,
      source_type: 'Government publication (U.S. Code / CFR / Federal Register)',
      url_or_ref: r.detailsLink || r.uri || (r.packageId ? `https://www.govinfo.gov/pkg/${r.packageId}` : ''),
      date: r.dateIssued || r.date || r.lastModified || '',
      excerpt: r.summary || r.abstract || r.title || '',
      raw_metadata: r,
    }));
    return okResponse(sources, query, 'GovInfo');
  } catch (error) {
    return errResponse('', 'GovInfo', (error as Error).message);
  }
}