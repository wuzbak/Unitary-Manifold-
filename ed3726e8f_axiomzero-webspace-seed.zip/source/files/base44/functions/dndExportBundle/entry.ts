/**
 * dndExportBundle — Compiles a full character + campaign bundle for export.
 *
 * Gathers all related entities (character, campaign, inventory items, custom
 * spells, lore notes, encounters) into a single structured bundle. Returns the
 * bundle plus a formatted string for the requested format (json, markdown, html).
 * PDF is rendered client-side via jspdf from the structured bundle.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { format = 'json', characterId, campaignId } = body;

    // Gather all related data in parallel
    const queries = [];
    let character = null;
    let campaign = null;

    if (characterId) {
      character = await base44.entities.DnDCharacter.get(characterId);
    }
    if (campaignId) {
      campaign = await base44.entities.DnDCampaign.get(campaignId);
    }
    const cid = campaignId || character?.campaign_id || '';

    const [inventoryItems, customSpells, customItems, loreNotes, encounters, players] = await Promise.all([
      cid ? base44.entities.DnDInventoryItem.filter({ campaign_id: cid }, '-created_date', 500) : Promise.resolve([]),
      base44.entities.DnDCustomSpell.list('-created_date', 200),
      base44.entities.DnDCustomItem.list('-created_date', 200),
      cid ? base44.entities.DnDLoreArticle.filter({ campaign_id: cid }, '-created_date', 100) : Promise.resolve([]),
      cid ? base44.entities.DnDEncounter.filter({ campaign_id: cid }, '-created_date', 50) : Promise.resolve([]),
      cid ? base44.entities.DnDPlayer.filter({ campaign_id: cid }, '-created_date', 50) : Promise.resolve([]),
    ]);

    const bundle = {
      meta: {
        exportedAt: new Date().toISOString(),
        format,
        appVersion: 'Merlin D&D v1.2.0',
      },
      character: character ? cleanCharacter(character) : null,
      campaign: campaign ? cleanCampaign(campaign) : null,
      inventory: (inventoryItems || []).map(cleanInventory),
      customSpells: (customSpells || []).map(cleanSpell),
      customItems: (customItems || []).map(cleanCustomItem),
      loreNotes: (loreNotes || []).map(cleanLore),
      encounters: (encounters || []).map(cleanEncounter),
      players: (players || []).map((p) => ({ display_name: p.display_name, invite_code: p.invite_code })),
    };

    if (format === 'json') {
      return Response.json({
        bundle,
        content: JSON.stringify(bundle, null, 2),
        mimeType: 'application/json',
        ext: 'json',
      });
    }

    if (format === 'markdown') {
      return Response.json({
        bundle,
        content: buildMarkdown(bundle),
        mimeType: 'text/markdown',
        ext: 'md',
      });
    }

    if (format === 'html') {
      return Response.json({
        bundle,
        content: buildHtml(bundle),
        mimeType: 'text/html',
        ext: 'html',
      });
    }

    // PDF — client renders from bundle
    return Response.json({ bundle, content: null, mimeType: null, ext: 'pdf' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

function cleanCharacter(c) {
  return {
    name: c.name, species: c.species, klass: c.klass, background: c.background,
    level: c.level, alignment: c.alignment,
    ability_scores: safeParse(c.ability_scores_json),
    hp_current: c.hp_current, hp_max: c.hp_max, temp_hp: c.temp_hp,
    armor_class: c.armor_class, passive_perception: c.passive_perception,
    proficiency_bonus: c.proficiency_bonus,
    spellcasting_ability: c.spellcasting_ability,
    spell_save_dc: c.spell_save_dc, spell_attack_bonus: c.spell_attack_bonus,
    spell_slots: safeParse(c.spell_slots_json),
    spellbook: safeParse(c.spellbook_json),
    inventory: safeParse(c.inventory_json),
    notes: safeParse(c.notes_json),
    abilities: safeParse(c.abilities_json),
    conditions: safeParse(c.conditions_json),
    xp: c.xp, gold: c.gold, solo: c.solo,
  };
}

function cleanCampaign(c) {
  return {
    name: c.name, setting: c.setting, rules_edition: c.rules_edition,
    tone: c.tone, summary: c.summary, dm_name: c.dm_name,
    party_gold: c.party_gold, party_xp: c.party_xp,
  };
}

function cleanInventory(i) {
  return {
    name: i.name, kind: i.kind, quantity: i.quantity, rarity: i.rarity,
    equipped: i.equipped, description: i.description, price_paid: i.price_paid,
  };
}

function cleanSpell(s) {
  return {
    name: s.name, level: s.level, school: s.school,
    casting_time: s.casting_time, range: s.range, duration: s.duration,
    components: s.components, concentration: s.concentration, ritual: s.ritual,
    description: s.description, classes: safeParse(s.classes_json),
  };
}

function cleanCustomItem(i) {
  return {
    name: i.name, type: i.type, rarity: i.rarity, attunement: i.attunement,
    value: i.value, description: i.description,
  };
}

function cleanLore(l) {
  return { title: l.title, body: l.body, tags: safeParse(l.tags_json) };
}

function cleanEncounter(e) {
  return {
    title: e.title, monster_slugs: safeParse(e.monster_slugs_json),
    difficulty: e.difficulty, status: e.status,
  };
}

function safeParse(str) {
  if (!str) return [];
  if (typeof str !== 'string') return str;
  try { return JSON.parse(str); } catch { return []; }
}

function buildMarkdown(b) {
  const lines = [];
  lines.push(`# ${b.character?.name || b.campaign?.name || 'D&D Export'}`);
  lines.push('');
  if (b.character) {
    const c = b.character;
    lines.push(`## Character: ${c.name}`);
    lines.push(`**${c.species} ${c.klass} · Level ${c.level} · ${c.alignment}**`);
    lines.push('');
    lines.push(`- **HP:** ${c.hp_current}/${c.hp_max}${c.temp_hp ? ` (+${c.temp_hp} temp)` : ''}`);
    lines.push(`- **AC:** ${c.armor_class} · **Passive Perception:** ${c.passive_perception}`);
    lines.push(`- **Proficiency Bonus:** +${c.proficiency_bonus}`);
    lines.push(`- **XP:** ${c.xp} · **Gold:** ${c.gold}`);
    lines.push('');
    lines.push('### Ability Scores');
    const as = c.ability_scores || {};
    lines.push(`STR ${as.strength || 10} · DEX ${as.dexterity || 10} · CON ${as.constitution || 10}`);
    lines.push(`INT ${as.intelligence || 10} · WIS ${as.wisdom || 10} · CHA ${as.charisma || 10}`);
    lines.push('');
    if (c.spellcasting_ability) {
      lines.push(`### Spellcasting (${c.spellcasting_ability})`);
      lines.push(`Save DC ${c.spell_save_dc} · Attack +${c.spell_attack_bonus}`);
      if (c.spellbook?.length) lines.push(`**Spells:** ${c.spellbook.join(', ')}`);
      lines.push('');
    }
    if (c.abilities?.length) {
      lines.push('### Abilities & Traits');
      c.abilities.forEach((a) => lines.push(`- ${a}`));
      lines.push('');
    }
    if (c.inventory?.length) {
      lines.push('### Inventory');
      c.inventory.forEach((i) => lines.push(`- ${i.name || i}${i.quantity > 1 ? ` ×${i.quantity}` : ''}`));
      lines.push('');
    }
    if (c.notes?.length) {
      lines.push('### Notes');
      c.notes.forEach((n) => lines.push(`- ${n}`));
      lines.push('');
    }
  }
  if (b.campaign) {
    const c = b.campaign;
    lines.push(`## Campaign: ${c.name}`);
    lines.push(`**${c.setting} · ${c.rules_edition} · ${c.tone}**`);
    if (c.summary) lines.push(`\n${c.summary}`);
    lines.push('');
  }
  if (b.inventory?.length) {
    lines.push('## Party Inventory');
    b.inventory.forEach((i) => lines.push(`- ${i.name} (${i.kind}) ×${i.quantity} [${i.rarity}]`));
    lines.push('');
  }
  if (b.customSpells?.length) {
    lines.push('## Custom Spells');
    b.customSpells.forEach((s) => {
      lines.push(`### ${s.name} (${s.level === 0 ? 'Cantrip' : 'Level ' + s.level} ${s.school})`);
      lines.push(`*${s.casting_time} · ${s.range} · ${s.duration}${s.concentration ? ' · Conc' : ''}${s.ritual ? ' · Ritual' : ''}*`);
      lines.push(s.description);
      lines.push('');
    });
  }
  if (b.customItems?.length) {
    lines.push('## Custom Items');
    b.customItems.forEach((i) => {
      lines.push(`### ${i.name} [${i.rarity}]`);
      lines.push(i.description);
      lines.push('');
    });
  }
  if (b.loreNotes?.length) {
    lines.push('## Lore & Notes');
    b.loreNotes.forEach((l) => {
      lines.push(`### ${l.title}`);
      lines.push(l.body);
      lines.push('');
    });
  }
  return lines.join('\n');
}

function buildHtml(b) {
  const esc = (s) => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const title = b.character?.name || b.campaign?.name || 'D&D Export';
  let html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(title)}</title>`;
  html += `<style>body{font-family:Georgia,serif;max-width:800px;margin:40px auto;padding:20px;color:#1a1a1a;background:#f5f0e8;}`;
  html += `h1{border-bottom:2px solid #8b4513;padding-bottom:8px;}h2{color:#8b4513;margin-top:28px;}`;
  html += `h3{color:#5a3a1a;margin-top:18px;}table{border-collapse:collapse;width:100%;}td,th{border:1px solid #ccc;padding:6px;text-align:left;}`;
  html += `.stat{display:inline-block;margin:4px 12px 4px 0;padding:4px 10px;background:#e8dcc4;border-radius:4px;}</style></head><body>`;
  html += `<h1>${esc(title)}</h1>`;
  if (b.character) {
    const c = b.character;
    html += `<h2>Character: ${esc(c.name)}</h2>`;
    html += `<p><strong>${esc(c.species)} ${esc(c.klass)} · Level ${c.level} · ${esc(c.alignment)}</strong></p>`;
    html += `<div class="stat">HP: ${c.hp_current}/${c.hp_max}</div><div class="stat">AC: ${c.armor_class}</div>`;
    html += `<div class="stat">Passive Perception: ${c.passive_perception}</div><div class="stat">Prof: +${c.proficiency_bonus}</div>`;
    html += `<div class="stat">XP: ${c.xp}</div><div class="stat">Gold: ${c.gold}</div>`;
    const as = c.ability_scores || {};
    html += `<h3>Ability Scores</h3><table><tr><th>STR</th><th>DEX</th><th>CON</th><th>INT</th><th>WIS</th><th>CHA</th></tr>`;
    html += `<tr><td>${as.strength||10}</td><td>${as.dexterity||10}</td><td>${as.constitution||10}</td><td>${as.intelligence||10}</td><td>${as.wisdom||10}</td><td>${as.charisma||10}</td></tr></table>`;
    if (c.abilities?.length) {
      html += `<h3>Abilities & Traits</h3><ul>${c.abilities.map((a) => `<li>${esc(a)}</li>`).join('')}</ul>`;
    }
    if (c.inventory?.length) {
      html += `<h3>Inventory</h3><ul>${c.inventory.map((i) => `<li>${esc(i.name||i)}${i.quantity>1?` ×${i.quantity}`:''}</li>`).join('')}</ul>`;
    }
    if (c.notes?.length) {
      html += `<h3>Notes</h3><ul>${c.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul>`;
    }
  }
  if (b.campaign) {
    const c = b.campaign;
    html += `<h2>Campaign: ${esc(c.name)}</h2><p><strong>${esc(c.setting)} · ${esc(c.rules_edition)} · ${esc(c.tone)}</strong></p>`;
    if (c.summary) html += `<p>${esc(c.summary)}</p>`;
  }
  if (b.customSpells?.length) {
    html += `<h2>Custom Spells</h2>`;
    b.customSpells.forEach((s) => {
      html += `<h3>${esc(s.name)} (${s.level===0?'Cantrip':'Level '+s.level} ${esc(s.school)})</h3>`;
      html += `<p><em>${esc(s.casting_time)} · ${esc(s.range)} · ${esc(s.duration)}${s.concentration?' · Conc':''}${s.ritual?' · Ritual':''}</em></p>`;
      html += `<p>${esc(s.description)}</p>`;
    });
  }
  if (b.customItems?.length) {
    html += `<h2>Custom Items</h2>`;
    b.customItems.forEach((i) => {
      html += `<h3>${esc(i.name)} [${esc(i.rarity)}]</h3><p>${esc(i.description)}</p>`;
    });
  }
  if (b.loreNotes?.length) {
    html += `<h2>Lore & Notes</h2>`;
    b.loreNotes.forEach((l) => {
      html += `<h3>${esc(l.title)}</h3><p>${esc(l.body)}</p>`;
    });
  }
  html += `<hr><p style="font-size:11px;color:#888;">Exported ${new Date().toLocaleString()} · Merlin D&D</p>`;
  html += `</body></html>`;
  return html;
}