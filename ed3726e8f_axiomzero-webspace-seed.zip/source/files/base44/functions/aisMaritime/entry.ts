/**
 * aisMaritime — global vessel positions from AISHub (free-for-contributors
 * REST snapshot). Requires AIS_API_KEY secret (AISHub username/key).
 * Returns normalized vessels {mmsi, name, coords, speed, course, type,
 * nav_status} for the maritime domain layer. Surfaces 'key-required' when
 * the secret is absent.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    const key = secrets.get('AIS_API_KEY');
    if (!key) {
      return Response.json({ vessels: [], status: 'key-required', message: 'AIS_API_KEY secret required (AISHub username/key from data.aishub.net).' });
    }

    const url = `http://data.aishub.net/ws.php?username=${encodeURIComponent(key)}&format=1&compress=0`;
    const res = await fetch(url, { headers: { 'User-Agent': 'AxiomZero-GeoMonitor' } });
    if (!res.ok) return Response.json({ vessels: [], status: 'unavailable', message: `AISHub returned ${res.status}` });

    const data = await res.json();
    if (data && data.error) return Response.json({ vessels: [], status: 'unavailable', message: `AISHub: ${data.error}` });

    // AISHub format 1: array of arrays [MMSI, name, lat, lon, speed, course, heading, nav_status, type, ...]
    const rows = Array.isArray(data) ? data : (data.vessels || []);
    const vessels = [];
    for (const v of rows) {
      const lat = v[2] ?? v.latitude, lon = v[3] ?? v.longitude;
      if (lat == null || lon == null) continue;
      vessels.push({
        mmsi: String(v[0] ?? v.mmsi ?? ''),
        name: v[1] ?? v.name ?? '',
        latitude: Number(lat), longitude: Number(lon),
        speed: v[4] != null ? Number(v[4]) : (v.speed ?? null),
        course: v[5] != null ? Number(v[5]) : (v.course ?? null),
        heading: v[6] != null ? Number(v[6]) : (v.heading ?? null),
        navStatus: v[7] ?? v.nav_status ?? null,
        type: v[8] ?? v.type ?? null,
      });
    }
    return Response.json({ vessels, count: vessels.length, source: 'AISHub', timestamp: new Date().toISOString() });
  } catch (error) {
    return Response.json({ vessels: [], status: 'unavailable', message: (error as Error).message });
  }
}