import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

/**
 * psicatRadioDedup — auto-removes exact duplicate tracks from the library.
 *
 * Two tracks are considered exact duplicates if they share ALL of:
 *   - title (exact string match)
 *   - original_size_bytes (exact byte count)
 *   - duration_seconds (exact second count)
 *
 * Same-name files with different size or duration are preserved as distinct.
 * In each duplicate group, the oldest record (by created_date) is kept and the
 * rest are deleted.
 *
 * Returns: { duplicates_found, removed, kept, groups }
 */
export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const tracks = await base44.entities.PsiCatRadioTrack.list('-created_date', 500);

    // Group by (title + original_size_bytes + duration_seconds)
    const groups: Record<string, any[]> = {};
    for (const t of tracks) {
      const key = `${t.title}|${t.original_size_bytes || 0}|${t.duration_seconds || 0}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(t);
    }

    let duplicatesFound = 0;
    let removed = 0;
    const toDelete: string[] = [];
    const groupDetails: any[] = [];

    for (const key of Object.keys(groups)) {
      const group = groups[key];
      if (group.length > 1) {
        duplicatesFound += group.length - 1;
        // Sort by created_date ascending (oldest first)
        group.sort((a, b) => {
          const da = new Date(a.created_date || a.date_created || 0).getTime();
          const db = new Date(b.created_date || b.date_created || 0).getTime();
          return da - db;
        });
        const kept = group[0];
        const dups = group.slice(1);
        groupDetails.push({
          title: kept.title,
          size: kept.original_size_bytes,
          duration: kept.duration_seconds,
          kept_id: kept.id,
          removed_ids: dups.map((d) => d.id),
          count: group.length,
        });
        for (const dup of dups) {
          toDelete.push(dup.id);
        }
      }
    }

    // Delete duplicates
    for (const id of toDelete) {
      try {
        await base44.entities.PsiCatRadioTrack.delete(id);
        removed++;
      } catch (e) {
        /* skip deletion errors */
      }
    }

    return Response.json({
      duplicates_found: duplicatesFound,
      removed,
      kept: tracks.length - removed,
      groups: groupDetails,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}