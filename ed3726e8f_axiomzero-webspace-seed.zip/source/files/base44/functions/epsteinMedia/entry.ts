import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { makeSource, okResponse, readQuery } from '../../shared/sourceNormalizer.ts';

/**
 * epsteinMedia — The Epstein Files archive (epstein.media).
 *
 * The archive's person-profile pages are currently returning 403 to server-side
 * fetches (bot protection), so this function now degrades gracefully to a
 * deep-link fallback: it returns pre-filled browse/search links to the archive
 * the journalist opens in-browser, matching the honest dojEpstein pattern.
 *
 * If the profile fetch succeeds (403 lifts), it still parses the linked documents.
 *
 * Archive: https://www.epstein.media/
 *
 * Theory, methodology: ThomasCory Walker-Pearson / AxiomZero Technologies & Consulting, SPC.
 * Implementation: GitHub Copilot (AI).
 */

function slugify(name: string): string {
  return name.toLowerCase().trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

const FILE_LINK_RE = /<a[^>]+href="((?:https?:\/\/www\.epstein\.media)?\/files\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;

function deepLinkFallback(query: string, slug: string, reason: string) {
  return [
    makeSource({
      title: `Epstein Files Archive — Person: "${query}"`,
      tier: 2,
      source_type: 'Investigative archive — person profile (open in browser)',
      url_or_ref: `https://www.epstein.media/people/${slug}/`,
      date: '',
      excerpt: `Direct profile page for "${query}" on the House Oversight Epstein release. ${reason} Open in-browser to view the full document index and copy references here.`,
      raw_metadata: { slug, attempted_slug: slug, fallback: true },
    }),
    makeSource({
      title: `Epstein Files Archive — Browse Key Figures`,
      tier: 2,
      source_type: 'Investigative archive — person index (browse in browser)',
      url_or_ref: 'https://www.epstein.media/#key-figures-in-the-files',
      date: '',
      excerpt: `Browse the 1,500+ person index to find "${query}" and copy their profile + documents here.`,
      raw_metadata: { fallback: true },
    }),
    makeSource({
      title: `Epstein Files Archive — Home`,
      tier: 2,
      source_type: 'Investigative archive — full document repository',
      url_or_ref: 'https://www.epstein.media/',
      date: '',
      excerpt: `Full House Oversight Committee Epstein document repository — search and browse all released files.`,
      raw_metadata: { fallback: true },
    }),
  ];
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return okResponse([], query, 'Epstein Files Archive');

    const slug = slugify(query);
    const profileUrl = `https://www.epstein.media/people/${slug}/`;
    let res: Response;
    try {
      res = await fetch(profileUrl, { headers: { Accept: 'text/html', 'User-Agent': 'AxiomZero-AXIOM-Journalist/1.0' } });
    } catch (e) {
      return okResponse(deepLinkFallback(query, slug, 'Server-side fetch blocked.'), query, 'Epstein Files Archive');
    }

    // 403/404/5xx — degrade to deep-link fallback
    if (!res.ok) {
      return okResponse(deepLinkFallback(query, slug, `Profile fetch returned ${res.status}.`), query, 'Epstein Files Archive');
    }

    const html = await res.text();
    const sources: any[] = [
      makeSource({
        title: `Epstein Files — Person Profile: ${query}`,
        tier: 2,
        source_type: 'Investigative archive — person profile (House Oversight documents)',
        url_or_ref: profileUrl,
        date: '',
        excerpt: `Full profile and document index for ${query} from the House Oversight Committee Epstein release.`,
        raw_metadata: { slug, profile_url: profileUrl },
      }),
    ];

    const seen = new Set<string>();
    let m: RegExpExecArray | null;
    while ((m = FILE_LINK_RE.exec(html)) !== null) {
      let url = m[1];
      if (url.startsWith('/')) url = `https://www.epstein.media${url}`;
      if (seen.has(url)) continue;
      seen.add(url);
      const text = m[2].replace(/<[^>]*>/g, '').trim();
      if (!text || text.length < 5) continue;
      sources.push(makeSource({
        title: `Epstein Files: ${text}`,
        tier: 2,
        source_type: 'Investigative archive — document (House Oversight Committee release)',
        url_or_ref: url,
        date: '',
        excerpt: `Document from ${query}'s file — ${text}.`,
        raw_metadata: { doc_url: url, person: query },
      }));
      if (sources.length >= 13) break;
    }
    return okResponse(sources, query, 'Epstein Files Archive');
  } catch (error) {
    return okResponse([], '', 'Epstein Files Archive');
  }
}