import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const body = await req.json().catch(() => ({}));
    const campaignId = body.campaign_id;
    if (!campaignId) return Response.json({ error: 'campaign_id required' }, { status: 400 });

    const [rolls, encounters, characters, campaign] = await Promise.all([
      base44.entities.DnDRoll.filter({ campaign_id: campaignId }, '-created_date', 60),
      base44.entities.DnDEncounter.filter({ campaign_id: campaignId }, '-created_date', 10),
      base44.entities.DnDCharacter.filter({ campaign_id: campaignId }, '-created_date', 20),
      base44.entities.DnDCampaign.get(campaignId).catch(() => null),
    ]);

    const rollLines = (rolls || []).slice(0, 40).map((r) =>
      `${r.roller_name || 'Someone'}: ${r.expression} = ${r.total}${r.is_crit ? ' (CRIT)' : ''}${r.is_fumble ? ' (FUMBLE)' : ''}${r.label ? ` [${r.label}]` : ''}`
    );
    const encLines = (encounters || []).map((e) => `${e.title} (${e.difficulty}, ${e.adjusted_xp}xp, ${e.status})`);
    const partyLines = (characters || []).map((c) => `${c.name} Lv${c.level} ${c.klass} — HP ${c.hp_current}/${c.hp_max}, AC ${c.armor_class}`);

    const context = [
      `CAMPAIGN: ${campaign?.name || 'Unknown'} — ${campaign?.setting || ''} (${campaign?.rules_edition || '5e-2024'}), tone: ${campaign?.tone || 'heroic'}`,
      `PARTY:\n${partyLines.join('\n') || 'No characters'}`,
      `RECENT ENCOUNTERS:\n${encLines.join('\n') || 'None'}`,
      `RECENT ROLLS:\n${rollLines.join('\n') || 'None'}`,
    ].join('\n\n');

    const prompt = `You are Merlin, the D&D 5e/5.5e campaign expert for the "Merlin DM Guide & Player Assistant". Using ONLY the session data below, write a vivid session recap (3-4 short paragraphs of in-world prose, citing notable dice rolls by roller and result), then a next-session prep brief with open threads, faction/NPC moves to consider, and 2-3 recommended encounter ideas (each with a target difficulty). Do not invent mechanics, stats, or events outside the provided data. Be concise and table-ready.\n\nSESSION DATA:\n${context}`;

    const res = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          recap: { type: 'string' },
          prep_brief: { type: 'string' },
          open_threads: { type: 'array', items: { type: 'string' } },
        },
        required: ['recap', 'prep_brief'],
      },
    });

    return Response.json({
      recap: res.recap,
      prep_brief: res.prep_brief,
      open_threads: res.open_threads || [],
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}