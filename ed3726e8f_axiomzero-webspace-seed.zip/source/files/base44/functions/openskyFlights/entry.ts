import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';
import { fetchWithResilience } from '../../shared/resilientFetch.ts';

/**
 * openskyFlights — OpenSky Network live/historical flight states.
 *
 * OAuth2 client-credentials (OPENSKY_CLIENT_ID / OPENSKY_CLIENT_SECRET).
 * Wrapped with resilient fetch so transient 522 (Cloudflare/origin down) and
 * 5xx errors retry with backoff before degrading gracefully.
 */

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const { mode = 'live', icao24, bbox, time } = body;

    const clientId = secrets.get('OPENSKY_CLIENT_ID');
    const clientSecret = secrets.get('OPENSKY_CLIENT_SECRET');

    if (!clientId || !clientSecret) {
      return Response.json({
        states: [], count: 0, source: 'OpenSky Network', status: 'missing-credentials',
        message: 'OpenSky credentials not configured. Set OPENSKY_CLIENT_ID and OPENSKY_CLIENT_SECRET in app secrets.',
      }, { status: 200 });
    }

    // OAuth2 token with retry (522 = Cloudflare/origin down)
    const tokenRes = await fetchWithResilience('https://opensky-network.org/api/auth/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ grant_type: 'client_credentials', client_id: clientId, client_secret: clientSecret }).toString(),
      retries: 2, timeoutMs: 12000, cacheTtl: 300000,
    });
    if (!tokenRes.data || !tokenRes.data.access_token) {
      return Response.json({
        states: [], count: 0, source: 'OpenSky Network', status: 'unavailable',
        message: `OpenSky auth failed: ${tokenRes.error || 'no token'}`,
      }, { status: 200 });
    }
    const accessToken = tokenRes.data.access_token;

    let apiUrl = 'https://opensky-network.org/api/states/all';
    const params = new URLSearchParams();
    if (mode === 'track' && icao24) {
      apiUrl = `https://opensky-network.org/api/track?icao24=${encodeURIComponent(icao24)}`;
      if (time) apiUrl += `&time=${time}`;
    } else {
      if (bbox) {
        const { lamin, lomin, lamax, lomax } = bbox;
        if (lamin != null) params.set('lamin', String(lamin));
        if (lomin != null) params.set('lomin', String(lomin));
        if (lamax != null) params.set('lamax', String(lamax));
        if (lomax != null) params.set('lomax', String(lomax));
      }
      if (icao24) params.set('icao24', icao24);
      if (time) params.set('time', String(time));
      const qs = params.toString();
      if (qs) apiUrl += `?${qs}`;
    }

    const dataRes = await fetchWithResilience(apiUrl, {
      headers: { Authorization: `Bearer ${accessToken}` },
      retries: 2, timeoutMs: 15000, cacheTtl: 60000,
    });
    if (!dataRes.data) {
      return Response.json({
        states: [], count: 0, source: 'OpenSky Network', status: 'unavailable',
        message: `OpenSky API: ${dataRes.error || 'no data'}`,
      }, { status: 200 });
    }
    const data = dataRes.data;

    // Density mode — aggregate global states into 5° grid cells
    if (mode === 'density') {
      const cells: Record<string, { lat: number; lon: number; count: number }> = {};
      const allStates = (data.states || []).map((s: any[]) => ({ lat: s[6], lon: s[5] }))
        .filter((s) => s.lat != null && s.lon != null);
      for (const s of allStates) {
        const lat = Math.floor(s.lat / 5) * 5 + 2.5;
        const lon = Math.floor(s.lon / 5) * 5 + 2.5;
        const k = `${lat},${lon}`;
        if (!cells[k]) cells[k] = { lat, lon, count: 0 };
        cells[k].count++;
      }
      return Response.json({ cells: Object.values(cells), count: allStates.length, source: 'OpenSky Network (density)', timestamp: new Date().toISOString() });
    }

    // Track mode
    if (mode === 'track') {
      const path = (data.path || []).map((p: any) => ({ time: p[0], latitude: p[1], longitude: p[2], altitude: p[3], onGround: p[4] }));
      return Response.json({ track: path, icao24, startTime: data.startTime, endTime: data.endTime, source: 'OpenSky Network (historical track)', timestamp: new Date().toISOString() });
    }

    // State vectors
    const states = (data.states || []).map((s: any[]) => ({
      icao24: s[0], callsign: s[1]?.trim() || null, originCountry: s[2], timePosition: s[3], lastContact: s[4],
      longitude: s[5], latitude: s[6], baroAltitude: s[7], onGround: s[8], velocity: s[9], trueTrack: s[10],
      verticalRate: s[11], geoAltitude: s[13], squawk: s[14], positionSource: s[16],
    })).filter((s: any) => s.latitude != null && s.longitude != null);

    return Response.json({ states, count: states.length, source: 'OpenSky Network', timestamp: new Date().toISOString() });
  } catch (error) {
    return Response.json({ states: [], count: 0, source: 'OpenSky Network', status: 'unavailable', message: (error as Error).message }, { status: 200 });
  }
}