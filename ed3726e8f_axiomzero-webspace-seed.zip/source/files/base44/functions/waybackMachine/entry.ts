import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { makeSource, okResponse, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'Wayback Machine', 'No URL provided');
    // Normalize to a URL if the user passed a bare domain
    const target = query.startsWith('http') ? query : `http://${query}`;
    const url = `https://web.archive.org/cdx/search/cdx?url=${target}&output=json&limit=10`;
    const res = await fetch(url, { headers: { 'User-Agent': 'AxiomZero/1.0' } });
    if (!res.ok) return errResponse(query, 'Wayback Machine', `API ${res.status}`);
    const rows = await res.json();
    // CDX returns an array of arrays; first row is the header
    const header = rows[0] || ['urlkey', 'timestamp', 'original', 'mimetype', 'statuscode', 'digest', 'length'];
    const dataRows = rows.slice(1);
    const sources = dataRows.map((row: any[]) => {
      const obj = Object.fromEntries(header.map((h: string, i: number) => [h, row[i]]));
      const ts = obj.timestamp || '';
      const dateStr = ts ? `${ts.slice(0, 4)}-${ts.slice(4, 6)}-${ts.slice(6, 8)}` : '';
      return makeSource({
        title: `Wayback snapshot: ${obj.original || target}`,
        tier: 2, source_type: 'Archived web page (version history)',
        url_or_ref: ts ? `https://web.archive.org/web/${ts}/${obj.original || target}` : '',
        date: dateStr,
        excerpt: `Captured ${dateStr} · Status ${obj.statuscode || 'N/A'} · MIME ${obj.mimetype || 'N/A'}`,
        raw_metadata: obj,
      });
    });
    return okResponse(sources, query, 'Wayback Machine');
  } catch (error) {
    return errResponse('', 'Wayback Machine', (error as Error).message);
  }
}