import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { makeSource, okResponse, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';

/**
 * icijOffshoreSearch — pre-filled deep links into the ICIJ Offshore Leaks Database
 * web search (the same database embedded at panamapapers.investigativecenters.org/panama-db/).
 *
 * The web search at offshoreleaks.icij.org/search is protected by an AWS WAF JavaScript
 * challenge, so server-side scraping is blocked (same constraint as the DOJ Epstein
 * portal). This fetcher returns pre-filled search deep links — one per leak dataset —
 * that the journalist opens in-browser to run the search and copy results.
 *
 * For programmatic name matching, use the `icijOffshore` fetcher (reconcile API) which
 * returns structured records without the WAF gate.
 *
 * Theory, methodology: ThomasCory Walker-Pearson / AxiomZero Technologies & Consulting, SPC.
 * Implementation: GitHub Copilot (AI).
 */

const DATASETS = [
  { code: '', label: 'All Offshore Leaks', desc: '810k+ offshore entities across all investigations' },
  { code: 'pp', label: 'Panama Papers', desc: 'Mossack Fonseca leak — shell companies and beneficial owners' },
  { code: 'pa', label: 'Pandora Papers', desc: '2.94M files from 14 service providers — the largest leak' },
  { code: 'ap', label: 'Paradise Papers — Appleby', desc: 'Appleby offshore law firm leak' },
  { code: 'bl', label: 'Bahamas Leaks', desc: 'Bahamas corporate registry leak' },
  { code: 'ol', label: 'Offshore Leaks', desc: 'Original 2013 ICIJ offshore investigation' },
];

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'ICIJ Offshore Leaks (search)', 'No query provided');

    const q = encodeURIComponent(query);
    const sources = DATASETS.map((ds) => {
      const dParam = ds.code ? `&d=${ds.code}` : '';
      const url = `https://offshoreleaks.icij.org/search?q=${q}${dParam}&e=true`;
      return makeSource({
        title: `ICIJ Offshore Leaks — ${ds.label}: "${query}"`,
        tier: 2,
        source_type: `Offshore leak database — pre-filled web search (${ds.label})`,
        url_or_ref: url,
        date: '',
        excerpt: `Pre-filled search of the ICIJ Offshore Leaks Database (${ds.desc}). Opens the WAF-verified portal — run the search in-browser and copy results here. ${ds.code ? `Filtered to ${ds.label}.` : 'Searches all datasets.'}`,
        raw_metadata: { portal: 'offshoreleaks.icij.org', query, dataset: ds.code || 'all', search_url: url },
      });
    });

    // Also include the power-players deep link for person queries.
    sources.push(makeSource({
      title: `ICIJ Power Players — ${query}`,
      tier: 2,
      source_type: 'Offshore leak database — power players profile index',
      url_or_ref: 'https://offshoreleaks.icij.org/power-players',
      date: '',
      excerpt: 'Browse curated offshore-connection profiles of world leaders, politicians, and their associates. Open to find the person and copy their profile link.',
      raw_metadata: { portal: 'offshoreleaks.icij.org/power-players', query },
    }));

    return okResponse(sources, query, 'ICIJ Offshore Leaks (search)');
  } catch (error) {
    return errResponse('', 'ICIJ Offshore Leaks (search)', (error as Error).message);
  }
}