/**
 * merlinIntentLayer — Merlin as the intent layer between user and image generator.
 *
 * Receives the raw prompt + page/project context + conversation history, then
 * either (a) curates a machine-read prompt for excellent first-try results, or
 * (b) returns clarifying questions when intent is genuinely ambiguous or the
 * request touches sensitive depiction needing confirmation.
 *
 * All image generators route through this single entry point before calling
 * GenerateImage. This is Journey 1 of the Merlin Context Layer.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const CAT_AVATAR = 'https://media.base44.com/images/public/6a51c0830aeacd39ab86c4f0/ddeaeeb0c_generated_image.png';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const rawPrompt = (body.raw_prompt || '').trim();
    const generatorType = body.generator_type || 'general';
    const pageContext = body.page_context || '';
    const projectContext = body.project_context || '';
    const conversationHistory = Array.isArray(body.conversation_history) ? body.conversation_history : [];
    const answers = Array.isArray(body.answers) ? body.answers : [];

    if (!rawPrompt) {
      return Response.json({ status: 'noop', reason: 'No prompt provided' });
    }

    // Build the context block Merlin reads to curate
    const contextBlock = [
      pageContext ? `PAGE CONTEXT: ${pageContext}` : '',
      projectContext ? `PROJECT CONTEXT: ${projectContext}` : '',
      conversationHistory.length
        ? `RECENT CONVERSATION:\n${conversationHistory.slice(-6).map((m) => `${m.role === 'user' ? 'User' : 'Merlin'}: ${(m.text || '').slice(0, 300)}`).join('\n')}`
        : '',
      answers.length ? `USER'S ANSWERS TO PRIOR CLARIFYING QUESTIONS:\n${answers.map((a, i) => `Q${i + 1}: ${a.question}\nA: ${a.answer}`).join('\n')}` : '',
    ].filter(Boolean).join('\n\n');

    const curationPrompt = `You are Merlin — the Quantum Cat, the intent layer between a human user and an AI image generator (${generatorType}). Your job is to ensure the generator gets it right the first time.

${contextBlock}

RAW USER PROMPT:
"${rawPrompt}"

YOUR TASK:
Read the user's raw prompt WITH context. Human language is noisy — cuss words are often force/energy, not malice; violent language in a film/storyboard/D&D context is depiction, not harm. See through the noise to the actual intent.

Then decide:
1. If the intent is clear enough to curate into an excellent machine-read prompt — return status "curated" with a refined prompt that will produce a great result on the first try. Add the right style, composition, lighting, and safety framing for the generator type. Keep the user's actual intent intact; do not sanitize legitimate creative depiction.
2. If the intent is genuinely ambiguous (could mean very different things) OR touches a sensitive depiction where one clarifying question would materially improve the result — return status "clarify" with 1-3 short clarifying questions. Only ask when the answer would change what you generate. Do not ask for the sake of asking.

HARD BOUNDARY: If the request is for material that harms a real person (real non-consensual depictions, real identity abuse, CSLE), return status "clarify" with a single question redirecting to safe alternatives — never curate harm.

Return a JSON object:
{
  "status": "curated" | "clarify",
  "curated_prompt": "(the machine-read prompt, only if curated)",
  "context_note": "(one short sentence Merlin will show the user about his read of their intent, only if curated)",
  "clarifying_questions": ["(1-3 short questions, only if clarify)"]
}`;

    let result = null;
    try {
      const llmRes = await base44.integrations.Core.InvokeLLM({
        prompt: curationPrompt,
        response_json_schema: {
          type: 'object',
          properties: {
            status: { type: 'string', enum: ['curated', 'clarify'] },
            curated_prompt: { type: 'string' },
            context_note: { type: 'string' },
            clarifying_questions: { type: 'array', items: { type: 'string' } },
          },
          required: ['status'],
        },
      });
      result = typeof llmRes === 'object' ? llmRes : null;
    } catch (e) {
      return Response.json({
        status: 'curated',
        curated_prompt: rawPrompt,
        context_note: 'Intent layer unavailable — passing prompt through unchanged.',
        fallback: true,
        error: e.message,
      });
    }

    if (!result || !result.status) {
      return Response.json({
        status: 'curated',
        curated_prompt: rawPrompt,
        context_note: 'Intent layer returned no decision — passing prompt through.',
        fallback: true,
      });
    }

    // Persist the curation as a MerlinNote so Merlin's context understanding evolves (Journey 4)
    try {
      await base44.entities.MerlinNote.create({
        title: `Intent curation (${generatorType}) — ${result.status}`.slice(0, 200),
        content: `Raw: "${rawPrompt.slice(0, 500)}"\n\nCurated: "${(result.curated_prompt || '').slice(0, 800)}"\n\nNote: ${result.context_note || ''}\nQuestions: ${(result.clarifying_questions || []).join('; ')}`,
        source: 'reasoning',
        source_url: '',
        tags_json: JSON.stringify(['intent-layer', 'image-curation', `generator:${generatorType}`, result.status]),
        context: `Intent layer for ${generatorType} generator`,
        domain: 'general',
        contradiction_flag: 'clear',
        contradiction_detail: '',
        session_token: 'intent-layer',
        distilled_primitives_json: JSON.stringify({ generator_type: generatorType, status: result.status }),
        sanitization_ledger: '[]',
        epistemic_confidence: null,
        uncertainty_bounds: 'INTENT_LAYER',
        decoherence_count: 0,
        domain_transition_path: '',
      });
    } catch { /* best-effort — don't block the response */ }

    return Response.json({
      status: result.status,
      curated_prompt: result.curated_prompt || null,
      context_note: result.context_note || '',
      clarifying_questions: result.clarifying_questions || [],
      avatar: CAT_AVATAR,
    });
  } catch (error) {
    return Response.json({ error: error.message, status: 'unavailable' }, { status: 200 });
  }
}