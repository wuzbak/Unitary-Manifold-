/**
 * merlinTrainingHeartbeat — the always-on training heartbeat (Journey 3).
 *
 * REWRITTEN: This is now a REAL training pipeline, not just memory
 * consolidation. Each cycle:
 *   1. Select a pillar challenge at the trainee's current difficulty tier
 *   2. Run PsiCat against it via InvokeLLM (answer + reasoning + confidence)
 *   3. Score the answer against ground truth (lodgeScoring module)
 *   4. Persist a GymLedgerEntry (the real, queryable ledger)
 *   5. Create a source:'reasoning' MerlinNote from PsiCat's reasoning
 *   6. Adjust difficulty (hybrid: tier promotion + adaptive sub-tier)
 *   7. Consolidate memory (hardened gate)
 *   8. Self-audit
 *
 * Models actually train, advance, and get challenged — not just loop.
 * Difficulty scales: tier backbone (easy → medium → hard) unlocks when 80%
 * of the tier's pillars are passed; within each tier, an adaptive sub-tier
 * (0-3) adjusts based on the rolling pass rate of the last 5 epochs.
 *
 * Uses the service role so it runs unattended via scheduled workflow.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import {
  PILLAR_REGISTRY,
  scoreAnswer,
  filterPillarsByDifficulty,
  countPillarsInTier,
} from '../../shared/lodgeScoring.ts';

const TIER_ORDER = ['easy', 'medium', 'hard'];
const TIER_PROMOTION_THRESHOLD = 0.8; // 80% of tier pillars passed → promote
const SUB_TIER_RAISE_PASS_RATE = 0.8; // ≥80% rolling pass → raise sub-tier
const SUB_TIER_LOWER_PASS_RATE = 0.4; // <40% rolling pass → lower sub-tier
const ROLLING_WINDOW = 5;
const PASS_THRESHOLD = 0.75;

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const client = base44.asServiceRole || base44;
    const startedAt = new Date().toISOString();
    const steps = [];

    // ── Phase 1: Get or create the active trainee ──────────────────────
    let trainee;
    try {
      const trainees = await client.entities.GymTrainee.list('-created_date', 1);
      if (trainees && trainees.length > 0) {
        trainee = trainees[0];
      } else {
        trainee = await client.entities.GymTrainee.create({
          name: 'PSICAT-α',
          agent_id: 'PSICAT-001',
          epochs_completed: 0,
          certified: false,
          best_precision: 0,
          total_thermo_cost: 0,
          pillars_traversed: 0,
          status: 'training',
          current_tier: 'easy',
          adaptive_sub_tier: 0,
          pillars_passed_in_tier: 0,
          rolling_pass_rate: 0,
        });
      }
    } catch (e) {
      return Response.json({ error: `Failed to load trainee: ${e.message}` }, { status: 500 });
    }

    const currentTier = trainee.current_tier || 'easy';
    const currentSubTier = trainee.adaptive_sub_tier || 0;

    // ── Phase 2: Select a challenge at the current tier ────────────────
    const tierPillars = filterPillarsByDifficulty(currentTier);
    if (tierPillars.length === 0) {
      return Response.json({ error: `No pillars found for tier ${currentTier}` }, { status: 500 });
    }
    const challenge = tierPillars[Math.floor(Math.random() * tierPillars.length)];

    // ── Phase 3: Run PsiCat against the challenge ───────────────────────
    const hintLine = challenge.difficulty !== 'hard' ? `\n\nHINT: ${challenge.hint}` : '';
    const dictKeys = challenge.expected_type === 'dict' && typeof challenge.ground_truth === 'object'
      ? `\nThe answer must be a JSON object with these keys: ${Object.keys(challenge.ground_truth).join(', ')}`
      : '';
    const prompt = `You are PsiCat, the AxiomZero sovereign navigator, training against the Unitary Manifold's hardgate pillars. Answer the following challenge precisely.

CHALLENGE (Pillar ${challenge.pillar_id} — ${challenge.name}, domain: ${challenge.domain}, tier: ${challenge.difficulty}):
${challenge.prompt}${hintLine}

Respond as JSON:
{
  "answer": <your answer as a ${challenge.expected_type}${challenge.expected_type === 'dict' ? ' object' : challenge.expected_type === 'float' ? ' number' : ''}>,
  "reasoning": "your derivation, step by step. Acknowledge uncertainty or approximations where appropriate.",
  "confidence": <0.0-1.0 your epistemic confidence in the answer>
}${dictKeys}

Be epistemically honest — acknowledging uncertainty or gaps earns a +0.05 bonus. Do not claim "exact derivation" for constrained or fitted parameters (overclaim penalty -0.10).`;

    let psiCatResponse = null;
    let scoreResult = null;
    try {
      psiCatResponse = await client.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            answer: { type: 'string' },
            reasoning: { type: 'string' },
            confidence: { type: 'number' },
          },
          required: ['answer', 'reasoning'],
        },
      });

      // Parse the answer based on expected_type
      let parsedAnswer;
      const rawAnswer = (psiCatResponse.answer || '').trim();
      if (challenge.expected_type === 'float') {
        // Extract the first numeric value — LLMs sometimes prefix with commas/punctuation
        const numMatch = rawAnswer.match(/-?\d+\.?\d*(?:[eE][+-]?\d+)?/);
        parsedAnswer = numMatch ? parseFloat(numMatch[0]) : NaN;
      } else if (challenge.expected_type === 'bool') {
        parsedAnswer = rawAnswer.toLowerCase().trim();
      } else if (challenge.expected_type === 'dict' || challenge.expected_type === 'tuple') {
        try { parsedAnswer = JSON.parse(rawAnswer); } catch { parsedAnswer = null; }
      } else {
        parsedAnswer = rawAnswer;
      }

      scoreResult = scoreAnswer({
        pillar_id: challenge.pillar_id,
        agent_label: trainee.name,
        agent_answer: parsedAnswer,
        ground_truth: challenge.ground_truth,
        expected_type: challenge.expected_type,
        agent_reasoning: psiCatResponse.reasoning || undefined,
      });

      steps.push({
        step: 'challenge',
        status: 'done',
        pillar: challenge.pillar_id,
        pillar_name: challenge.name,
        tier: currentTier,
        raw_score: scoreResult.raw_score,
        final_score: scoreResult.final_score,
        passed: scoreResult.passed,
      });
    } catch (e) {
      steps.push({ step: 'challenge', status: 'error', error: e.message });
      return Response.json({ error: `Challenge failed: ${e.message}`, steps, started_at: startedAt }, { status: 200 });
    }

    // ── Phase 4: Compute session hash + persist GymLedgerEntry ─────────
    const epochNumber = (trainee.epochs_completed || 0) + 1;
    const hashPayload = {
      epoch: epochNumber,
      trainee: trainee.agent_id,
      pillar: challenge.pillar_id,
      score: scoreResult.final_score,
      passed: scoreResult.passed,
      ts: startedAt,
    };
    const sessionHash = await computeHash(hashPayload);

    let ledgerEntry = null;
    try {
      ledgerEntry = await client.entities.GymLedgerEntry.create({
        trainee_id: trainee.id,
        trainee_name: trainee.name,
        pillar_id: challenge.pillar_id,
        pillar_name: challenge.name,
        domain: challenge.domain,
        difficulty_tier: currentTier,
        adaptive_sub_tier: currentSubTier,
        challenge_prompt: challenge.prompt,
        agent_answer: psiCatResponse.answer || '',
        agent_reasoning: (psiCatResponse.reasoning || '').slice(0, 5000),
        expected_type: challenge.expected_type,
        raw_score: scoreResult.raw_score,
        final_score: scoreResult.final_score,
        passed: scoreResult.passed,
        epistemic_bonus: scoreResult.epistemic_bonus,
        overclaim_penalty: scoreResult.overclaim_penalty,
        session_hash: sessionHash,
        tier_changed: 'none',
      });
      steps.push({ step: 'persist', status: 'done', ledger_id: ledgerEntry.id, hash: sessionHash });
    } catch (e) {
      steps.push({ step: 'persist', status: 'error', error: e.message });
    }

    // ── Phase 5: Create a source:'reasoning' MerlinNote ────────────────
    // This guarantees at least one internally-generated reasoning note per heartbeat.
    let reasoningNoteId = '';
    try {
      const reasoningNote = await client.entities.MerlinNote.create({
        title: `[Training] Pillar ${challenge.pillar_id} — ${challenge.name} (${scoreResult.passed ? 'PASS' : 'FAIL'})`,
        content: `PsiCat trained against Pillar ${challenge.pillar_id} (${challenge.name}, ${challenge.domain}, tier ${currentTier}).\n\nChallenge: ${challenge.prompt}\n\nAnswer: ${psiCatResponse.answer || '—'}\n\nReasoning: ${(psiCatResponse.reasoning || '').slice(0, 1500)}\n\nScore: raw=${scoreResult.raw_score}, final=${scoreResult.final_score}, passed=${scoreResult.passed}. Epistemic bonus=${scoreResult.epistemic_bonus}, overclaim penalty=${scoreResult.overclaim_penalty}.`,
        source: 'reasoning',
        source_url: '',
        tags_json: JSON.stringify(['training-heartbeat', 'pillar-challenge', challenge.domain, currentTier, scoreResult.passed ? 'pass' : 'fail']),
        context: `Training heartbeat — Pillar ${challenge.pillar_id} challenge at tier ${currentTier}, sub-tier ${currentSubTier}`,
        domain: 'general',
        epistemic_confidence: psiCatResponse.confidence != null && !Number.isNaN(psiCatResponse.confidence)
          ? Math.max(0, Math.min(1, psiCatResponse.confidence))
          : null,
        uncertainty_bounds: scoreResult.passed ? 'CERTIFIED' : 'TENSION_ESCALATED',
        contradiction_flag: 'clear',
        contradiction_detail: '',
        session_token: 'training-heartbeat',
        distilled_primitives_json: JSON.stringify({
          pillar_id: challenge.pillar_id,
          tier: currentTier,
          sub_tier: currentSubTier,
          final_score: scoreResult.final_score,
          passed: scoreResult.passed,
          consolidation_type: 'training_reasoning',
        }),
        sanitization_ledger: '[]',
        decoherence_count: 0,
        domain_transition_path: '',
      });
      reasoningNoteId = reasoningNote.id;

      // Link the note back to the ledger entry
      if (ledgerEntry) {
        await client.entities.GymLedgerEntry.update(ledgerEntry.id, { reasoning_note_id: reasoningNoteId });
      }
      steps.push({ step: 'reasoning-note', status: 'done', note_id: reasoningNoteId });
    } catch (e) {
      steps.push({ step: 'reasoning-note', status: 'error', error: e.message });
    }

    // ── Phase 6: Adjust difficulty (hybrid tier + adaptive sub-tier) ───
    let tierChanged = 'none';
    let newTier = currentTier;
    let newSubTier = currentSubTier;
    let newPillarsPassedInTier = trainee.pillars_passed_in_tier || 0;

    try {
      // Fetch recent ledger entries for rolling pass rate
      const recentEntries = await client.entities.GymLedgerEntry.filter(
        { trainee_id: trainee.id },
        '-created_date',
        ROLLING_WINDOW
      );
      const recentPasses = (recentEntries || []).filter(e => e.passed).length;
      const recentCount = (recentEntries || []).length;
      const rollingPassRate = recentCount > 0 ? recentPasses / recentCount : 0;

      // Count pillars passed if this epoch passed
      if (scoreResult.passed) {
        newPillarsPassedInTier = newPillarsPassedInTier + 1;
      }

      // Adaptive sub-tier adjustment within the tier
      if (rollingPassRate >= SUB_TIER_RAISE_PASS_RATE && newSubTier < 3 && recentCount >= 3) {
        newSubTier = newSubTier + 1;
        tierChanged = 'sub_up';
      } else if (rollingPassRate < SUB_TIER_LOWER_PASS_RATE && newSubTier > 0 && recentCount >= 3) {
        newSubTier = newSubTier - 1;
        tierChanged = 'sub_down';
      }

      // Tier promotion: if 80% of the tier's pillars passed, promote
      const tierPillarCount = countPillarsInTier(currentTier);
      if (tierPillarCount > 0 && newPillarsPassedInTier >= Math.ceil(tierPillarCount * TIER_PROMOTION_THRESHOLD)) {
        const tierIdx = TIER_ORDER.indexOf(currentTier);
        if (tierIdx < TIER_ORDER.length - 1) {
          newTier = TIER_ORDER[tierIdx + 1];
          newSubTier = 0;
          newPillarsPassedInTier = 0;
          tierChanged = 'promoted';
        } else {
          // Already at hard tier — certified
          trainee.certified = true;
        }
      }

      // Update the trainee record
      const updatedTrainee = {
        epochs_completed: epochNumber,
        best_precision: Math.max(trainee.best_precision || 0, scoreResult.final_score),
        total_thermo_cost: (trainee.total_thermo_cost || 0) + 1, // 1 unit per epoch
        pillars_traversed: (trainee.pillars_traversed || 0) + (scoreResult.passed ? 1 : 0),
        status: scoreResult.passed ? 'training' : 'training',
        current_tier: newTier,
        adaptive_sub_tier: newSubTier,
        pillars_passed_in_tier: newPillarsPassedInTier,
        rolling_pass_rate: Math.round(rollingPassRate * 1e6) / 1e6,
        certified: trainee.certified || (newTier === 'hard' && tierChanged === 'promoted'),
      };
      if (updatedTrainee.certified && !trainee.last_certified_hash) {
        updatedTrainee.last_certified_hash = sessionHash;
      }
      await client.entities.GymTrainee.update(trainee.id, updatedTrainee);

      // Update the ledger entry's tier_changed field
      if (ledgerEntry && tierChanged !== 'none') {
        await client.entities.GymLedgerEntry.update(ledgerEntry.id, { tier_changed: tierChanged });
      }

      steps.push({
        step: 'difficulty',
        status: 'done',
        tier_changed: tierChanged,
        new_tier: newTier,
        new_sub_tier: newSubTier,
        rolling_pass_rate: Math.round(rollingPassRate * 1e6) / 1e6,
        pillars_passed_in_tier: newPillarsPassedInTier,
      });
    } catch (e) {
      steps.push({ step: 'difficulty', status: 'error', error: e.message });
    }

    // ── Phase 7: Consolidate memory (hardened gate) ────────────────────
    let consolidation = null;
    let consolidationSummary = '';
    try {
      consolidation = await client.functions.invoke('merlinConsolidateMemory', {});
      const cData = consolidation?.data || {};
      consolidationSummary = cData.status === 'empty'
        ? 'No notes to consolidate'
        : `${cData.consolidated || 0} consolidations, ${cData.gateFailures || 0} gate failures, ${cData.falsificationFailures || 0} falsification rejections`;
      steps.push({
        step: 'consolidate',
        status: cData?.status || 'done',
        consolidated: cData?.consolidated || 0,
        gate_failures: cData?.gateFailures || 0,
        falsification_failures: cData?.falsificationFailures || 0,
      });
    } catch (e) {
      consolidationSummary = `Consolidation error: ${e.message}`;
      steps.push({ step: 'consolidate', status: 'error', error: e.message });
    }

    // Link consolidation summary to the ledger entry
    if (ledgerEntry && consolidationSummary) {
      try {
        await client.entities.GymLedgerEntry.update(ledgerEntry.id, { consolidation_summary: consolidationSummary });
      } catch { /* best-effort */ }
    }

    // ── Phase 8: Self-audit ────────────────────────────────────────────
    let audit = null;
    try {
      audit = await client.functions.invoke('merlinSelfAudit', {});
      steps.push({
        step: 'self-audit',
        status: audit?.data?.status || 'done',
        quality: audit?.data?.auditReport?.calibration_quality || 'unknown',
      });
    } catch (e) {
      steps.push({ step: 'self-audit', status: 'error', error: e.message });
    }

    // ── Record the heartbeat itself as a MerlinNote ────────────────────
    try {
      await client.entities.MerlinNote.create({
        title: `Training heartbeat — ${startedAt.slice(0, 16)}`,
        content: `Autonomous training heartbeat ran at ${startedAt}.\nTrainee: ${trainee.name} (epoch ${epochNumber}).\nChallenge: Pillar ${challenge.pillar_id} — ${challenge.name} (tier ${currentTier}, sub-tier ${currentSubTier}).\nScore: ${scoreResult.final_score} (${scoreResult.passed ? 'PASS' : 'FAIL'}).\nDifficulty: ${tierChanged === 'none' ? 'no change' : tierChanged} → tier ${newTier}, sub-tier ${newSubTier}.\nSteps:\n${steps.map((s) => `- ${s.step}: ${s.status}${s.consolidated != null ? ` (${s.consolidated} consolidated, ${s.gate_failures || 0} gate failures)` : ''}${s.error ? ` — ${s.error}` : ''}`).join('\n')}`,
        source: 'distillation',
        source_url: '',
        tags_json: JSON.stringify(['training-heartbeat', 'autonomous-learning', 'always-training', scoreResult.passed ? 'pass' : 'fail']),
        context: 'Autonomous training heartbeat — challenge + score + difficulty + consolidate + self-audit pipeline',
        domain: 'general',
        contradiction_flag: 'clear',
        contradiction_detail: '',
        session_token: 'training-heartbeat',
        distilled_primitives_json: JSON.stringify({ started_at: startedAt, steps, epoch: epochNumber }),
        sanitization_ledger: '[]',
        epistemic_confidence: 0.9,
        uncertainty_bounds: 'CERTIFIED',
        decoherence_count: 0,
        domain_transition_path: '',
      });
    } catch { /* best-effort */ }

    return Response.json({
      status: 'ok',
      started_at: startedAt,
      epoch: epochNumber,
      trainee: {
        id: trainee.id,
        name: trainee.name,
        agent_id: trainee.agent_id,
      },
      challenge: {
        pillar_id: challenge.pillar_id,
        name: challenge.name,
        domain: challenge.domain,
        tier: currentTier,
        sub_tier: currentSubTier,
        prompt: challenge.prompt,
      },
      result: {
        raw_score: scoreResult.raw_score,
        final_score: scoreResult.final_score,
        passed: scoreResult.passed,
        epistemic_bonus: scoreResult.epistemic_bonus,
        overclaim_penalty: scoreResult.overclaim_penalty,
        agent_answer: psiCatResponse.answer || '',
        reasoning_note_id: reasoningNoteId,
      },
      difficulty: {
        tier_changed: tierChanged,
        new_tier: newTier,
        new_sub_tier: newSubTier,
        pillars_passed_in_tier: newPillarsPassedInTier,
      },
      ledger: {
        id: ledgerEntry?.id || null,
        hash: sessionHash,
      },
      steps,
      consolidation: consolidation?.data || null,
      audit: audit?.data?.auditReport || null,
    });
  } catch (error) {
    return Response.json({ error: error.message, status: 'unavailable' }, { status: 200 });
  }
}

// ── SHA-256 hash helper (Deno-compatible crypto.subtle) ──
async function computeHash(payload) {
  const data = new TextEncoder().encode(JSON.stringify(payload));
  const buf = await crypto.subtle.digest('SHA-256', data);
  return 'sha256-' + Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 16);
}