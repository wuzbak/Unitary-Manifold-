import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { getLiveStatus, clearCache } from '../../shared/repoContext.ts';

/**
 * fetchRepoContext — Returns live repository status for all dashboards.
 *
 * Fetches 9-INFRASTRUCTURE/um_live_status.json (primary) or parses STATUS.md
 * (fallback). Cached 1 hour at the module level. forceRefresh clears the cache.
 *
 * Returns: { status, data, fetchedAt }
 * data contains: version, testsPassed, lean4Theorems, nextPillarSlot, openProblems, ...
 */
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    let body = {};
    try { body = await req.json(); } catch {}
    if (body.forceRefresh) clearCache();

    const data = await getLiveStatus();
    if (!data) {
      return Response.json(
        { status: 'unavailable', data: null, message: 'Failed to fetch repository context — um_live_status.json and STATUS.md both unavailable' },
        { status: 200 }
      );
    }

    return Response.json({
      status: 'ok',
      data,
      fetchedAt: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ status: 'unavailable', data: null, message: error.message }, { status: 200 });
  }
}