import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { computeManifoldVersion } from '../../shared/manifoldVersionTimeline.ts';

/**
 * psicatRadioUpload — catalogs an uploaded media file as a PsiCatRadioTrack.
 *
 * Frontend flow:
 *   1. User selects a file from local folders
 *   2. Browser extracts duration (via temporary <audio>/<video> element) and
 *      date_created (from file.lastModified)
 *   3. Frontend uploads the file (or a compressed playback copy) via
 *      base44.integrations.Core.UploadPublicFile
 *   4. Frontend calls THIS function with { file_url, title, media_type,
 *      duration_seconds, date_created, source_folder, tags,
 *      original_size_bytes, quality_tier }
 *   5. This function computes the manifold_version tag and creates the entity
 *
 * Supports single-track and batch (tracks[]) payloads.
 */
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const tracks = Array.isArray(body.tracks) ? body.tracks : [body];

    const results = [];
    for (const t of tracks) {
      if (!t.title || !t.file_url) {
        results.push({ title: t.title || '(untitled)', error: 'Missing title or file_url' });
        continue;
      }
      const manifoldVersion = computeManifoldVersion(t.date_created);
      const record = await base44.entities.PsiCatRadioTrack.create({
        title: t.title,
        media_type: t.media_type || 'audio',
        file_url: t.file_url,
        duration_seconds: Number(t.duration_seconds) || 0,
        date_created: t.date_created || '',
        manifold_version: manifoldVersion,
        tags_json: JSON.stringify(t.tags || []),
        source_folder: t.source_folder || '',
        notes: t.notes || '',
        original_size_bytes: Number(t.original_size_bytes) || 0,
        quality_tier: t.quality_tier || 'original',
      });
      results.push({ id: record.id, title: record.title, manifold_version: manifoldVersion });
    }

    return Response.json({ uploaded: results.length, tracks: results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}