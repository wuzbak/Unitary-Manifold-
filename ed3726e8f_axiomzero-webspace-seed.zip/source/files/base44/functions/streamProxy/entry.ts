/**
 * streamProxy — last-resort streaming CORS relay for internet radio stations
 * that the browser cannot play directly (mixed-content HTTP streams on the
 * HTTPS site, or CORS-blocked streams that break the Web Audio graph).
 *
 * The browser <audio> element loads this endpoint as a same-origin URL, so
 * neither mixed-content nor CORS restrictions apply. The function fetches the
 * upstream stream server-side and pipes the bytes straight through to the
 * client with the upstream content-type preserved.
 *
 * This is a RELAY, not a transcoder — it removes network/CORS barriers (the
 * largest share of "unplayable" stations) but cannot make a browser play a
 * codec it doesn't support (e.g. HE-AAC). Truly unsupported codecs are
 * flagged client-side with a clear state.
 *
 * Invoked two ways:
 *   - GET  /functions/streamProxy?url=<encoded>   (browser <audio src>)
 *   - POST with JSON body { url }                 (SDK / programmatic)
 *
 * Concurrency-capped and hard-timeout-bounded to protect backend resources.
 */
const USER_AGENT = 'AxiomZero-SDR-Radio/1.0 (https://axiomzero-webspace-prototype.base44.app)';
const MAX_CONCURRENT = 12;
const STREAM_TIMEOUT_MS = 60000; // 60s hard cap on the upstream connect + first byte
let activeProxies = 0;

export default async function(req: Request): Promise<Response> {
  try {
    // Accept url from query (GET) or body (POST)
    let url = '';
    if (req.method === 'GET') {
      url = new URL(req.url).searchParams.get('url') || '';
    } else {
      const body = await req.json().catch(() => ({}));
      url = (body?.url || '').trim();
    }
    if (!url || !/^https?:\/\//i.test(url)) {
      return Response.json({ error: 'Valid url required' }, { status: 400 });
    }

    // Concurrency cap
    if (activeProxies >= MAX_CONCURRENT) {
      return Response.json({ error: 'proxy busy — try again shortly', status: 'busy' }, { status: 503 });
    }
    activeProxies++;

    try {
      const upstream = await fetch(url, {
        headers: {
          'User-Agent': USER_AGENT,
          'Accept': 'audio/*,*/*',
          'Icy-MetaData': '0', // request no ICY metadata interleaving for clean audio
        },
        // @ts-ignore — AbortSignal.timeout is valid in Workers
        signal: AbortSignal.timeout(STREAM_TIMEOUT_MS),
        redirect: 'follow',
      });

      if (!upstream.ok || !upstream.body) {
        activeProxies--;
        return Response.json({ error: `upstream HTTP ${upstream.status || 'unavailable'}` }, { status: 502 });
      }

      // Preserve the upstream content-type (audio/mpeg, audio/aac, audio/ogg, etc.)
      const ct = upstream.headers.get('content-type') || 'audio/mpeg';
      // Identity stream — pipe upstream body through to the client.
      const { readable, writable } = new TransformStream();
      (async () => {
        try {
          await upstream.body.pipeTo(writable);
        } catch (e) {
          // upstream ended or aborted — close the writable
          try { writable.abort(e as any); } catch {}
        } finally {
          activeProxies = Math.max(0, activeProxies - 1);
        }
      })();

      return new Response(readable, {
        status: 200,
        headers: {
          'Content-Type': ct,
          'Cache-Control': 'no-store, no-transform',
          'Access-Control-Allow-Origin': '*',
          'X-PsiCat-Proxy': 'relay',
        },
      });
    } catch (e) {
      activeProxies--;
      return Response.json({ error: (e as Error).message || 'proxy fetch failed' }, { status: 502 });
    }
  } catch (error) {
    activeProxies = Math.max(0, activeProxies - 1);
    return Response.json({ error: error.message }, { status: 500 });
  }
}