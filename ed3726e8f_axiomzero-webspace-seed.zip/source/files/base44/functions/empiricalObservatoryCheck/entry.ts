/**
 * empiricalObservatoryCheck — Scheduled empirical observatory monitor.
 *
 * Polls for new observational data releases from DESI DR3, JUNO, and
 * LiteBIRD pre-launch status. When a new release crosses a certified kill
 * threshold (e.g., DESI w_a ≠ 0 confirmed >3σ by ≥3 datasets → Pillar 486),
 * logs an empirical tripwire to MerlinNote and surfaces the event.
 *
 * Called weekly by the EmpiricalObservatoryMonitor workflow.
 * Admin-only (scheduled task).
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const OBSERVATORIES = [
  {
    id: 'DESI',
    name: 'DESI DR3 dark energy',
    kill_condition: 'w_a ≠ 0 confirmed >3σ by ≥3 independent datasets',
    pillar: 486,
    status_key: 'w_a',
    query: 'DESI DR3 dark energy w_a results 2026',
  },
  {
    id: 'JUNO',
    name: 'JUNO neutrino mass ordering Δm²₂₁',
    kill_condition: 'IH confirmed >3σ OR Δm²₂₁ measured value excludes UM window',
    pillar: 796,
    status_key: 'dm21',
    query: 'JUNO 2026 neutrino mass ordering Δm²₂₁ results',
  },
  {
    id: 'LiteBIRD',
    name: 'LiteBIRD CMB birefringence β',
    kill_condition: 'β outside [0.22°, 0.38°] OR β in [0.29°, 0.31°]',
    pillar: 795,
    status_key: 'beta',
    query: 'LiteBIRD CMB birefringence beta launch status 2026 2027',
  },
];

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ status: 'unavailable', error: 'Unauthorized' }, { status: 200 });
    if (user.role !== 'admin') return Response.json({ status: 'forbidden', error: 'Admin only' }, { status: 200 });

    const tripwires = [];

    for (const obs of OBSERVATORIES) {
      try {
        // Check for recent updates via web search
        const llmRes = await base44.integrations.Core.InvokeLLM({
          prompt: `Check for the latest ${obs.name} results or announcements as of 2026. Has there been a new data release? If so, what are the key findings? Specifically: has the kill condition "${obs.kill_condition}" been triggered? Respond in JSON format with: { "new_release": boolean, "findings": string, "kill_condition_triggered": boolean, "details": string }`,
          add_context_from_internet: true,
          model: 'gemini_3_flash',
          response_json_schema: {
            type: 'object',
            properties: {
              new_release: { type: 'boolean' },
              findings: { type: 'string' },
              kill_condition_triggered: { type: 'boolean' },
              details: { type: 'string' },
            },
            required: ['new_release', 'kill_condition_triggered'],
          },
        });

        const result = typeof llmRes === 'object' ? llmRes : null;

        if (result?.new_release || result?.kill_condition_triggered) {
          // Log a tripwire to MerlinNote
          const note = await base44.entities.MerlinNote.create({
            title: `[EMPIRICAL TRIPWIRE] ${obs.name} — ${result.kill_condition_triggered ? 'KILL CONDITION TRIGGERED' : 'New release'}`,
            content: (result.findings || result.details || `New ${obs.name} release detected.`).slice(0, 5000),
            source: 'distillation',
            source_url: '',
            tags_json: JSON.stringify([
              'empirical-tripwire',
              `observatory:${obs.id}`,
              `pillar:${obs.pillar}`,
              result.kill_condition_triggered ? 'kill-condition-triggered' : 'new-release',
            ]),
            context: `Empirical observatory monitor — ${obs.name} (Pillar ${obs.pillar})`,
            domain: 'physics',
            sanitization_ledger: '[]',
            contradiction_flag: result.kill_condition_triggered ? 'flagged' : 'clear',
            contradiction_detail: result.kill_condition_triggered
              ? `Kill condition triggered: ${obs.kill_condition} (Pillar ${obs.pillar})`
              : '',
            session_token: '',
            distilled_primitives_json: JSON.stringify({
              tensions: result.kill_condition_triggered ? [obs.kill_condition] : [],
              conjectures: [],
              constraints: [],
              heuristics: [obs.name],
            }),
          });

          tripwires.push({
            observatory: obs.id,
            name: obs.name,
            kill_condition_triggered: result.kill_condition_triggered,
            note_id: note.id,
            findings: result.findings,
          });
        }
      } catch (obsError) {
        // Graceful degradation — continue to next observatory
        tripwires.push({
          observatory: obs.id,
          error: obsError.message,
        });
      }
    }

    return Response.json({
      status: 'ok',
      checked: OBSERVATORIES.length,
      tripwires,
      checked_at: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({
      status: 'unavailable',
      error: error.message,
      tripwires: [],
    }, { status: 200 });
  }
}