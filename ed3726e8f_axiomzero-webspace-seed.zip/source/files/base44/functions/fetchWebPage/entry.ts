import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    let body: any = {};
    try { body = await req.json(); } catch (e) {}
    const url: string = body.url;
    if (!url) return Response.json({ error: 'URL required' }, { status: 400 });

    // Validate URL format
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(url);
    } catch (e) {
      return Response.json({ error: 'Invalid URL format' }, { status: 400 });
    }
    if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
      return Response.json({ error: 'Only HTTP/HTTPS URLs allowed' }, { status: 400 });
    }

    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; AxiomZero-Merlin-Bot/1.0; +https://axiomzerospc.org)',
        'Accept': 'text/html,application/xhtml+xml,application/xml,text/plain,application/json',
        'Accept-Language': 'en-US,en;q=0.9',
      },
      redirect: 'follow',
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      return Response.json({ url, title: '', content: '', isTruncated: false, contentLength: 0, status: 'unavailable', message: `Fetch failed: ${response.status}` }, { status: 200 });
    }

    const contentType = response.headers.get('content-type') || '';
    const rawContent = await response.text();
    const maxChars = 30000;

    let extractedText: string;
    let title: string = '';

    if (contentType.includes('application/json')) {
      extractedText = rawContent.slice(0, maxChars);
    } else if (contentType.includes('text/plain')) {
      extractedText = rawContent.slice(0, maxChars);
    } else {
      // HTML — extract title and visible text
      const titleMatch = rawContent.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
      if (titleMatch) title = titleMatch[1].trim().replace(/&[^;]+;/g, ' ');

      // Remove scripts, styles, nav, footer, header, aside
      let cleaned = rawContent
        .replace(/<script[\s\S]*?<\/script>/gi, '')
        .replace(/<style[\s\S]*?<\/style>/gi, '')
        .replace(/<nav[\s\S]*?<\/nav>/gi, '')
        .replace(/<footer[\s\S]*?<\/footer>/gi, '')
        .replace(/<header[\s\S]*?<\/header>/gi, '')
        .replace(/<aside[\s\S]*?<\/aside>/gi, '')
        .replace(/<noscript[\s\S]*?<\/noscript>/gi, '')
        .replace(/<!--[\s\S]*?-->/g, '');

      // Preserve line breaks for block elements
      cleaned = cleaned
        .replace(/<\/(p|div|br|li|h[1-6]|tr|td|th)>/gi, '\n')
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<li[^>]*>/gi, '• ');

      // Strip remaining tags
      cleaned = cleaned.replace(/<[^>]+>/g, '');

      // Decode common HTML entities
      cleaned = cleaned
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&nbsp;/g, ' ')
        .replace(/&mdash;/g, '—')
        .replace(/&ndash;/g, '–')
        .replace(/&hellip;/g, '…')
        .replace(/&[a-z]+;/g, ' ');

      // Collapse whitespace
      extractedText = cleaned
        .split('\n')
        .map((line) => line.replace(/[ \t]+/g, ' ').trim())
        .filter((line) => line.length > 0)
        .join('\n')
        .slice(0, maxChars);
    }

    const isTruncated = extractedText.length >= maxChars;

    return Response.json({
      url,
      title: title.slice(0, 200),
      content: extractedText,
      isTruncated,
      contentLength: extractedText.length,
      contentType,
    });
  } catch (error) {
    return Response.json({ url: '', title: '', content: '', isTruncated: false, contentLength: 0, status: 'unavailable', message: error.message }, { status: 200 });
  }
}