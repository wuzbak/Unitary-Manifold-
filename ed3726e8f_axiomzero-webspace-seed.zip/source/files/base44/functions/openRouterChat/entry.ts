import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { secrets } from 'base44:runtime';

const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';
const APP_REFERER = 'https://axiomzerospc.org';
const APP_TITLE = 'AxiomZero';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const {
      model = 'nvidia/nemotron-3.5-lightning:free',
      messages = [],
      temperature,
      max_tokens,
      response_format,
      feature_key = 'default',
    } = body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return Response.json({ error: 'messages array is required' }, { status: 400 });
    }

    const apiKey = secrets.get('OPENROUTER_API_KEY');
    if (!apiKey) return Response.json({ error: 'OPENROUTER_API_KEY not configured', status: 'missing-credentials', content: '' }, { status: 200 });

    const payload = {
      model,
      messages,
      ...(temperature != null ? { temperature } : {}),
      ...(max_tokens != null ? { max_tokens } : {}),
      ...(response_format ? { response_format } : {}),
    };

    const doFetch = async (mdl) => {
      const p = { ...payload, model: mdl };
      const r = await fetch(OPENROUTER_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'HTTP-Referer': APP_REFERER,
          'X-Title': APP_TITLE,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(p),
      });
      const j = await r.json();
      return { ok: r.ok, status: r.status, data: j };
    };

    let { ok, status, data } = await doFetch(model);

    // Strong free-model fallback on 402 (insufficient credits), 429 (rate limit), or 403.
    // Falls back to the next strong free model instead of a tiny toy model.
    let fell_back = false;
    let fallback_model = null;
    if (!ok && (status === 402 || status === 429 || status === 403)) {
      const FREE_MODELS = ['nvidia/nemotron-3-ultra-550b-a55b:free', 'minimax/minimax-m3:free', 'nvidia/nemotron-3.5-lightning:free'];
      for (const fm of FREE_MODELS) {
        if (fm === model) continue; // don't retry the same model that just failed
        const retry = await doFetch(fm);
        if (retry.ok) {
          ok = true;
          status = 200;
          data = retry.data;
          fell_back = true;
          fallback_model = fm;
          break;
        }
      }
    }

    if (!ok) {
      return Response.json(
        { error: data?.error?.message || `OpenRouter returned ${status}`, provider_error: data?.error || null, fell_back, fallback_model, status: status === 429 ? 'rate-limited' : 'unavailable', content: '' },
        { status: 200 }
      );
    }

    // Normalize the OpenAI-compatible response
    const choice = data?.choices?.[0];
    const content = choice?.message?.content ?? '';
    const result = {
      content,
      model: data?.model || model,
      usage: data?.usage || null,
      feature_key,
      finish_reason: choice?.finish_reason || null,
      fell_back,
      fallback_model,
    };

    return Response.json(result);
  } catch (error) {
    return Response.json({ error: error.message, status: 'unavailable', content: '' }, { status: 200 });
  }
}