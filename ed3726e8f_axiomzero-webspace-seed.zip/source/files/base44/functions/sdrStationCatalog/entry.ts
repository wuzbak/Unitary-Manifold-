import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { fetchWithResilience } from '../../shared/resilientFetch.ts';
import { isBlockedStation } from '../../shared/stationBlocklist.ts';
import { PLAYABLE_REPUTABLE_PRESS, toSdrStationRecord } from '../../shared/reputablePressStations.ts';

/**
 * sdrStationCatalog — serves the curated Washington State broadcast + Web-SDR
 * receiver catalog AND auto-fetches popular global FM/AM stations from the
 * radio-browser API on load, merging them into a single playable catalog.
 *
 * Flow:
 *   1. Read all SdrStation records (seeded WA + previously cached radio_browser_api)
 *   2. If fewer than 30 cached FM or 30 cached AM radio-browser stations, fetch
 *      popular FM and AM stations from radio-browser (order=votes, hidebroken=true)
 *   3. Normalize, deduplicate by stream_url, cache fresh records as SdrStation
 *   4. Filter to PLAYABLE stations only (non-empty stream_url)
 *   5. Return grouped by station_type
 */
const RADIO_BROWSER_MIRRORS = [
  'https://all.api.radio-browser.info',
  'https://fi1.api.radio-browser.info',
  'https://de1.api.radio-browser.info',
  'https://nl1.api.radio-browser.info',
];
const VALID_CODECS = ['MP3', 'AAC', 'AAC+', 'OGG', 'FLAC', 'OPUS'];
const USER_AGENT = 'AxiomZero-SDR-Radio/1.0 (https://axiomzero-webspace-prototype.base44.app)';
const MIN_CACHED_FM = 30;
const MIN_CACHED_AM = 30;
const MIN_CACHED_WA_FM = 15;
const MIN_CACHED_WA_AM = 10;
const FETCH_LIMIT = 45;
const WA_FETCH_LIMIT = 35;

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    // Public endpoint — no auth gate. SdrStation has public read RLS ({}) and
    // writes use asServiceRole, so anonymous visitors can load the catalog.

    // 1. Read all stations from DB (seeded + cached radio_browser_api)
    let stations: any[] = [];
    try {
      stations = await base44.entities.SdrStation.list('-created_date', 1000);
    } catch (e) {
      stations = [];
    }

    // 2. Check cache sufficiency for radio_browser_api FM/AM
    const cachedFm = stations.filter(s => s.station_type === 'fm' && s.source === 'radio_browser_api');
    const cachedAm = stations.filter(s => s.station_type === 'am' && s.source === 'radio_browser_api');
    const cachedWaFm = stations.filter(s => s.station_type === 'wa_fm' && s.source === 'radio_browser_api');
    const cachedWaAm = stations.filter(s => s.station_type === 'wa_am' && s.source === 'radio_browser_api');

    if (cachedFm.length < MIN_CACHED_FM || cachedAm.length < MIN_CACHED_AM ||
        cachedWaFm.length < MIN_CACHED_WA_FM || cachedWaAm.length < MIN_CACHED_WA_AM) {
      // 3. Fetch popular FM, AM, and Washington State stations from radio-browser in parallel
      const [fmApiStations, amApiStations, waFmStations, waAmStations] = await Promise.all([
        fetchPopularByTag('fm', FETCH_LIMIT),
        fetchPopularByTag('am', FETCH_LIMIT),
        fetchByState('Washington', 'fm', WA_FETCH_LIMIT),
        fetchByState('Washington', 'am', WA_FETCH_LIMIT),
      ]);

      const fmRecords = fmApiStations.map(s => normalizeStation(s, 'fm'));
      const amRecords = amApiStations.map(s => normalizeStation(s, 'am'));
      const waFmRecords = waFmStations.map(s => normalizeStation(s, 'wa_fm'));
      const waAmRecords = waAmStations.map(s => normalizeStation(s, 'wa_am'));
      const fresh = [...fmRecords, ...amRecords, ...waFmRecords, ...waAmRecords].filter(s => !isBlockedStation(s));

      // Deduplicate against existing stations by stream_url
      const existingUrls = new Set(stations.map(s => s.stream_url).filter(Boolean));
      const toCreate = fresh.filter(r => r.stream_url && !existingUrls.has(r.stream_url));

      if (toCreate.length > 0) {
        try {
          await base44.asServiceRole.entities.SdrStation.bulkCreate(toCreate);
          stations.push(...toCreate);
        } catch (e) {
          // cache write failure is non-fatal — still return what we have
        }
      }
    }

    // 3b. Seed reputable press stations (NPR, NASA, BBC, DW, RFI, ABC, etc.)
    // Only seed if not already present (deduplicate by stream_url)
    const existingUrls = new Set(stations.map(s => s.stream_url).filter(Boolean));
    const reputableToCreate = PLAYABLE_REPUTABLE_PRESS
      .map(toSdrStationRecord)
      .filter(r => r.stream_url && !existingUrls.has(r.stream_url));

    if (reputableToCreate.length > 0) {
      try {
        await base44.asServiceRole.entities.SdrStation.bulkCreate(reputableToCreate);
        stations.push(...reputableToCreate);
      } catch (e) {
        // seeding failure is non-fatal — still return what we have
      }
    }

    // 4. Filter to PLAYABLE stations only (non-empty stream_url)
    const playable = stations.filter(s => s.stream_url && s.stream_url.trim().length > 0 && !isBlockedStation(s));

    // 5. Group by station_type
    const grouped = {
      web_sdr: playable.filter(s => s.station_type === 'web_sdr'),
      wa_fm: playable.filter(s => s.station_type === 'wa_fm'),
      wa_am: playable.filter(s => s.station_type === 'wa_am'),
      fm: playable.filter(s => s.station_type === 'fm'),
      am: playable.filter(s => s.station_type === 'am'),
      internet_stream: playable.filter(s => s.station_type === 'internet_stream'),
    };

    return Response.json({
      total: playable.length,
      groups: grouped,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

/**
 * Fetch popular stations tagged with a given tag (fm/am) from radio-browser.
 * Tries mirrors in order, returns the first successful result set.
 */
async function fetchPopularByTag(tag: string, limit: number): Promise<any[]> {
  const params = new URLSearchParams();
  params.set('limit', String(limit));
  params.set('order', 'votes');
  params.set('reverse', 'true');
  params.set('hidebroken', 'true');
  params.set('tag', tag);

  for (const mirror of RADIO_BROWSER_MIRRORS) {
    const url = `${mirror}/json/stations/search?${params.toString()}`;
    const res = await fetchWithResilience<any[]>(url, {
      headers: { 'User-Agent': USER_AGENT, 'Accept': 'application/json' },
      cacheTtl: 600000, // 10 min cache
      retries: 1,
      timeoutMs: 10000,
    });
    if (res.data && Array.isArray(res.data) && res.data.length > 0) {
      // Filter to streamable + valid codec
      return res.data.filter((s: any) =>
        s.url_resolved &&
        s.url_resolved.length > 0 &&
        s.lastcheckok === 1 &&
        VALID_CODECS.includes((s.codec || '').toUpperCase())
      ).slice(0, limit);
    }
    if (res.status === 'live' && (!res.data || res.data.length === 0)) {
      continue; // try next mirror
    }
  }
  return [];
}

/**
 * Fetch stations from a specific US state, filtered by tag (fm/am).
 * Used to populate Washington State broadcast stations.
 */
async function fetchByState(state: string, tag: string, limit: number): Promise<any[]> {
  const params = new URLSearchParams();
  params.set('limit', String(limit));
  params.set('order', 'votes');
  params.set('reverse', 'true');
  params.set('hidebroken', 'true');
  params.set('country', 'The United States Of America');
  params.set('state', state);
  params.set('tag', tag);

  for (const mirror of RADIO_BROWSER_MIRRORS) {
    const url = `${mirror}/json/stations/search?${params.toString()}`;
    const res = await fetchWithResilience<any[]>(url, {
      headers: { 'User-Agent': USER_AGENT, 'Accept': 'application/json' },
      cacheTtl: 600000,
      retries: 1,
      timeoutMs: 10000,
    });
    if (res.data && Array.isArray(res.data) && res.data.length > 0) {
      return res.data.filter((s: any) =>
        s.url_resolved &&
        s.url_resolved.length > 0 &&
        s.lastcheckok === 1 &&
        VALID_CODECS.includes((s.codec || '').toUpperCase())
      ).slice(0, limit);
    }
    if (res.status === 'live' && (!res.data || res.data.length === 0)) {
      continue;
    }
  }
  return [];
}

/**
 * Normalize a radio-browser station to the SdrStation schema.
 */
function normalizeStation(s: any, stationType: string): any {
  const tagsRaw = (s.tags || '').split(',').map((t: string) => t.trim()).filter(Boolean);
  const tagsJson = JSON.stringify(tagsRaw.slice(0, 12));
  const altUrls = [s.url, s.url_resolved].filter((u: string) => u && u !== s.url_resolved);
  const altSet = Array.from(new Set(altUrls));
  const codecInfo = [s.codec, s.bitrate ? `${s.bitrate}kbps` : ''].filter(Boolean).join(' · ');

  return {
    name: (s.name || 'Unknown Station').trim(),
    station_type: stationType,
    band: stationType === 'fm' ? 'FM' : stationType === 'am' ? 'AM' : 'Internet',
    region: s.state || s.country || '',
    country: s.country || '',
    country_code: s.countrycode || '',
    frequency_mhz: 0,
    stream_url: s.url_resolved || s.url || '',
    embed_url: '',
    description: codecInfo || `${stationType.toUpperCase()} radio stream`,
    status: 'active',
    geo_lat: s.geo_lat || 0,
    geo_lng: s.geo_long || 0,
    source: 'radio_browser_api',
    codec: (s.codec || '').toUpperCase(),
    bitrate: s.bitrate || 0,
    vote_count: s.votes || 0,
    click_trend: s.clicktrend || 0,
    favicon_url: s.favicon || '',
    homepage_url: s.homepage || '',
    tags_json: tagsJson,
    language: (s.language || '').split(',')[0]?.trim() || '',
    last_checked_ok: s.lastcheckok === 1,
    alt_urls_json: JSON.stringify(altSet.slice(0, 5)),
  };
}