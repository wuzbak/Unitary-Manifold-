import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { zipSync, strToU8 } from 'npm:fflate@0.8.2';

// Pre-uploaded source code bundle (generated from the app's Node.js sandbox)
// This contains all React pages, components, backend functions, and config files
const SOURCE_BUNDLE_URL = 'https://base44.app/api/apps/6a51c0830aeacd39ab86c4f0/files/mp/public/6a51c0830aeacd39ab86c4f0/a3aa87a22_axiomzero-source-bundle.json';

const KNOWN_ENTITIES = [
  'User', 'FilmProject', 'Script', 'Scene', 'StoryFragment', 'BreakdownReview',
  'Location', 'CastMember', 'CrewMember', 'TimeCard', 'LocalResource', 'ShootDay',
  'CallSheet', 'Permit', 'FilmCredit', 'DepartmentItem', 'CameraItem', 'WardrobeItem',
  'StudioInventory', 'StudioLocation', 'StudioContact', 'ProjectTemplate', 'ProductionActivity',
  'Shot', 'StoryboardPanel', 'SdrStation', 'UserRadioFavorite', 'PsiCatRadioTrack',
  'PsiCatCouncil', 'PsiCatPromotionState', 'FallibilityEntry', 'GymTrainee', 'GymLedgerEntry',
  'CurriculumProgress', 'MerlinNote', 'MerlinSession', 'Investigation', 'WatchlistHit',
  'WatchlistEntry', 'Project', 'PentadGovernance', 'AgentLedger', 'AuditLog', 'Task', 'Inquiry',
  'DnDCustomSubclass', 'DnDRandomTable', 'DnDCustomSpell', 'DnDFaction', 'HomebrewPack',
  'MarketplacePack', 'DnDCustomMonster', 'DnDCustomItem', 'DnDCalendar', 'DnDLocation',
  'DnDLoreArticle', 'BattlemapScene', 'DnDRoll', 'DnDSessionLog', 'GeoMonitorView',
  'DnDInventoryItem', 'DnDPlayer', 'DnDMap', 'DnDEncounter', 'DnDCampaign', 'DnDSharedImage',
  'DnDCombatant', 'DnDTreasure', 'DnDQuest', 'DnDCharacter', 'DnDNpc',
];

const KNOWN_SECRETS = [
  { name: 'ACLED_EMAIL', description: 'Email for ACLED conflict data API access' },
  { name: 'OPENSKY_CLIENT_SECRET', description: 'Client secret for OpenSky flight tracker OAuth' },
  { name: 'OPENSKY_CLIENT_ID', description: 'Client ID for OpenSky flight tracker OAuth' },
  { name: 'FIRMS_MAP_KEY', description: 'API key for NASA FIRMS fire data map' },
  { name: 'EIA_API_KEY', description: 'API key for EIA electricity grid data' },
  { name: 'AIRNOW_API_KEY', description: 'API key for AirNow air quality data' },
  { name: 'NASA_API_KEY', description: 'API key for NASA APIs' },
  { name: 'OPENROUTER_API_KEY', description: 'API key for OpenRouter LLM proxy' },
  { name: 'ALEPH_API_TOKEN', description: 'API token for Aleph/OCCRP investigative data' },
  { name: 'SEC_EDGAR_CONTACT_EMAIL', description: 'Contact email for SEC EDGAR API compliance' },
  { name: 'OPENSANCTIONS_API_KEY', description: 'API key for OpenSanctions data' },
  { name: 'OPENCORPORATES_API_TOKEN', description: 'API token for OpenCorporates company data' },
  { name: 'FEC_API_KEY', description: 'API key for FEC campaign finance data' },
  { name: 'COURTLISTENER_API_TOKEN', description: 'API token for CourtListener legal data' },
  { name: 'GOVINFO_API_KEY', description: 'API key for GovInfo government publications' },
];

const KNOWN_BACKEND_FUNCTIONS = [
  'acledConflict','adsbFlightTracker','agWeatherReport','agentInvoke','agentOrchestrate',
  'agentToolkit','airNow','aisMaritime','alephOccrp','checkSecretStatus','closurePipelineState',
  'coopsStations','courtListener','defenseNewsFeed','deleteAccount','dndCompileEntry',
  'dndExportBundle','dndImportParse','dndMarketplace','dndSessionRecap','dojEpstein','echoEpa',
  'eiaGrid','empiricalObservatoryCheck','epsteinMedia','fallibilityAutoScan','fec',
  'fetchAzProducts','fetchBookMarkdown','fetchMerlinNavigator','fetchMerlinRoadmap',
  'fetchRepoContext','fetchRepoFile','fetchRepoReadme','fetchRepoTree','fetchWebPage',
  'gdacsFeed','gdeltEvents','generateCrawlManifest','generateFalsificationOracle',
  'githubRepoContent','globalStationSearch','govInfo','hardinessZone','icijOffshore',
  'icijOffshoreSearch','lean4ProofRegistry','leanPythonBridgeHealth','logSystemHealth',
  'merlinAgentLoop','merlinAnalyzeDepth','merlinConsolidateMemory','merlinCouncilPropose',
  'merlinDistillInsight','merlinEclipsaJudge','merlinFallibilitySuggest','merlinIntentLayer',
  'merlinProofImage','merlinRelayEmail','merlinRepoTrainingSync','merlinSeedMemory',
  'merlinSelfAudit','merlinTrainingHeartbeat','nasaCneos','nasaDonki','nasaFeeds',
  'nasaFirms','ndbcBuoys','nhcCyclones','nwsAlerts','openCorporates','openRouterChat',
  'openSanctions','openskyFlights','oxQuery','propublicaNonprofits','psicatAutonomousPropose',
  'psicatRadioBuildPlaylist','psicatRadioDedup','psicatRadioOrganize','psicatRadioRehostUrl',
  'psicatRadioUpload','purgeBlockedStations','radioBrowserSearch','resolveStreamUrl',
  'sdrRadioFeed','sdrStationCatalog','secEdgar','smithsonianVolcano','spaceWeatherProxy',
  'streamProxy','systemHealthCheck','trustedNewsFeed','watchlistScan','waybackMachine',
  'webspaceSeedExport','worldMonitorFeeds','zarrChunkServer',
];

function generateMigrationMd(manifest: any): string {
  return `# AxiomZero Webspace — SEED Migration Guide

Generated: ${manifest.generated_at}
Published URL: ${manifest.published_url}
Entities Exported: ${manifest.total_entities}
Entity Records: ${manifest.total_entity_records}
Backend Functions Documented: ${manifest.backend_functions_count}

## What's In This Bundle

### Source Code (\`source/\`)
Full app source code — all React pages, components, backend functions, entities, workflows,
and config files. Included in two formats:
- \`source/source_bundle.json\` — Machine-readable JSON with all files (path → content)
- \`source/files/\` — Individual files preserving the original directory structure

Source files included: ${manifest.source_code?.file_count || 0}
Source snapshot generated: ${manifest.source_code?.generated_at || 'N/A'}

### Entity Schemas (\`data/schemas/\`)
Full JSON schema definitions for all ${manifest.total_entities} entities in the app.
These define the complete data model — every field, type, default, and RLS rule.

### Entity Data (\`data/entities/\`)
Exported data records for all entities (JSON arrays, one file per entity).
Total records exported: ${manifest.total_entity_records}

### Documentation (\`docs/\`)
- \`MIGRATION.md\` — This file
- \`DEPLOYMENT_MANIFEST.json\` — Full deployment manifest (entities, functions, secrets, connectors)
- \`SECRETS_MANIFEST.md\` — All 15 secret/env-var names with descriptions
- \`DNS_DOMAINS.md\` — DNS, nameserver, and domain configuration guide
- \`migrate.sh\` — One-command migration script

## Migration Steps

### 1. Extract Source Code
\`\`\`bash
# Copy source files to your project root
cp -r source/files/* your-project/
# Or use the JSON bundle programmatically
node -e "const b=require('./source/source_bundle.json'); Object.entries(b.files).forEach(([p,c])=>{require('fs').mkdirSync(require('path').dirname(p),{recursive:true});require('fs').writeFileSync(p,c)})"
\`\`\`

### 2. Install Dependencies
\`\`\`bash
npm ci  # or npm install
\`\`\`

### 3. Environment Variables / Secrets
See **docs/SECRETS_MANIFEST.md** — re-provision all 15 secrets on the target platform.

### 4. Build
\`\`\`bash
npm run build
\`\`\`

### 5. DNS / Domain Configuration
See **docs/DNS_DOMAINS.md** for DNS, nameserver, and SSL instructions.

### 6. Database / Entity Data
Entity data is in \`data/entities/\`. Import into your new platform:
- **Base44**: Use SDK or dashboard bulk import
- **WordPress**: Use WP All Import with JSON files
- **CMS2CMS**: Map entity types to CMS content types
- **Automattic RSS**: Convert JSON records to RSS XML for feed import

### 7. Platform-Specific Notes

#### WordPress
- Convert React pages to WP pages or custom post types
- Use entity JSON with WP All Import for content migration
- Map entity fields to WordPress custom fields (ACF / CMB2)

#### CMS2CMS
- Upload JSON files as custom post types
- Use deployment manifest for field mapping

#### Automattic RSS
- Convert entity JSON to RSS XML
- Use deployment manifest for content type mapping

## Verification
1. All pages load correctly
2. Entity data is accessible
3. Backend functions respond
4. Authentication works
5. All secrets are provisioned
6. DNS resolves to the new host
`;
}

function generateSecretsMd(): string {
  const secretList = KNOWN_SECRETS.map(s => `### ${s.name}\n\n${s.description}\n`).join('\n');
  return `# Secrets Manifest — AxiomZero Webspace

> **WARNING**: Secret **values** are NOT included. You MUST re-provision each on the target.

## How to Set Secrets

### On Base44
Dashboard → Settings → Secrets → Add each secret name + value

### On Custom Hosting
\`\`\`bash
export ACLED_EMAIL="your_value"
export OPENSKY_CLIENT_SECRET="your_value"
# ... etc
\`\`\`

### On Vercel / Netlify / Cloudflare
Add each as a project environment variable in the dashboard.

## Complete Secret List

${secretList}

## Notes
- Base44 auto-provides \`BASE44_APP_ID\` — no action needed.
- Never commit secret values to version control.
- Some secrets are used across multiple backend functions.
`;
}

function generateDnsMd(): string {
  return `# DNS, Nameservers & Domain Configuration — AxiomZero Webspace

## Current Configuration
- **Published App URL**: https://axiomzero-webspace-prototype.base44.app
- **Platform**: Base44 (base44.app)

## DNS Records

### Option A: Keep Base44 Hosting
\`\`\`
Type:  CNAME
Name:  @ (or subdomain)
Value: axiomzero-webspace-prototype.base44.app
TTL:   3600
\`\`\`

### Option B: Migrate to New Hosting
\`\`\`
Type:  A
Name:  @
Value: <target hosting IP>
TTL:   3600
\`\`\`

## Nameservers
\`\`\`
NS1: ___________________ (fill from your registrar)
NS2: ___________________ (fill from your registrar)
\`\`\`

### Changing Nameservers
1. Log into your domain registrar
2. Update nameservers to target hosting provider
3. Wait 24-48h for DNS propagation
4. Verify: \`dig axiomzerospc.org\`

## Known Domains
- **axiomzerospc.org** — Primary domain
- **axiomzero-webspace-prototype.base44.app** — Base44 URL

## SSL / TLS
- Base44 provisions SSL automatically
- For custom hosting, use Let's Encrypt or provider SSL
- Force HTTPS redirect

## Email Configuration
- Configure SPF, DKIM, DMARC for your domain
- For custom hosting, configure SMTP relay (SendGrid, Postmark, etc.)

## Migration Checklist
- [ ] DNS records updated
- [ ] Nameservers updated (if changing)
- [ ] SSL/TLS configured
- [ ] Domain verified on target
- [ ] Email DNS records configured
- [ ] Old DNS records removed after propagation
`;
}

function generateMigrateScript(): string {
  return `#!/bin/bash
# AxiomZero Webspace — Migration Script
set -e
echo "═══════════════════════════════════════════════"
echo "  AxiomZero Webspace — Migration Script"
echo "═══════════════════════════════════════════════"

if ! command -v node &> /dev/null; then echo "✗ Node.js not found."; exit 1; fi
NODE_VERSION=$(node -v | cut -d'.' -f1 | tr -d 'v')
if [ "$NODE_VERSION" -lt 18 ]; then echo "✗ Node.js 18+ required."; exit 1; fi
echo "✓ Node.js $(node -v)"

echo "── Installing dependencies ──"
if [ -f package-lock.json ]; then npm ci; else npm install; fi
echo "✓ Dependencies installed"

echo "── Building ──"
npm run build
echo "✓ Build complete (dist/)"

if [ -d data/entities ]; then
  echo "✓ $(ls -1 data/entities/*.json 2>/dev/null | wc -l) entity data files"
fi

echo "═══════════════════════════════════════════════"
echo "  Next: provision secrets (docs/SECRETS_MANIFEST.md)"
echo "  Configure DNS (docs/DNS_DOMAINS.md)"
echo "  Deploy dist/ to hosting provider"
echo "  Import data from data/entities/"
echo "═══════════════════════════════════════════════"
`;
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden: admin only' }, { status: 403 });

    // 1. Export entity schemas and data
    const entitySchemas: Record<string, any> = {};
    const entityExports: Record<string, any> = {};
    const entityCounts: Record<string, number> = {};

    for (const name of KNOWN_ENTITIES) {
      try {
        const schema = await base44.entities[name].schema();
        entitySchemas[name] = schema;
      } catch {}
      try {
        const records = await base44.asServiceRole.entities[name].list();
        entityExports[name] = records;
        entityCounts[name] = Array.isArray(records) ? records.length : 0;
      } catch (e: any) {
        entityExports[name] = { _export_error: e.message };
        entityCounts[name] = -1;
      }
    }

    // 2. Fetch source code bundle (pre-uploaded from the app sandbox)
    let sourceBundle: any = null;
    let sourceFileCount = 0;
    let sourceGeneratedAt = '';
    try {
      const sourceRes = await fetch(SOURCE_BUNDLE_URL);
      if (sourceRes.ok) {
        const sourceText = await sourceRes.text();
        sourceBundle = JSON.parse(sourceText);
        sourceFileCount = sourceBundle.file_count || 0;
        sourceGeneratedAt = sourceBundle.generated_at || '';
      }
    } catch (e: any) {
      // Source code fetch failed — continue without it
    }

    // 3. Generate manifests and docs
    const generatedAt = new Date().toISOString();
    const validEntityNames = Object.keys(entityCounts).filter(n => entityCounts[n] >= 0);

    const deploymentManifest = {
      generated_at: generatedAt,
      app_name: 'AxiomZero Webspace Prototype',
      published_url: 'https://axiomzero-webspace-prototype.base44.app',
      entities: validEntityNames.map(n => ({ name: n, record_count: entityCounts[n] })),
      total_entities: validEntityNames.length,
      total_entity_records: Object.values(entityCounts).reduce((a: number, b: number) => a + (b > 0 ? b : 0), 0),
      secrets: KNOWN_SECRETS.map(s => ({ name: s.name, description: s.description })),
      connectors: [{ type: 'github', scopes: ['public_repo', 'read:user'] }],
      backend_functions: KNOWN_BACKEND_FUNCTIONS,
      backend_functions_count: KNOWN_BACKEND_FUNCTIONS.length,
      source_code: {
        included: !!sourceBundle,
        file_count: sourceFileCount,
        generated_at: sourceGeneratedAt,
        bundle_path: 'source/source_bundle.json',
        files_path: 'source/files/',
      },
    };

    // 4. Build the final ZIP
    const finalFiles: Record<string, Uint8Array> = {};

    // Entity schemas
    for (const [name, schema] of Object.entries(entitySchemas)) {
      finalFiles[`data/schemas/${name}.jsonc`] = strToU8(JSON.stringify(schema, null, 2));
    }

    // Entity data
    for (const [name, data] of Object.entries(entityExports)) {
      finalFiles[`data/entities/${name}.json`] = strToU8(JSON.stringify(data, null, 2));
    }

    // Source code — include as individual files + machine-readable JSON bundle
    if (sourceBundle && sourceBundle.files) {
      for (const [filePath, content] of Object.entries(sourceBundle.files)) {
        finalFiles[`source/files/${filePath}`] = strToU8(String(content));
      }
      // Also include the full JSON bundle (machine-readable format)
      finalFiles['source/source_bundle.json'] = strToU8(JSON.stringify({
        generated_at: sourceBundle.generated_at,
        app_name: sourceBundle.app_name,
        file_count: sourceBundle.file_count,
        files: sourceBundle.files,
      }, null, 2));
    }

    // Docs
    finalFiles['docs/DEPLOYMENT_MANIFEST.json'] = strToU8(JSON.stringify(deploymentManifest, null, 2));
    finalFiles['docs/MIGRATION.md'] = strToU8(generateMigrationMd(deploymentManifest));
    finalFiles['docs/SECRETS_MANIFEST.md'] = strToU8(generateSecretsMd());
    finalFiles['docs/DNS_DOMAINS.md'] = strToU8(generateDnsMd());
    finalFiles['migrate.sh'] = strToU8(generateMigrateScript());

    // 4. Zip
    const zipped = zipSync(finalFiles);

    // 5. Upload
    const blob = new Blob([zipped], { type: 'application/zip' });
    const file = new File([blob], 'axiomzero-webspace-seed.zip', { type: 'application/zip' });
    const uploadRes = await base44.integrations.Core.UploadPublicFile({ file });

    return Response.json({
      download_url: uploadRes.file_url,
      file_count: Object.keys(finalFiles).length,
      entity_counts: entityCounts,
      total_entities: validEntityNames.length,
      total_entity_records: deploymentManifest.total_entity_records,
      backend_functions_count: KNOWN_BACKEND_FUNCTIONS.length,
      source_code_included: !!sourceBundle,
      source_file_count: sourceFileCount,
      source_generated_at: sourceGeneratedAt,
      zip_size_mb: Math.round(zipped.length / 1048576 * 10) / 10,
      generated_at: generatedAt,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}