import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';
import { makeSource, okResponse, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';
import { fetchWithResilience } from '../../shared/resilientFetch.ts';

/**
 * courtListener — CourtListener v4 REST API fetcher.
 *
 * Token-gated (COURTLISTENER_API_TOKEN). No clean free no-auth court API exists,
 * so this keeps the token path as the primary tier and falls back to deep-link
 * sources (CourtListener public search + Google Scholar case law) when the token
 * is missing or rejected, with a clear 'token invalid — refresh in Secrets' state.
 *
 * Docs: https://www.courtlistener.com/api/rest/v4/
 */

const TYPE_META: Record<string, { label: string; source_type: string }> = {
  o: { label: 'Opinion', source_type: 'Federal/state court opinion' },
  r: { label: 'RECAP Docket', source_type: 'PACER docket / filing' },
  p: { label: 'Judge Profile', source_type: 'Judge personnel record' },
};

function deepLinkFallback(query: string, reason: string) {
  return [
    makeSource({
      title: `CourtListener — Search: "${query}"`,
      tier: 1,
      source_type: 'Case-law search portal (open in browser)',
      url_or_ref: `https://www.courtlistener.com/?q=${encodeURIComponent(query)}`,
      date: '',
      excerpt: `Pre-filled search of CourtListener's unified case-law, RECAP docket, and judge database. ${reason} Run the search in-browser and copy results here.`,
      raw_metadata: { portal: 'courtlistener.com', query, fallback: true },
    }),
    makeSource({
      title: `Google Scholar Case Law — "${query}"`,
      tier: 1,
      source_type: 'Case-law search (open in browser)',
      url_or_ref: `https://scholar.google.com/scholar_cases?q=${encodeURIComponent(query)}`,
      date: '',
      excerpt: `Google Scholar's case-law search across federal/state opinions. Open in-browser to find and copy relevant opinions.`,
      raw_metadata: { portal: 'scholar.google.com', query, fallback: true },
    }),
  ];
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'CourtListener', 'No query provided');

    const token = secrets.get('COURTLISTENER_API_TOKEN');
    if (!token) {
      return Response.json({
        sources: deepLinkFallback(query, 'COURTLISTENER_API_TOKEN not set — using public search.'),
        query, source_name: 'CourtListener', count: 2, status: 'degraded',
        tier: 'fallback', message: 'COURTLISTENER_API_TOKEN not set — configure it in Secrets to enable the API tier.',
      });
    }

    const headers = { Authorization: `Token ${token}` };
    const base = 'https://www.courtlistener.com/api/rest/v4/search/';
    const allSources: any[] = [];
    let lastErr = '';
    let authFailed = false;

    for (const [type, meta] of Object.entries(TYPE_META)) {
      try {
        const url = `${base}?q=${encodeURIComponent(query)}&type=${type}&order_by=score%20desc&page_size=10`;
        const res = await fetchWithResilience(url, { headers, retries: 1, timeoutMs: 12000, cacheTtl: 300000 });
        if (!res.data) { lastErr = res.error || `unavailable (${meta.label})`; if (res.error?.includes('401')) authFailed = true; continue; }
        const results = res.data.results || [];
        for (const r of results) {
          const absUrl = r.absolute_url ? `https://www.courtlistener.com${r.absolute_url}` : (r.url || '');
          allSources.push(makeSource({
            title: r.caseName || r.case_name || r.name || `${meta.label} — ${r.id || ''}`,
            tier: 1,
            source_type: meta.source_type,
            url_or_ref: absUrl,
            date: r.dateFiled || r.date_filed || r.date_created || '',
            excerpt: r.snippet || r.summary || (type === 'p' ? `Judge — ${r.court || ''}` : r.caseName || ''),
            raw_metadata: { ...r, cl_type: type, cl_type_label: meta.label, tier: 'token-premium' },
          }));
        }
      } catch (e) {
        lastErr = (e as Error).message;
      }
    }

    if (allSources.length === 0) {
      // Token present but rejected — fall back to deep links
      const reason = authFailed || (lastErr || '').includes('401')
        ? 'COURTLISTENER_API_TOKEN rejected as invalid/expired — refresh it in Secrets.'
        : `API unavailable (${lastErr}).`;
      return Response.json({
        sources: deepLinkFallback(query, reason),
        query, source_name: 'CourtListener', count: 2, status: 'degraded',
        tier: 'fallback', message: reason,
      });
    }
    return Response.json({ sources: allSources, query, source_name: 'CourtListener', count: allSources.length, status: 'ok', tier: 'token-premium' });
  } catch (error) {
    return errResponse('', 'CourtListener', (error as Error).message);
  }
}