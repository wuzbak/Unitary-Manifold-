import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { makeSource, okResponse, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';

/**
 * icijOffshore — ICIJ Offshore Leaks Database (offshoreleaks.icij.org).
 * Uses the OpenRefine Reconciliation API (POST /api/v1/reconcile) to match a name
 * against 810k+ offshore entities across the Panama, Pandora, Paradise, Bahamas, and
 * Offshore Leaks datasets. Results are tagged with their source dataset so the
 * journalist can scope to Paradise Papers etc.
 *
 * Docs: https://offshoreleaks.icij.org/docs/reconciliation
 *
 * Theory, methodology: ThomasCory Walker-Pearson / AxiomZero Technologies & Consulting, SPC.
 * Implementation: GitHub Copilot (AI).
 */

const TYPES = [
  { type: 'Officer', label: 'Officer / Person' },
  { type: 'Entity', label: 'Offshore Entity' },
  { type: 'Intermediary', label: 'Intermediary' },
];

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'ICIJ Offshore Leaks', 'No query provided');

    const allSources: any[] = [];
    let lastErr = '';
    for (const { type, label } of TYPES) {
      try {
        const res = await fetch('https://offshoreleaks.icij.org/api/v1/reconcile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'User-Agent': 'Mozilla/5.0 (AxiomZero-AXIOM-Journalist)' },
          body: JSON.stringify({ query, type, limit: 10 }),
        });
        if (!res.ok) { lastErr = `API ${res.status} (${label})`; continue; }
        const data = await res.json();
        const results = data.result || [];
        for (const r of results) {
          if (r.score !== undefined && r.score < 0.3) continue; // skip weak matches
          const nodeId = String(r.id || '');
          const typeNames = (r.type || []).map((t: any) => t.name || t.id || '').join(', ') || label;
          allSources.push(makeSource({
            title: `ICIJ Offshore: ${r.name || query} (${typeNames})`,
            tier: 2,
            source_type: `Offshore leak record — ${label} (Panama/Pandora/Paradise Papers)`,
            url_or_ref: nodeId ? `https://offshoreleaks.icij.org/nodes/${nodeId}` : '',
            date: '',
            excerpt: `Name: ${r.name || 'N/A'} · Type: ${typeNames} · Match score: ${r.score !== undefined ? r.score.toFixed(2) : 'N/A'}${r.match ? ' · EXACT MATCH' : ''}`,
            raw_metadata: { ...r, icij_type: type },
          }));
        }
      } catch (e) {
        lastErr = (e as Error).message;
      }
    }
    if (allSources.length === 0 && lastErr) return errResponse(query, 'ICIJ Offshore Leaks', lastErr);
    // Dedupe by name+type
    const seen = new Set<string>();
    const deduped = allSources.filter((s) => { const k = s.title; if (seen.has(k)) return false; seen.add(k); return true; });
    return okResponse(deduped, query, 'ICIJ Offshore Leaks');
  } catch (error) {
    return errResponse('', 'ICIJ Offshore Leaks', (error as Error).message);
  }
}