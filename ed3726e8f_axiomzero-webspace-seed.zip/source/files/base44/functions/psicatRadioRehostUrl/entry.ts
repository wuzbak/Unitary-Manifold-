import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { computeManifoldVersion } from '../../shared/manifoldVersionTimeline.ts';

/**
 * psicatRadioRehostUrl — permanently re-hosts a remote media URL onto this site.
 *
 * Flow:
 *   1. Frontend pastes a remote URL (mp3, aac, m4a, mp4, etc.)
 *   2. This function fetches the actual file bytes server-side
 *   3. Uploads the bytes to this site's permanent public storage via
 *      UploadPublicFile
 *   4. Catalogs the track as a PsiCatRadioTrack with:
 *        file_url  → this site's local copy (permanent, never depends on remote)
 *        source_url → the original external URL (provenance only)
 *   5. Returns the new track record
 *
 * Supports single-url and batch (urls[]) payloads.
 *
 * Size guard: rejects files larger than 100MB to avoid Worker memory limits.
 */
const MAX_BYTES = 100 * 1024 * 1024; // 100MB

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const items = Array.isArray(body.urls) ? body.urls : [body];

    const results = [];
    for (const item of items) {
      const url = item.url || item;
      const title = item.title || (typeof url === 'string' ? decodeURIComponent(url.split('/').pop().split('?')[0] || 'rehosted-track') : 'rehosted-track');
      const mediaType = item.media_type || 'audio';
      const durationSeconds = Number(item.duration_seconds) || 0;
      const sourceFolder = item.source_folder || '';

      if (!url || !/^https?:\/\//.test(url)) {
        results.push({ title, error: 'Missing or invalid URL' });
        continue;
      }

      try {
        // 1. Fetch the remote file bytes
        const fetchRes = await fetch(url, { redirect: 'follow' });
        if (!fetchRes.ok) {
          results.push({ title, error: `Fetch failed: ${fetchRes.status} ${fetchRes.statusText}` });
          continue;
        }

        const contentLength = Number(fetchRes.headers.get('content-length') || 0);
        if (contentLength > MAX_BYTES) {
          results.push({ title, error: `File too large (${(contentLength / 1048576).toFixed(1)}MB > 100MB limit)` });
          continue;
        }

        const blob = await fetchRes.blob();
        if (blob.size > MAX_BYTES) {
          results.push({ title, error: `File too large (${(blob.size / 1048576).toFixed(1)}MB > 100MB limit)` });
          continue;
        }

        // Derive a filename with extension from the URL or content-type
        const urlPath = url.split('?')[0].split('/').pop() || 'rehosted-track';
        const hasExt = /\.[a-z0-9]{2,4}$/i.test(urlPath);
        const ct = (fetchRes.headers.get('content-type') || '').split(';')[0].trim();
        let ext = urlPath.split('.').pop().toLowerCase();
        if (!hasExt || !['mp3','wav','ogg','m4a','flac','aac','opus','mp4','webm','mov','mkv'].includes(ext)) {
          ext = mediaType === 'video' ? 'mp4' : (ct.includes('mp4') ? 'mp4' : ct.includes('ogg') ? 'ogg' : ct.includes('aac') ? 'aac' : 'mp3');
        }
        const filename = `${title.replace(/[^a-z0-9_-]+/gi, '_').slice(0, 60)}.${ext}`;

        // 2. Upload to this site's permanent public storage
        const fileObj = new File([blob], filename, { type: blob.type || (mediaType === 'video' ? 'video/mp4' : 'audio/mpeg') });
        const uploadRes = await base44.integrations.Core.UploadPublicFile({ file: fileObj });
        const fileUrl = uploadRes.file_url;
        if (!fileUrl) {
          results.push({ title, error: 'Upload returned no file_url' });
          continue;
        }

        // 3. Try to get a creation date from Last-Modified header
        let dateCreated = '';
        const lastMod = fetchRes.headers.get('last-modified');
        if (lastMod) {
          const d = new Date(lastMod);
          if (!isNaN(d.getTime())) dateCreated = d.toISOString().split('T')[0];
        }

        // 4. Catalog as a PsiCatRadioTrack
        const manifoldVersion = computeManifoldVersion(dateCreated);
        const record = await base44.entities.PsiCatRadioTrack.create({
          title,
          media_type: mediaType,
          file_url: fileUrl,
          source_url: url,
          duration_seconds: durationSeconds,
          date_created: dateCreated,
          manifold_version: manifoldVersion,
          tags_json: '[]',
          source_folder: sourceFolder,
          notes: '',
          original_size_bytes: blob.size,
          quality_tier: 'rehosted',
        });

        results.push({ id: record.id, title, file_url: fileUrl, manifold_version: manifoldVersion, original_size_bytes: blob.size });
      } catch (e) {
        results.push({ title, error: e.message });
      }
    }

    return Response.json({ rehosted: results.length, tracks: results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}