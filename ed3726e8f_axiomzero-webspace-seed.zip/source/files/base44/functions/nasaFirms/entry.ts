/**
 * nasaFirms — proxies NASA FIRMS active-fire CSV (VIIRS_SNPP, last 24h, global).
 * Parses CSV to JSON points, capped at 1000 to bound payload. Requires NASA_API_KEY.
 * Public data proxy (no auth) — key kept server-side.
 */
import { secrets } from 'base44:runtime';
import { unavailableResponse } from '../../shared/degradedResponse.ts';

export default async function (req: Request): Promise<Response> {
  try {
    const key = secrets.get('FIRMS_MAP_KEY');
    if (!key) return unavailableResponse({ fires: [], count: 0, truncated: false }, 'missing-credentials', 'FIRMS_MAP_KEY not set — get a free MAP_KEY from https://firms.modaps.eosdis.nasa.gov/api/mapkey/');
    const url = `https://firms.modaps.eosdis.nasa.gov/api/area/csv/${key}/VIIRS_SNPP_NRT/world/1`;
    const res = await fetch(url, { headers: { 'User-Agent': 'AxiomZero/1.0' } });
    if (!res.ok) return unavailableResponse({ fires: [], count: 0, truncated: false }, 'unavailable', `FIRMS ${res.status}`);
    const csv = await res.text();
    const lines = csv.trim().split('\n');
    if (lines.length < 2) return Response.json({ fires: [], count: 0, truncated: false });
    const header = lines[0].split(',');
    const idx = (name: string) => header.indexOf(name);
    const latI = idx('latitude'), lonI = idx('longitude'), brI = idx('bright_ti4'),
      confI = idx('confidence'), dateI = idx('acq_date'), timeI = idx('acq_time'), satI = idx('satellite');
    const CAP = 1000;
    const fires: any[] = [];
    let truncated = false;
    for (let i = 1; i < lines.length; i++) {
      if (fires.length >= CAP) { truncated = true; break; }
      const cols = lines[i].split(',');
      const lat = parseFloat(cols[latI]);
      const lon = parseFloat(cols[lonI]);
      if (isNaN(lat) || isNaN(lon)) continue;
      fires.push({
        lat, lon,
        brightness: brI >= 0 ? parseFloat(cols[brI]) : null,
        confidence: confI >= 0 ? cols[confI] : '',
        acqDate: dateI >= 0 ? cols[dateI] : '',
        acqTime: timeI >= 0 ? cols[timeI] : '',
        satellite: satI >= 0 ? cols[satI] : '',
      });
    }
    return Response.json({ fires, count: fires.length, truncated });
  } catch (error) {
    return unavailableResponse({ fires: [], count: 0, truncated: false }, 'unavailable', (error as Error).message);
  }
}