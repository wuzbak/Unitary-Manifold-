/**
 * hardinessZone — USDA Hardiness Zone Lookup (Hybrid Authoritative System)
 *
 * Accepts { zip } or { lat, lon } and returns the USDA hardiness zone with
 * half-zone precision (e.g., 8b), frost dates, and growing season length.
 *
 * Three-tier lookup (via shared module):
 * 1. phzmapi.org (USDA 2023 PHZM zip-code API) — TRUSTED
 * 2. Open-Meteo historical temperature method (empirical 10-year avg) — EMPIRICAL
 * 3. Improved latitude model (fallback) — ESTIMATED
 *
 * Source: USDA ARS Plant Hardiness Zone Map (2023 edition) + PRISM Climate Group
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { unavailableResponse } from '../../shared/degradedResponse.ts';
import { lookupHardinessZone } from '../../shared/hardinessZoneLookup.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json();
    const { zip, lat, lon } = body;

    if (!zip && (lat == null || lon == null)) {
      return Response.json({ error: 'Provide { zip } or { lat, lon }' }, { status: 400 });
    }

    const result = await lookupHardinessZone({ zip, lat, lon });
    const year = new Date().getFullYear();

    return Response.json({
      zip: zip || null,
      lat,
      lon,
      zone: result.halfZone,
      zoneNum: result.zoneNum,
      halfZone: result.halfZone,
      zoneDescription: `USDA Hardiness Zone ${result.halfZone}`,
      tempRangeF: result.tempRangeF,
      tempRangeC: result.tempRangeC,
      avgExtremeMinC: result.avgExtremeMinC || null,
      avgExtremeMinF: result.avgExtremeMinF || null,
      yearsAnalyzed: result.yearsAnalyzed || null,
      frostDates: {
        lastSpring: `${year}-${result.frostDates.lastSpring}`,
        firstFall: `${year}-${result.frostDates.firstFall}`,
        growingDays: result.frostDates.growingDays,
        growingSeason: `${result.frostDates.growingDays} days`,
      },
      source: result.source,
      sourceTier: result.sourceTier,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return unavailableResponse({ zone: null, zoneNum: null, halfZone: null, frostDates: null, source: null }, 'unavailable', error.message);
  }
}