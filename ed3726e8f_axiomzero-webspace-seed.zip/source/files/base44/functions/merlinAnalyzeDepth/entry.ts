/**
 * merlinAnalyzeDepth — Adaptive reasoning depth telemetry analyzer.
 *
 * Addresses Merlin's open question: "What is the optimal threshold for
 * adaptive reasoning depth before diminishing returns?"
 *
 * This function reads depth-telemetry MerlinNotes (logged by the engine when
 * the adaptive depth controller uses >2 rounds) and computes:
 * - Total queries that used the adaptive controller
 * - Round distribution (how many queries used 3, 4, 5 rounds)
 * - Average rounds used
 * - Whether the current max (5) is optimal or should be adjusted
 *
 * The analysis uses the LLM to interpret the telemetry and generate
 * actionable recommendations for the optimal depth threshold.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Fetch depth-telemetry notes
    const notes = await base44.entities.MerlinNote.filter(
      { tags_json: { $regex: 'depth-telemetry' } },
      '-created_date',
      100
    ).catch(() => []);

    const telemetryNotes = (notes || []).filter(n => {
      try {
        const tags = JSON.parse(n.tags_json || '[]');
        return tags.includes('depth-telemetry');
      } catch { return false; }
    });

    // Parse telemetry data from note content
    const telemetryData = telemetryNotes.map(n => {
      try {
        return JSON.parse(n.content);
      } catch {
        return null;
      }
    }).filter(Boolean);

    // Compute statistics
    const totalQueries = telemetryData.length;
    const roundDistribution: Record<number, number> = {};
    let totalRounds = 0;
    let maxRoundsSeen = 0;
    let toolCallsTotal = 0;
    let successfulQueries = 0;
    let erroredQueries = 0;

    for (const entry of telemetryData) {
      const rounds = entry.rounds || 0;
      totalRounds += rounds;
      maxRoundsSeen = Math.max(maxRoundsSeen, rounds);
      roundDistribution[rounds] = (roundDistribution[rounds] || 0) + 1;
      if (entry.toolCalls) toolCallsTotal += entry.toolCalls;
      if (entry.outcome === 'success') successfulQueries++;
      if (entry.outcome === 'error') erroredQueries++;
    }

    const avgRounds = totalQueries > 0 ? totalRounds / totalQueries : 0;
    const successRate = totalQueries > 0 ? successfulQueries / totalQueries : 0;
    const errorRate = totalQueries > 0 ? erroredQueries / totalQueries : 0;

    // Compute diminishing returns: what % of queries needed 5 rounds vs 3-4?
    const queriesAtMax = roundDistribution[5] || 0;
    const queriesBelowMax = totalQueries - queriesAtMax;
    const maxUtilizationRate = totalQueries > 0 ? queriesAtMax / totalQueries : 0;

    // LLM analysis of the telemetry
    let analysis: any = null;
    if (totalQueries > 0) {
      const statsBlock = JSON.stringify({
        totalQueries,
        avgRounds: avgRounds.toFixed(2),
        maxRoundsSeen,
        roundDistribution,
        successRate: (successRate * 100).toFixed(1) + '%',
        errorRate: (errorRate * 100).toFixed(1) + '%',
        maxUtilizationRate: (maxUtilizationRate * 100).toFixed(1) + '%',
        toolCallsTotal,
        currentMax: 5,
      }, null, 2);

      const llmRes = await base44.integrations.Core.InvokeLLM({
        prompt: `You are analyzing the adaptive reasoning depth telemetry for Merlin, an AI navigator.
Here are the statistics from depth-telemetry logs (queries that used >2 rounds of the adaptive depth controller):

${statsBlock}

Analyze this data and answer: "What is the optimal threshold for adaptive reasoning depth before diminishing returns?"

Consider:
1. If maxUtilizationRate is high (>30%), the current max (5) may be too low — queries are hitting the ceiling.
2. If maxUtilizationRate is low (<10%), the current max (5) is sufficient — few queries need all 5 rounds.
3. If errorRate is high, the controller may be looping on failed tool calls.
4. If avgRounds is close to 3, the optimal threshold may be 3-4 (diminishing returns after that).
5. If avgRounds is close to 5, the optimal threshold may need to be higher (6-7).

Return a JSON object:
{
  "optimal_threshold": number (recommended max rounds),
  "confidence": number (0-1, how confident in this recommendation),
  "reasoning": "why this threshold is optimal",
  "diminishing_returns_analysis": "analysis of where diminishing returns begin",
  "recommendation": "actionable recommendation for the engine",
  "current_max_assessment": "whether the current max of 5 is too low, optimal, or too high"
}`,
        response_json_schema: {
          type: 'object',
          properties: {
            optimal_threshold: { type: 'number' },
            confidence: { type: 'number' },
            reasoning: { type: 'string' },
            diminishing_returns_analysis: { type: 'string' },
            recommendation: { type: 'string' },
            current_max_assessment: { type: 'string' },
          },
        },
      });
      analysis = llmRes;
    }

    return Response.json({
      status: 'analyzed',
      totalTelemetryEntries: totalQueries,
      statistics: {
        totalQueries,
        avgRounds: parseFloat(avgRounds.toFixed(2)),
        maxRoundsSeen,
        roundDistribution,
        successRate: parseFloat(successRate.toFixed(3)),
        errorRate: parseFloat(errorRate.toFixed(3)),
        maxUtilizationRate: parseFloat(maxUtilizationRate.toFixed(3)),
        toolCallsTotal,
        currentMax: 5,
      },
      analysis,
      message: totalQueries === 0
        ? 'No depth-telemetry data yet. The adaptive depth controller logs telemetry when queries use >2 rounds. Ask Merlin multi-step questions to generate data.'
        : `Analyzed ${totalQueries} telemetry entries. Optimal threshold recommendation: ${analysis?.optimal_threshold || 'insufficient data'}.`,
    });
  } catch (error) {
    return Response.json({
      status: 'unavailable',
      error: error.message,
    }, { status: 200 });
  }
}