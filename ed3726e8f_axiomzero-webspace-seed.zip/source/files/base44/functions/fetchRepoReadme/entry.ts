import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';

Deno.serve(async (req) => {
  try {
    // Public GitHub data — no auth required
    const response = await fetch('https://raw.githubusercontent.com/wuzbak/Unitary-Manifold-/main/README.md');
    if (!response.ok) return Response.json({ readme: '', isTruncated: false, fullLength: 0, status: 'unavailable', message: 'Failed to fetch README' }, { status: 200 });

    const fullReadme = await response.text();
    const maxChars = 30000;
    const truncated = fullReadme.slice(0, maxChars);
    const isTruncated = fullReadme.length > maxChars;

    return Response.json({
      readme: truncated,
      isTruncated,
      fullLength: fullReadme.length,
      repoUrl: 'https://github.com/wuzbak/Unitary-Manifold-',
      readmeUrl: 'https://github.com/wuzbak/Unitary-Manifold-/blob/main/README.md'
    });
  } catch (error) {
    return Response.json({ readme: '', isTruncated: false, fullLength: 0, status: 'unavailable', message: error.message }, { status: 200 });
  }
});