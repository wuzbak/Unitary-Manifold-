import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

/**
 * merlinAgentLoop — Server-side autonomous agent loop.
 *
 * Accepts a task + context + tool manifest, then loops:
 *   1. Call InvokeLLM with the task, accumulated context, and tool list
 *   2. LLM returns either { action: "call_tool", tool, args } or { action: "done", summary }
 *   3. If call_tool → invoke agentInvoke → add result to context → loop
 *   4. If done → return the summary + full action log
 *   5. Max iterations cap (default 8)
 *
 * This keeps tool execution server-side (authenticated, secrets protected).
 * The client-side MerlinAgentRunner component drives its own loop for live
 * streaming UX; this function is for programmatic / workflow use.
 *
 * Input: { task, context, tools, max_iterations?, model? }
 * Returns: { ok, summary, actions: [...], iterations, model }
 */
const MAX_ITERATIONS = 8;

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let body = {};
    try { body = await req.json(); } catch {}
    const { task, context = '', tools = [], max_iterations = MAX_ITERATIONS, model = 'claude_sonnet_4_6' } = body;

    if (!task) return Response.json({ error: 'task param required.' }, { status: 400 });
    const cap = Math.min(max_iterations, MAX_ITERATIONS);

    const toolList = tools.map(t => `- ${t.name}: ${t.desc || ''} | args: ${t.args || '{}'}`).join('\n');

    const actions = [];
    let accumulatedContext = context;
    let summary = '';
    let iterations = 0;

    for (let i = 0; i < cap; i++) {
      iterations++;
      const systemPrompt = `You are PsiCat (Merlin), an autonomous production agent. A user has assigned you a task. You have access to tools. Decide what tool to call, or if the task is complete.

AVAILABLE TOOLS:
${toolList}

RULES:
1. Call ONE tool per iteration. Choose the tool that makes the most progress.
2. After each tool result, decide if you need another tool or if you're done.
3. When the task is complete, return action: "done" with a summary of what you did.
4. If a tool fails, try an alternative approach or report the failure in your summary.
5. For entity creates, always include project_id if the task is project-scoped.
6. Be specific with tool args — use the exact field names from the tool description.

TASK: ${task}

CONTEXT:
${accumulatedContext}

PREVIOUS ACTIONS:
${actions.map((a, idx) => `${idx + 1}. ${a.tool} → ${a.ok ? 'OK' : 'FAILED: ' + (a.error || '').slice(0, 200)}`).join('\n') || 'None yet'}

Respond with JSON only.`;

      const llmRes = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt: systemPrompt,
        model,
        response_json_schema: {
          type: 'object',
          properties: {
            action: { type: 'string', enum: ['call_tool', 'done'] },
            tool: { type: 'string', description: 'Tool name to call' },
            args: { type: 'object', description: 'Arguments for the tool' },
            reasoning: { type: 'string', description: 'Why this tool / why done' },
            summary: { type: 'string', description: 'Final summary when action=done' },
          },
          required: ['action'],
        },
      });

      const decision = typeof llmRes === 'string' ? safeParse(llmRes) : llmRes;

      if (!decision || !decision.action) {
        summary = 'Agent could not determine next action. Task may be ambiguous.';
        break;
      }

      if (decision.action === 'done') {
        summary = decision.summary || decision.reasoning || 'Task complete.';
        break;
      }

      if (decision.action === 'call_tool' && decision.tool) {
        const toolStart = Date.now();
        let toolResult;
        try {
          const invokeRes = await base44.functions.invoke('agentInvoke', {
            tool: decision.tool,
            args: decision.args || {},
          });
          toolResult = invokeRes?.data || invokeRes;
        } catch (e) {
          toolResult = { ok: false, error: e.message };
        }
        const duration_ms = Date.now() - toolStart;
        const ok = toolResult?.ok !== false;
        const action = {
          iteration: i + 1,
          tool: decision.tool,
          args: decision.args || {},
          reasoning: decision.reasoning || '',
          ok,
          result: ok ? summarizeResult(toolResult?.result) : null,
          error: ok ? null : toolResult?.error,
          duration_ms,
        };
        actions.push(action);

        // Feed result back into context
        const resultStr = ok
          ? JSON.stringify(summarizeResult(toolResult?.result)).slice(0, 2000)
          : `Error: ${toolResult?.error}`;
        accumulatedContext += `\n\n[Tool ${decision.tool} result]: ${resultStr}`;
      }
    }

    if (!summary) {
      summary = `Reached max iterations (${cap}). ${actions.length} actions taken. Last: ${actions[actions.length - 1]?.tool || 'none'}`;
    }

    return Response.json({
      ok: true,
      summary,
      actions,
      iterations,
      model,
    });
  } catch (error) {
    return Response.json({ ok: false, error: error.message, summary: `Agent loop failed: ${error.message}`, actions: [], iterations: 0 }, { status: 200 });
  }
}

function summarizeResult(result) {
  if (!result) return null;
  if (Array.isArray(result)) return `[${result.length} items]`;
  if (typeof result === 'object') {
    // For entity records, return a compact summary
    if (result.id) {
      const { id, created_date, updated_date, created_by_id, ...fields } = result;
      const keys = Object.keys(fields).slice(0, 8);
      const compact = {};
      keys.forEach(k => {
        const v = fields[k];
        if (typeof v === 'string' && v.length > 200) compact[k] = v.slice(0, 200) + '…';
        else compact[k] = v;
      });
      return { id, ...compact };
    }
    return result;
  }
  return String(result).slice(0, 1000);
}

function safeParse(str) {
  try { return JSON.parse(str); } catch { return null; }
}