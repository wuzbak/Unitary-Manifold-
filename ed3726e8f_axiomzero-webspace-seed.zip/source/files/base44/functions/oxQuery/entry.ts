import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { secrets } from 'base44:runtime';
import { getTrimmedContext, getFullContext } from '../../shared/repoContext.ts';

const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';
const APP_REFERER = 'https://axiomzerospc.org';
const APP_TITLE = 'AxiomZero';

// Model selection per context tier.
// stealth/ox-alpha: 1M context, $0 pricing, supports structured output — used for both
// tiers because the OpenRouter account currently has no paid credits. ox-alpha is free.
// When credits are purchased, trimmed can switch to openai/gpt-4o-mini for lower latency.
const TIER_MODELS = {
  trimmed: 'stealth/ox-alpha',
  full: 'stealth/ox-alpha',
};

const EPISTEMIC_INSTRUCTIONS = `You are the Unitary Manifold physics reasoning engine, grounded in the live repository context provided below.

EPISTEMIC RULES (follow strictly):
1. Cite specific Pillar numbers (e.g., "Pillar 396") for every physics claim you make.
2. Use honest epistemic gate labels: HARDGATE, ADJACENT_TRACK, OPEN_GAP, ARCHITECTURE_LIMIT, DERIVED.
3. NEVER use "100% hardgate", "proven", or "confirmed" language. Use "derived", "predicted", "consistent with", or "awaits experimental test".
4. If the context does NOT contain the answer, say "Not found in framework context" — do NOT invent or confabulate.
5. Include σ tensions where relevant (e.g., "2.30σ tension with DESI DR2").
6. Flag ARCHITECTURE_LIMIT items honestly — these are known gaps, not failures.

OUTPUT FORMAT: Return a JSON object with this exact structure:
{
  "answer": "Your detailed physics answer (2-6 sentences)",
  "pillarCitations": [{ "pillar": 396, "claim": "r = 0.0315 braided prediction" }],
  "gateStatus": "HARDGATE | ADJACENT_TRACK | OPEN_GAP | ARCHITECTURE_LIMIT | DERIVED | NOT_FOUND",
  "confidence": 0.0-1.0,
  "caveat": "Epistemic caveat — what the user should know about this answer's certainty"
}`;

/**
 * oxQuery — Native OX-equivalent physics query layer.
 *
 * Replaces the undeployed /api/ox endpoint. Assembles context from the live
 * repository (two-tier: trimmed ~5k tokens or full ~85k tokens), sends to
 * OpenRouter with epistemic-grounding instructions, returns structured JSON.
 *
 * Input: { query, contextTier: 'trimmed'|'full', systemPromptPrefix? }
 * Output: { answer, pillarCitations[], gateStatus, confidence, caveat, model, contextTier }
 */
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { query, contextTier = 'trimmed', systemPromptPrefix = '' } = body;

    if (!query) return Response.json({ error: 'query is required' }, { status: 400 });

    const apiKey = secrets.get('OPENROUTER_API_KEY');
    if (!apiKey) return Response.json({ error: 'OPENROUTER_API_KEY not configured', status: 'missing-credentials', answer: 'AI backend not configured.', pillarCitations: [], gateStatus: 'NOT_FOUND', confidence: 0, caveat: 'OPENROUTER_API_KEY not configured' }, { status: 200 });

    // Assemble context based on tier
    const tier = contextTier === 'full' ? 'full' : 'trimmed';
    let context;
    try {
      context = tier === 'full' ? await getFullContext() : await getTrimmedContext();
    } catch {
      context = 'Framework context unavailable.';
    }

    const model = TIER_MODELS[tier];
    const systemPrompt = [
      systemPromptPrefix ? systemPromptPrefix + '\n' : '',
      EPISTEMIC_INSTRUCTIONS,
      '\n=== FRAMEWORK CONTEXT (live from repository) ===\n',
      context,
    ].join('\n');

    const payload = {
      model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: query },
      ],
      temperature: 0.3,
      max_tokens: 2000,
      response_format: { type: 'json_object' },
    };

    // 30s timeout via AbortController
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);

    let apiRes;
    try {
      apiRes = await fetch(OPENROUTER_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'HTTP-Referer': APP_REFERER,
          'X-Title': APP_TITLE,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });
    } catch (fetchError) {
      if (fetchError.name === 'AbortError') {
        return Response.json({ error: 'Request timed out after 30s', status: 'unavailable', answer: 'Request timed out.', pillarCitations: [], gateStatus: 'NOT_FOUND', confidence: 0, caveat: 'Request timed out after 30s' }, { status: 200 });
      }
      throw fetchError;
    } finally {
      clearTimeout(timeout);
    }

    if (!apiRes.ok) {
      const errData = await apiRes.json().catch(() => ({}));
      return Response.json(
        { error: errData?.error?.message || `OpenRouter returned ${apiRes.status}`, status: apiRes.status === 429 ? 'rate-limited' : 'unavailable', answer: 'AI backend error.', pillarCitations: [], gateStatus: 'NOT_FOUND', confidence: 0, caveat: errData?.error?.message || `OpenRouter returned ${apiRes.status}` },
        { status: 200 }
      );
    }

    const data = await apiRes.json();
    const content = data?.choices?.[0]?.message?.content || '';

    // Parse structured JSON from the LLM response
    let parsed;
    try {
      parsed = JSON.parse(content);
    } catch {
      parsed = {
        answer: content,
        pillarCitations: [],
        gateStatus: 'UNKNOWN',
        confidence: 0.5,
        caveat: 'Response was not structured JSON; rendered as plain text.',
      };
    }

    return Response.json({
      ...parsed,
      model: data?.model || model,
      contextTier: tier,
      usage: data?.usage || null,
    });
  } catch (error) {
    return Response.json({ error: error.message, status: 'unavailable', answer: 'Query failed.', pillarCitations: [], gateStatus: 'NOT_FOUND', confidence: 0, caveat: error.message }, { status: 200 });
  }
}