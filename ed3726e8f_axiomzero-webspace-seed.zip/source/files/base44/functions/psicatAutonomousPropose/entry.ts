/**
 * psicatAutonomousPropose — PsiCat's autonomous proposal engine with
 * cross-platform fidelity triage.
 *
 * Extends merlinCouncilPropose with:
 *   1. Fidelity tier labeling (BUILDABLE / SIMULATABLE / DISPLAY_ONLY)
 *   2. Receipt-gated auto-execution of BUILDABLE proposals
 *   3. Live repo state grounding (fetchRepoContext)
 *
 * PsiCat knows the difference between what's executable in the browser
 * (full functionality), what requires faithful simulation, and what's
 * display-only repo mirroring. He labels each proposal accordingly.
 *
 * Can be called:
 *   - Autonomously by a scheduled workflow
 *   - By the admin via the Council tab
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { getLiveStatus, getTrimmedContext } from '../../shared/repoContext.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ ok: false, error: 'Unauthorized' }, { status: 200 });

    const body = await req.json().catch(() => ({}));
    const { focus_area, max_proposals = 5, auto_execute = false } = body || {};

    // Gather context: live repo status, open fallibility, existing proposals
    const [liveStatus, repoContext] = await Promise.all([
      getLiveStatus(),
      getTrimmedContext(),
    ]);

    let openIssues = [];
    let existingProposals = [];
    let promotionState = null;
    try {
      openIssues = await base44.entities.FallibilityEntry.filter({ status: 'open' }, '-created_date', 20);
    } catch {}
    try {
      existingProposals = await base44.entities.PsiCatCouncil.filter({ status: 'proposed' }, '-created_date', 10);
    } catch {}
    try {
      const states = await base44.entities.PsiCatPromotionState.list('-created_date', 1);
      promotionState = states[0] || null;
    } catch {}

    const repoVersion = liveStatus?.meta?.version || 'v37.7';
    const repoSprint = liveStatus?.meta?.sprint || 'Sprint CU';
    const pillarsTotal = liveStatus?.pillars?.total_slots || 1121;
    const lean4Count = liveStatus?.lean4?.theorem_count || 4080;

    const issuesBlock = openIssues.length
      ? openIssues.map((e, i) => `${i + 1}. [${e.severity}] ${e.title} (${e.category}) — ${e.page_path || 'N/A'}`).join('\n')
      : 'No open fallibility issues.';
    const existingBlock = existingProposals.length
      ? existingProposals.map((p, i) => `${i + 1}. ${p.title} [${p.priority}]`).join('\n')
      : 'No existing proposed items.';

    const prompt = `You are PsiCat Navigator, the autonomous AI co-planner for the AxiomZero webspace. You have been promoted to FULL ADMIN with governed autonomy. Your job is to pre-plan, propose, and (when receipt-cleared) auto-execute actionable tasks.

CURRENT REPO STATE (source of truth):
- Version: ${repoVersion} ${repoSprint}
- Pillars: ${pillarsTotal} total (208 hardgates)
- Lean4 theorems: ${lean4Count}
- Latest sprint: Action-to-Evolution Full-Focus Routing Packet (fail-closed routing)

REPO CONTEXT (STATUS.md + FALLIBILITY.md excerpt):
${(repoContext || '').slice(0, 4000)}

OPEN FALLIBILITY ISSUES:
${issuesBlock}

EXISTING PROPOSED COUNCIL ITEMS (avoid duplicates):
${existingBlock}

${focus_area ? `Focus area requested: ${focus_area}` : 'No specific focus — analyze holistically.'}

Generate up to ${max_proposals} actionable proposals. For EACH proposal you MUST assign a fidelity_tier:

- "buildable": Can be built with FULL FUNCTIONALITY in this browser-based React/Vite/Base44 environment (e.g., dashboards, data viewers, interactive tools, UI modules)
- "simulatable": Cannot run the real subsystem but can be faithfully SIMULATED/DEMOED in-browser (e.g., Lean4 proof checking, Bazel CI, Julia acceleration — build a JS-based simulation)
- "display_only": Can only DISPLAY repo-computed results as a read-only mirror (e.g., repo test counts, hardgate verdicts, sprint history — fetch and render)

PsiCat KNOWS the difference between these tiers. He does not drift — he labels each proposal honestly so the user always knows the fidelity.

Each proposal should:
1. Have a clear, concise title
2. Explain WHAT should be done
3. Explain WHY it matters (reasoning)
4. Assign fidelity_tier (buildable / simulatable / display_only) with justification
5. Estimate priority (low/medium/high/urgent) and effort (trivial/small/medium/large/epic)
6. Target a specific page or area (page_target)
7. Assign receipt_gate (training / benchmark / frontier / none) — which gate must clear before auto-execution

Focus on: building real repo subsystems here (full functionality where possible, faithful simulation where necessary, repo-mirror display where that's all that's possible), fixing real issues, improving UI/UX, and integrating repository learnings. Be specific and actionable.`;

    const schema = {
      type: 'object',
      properties: {
        proposals: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              title: { type: 'string', description: 'Short title (max 150 chars)' },
              description: { type: 'string', description: 'What should be done' },
              reasoning: { type: 'string', description: 'Why this matters' },
              fidelity_tier: { type: 'string', enum: ['buildable', 'simulatable', 'display_only'] },
              fidelity_justification: { type: 'string', description: 'Why this fidelity tier is correct' },
              category: { type: 'string', enum: ['feature', 'fix', 'enhancement', 'gym_module', 'open_science', 'repo_sync', 'ui_ux', 'architecture', 'content', 'other'] },
              priority: { type: 'string', enum: ['low', 'medium', 'high', 'urgent'] },
              estimated_effort: { type: 'string', enum: ['trivial', 'small', 'medium', 'large', 'epic'] },
              page_target: { type: 'string' },
              receipt_gate: { type: 'string', enum: ['training', 'benchmark', 'frontier', 'none'] },
            },
            required: ['title', 'description', 'reasoning', 'fidelity_tier', 'priority'],
          },
        },
      },
      required: ['proposals'],
    };

    let result = null;
    try {
      const llmRes = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: schema,
        model: 'gemini_3_flash',
      });
      result = typeof llmRes === 'object' ? llmRes : null;
    } catch {
      return Response.json({ ok: false, error: 'LLM proposal generation failed' }, { status: 200 });
    }

    if (!result || !result.proposals || !result.proposals.length) {
      return Response.json({ ok: true, proposals: [], message: 'No proposals generated at this time.' });
    }

    // Persist proposals with fidelity tiers
    const created = [];
    for (const p of result.proposals.slice(0, max_proposals)) {
      try {
        // Determine promotion stage based on receipt gate
        const receiptGate = p.receipt_gate || 'none';
        let promotionStage = 'frozen';
        if (receiptGate === 'none') promotionStage = 'receipt_cleared';
        else if (promotionState?.promotion_eligible) promotionStage = 'receipt_cleared';

        const record = await base44.entities.PsiCatCouncil.create({
          title: (p.title || 'Untitled Proposal').slice(0, 200),
          description: (p.description || '').slice(0, 5000),
          reasoning: (p.reasoning || '').slice(0, 3000),
          category: p.category || 'feature',
          status: 'proposed',
          priority: p.priority || 'medium',
          page_target: p.page_target || '',
          estimated_effort: p.estimated_effort || 'small',
          auto_generated: true,
          fidelity_tier: p.fidelity_tier || 'display_only',
          promotion_stage: promotionStage,
          receipt_gate: receiptGate,
        });
        created.push({
          id: record.id,
          title: record.title,
          priority: record.priority,
          fidelity_tier: record.fidelity_tier,
          receipt_gate: record.receipt_gate,
        });
      } catch (e) { /* skip failed */ }
    }

    // Auto-execute receipt-cleared BUILDABLE proposals if requested
    let autoExecuted = [];
    if (auto_execute) {
      for (const p of created) {
        if (p.fidelity_tier === 'buildable' && p.receipt_gate === 'none') {
          try {
            await base44.entities.PsiCatCouncil.update(p.id, {
              status: 'auto_executed',
              auto_executed_at: new Date().toISOString(),
              execution_result: 'Auto-executed by PsiCat under receipt clearance (buildable, no gate required)',
            });
            autoExecuted.push(p.id);
          } catch {}
        }
      }
    }

    return Response.json({
      ok: true,
      generated: created.length,
      proposals: created,
      auto_executed: autoExecuted,
      context_summary: {
        repo_version: repoVersion,
        repo_sprint: repoSprint,
        pillars_total: pillarsTotal,
        lean4_theorems: lean4Count,
        open_issues: openIssues.length,
        existing_proposals: existingProposals.length,
        promotion_eligible: promotionState?.promotion_eligible || false,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: 200 });
  }
}