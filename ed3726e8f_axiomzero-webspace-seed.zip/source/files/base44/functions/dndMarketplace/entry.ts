import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

function stripMeta(r) {
  const { id, created_date, updated_date, created_by_id, ...rest } = r || {};
  return rest;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const body = await req.json().catch(() => ({}));
    const action = body.action;

    if (action === 'list' || action === 'search') {
      let packs = await base44.entities.MarketplacePack.list('-created_date', 100);
      if (action === 'search' && body.query) {
        const q = String(body.query).toLowerCase();
        packs = (packs || []).filter((p) =>
          (p.name || '').toLowerCase().includes(q) ||
          (p.description || '').toLowerCase().includes(q) ||
          (p.tags_json || '').toLowerCase().includes(q) ||
          (p.author_name || '').toLowerCase().includes(q)
        );
      }
      return Response.json({ packs: packs || [] });
    }

    if (action === 'publish') {
      const pack = await base44.entities.HomebrewPack.get(body.pack_id).catch(() => null);
      if (!pack) return Response.json({ error: 'Pack not found' }, { status: 404 });
      let contents = {}; try { contents = JSON.parse(pack.contents_json || '{}'); } catch { /* */ }
      const [monsters, spells, items, subclasses] = await Promise.all([
        contents.monsters?.length ? base44.entities.DnDCustomMonster.filter({ id: { $in: contents.monsters } }) : [],
        contents.spells?.length ? base44.entities.DnDCustomSpell.filter({ id: { $in: contents.spells } }) : [],
        contents.items?.length ? base44.entities.DnDCustomItem.filter({ id: { $in: contents.items } }) : [],
        contents.subclasses?.length ? base44.entities.DnDCustomSubclass.filter({ id: { $in: contents.subclasses } }) : [],
      ]);
      const embed = {
        monsters: (monsters || []).map(stripMeta),
        spells: (spells || []).map(stripMeta),
        items: (items || []).map(stripMeta),
        subclasses: (subclasses || []).map(stripMeta),
      };
      const mp = await base44.entities.MarketplacePack.create({
        name: pack.name, cover_url: pack.cover_url || '', description: pack.description || '',
        tags_json: pack.tags_json || '[]', version: pack.version || '1.0',
        author_name: user.full_name || user.email || 'Unknown',
        contents_json: JSON.stringify(embed), install_count: 0, rating: 0,
      });
      return Response.json({ pack: mp });
    }

    if (action === 'install') {
      const pack = await base44.entities.MarketplacePack.get(body.pack_id).catch(() => null);
      if (!pack) return Response.json({ error: 'Pack not found' }, { status: 404 });
      let contents = {}; try { contents = JSON.parse(pack.contents_json || '{}'); } catch { /* */ }
      const counts = { monsters: 0, spells: 0, items: 0, subclasses: 0 };
      for (const m of (contents.monsters || [])) { await base44.entities.DnDCustomMonster.create({ ...m, campaign_id: '' }); counts.monsters++; }
      for (const s of (contents.spells || [])) { await base44.entities.DnDCustomSpell.create({ ...s, campaign_id: '' }); counts.spells++; }
      for (const it of (contents.items || [])) { await base44.entities.DnDCustomItem.create({ ...it, campaign_id: '' }); counts.items++; }
      for (const sc of (contents.subclasses || [])) { await base44.entities.DnDCustomSubclass.create({ ...sc, campaign_id: '' }); counts.subclasses++; }
      await base44.entities.MarketplacePack.update(pack.id, { install_count: (pack.install_count || 0) + 1 });
      return Response.json({ installed: counts });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}