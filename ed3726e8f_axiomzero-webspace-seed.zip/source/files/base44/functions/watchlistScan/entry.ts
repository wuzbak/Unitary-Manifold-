import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { secrets } from 'base44:runtime';

/**
 * watchlistScan — server-side watchlist monitor.
 * Reads all active WatchlistEntry records, queries the configured enforcement databases
 * for each, and creates WatchlistHit records for new enforcement actions.
 * Invoked by the scheduled WatchlistMonitor workflow (and manually from the Watchlist tab).
 *
 * Only keyless databases are queried server-side (EPA ECHO, OpenSanctions). SEC EDGAR
 * requires a contact-email secret; if configured later it can be added back. The
 * client-side manual scan can still attempt SEC via the secEdgar fetcher.
 *
 * Theory, methodology: ThomasCory Walker-Pearson / AxiomZero Technologies & Consulting, SPC.
 * Implementation: GitHub Copilot (AI).
 */

const DB_FETCHERS: Record<string, { url: (q: string) => string, tier: number, source_name: string, map: (r: any) => any }> = {
  echoEpa: {
    url: (q) => `https://ofmpub.epa.gov/echo/rest_services/rest_services.get_facilities?output=JSON&search=${encodeURIComponent(q)}`,
    tier: 1, source_name: 'EPA Penalties',
    map: (r) => ({ title: `EPA ECHO: ${r.Name || r.SourceID || ''}`, url: r.RegistryID ? `https://echo.epa.gov/detailed-facility-results?fid=${r.RegistryID}` : '', excerpt: `Facility ${r.Name || ''} · Qtrs in non-compliance: ${r.QtrsInNC || 'N/A'}` }),
  },
  openSanctions: {
    url: (q) => { const key = secrets.get('OPENSANCTIONS_API_KEY') || ''; return `https://api.opensanctions.org/search/default?q=${encodeURIComponent(q)}&limit=5${key ? `&api_key=${encodeURIComponent(key)}` : ''}`; },
    tier: 1, source_name: 'Sanctions',
    map: (r) => { const p = r.properties || r; return { title: `Sanctions: ${p.name || r.caption || ''}`, url: r.id ? `https://opensanctions.org/entities/${r.id}/` : '', excerpt: `Match ${p.name || ''} · ${(p.topics || []).join(', ')}` }; },
  },
};

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const svc = base44.asServiceRole;
    const entries = await svc.entities.WatchlistEntry.filter({ active: true });
    let totalHits = 0;
    const scanned: any[] = [];
    for (const entry of entries) {
      const dbs: string[] = (() => { try { return JSON.parse(entry.monitored_databases_json || '[]'); } catch { return ['echoEpa', 'openSanctions']; } })();
      const name = entry.entity_name;
      for (const dbId of dbs) {
        const fetcher = DB_FETCHERS[dbId];
        if (!fetcher) { scanned.push({ entity: name, db: dbId, status: 'skipped', reason: 'not configured server-side' }); continue; }
        try {
          const res = await fetch(fetcher.url(name), { headers: { Accept: 'application/json' } });
          if (!res.ok) { scanned.push({ entity: name, db: dbId, status: 'error', code: res.status }); continue; }
          const data = await res.json();
          const rows = (dbId === 'echoEpa') ? ((data.Results && data.Results.Facilities) || []) : (data.results || []);
          let count = 0;
          for (const row of rows.slice(0, 3)) {
            const mapped = fetcher.map(row);
            try {
              await svc.entities.WatchlistHit.create({
                watchlist_name: name, database: fetcher.source_name, record_ref: mapped.url || '',
                summary: mapped.excerpt || mapped.title, detected_date: new Date().toISOString(), promoted: false,
              });
              count++; totalHits++;
            } catch { /* skip duplicate/failed hit */ }
          }
          scanned.push({ entity: name, db: dbId, status: 'ok', hits: count });
        } catch (e) {
          scanned.push({ entity: name, db: dbId, status: 'error', error: (e as Error).message });
        }
      }
    }
    return Response.json({ ok: true, scanned_entries: entries.length, total_hits: totalHits, details: scanned });
  } catch (error) {
    return Response.json({ ok: false, scanned_entries: 0, total_hits: 0, details: [], status: 'unavailable', message: (error as Error).message }, { status: 200 });
  }
}