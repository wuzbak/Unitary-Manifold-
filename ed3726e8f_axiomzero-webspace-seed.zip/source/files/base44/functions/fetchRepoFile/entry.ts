import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';

Deno.serve(async (req) => {
  try {
    // Public GitHub data — no auth required
    let body = {};
    try { body = await req.json(); } catch (e) {}
    const filePath = body.path;
    if (!filePath) return Response.json({ error: 'Path required' }, { status: 400 });

    const response = await fetch(`https://raw.githubusercontent.com/wuzbak/Unitary-Manifold-/main/${filePath}`, {
      headers: { 'User-Agent': 'AxiomZero-App' }
    });

    if (!response.ok) return Response.json({ path: filePath, content: '', isTruncated: false, fullLength: 0, status: 'unavailable', message: `Failed to fetch file: ${response.status}` }, { status: 200 });

    const content = await response.text();
    // No truncation for articles/manuscripts in 7-OUTREACH — render fully
    const isArticle = filePath.startsWith('7-OUTREACH/');
    const maxChars = isArticle ? 500000 : 50000;
    const isTruncated = content.length > maxChars;
    const truncated = content.slice(0, maxChars);

    return Response.json({ path: filePath, content: truncated, isTruncated, fullLength: content.length });
  } catch (error) {
    return Response.json({ path: '', content: '', isTruncated: false, fullLength: 0, status: 'unavailable', message: error.message }, { status: 200 });
  }
});