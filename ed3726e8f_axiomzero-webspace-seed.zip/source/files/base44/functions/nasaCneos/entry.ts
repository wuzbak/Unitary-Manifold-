/**
 * nasaCneos — proxies NASA NeoWS (CNEOS) near-earth object feed for the last 3
 * days. Returns NEOs with close-approach data + hazardous flag.
 * Requires NASA_API_KEY. Public data proxy (no auth).
 */
import { secrets } from 'base44:runtime';
import { unavailableResponse } from '../../shared/degradedResponse.ts';

function daysAgo(n: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - n);
  return d.toISOString().slice(0, 10);
}
function today(): string {
  return new Date().toISOString().slice(0, 10);
}

export default async function (req: Request): Promise<Response> {
  try {
    const key = secrets.get('NASA_API_KEY');
    if (!key) return unavailableResponse({ neos: [], count: 0 }, 'missing-credentials', 'NASA_API_KEY not set');
    const url = `https://api.nasa.gov/neo/rest/v1/feed?start_date=${daysAgo(3)}&end_date=${today()}&api_key=${key}`;
    const res = await fetch(url, { headers: { 'User-Agent': 'AxiomZero/1.0' } });
    if (!res.ok) return unavailableResponse({ neos: [], count: 0 }, 'unavailable', `CNEOS ${res.status}`);
    const data = await res.json();
    const neos: any[] = [];
    const byDate = data.near_earth_objects || {};
    for (const date of Object.keys(byDate)) {
      for (const neo of byDate[date]) {
        const approach = neo.close_approach_data && neo.close_approach_data[0];
        if (!approach) continue;
        neos.push({
          id: neo.id,
          name: neo.name,
          hazardous: neo.is_potentially_hazardous_asteroid,
          diameter: neo.estimated_diameter && neo.estimated_diameter.kilometers
            ? neo.estimated_diameter.kilometers.estimated_diameter_max : null,
          velocity: approach.relative_velocity ? approach.relative_velocity.kilometers_per_hour : null,
          missDistance: approach.miss_distance ? approach.miss_distance.kilometers : null,
          approachDate: approach.close_approach_date,
        });
      }
    }
    return Response.json({ neos, count: neos.length });
  } catch (error) {
    return unavailableResponse({ neos: [], count: 0 }, 'unavailable', (error as Error).message);
  }
}