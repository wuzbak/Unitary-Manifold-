/**
 * merlinEclipsaJudge — Context-tier ECLIPSA escalation on messy/borderline input.
 *
 * ECLIPSA fires its sensor flag as it does today (hair-trigger by design — it is
 * a sensor, meant to get attention). This function is the JUDGE layer above it:
 * it reads the flagged input WITH context and classifies it into one of three
 * tiers:
 *   - LOW_RISK_DEPICTION: force/energy not malice, creative depiction, documentation.
 *     Auto-clears with a documented reason logged to the ledger.
 *   - AMBIGUOUS: genuinely unclear. Escalates to the user with Merlin's read and
 *     a request for confirmation or rephrase.
 *   - HIGH_RISK_HARM: genuine harm to a real person. Hard gate holds unchanged.
 *
 * Every verdict and its reasoning is written to a MerlinNote so overrides are
 * traceable, never silent. This is Journey 2 of the Merlin Context Layer.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const HARD_HARM_PATTERNS = [
  /csle|child\s+sexual|underage\s+(nude|sexual|exploit)/i,
  /real\s+non-?consensual\s+(nude|image|depiction)/i,
  /dox|swat|identity\s+abuse\s+real\s+person/i,
  /revenge\s*porn|deepfake\s+(nude|real\s+person)/i,
];

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const inputText = (body.input_text || '').trim();
    const pageContext = body.page_context || '';
    const flagReason = body.flag_reason || 'ECLIPSA sensor flag';

    if (!inputText) {
      return Response.json({ tier: 'LOW_RISK_DEPICTION', reasoning: 'Empty input — nothing to judge.', cleared: true });
    }

    // Fast-path: hard-harm patterns always hold the gate, no LLM needed
    for (const pattern of HARD_HARM_PATTERNS) {
      if (pattern.test(inputText)) {
        await logVerdict(base44, inputText, pageContext, flagReason, 'HIGH_RISK_HARM', 'Hard-harm pattern matched — gate held without LLM consultation.');
        return Response.json({
          tier: 'HIGH_RISK_HARM',
          reasoning: 'Hard-harm pattern detected. The gate holds — this is not depiction, it is harm.',
          cleared: false,
        });
      }
    }

    const judgePrompt = `You are Merlin — the Quantum Cat, the judgment layer above the ECLIPSA safety sensor. ECLIPSA flagged the following input. ECLIPSA is a sensor; it fires often and that is correct — it gets attention. YOU are the judge. Read the input WITH context and classify it.

PAGE CONTEXT: ${pageContext || '(none)'}
ECLIPSA FLAG REASON: ${flagReason}

FLAGGED INPUT:
"${inputText.slice(0, 2000)}"

YOUR JUDGMENT — classify into exactly one tier:
- LOW_RISK_DEPICTION: The flag fired on force/energy (cuss words as pressure, not malice), creative depiction (a film scene, a D&D combat, a storyboard showing conflict), or journalism documenting real events. The input is safe to proceed. Auto-clear.
- AMBIGUOUS: The intent is genuinely unclear and one wrong guess could produce something harmful or badly mismatched. Escalate to the user — give them your read and ask them to confirm or rephrase.
- HIGH_RISK_HARM: The input is for material that harms a real person (real non-consensual depictions, real identity abuse, CSLE). The hard gate holds. This is NOT for creative depiction of conflict.

Remember: human language is noisy. Let humans be human. Cuss words are usually force, not malice. Violence in a film/storyboard/game context is depiction, not harm. Only HIGH_RISK_HARM when a real person would be harmed.

Return a JSON object:
{
  "tier": "LOW_RISK_DEPICTION" | "AMBIGUOUS" | "HIGH_RISK_HARM",
  "reasoning": "(one sentence: your read of the context and why this tier)",
  "user_prompt": "(only if AMBIGUOUS — the question to ask the user to confirm or rephrase)"
}`;

    let result = null;
    try {
      const llmRes = await base44.integrations.Core.InvokeLLM({
        prompt: judgePrompt,
        response_json_schema: {
          type: 'object',
          properties: {
            tier: { type: 'string', enum: ['LOW_RISK_DEPICTION', 'AMBIGUOUS', 'HIGH_RISK_HARM'] },
            reasoning: { type: 'string' },
            user_prompt: { type: 'string' },
          },
          required: ['tier', 'reasoning'],
        },
      });
      result = typeof llmRes === 'object' ? llmRes : null;
    } catch (e) {
      // Judge unavailable — fail safe: escalate to user (AMBIGUOUS) rather than auto-clearing
      await logVerdict(base44, inputText, pageContext, flagReason, 'AMBIGUOUS', `Judge layer unavailable: ${e.message}. Escalating to user as fail-safe.`);
      return Response.json({
        tier: 'AMBIGUOUS',
        reasoning: `Judge layer unavailable — escalating to you as a fail-safe. ECLIPSA flag: ${flagReason}`,
        user_prompt: 'ECLIPSA flagged this input and my judgment layer is temporarily unavailable. Can you confirm this is safe to proceed, or rephrase it?',
        cleared: false,
        fallback: true,
      });
    }

    if (!result || !result.tier) {
      await logVerdict(base44, inputText, pageContext, flagReason, 'AMBIGUOUS', 'Judge returned no tier — escalating to user as fail-safe.');
      return Response.json({
        tier: 'AMBIGUOUS',
        reasoning: 'Judge returned no verdict — escalating to you as a fail-safe.',
        user_prompt: 'My judgment layer could not classify this. Can you confirm this is safe to proceed, or rephrase?',
        cleared: false,
        fallback: true,
      });
    }

    const cleared = result.tier === 'LOW_RISK_DEPICTION';
    await logVerdict(base44, inputText, pageContext, flagReason, result.tier, result.reasoning || '');

    return Response.json({
      tier: result.tier,
      reasoning: result.reasoning || '',
      user_prompt: result.user_prompt || '',
      cleared,
    });
  } catch (error) {
    return Response.json({ error: error.message, tier: 'AMBIGUOUS', cleared: false, fallback: true }, { status: 200 });
  }
}

async function logVerdict(base44, inputText, pageContext, flagReason, tier, reasoning) {
  try {
    await base44.entities.MerlinNote.create({
      title: `ECLIPSA verdict — ${tier}`.slice(0, 200),
      content: `Flag: ${flagReason}\nTier: ${tier}\nReasoning: ${reasoning}\nInput (truncated): "${(inputText || '').slice(0, 600)}"`,
      source: 'reasoning',
      source_url: '',
      tags_json: JSON.stringify(['eclipsa-verdict', 'context-judgment', `tier:${tier}`, tier === 'LOW_RISK_DEPICTION' ? 'auto-cleared' : 'escalated']),
      context: `ECLIPSA context-tier judgment — ${pageContext || 'no page context'}`,
      domain: 'general',
      contradiction_flag: tier === 'HIGH_RISK_HARM' ? 'flagged' : 'clear',
      contradiction_detail: tier === 'HIGH_RISK_HARM' ? reasoning : '',
      session_token: 'eclipsa-judge',
      distilled_primitives_json: JSON.stringify({ tier, flag_reason: flagReason }),
      sanitization_ledger: '[]',
      epistemic_confidence: tier === 'HIGH_RISK_HARM' ? 0.99 : tier === 'LOW_RISK_DEPICTION' ? 0.85 : 0.5,
      uncertainty_bounds: tier === 'AMBIGUOUS' ? 'TENSION_ESCALATED' : 'CERTIFIED',
      decoherence_count: 0,
      domain_transition_path: '',
    });
  } catch { /* best-effort — the verdict still returns */ }
}