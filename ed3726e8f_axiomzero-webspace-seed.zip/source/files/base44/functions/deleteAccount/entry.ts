import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

/**
 * deleteAccount — permanently deletes the calling user's own account.
 * Uses the service role to remove the User record (admin-level operation).
 * Only ever acts on the authenticated caller — never on another user.
 */
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Delete the caller's own user record via the service role.
    await base44.asServiceRole.entities.User.delete(user.id);

    return Response.json({ ok: true, deletedUserId: user.id });
  } catch (error) {
    return Response.json({ ok: false, status: 'unavailable', message: error.message || 'Failed to delete account' }, { status: 200 });
  }
}