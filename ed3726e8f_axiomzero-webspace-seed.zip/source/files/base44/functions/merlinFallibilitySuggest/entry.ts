/**
 * merlinFallibilitySuggest — PsiCat's suggestion engine for FallibilityEntry issues.
 *
 * Takes a FallibilityEntry and returns PsiCat's suggestion via InvokeLLM:
 *   - fix_approach: how to fix it (with steps)
 *   - wont_fix: why it's not worth fixing
 *   - not_an_issue: why this is expected behavior, not a bug
 *
 * Also stores the suggestion in the FallibilityEntry's resolution_notes field
 * so the administrator sees it in the ledger.
 *
 * Called when a new issue is created or when the administrator requests a suggestion.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ ok: false, error: 'Unauthorized' }, { status: 200 });

    const body = await req.json();
    const { entry_id, title, description, category, severity, page_path, component } = body || {};

    if (!title) {
      return Response.json({ ok: false, error: 'title is required' }, { status: 200 });
    }

    // If entry_id provided, fetch the full entry
    let entry = body;
    if (entry_id) {
      try {
        entry = await base44.entities.FallibilityEntry.get(entry_id);
      } catch { /* use passed body */ }
    }

    const prompt = `You are PsiCat Navigator, the AI assistant for the AxiomZero webspace. A fallibility issue has been logged and you need to provide a suggestion for how to address it.

ISSUE DETAILS:
- Title: ${entry.title || title}
- Category: ${entry.category || category || 'other'}
- Severity: ${entry.severity || severity || 'warning'}
- Page: ${entry.page_path || page_path || 'N/A'}
- Component: ${entry.component || component || 'N/A'}
- Description: ${entry.description || description || 'No description provided'}

Analyze this issue and provide your suggestion. Choose one of three verdicts:
1. "fix" — This is a real issue that should be fixed. Provide a concrete approach.
2. "wont_fix" — This is known/accepted and not worth fixing. Explain why.
3. "not_an_issue" — This is expected behavior, not a bug. Explain why it's correct.

Respond as PsiCat — concise, honest, with receipts. Include a suggested priority and estimated effort if it's a fix.`;

    const schema = {
      type: 'object',
      properties: {
        verdict: { type: 'string', enum: ['fix', 'wont_fix', 'not_an_issue'] },
        suggestion: { type: 'string', description: 'PsiCat\'s detailed suggestion or explanation' },
        suggested_priority: { type: 'string', enum: ['low', 'medium', 'high', 'urgent'] },
        estimated_effort: { type: 'string', enum: ['trivial', 'small', 'medium', 'large', 'epic'] },
        reasoning: { type: 'string', description: 'Why PsiCat reached this verdict' },
      },
      required: ['verdict', 'suggestion'],
    };

    let suggestion = null;
    try {
      const llmRes = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: schema,
        model: 'gemini_3_flash',
      });
      suggestion = typeof llmRes === 'object' ? llmRes : null;
    } catch {
      suggestion = null;
    }

    if (!suggestion) {
      return Response.json({ ok: false, error: 'LLM suggestion failed' }, { status: 200 });
    }

    // Store the suggestion in the FallibilityEntry's resolution_notes
    if (entry_id) {
      try {
        const noteText = `[PsiCat: ${suggestion.verdict.toUpperCase()}] ${suggestion.suggestion}`.slice(0, 2000);
        await base44.entities.FallibilityEntry.update(entry_id, {
          resolution_notes: noteText,
        });
      } catch { /* best-effort persistence */ }
    }

    // Log as a MerlinNote for PsiCat's learning
    try {
      await base44.entities.MerlinNote.create({
        title: `Fallibility suggestion: ${(entry.title || title).slice(0, 150)}`,
        content: JSON.stringify(suggestion).slice(0, 3000),
        source: 'reasoning',
        source_url: '',
        tags_json: JSON.stringify(['fallibility', 'suggestion', suggestion.verdict, entry.category || category || 'other']),
        context: `Fallibility suggestion for ${entry.page_path || page_path || 'unknown page'}`,
        domain: 'general',
        contradiction_flag: 'clear',
        contradiction_detail: '',
        session_token: '',
        distilled_primitives_json: '{}',
        epistemic_confidence: null,
        uncertainty_bounds: 'SUGGESTION',
        decoherence_count: 0,
        domain_transition_path: '',
      });
    } catch { /* best-effort */ }

    return Response.json({
      ok: true,
      entry_id: entry_id || null,
      suggestion,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: 200 });
  }
}