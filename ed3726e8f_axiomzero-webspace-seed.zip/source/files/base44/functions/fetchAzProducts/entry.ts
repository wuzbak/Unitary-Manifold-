/**
 * fetchAzProducts — Live 12-AZ-IP product metadata from the repository.
 *
 * Fetches 12-AZ-IP/README.md via the authorized GitHub connector (5,000 req/hr),
 * parses the product registry table, and returns per-product metadata
 * (version, TRL, test count, description, folder) keyed by product number.
 *
 * Cached 1 hour at the module level. forceRefresh clears the cache.
 *
 * The frontend merges this live data with the hardcoded azProducts.js array
 * (which holds app-specific routing paths, icons, categories not in the repo).
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';

const REPO_OWNER = 'wuzbak';
const REPO_NAME = 'Unitary-Manifold-';
const REPO_BRANCH = 'main';
const REGISTRY_PATH = '12-AZ-IP/README.md';
const CACHE_TTL = 3600 * 1000; // 1 hour

let productCache = null; // { data, fetchedAt }

/**
 * Parse the 12-AZ-IP README product registry table.
 * Row format: | NN | Name | Version | TRL | Port | Tests | Description | [folder/](folder/) |
 */
function parseRegistry(md) {
  const lines = md.split('\n');
  const products = {};
  let inTable = false;

  for (const line of lines) {
    // Detect the main product table header row: "| # | Product | Version | TRL | ..."
    if (line.startsWith('| #') || line.startsWith('|#')) {
      inTable = true;
      continue;
    }
    // Skip separator rows and sub-surface tables
    if (inTable && /^\|[\s-]+\|/.test(line)) continue;
    if (!inTable) continue;

    const cols = line.split('|').map((c) => c.trim());
    // cols[0] is empty (leading |), cols[last] is empty (trailing |)
    // Need at least 8 content columns: #, name, version, trl, port, tests, desc, folder
    if (cols.length < 9) continue;

    const num = cols[1];
    // Must be a 2-digit product number
    if (!/^\d{2}$/.test(num)) continue;

    const name = cols[2];
    const version = cols[3];
    const trl = cols[4];
    const testsRaw = cols[6];
    const description = cols[7];
    const folderLink = cols[8] || '';

    // Extract folder name from "[01-axiom-os/](01-axiom-os/)"
    const folderMatch = folderLink.match(/\[([^\]]+)\]/);
    const folder = folderMatch ? folderMatch[1].replace(/\/$/, '') : '';

    // Parse test count (strip commas, non-numeric like "—" → null)
    const tests = /^\d[\d,]*$/.test(testsRaw) ? parseInt(testsRaw.replace(/,/g, '')) : null;

    // Stop at sub-surface tables (which start with surface names, not numbers)
    products[num] = { num, name, version, trl, tests, description: description.trim(), folder };
  }

  return products;
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    let body = {};
    try { body = await req.json(); } catch {}
    if (body.forceRefresh) productCache = null;

    // Return cache if fresh
    if (productCache && Date.now() - productCache.fetchedAt < CACHE_TTL) {
      return Response.json({
        status: 'ok',
        source: productCache.source,
        products: productCache.data,
        fetchedAt: new Date(productCache.fetchedAt).toISOString(),
        cached: true,
      });
    }

    // Authenticated GitHub access via OAuth connector
    let headers = {
      'Accept': 'application/vnd.github.raw+json',
      'User-Agent': 'AxiomZero-App',
      'X-GitHub-Api-Version': '2022-11-28',
    };
    let source = 'github-connector';
    try {
      const { accessToken } = await base44.asServiceRole.connectors.getConnection('github');
      if (accessToken) headers = { ...headers, Authorization: `Bearer ${accessToken}` };
    } catch {
      source = 'raw-githubusercontent (connector unavailable)';
    }

    const res = await fetch(
      `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${REGISTRY_PATH}?ref=${REPO_BRANCH}`,
      { headers }
    );

    if (!res.ok) {
      // Fallback to raw.githubusercontent (CDN, no rate limit)
      const rawRes = await fetch(
        `https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/${REPO_BRANCH}/${REGISTRY_PATH}`,
        { headers: { 'User-Agent': 'AxiomZero-App' } }
      );
      if (!rawRes.ok) {
        return Response.json({ status: 'unavailable', products: {}, message: `Failed to fetch registry: ${res.status}` }, { status: 200 });
      }
      const md = await rawRes.text();
      const products = parseRegistry(md);
      productCache = { data: products, fetchedAt: Date.now(), source: 'raw-githubusercontent' };
      return Response.json({
        status: 'ok',
        source: 'raw-githubusercontent',
        products,
        fetchedAt: new Date().toISOString(),
        cached: false,
      });
    }

    const md = await res.text();
    const products = parseRegistry(md);
    productCache = { data: products, fetchedAt: Date.now(), source };

    return Response.json({
      status: 'ok',
      source,
      products,
      fetchedAt: new Date().toISOString(),
      cached: false,
    });
  } catch (error) {
    return Response.json({ status: 'unavailable', products: {}, message: error.message }, { status: 200 });
  }
}