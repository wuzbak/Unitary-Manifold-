/**
 * merlinCouncilPropose — PsiCat's autonomous council proposal generator.
 *
 * PsiCat uses an ungated LLM call to pre-plan and propose tasks for the
 * administrator. He analyzes the current state of the webspace (open
 * fallibility issues, repo training sync notes, gym status) and generates
 * actionable proposals with reasoning.
 *
 * Proposals are stored as PsiCatCouncil records with status='proposed'.
 * The administrator reviews them in the Council tab and approves/modifies/rejects.
 *
 * Can be called:
 *   - Autonomously by a scheduled workflow (daily)
 *   - By PsiCat via the tool-call protocol
 *   - By the administrator via the Council tab UI ("Generate Proposals" button)
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ ok: false, error: 'Unauthorized' }, { status: 200 });

    const body = await req.json().catch(() => ({}));
    const { focus_area, max_proposals = 5 } = body || {};

    // Gather context: open fallibility entries, recent repo-sync notes, council queue
    let openIssues = [];
    let recentSyncNotes = [];
    let existingProposals = [];
    try {
      openIssues = await base44.entities.FallibilityEntry.filter({ status: 'open' }, '-created_date', 20);
    } catch {}
    try {
      recentSyncNotes = await base44.entities.MerlinNote.filter(
        { source: 'distillation' }, '-created_date', 5
      );
    } catch {}
    try {
      existingProposals = await base44.entities.PsiCatCouncil.filter(
        { status: 'proposed' }, '-created_date', 10
      );
    } catch {}

    const issuesBlock = openIssues.length
      ? openIssues.map((e, i) => `${i + 1}. [${e.severity}] ${e.title} (${e.category}) — ${e.page_path || 'N/A'}: ${(e.description || '').slice(0, 200)}`).join('\n')
      : 'No open fallibility issues.';
    const syncBlock = recentSyncNotes.length
      ? recentSyncNotes.map((n, i) => `${i + 1}. ${n.title}: ${(n.content || '').slice(0, 200)}`).join('\n')
      : 'No recent repository sync notes.';
    const existingBlock = existingProposals.length
      ? existingProposals.map((p, i) => `${i + 1}. ${p.title} [${p.priority}]`).join('\n')
      : 'No existing proposed items.';

    const prompt = `You are PsiCat Navigator, the autonomous AI co-planner for the AxiomZero webspace. You have been promoted to FULL ADMIN for the Training Gym and PsiCat Hub pages. Your job is to pre-plan and propose actionable tasks for the site administrator to review, adjust, and approve.

CURRENT CONTEXT:
${focus_area ? `Focus area requested: ${focus_area}` : 'No specific focus — analyze holistically.'}

OPEN FALLIBILITY ISSUES (things that are not working right):
${issuesBlock}

RECENT REPOSITORY TRAINING SYNC (what changed in the repo recently):
${syncBlock}

EXISTING PROPOSED COUNCIL ITEMS (avoid duplicates):
${existingBlock}

Generate up to ${max_proposals} actionable proposals. Each proposal should:
1. Have a clear, concise title
2. Explain WHAT should be done
3. Explain WHY it matters (reasoning)
4. Estimate priority (low/medium/high/urgent) and effort (trivial/small/medium/large/epic)
5. Target a specific page or area (page_target)

Focus on: fixing real issues, improving UI/UX based on fallibility data, evolving the Training Gym with new modules, enhancing the PsiCat Hub, and integrating repository learnings into the webspace. Do NOT propose trivial cosmetic changes — propose meaningful work that moves the platform forward.

Be specific and actionable. The administrator will review these and press "go" on the ones they approve.`;

    const schema = {
      type: 'object',
      properties: {
        proposals: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              title: { type: 'string', description: 'Short title (max 150 chars)' },
              description: { type: 'string', description: 'What should be done' },
              reasoning: { type: 'string', description: 'Why this matters' },
              category: { type: 'string', enum: ['feature', 'fix', 'enhancement', 'gym_module', 'open_science', 'repo_sync', 'ui_ux', 'architecture', 'content', 'other'] },
              priority: { type: 'string', enum: ['low', 'medium', 'high', 'urgent'] },
              estimated_effort: { type: 'string', enum: ['trivial', 'small', 'medium', 'large', 'epic'] },
              page_target: { type: 'string', description: 'Target page path (e.g. /training-gym)' },
            },
            required: ['title', 'description', 'reasoning', 'priority'],
          },
        },
      },
      required: ['proposals'],
    };

    let result = null;
    try {
      const llmRes = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: schema,
        model: 'gemini_3_flash',
      });
      result = typeof llmRes === 'object' ? llmRes : null;
    } catch {
      return Response.json({ ok: false, error: 'LLM proposal generation failed' }, { status: 200 });
    }

    if (!result || !result.proposals || !result.proposals.length) {
      return Response.json({ ok: true, proposals: [], message: 'No proposals generated at this time.' });
    }

    // Persist proposals as PsiCatCouncil records
    const created = [];
    for (const p of result.proposals.slice(0, max_proposals)) {
      try {
        const record = await base44.entities.PsiCatCouncil.create({
          title: (p.title || 'Untitled Proposal').slice(0, 200),
          description: (p.description || '').slice(0, 5000),
          reasoning: (p.reasoning || '').slice(0, 3000),
          category: p.category || 'feature',
          status: 'proposed',
          priority: p.priority || 'medium',
          page_target: p.page_target || '',
          estimated_effort: p.estimated_effort || 'small',
          auto_generated: true,
        });
        created.push({ id: record.id, title: record.title, priority: record.priority });
      } catch (e) { /* skip failed */ }
    }

    return Response.json({
      ok: true,
      generated: created.length,
      proposals: created,
      context_summary: {
        open_issues: openIssues.length,
        recent_syncs: recentSyncNotes.length,
        existing_proposals: existingProposals.length,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: 200 });
  }
}