import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { findFunction, findIntegration, findEntity, ENTITY_TOOL_RE, CONNECTOR_TOOL_RE } from '../../shared/agentRegistry.ts';

/**
 * agentOrchestrate — Multi-step chained tool execution.
 *
 * Input: { steps: [{ tool, args, input_from }] }
 *   - tool: registered tool name (same conventions as agentInvoke)
 *   - args: arguments for the tool
 *   - input_from: { step: <index>, path: '<dotted.path>' } — threads a prior step's
 *     output into this step's args. The value at `path` inside the prior step's
 *     `result` is deep-merged into `args`.
 *
 * Executes steps sequentially, applies the same per-step auth/scope gating as
 * agentInvoke, enforces a step cap (10), and returns every step's normalized
 * envelope in order.
 *
 * Returns: { ok, steps: [{ ok, tool, type, result, error, duration_ms }], total_duration_ms }
 */
const MAX_STEPS = 10;

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let body = {};
    try { body = await req.json(); } catch {}
    const { steps } = body;
    if (!Array.isArray(steps) || steps.length === 0) return Response.json({ error: 'steps array required.' }, { status: 400 });
    if (steps.length > MAX_STEPS) return Response.json({ error: `Step cap exceeded: ${steps.length} > ${MAX_STEPS}.` }, { status: 400 });

    const startTotal = Date.now();
    const results = [];

    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      if (!step.tool) { results.push({ ok: false, step: i, tool: null, error: 'Missing tool name.' }); continue; }

      // Resolve input_from: thread prior step output into args
      let resolvedArgs = { ...(step.args || {}) };
      if (step.input_from && typeof step.input_from === 'object') {
        const { step: fromStep, path, into, template } = step.input_from;
        if (typeof fromStep === 'number' && fromStep < i && results[fromStep]?.ok) {
          const threaded = getPath(results[fromStep].result, path);
          if (threaded !== undefined) {
            if (template && typeof template === 'string') {
              // Interpolate {value} into the template string, set into `into` (default 'prompt')
              const valStr = typeof threaded === 'object' ? JSON.stringify(threaded) : String(threaded);
              const interpolated = template.replace(/\{value\}/g, valStr);
              resolvedArgs[into || 'prompt'] = interpolated;
            } else if (into && typeof into === 'string') {
              // Set the threaded value directly into a named arg field
              resolvedArgs[into] = threaded;
            } else {
              // Default: deep-merge (object) or stash under _threaded (primitive)
              resolvedArgs = deepMerge(resolvedArgs, threaded);
            }
          }
        }
      }

      const start = Date.now();
      const routed = await routeTool(base44, user, step.tool, resolvedArgs);
      const duration_ms = Date.now() - start;
      results.push({ ...routed, step: i, tool: step.tool, duration_ms });
    }

    return Response.json({ ok: results.every(r => r.ok), steps: results, total_duration_ms: Date.now() - startTotal });
  } catch (error) {
    return Response.json({ ok: false, error: error.message, status: 'unavailable', steps: [], total_duration_ms: 0 }, { status: 200 });
  }
}

// Shared routing logic (mirrors agentInvoke)
async function routeTool(base44, user, tool, args) {
  const fn = findFunction(tool);
  if (fn) {
    if (fn.admin && user.role !== 'admin') return { ok: false, type: 'function', error: 'Admin role required for this tool.' };
    try {
      const res = await base44.functions.invoke(tool, args);
      const result = res?.data !== undefined ? res.data : res;
      return { ok: true, type: 'function', result };
    } catch (e) { return { ok: false, type: 'function', error: e.message }; }
  }
  if (tool.startsWith('Core.')) {
    const integ = findIntegration(tool);
    if (!integ) return { ok: false, type: 'integration', error: `Unknown integration: ${tool}` };
    if (integ.admin && user.role !== 'admin') return { ok: false, type: 'integration', error: 'Admin role required for this tool.' };
    const endpoint = tool.slice(5);
    try {
      const result = await base44.asServiceRole.integrations.Core[endpoint](args);
      return { ok: true, type: 'integration', result };
    } catch (e) { return { ok: false, type: 'integration', error: e.message }; }
  }
  const em = tool.match(ENTITY_TOOL_RE);
  if (em) {
    const [, entityName, op] = em;
    const ent = findEntity(entityName);
    if (!ent) return { ok: false, type: 'entity', error: `Unknown entity: ${entityName}` };
    const entityClient = base44.entities[entityName];
    if (!entityClient) return { ok: false, type: 'entity', error: `Entity client not available: ${entityName}` };
    try {
      let result;
      switch (op) {
        case 'list': result = await entityClient.list(args.sort, args.limit); break;
        case 'get': result = await entityClient.get(args.id); break;
        case 'create': result = await entityClient.create(args.data || args); break;
        case 'update': result = await entityClient.update(args.id, args.data || args); break;
        case 'delete': result = await entityClient.delete(args.id); break;
        case 'filter': result = await entityClient.filter(args.query || {}, args.sort, args.limit); break;
        case 'bulkCreate': result = await entityClient.bulkCreate(args.records || []); break;
        case 'schema': result = await entityClient.schema(); break;
        default: return { ok: false, type: 'entity', error: `Unknown entity operation: ${op}` };
      }
      return { ok: true, type: 'entity', result };
    } catch (e) { return { ok: false, type: 'entity', error: e.message }; }
  }
  const cm = tool.match(CONNECTOR_TOOL_RE);
  if (cm) {
    const [, connType] = cm;
    try {
      const conn = await base44.asServiceRole.connectors.getConnection(connType);
      return { ok: true, type: 'connector', result: { authorized: true, type: connType, connectionConfig: conn?.connectionConfig || null } };
    } catch (e) { return { ok: false, type: 'connector', error: `Connector ${connType} not authorized: ${e.message}` }; }
  }
  return { ok: false, type: 'unknown', error: `Tool not found: ${tool}` };
}

// Get a value at a dotted path inside an object
function getPath(obj, path) {
  if (!path) return obj;
  return path.split('.').reduce((acc, key) => (acc && typeof acc === 'object' ? acc[key] : undefined), obj);
}

// Deep-merge a threaded value into args. If threaded is an object, merge keys; else set under '_threaded'.
function deepMerge(target, threaded) {
  if (threaded && typeof threaded === 'object' && !Array.isArray(threaded)) {
    return { ...target, ...threaded };
  }
  return { ...target, _threaded: threaded };
}