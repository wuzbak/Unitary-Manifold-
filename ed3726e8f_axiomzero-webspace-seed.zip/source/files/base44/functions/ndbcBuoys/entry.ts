/**
 * ndbcBuoys — proxies the NDBC active-stations XML (no key required).
 * Returns marine-buoy / C-MAN station coverage points (id, name, lat, lon,
 * type, owner). Capped at 500 to keep the map payload manageable.
 * Public data proxy (no auth) — station metadata is public information.
 */
import { unavailableResponse } from '../../shared/degradedResponse.ts';

export default async function (req: Request): Promise<Response> {
  try {
    const res = await fetch('https://www.ndbc.noaa.gov/activestations.xml', {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; AxiomZeroGeoMonitor/1.0)' },
    });
    if (!res.ok) return unavailableResponse({ stations: [], count: 0 }, 'unavailable', `NDBC ${res.status}`);
    const xml = await res.text();
    const stations: any[] = [];
    const re = /<station\b([^>]*?)\s*\/>/gi;
    let m: RegExpExecArray | null;
    while ((m = re.exec(xml)) !== null) {
      const attrs = m[1];
      const id = attrs.match(/\bid="([^"]*)"/i)?.[1] || '';
      const lat = parseFloat(attrs.match(/\blat="([^"]*)"/i)?.[1] || 'NaN');
      const lon = parseFloat(attrs.match(/\blon="([^"]*)"/i)?.[1] || 'NaN');
      const name = attrs.match(/\bname="([^"]*)"/i)?.[1] || '';
      const type = attrs.match(/\btype="([^"]*)"/i)?.[1] || '';
      const owner = attrs.match(/\bowner="([^"]*)"/i)?.[1] || '';
      if (id && !isNaN(lat) && !isNaN(lon)) {
        stations.push({ id, name, lat, lon, type, owner });
      }
      if (stations.length >= 500) break;
    }
    return Response.json({ stations, count: stations.length });
  } catch (error) {
    return unavailableResponse({ stations: [], count: 0 }, 'unavailable', (error as Error).message);
  }
}