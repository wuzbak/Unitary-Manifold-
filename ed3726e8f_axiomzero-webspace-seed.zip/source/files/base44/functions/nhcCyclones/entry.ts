/**
 * nhcCyclones — proxies NOAA NHC tropical cyclone advisory RSS (Atlantic + E Pac).
 * Extracts lat/lon from advisory text where present. Public data proxy (no auth).
 */
import { parseRss } from '../../shared/rssParser.ts';
import { unavailableResponse } from '../../shared/degradedResponse.ts';

function extractCoords(text: string): [number, number] | null {
  const m = text.match(/(\d{1,2}\.\d+)\s*([NS])\s*(\d{1,3}\.\d+)\s*([EW])/i);
  if (!m) return null;
  const lat = parseFloat(m[1]) * (m[2].toUpperCase() === 'S' ? -1 : 1);
  const lon = parseFloat(m[3]) * (m[4].toUpperCase() === 'W' ? -1 : 1);
  return [lat, lon];
}

export default async function (req: Request): Promise<Response> {
  try {
    const feeds = [
      'https://www.nhc.noaa.gov/index-at.xml',
      'https://www.nhc.noaa.gov/index-ep.xml',
    ];
    const results = await Promise.allSettled(
      feeds.map((url) => fetch(url, { headers: { 'User-Agent': 'AxiomZero/1.0' } }).then((r) => r.text())),
    );
    const cyclones: any[] = [];
    results.forEach((res) => {
      if (res.status !== 'fulfilled') return;
      const items = parseRss(res.value);
      for (const it of items) {
        if (!/advisory|tropical|hurricane|storm|depression/i.test(it.title)) continue;
        cyclones.push({
          id: it.guid || it.link,
          title: it.title,
          link: it.link,
          description: it.description,
          pubDate: it.pubDate,
          coords: extractCoords(it.description + ' ' + it.title),
        });
      }
    });
    return Response.json({ cyclones, count: cyclones.length });
  } catch (error) {
    return unavailableResponse({ cyclones: [], count: 0 }, 'unavailable', (error as Error).message);
  }
}