/**
 * fallibilityAutoScan — Automated website fallibility scanner.
 *
 * Crawls key app pages via fetchWebPage, checks HTTP status, parses for
 * broken links and obvious error signatures, and writes results as
 * FallibilityEntry records with discovered_by='merlin_auto'.
 *
 * Called daily by the "Fallibility Auto-Scan" workflow.
 * Admin-only (scheduled task).
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

// Key pages to scan — the most important routes
const SCAN_PAGES = [
  { path: '/', label: 'Topology (Home)' },
  { path: '/psicat', label: 'PsiCat Hub' },
  { path: '/training-gym', label: 'Training Gym' },
  { path: '/filmers-companion', label: "Filmer's Companion" },
  { path: '/az-products', label: 'AZ Products' },
  { path: '/manifold-explorer', label: 'Manifold Explorer' },
  { path: '/knowledge-hub', label: 'Knowledge Hub' },
  { path: '/corporate', label: 'Corporate' },
  { path: '/system-status', label: 'System Status' },
  { path: '/falsification-lab', label: 'Falsification Lab' },
  { path: '/geo-monitor', label: 'Geo Monitor' },
  { path: '/terra-os', label: 'Earth Sciences' },
  { path: '/delphi', label: 'DelPhi Oracle' },
  { path: '/axiom-os-core', label: 'AxiomOS Core' },
  { path: '/eclipsa-integrity', label: 'ECLIPSA Console' },
  { path: '/safety', label: 'Safety Hub' },
  { path: '/lean4-formalization', label: 'Lean4 Formalization' },
  { path: '/about', label: 'About' },
];

const APP_BASE = 'https://axiomzero-webspace-prototype.base44.app';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ status: 'unavailable', error: 'Unauthorized' }, { status: 200 });
    if (user.role !== 'admin') return Response.json({ status: 'forbidden', error: 'Admin only' }, { status: 200 });

    const results = [];
    const newIssues = [];

    for (const page of SCAN_PAGES) {
      const url = `${APP_BASE}${page.path}`;
      let status = 'unknown';
      let httpCode = 0;
      let title = '';
      let contentLength = 0;
      let errorSig = null;

      try {
        // Use fetchWebPage backend function to crawl
        const crawlRes = await base44.functions.invoke('fetchWebPage', { url });
        const data = crawlRes?.data || crawlRes;
        httpCode = data?.status || 200;
        title = data?.title || '';
        contentLength = (data?.content || '').length;

        // Check for real error signatures in content.
        // NOTE: this is a client-rendered SPA — a 200 response with the app shell
        // title and minimal server-rendered text is the EXPECTED response, not an
        // error. Only flag genuine error signatures, not low content length.
        const content = (data?.content || '').toLowerCase();
        if (content.includes('cannot read properties of undefined')) {
          errorSig = 'Runtime error: Cannot read properties of undefined';
        } else if (content.includes('is not a function')) {
          errorSig = 'Runtime error: is not a function';
        } else if (content.includes('failed to fetch')) {
          errorSig = 'Network error: Failed to fetch';
        } else if (content.includes('application error') || content.includes('client-side exception')) {
          errorSig = 'Application error detected';
        }

        status = errorSig ? 'error' : (httpCode >= 400 ? 'error' : 'ok');
      } catch (e) {
        status = 'fetch_failed';
        errorSig = e.message || 'Fetch failed';
      }

      results.push({ path: page.path, label: page.label, status, httpCode, title, contentLength, errorSig });

      // Create FallibilityEntry for errors
      if (status === 'error' && errorSig) {
        // Check if we already have an open entry for this page+error
        let existing = [];
        try {
          existing = await base44.entities.FallibilityEntry.filter({
            page_path: page.path,
            status: 'open',
          }, '-created_date', 5);
        } catch {}

        const alreadyLogged = existing.some((e) =>
          (e.description || '').includes(errorSig)
        );

        if (!alreadyLogged) {
          try {
            const entry = await base44.entities.FallibilityEntry.create({
              title: `Auto-scan: ${errorSig} on ${page.label}`,
              description: `Automated fallibility scan detected: ${errorSig}\n\nPage: ${page.path} (${page.label})\nHTTP Status: ${httpCode}\nContent Length: ${contentLength} chars\nTitle: ${title}\n\nThis issue was detected by the daily auto-scan workflow.`,
              category: errorSig.includes('Runtime') ? 'error' : errorSig.includes('Network') ? 'error' : 'function',
              severity: 'warning',
              status: 'open',
              page_path: page.path,
              component: page.label,
              discovered_by: 'merlin_auto',
            });
            newIssues.push({ id: entry.id, path: page.path, error: errorSig });
          } catch {}
        }
      }
    }

    // Log scan summary as a MerlinNote
    try {
      const okCount = results.filter((r) => r.status === 'ok').length;
      const errorCount = results.filter((r) => r.status === 'error').length;
      const fetchFailCount = results.filter((r) => r.status === 'fetch_failed').length;

      await base44.entities.MerlinNote.create({
        title: `Fallibility auto-scan: ${okCount} ok, ${errorCount} errors, ${newIssues.length} new issues`,
        content: JSON.stringify({ results, newIssues }, null, 2).slice(0, 5000),
        source: 'internal',
        source_url: '',
        tags_json: JSON.stringify(['fallibility', 'auto-scan', `errors:${errorCount}`, `new:${newIssues.length}`]),
        context: 'Daily automated fallibility scan of key webspace pages',
        domain: 'general',
        contradiction_flag: 'clear',
        contradiction_detail: '',
        session_token: '',
        distilled_primitives_json: '{}',
        epistemic_confidence: null,
        uncertainty_bounds: 'TELEMETRY',
        decoherence_count: 0,
        domain_transition_path: '',
      });
    } catch {}

    return Response.json({
      status: 'ok',
      scannedAt: new Date().toISOString(),
      pagesScanned: results.length,
      okCount: results.filter((r) => r.status === 'ok').length,
      errorCount: results.filter((r) => r.status === 'error').length,
      fetchFailCount: results.filter((r) => r.status === 'fetch_failed').length,
      newIssuesCreated: newIssues.length,
      newIssues,
      results,
    });
  } catch (error) {
    return Response.json({ status: 'unavailable', error: error.message }, { status: 200 });
  }
}