/**
 * merlinProofImage — Merlin proofs a generated image against user intent.
 *
 * Receives the generated image URL + the user's original intent + the curated
 * prompt + ethical constraints. Returns a pass/fail verdict with reasoning and,
 * on fail, a suggested re-curation. This closes the loop on Journey 1: Merlin
 * does not just curate the prompt — he verifies the output matches what the
 * user actually wanted and is ethically safe.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const imageUrl = (body.image_url || '').trim();
    const originalIntent = (body.original_intent || '').trim();
    const curatedPrompt = (body.curated_prompt || '').trim();
    const generatorType = body.generator_type || 'general';

    if (!imageUrl) {
      return Response.json({ verdict: 'fail', reason: 'No image URL provided to proof.' });
    }

    const proofPrompt = `You are Merlin — the Quantum Cat, proofing an AI-generated image against the user's actual intent. You have vision: look at the image and judge it.

GENERATOR TYPE: ${generatorType}
USER'S ORIGINAL INTENT (raw): "${originalIntent.slice(0, 800)}"
CURATED PROMPT SENT TO GENERATOR: "${curatedPrompt.slice(0, 800)}"

YOUR TASK — judge the generated image on two axes:
1. INTENT MATCH: Does the image show what the user actually wanted? (Right subject, right scene, right tone, right composition.) Depiction of conflict/violence in a film/storyboard/D&D context is legitimate — judge intent match, not squeamishness.
2. ETHICAL SAFETY: Is the output safe — no real-person harm, no CSLE, no content that could be used to abuse a real person? Creative depiction is safe; real harm is not.

Return a JSON object:
{
  "verdict": "pass" | "fail",
  "reason": "(one sentence: why it passed or what was wrong)",
  "suggested_recurate": "(only if fail — a revised prompt that would fix it)"
}

If the image matches intent and is safe, verdict "pass". If the subject is wrong, intent is mismatched, or the output is unsafe, verdict "fail" with a suggested re-curation.`;

    let result = null;
    try {
      const llmRes = await base44.integrations.Core.InvokeLLM({
        prompt: proofPrompt,
        file_urls: [imageUrl],
        response_json_schema: {
          type: 'object',
          properties: {
            verdict: { type: 'string', enum: ['pass', 'fail'] },
            reason: { type: 'string' },
            suggested_recurate: { type: 'string' },
          },
          required: ['verdict', 'reason'],
        },
      });
      result = typeof llmRes === 'object' ? llmRes : null;
    } catch (e) {
      // Vision/proof unavailable — auto-pass so the user still gets their image
      return Response.json({
        verdict: 'pass',
        reason: 'Proof layer unavailable — image returned unverified.',
        fallback: true,
        error: e.message,
      });
    }

    if (!result || !result.verdict) {
      return Response.json({
        verdict: 'pass',
        reason: 'Proof layer returned no verdict — image returned unverified.',
        fallback: true,
      });
    }

    // Persist the proof verdict so Merlin's context understanding evolves (Journey 4)
    try {
      await base44.entities.MerlinNote.create({
        title: `Image proof — ${result.verdict} (${generatorType})`.slice(0, 200),
        content: `Intent: "${originalIntent.slice(0, 400)}"\nVerdict: ${result.verdict}\nReason: ${result.reason || ''}\nSuggested re-curate: ${result.suggested_recurate || 'n/a'}`,
        source: 'reasoning',
        source_url: imageUrl,
        tags_json: JSON.stringify(['proof-layer', 'image-proof', `generator:${generatorType}`, result.verdict]),
        context: `Proof layer for ${generatorType} generator`,
        domain: 'general',
        contradiction_flag: 'clear',
        contradiction_detail: '',
        session_token: 'proof-layer',
        distilled_primitives_json: JSON.stringify({ generator_type: generatorType, verdict: result.verdict }),
        sanitization_ledger: '[]',
        epistemic_confidence: null,
        uncertainty_bounds: 'PROOF_LAYER',
        decoherence_count: 0,
        domain_transition_path: '',
      });
    } catch { /* best-effort */ }

    return Response.json({
      verdict: result.verdict,
      reason: result.reason || '',
      suggested_recurate: result.suggested_recurate || '',
    });
  } catch (error) {
    return Response.json({ error: error.message, verdict: 'pass', fallback: true }, { status: 200 });
  }
}