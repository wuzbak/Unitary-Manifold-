/**
 * smithsonianVolcano — USGS Volcano Notification API (primary, no auth) with
 * Smithsonian Global Volcanism Program as a secondary fallback (often WAF-blocked).
 *
 * Primary: USGS getElevatedVolcanoes (JSON) — volcanoes in elevated state
 *   (yellow/orange/red, advisory/watch/warning), cross-referenced with
 *   getUSVolcanoes for coordinates so they pin on the map.
 * Fallback: Smithsonian GVPS RSS (volcano.si.edu) if USGS returns nothing.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { fetchWithResilience, fetchTextWithResilience } from '../../shared/resilientFetch.ts';
import { parseRss, geoPoint, field } from '../../shared/rssParser.ts';

const ELEVATED_URL = 'https://volcanoes.usgs.gov/hans-public/api/volcano/getElevatedVolcanoes';
const US_VOLCANOES_URL = 'https://volcanoes.usgs.gov/hans-public/api/volcano/getUSVolcanoes';
const SMITHSONIAN_URL = 'https://volcano.si.edu/feed/feeds/volcanowarning.xml';
const UA = 'Mozilla/5.0 (AxiomZero-GeoMonitor/1.0; +https://axiomzerospc.org)';

export default async function (req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    let volcanoes: any[] = [];
    let source = 'USGS Volcano Notifications';
    let fetchStatus = 'unavailable';

    // Fetch elevated volcanoes + US volcano coords in parallel
    const [elevatedRes, usRes] = await Promise.all([
      fetchWithResilience(ELEVATED_URL, {
        headers: { 'User-Agent': UA, 'Accept': 'application/json' },
        retries: 2, timeoutMs: 12000, cacheTtl: 300000,
      }),
      fetchWithResilience(US_VOLCANOES_URL, {
        headers: { 'User-Agent': UA, 'Accept': 'application/json' },
        retries: 1, timeoutMs: 10000, cacheTtl: 600000,
      }),
    ]);
    fetchStatus = elevatedRes.status;

    if (Array.isArray(elevatedRes.data)) {
      // Build vnum → coords map from the full US volcano list
      const coordsMap: Record<string, [number, number]> = {};
      if (Array.isArray(usRes.data)) {
        for (const v of usRes.data) {
          const lat = v.latitude ?? v.lat ?? v.geo_lat;
          const lon = v.longitude ?? v.lon ?? v.geo_lon;
          if (v.vnum && lat != null && lon != null) coordsMap[String(v.vnum)] = [Number(lat), Number(lon)];
        }
      }
      for (const v of elevatedRes.data) {
        volcanoes.push({
          id: v.notice_identifier || v.vnum,
          title: v.volcano_name || 'Unknown Volcano',
          link: v.notice_url || '',
          description: `${v.obs_fullname || v.obs_abbr || ''} — ${v.color_code || ''} / ${v.alert_level || ''}`,
          alertLevel: `${v.color_code || ''} ${v.alert_level || ''}`.trim(),
          pubDate: v.sent_utc || '',
          coords: v.vnum ? coordsMap[String(v.vnum)] || null : null,
        });
      }
      source = 'USGS Volcano Notifications (elevated)';
    }

    // Fallback: Smithsonian GVPS RSS if USGS returned nothing
    if (volcanoes.length === 0) {
      const smith = await fetchTextWithResilience(SMITHSONIAN_URL, {
        headers: { 'User-Agent': UA },
        retries: 1, timeoutMs: 10000, cacheTtl: 300000,
      });
      if (smith.data) {
        source = 'Smithsonian Global Volcanism Program';
        fetchStatus = smith.status;
        for (const it of parseRss(smith.data)) {
          volcanoes.push({
            id: it.guid || it.link,
            title: it.title,
            link: it.link,
            description: it.description,
            alertLevel: field(it.raw, 'dc:subject', 'category') || 'Alert',
            pubDate: it.pubDate,
            coords: geoPoint(it.raw),
          });
        }
      }
    }

    const filtered = volcanoes.filter((v) => v.title);
    return Response.json({
      volcanoes: filtered,
      count: filtered.length,
      source,
      status: filtered.length > 0 ? 'ok' : 'unavailable',
      fetchStatus,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ volcanoes: [], count: 0, status: 'unavailable', message: (error as Error).message }, { status: 200 });
  }
}