/**
 * airNow — proxies EPA AirNow current AQI observations for major US metros.
 * Queries ~15 city coordinates in parallel. Requires AIRNOW_API_KEY.
 * Public data proxy (no auth) — key kept server-side.
 */
import { secrets } from 'base44:runtime';
import { unavailableResponse } from '../../shared/degradedResponse.ts';

const CITIES = [
  { name: 'New York', state: 'NY', lat: 40.71, lon: -74.0 },
  { name: 'Los Angeles', state: 'CA', lat: 34.05, lon: -118.24 },
  { name: 'Chicago', state: 'IL', lat: 41.88, lon: -87.63 },
  { name: 'Houston', state: 'TX', lat: 29.76, lon: -95.37 },
  { name: 'Phoenix', state: 'AZ', lat: 33.45, lon: -112.07 },
  { name: 'Philadelphia', state: 'PA', lat: 39.95, lon: -75.17 },
  { name: 'San Antonio', state: 'TX', lat: 29.42, lon: -98.49 },
  { name: 'San Diego', state: 'CA', lat: 32.72, lon: -117.16 },
  { name: 'Dallas', state: 'TX', lat: 32.78, lon: -96.8 },
  { name: 'Denver', state: 'CO', lat: 39.74, lon: -104.99 },
  { name: 'Seattle', state: 'WA', lat: 47.61, lon: -122.33 },
  { name: 'Atlanta', state: 'GA', lat: 33.75, lon: -84.39 },
  { name: 'Miami', state: 'FL', lat: 25.76, lon: -80.19 },
  { name: 'Portland', state: 'OR', lat: 45.52, lon: -122.68 },
  { name: 'Salt Lake City', state: 'UT', lat: 40.76, lon: -111.89 },
];

export default async function (req: Request): Promise<Response> {
  try {
    const key = secrets.get('AIRNOW_API_KEY');
    if (!key) return unavailableResponse({ observations: [], count: 0 }, 'missing-credentials', 'AIRNOW_API_KEY not set');
    const results = await Promise.allSettled(CITIES.map((c) => {
      const url = `https://airnowapi.org/aq/observation/latLong/current/?format=application/json&latitude=${c.lat}&longitude=${c.lon}&distance=25&API_KEY=${key}`;
      return fetch(url, { headers: { 'User-Agent': 'AxiomZero/1.0' } }).then((r) => r.json());
    }));
    const observations: any[] = [];
    results.forEach((res, i) => {
      if (res.status !== 'fulfilled' || !Array.isArray(res.value) || !res.value.length) return;
      const obs: any = res.value[0];
      observations.push({
        lat: CITIES[i].lat,
        lon: CITIES[i].lon,
        reportingArea: obs.ReportingArea || CITIES[i].name,
        state: obs.StateCode || CITIES[i].state,
        aqi: obs.AQI != null ? obs.AQI : null,
        category: obs.Category && obs.Category.Name ? obs.Category.Name : '',
        parameterName: obs.ParameterName || '',
      });
    });
    return Response.json({ observations, count: observations.length });
  } catch (error) {
    return unavailableResponse({ observations: [], count: 0 }, 'unavailable', (error as Error).message);
  }
}