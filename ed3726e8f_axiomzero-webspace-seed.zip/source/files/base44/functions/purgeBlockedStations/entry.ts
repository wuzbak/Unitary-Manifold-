import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { isBlockedStation } from '../../shared/stationBlocklist.ts';

/**
 * purgeBlockedStations — one-time maintenance function that scans all cached
 * SdrStation records, deletes any matching the authoritarian propaganda
 * blocklist, and returns a count. Run once to clean the existing cache, then
 * re-run whenever the blocklist is updated.
 *
 * Uses asServiceRole for deletes (SdrStation delete is admin-only RLS).
 * No auth gate — this is a maintenance utility, not user-facing.
 */
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    // 1. Read all cached stations
    let all: any[] = [];
    try {
      all = await base44.entities.SdrStation.list('-created_date', 2000);
    } catch (e) {
      return Response.json({ error: 'Failed to read stations: ' + e.message }, { status: 500 });
    }

    // 2. Find blocked stations
    const blocked = all.filter(isBlockedStation);
    const blockedNames = blocked.map(s => s.name);

    // 3. Delete them individually (asServiceRole bypasses admin-only delete RLS)
    let deleted = 0;
    const errors: string[] = [];
    for (const s of blocked) {
      try {
        await base44.asServiceRole.entities.SdrStation.delete(s.id);
        deleted++;
      } catch (e) {
        errors.push(`${s.name}: ${e.message}`);
      }
    }

    return Response.json({
      total_scanned: all.length,
      blocked_found: blocked.length,
      deleted,
      blocked_names: blockedNames,
      errors: errors.length > 0 ? errors : undefined,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}