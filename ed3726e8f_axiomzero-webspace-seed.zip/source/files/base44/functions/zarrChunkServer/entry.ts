/**
 * zarrChunkServer — Zarr v2 chunked array server for N-dimensional dataset streaming.
 *
 * Serves metadata (shape, chunks, dtype) and individual chunk data on demand.
 * The frontend ZarrClient fetches only the chunks needed for the current viewport —
 * no full-payload JSON API choking. Chunks are computed procedurally server-side
 * (no static file storage needed) and returned as base64-encoded Float32 bytes.
 *
 * Datasets:
 *   - manifold-excitation: 256×256 Float32, 64×64 chunks — toroidal excitation pattern
 *   - geo-event-grid: 180×360 Float32, 45×90 chunks — lat/lon event density
 *
 * Input: { dataset, metadataOnly?, chunkIndex? }
 * Returns metadata JSON or { data: base64, shape, chunkIndex }
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

interface DatasetConfig {
  shape: number[];
  chunks: number[];
  dtype: string;
  fillValue: number;
  description: string;
  compute: (indices: number[], shape: number[], chunks: number[]) => number;
}

const DATASETS: Record<string, DatasetConfig> = {
  'manifold-excitation': {
    shape: [256, 256],
    chunks: [64, 64],
    dtype: '<f4',
    fillValue: 0,
    description: '2D scalar field over toroidal coordinates — excitation pattern of the 5D Kaluza-Klein manifold.',
    compute: (idx, shape, chunks) => {
      const [r, c] = idx;
      // Toroidal excitation: sum of sinusoids creating a manifold resonance pattern
      const x = r / shape[0] * 2 * Math.PI;
      const y = c / shape[1] * 2 * Math.PI;
      return Math.sin(4 * x) * Math.cos(4 * y) + 0.5 * Math.sin(8 * (x + y)) + 0.3 * Math.cos(16 * x * y);
    },
  },
  'geo-event-grid': {
    shape: [180, 360],
    chunks: [45, 90],
    dtype: '<f4',
    fillValue: 0,
    description: '2D event density grid over lat/lon coordinates — aggregated geological and disaster event density.',
    compute: (idx, shape, chunks) => {
      const [r, c] = idx;
      const lat = (r / shape[0] - 0.5) * Math.PI;  // -π/2 to π/2
      const lon = (c / shape[1] - 0.5) * 2 * Math.PI;  // -π to π
      // Event density: higher near equator + tectonic plate boundaries (simplified)
      const equatorBoost = Math.exp(-Math.abs(lat) * 2);
      const plateBoundary = 0.4 * Math.exp(-Math.abs(Math.sin(lon * 3)) * 3) * Math.exp(-Math.abs(lat - 0.3) * 4);
      const noise = 0.1 * Math.sin(lat * 20) * Math.cos(lon * 17);
      return equatorBoost + plateBoundary + noise;
    },
  },
};

function float32ToBase64(arr: Float32Array): string {
  const bytes = new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let body: any = {};
    try { body = await req.json(); } catch {}
    const { dataset = 'manifold-excitation', metadataOnly = false, chunkIndex = null } = body;

    const config = DATASETS[dataset];
    if (!config) {
      return Response.json({ error: `Unknown dataset: ${dataset}. Available: ${Object.keys(DATASETS).join(', ')}` }, { status: 400 });
    }

    // Metadata request
    if (metadataOnly) {
      const chunksPerDim = config.shape.map((s, d) => Math.ceil(s / config.chunks[d]));
      const totalChunks = chunksPerDim.reduce((a, b) => a * b, 1);
      return Response.json({
        dataset,
        shape: config.shape,
        chunks: config.chunks,
        dtype: config.dtype,
        fillValue: config.fillValue,
        order: 'C',
        totalChunks,
        chunksPerDim,
        description: config.description,
      });
    }

    // Chunk request
    if (chunkIndex === null || chunkIndex === undefined) {
      return Response.json({ error: 'chunkIndex required when metadataOnly is false' }, { status: 400 });
    }

    const chunksPerDim = config.shape.map((s, d) => Math.ceil(s / config.chunks[d]));
    const totalChunks = chunksPerDim.reduce((a, b) => a * b, 1);
    if (chunkIndex < 0 || chunkIndex >= totalChunks) {
      return Response.json({ error: `chunkIndex ${chunkIndex} out of range [0, ${totalChunks})` }, { status: 400 });
    }

    // Convert flat chunk index to multi-dim chunk coordinates (row-major)
    const chunkCoords: number[] = [];
    let remaining = chunkIndex;
    for (let d = chunksPerDim.length - 1; d >= 0; d--) {
      chunkCoords[d] = remaining % chunksPerDim[d];
      remaining = Math.floor(remaining / chunksPerDim[d]);
    }

    // Compute the chunk data
    const [chunkRows, chunkCols] = config.chunks;
    const chunkData = new Float32Array(chunkRows * chunkCols);
    const [rowOffset, colOffset] = [chunkCoords[0] * chunkRows, chunkCoords[1] * chunkCols];

    for (let r = 0; r < chunkRows; r++) {
      for (let c = 0; c < chunkCols; c++) {
        const globalR = rowOffset + r;
        const globalC = colOffset + c;
        // Clamp to shape (last chunk may be smaller)
        if (globalR < config.shape[0] && globalC < config.shape[1]) {
          chunkData[r * chunkCols + c] = config.compute([globalR, globalC], config.shape, config.chunks);
        } else {
          chunkData[r * chunkCols + c] = config.fillValue;
        }
      }
    }

    return Response.json({
      dataset,
      chunkIndex,
      chunkCoords,
      shape: [chunkRows, chunkCols],
      data: float32ToBase64(chunkData),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}