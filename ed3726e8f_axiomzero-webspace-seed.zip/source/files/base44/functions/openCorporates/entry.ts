import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';
import { makeSource, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';
import { fetchWithResilience } from '../../shared/resilientFetch.ts';

/**
 * openCorporates — Corporate registration records worldwide.
 *
 * Free-alt tier (primary): SEC EDGAR full-text search (efts.sec.gov, no auth) —
 * discovers public companies by name → CIK + filings.
 * Premium tier (secondary): OpenCorporates API (if OPENCORPORATES_API_TOKEN valid).
 * Results are tagged with which tier produced them.
 */

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'OpenCorporates', 'No query provided');

    const sources: any[] = [];
    const tiers: string[] = [];

    // ── Free-alt tier: SEC EDGAR full-text search (no auth) ──
    const contact = secrets.get('SEC_EDGAR_CONTACT_EMAIL') || 'admin@axiomzerospc.org';
    const eftsUrl = `https://efts.sec.gov/LATEST/search-index?q=${encodeURIComponent(query)}&forms=10-K,10-Q,8-K,4,SC-13D`;
    const efts = await fetchWithResilience(eftsUrl, {
      headers: { 'User-Agent': `AxiomZero AXIOM Journalist ${contact}` },
      retries: 2, timeoutMs: 12000, cacheTtl: 300000,
    });
    if (efts.data && efts.data.hits && Array.isArray(efts.data.hits.hits)) {
      const seenCik = new Set<string>();
      for (const hit of efts.data.hits.hits) {
        const s = hit._source || {};
        const ciks: string[] = s.ciks || [];
        const names: string[] = s.display_names || [];
        for (let i = 0; i < ciks.length; i++) {
          const cik = String(ciks[i]);
          if (seenCik.has(cik)) continue;
          seenCik.add(cik);
          const cikNum = cik ? String(parseInt(cik, 10)) : '';
          const name = names[i] || query;
          sources.push(makeSource({
            title: `${name} (CIK ${cikNum})`,
            tier: 2,
            source_type: 'Corporate registration record — SEC EDGAR (free-alt)',
            url_or_ref: `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=${cik}&type=&dateb=&owner=include&count=40`,
            date: s.file_date || '',
            excerpt: `SEC filer — CIK ${cikNum}. Forms: ${(s.root_forms || []).join(', ') || 'N/A'}. Latest filing: ${s.file_date || 'N/A'}.`,
            raw_metadata: { ...s, free_alt: 'sec_edgar_efts', cik: cikNum },
          }));
          if (sources.length >= 15) break;
        }
        if (sources.length >= 15) break;
      }
      if (sources.length > 0) tiers.push('free-alt:sec-edgar');
    }

    // ── Premium tier: OpenCorporates API (if token valid) ──
    const token = secrets.get('OPENCORPORATES_API_TOKEN');
    if (token) {
      try {
        const ocUrl = `https://api.opencorporates.com/v0.4/companies/search?q=${encodeURIComponent(query)}&api_token=${encodeURIComponent(token)}&per_page=10`;
        const ocRes = await fetchWithResilience(ocUrl, { retries: 1, timeoutMs: 10000, cacheTtl: 300000 });
        if (ocRes.data && ocRes.data.results && ocRes.data.results.companies) {
          for (const row of ocRes.data.results.companies) {
            const c = row.company || row;
            sources.push(makeSource({
              title: `${c.name || query} (${c.jurisdiction_code || ''})`,
              tier: 2,
              source_type: 'Corporate registration record — OpenCorporates (premium)',
              url_or_ref: c.opencorporates_url || `https://opencorporates.com/companies/${c.jurisdiction_code}/${c.company_number}`,
              date: c.incorporation_date || c.created_at || '',
              excerpt: `Company #${c.company_number || ''} · Status: ${c.current_status || 'N/A'} · Registered: ${c.registered_address_in_full || 'N/A'}`,
              raw_metadata: { ...c, tier: 'token-premium', source: 'opencorporates' },
            }));
          }
          tiers.push('token-premium:opencorporates');
        } else if ((ocRes.error || '').includes('401')) {
          tiers.push('token-premium:opencorporates:token-invalid');
        }
      } catch { tiers.push('token-premium:opencorporates:failed'); }
    }

    if (sources.length === 0) return errResponse(query, 'OpenCorporates', 'No results from SEC EDGAR or OpenCorporates');
    return Response.json({ sources, query, source_name: 'OpenCorporates', count: sources.length, status: 'ok', tiers });
  } catch (error) {
    return errResponse('', 'OpenCorporates', (error as Error).message);
  }
}