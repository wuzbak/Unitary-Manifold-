/**
 * dndCompileEntry — Merlin-compiled hybrid compendium expansion.
 *
 * Uses InvokeLLM with add_context_from_internet to compile additional D&D
 * entries for a given category (monsters, spells, items, backgrounds, cantrips,
 * feats, villains, heroes, npcs) on demand. Returns JSON-schema-shaped records
 * that the client merges into the catalog and persists as custom entities.
 *
 * The SRD static base lives client-side; this function retrieves additional
 * entries beyond the base set.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { category, query, count = 5, existingSlugs = [] } = body;
    if (!category) return Response.json({ error: 'category is required' }, { status: 400 });

    const prompt = buildCompilePrompt(category, query, count, existingSlugs);

    const schema = buildSchema(category);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      model: 'gemini_3_flash',
      response_json_schema: schema,
    });

    const entries = result.entries || result.monsters || result.spells || result.items || result.heroes || result.villains || result.npcs || [];
    return Response.json({ category, entries, summary: result.summary || `Compiled ${entries.length} ${category} entries.` });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

function buildCompilePrompt(category, query, count, existingSlugs) {
  const base = `You are a D&D 5e/5.5e compendium compiler. Compile ${count} additional ${category} entries${query ? ` related to "${query}"` : ''} that are NOT in this list of already-known slugs: ${existingSlugs.join(', ') || '(none)'}.`;

  switch (category) {
    case 'monsters':
    case 'villains':
      return `${base}

Return full monster stat blocks. Each entry needs:
- name, slug (kebab-case), cr (challenge rating number, e.g. 0.25, 1, 5, 17, 30), xp, hp, ac, speed
- size, type (Undead/Dragon/Fiend/Beast/etc), environment, role (brute/controller/skirmisher/etc), alignment
- str, dex, con, int, wis, cha (ability scores 1-30)
- senses, languages
- signature_abilities (array of strings), actions (array of strings), tactics (array of strings)
- description (1-2 sentences of lore)
${category === 'villains' ? 'Focus on legendary, high-CR (10+), named villains and boss monsters with rich lore.' : ''}`;

    case 'spells':
    case 'cantrips':
      return `${base}

Return full spell entries. Each entry needs:
- name, slug, level (0 for cantrips, 1-9), school (Evocation/Abjuration/Conjuration/Divination/Enchantment/Illusion/Necromancy/Transmutation)
- casting_time, range, components, duration, concentration (boolean), ritual (boolean)
- description (full spell text), classes (array of class names that can cast it)
${category === 'cantrips' ? 'Only return level-0 cantrips.' : ''}`;

    case 'items':
      return `${base}

Return full magic item entries. Each entry needs:
- name, slug, type (weapon/armor/shield/consumable/tool/wondrous item/scroll/wand/staff/ring/rod), rarity (common/uncommon/rare/very-rare/legendary/artifact)
- attunement (boolean), value (in gp), description (full item text)`;

    case 'backgrounds':
      return `${base}

Return full background entries. Each entry needs:
- name, slug, skill (the granted skill proficiency), feature (name and description of the background feature), description`;

    case 'feats':
      return `${base}

Return full feat entries. Each entry needs:
- name, slug, description (full feat text), prerequisite (if any, or empty string)`;

    case 'heroes':
    case 'npcs':
      return `${base}

Return full character/NPC entries. Each entry needs:
- name, slug, species, klass, level, alignment
- ability_scores (strength/dexterity/constitution/intelligence/wisdom/charisma)
- hp_max, armor_class, passive_perception
- abilities (array of notable abilities/features), description (1-2 sentences of personality/lore)
- role (their role in the world, e.g. "retired adventurer", "village elder", "royal knight")
${category === 'heroes' ? 'Focus on notable, named heroes and legendary adventurers.' : 'Focus on interesting, memorable NPCs with distinct personalities.'}`;

    default:
      return `${base}\n\nReturn entries with name, slug, and description fields.`;
  }
}

function buildSchema(category) {
  const base = { type: 'object', properties: { summary: { type: 'string' } } };
  if (category === 'monsters' || category === 'villains') {
    base.properties.entries = {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' }, slug: { type: 'string' },
          cr: { type: 'number' }, xp: { type: 'number' }, hp: { type: 'number' }, ac: { type: 'number' },
          speed: { type: 'string' }, size: { type: 'string' }, type: { type: 'string' },
          environment: { type: 'string' }, role: { type: 'string' }, alignment: { type: 'string' },
          str: { type: 'number' }, dex: { type: 'number' }, con: { type: 'number' },
          int: { type: 'number' }, wis: { type: 'number' }, cha: { type: 'number' },
          senses: { type: 'string' }, languages: { type: 'string' },
          signature_abilities: { type: 'array', items: { type: 'string' } },
          actions: { type: 'array', items: { type: 'string' } },
          tactics: { type: 'array', items: { type: 'string' } },
          description: { type: 'string' },
        },
      },
    };
  } else if (category === 'spells' || category === 'cantrips') {
    base.properties.entries = {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' }, slug: { type: 'string' }, level: { type: 'number' },
          school: { type: 'string' }, casting_time: { type: 'string' }, range: { type: 'string' },
          components: { type: 'string' }, duration: { type: 'string' },
          concentration: { type: 'boolean' }, ritual: { type: 'boolean' },
          description: { type: 'string' }, classes: { type: 'array', items: { type: 'string' } },
        },
      },
    };
  } else if (category === 'items') {
    base.properties.entries = {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' }, slug: { type: 'string' }, type: { type: 'string' },
          rarity: { type: 'string' }, attunement: { type: 'boolean' },
          value: { type: 'number' }, description: { type: 'string' },
        },
      },
    };
  } else if (category === 'backgrounds') {
    base.properties.entries = {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' }, slug: { type: 'string' }, skill: { type: 'string' },
          feature: { type: 'string' }, description: { type: 'string' },
        },
      },
    };
  } else if (category === 'feats') {
    base.properties.entries = {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' }, slug: { type: 'string' },
          description: { type: 'string' }, prerequisite: { type: 'string' },
        },
      },
    };
  } else if (category === 'heroes' || category === 'npcs') {
    base.properties.entries = {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' }, slug: { type: 'string' },
          species: { type: 'string' }, klass: { type: 'string' },
          level: { type: 'number' }, alignment: { type: 'string' },
          ability_scores: {
            type: 'object',
            properties: {
              strength: { type: 'number' }, dexterity: { type: 'number' },
              constitution: { type: 'number' }, intelligence: { type: 'number' },
              wisdom: { type: 'number' }, charisma: { type: 'number' },
            },
          },
          hp_max: { type: 'number' }, armor_class: { type: 'number' },
          passive_perception: { type: 'number' },
          abilities: { type: 'array', items: { type: 'string' } },
          description: { type: 'string' }, role: { type: 'string' },
        },
      },
    };
  } else {
    base.properties.entries = {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' }, slug: { type: 'string' }, description: { type: 'string' },
        },
      },
    };
  }
  return base;
}