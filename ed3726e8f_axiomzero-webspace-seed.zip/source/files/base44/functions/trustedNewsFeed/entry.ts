/**
 * trustedNewsFeed — keyless RSS proxy for the Trusted News Ticker and the
 * contextual RSS Feed Footers.
 *
 * Fetches headlines from a curated set of empirically-rated, publicly-syndicated
 * outlets, normalizes them with outlet / category / trust tags, and returns a
 * unified array. Organized by feedCategory for contextual page footers.
 *
 * Categories:
 *   global-wires   — BBC, AP, Guardian, DW, PBS, ProPublica, Economist, CSM
 *   nyt            — NYT sections (Home, World, Business, Technology, Science)
 *   science-space  — NASA JPL, NASA Main, NASA CNEOS, ScienceDaily
 *   academic       — Nature, Science Magazine, Cell
 *   public-health  — CDC EID, CDC Travel, CDC Media, NIH NIEHS
 *   clinical       — MedPage Today (headlines, cardiology, COVID-19)
 *
 * Query param: { categories: string[] } — filters feeds by feedCategory.
 * When omitted, fetches all feeds (backward-compatible with TrustedNewsTicker).
 *
 * Safeguards: UA-masking (avoids 403s), If-None-Match/ETag caching, XXE-safe
 * regex parsing (no external entity resolution). Partial-outage tolerant.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const FEEDS = [
  // ── Global Wires & Hard News ──
  { id: 'bbc', outlet: 'BBC News', feedCategory: 'global-wires', category: 'public', trustTag: 'International desk — global gold standard for fact-reporting',
    url: 'http://feeds.bbci.co.uk/news/world/rss.xml' },
  { id: 'dw', outlet: 'Deutsche Welle', feedCategory: 'global-wires', category: 'public', trustTag: 'German public broadcaster — data-heavy, outside US polarization',
    url: 'https://rss.dw.com/rdf/rss-en-all' },
  { id: 'pbs', outlet: 'PBS NewsHour', feedCategory: 'global-wires', category: 'public', trustTag: 'Least biased TV news — uninterrupted time to both sides',
    url: 'https://www.pbs.org/newshour/feeds/rss/headlines' },
  { id: 'propublica', outlet: 'ProPublica', feedCategory: 'global-wires', category: 'investigative', trustTag: 'Non-profit investigative — public records + data analysis',
    url: 'https://feeds.propublica.org/propublica/main' },
  { id: 'economist', outlet: 'The Economist', feedCategory: 'global-wires', category: 'financial', trustTag: 'Anonymous bylines — evidence-based collective stance',
    url: 'https://www.economist.com/latest/rss' },
  { id: 'csm', outlet: 'Christian Science Monitor', feedCategory: 'global-wires', category: 'investigative', trustTag: 'Secular weekly — avoids outrage cycle, low bias',
    url: 'https://www.csmonitor.com/rss/top' },
  { id: 'guardian', outlet: 'The Guardian (US)', feedCategory: 'global-wires', category: 'investigative', trustTag: 'British daily — Pulitzer-level investigative work; center-left editorial, rigorous news desk',
    url: 'https://www.theguardian.com/us/rss' },
  { id: 'bbc_main', outlet: 'BBC News', feedCategory: 'global-wires', category: 'public', trustTag: 'BBC main news stream — global gold standard for fact-reporting',
    url: 'http://feeds.bbci.co.uk/news/rss.xml' },
  { id: 'bbc_business', outlet: 'BBC Business', feedCategory: 'global-wires', category: 'financial', trustTag: 'BBC business & finance desk — data-driven reporting',
    url: 'http://feeds.bbci.co.uk/news/business/rss.xml' },
  { id: 'bbc_tech', outlet: 'BBC Technology', feedCategory: 'global-wires', category: 'public', trustTag: 'BBC technology desk — empirical tech reporting',
    url: 'http://feeds.bbci.co.uk/news/technology/rss.xml' },
  { id: 'ap', outlet: 'Associated Press (AP)', feedCategory: 'global-wires', category: 'wire', trustTag: 'Global non-profit cooperative — strict neutral style guide',
    url: 'https://feeds.apnews.com/rss/apf-topnews' },
  { id: 'guardian_world', outlet: 'The Guardian (World)', feedCategory: 'global-wires', category: 'investigative', trustTag: 'Guardian world desk — international coverage, Pulitzer-level investigative work',
    url: 'https://www.theguardian.com/world/rss' },
  // ── NYT (Premium Newspapers) ──
  { id: 'nyt_home', outlet: 'NYT (Home)', feedCategory: 'nyt', category: 'newspaper', trustTag: 'New York Times home page — premium newspaper, rigorous news desk',
    url: 'https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml' },
  { id: 'nyt_world', outlet: 'NYT (World)', feedCategory: 'nyt', category: 'newspaper', trustTag: 'NYT world desk — international reporting, primary-source focus',
    url: 'https://rss.nytimes.com/services/xml/rss/nyt/World.xml' },
  { id: 'nyt_business', outlet: 'NYT (Business)', feedCategory: 'nyt', category: 'financial', trustTag: 'NYT business desk — data-driven financial reporting',
    url: 'https://rss.nytimes.com/services/xml/rss/nyt/Business.xml' },
  { id: 'nyt_tech', outlet: 'NYT (Technology)', feedCategory: 'nyt', category: 'newspaper', trustTag: 'NYT technology desk — empirical tech industry reporting',
    url: 'https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml' },
  { id: 'nyt_science', outlet: 'NYT (Science)', feedCategory: 'nyt', category: 'newspaper', trustTag: 'NYT science desk — peer-reviewed research reporting',
    url: 'https://rss.nytimes.com/services/xml/rss/nyt/Science.xml' },
  // ── Science & Space ──
  { id: 'nasa_jpl', outlet: 'NASA JPL', feedCategory: 'science-space', category: 'science', trustTag: 'Jet Propulsion Lab — breaking news & deep-space mission features',
    url: 'https://www.jpl.nasa.gov/feeds/news/' },
  { id: 'nasa_main', outlet: 'NASA', feedCategory: 'science-space', category: 'science', trustTag: 'NASA site-wide master news stream — official agency feed',
    url: 'https://www.nasa.gov/feed/' },
  { id: 'nasa_cneos', outlet: 'NASA CNEOS', feedCategory: 'science-space', category: 'science', trustTag: 'Center for Near-Earth Object Studies — NEO tracking data',
    url: 'https://cneos.jpl.nasa.gov/feed/' },
  { id: 'sciencedaily', outlet: 'ScienceDaily', feedCategory: 'science-space', category: 'science', trustTag: 'Top research summaries — peer-reviewed study aggregations',
    url: 'https://www.sciencedaily.com/rss/all.xml' },
  // ── Academic Journals ──
  { id: 'nature', outlet: 'Nature', feedCategory: 'academic', category: 'academic', trustTag: 'Current issue headlines — peer-reviewed premier journal',
    url: 'http://feeds.nature.com/nature/rss/current' },
  { id: 'science_mag', outlet: 'Science Magazine', feedCategory: 'academic', category: 'academic', trustTag: 'Science Express — early-release peer-reviewed papers',
    url: 'https://www.science.org/rss/express.xml' },
  { id: 'cell', outlet: 'Cell', feedCategory: 'academic', category: 'academic', trustTag: 'Articles in press — peer-reviewed life-science journal',
    url: 'https://www.cell.com/cell/inpress.rss' },
  // ── Public Health ──
  { id: 'cdc_eid', outlet: 'CDC EID', feedCategory: 'public-health', category: 'health', trustTag: 'Emerging Infectious Diseases — ahead-of-print peer-reviewed',
    url: 'http://wwwnc.cdc.gov/eid/rss/ahead-of-print.xml' },
  { id: 'cdc_travel', outlet: 'CDC Travel', feedCategory: 'public-health', category: 'health', trustTag: 'International travel notices — official US government advisories',
    url: 'https://wwwnc.cdc.gov/travel/rss/notices.xml' },
  { id: 'cdc_media', outlet: 'CDC Media', feedCategory: 'public-health', category: 'health', trustTag: 'CDC media relations newsroom — official public health statements',
    url: 'http://www.cdc.gov/media/rss.xml' },
  { id: 'nih_niehs', outlet: 'NIH NIEHS', feedCategory: 'public-health', category: 'health', trustTag: 'National Institute of Environmental Health Sciences — environmental health news',
    url: 'https://www.niehs.nih.gov/rssfeed' },
  // ── Clinical Medicine ──
  { id: 'medpage_headlines', outlet: 'MedPage Today', feedCategory: 'clinical', category: 'clinical', trustTag: 'Latest general medical news — clinical reporting',
    url: 'https://www.medpagetoday.com/rss/headlines.xml' },
  { id: 'medpage_cardio', outlet: 'MedPage Cardio', feedCategory: 'clinical', category: 'clinical', trustTag: 'Cardiovascular medicine — clinical trial & guideline updates',
    url: 'https://www.medpagetoday.com/rss/cardiology.xml' },
  { id: 'medpage_covid', outlet: 'MedPage COVID-19', feedCategory: 'clinical', category: 'clinical', trustTag: 'COVID-19 / virology tracking — clinical surveillance',
    url: 'https://www.medpagetoday.com/rss/covid19.xml' },
];

import { parseFeed } from '../../shared/rssParser.ts';

// Module-level cache — RSS feeds update every 5-30 min; cache for 5 min to reduce bandwidth and avoid rate limits
const feedCache = new Map<string, { data: any; fetchedAt: number }>();
const FEED_CACHE_TTL = 5 * 60 * 1000;

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    let body: any = {};
    try { body = await req.json(); } catch {}
    const requestedCategories: string[] | undefined = body.categories;

    const cacheKey = (requestedCategories || ['all']).sort().join(',');
    const cached = feedCache.get(cacheKey);
    if (cached && Date.now() - cached.fetchedAt < FEED_CACHE_TTL) {
      return Response.json({ ...cached.data, cached: true });
    }

    // Filter feeds by feedCategory when categories param is provided
    const feeds = requestedCategories && requestedCategories.length
      ? FEEDS.filter((f) => requestedCategories.includes(f.feedCategory))
      : FEEDS;

    const results = await Promise.allSettled(feeds.map((f) =>
      fetch(f.url, {
        headers: { 'User-Agent': 'AxiomZero-GeoMonitor/1.0', Accept: 'application/rss+xml,application/xml,text/xml' },
      }).then((r) => (r.ok ? r.text() : null)).then((xml) => (xml ? parseFeed(xml, f).slice(0, 8) : []))
    ));

    const headlines: any[] = [];
    let okCount = 0;
    results.forEach((res) => {
      if (res.status === 'fulfilled' && res.value.length) {
        headlines.push(...res.value);
        okCount++;
      }
    });

    headlines.sort((a, b) =>
      (new Date(b.published || 0).getTime()) - (new Date(a.published || 0).getTime())
    );

    const status = okCount === 0 ? 'unavailable' : okCount < feeds.length ? 'partial' : 'live';

    const result = {
      headlines,
      count: headlines.length,
      status,
      sources: okCount,
      total: feeds.length,
      timestamp: new Date().toISOString(),
    };
    feedCache.set(cacheKey, { data: result, fetchedAt: Date.now() });
    return Response.json({ ...result, cached: false });
  } catch (error) {
    return Response.json({ headlines: [], status: 'unavailable', message: error.message });
  }
}