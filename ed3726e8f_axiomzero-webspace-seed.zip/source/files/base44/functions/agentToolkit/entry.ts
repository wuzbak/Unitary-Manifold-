import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';
import {
  DOMAINS, FUNCTIONS, INTEGRATIONS, ENTITIES, CONNECTORS, SECRETS,
  findFunction, findIntegration, findEntity,
} from '../../shared/agentRegistry.ts';

/**
 * agentToolkit — Agent-readable discovery API (read-only).
 *
 * Views:
 *   view=index    — compact one-line-per-tool index across all domains
 *   view=domain   — modular section (requires domain param)
 *   view=tool     — full detail for one tool (requires tool param)
 *   view=full     — entire capability map in one JSON payload
 *   view=state    — live runtime state (repo version, connector auth, secret availability, entity counts + samples)
 *
 * Requires authenticated user. Read-only — safe for any logged-in agent.
 */
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    let body = {};
    try { body = await req.json(); } catch {}
    const { view = 'index', domain, tool } = body;

    if (view === 'index') return Response.json(buildIndex());
    if (view === 'domain') return Response.json(buildDomain(domain));
    if (view === 'tool') return Response.json(buildToolDetail(tool));
    if (view === 'full') return Response.json(buildFull());
    if (view === 'state') return Response.json(await buildLiveState(base44));

    return Response.json({ error: `Unknown view: ${view}. Use index|domain|tool|full|state.` }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message, status: 'unavailable', view: null }, { status: 200 });
  }
}

// ── INDEX ──────────────────────────────────────────────────────────
function buildIndex() {
  const functions = FUNCTIONS.map(f => ({ name: f.name, type: 'function', category: f.category, summary: f.summary, admin: f.admin }));
  const integrations = INTEGRATIONS.map(i => ({ name: i.name, type: 'integration', category: i.category, summary: i.summary, admin: i.admin }));
  const entities = ENTITIES.map(e => ({ name: e.name, type: 'entity', summary: e.summary, ops: ['list', 'get', 'create', 'update', 'delete', 'filter', 'schema'] }));
  const connectors = CONNECTORS.map(c => ({ name: `connector.${c.type}`, type: 'connector', summary: c.summary }));
  const secretNames = SECRETS.map(s => ({ name: s.name, type: 'secret', description: s.description }));
  return {
    view: 'index',
    description: 'Compact one-line-per-tool index. Drill in with view=tool&tool=<name>, view=domain&domain=<id>, or view=full.',
    domains: DOMAINS,
    counts: { functions: functions.length, integrations: integrations.length, entities: entities.length, connectors: connectors.length, secrets: secretNames.length },
    functions,
    integrations,
    entities,
    connectors,
    secrets: secretNames,
  };
}

// ── DOMAIN ─────────────────────────────────────────────────────────
function buildDomain(domain) {
  if (!domain) return { error: 'domain param required for view=domain. One of: ' + DOMAINS.map(d => d.id).join(', ') };
  const dom = DOMAINS.find(d => d.id === domain);
  if (!dom) return { error: `Unknown domain: ${domain}. Valid: ${DOMAINS.map(d => d.id).join(', ')}` };

  let payload;
  switch (domain) {
    case 'functions':
      payload = FUNCTIONS.map(f => ({ name: f.name, category: f.category, summary: f.summary, brief: f.brief, params: f.params, returns: f.returns, secret: f.secret || null, admin: f.admin, example: f.example }));
      break;
    case 'integrations':
      payload = INTEGRATIONS.map(i => ({ name: i.name, category: i.category, summary: i.summary, brief: i.brief, params: i.params, returns: i.returns, admin: i.admin, example: i.example }));
      break;
    case 'entities':
      payload = ENTITIES.map(e => ({ name: e.name, summary: e.summary, ops: ['list', 'get', 'create', 'update', 'delete', 'filter', 'bulkCreate', 'schema'] }));
      break;
    case 'connectors':
      payload = CONNECTORS.map(c => ({ type: c.type, summary: c.summary }));
      break;
    case 'secrets':
      payload = SECRETS.map(s => ({ name: s.name, description: s.description }));
      break;
    case 'merlin':
      payload = FUNCTIONS.filter(f => f.category === 'merlin').map(f => ({ name: f.name, category: f.category, summary: f.summary, brief: f.brief, params: f.params, returns: f.returns, admin: f.admin, example: f.example }));
      break;
    default:
      return { error: `Domain ${domain} is static-only. Use view=state for live state.` };
  }
  return { view: 'domain', domain, label: dom.label, description: dom.description, tools: payload };
}

// ── TOOL DETAIL ────────────────────────────────────────────────────
function buildToolDetail(tool) {
  if (!tool) return { error: 'tool param required for view=tool.' };

  // Backend function
  const fn = findFunction(tool);
  if (fn) {
    return { view: 'tool', tool, type: 'function', name: fn.name, category: fn.category, summary: fn.summary, brief: fn.brief, params: fn.params, returns: fn.returns, secret: fn.secret || null, admin: fn.admin, example: fn.example, how_to_call: `agentInvoke({ tool: "${fn.name}", args: {...} })` };
  }
  // Integration
  const integ = findIntegration(tool);
  if (integ) {
    return { view: 'tool', tool, type: 'integration', name: integ.name, category: integ.category, summary: integ.summary, brief: integ.brief, params: integ.params, returns: integ.returns, admin: integ.admin, example: integ.example, how_to_call: `agentInvoke({ tool: "${integ.name}", args: {...} })` };
  }
  // Entity operation: entity.<Name>.<op>
  const m = tool.match(/^entity\.([A-Za-z_]+)\.([a-zA-Z]+)$/);
  if (m) {
    const ent = findEntity(m[1]);
    if (ent) {
      const op = m[2];
      return { view: 'tool', tool, type: 'entity', entity: ent.name, operation: op, summary: ent.summary, how_to_call: `agentInvoke({ tool: "entity.${ent.name}.${op}", args: {...} })`, args_hint: entityArgsHint(op) };
    }
  }
  // Connector
  const cm = tool.match(/^connector\.([a-z_]+)$/);
  if (cm) {
    const conn = CONNECTORS.find(c => c.type === cm[1]);
    if (conn) return { view: 'tool', tool, type: 'connector', connector: conn.type, summary: conn.summary, how_to_call: `agentInvoke({ tool: "connector.${conn.type}", args: {} })`, returns: 'Connection status + (for authorized connectors) access token context. Token is used server-side only.' };
  }
  return { error: `Tool not found: ${tool}. Use view=index to list all tools.` };
}

function entityArgsHint(op) {
  const hints = {
    list: 'args: { sort?, limit? } — returns array of records.',
    get: 'args: { id } — returns one record.',
    create: 'args: { ...fields } — creates one record, returns it.',
    update: 'args: { id, ...fields } — updates one record, returns it.',
    delete: 'args: { id } — deletes one record.',
    filter: 'args: { query, sort?, limit? } — returns matching records.',
    bulkCreate: 'args: { records: [...] } — creates multiple records.',
    schema: 'args: {} — returns the entity JSON schema (no built-in fields).',
  };
  return hints[op] || 'See entity SDK operations.';
}

// ── FULL ───────────────────────────────────────────────────────────
function buildFull() {
  return {
    view: 'full',
    description: 'Entire capability map in one payload. For when an agent wants everything at once.',
    domains: DOMAINS,
    functions: FUNCTIONS,
    integrations: INTEGRATIONS,
    entities: ENTITIES,
    connectors: CONNECTORS,
    secrets: SECRETS,
  };
}

// ── LIVE STATE ─────────────────────────────────────────────────────
async function buildLiveState(base44) {
  const state = { view: 'state', fetchedAt: new Date().toISOString(), repo: null, connectors: {}, secrets: {}, entities: {} };

  // Repo version via existing fetchRepoContext
  try {
    const repoRes = await base44.functions.invoke('fetchRepoContext', {});
    state.repo = repoRes?.data || repoRes || null;
  } catch (e) {
    state.repo = { error: e.message };
  }

  // Connector auth state
  for (const c of CONNECTORS) {
    try {
      const conn = await base44.asServiceRole.connectors.getConnection(c.type);
      state.connectors[c.type] = { authorized: true, summary: c.summary };
    } catch {
      state.connectors[c.type] = { authorized: false, summary: c.summary };
    }
  }

  // Secret availability (boolean only — values never exposed)
  for (const s of SECRETS) {
    try {
      const val = secrets.get(s.name);
      state.secrets[s.name] = { available: !!val, description: s.description };
    } catch {
      state.secrets[s.name] = { available: false, description: s.description };
    }
  }

  // Entity schemas, counts, and samples (user-scoped reads respect RLS)
  for (const e of ENTITIES) {
    if (e.name === 'User') { state.entities[e.name] = { summary: e.summary, note: 'Built-in. Read-only via SDK. Use base44.entities.User.list() — admin-only for other users.' }; continue; }
    try {
      const entityClient = base44.entities[e.name];
      if (!entityClient) { state.entities[e.name] = { summary: e.summary, error: 'Entity client not available' }; continue; }
      let schema = null, samples = null, count = null;
      try { schema = await entityClient.schema(); } catch {}
      try { samples = await entityClient.list('-created_date', 3); } catch {}
      state.entities[e.name] = {
        summary: e.summary,
        schema,
        sample_count: samples ? samples.length : 0,
        samples: samples ? samples.map(s => sanitizeRecord(s)) : [],
      };
    } catch (err) {
      state.entities[e.name] = { summary: e.summary, error: err.message };
    }
  }

  return state;
}

// Strip large/recursive fields from sample records to keep payload small
function sanitizeRecord(rec) {
  if (!rec || typeof rec !== 'object') return rec;
  const out = {};
  for (const [k, v] of Object.entries(rec)) {
    if (typeof v === 'string' && v.length > 500) out[k] = v.slice(0, 500) + '…[truncated]';
    else if (Array.isArray(v) && v.length > 10) out[k] = `[${v.length} items]`;
    else out[k] = v;
  }
  return out;
}