import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { unavailableResponse } from '../../shared/degradedResponse.ts';
import { fetchWithResilience } from '../../shared/resilientFetch.ts';

/**
 * adsbFlightTracker — resilient multi-source flight tracking.
 *
 * Cascade: ADSB.lol (primary) → airplanes.live (free, no key, fallback).
 * A single upstream 503/timeout no longer empties the flight tracker.
 * All sources normalize to the same aircraft schema with a `source` provenance tag.
 */

function normalizeAc(rawAc: any[], source: string, ptime?: number) {
  return rawAc.map((a: any) => ({
    icao24: a.hex,
    callsign: a.flight?.trim() || null,
    registration: a.r || null,
    aircraftType: a.t || null,
    latitude: a.lat,
    longitude: a.lon,
    altitudeBaro: a.alt_baro,
    altitudeGeom: a.alt_geom,
    groundSpeed: a.gs,
    track: a.track,
    verticalRate: a.bar_rate || a.geom_rate,
    squawk: a.squawk,
    emergency: a.emergency || null,
    category: a.category || null,
    onGround: a.alt_baro === 'ground',
    fromOrigin: a.from || null,
    toDestination: a.to || null,
    lastSeen: a.now || ptime,
    source,
  })).filter((a: any) => a.latitude != null && a.longitude != null);
}

function buildUrl(source: string, mode: string, query: string, lat: number, lon: number, dist: number): string {
  const base = source === 'adsb.lol' ? 'https://api.adsb.lol/v2' : 'https://api.airplanes.live/v2';
  if (mode === 'callsign' && query) return `${base}/callsign/${encodeURIComponent(query)}`;
  if (mode === 'icao' && query) return `${base}/icao/${encodeURIComponent(query)}`;
  if (mode === 'mil') return `${base}/mil`;
  return `${base}/${source === 'adsb.lol' ? 'lat' : 'point'}/${lat}/${lon}/${dist}`;
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const { query, lat, lon, dist, mode = 'area' } = body;
    const d = dist || 250;

    const needsCoords = !(mode === 'callsign' || mode === 'icao' || mode === 'mil');
    if (mode !== 'mil' && ((mode === 'callsign' || mode === 'icao') ? !query : (lat == null || lon == null))) {
      return Response.json({ error: 'Provide either query (callsign/icao) or lat+lon+dist' }, { status: 400 });
    }

    const sources = ['adsb.lol', 'airplanes.live'];
    let lastErr = '';
    for (const src of sources) {
      const url = buildUrl(src, mode, query, lat, lon, d);
      const res = await fetchWithResilience(url, {
        headers: { 'Accept': 'application/json', 'User-Agent': 'AxiomZero-GeoMonitor' },
        retries: 1, timeoutMs: 10000, cacheTtl: 60000,
      });
      if (res.data && Array.isArray(res.data.ac)) {
        const aircraft = normalizeAc(res.data.ac, src, res.data.ptime);
        // Return on a live fetch (even 0 aircraft = definitive "none in area"),
        // or on a cached/degraded fetch that has results.
        if (res.status === 'live' || aircraft.length > 0) {
          return Response.json({
            aircraft,
            count: aircraft.length,
            source: `${src} (community unfiltered)`,
            ctime: res.data.ctime,
            ptime: res.data.ptime,
            fetchStatus: res.status,
            timestamp: new Date().toISOString(),
          });
        }
      }
      lastErr = res.error || 'no data';
    }

    return unavailableResponse({ aircraft: [], count: 0, source: 'ADSB.lol + airplanes.live' }, 'unavailable', `All flight sources unavailable (${lastErr})`);
  } catch (error) {
    return unavailableResponse({ aircraft: [], count: 0, source: 'ADSB.lol + airplanes.live' }, 'unavailable', error.message);
  }
}