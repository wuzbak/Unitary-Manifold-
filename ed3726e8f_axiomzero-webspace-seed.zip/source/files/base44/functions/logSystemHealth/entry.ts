/**
 * logSystemHealth — scheduled health-check logger.
 *
 * Runs the full system health check (same logic as systemHealthCheck) and
 * writes a summary to the AuditLog entity. Called by the System Health
 * Monitor workflow every 6 hours.
 *
 * If any system is RED, the log entry is tagged as "alert" so it can be
 * surfaced in the Governance Ledger.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';

const SECRET_CHECKS = [
  { key: 'OPENROUTER_API_KEY', label: 'OpenRouter (AI)' },
  { key: 'OPENSANCTIONS_API_KEY', label: 'OpenSanctions' },
  { key: 'OPENCORPORATES_API_TOKEN', label: 'OpenCorporates' },
  { key: 'FEC_API_KEY', label: 'FEC' },
  { key: 'COURTLISTENER_API_TOKEN', label: 'CourtListener' },
  { key: 'GOVINFO_API_KEY', label: 'GovInfo' },
  { key: 'SEC_EDGAR_CONTACT_EMAIL', label: 'SEC EDGAR' },
  { key: 'ALEPH_API_TOKEN', label: 'OCCRP Aleph' },
  { key: 'NASA_API_KEY', label: 'NASA CNEOS' },
  { key: 'FIRMS_MAP_KEY', label: 'NASA FIRMS' },
  { key: 'EIA_API_KEY', label: 'EIA Grid' },
  { key: 'AIRNOW_API_KEY', label: 'AirNow' },
  { key: 'OPENSKY_CLIENT_ID', label: 'OpenSky' },
  { key: 'ACLED_EMAIL', label: 'ACLED' },
];

const PUBLIC_ENDPOINTS = [
  { label: 'NOAA SWPC', url: 'https://services.swpc.noaa.gov/json/planetary_k_index_1m.json' },
  { label: 'USGS Earthquakes', url: 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/significant_day.geojson' },
  { label: 'NASA EONET', url: 'https://eonet.gsfc.nasa.gov/api/v2.1/events?limit=1&days=1' },
  { label: 'GDACS', url: 'https://www.gdacs.org/xml/rss.xml' },
  { label: 'BBC News RSS', url: 'http://feeds.bbci.co.uk/news/world/rss.xml' },
  { label: 'NPR News RSS', url: 'https://feeds.npr.org/1001/rss.xml' },
  { label: 'Defense.gov RSS', url: 'https://www.defense.gov/DesktopModules/ArticleCS/RSS.ashx?ContentType=1&Site=1065&max=20' },
  { label: 'ICIJ Offshore', url: 'https://offshoreleaks.icij.org' },
  { label: 'DOJ Epstein', url: 'https://www.justice.gov/epstein' },
  { label: 'USGS Volcanoes', url: 'https://volcanoes.usgs.gov/hans-public/api/volcano/getElevatedVolcanoes' },
];

async function probe(url: string): Promise<boolean> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    const res = await fetch(url, { method: 'GET', signal: controller.signal, headers: { 'User-Agent': 'AxiomZero-HealthCheck/1.0' } });
    clearTimeout(timeout);
    return res.ok;
  } catch {
    return false;
  }
}

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    // Check secrets
    const secretResults = SECRET_CHECKS.map((s) => {
      let configured = false;
      try { configured = !!(secrets.get(s.key) || '').trim(); } catch {}
      return { label: s.label, status: configured ? 'green' : 'amber' };
    });

    // Probe public endpoints
    const publicResults = await Promise.all(PUBLIC_ENDPOINTS.map(async (ep) => ({
      label: ep.label,
      status: (await probe(ep.url)) ? 'green' : 'red',
    })));

    // Check GitHub connector
    let ghStatus = 'red';
    try {
      const conn = await base44.asServiceRole.connectors.getConnection('github');
      if (conn?.accessToken) ghStatus = 'green';
    } catch {}

    const allChecks = [...secretResults, ...publicResults, { label: 'GitHub Connector', status: ghStatus }];
    const green = allChecks.filter((c) => c.status === 'green').length;
    const amber = allChecks.filter((c) => c.status === 'amber').length;
    const red = allChecks.filter((c) => c.status === 'red').length;
    const total = allChecks.length;

    const redSystems = allChecks.filter((c) => c.status === 'red').map((c) => c.label);
    const amberSystems = allChecks.filter((c) => c.status === 'amber').map((c) => c.label);

    // Write to AuditLog
    const eventType = red > 0 ? 'system_health_alert' : 'system_health_ok';
    const details = JSON.stringify({
      overall: red > 0 ? 'issues' : amber > 0 ? 'warnings' : 'all-green',
      summary: { green, amber, red, total },
      red: redSystems,
      amber: amberSystems,
      timestamp: new Date().toISOString(),
    });

    try {
      await base44.asServiceRole.entities.AuditLog.create({
        event_type: eventType,
        manager: 'systemHealthCheck-workflow',
        task_ref: 'scheduled-health-monitor',
        details,
      });
    } catch (e) {
      // AuditLog write failure shouldn't fail the function
    }

    return Response.json({
      overall: red > 0 ? 'issues' : amber > 0 ? 'warnings' : 'all-green',
      summary: { green, amber, red, total },
      red: redSystems,
      amber: amberSystems,
      logged: true,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ error: (error as Error).message, logged: false }, { status: 200 });
  }
}