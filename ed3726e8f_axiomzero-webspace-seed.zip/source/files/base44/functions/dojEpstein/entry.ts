import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { makeSource, okResponse, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';

/**
 * dojEpstein — DOJ Epstein Library (justice.gov/epstein).
 * The library's full-text search is a JavaScript-driven portal behind an age gate,
 * so it cannot be scraped server-side. This fetcher returns:
 *   1. A pre-filled deep link to the search results (keys=<query>) the journalist
 *      opens in-browser to run the actual search and copy findings.
 *   2. The structured DOJ disclosure categories (Court Records, FOIA, prior
 *      disclosures) as browseable source records.
 * This is honest about the portal limitation while still giving one-click search+copy.
 *
 * Portal: https://www.justice.gov/epstein
 *
 * Theory, methodology: ThomasCory Walker-Pearson / AxiomZero Technologies & Consulting, SPC.
 * Implementation: GitHub Copilot (AI).
 */

const DISCLOSURE_LINKS = [
  { title: 'DOJ Disclosures — Court Records', url: 'https://www.justice.gov/epstein/doj-disclosures', excerpt: 'Court records released under the Epstein Files Transparency Act (H.R. 4405).' },
  { title: 'DOJ Disclosures — FOIA Records', url: 'https://www.justice.gov/epstein/doj-disclosures', excerpt: 'Freedom of Information Act releases pertaining to Jeffrey Epstein.' },
  { title: 'House Oversight Committee Releases', url: 'https://oversight.house.gov/release/oversight-committee-releases-epstein-records-provided-by-the-department-of-justice/', excerpt: 'Records provided by DOJ to the House Committee on Oversight and Accountability.' },
];

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'DOJ Epstein Library', 'No query provided');

    const sources: any[] = [
      makeSource({
        title: `DOJ Epstein Library — Search: "${query}"`,
        tier: 1,
        source_type: 'Federal disclosure portal — full-text search (open in browser)',
        url_or_ref: `https://www.justice.gov/epstein/search?keys=${encodeURIComponent(query)}`,
        date: '',
        excerpt: `Pre-filled search of the DOJ Epstein Library (3.5M+ pages: flight manifests, grand jury exhibits, prison logs). Opens the age-verified portal — run the search in-browser and copy results here.`,
        raw_metadata: { portal: 'justice.gov/epstein', query },
      }),
      ...DISCLOSURE_LINKS.map((d) => makeSource({
        title: d.title,
        tier: 1,
        source_type: 'Federal disclosure category — browseable document index',
        url_or_ref: d.url,
        date: '',
        excerpt: d.excerpt,
        raw_metadata: { portal: 'justice.gov/epstein' },
      })),
    ];
    return okResponse(sources, query, 'DOJ Epstein Library');
  } catch (error) {
    return Response.json({ error: (error as Error).message }, { status: 500 });
  }
}