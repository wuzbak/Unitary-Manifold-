import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

/**
 * resolveStreamUrl — resolves .pls / .m3u / .m3u8 / .asx / .ram / .qtl playlist
 * files to their direct streamable audio URL(s). Many radio stations expose a
 * playlist file rather than a direct stream; the browser <audio> element cannot
 * play a .pls, so we resolve it server-side.
 *
 * Returns { resolved_url, alt_urls, codec_hint, is_playlist }
 * Cached 1 hour in a module Map.
 */
const USER_AGENT = 'AxiomZero-SDR-Radio/1.0 (https://axiomzero-webspace-prototype.base44.app)';
const cache = new Map<string, { data: any; at: number }>();
const CACHE_TTL = 3600000; // 1 hour

const PLAYLIST_EXT = /\.(pls|m3u|m3u8|asx|ram|qtl|wax|wvx)$/i;
const PLAYLIST_CT = /(playlist|mpegurl|scpls|asx|audio\/x-)/i;

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    // Public endpoint — no auth gate. This is a pure URL resolver (no entity
    // reads or writes), so anonymous visitors can resolve playlist streams.

    const body = await req.json().catch(() => ({}));
    const url: string = (body?.url || '').trim();
    if (!url || !/^https?:\/\//i.test(url)) {
      return Response.json({ error: 'Valid url required' }, { status: 400 });
    }

    // Cache hit
    const cached = cache.get(url);
    if (cached && Date.now() - cached.at < CACHE_TTL) {
      return Response.json({ ...cached.data, fromCache: true });
    }

    // If the URL doesn't look like a playlist, return it as-is
    const looksLikePlaylist = PLAYLIST_EXT.test(url);
    if (!looksLikePlaylist) {
      // Still do a lightweight HEAD to confirm content-type — some streams hide
      // playlists behind extensionless URLs.
      const result = { resolved_url: url, alt_urls: [] as string[], codec_hint: '', is_playlist: false };
      cache.set(url, { data: result, at: Date.now() });
      return Response.json(result);
    }

    // Fetch the playlist text
    const res = await fetch(url, {
      headers: { 'User-Agent': USER_AGENT, 'Accept': 'audio/x-scpls,application/mpegurl,audio/x-mpegurl,text/plain,*/*' },
      // @ts-ignore — signal is valid
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) {
      // If fetch fails, fall back to the original URL (client will attempt it)
      const result = { resolved_url: url, alt_urls: [] as string[], codec_hint: '', is_playlist: false, error: `HTTP ${res.status}` };
      cache.set(url, { data: result, at: Date.now() });
      return Response.json(result);
    }
    const ct = res.headers.get('content-type') || '';
    const text = await res.text();

    // If the content is actually a direct stream (binary), not a playlist text
    if (!PLAYLIST_CT.test(ct) && !PLAYLIST_EXT.test(url) && text.length > 0 && text.charCodeAt(0) > 127) {
      const result = { resolved_url: url, alt_urls: [] as string[], codec_hint: ct, is_playlist: false };
      cache.set(url, { data: result, at: Date.now() });
      return Response.json(result);
    }

    const base = url;
    const urls = parsePlaylist(text, base, url);

    if (urls.length === 0) {
      // Couldn't parse — fall back to original
      const result = { resolved_url: url, alt_urls: [] as string[], codec_hint: '', is_playlist: true, error: 'parse-empty' };
      cache.set(url, { data: result, at: Date.now() });
      return Response.json(result);
    }

    const result = {
      resolved_url: urls[0],
      alt_urls: urls.slice(1, 6),
      codec_hint: guessCodec(urls[0]),
      is_playlist: true,
    };
    cache.set(url, { data: result, at: Date.now() });
    return Response.json({ ...result, fromCache: false });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

/**
 * Parse a playlist file body into a list of absolute stream URLs.
 * Handles PLS, M3U/M3U8, ASX, RAM/QTL.
 */
function parsePlaylist(text: string, baseUrl: string, originalUrl: string): string[] {
  const lower = text.toLowerCase();
  // PLS: [playlist] File1=...
  if (lower.includes('[playlist]') || /file\d+\s*=/i.test(text)) {
    const files = text.match(/file\d+\s*=\s*(.+)/gi) || [];
    return files.map((f) => f.replace(/file\d+\s*=\s*/i, '').trim()).filter(Boolean).map((u) => abs(u, baseUrl));
  }
  // ASX: <ref href="..."/>
  if (lower.includes('<asx') || /<ref\s+href/i.test(text)) {
    const refs = text.match(/<ref\s+href\s*=\s*"([^"]+)"/gi) || [];
    return refs.map((r) => r.replace(/<ref\s+href\s*=\s*"([^"]+)"/i, '$1').trim()).filter(Boolean).map((u) => abs(u, baseUrl));
  }
  // M3U / M3U8: lines that are URLs (skip #EXT)
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter((l) => l && !l.startsWith('#'));
  if (lines.length > 0) {
    return lines.filter((l) => /^https?:\/\//i.test(l) || !l.startsWith('#')).map((u) => abs(u, baseUrl));
  }
  return [];
}

function abs(u: string, baseUrl: string): string {
  try {
    return new URL(u, baseUrl).href;
  } catch {
    return u;
  }
}

function guessCodec(url: string): string {
  const u = url.toLowerCase();
  if (u.includes('.ogg') || u.includes('.opus')) return 'OGG';
  if (u.includes('.aac') || u.includes('aac')) return 'AAC';
  if (u.includes('.m3u8')) return 'HLS';
  return 'MP3';
}