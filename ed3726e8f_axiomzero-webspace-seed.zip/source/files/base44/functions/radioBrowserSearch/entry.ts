import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { fetchWithResilience } from '../../shared/resilientFetch.ts';
import { isBlockedStation } from '../../shared/stationBlocklist.ts';

/**
 * radioBrowserSearch — advanced faceted search over the radio-browser.info
 * database (50,000+ stations). Supports tag/genre, country, countrycode,
 * language, codec, bitrate, and ordering (trending, popular, random, top).
 *
 * Modes:
 *   - 'search'    → faceted search by tag/country/language/codec
 *   - 'trending'  → order by clicktrend (rising popularity)
 *   - 'popular'   → order by votes (community favorites)
 *   - 'top'       → order by clickcount (most-played)
 *   - 'random'    → order by random (discover mode)
 *   - 'facets'    → return top tags/countries/languages/codecs for browse chips
 *
 * Results are normalized into SdrStation records (source: 'radio_browser_api'),
 * de-duplicated against the cache by stream_url, and bulk-created. Cached 10 min.
 */
const RADIO_BROWSER_MIRRORS = [
  'https://all.api.radio-browser.info',
  'https://fi1.api.radio-browser.info',
  'https://de1.api.radio-browser.info',
  'https://nl1.api.radio-browser.info',
];
const VALID_CODECS = ['MP3', 'AAC', 'AAC+', 'OGG', 'FLAC', 'OPUS'];
const MAX_RESULTS = 80;
const USER_AGENT = 'AxiomZero-SDR-Radio/1.0 (https://axiomzero-webspace-prototype.base44.app)';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    // Public endpoint — no auth gate. SdrStation has public read RLS ({}) and
    // writes use asServiceRole, so anonymous visitors can use Discovery.

    const body = await req.json().catch(() => ({}));
    const mode: string = (body?.mode || 'search').trim();
    const tag: string = (body?.tag || '').trim();
    const country: string = (body?.country || '').trim();
    const countrycode: string = (body?.countrycode || '').trim();
    const language: string = (body?.language || '').trim();
    const codec: string = (body?.codec || '').trim();
    const bitrateMin: number = parseInt(body?.bitrate_min || '0', 10) || 0;
    const limit: number = Math.min(parseInt(body?.limit || String(MAX_RESULTS), 10) || MAX_RESULTS, 200);

    // ── Facets mode: return top browse lists ──
    if (mode === 'facets') {
      const facets = await fetchFacets();
      return Response.json({ mode, facets });
    }

    // ── Build search query ──
    const order = mode === 'trending' ? 'clicktrend'
      : mode === 'popular' ? 'votes'
      : mode === 'top' ? 'clickcount'
      : mode === 'random' ? 'random'
      : 'votes'; // default search → most-voted first
    const reverse = mode !== 'random';

    const params = new URLSearchParams();
    params.set('limit', String(limit));
    params.set('order', order);
    params.set('reverse', reverse ? 'true' : 'false');
    params.set('hidebroken', 'true');
    if (tag) params.set('tag', tag);
    if (country) params.set('country', country);
    if (countrycode) params.set('countrycode', countrycode.toUpperCase());
    if (language) params.set('language', language);
    if (codec) params.set('codec', codec.toUpperCase());
    if (bitrateMin > 0) params.set('bitrateMin', String(bitrateMin));

    // ── Query mirrors with resilience ──
    let apiStations: any[] = [];
    for (const mirror of RADIO_BROWSER_MIRRORS) {
      const url = `${mirror}/json/stations/search?${params.toString()}`;
      const res = await fetchWithResilience<any[]>(url, {
        headers: { 'User-Agent': USER_AGENT, 'Accept': 'application/json' },
        cacheTtl: 600000, // 10 min
        retries: 1,
        timeoutMs: 10000,
      });
      if (res.data && Array.isArray(res.data) && res.data.length > 0) {
        apiStations = res.data;
        break;
      }
      if (res.status === 'live' && (!res.data || res.data.length === 0)) {
        // mirror responded OK but empty — try next mirror
        continue;
      }
    }

    // ── Filter to streamable + valid codec ──
    const streamable = apiStations.filter((s: any) =>
      s.url_resolved && s.url_resolved.length > 0 &&
      s.lastcheckok === 1 &&
      VALID_CODECS.includes((s.codec || '').toUpperCase())
    ).slice(0, limit);

    // ── Normalize and filter blocked outlets ──
    const records = streamable.map(normalizeStation).filter(s => !isBlockedStation(s));

    // ── Dedup against cache by stream_url ──
    const streamUrls = records.map((r: any) => r.stream_url).filter(Boolean);
    let existing = new Set<string>();
    if (streamUrls.length > 0) {
      try {
        const cached = await base44.asServiceRole.entities.SdrStation.filter(
          { stream_url: { $in: streamUrls }, source: 'radio_browser_api' },
          '-created_date', 500,
        );
        existing = new Set((cached || []).map((c: any) => c.stream_url));
      } catch (e) { /* ignore — proceed */ }
    }
    const fresh = records.filter((r: any) => !existing.has(r.stream_url));

    // ── Bulk-create fresh records ──
    if (fresh.length > 0) {
      try {
        await base44.asServiceRole.entities.SdrStation.bulkCreate(fresh);
      } catch (e) { /* cache write failure is non-fatal */ }
    }

    return Response.json({
      mode,
      total: records.length,
      fresh: fresh.length,
      stations: records,
      source: 'radio_browser_api',
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

/**
 * Fetch top tags, countries, languages, and codecs for browse chips.
 */
async function fetchFacets(): Promise<any> {
  const headers = { 'User-Agent': USER_AGENT, 'Accept': 'application/json' };
  const [tags, countries, languages, codecs] = await Promise.all([
    fetchTop(`${RADIO_BROWSER_MIRRORS[0]}/json/tags?order=stationcount&reverse=true&limit=40`, headers),
    fetchTop(`${RADIO_BROWSER_MIRRORS[0]}/json/countries?order=stationcount&reverse=true&limit=40`, headers),
    fetchTop(`${RADIO_BROWSER_MIRRORS[0]}/json/languages?order=stationcount&reverse=true&limit=40`, headers),
    fetchTop(`${RADIO_BROWSER_MIRRORS[0]}/json/codecs?order=stationcount&reverse=true&limit=20`, headers),
  ]);
  return {
    tags: (tags || []).map((t: any) => ({ name: t.name, count: t.stationcount })).filter((t: any) => t.name && t.count > 30),
    countries: (countries || []).map((c: any) => ({ name: c.name, code: c.iso_3166_1, count: c.stationcount })).filter((c: any) => c.name),
    languages: (languages || []).map((l: any) => ({ name: l.name, count: l.stationcount })).filter((l: any) => l.name && l.count > 20),
    codecs: (codecs || []).map((c: any) => ({ name: c.name, count: c.stationcount })).filter((c: any) => VALID_CODECS.includes((c.name || '').toUpperCase())),
  };
}

async function fetchTop(url: string, headers: Record<string, string>): Promise<any[]> {
  const res = await fetchWithResilience<any[]>(url, { headers, cacheTtl: 3600000, retries: 1, timeoutMs: 10000 });
  return Array.isArray(res.data) ? res.data : [];
}

/**
 * Normalize a radio-browser station to the extended SdrStation schema.
 */
function normalizeStation(s: any): any {
  const tagsRaw = (s.tags || '').split(',').map((t: string) => t.trim()).filter(Boolean);
  const tagsJson = JSON.stringify(tagsRaw.slice(0, 12));
  const altUrls = [s.url, s.url_resolved].filter((u: string) => u && u !== s.url_resolved);
  // dedupe alt urls
  const altSet = Array.from(new Set(altUrls));
  const codecInfo = [s.codec, s.bitrate ? `${s.bitrate}kbps` : ''].filter(Boolean).join(' · ');
  const stationType = (s.tags || '').toLowerCase().includes('fm') && s.geo_lat ? 'fm'
    : (s.tags || '').toLowerCase().includes('am') && s.geo_lat ? 'am'
    : 'internet_stream';

  return {
    name: (s.name || 'Unknown Station').trim(),
    station_type: stationType,
    band: stationType === 'fm' ? 'FM' : stationType === 'am' ? 'AM' : 'Internet',
    region: s.state || s.country || '',
    country: s.country || '',
    country_code: s.countrycode || '',
    frequency_mhz: 0,
    stream_url: s.url_resolved || s.url || '',
    embed_url: '',
    description: codecInfo || 'Internet radio stream',
    status: s.lastcheckok === 1 ? 'active' : 'offline',
    geo_lat: s.geo_lat || 0,
    geo_lng: s.geo_long || 0,
    source: 'radio_browser_api',
    codec: (s.codec || '').toUpperCase(),
    bitrate: s.bitrate || 0,
    vote_count: s.votes || 0,
    click_trend: s.clicktrend || 0,
    favicon_url: s.favicon || '',
    homepage_url: s.homepage || '',
    tags_json: tagsJson,
    language: (s.language || '').split(',')[0]?.trim() || '',
    last_checked_ok: s.lastcheckok === 1,
    alt_urls_json: JSON.stringify(altSet.slice(0, 5)),
  };
}