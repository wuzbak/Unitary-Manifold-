import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { unavailableResponse } from '../../shared/degradedResponse.ts';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json().catch(() => ({}));
    const { state, area } = body;

    let apiUrl = 'https://api.weather.gov/alerts/active?status=actual&message_type=alert';
    if (state) apiUrl += `&area=${encodeURIComponent(state)}`;
    else if (area) apiUrl += `&area=${encodeURIComponent(area)}`;

    const response = await fetch(apiUrl, {
      headers: {
        'Accept': 'application/geo+json',
        'User-Agent': 'AxiomZero-GeoMonitor (cpo@axiomzerospc.org)',
      },
    });

    if (!response.ok) {
      return unavailableResponse({
        alerts: [],
        count: 0,
        source: 'NOAA NWS api.weather.gov',
      }, 'unavailable', `NWS API returned ${response.status}`);
    }

    const data = await response.json();
    const alerts = (data.features || []).map((f: any) => ({
      id: f.id,
      type: 'nwsAlert' as const,
      title: f.properties.event,
      severity: (f.properties.severity || 'unknown').toLowerCase(),
      certainty: f.properties.certainty,
      urgency: f.properties.urgency,
      headline: f.properties.headline,
      description: f.properties.description,
      instruction: f.properties.instruction,
      area: f.properties.areaDesc,
      expires: f.properties.expires,
      sent: f.properties.sent,
      sender: f.properties.senderName,
      coords: f.geometry?.coordinates?.[0]?.[0]
        ? [f.geometry.coordinates[0][0][1], f.geometry.coordinates[0][0][0]]
        : null,
    }));

    return Response.json({
      alerts,
      count: alerts.length,
      source: 'NOAA NWS api.weather.gov',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return unavailableResponse({ alerts: [], count: 0, source: 'NOAA NWS api.weather.gov' }, 'unavailable', error.message);
  }
}