import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';
import { makeSource, okResponse, errResponse, readQuery } from '../../shared/sourceNormalizer.ts';

const BASE = 'https://echodata.epa.gov/echo';
// qcolumns: 1=FAC_NAME, 3=FAC_CITY, 4=FAC_STATE, 5=FAC_ZIP, 6=REGISTRY_ID
const QCOLUMNS = '1,3,4,5,6';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const { query } = await readQuery(req);
    if (!query) return errResponse('', 'EPA ECHO', 'No query provided');

    // Step 1: get_facilities to validate params and obtain a QueryID (QID)
    const url1 = `${BASE}/echo_rest_services.get_facilities?output=JSON&p_fn=${encodeURIComponent(query)}`;
    const res1 = await fetch(url1);
    if (!res1.ok) return errResponse(query, 'EPA ECHO', `API ${res1.status} (get_facilities)`);
    const data1 = await res1.json();
    const qid = data1?.Results?.QueryID;
    if (!qid) return errResponse(query, 'EPA ECHO', 'No QueryID returned');

    // Step 2: get_qid with the QID to retrieve actual facility records
    const url2 = `${BASE}/echo_rest_services.get_qid?output=JSON&qid=${qid}&pageno=1&qcolumns=${QCOLUMNS}`;
    const res2 = await fetch(url2);
    if (!res2.ok) return errResponse(query, 'EPA ECHO', `API ${res2.status} (get_qid)`);
    const data2 = await res2.json();
    const results = (data2?.Results?.Facilities) || [];
    const sources = results.slice(0, 10).map((r: any) => makeSource({
      title: `EPA ECHO Facility: ${r.FacName || query}`,
      tier: 1, source_type: 'EPA enforcement / facility compliance record',
      url_or_ref: r.RegistryID ? `https://echo.epa.gov/detailed-facility-results?fid=${r.RegistryID}` : '',
      date: '',
      excerpt: `Name: ${r.FacName || 'N/A'} · City: ${r.FacCity || 'N/A'} · State: ${r.FacState || 'N/A'} · Zip: ${r.FacZip || 'N/A'}`,
      raw_metadata: r,
    }));
    return okResponse(sources, query, 'EPA ECHO');
  } catch (error) {
    return errResponse('', 'EPA ECHO', (error as Error).message);
  }
}