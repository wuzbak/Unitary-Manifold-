/**
 * merlinDistillInsight — Sovereign cognitive intake pipeline.
 *
 * Called on session close. Compiles the conversation into a distilled
 * artifact through three gates: ECLIPSA PII sanitization, LLM distillation,
 * and contradiction gating against the 208 hardgate pillars.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const PII_PATTERNS = [
  { name: 'email', pattern: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, replacement: '[EMAIL_REDACTED]' },
  { name: 'phone', pattern: /(\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/g, replacement: '[PHONE_REDACTED]' },
  { name: 'ssn', pattern: /\b\d{3}-\d{2}-\d{4}\b/g, replacement: '[SSN_REDACTED]' },
  { name: 'credit_card', pattern: /\b(?:\d[ -]*?){13,16}\b/g, replacement: '[CARD_REDACTED]' },
  { name: 'ip_address', pattern: /\b(?:\d{1,3}\.){3}\d{1,3}\b/g, replacement: '[IP_REDACTED]' },
];

const HARDGATE_INVARIANTS = [
  { id: 'k_CS', value: 74, description: 'Chern-Simons level k_CS = 74', pattern: /k_?CS\s*[:=]\s*(\d+)/i },
  { id: 'n_w', value: 5, description: 'Winding resonance n_w = 5 (Pillar 789)', pattern: /n_?w\s*[:=]\s*(\d+)/i },
  { id: 'w_a', value: 0, description: 'Cosmological constant w_a = 0 (Pillar 301)', pattern: /w_?a\s*[:=]\s*(-?\d+\.?\d*)/i },
  { id: 'r', value: 0.0315, description: 'Tensor-to-scalar ratio r = 0.0315 (Pillar 396)', pattern: /\br\s*[:=]\s*(\d+\.?\d*)/i },
  { id: 'n_s', value: 0.9635, description: 'Scalar spectral index n_s = 0.9635', pattern: /n_?s\s*[:=]\s*(\d+\.?\d*)/i },
  { id: 'dimensions', value: 5, description: '5D Kaluza-Klein dimensionality', pattern: /dimensions?\s*[:=]\s*(\d+)/i },
];

function sanitizePII(text) {
  let sanitized = text;
  const ledger = [];
  for (const { name, pattern, replacement } of PII_PATTERNS) {
    const matches = sanitized.match(pattern);
    if (matches && matches.length > 0) {
      ledger.push({ field: name, pattern: name, action: 'stripped ' + matches.length + ' occurrence(s)' });
      sanitized = sanitized.replace(pattern, replacement);
    }
  }
  return { sanitized, ledger };
}

function checkContradictions(text) {
  const details = [];
  const lowerText = text.toLowerCase();
  for (const inv of HARDGATE_INVARIANTS) {
    const match = text.match(inv.pattern);
    if (match && match[1]) {
      const assertedValue = parseFloat(match[1]);
      if (!isNaN(assertedValue) && Math.abs(assertedValue - inv.value) > 0.001) {
        if (lowerText.includes(inv.id.toLowerCase())) {
          details.push(inv.description + ': asserted ' + assertedValue + ', certified ' + inv.value);
        }
      }
    }
  }
  const falsificationPhrases = [
    /w_?a\s*!=\s*0/i,
    /k_?CS\s*!=\s*74/i,
    /n_?w\s*!=\s*5/i,
  ];
  for (const phrase of falsificationPhrases) {
    if (phrase.test(text)) {
      details.push('Falsification language detected');
    }
  }
  return { flagged: details.length > 0, details };
}

// ── Epistemic Uncertainty Scoring ───────────────────────────────────
// Computes second-order uncertainty when a distilled insight touches a known
// boundary. Confidence bounds assigned by Merlin himself.
const EPISTEMIC_BOUNDARIES = [
  { pattern: /cmb.*peak.*suppress|a_s.*mismatch|33\.6%/i, confidence: 0.336, bounds: 'ARCHITECTURE_LIMIT' },
  { pattern: /dm2_21|δm²₂₁|delta.*m.*2.*1|1\.71.*σ|1\.71.*sigma/i, confidence: 0.91, bounds: 'TENSION_ESCALATED' },
  { pattern: /cc.*kk.*hierarchy|10\^?55|cosmological.*constant.*hierarchy/i, confidence: 1.0, bounds: 'ARCHITECTURE_LIMIT' },
  { pattern: /r[- ]?tension|r\s*=\s*0\.0315|tensor.to.scalar.*r/i, confidence: 0.95, bounds: 'ARCHITECTURE_LIMIT_CERTIFIED' },
  { pattern: /w_?a.*tension|w_?a.*2\.30|desi.*w_?a/i, confidence: 0.98, bounds: 'ARCHITECTURE_LIMIT_CERTIFIED' },
];

function computeEpistemicConfidence(text) {
  for (const boundary of EPISTEMIC_BOUNDARIES) {
    if (boundary.pattern.test(text)) {
      return { confidence: boundary.confidence, bounds: boundary.bounds };
    }
  }
  return { confidence: null, bounds: '' };
}

function determineDomain(context, text) {
  const lower = (context + ' ' + text).toLowerCase();
  if (lower.includes('physics') || lower.includes('manifold') || lower.includes('pillar') ||
      lower.includes('lean4') || lower.includes('k_cs') || lower.includes('kaluza') ||
      lower.includes('falsification') || lower.includes('desi') || lower.includes('litebird')) {
    return 'physics';
  }
  if (lower.includes('film') || lower.includes('production') || lower.includes('scene') ||
      lower.includes('camera') || lower.includes('wardrobe') || lower.includes('cast')) {
    return 'film';
  }
  if (lower.includes('journalist') || lower.includes('investigation') || lower.includes('source') ||
      lower.includes('court') || lower.includes('sec') || lower.includes('watchlist')) {
    return 'journalism';
  }
  if (lower.includes('earth') || lower.includes('soil') || lower.includes('crop') ||
      lower.includes('weather') || lower.includes('geo') || lower.includes('volcano')) {
    return 'earth-science';
  }
  if (lower.includes('dnd') || lower.includes('dungeon') || lower.includes('character') ||
      lower.includes('encounter') || lower.includes('combat') || lower.includes('spell')) {
    return 'dnd';
  }
  return 'general';
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized', status: 'unavailable' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const messages = body.messages || [];
    const contextHint = body.context || '';
    const sessionToken = body.session_token || '';

    if (messages.length === 0) {
      return Response.json({ status: 'noop', reason: 'No messages to distill', artifact: null });
    }

    const conversationText = messages
      .map(m => (m.role === 'user' ? 'User' : 'Merlin') + ': ' + (m.text || ''))
      .join('\n')
      .slice(0, 12000);

    const { sanitized, ledger } = sanitizePII(conversationText);

    const distillSchema = {
      type: 'object',
      properties: {
        title: { type: 'string', description: 'Short title (max 120 chars)' },
        tensions: { type: 'array', items: { type: 'string' } },
        conjectures: { type: 'array', items: { type: 'string' } },
        constraints: { type: 'array', items: { type: 'string' } },
        heuristics: { type: 'array', items: { type: 'string' } },
        domain_tag: { type: 'string', enum: ['physics', 'film', 'journalism', 'earth-science', 'dnd', 'general'] },
        summary: { type: 'string', description: '2-3 sentence summary' },
      },
      required: ['title', 'summary', 'domain_tag'],
    };

    let distilled = null;
    try {
      const llmRes = await base44.integrations.Core.InvokeLLM({
        prompt: 'You are the ECLIPSA distillation gate for the Merlin Navigator. Analyze the following conversation and extract non-PII semantic primitives. Compile them into a structured artifact.\n\nConversation (PII sanitized):\n' + sanitized + '\n\nExtract: tensions, conjectures, constraints, heuristics, a domain tag, and a 2-3 sentence summary.',
        response_json_schema: distillSchema,
      });
      distilled = typeof llmRes === 'object' ? llmRes : null;
    } catch {
      distilled = {
        title: 'Session ' + new Date().toISOString().slice(0, 16),
        summary: sanitized.slice(0, 300),
        tensions: [],
        conjectures: [],
        constraints: [],
        heuristics: [],
        domain_tag: determineDomain(contextHint, sanitized),
      };
    }

    if (!distilled) {
      return Response.json({ status: 'noop', reason: 'Distillation produced no artifact', artifact: null });
    }

    const distilledText = distilled.title + ' ' + distilled.summary + ' ' + (distilled.tensions || []).join(' ') + ' ' + (distilled.conjectures || []).join(' ') + ' ' + (distilled.constraints || []).join(' ');
    const contradiction = checkContradictions(distilledText);
    const domain = distilled.domain_tag || determineDomain(contextHint, distilledText);
    const epistemic = computeEpistemicConfidence(distilledText);

    const primitives = {
      tensions: distilled.tensions || [],
      conjectures: distilled.conjectures || [],
      constraints: distilled.constraints || [],
      heuristics: distilled.heuristics || [],
    };

    const note = await base44.entities.MerlinNote.create({
      title: (distilled.title || 'Distilled Session').slice(0, 200),
      content: (distilled.summary || sanitized.slice(0, 2000)).slice(0, 5000),
      source: 'distillation',
      source_url: '',
      tags_json: JSON.stringify([
        'domain:' + domain,
        contradiction.flagged ? 'contradiction:flagged' : 'contradiction:clear',
        'session:' + (sessionToken ? sessionToken.slice(0, 12) : 'ephemeral'),
        ...(epistemic.confidence != null ? ['epistemic:' + epistemic.bounds] : []),
      ]),
      context: (contextHint || '').slice(0, 1000),
      domain,
      sanitization_ledger: JSON.stringify(ledger),
      contradiction_flag: contradiction.flagged ? 'flagged' : 'clear',
      contradiction_detail: contradiction.details.join('; ').slice(0, 2000),
      session_token: sessionToken.slice(0, 64),
      distilled_primitives_json: JSON.stringify(primitives),
      epistemic_confidence: epistemic.confidence,
      uncertainty_bounds: epistemic.bounds,
      decoherence_count: 0,
      domain_transition_path: '',
    });

    return Response.json({
      status: 'ok',
      artifact: {
        id: note.id,
        title: note.title,
        domain,
        contradiction_flag: note.contradiction_flag,
        contradiction_detail: note.contradiction_detail,
        sanitization_stripped: ledger.length,
        primitives,
        epistemic_confidence: epistemic.confidence,
        uncertainty_bounds: epistemic.bounds,
      },
    });
  } catch (error) {
    return Response.json({
      status: 'unavailable',
      error: error.message,
      artifact: null,
    }, { status: 200 });
  }
}