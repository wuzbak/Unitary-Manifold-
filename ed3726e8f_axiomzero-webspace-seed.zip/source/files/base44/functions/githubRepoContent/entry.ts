/**
 * githubRepoContent — Authenticated, read-only GitHub repository pull.
 *
 * Uses the authorized GitHub OAuth connector (public_repo, read:user scopes).
 * Base44 NEVER writes to the repository — this function is strictly read-only.
 *
 * Actions:
 *   - "tree":  list all markdown docs & research notes in the repo
 *   - "file":  fetch raw content of a single file path
 *
 * Source of truth: https://github.com/wuzbak/Unitary-Manifold-
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.43';

const REPO_OWNER = 'wuzbak';
const REPO_NAME = 'Unitary-Manifold-';
const REPO_BRANCH = 'main';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const action = body.action || 'tree';

    // Authenticated GitHub access via OAuth connector — read-only token
    const { accessToken } = await base44.asServiceRole.connectors.getConnection('github');

    const headers = {
      'Authorization': `Bearer ${accessToken}`,
      'Accept': 'application/vnd.github+json',
      'User-Agent': 'AxiomZero-App',
      'X-GitHub-Api-Version': '2022-11-28',
    };

    if (action === 'tree') {
      const res = await fetch(
        `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/git/trees/${REPO_BRANCH}?recursive=1`,
        { headers }
      );
      if (!res.ok) {
        return Response.json({ entries: [], totalFiles: 0, docsCount: 0, truncated: false, status: 'unavailable', message: `GitHub API error: ${res.status}` }, { status: 200 });
      }
      const data = await res.json();
      const allEntries = (data.tree || [])
        .filter((e) => e.type === 'blob')
        .map((e) => ({ path: e.path, size: e.size }));
      // Curate documentation & research notes: markdown files only
      const docs = allEntries.filter((e) => /\.md$/i.test(e.path));
      return Response.json({
        entries: docs,
        totalFiles: allEntries.length,
        docsCount: docs.length,
        truncated: data.truncated || false,
        repo: `${REPO_OWNER}/${REPO_NAME}`,
        branch: REPO_BRANCH,
        fetchedAt: new Date().toISOString(),
      });
    }

    if (action === 'file') {
      const path = body.path;
      if (!path) return Response.json({ error: 'Path required' }, { status: 400 });
      const res = await fetch(
        `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${path}?ref=${REPO_BRANCH}`,
        { headers: { ...headers, 'Accept': 'application/vnd.github.raw+json' } }
      );
      if (!res.ok) {
        return Response.json({ path: body.path || '', content: '', isTruncated: false, fullLength: 0, status: 'unavailable', message: `Failed to fetch file: ${res.status}` }, { status: 200 });
      }
      const content = await res.text();
      const maxChars = 200000;
      const isTruncated = content.length > maxChars;
      return Response.json({
        path,
        content: content.slice(0, maxChars),
        isTruncated,
        fullLength: content.length,
        fetchedAt: new Date().toISOString(),
      });
    }

    return Response.json({ error: 'Unknown action. Use "tree" or "file".' }, { status: 400 });
  } catch (error) {
    return Response.json({ entries: [], totalFiles: 0, docsCount: 0, truncated: false, status: 'unavailable', message: error.message }, { status: 200 });
  }
}