/**
 * agWeatherReport — Agricultural Weather Report Backend Function
 *
 * Accepts either { lat, lon } or { location } (free-text city/zip/address).
 * If location text is provided, geocodes via Open-Meteo geocoding API (free, no key).
 *
 * Fetches:
 * - Open-Meteo current conditions + 7-day forecast
 * - Open-Meteo historical precipitation (last 30 days) for drought assessment
 * - NOAA NWS active weather alerts (US only, no key required)
 * - Computes GDD (growing degree days) accumulation
 * - Estimates frost dates from climate zone
 *
 * Fallback chain: Open-Meteo → NOAA NWS → estimated climatology
 * No API keys required — all sources are free and open.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { unavailableResponse } from '../../shared/degradedResponse.ts';
import { lookupHardinessZone } from '../../shared/hardinessZoneLookup.ts';
import { fetchWithResilience } from '../../shared/resilientFetch.ts';

// ── Geocoding via Open-Meteo (free, no key) ──
async function geocode(location) {
  try {
    const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(location)}&count=1&language=en&format=json`;
    const resp = await fetch(url);
    if (!resp.ok) throw new Error('Geocoding failed: ' + resp.status);
    const data = await resp.json();
    if (data.results && data.results.length > 0) {
      const r = data.results[0];
      return {
        lat: r.latitude,
        lon: r.longitude,
        name: r.name,
        country: r.country,
        admin1: r.admin1,
        timezone: r.timezone,
      };
    }
    throw new Error('No geocoding results for: ' + location);
  } catch (e) {
    // Fallback: try Nominatim (OpenStreetMap) — free, no key, 1 req/sec limit
    try {
      const url2 = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(location)}&format=json&limit=1`;
      const resp2 = await fetch(url2, { headers: { 'User-Agent': 'AxiomZero-TerraOS/1.0' } });
      if (!resp2.ok) throw new Error('Nominatim failed: ' + resp2.status);
      const data2 = await resp2.json();
      if (data2 && data2.length > 0) {
        return {
          lat: parseFloat(data2[0].lat),
          lon: parseFloat(data2[0].lon),
          name: data2[0].display_name.split(',')[0],
          country: data2[0].display_name.split(',').pop().trim(),
          admin1: '',
          timezone: 'auto',
        };
      }
    } catch (e2) {
      // Last resort: try to parse as zip or lat,lon
      const coords = location.split(',').map(s => parseFloat(s.trim()));
      if (coords.length === 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
        return { lat: coords[0], lon: coords[1], name: `${coords[0]}, ${coords[1]}`, country: 'Unknown', admin1: '', timezone: 'auto' };
      }
    }
    throw new Error('Geocoding failed for all providers: ' + e.message);
  }
}

// ── WMO weather-code mapping for NWS shortForecast text ──
function mapNwsToWmo(text) {
  const t = (text || '').toLowerCase();
  if (t.includes('thunder')) return 95;
  if (t.includes('snow')) return 75;
  if (t.includes('rain shower')) return 80;
  if (t.includes('rain') || t.includes('drizzle')) return 63;
  if (t.includes('fog')) return 45;
  if (t.includes('overcast')) return 3;
  if (t.includes('partly') || t.includes('mostly cloudy')) return 2;
  if (t.includes('cloud')) return 2;
  if (t.includes('clear') || t.includes('sunny')) return 0;
  return 1;
}

// ── NOAA NWS forecast fallback (US only, no key) — returns Open-Meteo shape ──
async function fetchForecastNWS(lat, lon) {
  try {
    const pointsRes = await fetchWithResilience(`https://api.weather.gov/points/${Number(lat).toFixed(4)},${Number(lon).toFixed(4)}`, {
      headers: { 'User-Agent': 'AxiomZero-TerraOS/1.0 (https://axiomzerospc.org)', 'Accept': 'application/geo+json' },
      retries: 1, timeoutMs: 10000, cacheTtl: 600000,
    });
    if (!pointsRes.data?.properties?.forecast) return null;
    const fcstRes = await fetchWithResilience(pointsRes.data.properties.forecast, {
      headers: { 'User-Agent': 'AxiomZero-TerraOS/1.0 (https://axiomzerospc.org)', 'Accept': 'application/geo+json' },
      retries: 1, timeoutMs: 10000, cacheTtl: 600000,
    });
    if (!fcstRes.data?.properties?.periods) return null;
    const periods = fcstRes.data.properties.periods;
    const dayByDate = {};
    for (const p of periods) {
      const date = (p.startTime || '').slice(0, 10);
      if (!date) continue;
      if (!dayByDate[date]) dayByDate[date] = { tmax: -Infinity, tmin: Infinity, precipProb: 0, weatherCode: 1 };
      const tempC = p.temperature != null ? (p.temperature - 32) * 5 / 9 : null;
      if (tempC != null) {
        if (p.isDaytime) dayByDate[date].tmax = Math.max(dayByDate[date].tmax, tempC);
        else dayByDate[date].tmin = Math.min(dayByDate[date].tmin, tempC);
      }
      if (p.probabilityOfPrecipitation?.value != null) dayByDate[date].precipProb = Math.max(dayByDate[date].precipProb, p.probabilityOfPrecipitation.value);
      dayByDate[date].weatherCode = mapNwsToWmo(p.shortForecast || '');
    }
    const dates = Object.keys(dayByDate).sort().slice(0, 7);
    const first = periods[0] || {};
    const currentTempC = first.temperature != null ? (first.temperature - 32) * 5 / 9 : null;
    return {
      current: {
        temperature_2m: currentTempC,
        relative_humidity_2m: null,
        precipitation: null,
        wind_speed_10m: first.windSpeed ? parseInt(String(first.windSpeed)) : null,
        weather_code: mapNwsToWmo(first.shortForecast || ''),
        time: first.startTime,
      },
      daily: {
        time: dates,
        temperature_2m_max: dates.map(d => dayByDate[d].tmax === -Infinity ? null : dayByDate[d].tmax),
        temperature_2m_min: dates.map(d => dayByDate[d].tmin === Infinity ? null : dayByDate[d].tmin),
        precipitation_sum: dates.map(() => 0),
        precipitation_probability_max: dates.map(d => dayByDate[d].precipProb),
        weather_code: dates.map(d => dayByDate[d].weatherCode),
        sunrise: dates.map(() => null),
        sunset: dates.map(() => null),
        et0_fao_evapotranspiration: dates.map(() => null),
      },
      _source: 'NOAA NWS',
    };
  } catch { return null; }
}

// ── Forecast: Open-Meteo (primary) → NOAA NWS fallback (US) ──
async function fetchForecast(lat, lon) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code` +
    `&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,weather_code,sunrise,sunset,et0_fao_evapotranspiration` +
    `&timezone=auto&forecast_days=7`;
  const res = await fetchWithResilience(url, {
    headers: { 'Accept': 'application/json', 'User-Agent': 'AxiomZero-TerraOS/1.0 (https://axiomzerospc.org)' },
    retries: 2, timeoutMs: 12000, cacheTtl: 300000,
  });
  if (res.data) return res.data;
  // Open-Meteo rate-limited/unavailable — try NOAA NWS (US only)
  const nws = await fetchForecastNWS(lat, lon);
  if (nws) return nws;
  return { error: res.error || `status ${res.status}`, fallback: true };
}

// ── Open-Meteo Historical (free, no key) — resilient, for drought assessment ──
async function fetchHistorical(lat, lon, days = 30) {
  const endDate = new Date().toISOString().split('T')[0];
  const startDate = new Date(Date.now() - days * 86400000).toISOString().split('T')[0];
  const url = `https://archive-api.open-meteo.com/v1/archive?latitude=${lat}&longitude=${lon}` +
    `&start_date=${startDate}&end_date=${endDate}` +
    `&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,et0_fao_evapotranspiration` +
    `&timezone=auto`;
  const res = await fetchWithResilience(url, {
    headers: { 'Accept': 'application/json', 'User-Agent': 'AxiomZero-TerraOS/1.0 (https://axiomzerospc.org)' },
    retries: 2, timeoutMs: 12000, cacheTtl: 600000,
  });
  if (res.data) return res.data;
  return { error: res.error || `status ${res.status}`, fallback: true };
}

// ── NOAA NWS Active Alerts (US only, free, no key) ──
async function fetchNWSAlerts(lat, lon) {
  try {
    // NWS alerts by point — US only
    const url = `https://api.weather.gov/alerts/active?point=${lat.toFixed(4)},${lon.toFixed(4)}`;
    const resp = await fetch(url, {
      headers: {
        'User-Agent': 'AxiomZero-TerraOS/1.0 (https://axiomzerospc.org)',
        'Accept': 'application/geo+json',
      },
    });
    if (!resp.ok) {
      if (resp.status === 404) return { features: [] }; // No alerts = 404 sometimes
      throw new Error('NWS failed: ' + resp.status);
    }
    const data = await resp.json();
    return data;
  } catch (e) {
    return { error: e.message, features: [], fallback: true };
  }
}

// ── Compute GDD from daily temps ──
function computeGDD(dailyTemps, tbase) {
  let cumulative = 0;
  return dailyTemps.map(day => {
    const gdd = Math.max(0, ((day.tmax + day.tmin) / 2) - tbase);
    cumulative += gdd;
    return { date: day.date, gdd, cumulative };
  });
}

// ── Compute drought index from historical precipitation ──
function computeDroughtIndex(historical) {
  if (!historical || historical.error || !historical.daily) return { status: 'Unknown', index: null, desc: 'Historical data unavailable' };
  const precip = historical.daily.precipitation_sum || [];
  const totalPrecip = precip.reduce((s, p) => s + (p || 0), 0);
  const days = precip.length || 30;
  const avgDailyPrecip = totalPrecip / days;

  // Simple drought classification based on 30-day precipitation
  // (US Drought Monitor uses more complex Palmer Index, but this is a practical proxy)
  if (avgDailyPrecip < 0.02) return { status: 'Severe Drought', index: 'D3', totalPrecip: totalPrecip.toFixed(1), desc: 'Critically low precipitation — irrigation essential' };
  if (avgDailyPrecip < 0.04) return { status: 'Moderate Drought', index: 'D2', totalPrecip: totalPrecip.toFixed(1), desc: 'Below-normal precipitation — supplemental watering recommended' };
  if (avgDailyPrecip < 0.08) return { status: 'Abnormally Dry', index: 'D0', totalPrecip: totalPrecip.toFixed(1), desc: 'Slightly below normal — monitor soil moisture' };
  return { status: 'Normal', index: 'None', totalPrecip: totalPrecip.toFixed(1), desc: 'Adequate precipitation for most crops' };
}

// ── WMO weather code interpretation ──
function weatherCodeDesc(code) {
  const codes = {
    0: 'Clear sky', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast',
    45: 'Fog', 48: 'Depositing rime fog',
    51: 'Light drizzle', 53: 'Moderate drizzle', 55: 'Dense drizzle',
    61: 'Slight rain', 63: 'Moderate rain', 65: 'Heavy rain',
    66: 'Freezing rain', 67: 'Heavy freezing rain',
    71: 'Slight snow', 73: 'Moderate snow', 75: 'Heavy snow',
    80: 'Rain showers', 81: 'Moderate showers', 82: 'Violent showers',
    85: 'Snow showers', 86: 'Heavy snow showers',
    95: 'Thunderstorm', 96: 'Thunderstorm with hail', 99: 'Severe thunderstorm',
  };
  return codes[code] || 'Unknown';
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json();
    const { lat, lon, location, gddBase = 10 } = body;

    let coords = { lat, lon };
    let placeName = '';

    // Geocode if location text provided
    if (location && (!lat || !lon)) {
      coords = await geocode(location);
      placeName = coords.name + (coords.admin1 ? ', ' + coords.admin1 : '') + (coords.country ? ', ' + coords.country : '');
    } else if (lat && lon) {
      placeName = `${lat.toFixed(3)}, ${lon.toFixed(3)}`;
    } else {
      return Response.json({ error: 'Provide either { lat, lon } or { location }' }, { status: 400 });
    }

    // Parallel fetch all data sources
    const [forecast, historical, nwsAlerts] = await Promise.all([
      fetchForecast(coords.lat, coords.lon),
      fetchHistorical(coords.lat, coords.lon, 30),
      fetchNWSAlerts(coords.lat, coords.lon),
    ]);

    // Look up USDA hardiness zone via hybrid authoritative system
    // (phzmapi.org USDA 2023 → Open-Meteo historical → latitude fallback)
    const zipMatch = location && location.match(/\b(\d{5})\b/);
    const zoneResult = await lookupHardinessZone({
      zip: zipMatch ? zipMatch[1] : null,
      lat: coords.lat,
      lon: coords.lon,
    });
    const zone = zoneResult.zoneNum;
    const frostDates = zoneResult.frostDates;
    const year = new Date().getFullYear();

    // Compute GDD from forecast (7-day, base 10°C default)
    let gdd7Day = [];
    if (forecast && !forecast.error && forecast.daily) {
      const dailyTemps = forecast.daily.time.map((date, i) => ({
        date,
        tmax: forecast.daily.temperature_2m_max[i],
        tmin: forecast.daily.temperature_2m_min[i],
      }));
      gdd7Day = computeGDD(dailyTemps, gddBase);
    }

    // Compute drought index
    const drought = computeDroughtIndex(historical);

    // Parse NWS alerts
    const alerts = (nwsAlerts && nwsAlerts.features) ? nwsAlerts.features.map(f => ({
      event: f.properties.event,
      headline: f.properties.headline,
      description: f.properties.description?.slice(0, 500),
      severity: f.properties.severity,
      certainty: f.properties.certainty,
      ends: f.properties.ends,
      onset: f.properties.onset,
    })) : [];

    // Build current conditions
    const current = forecast && !forecast.error && forecast.current ? {
      temperature: forecast.current.temperature_2m,
      humidity: forecast.current.relative_humidity_2m,
      precipitation: forecast.current.precipitation,
      windSpeed: forecast.current.wind_speed_10m,
      weatherCode: forecast.current.weather_code,
      weatherDesc: weatherCodeDesc(forecast.current.weather_code),
      time: forecast.current.time,
    } : null;

    // Build 7-day forecast
    const dailyForecast = forecast && !forecast.error && forecast.daily ? forecast.daily.time.map((date, i) => ({
      date,
      tmax: forecast.daily.temperature_2m_max[i],
      tmin: forecast.daily.temperature_2m_min[i],
      precipSum: forecast.daily.precipitation_sum[i],
      precipProb: forecast.daily.precipitation_probability_max?.[i],
      weatherCode: forecast.daily.weather_code[i],
      weatherDesc: weatherCodeDesc(forecast.daily.weather_code[i]),
      sunrise: forecast.daily.sunrise?.[i],
      sunset: forecast.daily.sunset?.[i],
      et0: forecast.daily.et0_fao_evapotranspiration?.[i],
    })) : [];

    // Crop danger alerts — frost, heat, drought
    const cropDanger = [];
    if (current && current.temperature < 2) {
      cropDanger.push({ type: 'Frost', severity: 'High', desc: 'Near-freezing temperatures — protect tender crops' });
    }
    if (current && current.temperature > 35) {
      cropDanger.push({ type: 'Heat Stress', severity: 'High', desc: 'Extreme heat — provide shade and extra water' });
    }
    if (drought.index === 'D2' || drought.index === 'D3') {
      cropDanger.push({ type: 'Drought', severity: drought.index === 'D3' ? 'Severe' : 'Moderate', desc: drought.desc });
    }
    // Check forecast for frost risk
    for (const day of dailyForecast) {
      if (day.tmin <= 0 && new Date(day.date) <= new Date(Date.now() + 7 * 86400000)) {
        cropDanger.push({ type: 'Frost Forecast', severity: 'High', desc: `Frost expected on ${day.date} (low: ${day.tmin}°C) — protect crops` });
        break;
      }
    }

    const report = {
      location: {
        query: location || placeName,
        name: placeName,
        lat: coords.lat,
        lon: coords.lon,
        country: coords.country,
      },
      zone: zoneResult.halfZone || zone.toString(),
      zoneSource: zoneResult.source,
      zoneSourceTier: zoneResult.sourceTier,
      frostDates: {
        lastSpring: `${year}-${frostDates.lastSpring}`,
        firstFall: `${year}-${frostDates.firstFall}`,
        growingDays: frostDates.growingDays,
      },
      current,
      forecast7Day: dailyForecast,
      gdd7Day,
      gddBase,
      drought,
      alerts,
      cropDanger,
      sources: {
        forecast: forecast?.error ? 'fallback' : (forecast?._source || 'Open-Meteo'),
        historical: historical?.error ? 'fallback' : 'Open-Meteo Archive',
        alerts: nwsAlerts?.error ? 'fallback' : 'NOAA NWS',
        geocoding: 'Open-Meteo Geocoding',
      },
      forecastError: forecast?.error || null,
      historicalError: historical?.error || null,
      timestamp: new Date().toISOString(),
    };

    return Response.json(report);
  } catch (error) {
    return unavailableResponse({ location: null, current: null, forecast7Day: [], gdd7Day: [], alerts: [], cropDanger: [], drought: { status: 'Unknown', index: null, desc: 'Weather data unavailable' } }, 'unavailable', error.message);
  }
}