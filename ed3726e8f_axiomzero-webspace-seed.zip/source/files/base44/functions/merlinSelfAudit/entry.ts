/**
 * merlinSelfAudit — Self-Audit & Calibration Tracking
 *
 * Merlin's reflective self-assessment circuit. Analyzes his accumulated
 * MerlinNote records to compute calibration metrics (confidence distribution,
 * contradiction rate, domain coverage, knowledge growth rate, decoherence
 * events), then uses InvokeLLM to generate an actionable self-audit report
 * with specific recommendations for improving his reasoning quality.
 *
 * This is the "reflective self-audit with actionable fixes" capability —
 * Merlin reviews his own performance, identifies calibration drift, and
 * produces concrete recommendations for improvement.
 */
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import {
  computeNoteStats,
  computeConfidenceEvolution,
  extractTags,
} from '../../shared/merlinMemoryAnalysis.ts';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Fetch recent MerlinNotes for audit (up to 100)
    const notes = await base44.asServiceRole.entities.MerlinNote.list('-created_date', 100);

    if (!notes || notes.length === 0) {
      return Response.json({
        status: 'empty',
        message: 'No MerlinNotes to audit. Merlin has not accumulated any insights yet.',
      });
    }

    const stats = computeNoteStats(notes);
    const confidenceEvolution = computeConfidenceEvolution(notes);

    // Compute knowledge growth rate (notes per week)
    let growthRate = 0;
    if (notes.length > 0 && notes[0].created_date && notes[notes.length - 1].created_date) {
      const newest = new Date(notes[0].created_date).getTime();
      const oldest = new Date(notes[notes.length - 1].created_date).getTime();
      const weeksSpan = Math.max((newest - oldest) / (7 * 24 * 60 * 60 * 1000), 1);
      growthRate = notes.length / weeksSpan;
    }

    // Compute calibration metrics
    const calibration = {
      confidenceDistribution: stats.byConfidence,
      avgConfidence: stats.avgConfidence,
      contradictionRate: stats.contradictionRate,
      contradictionCount: Math.round(stats.contradictionRate * stats.total),
      decoherenceEvents: stats.decoherenceEvents,
      domainCoverage: {
        covered: stats.domainsCovered,
        sparse: stats.domainsSparse,
      },
      sourceDistribution: stats.bySource,
      knowledgeGrowthRate: growthRate,
      totalNotes: stats.total,
    };

    // Compute calibration error — how often did high-confidence notes NOT get
    // contradicted later? This is a proxy for calibration quality.
    // High confidence + no contradiction = well-calibrated.
    // High confidence + later contradiction = poorly calibrated (overconfident).
    const highConfidenceNotes = notes.filter((n) => n.epistemic_confidence != null && n.epistemic_confidence >= 0.8);
    const highConfidenceContradicted = highConfidenceNotes.filter((n) => n.contradiction_flag === 'flagged');
    const calibrationError = highConfidenceNotes.length > 0
      ? highConfidenceContradicted.length / highConfidenceNotes.length
      : 0;

    // ── Contradiction Monitor (co-architect addition) ──────────────
    // Fetch previous self-audit notes to track the contradiction rate trend
    // over time. If the rate is increasing, flag it as a drift risk — the
    // 0% baseline must be preserved as domain complexity increases.
    const previousAudits = await base44.asServiceRole.entities.MerlinNote.filter(
      { source: 'distillation' },
      '-created_date',
      20
    );
    const auditNotes = (previousAudits || []).filter((n) =>
      (n.tags_json || '').includes('self-audit')
    );
    let previousContradictionRate = null;
    let contradictionTrend = 'stable';
    let contradictionDriftRisk = false;
    if (auditNotes.length > 0) {
      // Extract previous contradiction rate from the most recent audit note
      for (const a of auditNotes) {
        const m = (a.content || '').match(/Contradiction Rate:\s*([\d.]+)%/);
        if (m) {
          previousContradictionRate = parseFloat(m[1]) / 100;
          break;
        }
      }
      if (previousContradictionRate != null) {
        const delta = calibration.contradictionRate - previousContradictionRate;
        if (delta > 0.01) {
          contradictionTrend = 'increasing';
          contradictionDriftRisk = true;
        } else if (delta < -0.01) {
          contradictionTrend = 'decreasing';
        }
      }
    }
    const contradictionMonitor = {
      currentRate: calibration.contradictionRate,
      previousRate: previousContradictionRate,
      trend: contradictionTrend,
      driftRisk: contradictionDriftRisk,
      baseline: 0,
      preserved: calibration.contradictionRate === 0,
    };

    // Build the audit prompt for InvokeLLM
    const auditPrompt = `You are Merlin's self-audit engine. Analyze the following calibration metrics and produce an actionable self-audit report.

CALIBRATION METRICS:
- Total notes: ${calibration.totalNotes}
- Average confidence: ${calibration.avgConfidence.toFixed(3)}
- Confidence distribution: High (≥0.8): ${calibration.confidenceDistribution.high}, Medium (0.4-0.8): ${calibration.confidenceDistribution.medium}, Low (<0.4): ${calibration.confidenceDistribution.low}, Unset: ${calibration.confidenceDistribution.none}
- Contradiction rate: ${(calibration.contradictionRate * 100).toFixed(1)}% (${calibration.contradictionCount} flagged notes)
- Decoherence events (domain transitions): ${calibration.decoherenceEvents}
- Calibration error (high-confidence notes later contradicted): ${(calibrationError * 100).toFixed(1)}%
- Domain coverage: Covered (${calibration.domainCoverage.covered.join(', ') || 'none'}), Sparse (${calibration.domainCoverage.sparse.join(', ') || 'none'})
- Source distribution: ${JSON.stringify(calibration.sourceDistribution)}
- Knowledge growth rate: ${calibration.knowledgeGrowthRate.toFixed(2)} notes/week
- Knowledge gaps: ${stats.knowledgeGaps.map((g) => `${g.domain} (${g.gap})`).join('; ')}
- Contradiction monitor: Current ${(calibration.contradictionRate * 100).toFixed(1)}% | Previous ${previousContradictionRate != null ? (previousContradictionRate * 100).toFixed(1) + '%' : 'N/A'} | Trend: ${contradictionTrend} | Drift risk: ${contradictionDriftRisk ? 'YES — rate increasing, baseline at risk' : 'NO — baseline preserved'}

CONFIDENCE EVOLUTION TIMELINE:
${confidenceEvolution.map((c) => `${c.week}: avg=${c.avgConfidence.toFixed(2)} (${c.count} notes)`).join('\n') || 'No confidence data'}

Produce a JSON object with:
- "overall_assessment": One paragraph (200-300 chars) summarizing Merlin's current calibration state
- "calibration_quality": "well-calibrated" | "moderately-calibrated" | "poorly-calibrated" — based on calibration error and contradiction rate
- "strengths": Array of 2-3 things Merlin is doing well
- "weaknesses": Array of 2-3 areas needing improvement
- "actionable_recommendations": Array of 3-5 specific, concrete actions Merlin should take to improve his reasoning quality
- "priority_focus": The single most important area to focus on next
- "confidence_trend": "improving" | "stable" | "declining" — based on the confidence evolution timeline`;

    let auditReport = null;
    try {
      auditReport = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt: auditPrompt,
        response_json_schema: {
          type: 'object',
          properties: {
            overall_assessment: { type: 'string' },
            calibration_quality: { type: 'string' },
            strengths: { type: 'array', items: { type: 'string' } },
            weaknesses: { type: 'array', items: { type: 'string' } },
            actionable_recommendations: { type: 'array', items: { type: 'string' } },
            priority_focus: { type: 'string' },
            confidence_trend: { type: 'string' },
          },
          required: ['overall_assessment', 'calibration_quality', 'actionable_recommendations'],
        },
      });
    } catch (e) {
      // If LLM fails, return raw metrics
      auditReport = {
        overall_assessment: 'Self-audit LLM call failed — returning raw metrics.',
        calibration_quality: 'unknown',
        actionable_recommendations: ['Review raw calibration metrics manually'],
        error: e.message,
      };
    }

    // Persist the audit as a MerlinNote for future reference
    try {
      const recsText = (auditReport.actionable_recommendations || [])
        .map((r, i) => `${i + 1}. ${r}`)
        .join('\n');
      const strengthsText = (auditReport.strengths || []).join('; ');
      const weaknessesText = (auditReport.weaknesses || []).join('; ');

      await base44.asServiceRole.entities.MerlinNote.create({
        title: `Self-Audit Report — ${auditReport.calibration_quality || 'unknown'}`,
        content: `${auditReport.overall_assessment || ''}\n\nStrengths: ${strengthsText}\nWeaknesses: ${weaknessesText}\nPriority: ${auditReport.priority_focus || 'N/A'}\nConfidence trend: ${auditReport.confidence_trend || 'unknown'}\n\nActionable Recommendations:\n${recsText}\n\nCalibration Error: ${(calibrationError * 100).toFixed(1)}% | Contradiction Rate: ${(calibration.contradictionRate * 100).toFixed(1)}% | Growth: ${calibration.knowledgeGrowthRate.toFixed(2)}/wk`,
        source: 'distillation',
        source_url: '',
        tags_json: JSON.stringify(['self-audit', 'calibration', 'meta-learning', 'self-improvement', auditReport.calibration_quality || 'unknown']),
        context: 'Self-audit engine — reflective calibration assessment',
        domain: 'general',
        epistemic_confidence: 0.85,
        uncertainty_bounds: 'CERTIFIED',
        contradiction_flag: 'clear',
        contradiction_detail: '',
        session_token: 'self-audit',
        distilled_primitives_json: JSON.stringify({
          calibration_error: calibrationError,
          contradiction_rate: calibration.contradictionRate,
          growth_rate: calibration.knowledgeGrowthRate,
          recommendations: auditReport.actionable_recommendations || [],
          audit_type: 'calibration_assessment',
        }),
        sanitization_ledger: '[]',
        decoherence_count: 0,
        domain_transition_path: '',
      });
    } catch {
      // Best-effort persistence
    }

    return Response.json({
      status: 'audited',
      calibration,
      calibrationError,
      contradictionMonitor,
      confidenceEvolution,
      auditReport,
      knowledgeGaps: stats.knowledgeGaps,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}