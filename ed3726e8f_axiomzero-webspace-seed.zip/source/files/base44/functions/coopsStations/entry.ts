/**
 * coopsStations — proxies the NOAA CO-OPS Metadata API water-level station
 * list (no key required). Returns coastal water-level monitoring station
 * coverage points (id, name, lat, lon, state).
 * Public data proxy (no auth) — station metadata is public information.
 */
import { unavailableResponse } from '../../shared/degradedResponse.ts';

export default async function (req: Request): Promise<Response> {
  try {
    const res = await fetch('https://api.tidesandcurrents.noaa.gov/mdapi/prod/webapi/stations.json?type=waterlevels', {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; AxiomZeroGeoMonitor/1.0)' },
    });
    if (!res.ok) return unavailableResponse({ stations: [], count: 0 }, 'unavailable', `COOPS ${res.status}`);
    const data: any = await res.json();
    const stations: any[] = (data.stations || [])
      .map((s: any) => ({
        id: String(s.id || ''),
        name: s.name || '',
        lat: parseFloat(s.lat),
        lon: parseFloat(s.lng),
        state: s.state || '',
        type: 'waterlevel',
      }))
      .filter((s: any) => !isNaN(s.lat) && !isNaN(s.lon) && s.id);
    return Response.json({ stations, count: stations.length });
  } catch (error) {
    return unavailableResponse({ stations: [], count: 0 }, 'unavailable', (error as Error).message);
  }
}